import hashlib,json,pathlib
r=pathlib.Path(__file__).resolve().parent
m=json.loads((r/"manifest.json").read_text())
for n,h in m.items():
 p=(r/n).resolve()
 assert p.is_relative_to(r),n
 assert hashlib.sha256(p.read_bytes()).hexdigest()==h,n
print("PASS",len(m),"files; byte integrity only")

# Paper-writing results / 论文写作结果

A writing snapshot of existing aggregates, not a new experiment or an acceptance decision. Null means unspecified; missing coverage is not a pass.

Use source configurations and report scope with every citation. GPU is not a mathematical oracle. DeepSeek mixed-FP8/FP4 TP4 versus adapted-BF16 TP8/EP8/offload48 is not a hardware-only comparison.

Qwen3.5 default NPU checkpoint continuation was 298/448 exact arrays; native deterministic level 1 reached 448/448. This supports a configuration-scoped conclusion.

Independent examples, dependent coordinates, repeated processes and overlapping operator prefixes are different units. Do not pool them as independent samples.

The numeric ledger includes configuration/count fields and dependent observations as well as measurements. Unspecified units must be read in the source/report, never guessed.

Operator alternate stacks change together. Active-cotangent diagnostics are post-outcome, not untouched validation. H200 is user-confirmed; raw H20Z metadata is retained.

DeepSeek has 191/275 paired tensor cells and 3168/3168 targets. Explicit gaps remain in gap-ledger and report. No claim of all numerical chains complete.

This portable aggregate bundle supports byte-integrity and exact source-pointer checks. Private raw-array numerical replay requires retained private evidence and is not included.

读取 results.json 的 sources / numeric_fields；CSV 数值含精确来源 JSON Pointer。报告和图在 reports/ 与 figures/。禁止忽略配置限定，禁止将缺项写成通过。

Run `python -I -B verify.py` here to verify included bytes. Reports retain their original scientific context; this export does not ship private replay tools, raw arrays, weights or full datasets.

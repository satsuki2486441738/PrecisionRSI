"""Actual original35-ref portable proof integration; no array I/O or Torch.

The unmodified original11f6 source map resolves metadata-only copies from the
independently SHA-verified observer GPU archive. No original JSON is rewritten.
The old failure is reproduced first; numerical function ASTs remain identical.
"""
from contextlib import ExitStack, contextmanager
import ast
import hashlib
import importlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
CASE = HERE.parent
for folder in (HERE, CASE/'transfer', HERE.parents[4]/'skills/precision-compare/scripts'):
    sys.path.insert(0, str(folder))
import numpy as np
import observer_artifact_admission_v1 as old
import observer_artifact_admission_v2 as new
import admit_observer_transparency_v1 as old_main
import admit_observer_transparency_v2 as new_main

MAP = CASE/'transfer/observer-gpu-metadata-local-20261106T232937Z/payload/source-map.json'
MAP_SHA = '11f6107b3f86f55f9d5f4a213f0233a1b9f2a8b8a9af0169cbd036abdcb59b1b'
OUTER = '/srv/precision-task/observer-transparency-20261107-gpu-v2/claims/REDACTED_APP_ID/capture-receipt.json'
OUTER_SHA = '71538b5c387d56997f5b1bf3553d8f29236f6f1255f63e3943080a3b5bb01765'


@contextmanager
def array_io_forbidden():
    opened, stated = Path.open, Path.stat
    def guard_open(path, *args, **kwargs):
        if path.suffix in ('.npy', '.safetensors'): raise AssertionError('array opened in metadata proof integration')
        return opened(path, *args, **kwargs)
    def guard_stat(path, *args, **kwargs):
        if path.suffix in ('.npy', '.safetensors'): raise AssertionError('array stat in metadata proof integration')
        return stated(path, *args, **kwargs)
    with ExitStack() as stack:
        stack.enter_context(patch.object(Path, 'open', guard_open)); stack.enter_context(patch.object(Path, 'stat', guard_stat))
        stack.enter_context(patch.object(np, 'load', side_effect=AssertionError('NumPy array load forbidden')))
        stack.enter_context(patch.object(np, 'memmap', side_effect=AssertionError('NumPy memmap forbidden')))
        yield


def endpoint(module):
    result = module.Endpoint(MAP, MAP_SHA)
    outer = result.json(OUTER, OUTER_SHA)
    return result, outer['i04_prerequisite_source_path'], outer['cpu_prerequisite_source_path']


class ActualProofCopy(unittest.TestCase):
    def test_01_original_failure_reproduced_without_any_array_io(self):
        self.assertEqual(old.sha(old.__file__), 'd6b4458e0bb861ef4b12d62655eff58712fa06c3e702abe2b456a44ac081c95a')
        self.assertEqual(old_main.sha(old_main.__file__), '799f5ab8d19505914bd1246c6912c56456a1a8ce54c30da1febdcc09529670a6')
        with tempfile.TemporaryDirectory() as folder, array_io_forbidden():
            ep, i04, cpu = endpoint(old)
            with self.assertRaisesRegex(AttributeError, 'as_posix'):
                old.copy_dual(ep, i04, cpu, Path(folder)/'prerequisites')
        self.assertIsInstance(new.prior.safe_relative('proof/real-original.json'), str)

    def test_02_actual32raw_plus2wrapper_copy_and35_ref_validation(self):
        with tempfile.TemporaryDirectory() as folder, array_io_forbidden():
            ep, i04, cpu = endpoint(new)
            before = {str(MAP): new.sha(MAP)}
            target = Path(folder)/'prerequisites'
            names = new.copy_dual(ep, i04, cpu, target)
            self.assertEqual(len(names), 34)
            checked = new.proof.prerequisite(target/'i04/prerequisite.json', new.I04_SHA,
                target/'cpu/prerequisite.json', new.CPU_SHA)
            self.assertEqual(len(checked['refs']), 35)
            self.assertEqual(checked['native_executions_started'], 0)
            self.assertEqual(new.sha(target/'i04/prerequisite.json'), new.I04_SHA)
            self.assertEqual(new.sha(target/'cpu/prerequisite.json'), new.CPU_SHA)
            self.assertEqual(len(list((target/'i04').rglob('*.*'))), 9)
            self.assertEqual(len(list((target/'cpu').rglob('*.*'))), 25)
            for original, digest in ep.checked.items():
                self.assertEqual(new.sha(ep.resolved[original]), digest)
                self.assertFalse(original.endswith(('.npy', '.safetensors')))
            self.assertEqual(new.sha(MAP), before[str(MAP)])
            self.assertFalse(any(k == 'torch' or k.startswith(('torch.', 'torch_npu', 'transformers')) for k in sys.modules))

    def test_03_copied_original_raw_tamper_rejected_by_pure_checker(self):
        with tempfile.TemporaryDirectory() as folder, array_io_forbidden():
            ep, i04, cpu = endpoint(new); target = Path(folder)/'prerequisites'
            new.copy_dual(ep, i04, cpu, target)
            wrapper = json.loads((target/'i04/prerequisite.json').read_bytes())
            first = target/'i04'/wrapper['report']['path']
            first.write_bytes(first.read_bytes() + b'\n')
            with self.assertRaises(ValueError):
                new.proof.prerequisite(target/'i04/prerequisite.json', new.I04_SHA,
                    target/'cpu/prerequisite.json', new.CPU_SHA)

    def test_04_wrong_map_or_wrapper_digest_rejected(self):
        with array_io_forbidden():
            with self.assertRaises(ValueError): new.Endpoint(MAP, '0'*64)
            ep, i04, _ = endpoint(new)
            with self.assertRaises(ValueError): ep.get(i04, '0'*64)

    def test_05_exact_path_return_handling_and_no_traversal(self):
        self.assertEqual(new.prior.safe_relative('proof/example.json'), 'proof/example.json')
        for name in ('../escape.json', '/absolute.json', 'proof/../escape.json', 'proof\\windows.json'):
            with self.subTest(name=name), self.assertRaises(ValueError): new.prior.safe_relative(name)

    def test_06_only_copy_path_adapter_changes_in_helper_AST(self):
        old_text = Path(old.__file__).read_text(encoding='utf-8')
        new_text = Path(new.__file__).read_text(encoding='utf-8')
        expected = old_text.replace("rel=prior.safe_relative(value['path']).as_posix();require(rel not in files,'duplicate portable raw proof')",
            "rel=prior.safe_relative(value['path']);require(isinstance(rel,str) and rel not in files,'duplicate portable raw proof or non-string reviewed path')")
        self.assertEqual(new_text, expected)
        old_funcs = {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(old_text).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
        new_funcs = {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(new_text).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
        self.assertEqual(set(old_funcs), set(new_funcs))
        self.assertEqual({k:v for k,v in old_funcs.items() if k != 'copy_dual'},
                         {k:v for k,v in new_funcs.items() if k != 'copy_dual'})

    def test_07_main_changes_only_versioned_source_names_and_gates_stay_None(self):
        a = Path(old_main.__file__).read_text(encoding='utf-8')
        b = Path(new_main.__file__).read_text(encoding='utf-8')
        self.assertEqual(b, a.replace('observer_artifact_admission_v1', 'observer_artifact_admission_v2').replace(
            'admit_observer_transparency_v1', 'admit_observer_transparency_v2'))
        self.assertIs(new_main.native, new)
        self.assertIsNone(old_main.HELPER_SHA); self.assertIsNone(new_main.HELPER_SHA)
        self.assertEqual(old_main.ACTUAL_ENDPOINTS, {'GPU': None, 'NPU': None})
        self.assertEqual(new_main.ACTUAL_ENDPOINTS, {'GPU': None, 'NPU': None})
        new.verify_tools()


if __name__ == '__main__': unittest.main()

"""Independent draft admission and CPU derivation for selected reserved48 BF16.

The source's all-target scalars are admitted as source evidence plus coordinate,
bit-scalar/formula and digest consistency. Only retained full-vocabulary rows can
be independently normalized afterwards. Newly written FP64 matrices are CPU
artifacts, never original GPU/NPU arrays. No Torch/model/device API is imported.
Actual stage/proof/budget/lifecycle/source-map gates deliberately remain None.
"""
import argparse
import hashlib
import importlib
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import struct
import sys
import time

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]
SCRIPTS = REPO / 'skills/precision-compare/scripts'
TASK = 'gemma4-reserved48-i05-q01-v1'
MANIFEST_SHA = '10f6b1a6976507e1af65706ddd4bb61d9276c43ae443b2a6852935e2967dca37'
EXPECTED_SOURCE_SHA = 'ad229e986bab26fb697ab58120d63b948123c3ad52a1a51383a09495e719c05e'
COMMON_SOURCE_SHA = 'bf1bd4176fd209fd6fabfbda22bd9fb246cfdf12e72d89d7ca77417ad8546e58'
NATIVE_SOURCE_SHA = 'd7bc0e8115769d4fcbe2aecec6e6ee550517fa7a27e7afef6b8b3844e20fe3e2'
VOCABULARY, CHUNK_ROWS = 262144, 32
MODES, BINS = ('full', 'token', 'chunk'), (128, 512, 2048, 8192)
HEX = re.compile(r'^[a-f0-9]{64}$')
GATES = {'stage_sha256': None, 'expected_inventory_sha256': None, 'budget_sha256': None,
         'cpu_prerequisite_sha256': None, 'cpu_prerequisite_checker_sha256': None,
         'gpu_lifecycle_sha256': None, 'npu_lifecycle_sha256': None,
         'native_endpoint_schema_reviewed': None}
SHARED = {'artifact_io': '0260cd5ee1fd4e9d37e39bfd79efa9e663a1d48cb75b5adb31b84af9e1edbf39',
          'inference_capture': '5d388e846249d7fd74df1b15036f8a371e3267ada1b2fb0408bc51345ffad19c',
          'compare_distributions': '6abc2eb0a741d554127911de9845d16e0d40f3f7759c42c172eae4907bbf8fc0',
          'score_metrics': 'f645a0092bb97229380c5da6302316978324baf38579476f980bb63da2d6a7da',
          'conditions': 'e012c025395f2f0474f0b35074d8417ec5a217f3659f82218de0f5d05068036d'}
DERIVATION = 'NEW common-CPU NumPy float64 log_softmax from original selected native BF16 rows'
SOURCE_LSE_ORIGIN = 'raw_max - shared_FP64_logprob_at_raw_argmax'
ATOL = 1e-12  # Evidence reconstruction diagnostic, never model acceptance.


def require(ok, message):
    if not ok: raise ValueError(message)


def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def parse(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate JSON key'); result[key] = value
        return result
    def reject(value): raise ValueError('nonfinite JSON token ' + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=reject)


def load(path): return parse(Path(path).read_bytes())


def sha(path, tick=lambda: None):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b''): tick(); digest.update(block)
    return digest.hexdigest()


def ref(path):
    path = Path(path); require(path.is_file() and not path.is_symlink(), 'regular file required')
    return {'path': str(path.resolve()), 'sha256': sha(path), 'size_bytes': path.stat().st_size}


def put(path, document):
    raw = (json.dumps(document, indent=2, allow_nan=False) + '\n').encode()
    require(len(raw) <= 16 * 1024**2, 'metadata exceeds16MiB')
    with Path(path).open('xb') as stream: stream.write(raw)


def safe_relative(name):
    require(isinstance(name, str) and name and not PurePosixPath(name).is_absolute() and str(PurePosixPath(name)) == name and
            '\\' not in name and all(part not in ('', '.', '..') for part in name.split('/')), 'canonical relative path required')
    return PurePosixPath(name)


def origin(name):
    require(isinstance(name, str) and name.startswith('/') and str(PurePosixPath(name)) == name and
            '\\' not in name and '..' not in PurePosixPath(name).parts, 'original absolute POSIX source path required')
    return name


def child(parent, name): return str(PurePosixPath(origin(parent)).joinpath(safe_relative(name)))


def libraries():
    """Reuse the owning tool interfaces; no collector math or framework import."""
    for name, digest in SHARED.items(): require(sha(SCRIPTS / (name + '.py')) == digest, 'shared tool bytes differ: ' + name)
    sys.path.insert(0, str(SCRIPTS)); modules = {name: importlib.import_module(name) for name in SHARED}
    for name, module in modules.items(): require(Path(module.__file__).resolve() == (SCRIPTS / (name + '.py')).resolve(), 'shared import path differs')
    import numpy as np
    require(not any(name in sys.modules for name in ('torch', 'torch_npu', 'transformers')), 'CPU artifact analysis imported a framework')
    return np, modules


class Audit:
    def __init__(self, seconds):
        require(type(seconds) in (int, float) and math.isfinite(seconds) and seconds > 0, 'finite CPU deadline required')
        self.deadline = time.monotonic() + seconds; self.checked = {}; self.originals = {}; self.large = set()

    def tick(self):
        if time.monotonic() >= self.deadline: raise TimeoutError('reserved48 CPU artifact deadline')

    def file(self, path, digest, size=None, large=False, force=False):
        self.tick(); path = Path(path)
        require(path.is_file() and not path.is_symlink() and isinstance(digest, str) and HEX.fullmatch(digest), 'regular frozen source/SHA required')
        resolved = str(path.resolve(strict=True)); actual_size = path.stat().st_size
        require(size is None or type(size) is int and size == actual_size, 'source byte count differs')
        if force or resolved not in self.checked:
            actual = sha(path, self.tick); require(actual == digest, 'source byte SHA differs: ' + str(path))
            require(resolved not in self.checked or self.checked[resolved] == (actual, actual_size), 'source changed during CPU analysis')
            self.checked[resolved] = (actual, actual_size)
        require(self.checked[resolved] == (digest, actual_size), 'conflicting source aliases')
        if large: self.large.add(resolved)
        return Path(resolved)

    def finish(self):
        for path, (digest, size) in list(self.checked.items()): self.file(path, digest, size, force=True)


class Endpoint:
    """Task-owned map geometry; no old160-row admission schema is reused."""
    def __init__(self, audit, info, backend, prompt_bin):
        self.audit, self.backend, self.prompt_bin = audit, backend, prompt_bin
        mapping = info['source_map']; self.path = audit.file(mapping['path'], mapping['sha256'])
        self.document = load(self.path); self.files = self.document['files']; self.info = info
        require(self.document.get('schema_version') == 1 and self.document.get('request') == {
            'task': 'RESERVED48', 'backend': backend, 'prompt_bin': prompt_bin,
            'outer_receipt': origin(info['receipt']['source_path'])}, 'new reserved48 endpoint request schema differs')
        self.root = Path(info['retained_root']).resolve(strict=True) if backend == 'NPU' and info.get('retained_root') else None
        require(backend in ('GPU', 'NPU') and prompt_bin in BINS and (backend == 'GPU' or self.root is not None), 'explicit source backend/bin/NPU root required')

    def get(self, name, digest=None, large=False):
        name = origin(name); item = self.files[name]
        require(type(item.get('size')) is int and item['size'] >= 0 and isinstance(item.get('sha256'), str) and
                HEX.fullmatch(item['sha256']) and (digest is None or digest == item['sha256']), 'source-map size/SHA differs')
        if item.get('retained_at_source') is True:
            require(self.backend == 'NPU' and large and self.root is not None and 'path' not in item and
                    PurePosixPath(name).name == 'selected-native-logits.safetensors', 'only explicit original NPU selected BF16 may remain at source')
            path = Path(name); require(path.is_relative_to(self.root) and path.resolve(strict=True).is_relative_to(self.root), 'retained source escapes declared root')
        else:
            relative = safe_relative(item['path']); path = self.path.parent.joinpath(*relative.parts)
            require(path.resolve(strict=True).is_relative_to(self.path.parent.resolve()), 'copied source escapes bundle')
            current = path
            while current != self.path.parent:
                require(not current.is_symlink(), 'copied source ancestor link'); current = current.parent
        actual = self.audit.file(path, item['sha256'], item['size'], large)
        self.audit.originals[(self.backend, self.prompt_bin, name)] = {'path': str(actual), 'sha256': item['sha256'], 'size_bytes': item['size']}
        return actual

    def json(self, name, digest=None):
        path = self.get(name, digest); require(path.stat().st_size <= 16 * 1024**2, 'source metadata exceeds16MiB'); return load(path)

    def bound_ref(self, value, large=False):
        require(set(value) == {'path', 'sha256', 'size_bytes'}, 'original file reference schema differs')
        path = self.get(value['path'], value['sha256'], large)
        require(path.stat().st_size == value['size_bytes'], 'original file reference size differs'); return path


def expected_rows(document, prompt_bin):
    require(document['task'] == TASK and document['manifest_sha256'] == MANIFEST_SHA and len(document['samples']) == 48,
            'independent complete48-input identity differs')
    rows = [value for value in document['samples'] if value['prompt_length'] == prompt_bin]
    require(len(rows) == 12 and len({value['sample'] for value in rows}) == 12, 'exact twelve distinct inputs per bin required')
    return rows


def bf16_scalar(word):
    require(type(word) is int and 0 <= word <= 65535, 'original BF16 scalar word required')
    value = struct.unpack('<f', struct.pack('<I', word << 16))[0]
    require(math.isfinite(value), 'source BF16 scalar is nonfinite'); return value


def admit_source_scalars(row, targets_doc, digest_doc, selection_doc, summary, vocabulary=VOCABULARY):
    """Admit all original scalars without pretending absent vectors can be replayed."""
    sequence, length, positions = row['input_ids'], row['sequence_length'], row['distribution_positions']
    scores, digests = targets_doc['scores'], digest_doc['rows']
    require(len(sequence) == length and len(scores) == length - 1 and len(digests) == length and len(positions) == 47,
            'complete causal target/raw digest/selected inventory required')
    require(targets_doc['input_sha256'] == row['input_sha256'] and targets_doc['sample'] == row['sample'] and
            targets_doc['mode'] == summary['mode'] and targets_doc['task'] == TASK and
            digest_doc['full_raw_rows_retained'] is False and digest_doc['all_valid_rows_checked_finite'] == length and
            digest_doc['unscored_finite_last_position'] == length - 1, 'source all-valid-finite evidence identity differs')
    for p, item in enumerate(digests):
        require(type(item.get('prediction_position')) is int and type(item.get('native_data_bytes')) is int and
                item == {'prediction_position': p, 'sha256': item.get('sha256'), 'native_data_bytes': vocabulary * 2} and
                isinstance(item['sha256'], str) and HEX.fullmatch(item['sha256']), 'source raw row digest inventory differs')
    for p, score in enumerate(scores):
        require(score['sample'] == row['sample'] and type(score['position']) is int and score['position'] == p + 1 and
                type(score['prediction_position']) is int and score['prediction_position'] == p and score['token'] == sequence[p + 1] and
                type(score['token']) is int and
                score['raw_row_sha256'] == digests[p]['sha256'] and score['source_logsumexp_origin'] == SOURCE_LSE_ORIGIN,
                'all-target causal coordinate/token/digest differs')
        native, maximum = bf16_scalar(score['raw_target_bf16_u16']), bf16_scalar(score['raw_argmax_bf16_u16'])
        lp, normalizer = score['logprob'], score['source_logsumexp']
        require(type(score['raw_target_value']) in (int, float) and score['raw_target_value'] == native and
                type(lp) in (int, float) and math.isfinite(lp) and lp <= 0 and
                type(normalizer) in (int, float) and math.isfinite(normalizer) and
                type(score['raw_argmax_token_lowest_id']) is int and 0 <= score['raw_argmax_token_lowest_id'] < vocabulary and
                native <= maximum and normalizer + ATOL >= maximum and normalizer <= maximum + math.log(vocabulary) + ATOL and
                abs((native - normalizer) - lp) <= ATOL,
                'source scalar/raw-BF16/normalizer formula differs')
    expected_positions = [{'row': i, 'prediction_position': p, 'target_position': p + 1, 'token': sequence[p + 1],
                          'raw_row_sha256': digests[p]['sha256']} for i, p in enumerate(positions)]
    require(selection_doc['sample'] == row['sample'] and selection_doc['mode'] == summary['mode'] and
            selection_doc['shape'] == [47, vocabulary] and selection_doc['original_sequence_native_shape'] == [1, length, vocabulary] and
            selection_doc['positions'] == expected_positions and summary['valid_rows'] == length and summary['targets'] == length - 1 and
            summary['selected_rows'] == 47 and summary['raw_stream_sha256'] == digest_doc['raw_stream_sha256'] and
            HEX.fullmatch(summary['raw_stream_sha256']), 'source selected-row/full stream declaration differs')
    return {'source_target_scores': length - 1, 'source_raw_rows_claimed_finite': length,
        'independently_replayed_selected_rows': 0, 'independent_all_target_normalizers': False,
        'independent_unretained_raw_finite_check': False, 'full_unselected_raw_audit': False,
        'scope': 'Original source evidence plus causal coordinate/BF16 scalar/formula/digest consistency; absent raw vectors cannot be independently normalized'}


def selected_array(path, vocabulary=VOCABULARY):
    """Bound the exact original tensor, then use the owning BF16 Array decoder."""
    np, modules = libraries(); path = Path(path)
    with path.open('rb') as stream:
        prefix = stream.read(8); require(len(prefix) == 8, 'truncated selected native length')
        length = struct.unpack('<Q', prefix)[0]; require(0 < length <= 131072, 'bounded selected native header required')
        header = parse(stream.read(length))
    require(set(header) in ({'logits'}, {'logits', '__metadata__'}) and header['logits'] == {
        'dtype': 'BF16', 'shape': [47, vocabulary], 'data_offsets': [0, 47 * vocabulary * 2]} and
        path.stat().st_size == 8 + length + 47 * vocabulary * 2, 'exact47-row BF16 tensor shape/offset/length required')
    require('__metadata__' not in header or isinstance(header['__metadata__'], dict) and
            all(type(k) is str and type(v) is str for k, v in header['__metadata__'].items()), 'native metadata must contain strings')
    array = modules['artifact_io'].Array(path.parent, {'path': path.name, 'key': 'logits'})
    require(array.bf16 and array.shape == [47, vocabulary], 'owning array reader geometry differs'); return array


def native_row_bytes(array, index, vocabulary=VOCABULARY):
    require(type(index) is int and 0 <= index < 47, 'selected native row index differs')
    with array.path.open('rb') as stream:
        stream.seek(array.offset + index * vocabulary * 2); raw = stream.read(vocabulary * 2)
    require(len(raw) == vocabulary * 2, 'truncated selected native row'); return raw


def derive_selected(path, source_ref, row, selection, scores, destination, audit, vocabulary=VOCABULARY):
    """Create one NEW [47,V] FP64 matrix in at most32-row derivation slabs."""
    np, modules = libraries(); array = selected_array(path, vocabulary)
    destination = Path(destination); require(destination.parent.is_dir() and not destination.exists() and not destination.is_symlink(), 'exclusive CPU matrix output required')
    fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600); os.close(fd)
    mapped = np.lib.format.open_memmap(destination, mode='w+', dtype='<f8', shape=(47, vocabulary))
    maximum, rows = 0.0, []
    try:
        for lo in range(0, 47, CHUNK_ROWS):
            audit.tick(); count = min(CHUNK_ROWS, 47 - lo)
            values = array.read(lo * vocabulary, count * vocabulary).reshape(count, vocabulary)
            require(np.isfinite(values).all(), 'retained selected native row is nonfinite')
            normalized = modules['inference_capture'].derive_logprobs(values, dtype='float64')
            require(normalized.shape == values.shape and np.isfinite(normalized).all(), 'shared matrix derivation differs')
            mapped[lo:lo + count] = normalized
            for relative in range(count):
                index = lo + relative; coordinate = selection['positions'][index]; p = coordinate['prediction_position']; target = scores[p]
                raw = native_row_bytes(array, index, vocabulary); digest = hashlib.sha256(raw).hexdigest()
                require(digest == coordinate['raw_row_sha256'] == target['raw_row_sha256'], 'retained native selected row digest differs')
                token = row['input_ids'][p + 1]; raw_word = struct.unpack_from('<H', raw, token * 2)[0]
                maximum_token = int(np.argmax(values[relative]))
                require(target['raw_argmax_token_lowest_id'] == maximum_token and
                    target['raw_argmax_bf16_u16'] == struct.unpack_from('<H', raw, maximum_token * 2)[0],
                    'retained native argmax/tie-breaking differs from source evidence')
                lp = float(normalized[relative, token]); normalizer = float(np.max(values[relative])) - float(np.max(normalized[relative]))
                delta = abs(lp - target['logprob']); maximum = max(maximum, delta)
                require(raw_word == target['raw_target_bf16_u16'] and delta <= ATOL and
                        abs(normalizer - target['source_logsumexp']) <= ATOL, 'retained full-row rederivation/source scalar mismatch')
                rows.append({'sample': row['sample'], 'position': p, 'history': row['input_ids'][:p + 1],
                    'scores': {'path': str(destination.resolve()), 'row': index},
                    'provenance': {'kind': 'new_common_cpu_artifact', 'derivation': DERIVATION, 'original_native_source': source_ref,
                        'selected_native_row': index, 'native_prediction_position': p, 'raw_row_sha256': digest,
                        'input_sha256': row['input_sha256']}})
            del normalized, values
        mapped.flush()
    finally: mapped._mmap.close()
    result = ref(destination)
    return {'matrix': result, 'positions': rows, 'new_derived_FP64_rows': 47,
        'maximum_selected_target_rederivation_delta': maximum, 'derivation': DERIVATION,
        'original_GPU_or_NPU_FP64_array': False, 'independent_all_target_normalizers': False}


def admit_cache_metadata(value, consumed, enabled, device):
    """Observe logical/physical cache geometry without claiming retained values."""
    if not enabled:
        require(value == {'present': False}, 'cache-off metadata must remain absent'); return
    if consumed == 0:
        require(value == {'present': False, 'logical_tokens': 0}, 'fresh cache prefix must be absent'); return
    require(value.get('present') is True and value['logical_tokens_consumed'] == value['reported_sequence_length'] == consumed and
            isinstance(value.get('class'), str) and len(value['layers']) == 48, 'cached logical prefix/layer inventory differs')
    for index, layer in enumerate(value['layers']):
        full = index % 6 == 5; heads, width = (1, 512) if full else (8, 256)
        require(layer['index'] == index and layer['configured_attention'] == ('full_attention' if full else 'sliding_attention') and
                layer['reported_sequence_length'] == consumed, 'per-layer cache prefix/profile differs')
        for name in ('keys', 'values'):
            tensor = layer[name]; shape = tensor['shape']
            require(len(shape) == 4 and shape[:2] == [1, heads] and shape[-1] == width and type(shape[-2]) is int and
                    0 < shape[-2] <= consumed and tensor['dtype'] == 'torch.bfloat16' and tensor['device'] == device,
                    'cache tensor geometry/dtype/device differs')
            if full: require(shape[-2] == consumed, 'full-attention cache was clipped')
            elif shape[-2] < consumed:
                require(layer['is_sliding'] is True and type(layer['sliding_window']) is int and
                        0 < shape[-2] <= layer['sliding_window'], 'trimmed cache lacks observed sliding provenance')
        require(layer['keys']['shape'] == layer['values']['shape'], 'cache K/V geometry differs')


def admit_observation(endpoint, output, row, mode, baseline, device, baseline_rng):
    prefix = child(output, 'samples/' + row['sample'] + '/' + mode)
    summary = endpoint.json(child(prefix, 'capture-summary.json'))
    scores = endpoint.json(child(prefix, 'source-target-scores.json'))
    digests = endpoint.json(child(prefix, 'native-row-digests.json'))
    selection = endpoint.json(child(prefix, 'selected-row-inventory.json'))
    checked = admit_source_scalars(row, scores, digests, selection, summary)
    native_ref = summary['selected_native']; require(native_ref == selection['native'] and
        native_ref['path'] == child(prefix, 'selected-native-logits.safetensors'), 'original selected native reference differs')
    native = endpoint.bound_ref(native_ref, True)
    invariant = {key: baseline[key] for key in ('model_object_id', 'class', 'config', 'module_training_flags', 'parameters')}
    parameter_sha = hashlib.sha256(canonical(invariant).encode()).hexdigest()
    buffer_sha = hashlib.sha256(canonical(baseline['buffers']).encode()).hexdigest()
    rng = summary['rng_before']
    require(set(rng) == {'python', 'numpy', 'torch_cpu', 'device0'} and all(isinstance(value, dict) and
            not value.get('unavailable') and isinstance(value.get('sha256'), str) and HEX.fullmatch(value['sha256']) for value in rng.values()),
            'complete source RNG observation required')
    if baseline_rng is not None: require(canonical(rng) == canonical(baseline_rng), 'source RNG reset differs across input/mode')
    require(summary['mode'] == mode and summary['sample'] == row['sample'] and
        summary['native_calls'] == {'full': 1, 'token': 33, 'chunk': 34}[mode] and
        summary['parameter_invariant_unchanged'] is True and summary['buffer_metadata_unchanged'] is True and
        summary['parameter_state_before_sha256'] == summary['parameter_state_after_sha256'] == parameter_sha and
        summary['buffer_metadata_before_sha256'] == summary['buffer_metadata_after_sha256'] == buffer_sha and
        canonical(summary['rng_before']) == canonical(summary['rng_after']), 'per-observation source state/RNG evidence differs')
    plans = next(plan for plan in row['modes'] if plan['mode'] == mode)['input_spans_zero_based_half_open']
    events = endpoint.json(child(prefix, 'events.json')); require(len(events) == len(plans), 'source forward count differs')
    for index, (event, (start, end)) in enumerate(zip(events, plans)):
        require(event['call'] == index and event['input_span'] == [start, end] and event['position_span'] == [start, end] and
            event['attention_mask_shape'] == [1, end] and event['attention_mask_values'] == 'all ones from length, including valid token0' and
            event['use_cache'] == (mode != 'full') and event['logits_to_keep'] == 0 and event['native_shape'] == [1, end - start, VOCABULARY] and
            event['input_token_sha256'] == hashlib.sha256(canonical(row['input_ids'][start:end]).encode()).hexdigest(),
            'causal source event/mask/token/position plan differs')
        admit_cache_metadata(event['cache_before'], start, mode != 'full', device)
        admit_cache_metadata(event['cache_after'], end, mode != 'full', device)
    final_cache = endpoint.json(child(prefix, 'final-cache-metadata.json'))
    admit_cache_metadata(final_cache, row['sequence_length'], mode != 'full', device)
    require(canonical(final_cache) == canonical(events[-1]['cache_after']), 'final cache metadata differs from final forward')
    source_path = child(prefix, 'source-target-scores.json'); descriptor = endpoint.files[source_path]
    return {'summary': summary, 'source_scores': scores['scores'], 'selection': selection, 'native_path': native,
            'native_ref': native_ref, 'source_admission': checked, 'output_prefix': prefix, 'rng_before': rng,
            'source_target_ref': {'path': source_path, 'sha256': descriptor['sha256'], 'size_bytes': descriptor['size']}}


def admit_endpoint(endpoint, inventory, stage_sha, expected_sha):
    """Validate one new12-input native job before admitting any numeric products.

    The outer lifecycle schema remains gated until that lifecycle exists and is
    independently reviewed. These are explicit new reserved48 fields, never an
    adapter that feeds new data into an old160-row receipt.
    """
    info = endpoint.info; outer_path = origin(info['receipt']['source_path'])
    outer = endpoint.json(outer_path, info['receipt']['sha256']); rows = expected_rows(inventory, endpoint.prompt_bin)
    require(outer['task'] == 'RESERVED48' and outer['task_id'] == TASK and outer['backend'] == endpoint.backend and
            outer['prompt_bin'] == endpoint.prompt_bin and outer['status'] == 'completed' and type(outer['returncode']) is int and
            outer['returncode'] == 0 and outer['timed_out'] is False and outer['native_capture_count'] == outer['model_loads'] == 1 and
            outer['native_forward_calls_total'] == 816 and outer['collector_sha256'] == NATIVE_SOURCE_SHA,
            'completed new reserved48 native outer receipt required')
    require(outer['stage_spec_source_sha256'] == stage_sha and outer['expected_inventory_source_sha256'] == expected_sha and
            outer['cpu_prerequisite_source_sha256'] == GATES['cpu_prerequisite_sha256'], 'actual native stage/expected/CPU proof binding differs')
    source_hashes = outer['source_sha256']
    require(type(source_hashes) is dict and set(outer['dependency_paths']) == set(source_hashes) and
            len(outer['dependency_paths']) == len(source_hashes), 'native frozen source closure differs')
    for name, digest in source_hashes.items(): endpoint.get(origin(name), digest)
    for digest in (COMMON_SOURCE_SHA, NATIVE_SOURCE_SHA, EXPECTED_SOURCE_SHA,
                   GATES['gpu_lifecycle_sha256' if endpoint.backend == 'GPU' else 'npu_lifecycle_sha256']):
        require(digest in source_hashes.values(), 'native source closure lacks reviewed collector/expected/lifecycle')
    claim = str(PurePosixPath(outer_path).parent)
    before = endpoint.json(child(claim, 'sources-before.json')); after = endpoint.json(child(claim, 'sources-after.json'))
    require(canonical(before) == canonical(after) == canonical(source_hashes), 'native source-before/after bytes disagree')
    command = endpoint.json(outer['generic_receipt']['path'], outer['generic_receipt']['sha256'])
    require(command['status'] == 'completed' and command['returncode'] == 0 and command['child_returncode'] == 0 and
            command['argv'] == outer['argv'] and math.isfinite(command['wall_seconds']) and command['wall_seconds'] > 0,
            'immutable generic native command is not completed0')
    argv = command['argv']; require(len(argv) >= 3 and argv[2] == outer['collector_path'], 'direct native collector argv required')
    def flag(name):
        require(argv.count(name) == 1 and argv.index(name) + 1 < len(argv), 'missing/duplicate native flag ' + name)
        return argv[argv.index(name) + 1]
    output = origin(outer['output_dir'])
    require(flag('--backend') == endpoint.backend.lower() and flag('--prompt-bin') == str(endpoint.prompt_bin) and
        flag('--device') == ('cuda:0' if endpoint.backend == 'GPU' else 'npu:0') and flag('--output') == output and
        flag('--stage-spec') == outer['stage_spec_source_path'] and flag('--stage-spec-sha256') == stage_sha and
        flag('--expected-inventory') == outer['expected_inventory_source_path'] and flag('--expected-inventory-sha256') == expected_sha,
        'native argv is detached from actual outer/input/stage coordinates')
    manifest = endpoint.json(child(output, 'artifacts-manifest.json'), outer['artifacts_manifest_sha256'])
    require(manifest['schema_version'] == 1 and manifest['task'] == TASK and type(manifest['files']) is dict, 'new native artifact manifest differs')
    files = manifest['files']; native_names = {'samples/' + row['sample'] + '/' + mode + '/selected-native-logits.safetensors'
        for row in rows for mode in MODES}
    require({name for name in files if name.endswith(('.npy', '.safetensors'))} == native_names and len(native_names) == 36,
            'exact36 selected BF16 matrices required; no full raw/KV/old arrays')
    mapped_output = {name for name in endpoint.files if name.startswith(output + '/')}
    require(mapped_output == {child(output, name) for name in files} | {child(output, name) for name in ('artifacts-manifest.json', 'status.json')},
            'native source-map output inventory has omissions/extras')
    for name, item in files.items():
        safe_relative(name); require(set(item) == {'sha256', 'size_bytes'}, 'native manifest reference schema differs')
        actual = endpoint.get(child(output, name), item['sha256'], name in native_names)
        require(actual.stat().st_size == item['size_bytes'], 'native manifest size differs')
    status = endpoint.json(child(output, 'status.json'))
    expected_targets = 3 * sum(row['sequence_length'] - 1 for row in rows)
    expected_finite = 3 * sum(row['sequence_length'] for row in rows)
    require(status['task'] == TASK and status['status'] == 'completed' and status['backend'] == endpoint.backend.lower() and
        status['prompt_bin'] == endpoint.prompt_bin and status['inputs'] == 12 and status['observations'] == 36 and
        status['native_calls'] == 816 and status['model_loads'] == 1 and status['selected_rows'] == 1692 and
        status['all_target_scores'] == expected_targets and status['all_valid_native_rows'] == expected_finite and
        status['manifest_sha256'] == outer['artifacts_manifest_sha256'] and status['full_raw_retained'] is False and
        status['full_KV_retained'] is False and status['independent_all_target_normalizer_replay'] is False and
        status['Q02_executed'] is False and status['P01_executed'] is False and status['thresholds'] is status['acceptance'] is None,
        'complete source12-input capture status or replay limits differ')
    runtime = endpoint.json(child(output, 'runtime.json'))
    require(runtime['task'] == TASK and runtime['backend'] == endpoint.backend.lower() and runtime['model_loads'] == 1 and
        runtime['prompt_bin'] == endpoint.prompt_bin and runtime['seed'] == 0 and
        runtime['instance_visible_count'] == (1 if endpoint.backend == 'GPU' else 8) and runtime['compute_device_count'] == 1 and
        runtime['tensor_parallel_size'] == 1 and len(runtime['native_observations']) == 36,
        'actual source runtime model/process/backend scope differs')
    identity = runtime['model_identity']; require(identity['model_class'] == 'Gemma4UnifiedForConditionalGeneration' and
        identity['model_type'] == 'gemma4_unified' and identity['parameter_dtypes'] == ['torch.bfloat16'] and identity['actual_attention'] == 'eager',
        'actual unchanged loaded model identity differs')
    require(identity['snapshot_receipt_sha256'] == files['snapshot-verification.json']['sha256'] and
            endpoint.json(child(output, 'snapshot-verification.json'))['status'] == 'verified', 'original official snapshot verification differs')
    baseline = endpoint.json(child(output, 'model-state-before-capture.json'))
    require(canonical(baseline) == canonical(endpoint.json(child(output, 'model-state-after-capture.json'))), 'native loaded model state changed')
    require(all('content_sha256' in item and 'content_probe_gap' not in item for item in baseline['buffers']), 'source complete buffer fingerprints missing')
    policy = endpoint.json(child(output, 'policy-before-load.json'))
    require(canonical(policy) == canonical(endpoint.json(child(output, 'policy-after-load.json'))) ==
            canonical(endpoint.json(child(output, 'policy-after-capture.json'))), 'source backend policy changed')
    sources = endpoint.json(child(output, 'frozen-source-refs.json'))
    for value in sources.values(): endpoint.bound_ref(value)
    for values in runtime['runtime_sources'].values():
        original, copied = values['original'], values['frozen_copy']
        require(original['sha256'] == copied['sha256'] and original['size_bytes'] == copied['size_bytes'], 'runtime original/copy alias differs')
        endpoint.bound_ref(original); endpoint.bound_ref(copied)
    return {'endpoint': endpoint, 'output': output, 'rows': rows, 'runtime': runtime, 'policy': policy, 'outer': outer,
            'baseline': baseline,
            'native_paths': [child(output, name) for name in sorted(native_names)],
            'source_target_count': expected_targets, 'source_finite_row_claim': expected_finite}


def activation_ready():
    require(all(isinstance(value, str) and HEX.fullmatch(value) for key, value in GATES.items() if key != 'native_endpoint_schema_reviewed') and
            GATES['native_endpoint_schema_reviewed'] is True, 'reserved48 CPU stage/proof/budget/native endpoint schema remains unready')


def request(path, digest):
    activation_ready()
    require(sha(path) == digest, 'external CPU analysis request SHA differs')
    doc = load(path); require(doc['schema_version'] == 1 and doc['kind'] == 'reserved48-common-cpu-request' and doc['task'] == TASK,
        'case-owned CPU request contract differs')
    for key, gate in (('stage_spec', 'stage_sha256'), ('expected_inventory', 'expected_inventory_sha256'),
                      ('budget', 'budget_sha256'), ('cpu_prerequisite', 'cpu_prerequisite_sha256')):
        value = doc[key]; require(value['sha256'] == GATES[gate] and ref(value['path']) == value, 'frozen actual CPU request dependency differs')
    checker = doc['cpu_prerequisite_checker']; require(checker['sha256'] == GATES['cpu_prerequisite_checker_sha256'] and
        ref(checker['path']) == checker, 'actual CPU proof checker source differs')
    spec = importlib.util.spec_from_file_location('_reserved48_actual_cpu_proof_checker', checker['path'])
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    proof = module.prerequisite(doc['cpu_prerequisite']['path'], GATES['cpu_prerequisite_sha256'])
    require(proof['native_executions_started'] == 0 and not any(name in sys.modules for name in ('torch', 'torch_npu', 'transformers')),
            'actual CPU proof verification must be pure metadata')
    require(set(doc['source_maps']) == {'GPU', 'NPU'} and all(set(doc['source_maps'][backend]) == set(map(str, BINS)) for backend in ('GPU', 'NPU')),
            'all four native bins per backend required; no omitted failed bin')
    require(ref(doc['manifest']['path']) == doc['manifest'] and doc['manifest']['sha256'] == MANIFEST_SHA, 'original48-input manifest differs')
    require(sha(HERE / 'reserved48_expected_v1.py') == EXPECTED_SOURCE_SHA, 'independent expected source differs')
    expected = importlib.import_module('reserved48_expected_v1')
    require(Path(expected.__file__).resolve() == (HERE / 'reserved48_expected_v1.py').resolve(), 'independent inventory import path differs')
    generated = expected.derive(doc['manifest']['path'], doc['input_dir'], GATES['stage_sha256'])
    require(canonical(load(doc['expected_inventory']['path'])) == canonical(generated), 'independent48-input inventory bytes/semantics differ')
    return doc, generated

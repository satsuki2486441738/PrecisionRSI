"""Pinned mask factories on tiny CPU tensors; backend import is not init.

Transformers may explicitly import TorchNPU and perform availability checks.
This probe never requests availability, device counts, device selection or a
model. Initialization observations use only the backend's state getter.
"""
import os
os.environ['TORCH_DEVICE_BACKEND_AUTOLOAD'] = '0'
import hashlib
import json
from pathlib import Path
import signal
import sys

PHASES = ('after_torch','after_transformers','after_configuration',
    'after_masking_utils','before_masks','after_masks')


def initialization_observation(torch,phase):
    """Read state without importing a backend or requesting its availability."""
    namespace = vars(torch).get('npu')
    initialized = None if namespace is None else namespace.is_initialized()
    cuda_initialized = torch.cuda.is_initialized()
    assert initialized is None or type(initialized) is bool
    assert type(cuda_initialized) is bool
    assert initialized is not True and cuda_initialized is False
    return {'phase':phase,'torch_npu_imported':'torch_npu' in sys.modules,
        'npu_namespace_registered':namespace is not None,
        'npu_initialized':initialized,'cuda_initialized':cuda_initialized}


def source_ref(module):
    path = Path(module.__file__).resolve()
    assert path.is_file() and not path.is_symlink() and path.suffix in ('.py','.pyi')
    assert path.stat().st_size <= 16*1024*1024
    raw = path.read_bytes()
    return {'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}


def main():
    def expire(*_): raise TimeoutError('I04 CPU mask probe60s timeout')
    signal.signal(signal.SIGALRM,expire); signal.setitimer(signal.ITIMER_REAL,60)
    try:
        phases = []
        import torch
        phases.append(initialization_observation(torch,'after_torch'))
        import numpy
        import transformers
        phases.append(initialization_observation(torch,'after_transformers'))
        from transformers import Gemma4UnifiedTextConfig
        import transformers.models.gemma4_unified.configuration_gemma4_unified as configuration
        phases.append(initialization_observation(torch,'after_configuration'))
        import transformers.masking_utils as masks
        phases.append(initialization_observation(torch,'after_masking_utils'))
        import transformers.utils.import_utils as import_utils
        assert str(torch.__version__) == '2.9.0+cpu'
        assert transformers.__version__ == '5.10.1' and numpy.__version__ == '1.26.4'
        # This fixture is for the already observed NPU environment. The first
        # explicit config import registers TorchNPU without initializing it.
        assert all(x['torch_npu_imported'] is False and x['npu_namespace_registered'] is False
            and x['npu_initialized'] is None for x in phases[:2])
        assert all(x['torch_npu_imported'] is True and x['npu_namespace_registered'] is True
            and x['npu_initialized'] is False for x in phases[2:])
        npu_module = sys.modules['torch_npu.npu']
        assert vars(torch)['npu'] is npu_module
        assert npu_module.is_initialized.__module__ == 'torch_npu.npu'
        torch.set_num_threads(2)
        config = Gemma4UnifiedTextConfig(num_hidden_layers=2,layer_types=['sliding_attention','full_attention'])
        config._attn_implementation = 'eager'; config.sliding_window = 1024
        phases.append(initialization_observation(torch,'before_masks'))
        cells = 0; observations = []
        for side,valid in [('left',[0,0,1,1]),('right',[1,1,0,0])]:
            mask = torch.tensor([[1,1,1,1],valid],dtype=torch.int64,device='cpu')
            position = (mask.cumsum(-1)-1).masked_fill(mask==0,0)
            embedded = torch.zeros((2,4,8),dtype=torch.bfloat16,device='cpu')
            assert mask.device.type == position.device.type == embedded.device.type == 'cpu'
            prepared = masks.create_masks_for_generate(config,embedded,mask,None,
                position_ids=position,block_sequence_ids=torch.full_like(mask,-1))
            assert set(prepared) == {'sliding_attention','full_attention'}
            prepared.update({'direct_full':masks.create_causal_mask(config,embedded,mask,None,position_ids=position),
                'direct_sliding':masks.create_sliding_window_causal_mask(config,embedded,mask,None,position_ids=position)})
            for name,value in prepared.items():
                assert list(value.shape) == [2,1,4,4] and value.device.type == 'cpu'
                assert value.dtype == torch.bfloat16
                for batch in range(2):
                    for query in range(4):
                        if mask[batch,query]:
                            for key in range(4):
                                assert bool(value[batch,0,query,key] == 0) == bool(key <= query and mask[batch,key])
                                cells += 1
                observations.append({'side':side,'factory':name,'shape':list(value.shape),
                    'dtype':str(value.dtype),'device':str(value.device)})
        phases.append(initialization_observation(torch,'after_masks'))
        assert cells == 192 and tuple(x['phase'] for x in phases) == PHASES
        assert all(x['npu_initialized'] is False for x in phases[2:])
        sources = {name:source_ref(module) for name,module in [('torch',torch),('numpy',numpy),
            ('transformers',transformers),('masking_utils',masks),('configuration',configuration),
            ('import_utils',import_utils),('torch_npu_npu',npu_module)]}
        assert sources['import_utils']['path'].endswith('/transformers/utils/import_utils.py')
        assert sources['torch_npu_npu']['path'].endswith('/torch_npu/npu/__init__.py')
        print(json.dumps({'status':'i04_cpu_only_actual_mask_factories_checked',
            'versions':{'torch':str(torch.__version__),'transformers':transformers.__version__,'numpy':numpy.__version__},
            'sources':sources,'observations':observations,'valid_query_key_cells_checked':cells,
            'phase_observations':phases,'torch_npu_imported':True,'npu_initialized':False,'cuda_initialized':False,
            'device_backend_autoload':'0','device_initialization_checks':'getter_only',
            'agent_hardware_or_availability_queries':0,
            'library_internal_availability_queries':'not_counted_and_not_prohibited',
            'model_loads':0,'native_model_forward_calls':0,'agent_accelerator_initialization_requests':0,'acceptance':None}),flush=True)
        return 0
    finally: signal.setitimer(signal.ITIMER_REAL,0)


if __name__ == '__main__': raise SystemExit(main())

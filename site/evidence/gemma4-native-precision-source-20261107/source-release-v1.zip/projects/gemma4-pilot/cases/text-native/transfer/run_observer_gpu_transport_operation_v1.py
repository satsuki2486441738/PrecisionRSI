"""Record one bounded, exclusively claimed OBSERVER CPU transport operation.

Only the frozen assembler is spawned, in its own POSIX process group. Original
archives/arrays and every failed log/claim are preserved. No native/device API.
"""
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

ASSEMBLER='reassemble_observer_gpu_transport_v1.py'
ASSEMBLER_SHA='4116c0b2924f842111b24abe8c3822609b07fd5334342e3c4616b054d1e273b5'
TRANSPORT='observer-gpu-transport-manifest-v1.json'
TOOLS='transport-tools-manifest.json'
TOTAL,CHILD,CLEANUP=900,870,20


def require(ok,message):
    if not ok:raise ValueError(message)


def utc():return datetime.now(timezone.utc).isoformat()


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def read(path):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,parse_constant=reject)


def put(path,document):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(document,stream,indent=2,allow_nan=False);stream.write('\n')


def contained(root,path):
    path=Path(path);require(path.is_absolute() and path.is_relative_to(root) and path.resolve().is_relative_to(root),'owned path escapes explicit R')
    current=path
    while current!=root:require(not current.is_symlink(),'symlink in operation path');current=current.parent
    return path


def verify_tools(root,tools,digest,transport_sha):
    tools=contained(root,Path(tools).absolute());manifest=tools/TOOLS
    require(manifest.is_file() and sha(manifest)==digest,'external transport tools manifest SHA differs')
    doc=read(manifest);require(doc['kind']=='observer-gpu-transport-tools' and doc['native_executions_started']==0,'wrong transport source package')
    expected={ASSEMBLER,TRANSPORT,Path(__file__).name}
    require(set(doc['files'])==expected and {p.name for p in tools.iterdir()}==expected|{TOOLS},'exact three transport source/data files required')
    for name,ref in doc['files'].items():
        path=contained(root,tools/name)
        require(path.is_file() and path.stat().st_nlink==1 and path.stat().st_size==ref['size_bytes'] and sha(path)==ref['sha256'],'transport source/data bytes changed')
    require(doc['files'][ASSEMBLER]['sha256']==ASSEMBLER_SHA and doc['files'][TRANSPORT]['sha256']==transport_sha and
        Path(__file__).resolve()==tools/Path(__file__).name,'assembler/data/executed controller identity differs')
    return read(tools/TRANSPORT)


def terminate(process):
    if process is None:return
    try:os.killpg(process.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        process.wait(timeout=5)


def run(root,tools,tool_sha,transport_sha,subdir,mode,wrapper=None):
    require(os.name=='posix' and mode in ('stage','assemble'),'POSIX single transport operation required')
    root=Path(root);require(root.is_dir() and not root.is_symlink(),'existing original R required');root=root.resolve(strict=True)
    doc=verify_tools(root,tools,tool_sha,transport_sha);tools=Path(tools).absolute();target=contained(root,root/subdir)
    require(target.is_dir() and tools==target/'tools','fixed existing task transport/tools directory required')
    part=None
    if mode=='stage':
        source=contained(root,Path(wrapper).absolute());require(source.parent==root,'one exact R-root uploaded wrapper required')
        matches=[p for p in doc['parts'] if p['wrapper_basename']==source.name];require(len(matches)==1,'wrapper absent from frozen actual manifest');part=matches[0]
        label='stage-%04d'%part['index']
    else:require(wrapper is None,'assembly accepts no wrapper');label='assemble'
    claim=target/(label+'-operation-claim.json');put(claim,{'claimed_utc':utc(),'mode':mode,'part_index':part['index'] if part else None,
        'manifest_sha256':transport_sha,'controller_sha256':sha(__file__),'automatic_retry':False,'native_executions_started':0})
    runs=contained(root,root/'runs');require(runs.is_dir(),'existing runs directory required')
    folder=runs/('compare-observer-transport-'+label+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));folder.mkdir(mode=0o700)
    state={'schema_version':1,'task':'OBSERVER-GPU-transport','mode':mode,'status':'running','started_utc':utc(),'run':str(folder),
        'tools_root':str(tools),'tool_manifest_sha256':tool_sha,'transport_manifest_sha256':transport_sha,
        'whole_cpu_seconds':TOTAL,'child_work_seconds':CHILD,'cleanup_reserve_seconds':CLEANUP,'native_executions_started':0,
        'numeric_admission_performed':False,'automatic_retry':False,'acceptance':None}
    args=[sys.executable,'-S','-B',str(tools/ASSEMBLER),mode,'--root',str(root),'--transport-subdir',subdir,
        '--manifest',str(tools/TRANSPORT),'--manifest-sha256',transport_sha]
    if part:args+=['--wrapper',str(source)]
    state['argv']=args;put(folder/'controller-start.json',state);started=time.monotonic();process=None;code=2
    def expire(*_):raise KeyboardInterrupt('OBSERVER recorded transport whole900-second deadline/signal')
    previous={s:signal.signal(s,expire) for s in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT,signal.SIGHUP)};signal.setitimer(signal.ITIMER_REAL,TOTAL)
    try:
        with (folder/'stdout.bin').open('xb') as out,(folder/'stderr.bin').open('xb') as err:
            process=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
            try:code=process.wait(timeout=CHILD)
            except subprocess.TimeoutExpired:state['timed_out']=True;terminate(process);code=process.returncode
        require(code==0 and not state.get('timed_out',False),'transport child did not complete0')
        result=read(folder/'stdout.bin')
        if mode=='stage':
            expected=read(target/('part-%04d'%part['index'])/'stage-receipt.json')
            require(result==expected and result['status']=='observer_wrapper_verified_and_moved' and result['part_index']==part['index'] and
                result['wrapper_sha256']==part['wrapper_sha256'] and result['manifest_sha256']==transport_sha,'actual completed stage receipt differs')
        else:
            expected=read(target/'assembly-receipt.json')
            require(result==expected and result['status']=='observer_original_gpu_gzip_reconstructed' and result['returncode']==0 and
                result['archive_sha256']==doc['archive']['sha256'] and result['archive_bytes']==doc['archive']['size_bytes'] and
                result['source_map_sha256']==doc['source_map_sha256'],'actual reconstructed original archive receipt differs')
        verify_tools(root,tools,tool_sha,transport_sha);state.update(status='completed',returncode=0,result=result)
    except BaseException as exc:state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),partial_files_preserved=True)
    finally:
        # The assembler is stdlib/single-process; still kill/reap its owned group.
        try:terminate(process)
        except BaseException as exc:state['cleanup_error']=str(exc)
        remaining=False
        if process is not None:
            try:os.killpg(process.pid,0);remaining=True
            except ProcessLookupError:pass
        if remaining or 'cleanup_error' in state:state.update(status='failed',returncode=2)
        signal.setitimer(signal.ITIMER_REAL,0)
        for s,h in previous.items():signal.signal(s,h)
        for key in ('stdout','stderr'):
            p=folder/(key+'.bin')
            if p.is_file():state[key]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
        state.update(child_returncode=code,remaining_owned_process_group=remaining,finished_utc=utc(),elapsed_seconds=time.monotonic()-started)
        put(folder/'controller-receipt.json',state)
    print(json.dumps({'status':state['status'],'receipt':str(folder/'controller-receipt.json'),'result':state.get('result'),'error':state.get('error')},indent=2),flush=True)
    return state['returncode']


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['stage','assemble'])
    for key in ('root','tools-root'):p.add_argument('--'+key,type=Path,required=True)
    for key in ('tool-manifest-sha256','transport-manifest-sha256','transport-subdir'):p.add_argument('--'+key,required=True)
    p.add_argument('--wrapper',type=Path);a=p.parse_args()
    return run(a.root,a.tools_root,a.tool_manifest_sha256,a.transport_manifest_sha256,a.transport_subdir,a.mode,a.wrapper)


if __name__=='__main__':raise SystemExit(main())

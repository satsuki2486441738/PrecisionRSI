"""One immutable I01 H100 app: claim, restore, native capture, validate, stop.

No platform API is used. Permanent claims survive every failure/restart. The
parent must stop the CCI after a terminal receipt; process exit does not release
its allocation. The source is exclusive to this new I01 task, never the old
REDACTED_APP_ID source or claim. Only main() performs native work.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import select
import shutil
import signal
import socket
import stat
import subprocess
import sys
import time
import uuid

TASK = Path('/srv/precision-task')
ROOT = TASK / 'i01-cacheoff-20261106'
STAGE = ROOT / 'source'
CASE_REL = 'projects/gemma4-pilot/cases/text-native'
ENTRY_NAME = 'launch-h100-i01-cacheoff-20261106-v1.sh'
LIFECYCLE_NAME = 'h100_i01_lifecycle_v1.py'
SOURCE_NAME = 'platform-allocation-source.json'
TASK_ID = 'gemma4-gpu-npu-i01-cacheoff-v1-20261106'
OLD_HELPER = TASK / 'attempts/launch_h100_torch290_repeat_v1-20261106.py'
OLD_HELPER_SHA = '5b8aecafd569999aebe5c369edacd9f054980bee3f75748a85189cae7690a06e'
RECORD_REL = 'skills/precision-compare/scripts/record_run.py'
RECORD_SHA = '2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'
INPUT_REL = CASE_REL + '/inputs/discovery-v1/wikitext2-discovery-001.json'
POLICY_REL = CASE_REL + '/inputs/peer-math-policy-cu128-v1.json'
GPU_REL = CASE_REL + '/adapters/i01_gpu_v1.py'
COMMON_REL = CASE_REL + '/adapters/i01_common_v1.py'
EXPECTED_REL = CASE_REL + '/adapters/i01_expected_inventory_v1.py'
SPEC_REL = CASE_REL + '/i01-stage-v1.json'
SPEC_SHA = '5aa7d50bb472aab82108ad6711fdd6c5bdd4780bbecb27cdf78c734d13093c05'
EXPECTED_SOURCE_SHA = '834de8fef3d6147b908450116e39a48ea75a026bfc13a290db7db25492fbb40b'
EXPECTED_JSON_SHA = '416b4f7384c5676c7b1fc9c6d41a7e5c53e654d95554ceebe71dceb94049d5ee'
EXPECTED_JSON_BYTES = 102138
BASE_PINS = {
    RECORD_REL: RECORD_SHA,
    SPEC_REL: SPEC_SHA,
    EXPECTED_REL: EXPECTED_SOURCE_SHA,
    INPUT_REL: '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0',
    POLICY_REL: '5ef32354ed453d27c5751248b66859e433d9230a7fbf620851f6d5ec6da92516',
    'skills/precision-compare/scripts/artifact_io.py': '0260cd5ee1fd4e9d37e39bfd79efa9e663a1d48cb75b5adb31b84af9e1edbf39',
    CASE_REL + '/adapters/pilot_gpu_torch290_candidate.py': '5a73efe31962788baa04fa21abb1079be8a47e43393c23f3fa483e71c64b4f53',
    CASE_REL + '/adapters/pilot_ascend_candidate_v3.py': '95b7b9302543d8a14995e293c790d5de9e23abc6041a53bb1d627ae3b5cd7ee8',
    CASE_REL + '/adapters/pilot_gpu_peer_v2.py': 'fbf0b1dc4b03576852d166bc56d3bca14d6544be8aebd120ef0b92f146429eae',
    CASE_REL + '/adapters/verify_snapshot.py': 'cd64a5f3f380d9cc04578848ba508ace3f1df0752ca952b8d575dd2904196f26',
    CASE_REL + '/adapters/upstream-identity.json': '80dc0e0e59e5c526426b566d36a21f762a79d498986d5d6cd01098c8cb5decc3',
    CASE_REL + '/transfer/npu_three_repeat_launcher_v4.py': 'c1719e831a557cd9707374138d9219a8ae887854dd029a1ec165631d9259f485',
    'skills/precision-compare/scripts/inference_capture.py': '5d388e846249d7fd74df1b15036f8a371e3267ada1b2fb0408bc51345ffad19c',
    'skills/precision-compare/scripts/compare_distributions.py': '6abc2eb0a741d554127911de9845d16e0d40f3f7759c42c172eae4907bbf8fc0',
    'skills/precision-compare/scripts/conditions.py': 'e012c025395f2f0474f0b35074d8417ec5a217f3659f82218de0f5d05068036d',
}
APP_ID = re.compile(r'^app-[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?$')
HEX64 = re.compile(r'^[a-f0-9]{64}$')
CAPTURE_SECONDS = 900
TOTAL_SECONDS = 2400
CLEANUP_RESERVE_SECONDS = 20
MAX_NEW_BYTES = 1024 ** 3
MIN_AFS_FREE_BYTES = 2 * 1024 ** 3
MAX_TRANSFER_BYTES = 256 * 1024 ** 2


def require(ok, message):
    if not ok:
        raise ValueError(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 ** 2), b''):
            digest.update(block)
    return digest.hexdigest()


def parse(raw):
    def pairs(items):
        document = {}
        for key, value in items:
            require(key not in document, 'duplicate JSON key: ' + key)
            document[key] = value
        return document
    def reject(value):
        raise ValueError('nonfinite JSON value: ' + value)
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs,
                      parse_constant=reject)


def write_raw(path, raw):
    require(isinstance(raw, bytes), 'evidence must be original bytes')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    require(Path(path).read_bytes() == raw, 'written evidence differs')


def put(path, document):
    write_raw(path, (json.dumps(document, indent=2, allow_nan=False) + '\n').encode())


def load_pinned(path, digest, name):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and sha(path) == digest,
            'reviewed source differs: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    require(Path(module.__file__).resolve() == path.resolve() and sha(path) == digest,
            'imported source identity differs')
    return module


def wait_source(path, seconds=120, clock=time.monotonic, pause=None):
    pause = pause or (lambda delay: select.select([], [], [], delay))
    deadline = clock() + seconds
    while not Path(path).is_file():
        left = deadline - clock()
        if left <= 0:
            return False
        pause(min(1, left))
    return True


def regular(path, max_bytes=None):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and
            stat.S_ISREG(path.stat().st_mode), 'original regular file required: ' + str(path))
    if max_bytes is not None:
        require(path.stat().st_size <= max_bytes, 'file exceeds bounded size')
    return path


def validate_source(document, root=ROOT):
    root = Path(root)
    fields = {'schema_version', 'task_id', 'allocation_id', 'vendor', 'visible_count',
              'observed_utc', 'evidence_source', 'entry_path', 'entry_sha256',
              'lifecycle_path', 'lifecycle_sha256', 'source_pins'}
    require(isinstance(document, dict) and set(document) == fields,
            'exact I01 allocation/source schema required')
    require(type(document['schema_version']) is int and document['schema_version'] == 1 and
            document['task_id'] == TASK_ID, 'I01 task identity differs')
    require(isinstance(document['allocation_id'], str) and
            APP_ID.fullmatch(document['allocation_id']), 'actual safe app ID required')
    require(document['allocation_id'] != 'REDACTED_APP_ID', 'old spent app cannot run I01')
    require(document['vendor'] == 'NVIDIA' and type(document['visible_count']) is int and
            document['visible_count'] == 1, 'one NVIDIA device allocation required')
    timestamp = datetime.fromisoformat(document['observed_utc'].replace('Z', '+00:00'))
    require(timestamp.tzinfo is not None and timestamp.utcoffset().total_seconds() == 0,
            'authenticated source observation must be UTC')
    require(isinstance(document['evidence_source'], str) and
            0 < len(document['evidence_source'].strip()) <= 4096, 'platform observation required')
    for label, name in [('entry', ENTRY_NAME), ('lifecycle', LIFECYCLE_NAME)]:
        require(document[label + '_path'] == str(root / name) and
                isinstance(document[label + '_sha256'], str) and
                HEX64.fullmatch(document[label + '_sha256']), 'entry/lifecycle identity missing')
    pins = document['source_pins']
    require(isinstance(pins, dict) and 5 <= len(pins) <= 40 and
            {GPU_REL, COMMON_REL, *BASE_PINS} <= set(pins),
            'I01 collector/common/recorder/input/policy source pins required')
    for relative, digest in pins.items():
        parts = PurePosixPath(relative).parts
        require(parts and not PurePosixPath(relative).is_absolute() and
                '..' not in parts and '\\' not in relative and
                isinstance(digest, str) and HEX64.fullmatch(digest), 'unsafe source pin')
    require(all(pins[p] == digest for p, digest in BASE_PINS.items()),
            'reviewed helper/input/policy/stage/inventory source differs')
    return document


def verify_sources(document, root=ROOT):
    root = Path(root)
    observed = {}
    items = [(root / ENTRY_NAME, document['entry_sha256']),
             (root / LIFECYCLE_NAME, document['lifecycle_sha256'])]
    items += [(root / 'source' / p, digest) for p, digest in document['source_pins'].items()]
    total = 0
    for path, expected in items:
        regular(path, 1024 ** 2)
        require(path.resolve().is_relative_to(root.resolve()), 'source escapes new task')
        # Reject symlinks in every source path component, not just its leaf.
        current = path
        while current != root:
            require(not current.is_symlink(), 'source path contains symlink')
            current = current.parent
        observed[str(path)] = sha(path)
        require(observed[str(path)] == expected, 'source SHA differs: ' + str(path))
        total += path.stat().st_size
    require(total <= 4 * 1024 ** 2, 'source closure exceeds4MiB')
    return observed


def claim_once(root, app_id, claim):
    directory = Path(root) / 'claims' / app_id
    try:
        directory.mkdir(mode=0o700)
    except FileExistsError:
        return None
    put(directory / 'claim.json', claim)
    return directory


def freeze_sources(directory, observed, root):
    directory, root = Path(directory), Path(root)
    frozen = {}
    for original, digest in observed.items():
        original = Path(original)
        destination = directory / 'frozen-source' / original.relative_to(root)
        destination.parent.mkdir(parents=True, exist_ok=True)
        raw = original.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == digest, 'source changed before freezing')
        write_raw(destination, raw)
        frozen[str(original)] = {'path': str(destination), 'sha256': digest}
    put(directory / 'frozen-source-map.json', frozen)
    return frozen


def freeze_runtime_refs(directory, references, previous=None):
    """Preserve small GPU /tmp package/modeling bytes before the app is stopped."""
    directory = Path(directory)
    frozen = {} if previous is None else dict(previous)
    for ref in references.values():
        require(isinstance(ref, dict) and set(ref) == {'path', 'sha256', 'size_bytes'},
                'exact runtime file reference required')
        original = regular(ref['path'], 4 * 1024 ** 2)
        require(original.is_absolute() and original.stat().st_size == ref['size_bytes'] and
                sha(original) == ref['sha256'], 'runtime source bytes differ')
        key = str(original)
        if key in frozen:
            copied = frozen[key]
            require(copied['sha256'] == ref['sha256'] and copied['size_bytes'] == ref['size_bytes'] and
                    sha(regular(copied['path'])) == ref['sha256'], 'frozen package source changed')
            continue
        destination = directory / 'frozen-runtime' / ('%04d' % len(frozen)) / original.name
        destination.parent.mkdir(parents=True)
        raw = original.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == ref['sha256'], 'runtime source changed during freeze')
        write_raw(destination, raw)
        frozen[key] = {'path': str(destination), 'sha256': ref['sha256'], 'size_bytes': len(raw)}
    return frozen


def proc_table():
    table = {}
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            raw = (path / 'stat').read_text()
            tail = raw[raw.rindex(') ') + 2:].split()
            table[int(path.name)] = {'state': tail[0], 'ppid': int(tail[1]),
                                     'pgid': int(tail[2]), 'starttime': int(tail[19])}
        except (OSError, ValueError, IndexError):
            pass
    return table


def discover_owned(table, owned):
    changed = True
    while changed:
        changed = False
        for pid, row in table.items():
            if pid not in owned and row['ppid'] in owned:
                parent = table.get(row['ppid'])
                if parent and parent['starttime'] == owned[row['ppid']]:
                    owned[pid] = row['starttime']
                    changed = True
    return owned


def live_owned(owned, table=None):
    table = proc_table() if table is None else table
    return {pid: table[pid] for pid, start in owned.items()
            if pid in table and table[pid]['starttime'] == start and table[pid]['state'] != 'Z'}


def stop_owned(owned, process, seconds=3):
    table = proc_table()
    discover_owned(table, owned)
    deadline = time.monotonic() + seconds
    for sig in (signal.SIGTERM, signal.SIGKILL):
        for pid in list(live_owned(owned)):
            # Recheck PID creation time before each signal to avoid PID reuse.
            current = proc_table().get(pid)
            if current and current['starttime'] == owned[pid]:
                try:
                    os.kill(pid, sig)
                except ProcessLookupError:
                    pass
        if sig == signal.SIGTERM:
            while time.monotonic() < deadline:
                discover_owned(proc_table(), owned)
                if not live_owned(owned):
                    break
                select.select([], [], [], min(.1, max(0, deadline - time.monotonic())))
    try:
        process.wait(timeout=1)
    except subprocess.TimeoutExpired:
        pass
    # SIGKILL delivery is asynchronous, including when the group leader has
    # already exited. Observe stopped/zombie transitions before declaring a
    # live cleanup failure; never forget the descendant merely on leader exit.
    killed_deadline = time.monotonic() + 1
    while live_owned(owned) and time.monotonic() < killed_deadline:
        select.select([], [], [], .05)
    return sorted(live_owned(owned))


def tree_bytes(root):
    total = 0
    for path in Path(root).rglob('*'):
        require(not path.is_symlink(), 'new task output contains symlink')
        if path.is_file():
            total += path.stat().st_size
    return total


def supervise(argv, directory, deadline, root=ROOT, max_bytes=MAX_NEW_BYTES):
    """Bound a synchronous worker and track its actual descendants, even sessions."""
    directory, root = Path(directory), Path(root)
    state = {'status': 'running', 'started_utc': utc(), 'argv': list(argv),
             'whole_attempt_deadline_monotonic': deadline,
             'artifact_sample_limit_bytes': max_bytes,
             'artifact_limit_is_sampled_not_a_hard_quota': True,
             'owned_process_boundary': 'Observed Linux PID ancestry plus creation times; scheduler owns escaping/unobserved processes.'}
    owned = {}
    process = None
    code = 1
    try:
        with (directory / 'worker.stdout').open('xb') as out, (directory / 'worker.stderr').open('xb') as err:
            process = subprocess.Popen(argv, stdout=out, stderr=err, start_new_session=True)
            state['worker_pid'] = process.pid
            row = proc_table().get(process.pid)
            require(row is not None, 'worker PID identity unavailable')
            owned[process.pid] = row['starttime']
            next_size = 0
            while True:
                discover_owned(proc_table(), owned)
                current = time.monotonic()
                if current >= deadline - CLEANUP_RESERVE_SECONDS:
                    state['status'] = 'timed_out'
                    code = 124
                    break
                if current >= next_size:
                    state['new_task_bytes_last_sample'] = tree_bytes(root)
                    require(state['new_task_bytes_last_sample'] <= max_bytes, 'new task sampled storage budget exceeded')
                    next_size = current + 2
                result = process.poll()
                if result is not None:
                    code = result if result >= 0 else 128 - result
                    state['status'] = 'completed' if code == 0 else 'failed'
                    state['live_descendants_at_worker_exit'] = sorted(
                        pid for pid in live_owned(owned) if pid != process.pid)
                    if code == 0 and state['live_descendants_at_worker_exit']:
                        code = 1
                        state['status'] = 'unexpected_descendants'
                    break
                select.select([], [], [], min(.2, max(0, deadline - CLEANUP_RESERVE_SECONDS - current)))
    except BaseException as exc:
        state.update(status='interrupted_or_failed', error_type=type(exc).__name__, error=str(exc))
        code = 130 if isinstance(exc, KeyboardInterrupt) else 1
    finally:
        remaining = stop_owned(owned, process) if process is not None else []
        state['remaining_descendants'] = remaining
        state['remaining_descendants_definition'] = 'Observed owned non-zombie processes, PID creation times checked.'
        table = proc_table()
        state['owned_zombies_observed'] = [pid for pid, start in owned.items()
            if pid in table and table[pid]['starttime'] == start and table[pid]['state'] == 'Z']
        if remaining:
            code = 1
            state['status'] = 'cleanup_incomplete'
        state.update(finished_utc=utc(), returncode=code)
        put(directory / 'controller-receipt.json', state)
    return code, state


def native_probe_code():
    return '''import json,pathlib,subprocess,sys
s=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,used_memory','--format=csv,noheader'],capture_output=True,text=True,timeout=30)
assert s.returncode==0,'compute process inventory unavailable'
sys.path.insert(0,sys.argv[1])
from pilot_gpu_torch290_candidate import canonical_uuid,check_stack,H100_NAME,MIN_FREE_BYTES
import torch,numpy,transformers
check_stack({'torch':torch.__version__,'transformers':transformers.__version__,'cuda_runtime':torch.version.cuda,'numpy':numpy.__version__})
assert torch.cuda.is_available() and torch.cuda.device_count()==1
torch.cuda.set_device(0);p=torch.cuda.get_device_properties(0);physical=canonical_uuid(getattr(p,'uuid',None))
assert p.name==H100_NAME and torch.cuda.is_bf16_supported()
free,total=torch.cuda.mem_get_info(0);assert free>=MIN_FREE_BYTES
conflicts=[line for line in s.stdout.splitlines() if line.strip() and canonical_uuid(line.split(',')[0])==physical]
assert not conflicts,'unknown process on selected GPU before Torch initialization'
print(json.dumps({'status':'native_preflight_passed','runtime_uuid':physical,'device_name':p.name,'free_bytes':int(free),'total_bytes':int(total),'visible_count':torch.cuda.device_count(),'python':sys.version,'executable':sys.executable,'versions':{'torch':torch.__version__,'transformers':transformers.__version__,'numpy':numpy.__version__,'cuda_runtime':torch.version.cuda},'module_files':{'torch':torch.__file__,'transformers':transformers.__file__,'numpy':numpy.__file__},'process_inventory_before_Torch':s.stdout,'self_nspid':[x for x in pathlib.Path('/proc/self/status').read_text().splitlines() if x.startswith('NSpid:')]}))'''


def worker(directory):
    """Restore pure reviewed helpers, then record one900s synchronous capture."""
    directory = Path(directory).resolve(strict=True)
    root = directory.parents[1]
    stage = root / 'source'
    adapters = stage / CASE_REL / 'adapters'
    raw = (directory / 'platform-allocation-source.json').read_bytes()
    source = validate_source(parse(raw), root)
    before = verify_sources(source, root)
    before[str(OLD_HELPER)] = OLD_HELPER_SHA
    require(sha(OLD_HELPER) == OLD_HELPER_SHA, 'pure restore helper differs')
    put(directory / 'prepared-source-pins.json', before)
    helper = load_pinned(OLD_HELPER, OLD_HELPER_SHA, 'i01_reviewed_bootstrap_helpers')
    # This invokes only stdlib cgroup observation and environment restore, never
    # the old helper's bootstrap(), capture(), old source or spent claims.
    memory = helper.memory()
    put(directory / 'memory-guard.json', memory)
    bootstrap_sources = {str(OLD_HELPER): OLD_HELPER_SHA,
                         memory['guard_source']: memory['guard_sha256']}
    bootstrap_copies = {}
    for original, digest in bootstrap_sources.items():
        destination = directory / 'frozen-bootstrap' / Path(original).name
        destination.parent.mkdir(parents=True, exist_ok=True)
        raw_source = Path(original).read_bytes()
        require(hashlib.sha256(raw_source).hexdigest() == digest, 'bootstrap helper changed')
        write_raw(destination, raw_source)
        bootstrap_copies[original] = {'path': str(destination), 'sha256': digest}
    put(directory / 'frozen-bootstrap-map.json', bootstrap_copies)
    expected_module = load_pinned(stage / EXPECTED_REL, EXPECTED_SOURCE_SHA, 'i01_independent_expected')
    expected_path = directory / 'expected-inventory.json'
    expected_module.build(stage / INPUT_REL, expected_path, stage / SPEC_REL, SPEC_SHA)
    require(expected_path.stat().st_size == EXPECTED_JSON_BYTES and sha(expected_path) == EXPECTED_JSON_SHA,
            'pre-model independent159-target/47-row inventory differs from frozen bytes')
    python = helper.restore_environment(directory)
    restore = parse((directory / 'environment-restore.json').read_bytes())
    env = {'PYTHONHASHSEED': '0', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
           'PYTHONPATH': None, 'PYTHONHOME': None, 'CUBLAS_WORKSPACE_CONFIG': None,
           'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
           'HF_HOME': str(root / 'cache'), 'TMPDIR': str(root / 'tmp')}
    for name in ('cache', 'tmp'):
        (root / name).mkdir(mode=0o700, exist_ok=True)
    effective = dict(os.environ)
    for key, value in env.items():
        if value is None:
            effective.pop(key, None)
        else:
            effective[key] = value
    probe = subprocess.run([str(python), '-B', '-c', native_probe_code(), str(adapters)],
                           env=effective, capture_output=True, timeout=120, check=False)
    write_raw(directory / 'native-preflight.stdout', probe.stdout)
    write_raw(directory / 'native-preflight.stderr', probe.stderr)
    require(probe.returncode == 0, 'native preflight failed; no model capture started')
    native = parse(probe.stdout)
    driver = parse((directory / 'driver-receipt.json').read_bytes())
    require(sum(row['uuid'] == native['runtime_uuid'] and row['name'] == native['device_name']
                for row in driver['rows']) == 1, 'selected CUDA UUID/name not uniquely bound to raw driver query')
    restored = Path(restore['restored']).resolve()
    require(all(Path(p).resolve().is_relative_to(restored) for p in native['module_files'].values()),
            'imported package file lies outside restored environment')
    package_refs = {name: {'path': str(Path(path).resolve()), 'sha256': sha(path),
                          'size_bytes': Path(path).stat().st_size}
                    for name, path in native['module_files'].items()}
    package_copies = freeze_runtime_refs(directory, package_refs)
    put(directory / 'runtime-packages-before.json', package_copies)
    allocation = {'vendor': 'NVIDIA', 'visible_count': 1, 'logical_ordinal': 0,
                  'allocation_id': source['allocation_id'], 'physical_device_id': native['runtime_uuid'],
                  'evidence_source': str(directory / 'platform-allocation-source.json'),
                  'platform_source_sha256': hashlib.sha256(raw).hexdigest(),
                  'native_source': str(directory / 'native-preflight.stdout'),
                  'native_source_sha256': sha(directory / 'native-preflight.stdout')}
    put(directory / 'allocation.json', allocation)
    put(directory / 'execution-profile.json', {'env': env})
    # Freeze dynamic device/binding/expected inputs before model launch as well
    # as project source. Preserve original absolute keys for export admission.
    dynamic_sources = [expected_path, directory / 'allocation.json',
        directory / 'platform-allocation-source.json', directory / 'native-preflight.stdout',
        directory / 'native-preflight.stderr', directory / 'driver-receipt.json',
        directory / 'driver.stdout', directory / 'driver.stderr',
        directory / 'execution-profile.json', directory / 'environment-restore.json',
        directory / 'memory-guard.json', directory / 'runtime-packages-before.json']
    before = verify_sources(source, root)
    before.update(bootstrap_sources)
    before.update({str(path): sha(regular(path, 1024 ** 2)) for path in dynamic_sources})
    before.update({ref['path']: ref['sha256'] for ref in package_refs.values()})
    put(directory / 'sources-before.json', before)
    recorder = load_pinned(stage / RECORD_REL, RECORD_SHA, 'i01_generic_record_run')
    def interrupted(_signum, _frame):
        raise KeyboardInterrupt()
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(sig, interrupted)
    run, command = recorder.record_run(root / 'runs', 'h100', 'i01-cacheoff', CAPTURE_SECONDS,
        lambda folder: [str(python), '-B', str(stage / GPU_REL), '--model', str(TASK / 'model-download/snapshot'),
                        '--input', str(stage / INPUT_REL), '--allocation-receipt', str(directory / 'allocation.json'),
                        '--numerics-policy', str(stage / POLICY_REL), '--device', 'cuda:0',
                        '--stage-spec', str(stage / SPEC_REL), '--stage-spec-sha256', SPEC_SHA,
                        '--expected-inventory', str(expected_path), '--expected-inventory-sha256', EXPECTED_JSON_SHA,
                        '--output', str(folder / 'artifacts')], cwd=stage,
        execution=directory / 'execution-profile.json')
    put(directory / 'generic-receipt-reference.json', {
        'path': str(run / 'command.json'), 'sha256': sha(run / 'command.json'),
        'output_dir': str(run / 'artifacts'), 'status': command['status'],
        'returncode': command['returncode'], 'argv': command['argv']})
    require(command['status'] == 'completed' and command['returncode'] == 0,
            'I01 collector did not complete successfully')
    # The common offline validator is run under the same restored Python; its
    # interface is frozen with the reviewed common/entry source pins.
    validate = '''import json,sys
sys.path.insert(0,sys.argv[1])
from i01_common_v1 import validate_output
print(json.dumps(validate_output(sys.argv[2],sys.argv[3]),allow_nan=False))'''
    checked = subprocess.run([str(python), '-B', '-c', validate, str(adapters),
                              str(run / 'artifacts'), str(stage / INPUT_REL)],
                             env=effective, capture_output=True, timeout=120, check=False)
    write_raw(directory / 'validation.stdout', checked.stdout)
    write_raw(directory / 'validation.stderr', checked.stderr)
    require(checked.returncode == 0, '159-target/47-row output inventory validation failed')
    validation = parse(checked.stdout)
    runtime = parse((run / 'artifacts/runtime.json').read_bytes())
    require(runtime['package_sources'] == package_refs, 'capture package identities differ from pre-model probe')
    runtime_refs = {**package_refs, 'modeling_source': runtime['model_identity']['modeling_source']}
    runtime_copies = freeze_runtime_refs(directory, runtime_refs, package_copies)
    put(directory / 'frozen-runtime-source-map.json', runtime_copies)
    after = verify_sources(source, root)
    after.update({path: sha(path) for path in bootstrap_sources})
    after.update({str(path): sha(regular(path, 1024 ** 2)) for path in dynamic_sources})
    after.update({ref['path']: sha(ref['path']) for ref in package_refs.values()})
    require(before == after and (directory / 'platform-allocation-source.json').read_bytes() == raw,
            'frozen source/input/policy bytes changed')
    require(sha(expected_path) == EXPECTED_JSON_SHA and sha(stage / SPEC_REL) == SPEC_SHA,
            'external stage/expected evidence changed')
    put(directory / 'sources-after.json', after)
    output = run / 'artifacts'
    put(directory / 'capture-receipt.json', {'schema_version': 1, 'status': 'completed',
        'task': 'I01', 'task_id': TASK_ID, 'backend': 'GPU', 'returncode': 0, 'timed_out': False,
        'started_utc': command['start'], 'finished_utc': utc(), 'run': str(run),
        'argv': command['argv'], 'collector_path': str(stage / GPU_REL),
        'collector_sha256': source['source_pins'][GPU_REL], 'input_path': str(stage / INPUT_REL),
        'input_sha256': BASE_PINS[INPUT_REL], 'dependency_paths': list(after),
        'output_dir': str(output), 'artifacts_manifest_sha256': sha(output / 'artifacts-manifest.json'),
        'expected_inventory_source_path': str(expected_path), 'expected_inventory_source_sha256': EXPECTED_JSON_SHA,
        'stage_spec_source_path': str(stage / SPEC_REL), 'stage_spec_source_sha256': SPEC_SHA,
        'generic_receipt': {'path': str(run / 'command.json'), 'sha256': sha(run / 'command.json')},
        'runtime_source_map_path': str(directory / 'frozen-runtime-source-map.json'),
        'runtime_source_map_sha256': sha(directory / 'frozen-runtime-source-map.json'),
        'allocation_path': str(directory / 'allocation.json'), 'allocation_sha256': sha(directory / 'allocation.json'),
        'platform_source_sha256': hashlib.sha256(raw).hexdigest(), 'validation': validation,
        'source_sha256': after, 'original_model_and_environment_preserved': True,
        'native_capture_count': 1, 'acceptance': None})
    return 0


def launch(root=ROOT, query=subprocess.run, runner=supervise):
    root = Path(root)
    started = time.monotonic()
    deadline = started + TOTAL_SECONDS
    regular(Path(__file__))
    require(sys.platform.startswith('linux') and root.is_dir() and not root.is_symlink(),
            'new Linux I01 task root required')
    source_path = root / SOURCE_NAME
    if not wait_source(source_path, min(120, max(0, deadline - time.monotonic()))):
        print(json.dumps({'status': 'source_timeout', 'task_id': TASK_ID, 'model_started': False}), flush=True)
        return 2
    regular(source_path, 131072)
    raw = source_path.read_bytes()
    source = validate_source(parse(raw), root)
    existing = root / 'claims' / source['allocation_id']
    if existing.exists() or existing.is_symlink():
        print(json.dumps({'status': 'refused', 'reason': 'permanent_I01_claim_exists',
                          'claim': str(existing), 'model_started': False}), flush=True)
        return 0
    pins = verify_sources(source, root)
    require(shutil.disk_usage(root).free >= MIN_AFS_FREE_BYTES, 'AFS free space below2GiB')
    require(tree_bytes(root) <= MAX_NEW_BYTES, 'existing new task storage exceeds budget')
    (root / 'claims').mkdir(mode=0o700, exist_ok=True)
    claim = {'schema_version': 1, 'task_id': TASK_ID, 'allocation_id': source['allocation_id'],
             'claimed_utc': utc(), 'hostname': socket.gethostname(), 'pid': os.getpid(),
             'source_sha256': hashlib.sha256(raw).hexdigest(), 'source_pins': pins,
             'old_helper_sha256': OLD_HELPER_SHA, 'whole_attempt_seconds': TOTAL_SECONDS,
             'capture_seconds': CAPTURE_SECONDS, 'max_new_bytes_sampled': MAX_NEW_BYTES,
             'transfer_cap_bytes_each_direction': MAX_TRANSFER_BYTES,
             'scope': 'Permanent new I01 application claim; no retry/release on any failure.'}
    directory = claim_once(root, source['allocation_id'], claim)
    if directory is None:
        print(json.dumps({'status': 'refused', 'reason': 'permanent_I01_claim_exists', 'model_started': False}), flush=True)
        return 0
    write_raw(directory / 'platform-allocation-source.json', raw)
    try:
        freeze_sources(directory, pins, root)
        start = utc()
        result = query(['nvidia-smi', '--query-gpu=uuid,name,driver_version', '--format=csv,noheader'],
                       capture_output=True, timeout=20, check=False)
        write_raw(directory / 'driver.stdout', result.stdout or b'')
        write_raw(directory / 'driver.stderr', result.stderr or b'')
        require(result.returncode == 0, 'native driver query failed')
        rows = []
        for line in result.stdout.decode('utf-8').splitlines():
            fields = [x.strip() for x in line.split(',')]
            require(len(fields) == 3 and fields[0].startswith('GPU-'), 'native driver query columns differ')
            identity = str(uuid.UUID(fields[0][4:]))
            require(identity != str(uuid.UUID(int=0)) and fields[1] and
                    re.fullmatch(r'[0-9]+(?:\.[0-9]+){1,3}', fields[2]), 'native driver metadata unavailable')
            rows.append({'uuid': identity, 'name': fields[1], 'driver_version': fields[2]})
        require(rows, 'native driver query returned no GPU')
        require(len({row['uuid'] for row in rows}) == len(rows), 'duplicate driver query UUID')
        put(directory / 'driver-receipt.json', {'status': 'observed', 'started_utc': start,
            'finished_utc': utc(), 'returncode': result.returncode, 'rows': rows,
            'stdout_sha256': sha(directory / 'driver.stdout'), 'stderr_sha256': sha(directory / 'driver.stderr'),
            'scope': 'Separate pre-model native driver metadata; not the collector runtime.'})
        require(source_path.read_bytes() == raw and verify_sources(source, root) == pins,
                'source changed after permanent claim')
        code, state = runner([sys.executable, '-B', str(root / LIFECYCLE_NAME), '--worker', str(directory)],
                             directory, deadline, root)
        print(json.dumps({'status': state['status'], 'returncode': code, 'claim': str(directory),
                          'controller': str(directory / 'controller-receipt.json'),
                          'app_must_be_stopped_in_platform_UI': True}), flush=True)
        return code
    except BaseException as exc:
        put(directory / 'launch-failure.json', {'status': 'failed', 'finished_utc': utc(),
            'error_type': type(exc).__name__, 'error': str(exc), 'claim_remains_spent': True,
            'app_must_be_stopped_in_platform_UI': True})
        print(json.dumps({'status': 'failed', 'error': str(exc), 'claim': str(directory)}), flush=True)
        return 1


def main():
    os.umask(0o077)
    def interrupted(_signum, _frame):
        raise KeyboardInterrupt()
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(sig, interrupted)
    if len(sys.argv) == 3 and sys.argv[1] == '--worker':
        directory = Path(sys.argv[2])
        try:
            return worker(directory)
        except BaseException as exc:
            failure = {'schema_version': 1, 'task': 'I01', 'task_id': TASK_ID,
                'backend': 'GPU', 'status': 'failed', 'returncode': 1,
                'finished_utc': utc(), 'error_type': type(exc).__name__, 'error': str(exc),
                'claim_remains_spent': True, 'acceptance': None}
            reference = directory / 'generic-receipt-reference.json'
            if reference.is_file():
                failure['generic_receipt'] = parse(reference.read_bytes())
            put(directory / 'capture-failure.json', failure)
            return 1
    require(len(sys.argv) == 1, 'no allocation IDs or unreviewed paths accepted on CLI')
    return launch()


if __name__ == '__main__':
    raise SystemExit(main())

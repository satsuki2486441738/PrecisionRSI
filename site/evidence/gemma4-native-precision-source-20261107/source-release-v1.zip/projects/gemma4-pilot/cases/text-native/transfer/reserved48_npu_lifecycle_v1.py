"""OFFLINE reserved48 NPU-bin lifecycle with unchanged all-board idle guard.

Each bin has its own permanent claim. All production pins remain None. No
observer claim is reused, no busy process is killed and no guard is relaxed.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

CONTRACT_SHA = None
HELPER_SHA = 'c1719e831a557cd9707374138d9219a8ae887854dd029a1ec165631d9259f485'
IDLE_HELPER_SHA = '84e6b29a550e9b9222539dd9c026a6e6820bbc8e3799cccb4759beff57b0d0d8'
SMI_SHA = '22feac701ab31bf5cc8c68244a4d529cf8b4060a8dd95bd3888c65247eda7cf3'


def contract():
    if not isinstance(CONTRACT_SHA,str):raise ValueError('reserved48 NPU lifecycle contract remains unready')
    path=Path(__file__).with_name('reserved48_stage_contract_v1.py')
    import hashlib
    if hashlib.sha256(path.read_bytes()).hexdigest()!=CONTRACT_SHA:raise ValueError('stage-contract source changed')
    spec=importlib.util.spec_from_file_location('_reserved48_NPU_contract',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ready();return m


def helpers(c,context):
    d=context['document'];source=context['source']
    helper=c.load_module(source/d['cleanup_relative_path'],HELPER_SHA,'_reserved48_NPU_reviewed_native_probe')
    idle=c.load_module(source/d['npu_idle_helper_relative_path'],IDLE_HELPER_SHA,'_reserved48_NPU_all_board_idle_parser')
    return helper,idle


def clean_environment():
    env=dict(os.environ)
    for key in ('PYTHONHOME','PYTHONPATH'):env.pop(key,None)
    env.update(PYTHONHASHSEED='0',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',TORCH_DEVICE_BACKEND_AUTOLOAD='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    return env


def idle_observation(c,idle,context,claim,number):
    d=context['document'];literal=d['npu_smi']['path'];c.absolute(literal);smi=Path(literal)
    c.require(literal=='/srv/precision-user/.local/bin/npu-smi' and d['npu_smi']['sha256']==SMI_SHA,'actual frozen NPU CLI identity differs')
    identity=idle.smi_identity(smi,SMI_SHA)
    if number==1:c.put(claim/'npu-smi-identity.json',identity)
    process=subprocess.run([literal,'info'],capture_output=True,timeout=20)
    for suffix,raw in (('stdout',process.stdout),('stderr',process.stderr)):
        with (claim/('process-%d.%s'%(number,suffix))).open('xb') as f:f.write(raw)
    c.require(process.returncode==0,'all-board NPU process query failed')
    # Original helper requires the exact observed hardware-board inventory and
    # explicit emptiness; any shared PID/unknown/partial table fails closed.
    result=idle.process_gate(process.stdout);c.put(claim/('process-%d.json'%number),result)


def native_probe(c,context,claim):
    c.worker_guard(context,claim,probe=True);helper,_=helpers(c,context);d=context['document']
    args=SimpleNamespace(allocation=Path(d['allocation_receipt']['path']),native_mapping=Path(d['native_mapping']['path']),native_source=Path(d['native_source']['path']))
    helper.native_probe(args,claim/'native-preflight.json')
    return 0


def prepare(c,context,claim):
    d=context['document'];helper,idle=helpers(c,context)
    a,physical=helper.binding(Path(d['allocation_receipt']['path']),Path(d['native_mapping']['path']),Path(d['native_source']['path']))
    c.require(a['allocation_id']==context['platform']['allocation_id'] and a['visible_count']==8 and a['logical_ordinal']==0,
        'actual NPU allocation/bin source differs; visible8 is selected TP1')
    memory=helper.memory_observation();c.require(memory['effective_available_bytes']>=80*c.GIB,'NPU effective host/cgroup80GiB guard');c.put(claim/'memory-guard.json',memory)
    idle_observation(c,idle,context,claim,1)
    python=Path(d['python']);c.require(python.is_file(),'explicit existing Torch2.9 CPU/NPU Python required')
    argv=[str(python),'-B',str(Path(__file__).resolve()),'--config',context['config_ref']['path'],'--config-sha256',context['config_ref']['sha256'],
        '--prompt-bin',str(context['bin']),'--internal-probe','--claim',str(claim)]
    probe=subprocess.run(argv,env=clean_environment(),capture_output=True,timeout=120)
    for name,raw in (('native-preflight.stdout',probe.stdout),('native-preflight.stderr',probe.stderr)):
        with (claim/name).open('xb') as f:f.write(raw)
    c.require(probe.returncode==0,'fresh selected NPU probe failed; claim remains spent')
    observed=c.read(claim/'native-preflight.json');c.require(observed['status']=='preflight_passed' and observed['runtime_uuid']==physical and observed['visible_count']==8,
        'fresh NPU UUID/visibility differs from recorded selected allocation')
    idle_observation(c,idle,context,claim,2)
    dynamic=[p for p in claim.rglob('*') if p.is_file() and p.name not in ('worker.stdout','worker.stderr')]
    for name in ('allocation_receipt','native_mapping','native_source','driver_source','npu_smi'):
        value=d[name];c.require(c.file_ref(value['path'])==value,'original NPU mapping/driver/CLI changed before model');dynamic.append(Path(value['path']))
    return python,Path(d['allocation_receipt']['path']),dynamic


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--config',type=Path,required=True);p.add_argument('--config-sha256',required=True)
    p.add_argument('--prompt-bin',type=int,choices=(128,512,2048,8192),required=True)
    p.add_argument('--internal-worker',action='store_true');p.add_argument('--internal-probe',action='store_true');p.add_argument('--claim',type=Path);args=p.parse_args()
    c=contract()
    with c.entry_deadline(args.prompt_bin):
        context=c.source_context(args.config,args.config_sha256,'NPU');c.require(context['bin']==args.prompt_bin,'CLI/prepared bin mismatch')
        c.require(c.sha(__file__)==context['document']['reviewed_source_sha256']['lifecycle'],'actual new NPU lifecycle source differs')
        c.require(not(args.internal_worker and args.internal_probe),'one explicit internal entry only')
        if args.internal_worker or args.internal_probe:
            c.require(args.claim is not None,'internal entry requires an existing claim')
            if args.internal_probe:return native_probe(c,context,args.claim)
            c.run_worker(context,args.claim,lambda ctx,claim:prepare(c,ctx,claim));return 0
        result=c.supervise(context,args.config,args.config_sha256,Path(__file__).resolve());print(json.dumps(result,indent=2));return result.get('returncode',0)


if __name__=='__main__':raise SystemExit(main())

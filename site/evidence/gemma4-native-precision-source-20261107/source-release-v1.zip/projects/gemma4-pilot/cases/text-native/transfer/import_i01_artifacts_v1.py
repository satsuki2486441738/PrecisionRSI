"""Bounded regular-file-only I01 tool/GPU import, preserving failed new paths."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path,PurePosixPath
import re
import shutil
import signal
import tarfile
import time

GPU_NAME='gpu-i01-full-REDACTED_APP_ID-20261106T134159Z.tar.gz'
GPU_BYTES=88540232
GPU_SHA='6d2e0864493e80e9e3123f107fc0cfc6e66c0b18069736af91ea773d68ff5cc4'
GPU_MAP_SHA='dbf3d67094a3b5399d46fc488724b89a497f9051486d4e50c8b2056e31cffd9b'
MAIN='projects/gemma4-pilot/cases/text-native/adapters/i01_admission_compare_v1.py'
MAIN_SHA='f7fe91cdcebeec910efed4579ecf379fd665cf305223a3fa77858004db81858a'
EXPECTED='projects/gemma4-pilot/cases/text-native/adapters/i01_expected_inventory_v1.py'
EXPECTED_SHA='834de8fef3d6147b908450116e39a48ea75a026bfc13a290db7db25492fbb40b'
HEX=re.compile(r'^[a-f0-9]{64}$')
GRID=sorted(set(i*127//15 for i in range(16))|set(range(127,159)))
LARGE={'raw-native-logits.safetensors'}|{'dist-p%03d.npy'%p for p in GRID}


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def load(path):
    def pairs(items):
        result={}
        for key,value in items:require(key not in result,'duplicate JSON key');result[key]=value
        return result
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)


def put(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def safe_name(name):
    p=PurePosixPath(name)
    require(isinstance(name,str) and name and not p.is_absolute() and '\\' not in name and
        all(part not in ('','.','..') for part in name.split('/')) and str(p)==name,'unsafe/noncanonical archive member')
    return name


def extract(archive,output,max_expanded):
    require(not output.exists() and output.parent.is_dir(),'exclusive new import directory required')
    with tarfile.open(archive,'r:*') as package:
        members=package.getmembers();names=[safe_name(m.name) for m in members]
        require(members and len(members)<=2048 and len(names)==len(set(names)) and all(m.isfile() and not m.issym() and not m.islnk() and
            m.size>=0 for m in members),'archive must contain unique regular members only')
        total=sum(m.size for m in members);require(total<=max_expanded,'expanded archive exceeds finite bound')
        # Reject file/directory collisions before creating any output bytes.
        memberset=set(names)
        require(all(not any(str(parent) in memberset for parent in PurePosixPath(name).parents if str(parent)!='.') for name in names),
            'archive has ancestor file collision')
        require(shutil.disk_usage(output.parent).free>=max(2*1024**3,total+1024**3),'insufficient observed free space for bounded import')
        output.mkdir(mode=0o700)
        for member in members:
            target=output/member.name;target.parent.mkdir(parents=True,exist_ok=True)
            require(target.resolve().is_relative_to(output.resolve()),'resolved member escapes new import')
            source=package.extractfile(member);require(source is not None,'regular member stream missing')
            with source,target.open('xb') as stream:
                copied=0
                for block in iter(lambda:source.read(4*1024**2),b''):stream.write(block);copied+=len(block)
            require(copied==member.size,'member byte count differs')
    return set(names),total


def verify_tools(output,names,manifest_sha):
    manifest=output/'tool-bundle-manifest.json'
    require(HEX.fullmatch(manifest_sha) and sha(manifest)==manifest_sha,'external tool manifest SHA differs')
    doc=load(manifest);require(doc['schema_version']==1 and doc['kind']=='i01-offline-tool-bundle' and doc['acceptance'] is None and
        doc['native_executions_started']==0,'wrong tool manifest')
    require(set(doc['files'])|{'tool-bundle-manifest.json'}==names,'tool manifest member set differs')
    require(doc['files'][MAIN]['sha256']==MAIN_SHA and doc['files'][EXPECTED]['sha256']==EXPECTED_SHA,'reviewed source pins differ')
    for name,ref in doc['files'].items():
        target=output/safe_name(name)
        require(set(ref)=={'sha256','size_bytes'} and target.stat().st_size==ref['size_bytes'] and sha(target)==ref['sha256'],
            'tool source byte identity differs: '+name)
    return {'manifest':str(manifest),'manifest_sha256':manifest_sha,'files_checked':len(doc['files'])}


def verify_gpu(output,names):
    mapping=output/'source-map.json';require(sha(mapping)==GPU_MAP_SHA,'actual GPU top source-map pin differs')
    doc=load(mapping);require(doc['request']['task']=='I01' and doc['request']['backend']=='GPU' and
        doc.get('retained_array_count')==0 and doc.get('full_array_hashes_checked')==48 and doc.get('acceptance') is None,
        'full GPU I01 export identity differs')
    payload=set();large=[]
    for original,ref in doc['files'].items():
        p=PurePosixPath(original);require(p.is_absolute() and '\\' not in original and '..' not in p.parts,'original POSIX source path changed')
        require('path' in ref and not ref.get('retained_at_source') and type(ref.get('size')) is int and ref['size']>=0 and
            isinstance(ref.get('sha256'),str) and HEX.fullmatch(ref['sha256']),'GPU full copied source reference required')
        relative=safe_name(ref['path']);require(relative.startswith('payload/') and relative not in payload,'mapped payload path duplicated/invalid')
        payload.add(relative);target=output/relative
        require(target.is_file() and target.stat().st_size==ref['size'] and sha(target)==ref['sha256'],'actual mapped GPU payload bytes differ')
        if p.suffix in ('.npy','.safetensors'):large.append(p.name)
        else:require(ref['size']<=4*1024**2,'unexpected large non-array GPU payload')
    require(set(large)==LARGE and len(large)==48,'exact raw80MiB and47fullFP64 arrays required')
    require(names==payload|{'source-map.json','export-summary.json'},'unmapped/omitted GPU archive member')
    return {'source_map':str(mapping),'source_map_sha256':GPU_MAP_SHA,'mapped_files_checked':len(payload),
        'new_native_array_files_checked':48,'raw_receipts_rewritten':False,'numeric_admission_performed':False}


def import_archive(root,archive,kind,digest,size,manifest_sha=None):
    require(not Path(root).is_symlink() and not Path(archive).is_symlink(),'original root/archive must not be symbolic links')
    root=Path(root).resolve(strict=True);archive=Path(archive).resolve(strict=True)
    require(root.is_dir() and archive.is_relative_to(root) and archive.is_file() and not archive.is_symlink(),'original uploaded archive must be below explicit R')
    require(HEX.fullmatch(digest) and type(size) is int and size>0 and archive.stat().st_size==size and sha(archive)==digest,'uploaded archive size/SHA differs')
    if kind=='gpu':require(archive.name==GPU_NAME and size==GPU_BYTES and digest==GPU_SHA,'only fixed actual GPU whole archive accepted')
    else:require(kind=='tools' and size<=2*1024**2 and manifest_sha is not None,'small frozen tools archive/manifest required')
    parent=root/('imports' if kind=='gpu' else 'tools');parent.mkdir(mode=0o700,exist_ok=True)
    require(parent.resolve().is_relative_to(root) and not parent.is_symlink(),'import parent escapes R')
    label='gpu-i01-full-REDACTED_APP_ID' if kind=='gpu' else 'i01-cpu-compare-v1'
    output=parent/(label+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    receipt=parent/(output.name+'-import-receipt.json')
    state={'schema_version':1,'kind':kind,'status':'running','started_utc':datetime.now(timezone.utc).isoformat(),
        'archive':str(archive),'archive_sha256':digest,'archive_bytes':size,'output':str(output),
        'cpu_timeout_seconds':240,'original_archive_preserved':True,'automatic_retry':False,'acceptance':None}
    started=time.monotonic()
    try:
        names,expanded=extract(archive,output,384*1024**2 if kind=='gpu' else 4*1024**2)
        state.update(verify_gpu(output,names) if kind=='gpu' else verify_tools(output,names,manifest_sha))
        require(sha(archive)==digest,'original uploaded archive changed during import')
        state.update(status='completed',returncode=0,regular_members=len(names),expanded_bytes=expanded)
    except BaseException as exc:
        state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),partial_output_preserved=True)
    finally:
        state.update(finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started)
        put(receipt,state)
    print(json.dumps({**state,'receipt':str(receipt)},indent=2),flush=True)
    return state['returncode']


def self_test():
    """Synthetic archive-path regressions, never actual inference evidence."""
    import io,tempfile
    for bad in ('/abs','../escape','a/../b','a//b','a\\b','./x',''):
        try:safe_name(bad)
        except ValueError:pass
        else:raise AssertionError('unsafe member accepted')
    with tempfile.TemporaryDirectory() as temporary:
        root=Path(temporary)
        for kind in ('duplicate','symlink','ancestor'):
            archive=root/(kind+'.tar')
            with tarfile.open(archive,'w') as package:
                for name in (['x','x'] if kind=='duplicate' else ['x','x/y'] if kind=='ancestor' else ['x']):
                    item=tarfile.TarInfo(name);item.size=1
                    if kind=='symlink':item.type=tarfile.SYMTYPE;item.linkname='/synthetic/outside';item.size=0
                    package.addfile(item,io.BytesIO(b'x'))
            try:extract(archive,root/(kind+'-out'),1024)
            except ValueError:pass
            else:raise AssertionError('unsafe synthetic archive accepted')
        target=root/'existing';target.mkdir()
        try:extract(root/'duplicate.tar',target,1024)
        except ValueError:pass
        else:raise AssertionError('existing directory accepted')
    print('synthetic_archive_regressions_passed; native_executions_started=0')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--self-test',action='store_true')
    parser.add_argument('--root',type=Path);parser.add_argument('--archive',type=Path);parser.add_argument('--kind',choices=['tools','gpu'])
    parser.add_argument('--archive-sha256');parser.add_argument('--archive-bytes',type=int);parser.add_argument('--manifest-sha256');args=parser.parse_args()
    if args.self_test:self_test();return 0
    require(all(getattr(args,n) is not None for n in ('root','archive','kind','archive_sha256','archive_bytes')),'all actual archive pins required')
    def expire(*_):raise TimeoutError('bounded import240s deadline reached')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,240)
    try:return import_archive(args.root,args.archive,args.kind,args.archive_sha256,args.archive_bytes,args.manifest_sha256)
    finally:signal.setitimer(signal.ITIMER_REAL,0)


if __name__=='__main__':raise SystemExit(main())

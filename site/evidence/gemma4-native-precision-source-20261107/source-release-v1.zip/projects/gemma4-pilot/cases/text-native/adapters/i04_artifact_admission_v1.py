"""Independent I04 raw-BF16, request/padding and complete product admission.

The immutable I03 helper supplies only source-map resolution, strict JSON and
RNG descriptor checks. I04 shape/coordinate/mask/numerical checks are new.
No collector/common validation function, Torch or device API is called.
"""
import math
from pathlib import Path, PurePosixPath
import struct

import numpy as np
import i03_artifact_admission_v1 as prior
import i04_expected_inventory_v1 as expected
import i04_prerequisite_v1 as i03_proof
import i04_cpu_prerequisite_v2 as cpu_proof

old = prior.old
require, canonical, load, sha, child = prior.require, prior.canonical, prior.load, prior.sha, prior.child
VOCABULARY = 262144
TASK = expected.TASK
STAGE_ID = expected.STAGE_ID
STAGE_SHA = expected.STAGE_SHA256
INPUT_SHAS = {'A': expected.INPUT_A_SHA256, 'B': expected.INPUT_B_SHA256}
EXPECTED_SHA = '22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76'
EXPECTED_SOURCE_SHA = 'b8f134724a295072a77e292864ebf12e0e5944f184690ba36f0f9d55937f1752'
I03_PROOF_SHA = '3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c'
I03_HELPER_SHA = '8d42c0eb525c92c23c5324dc751149b47f3c20b8e74d65d4ba76de6c1ca068f0'
CPU_HELPER_SHA = '8943f40ceb3b6c98408142843db72aa9d3b53df176b4a9add0ab3d5222a78e38'
PRIOR_SHA = 'b734babc65be6ec361acbc10905b6c3e02e8c5c57650efb11e3a195134a1b6eb'
CAP_BYTES = 1342177280
ATOL = 1e-12
NORMALIZATION = prior.NORMALIZATION
MODES = ['alone-A', 'alone-B', 'batch-left', 'batch-right']


def verify_tools():
    prior.verify_tools()
    for module, digest in [(prior, PRIOR_SHA), (expected, EXPECTED_SOURCE_SHA),
            (i03_proof, I03_HELPER_SHA), (cpu_proof, CPU_HELPER_SHA)]:
        require(sha(module.__file__) == digest, 'frozen independent I04 dependency differs')
        require(Path(module.__file__).resolve().parent == Path(__file__).resolve().parent,
                'independent I04 helper imported outside staged adapters')


class Endpoint(prior.Endpoint):
    """Keep original POSIX keys and a checked read cache; final rehash is required."""
    def get(self, name, expected_sha=None):
        name = old.origin(name)
        if name in self.checked:
            require(expected_sha is None or self.checked[name] == expected_sha, 'conflicting original source digest')
            return Path(self.resolved[name])
        return super().get(name, expected_sha)


def safe_relative(name):
    return prior.safe_relative(name)


def ref(endpoint, name):
    path = endpoint.get(name)
    return {'path': name, 'sha256': endpoint.checked[name], 'size_bytes': path.stat().st_size}


def decode_bits(bits):
    require(bits.dtype == np.dtype('<u2'), 'lossless little-endian BF16 words required')
    return (np.asarray(bits, dtype='<u4') << np.uint32(16)).view('<f4').astype(np.float64)


def raw_tensor(path, shape):
    """Read the exact I04 physical tensor, preserving pad-only payload words."""
    path = Path(path)
    with path.open('rb') as stream:
        prefix = stream.read(8); require(len(prefix) == 8, 'truncated native raw length')
        length = struct.unpack('<Q', prefix)[0]
        require(0 < length <= 65536, 'bounded native raw safetensors header required')
        raw = stream.read(length); require(len(raw) == length, 'truncated native raw header')
    header = old.parse(raw)
    require(set(header) in ({'logits'}, {'logits', '__metadata__'}), 'one original logits tensor required')
    size = math.prod(shape) * 2
    require(canonical(header['logits']) == canonical({'dtype': 'BF16', 'shape': shape, 'data_offsets': [0, size]}) and
            path.stat().st_size == 8 + length + size, 'native physical dtype/shape/offset/length differs')
    if '__metadata__' in header:
        require(isinstance(header['__metadata__'], dict) and all(isinstance(k, str) and isinstance(v, str)
            for k, v in header['__metadata__'].items()), 'raw metadata must contain strings')
    return np.memmap(path, mode='r', dtype='<u2', offset=8 + length, shape=tuple(shape))


def independent_logprobs(bits):
    require(bits.shape == (VOCABULARY,), 'complete logical BF16 vocabulary row required')
    values = decode_bits(bits)
    require(np.isfinite(values).all(), 'valid native row is nonfinite, including the unscored final predictor')
    values -= float(np.max(values))
    values -= math.log(math.fsum(math.exp(float(value)) for value in values))
    require(np.isfinite(values).all() and np.max(values) <= 0, 'independent FP64 log probabilities invalid')
    return values


def pad_inventory(native, plan):
    valid = {(o['slot'], o['physical_offset'] + p) for o in plan['observations'] for p in range(o['sequence_length'])}
    pads = {(item['slot'], item['physical_position']) for item in plan['pad_only_rows']}
    physical = {(slot, p) for slot in range(native.shape[0]) for p in range(native.shape[1])}
    require(len(valid) == sum(o['sequence_length'] for o in plan['observations']) and
            not valid & pads and valid | pads == physical and len(pads) == len(plan['pad_only_rows']),
            'complete disjoint valid/pad physical row inventory required')
    counts = {'rows': len(pads), 'coordinates': len(pads) * VOCABULARY, 'rows_with_nonfinite': 0,
        'nan': 0, 'positive_infinity': 0, 'negative_infinity': 0, 'nonfinite': 0}
    for slot, position in sorted(pads):
        values = decode_bits(native[slot, position])
        nan, positive, negative = int(np.isnan(values).sum()), int(np.isposinf(values).sum()), int(np.isneginf(values).sum())
        total = nan + positive + negative
        counts['rows_with_nonfinite'] += int(total > 0); counts['nan'] += nan
        counts['positive_infinity'] += positive; counts['negative_infinity'] += negative; counts['nonfinite'] += total
    return counts


def copy_portable(endpoint, logical, digest, helper, folder, raw_count):
    source = endpoint.get(logical, digest); doc = load(source); files = {}
    def visit(value):
        if isinstance(value, dict):
            if set(value) == {'path', 'source_path', 'sha256'}:
                relative = safe_relative(value['path']); require(relative not in files, 'duplicate portable proof copy path')
                files[relative] = endpoint.get(child(str(PurePosixPath(logical).parent), relative), value['sha256'])
            else:
                for child_value in value.values(): visit(child_value)
        elif isinstance(value, list):
            for child_value in value: visit(child_value)
    visit(doc); require(len(files) == raw_count, 'complete portable proof raw-document inventory required')
    folder.mkdir()
    with (folder / 'prerequisite.json').open('xb') as stream: stream.write(source.read_bytes())
    for relative, path in files.items():
        target = folder / relative; target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write(path.read_bytes())
    checked = helper.prerequisite(folder / 'prerequisite.json', digest)
    return doc, checked, {'prerequisite.json', *files}


def inspect_observation(endpoint, prefix, observation, request, raw, raw_ref):
    """Reconstruct every valid target; selected rows retain complete vocabulary."""
    name = observation['request']; slot, offset = observation['slot'], observation['physical_offset']
    sequence = request['input_ids']; length = request['sequence_length']
    paths = {key: endpoint.get(child(prefix, key)) for key in ('target-scores.json', 'distributions.json')}
    scores_doc, distributions = load(paths['target-scores.json']), load(paths['distributions.json'])
    base = {'schema_version': 1, 'task': TASK, 'mode': str(PurePosixPath(prefix).parent.name), 'request': name,
        'stage_spec_sha256': STAGE_SHA, 'input_sha256s': INPUT_SHAS, 'request_input_sha256': INPUT_SHAS[name],
        'raw_logits_sha256': raw_ref['sha256'], 'native_logits_dtype': 'torch.bfloat16', 'logprob_dtype': 'float64',
        'normalization': NORMALIZATION, 'slot': slot, 'physical_offset': offset}
    for doc, kind in ((scores_doc, 'i04-native-target-scores'), (distributions, 'i04-native-distribution-rows')):
        wanted = {**base, 'kind': kind}
        require(all(key in doc and canonical(doc[key]) == canonical(value) for key, value in wanted.items()),
                'request raw-derived source identity differs')
    scores, items = scores_doc['scores'], distributions['positions']
    require(len(scores) == length - 1 and len(items) == len(observation['distribution_positions']) == 47,
            'complete request-specific target/distribution inventory required')
    for score, coordinate in zip(scores, observation['all_targets']):
        wanted = {**coordinate, 'request': name, 'slot': slot}
        require(all(key in score and canonical(score[key]) == canonical(value) for key, value in wanted.items()) and
            type(score.get('logprob')) in (int, float) and math.isfinite(score['logprob']) and score['logprob'] <= 0,
            'logical/physical target coordinate or value differs')
    selected = {}; normalized = []
    for item, coordinate in zip(items, observation['distribution_positions']):
        p = coordinate['position']; stem = 'dist-p%03d' % p; descriptor = {'path': stem + '.npy', 'row': 0}
        roles = (['prompt_sample'] if p in [i * (request['prompt_length'] - 1) // 15 for i in range(16)] else [])
        roles += ['continuation'] if p >= request['prompt_length'] - 1 else []
        wanted = {**coordinate, 'roles': roles, 'scores': descriptor, 'record': stem + '.json'}
        require(all(key in item and canonical(item[key]) == canonical(value) for key, value in wanted.items()),
                'prespecified logical/physical full-row coordinate differs')
        record = endpoint.json(child(prefix, stem + '.json'))
        wanted = {**base, **coordinate, 'roles': roles, 'scores': descriptor, 'target_position': p + 1,
            'token': sequence[p + 1], 'logprob': scores[p]['logprob']}
        require(all(key in record and canonical(record[key]) == canonical(value) for key, value in wanted.items()),
                'request row target/physical offset/raw provenance differs')
        path = endpoint.get(child(prefix, stem + '.npy')); selected[p] = path
        normalized.append({key: coordinate[key] for key in ('sample', 'position', 'history')} |
            {'scores': {'path': str(path), 'row': 0}})
    maximum = 0.0
    for p in range(length):
        physical = offset + p
        if p == length - 1:
            require(np.isfinite(decode_bits(raw[slot, physical])).all(), 'valid unscored final row is nonfinite')
            continue
        derived = independent_logprobs(raw[slot, physical]); delta = abs(float(derived[sequence[p + 1]]) - scores[p]['logprob'])
        require(delta <= ATOL, 'raw BF16 target score reconstruction differs at logical ' + str(p))
        maximum = max(maximum, delta)
        if p in selected:
            array = np.load(selected[p], mmap_mode='r', allow_pickle=False)
            try:
                require(array.shape == (1, VOCABULARY) and array.dtype == np.dtype('float64') and
                    np.isfinite(array).all() and float(np.max(array)) <= 0, 'full FP64 NPY shape/dtype/finiteness differs')
                delta = float(np.max(np.abs(array[0] - derived)))
                require(delta <= ATOL and float(array[0, sequence[p + 1]]) == scores[p]['logprob'],
                        'complete NPY reconstruction/target lookup differs')
            finally: array._mmap.close()
            maximum = max(maximum, delta)
    summary = {'request': name, 'sample': request['sample'], 'slot': slot, 'physical_offset': offset,
        'sequence_length': length, 'targets': length - 1, 'sampled_distributions': 47, 'unscored_logical_predictors': [length - 1]}
    return {'summary': summary, 'targets': request['all_targets'], 'positions': normalized,
        'scores': [{key: score[key] for key in ('sample', 'position', 'token', 'logprob')} for score in scores],
        'raw_derivation_max_abs_delta': maximum, 'source_prefix': prefix}


def inspect_mode(endpoint, output, plan, inventory, baseline, baseline_sha, policy, device):
    mode = plan['id']; prefix = child(output, 'modes/' + mode)
    paths = {name: endpoint.get(child(prefix, name)) for name in ('raw-native-logits.safetensors', 'events.json',
        'raw-row-inventory.json', 'capture-summary.json', 'model-state-after.json', 'state-control.json')}
    raw_ref = ref(endpoint, child(prefix, 'raw-native-logits.safetensors'))
    events = load(paths['events.json'])
    wanted = {**plan, 'mode': mode, 'call_index': 0, 'use_cache': False, 'past_key_values_is_none': True,
        'logits_to_keep': 0, 'labels_supplied': False, 'shared_kv_states_supplied': False,
        'returned_cache': None, 'returned_shared_kv_states': None,
        'native_logits_shape': plan['raw_logits']['shape'], 'native_logits_dtype': 'torch.bfloat16'}
    require(len(events) == 1 and all(key in events[0] and canonical(events[0][key]) == canonical(value) for key, value in wanted.items()),
            'one exact cache-off physical input/mask/position event required')
    raw = raw_tensor(paths['raw-native-logits.safetensors'], plan['raw_logits']['shape'])
    observations = {}
    try:
        pads = pad_inventory(raw, plan)
        for observation in plan['observations']:
            request = observation['request']
            observations[request] = inspect_observation(endpoint, child(prefix, 'request-' + request), observation,
                inventory['requests'][request], raw, raw_ref)
    finally: raw._mmap.close()
    row_inventory = load(paths['raw-row-inventory.json']); physical = math.prod(plan['raw_logits']['shape'][:2])
    valid = sum(item['sequence_length'] for item in plan['observations'])
    wanted = {'schema_version': 1, 'task': TASK, 'mode': mode, 'raw_logits_sha256': raw_ref['sha256'],
        'physical_raw_rows': physical, 'valid_raw_rows': valid, 'valid_nonfinite_coordinates': 0,
        'pad_only_rows': plan['pad_only_rows'], 'pad_only_nonfinite_counts': pads}
    require(all(key in row_inventory and canonical(row_inventory[key]) == canonical(value) for key, value in wanted.items()),
            'independently counted valid/pad-only raw inventory differs')
    summary = load(paths['capture-summary.json'])
    wanted = {'schema_version': 1, 'task': TASK, 'mode': mode, 'native_forward_calls': 1, 'use_cache': False,
        'raw_logits': raw_ref, 'native_logits_shape': plan['raw_logits']['shape'], 'native_logits_dtype': 'torch.bfloat16',
        'observations': [observations[item['request']]['summary'] for item in plan['observations']],
        'targets': sum(item['sequence_length'] - 1 for item in plan['observations']), 'sampled_distributions': 47 * len(observations),
        'physical_raw_rows': physical, 'valid_raw_rows': valid, 'pad_only_raw_rows': len(plan['pad_only_rows']),
        'pad_only_nonfinite_counts': pads}
    require(all(key in summary and canonical(summary[key]) == canonical(value) for key, value in wanted.items()), 'mode complete native summary differs')
    require(canonical(load(paths['model-state-after.json'])) == canonical(baseline), 'persistent loaded model state changed')
    control = load(paths['state-control.json'])
    require(control.get('mode') == mode and type(control.get('seed_reset', {}).get('seed')) is int and control['seed_reset']['seed'] == 0 and
        canonical(control['seed_reset']['settings']) == canonical(policy) == canonical(control['math_policy']) and
        control['baseline_model_state_sha256'] == baseline_sha and control['model_state_after_sha256'] == sha(paths['model-state-after.json']),
        'mode seed/state/policy source chain differs')
    if device == 'cuda:0':
        require(all(type(control['seed_reset'].get(key)) is int and control['seed_reset'][key] == 0 for key in
            ('seed', 'python_random_seed', 'numpy_seed', 'torch_initial_seed', 'cuda_initial_seed')), 'GPU complete seed reset differs')
    prior.rng_descriptor(control['rng_before'], before=True); prior.rng_descriptor(control['rng_after'])
    return {'summary': summary, 'observations': observations, 'rng_before': control['rng_before'], 'raw_sha256': raw_ref['sha256'],
        'pad_inventory': row_inventory, 'mode_plan': plan}


def inspect_output(endpoint, outer, cpu_sha, proof_folder):
    output = old.origin(outer['output_dir'])
    external = endpoint.get(outer['expected_inventory_source_path'], EXPECTED_SHA)
    inventory = expected.verify(external, endpoint.get(outer['input_path'], INPUT_SHAS['A']),
        endpoint.get(outer['input_b_path'], INPUT_SHAS['B']), endpoint.get(outer['stage_spec_source_path'], STAGE_SHA))
    manifest_path = endpoint.get(child(output, 'artifacts-manifest.json'), outer['artifacts_manifest_sha256']); manifest = load(manifest_path)
    fixed = {'schema_version': 1, 'kind': 'i04-capture-artifacts', 'task': TASK, 'backend': outer['backend'].lower(),
        'stage_spec_sha256': STAGE_SHA, 'input_sha256s': INPUT_SHAS, 'expected_inventory_sha256': EXPECTED_SHA,
        'i03_prerequisite_sha256': I03_PROOF_SHA, 'acceptance': None}
    require(all(key in manifest and canonical(manifest[key]) == canonical(value) for key, value in fixed.items()), 'recursive I04 manifest identity differs')
    files = manifest['files']; observed = {name[len(output) + 1:] for name in endpoint.files if name.startswith(output + '/')}
    require(observed == set(files) | {'artifacts-manifest.json', 'status.json'}, 'unmapped extra/missing original capture artifact')
    paths = {}; total = 0
    for name, item in files.items():
        safe_relative(name)
        require(set(item) == {'sha256', 'size_bytes'} and type(item['size_bytes']) is int and item['size_bytes'] >= 0,
                'invalid recursive artifact descriptor')
        actual = endpoint.get(child(output, name), item['sha256'])
        require(actual.stat().st_size == item['size_bytes'], 'recursive artifact size differs')
        paths[name] = actual; total += item['size_bytes']
    require(total <= CAP_BYTES and sha(paths['input-A.json']) == INPUT_SHAS['A'] and sha(paths['input-B.json']) == INPUT_SHAS['B'] and
        sha(paths['stage-spec.json']) == STAGE_SHA and paths['expected-inventory.json'].read_bytes() == external.read_bytes(), 'input/stage/expected bytes or capture cap differs')
    proof_folder.mkdir()
    _, _, i03_names = copy_portable(endpoint, child(output, 'prerequisite/prerequisite.json'), I03_PROOF_SHA,
        i03_proof, proof_folder / 'i03', 8)
    require(endpoint.get(outer['i03_prerequisite_source_path'], I03_PROOF_SHA).read_bytes() == paths['prerequisite/prerequisite.json'].read_bytes(),
            'pre-model I03 portable proof was not preserved')
    _, cpu_checked, _ = copy_portable(endpoint, outer['cpu_prerequisite_source_path'], cpu_sha, cpu_proof, proof_folder / 'cpu', 21)
    required = {'input-A.json', 'input-B.json', 'stage-spec.json', 'expected-inventory.json', 'snapshot-verification.json',
        'loaded-model-inventory.json', 'loaded-model-state.json', 'runtime.json', 'policy-before-load.json', 'policy-after-load.json',
        'policy-after-capture.json', 'capture-summary.json'} | {'prerequisite/' + name for name in i03_names}
    if outer['backend'] == 'NPU': required.add('driver-version-provenance.json')
    runtime = load(paths['runtime.json']); baseline = load(paths['loaded-model-state.json']); policy = runtime['math_policy']
    require(type(baseline.get('model_object_id')) is int and baseline['model_object_id'] > 0 and
        baseline.get('class', '').endswith('.Gemma4UnifiedForConditionalGeneration') and baseline['parameters'] and
        all(flag is False for _, flag in baseline['module_training_flags']) and
        canonical(load(paths['loaded-model-inventory.json'])['config']) == canonical(baseline['config']), 'loaded model/config/eval observations differ')
    config=baseline['config']['text_config'];types=config['layer_types']
    require(len(types)==48 and types.count('sliding_attention')==40 and types.count('full_attention')==8 and
        config['num_key_value_heads']==8 and config['num_global_key_value_heads']==1 and config['head_dim']==256 and
        config['global_head_dim']==512 and config['num_kv_shared_layers']==0 and config['pad_token_id']==0,
        'configured48-layer attention/padding inventory differs')
    modes = {}; anchor = None
    for plan in inventory['modes']:
        prefix = 'modes/' + plan['id'] + '/'
        required.update(prefix + name for name in ('raw-native-logits.safetensors', 'events.json', 'raw-row-inventory.json',
            'capture-summary.json', 'model-state-after.json', 'state-control.json'))
        for observation in plan['observations']:
            sub = prefix + 'request-' + observation['request'] + '/'
            required.update(sub + name for name in ('target-scores.json', 'distributions.json'))
            required.update(sub + 'dist-p%03d%s' % (item['position'], suffix) for item in observation['distribution_positions'] for suffix in ('.json', '.npy'))
        mode = inspect_mode(endpoint, output, plan, inventory, baseline, sha(paths['loaded-model-state.json']), policy, runtime['device_argument'])
        modes[plan['id']] = mode
        if anchor is None: anchor = mode['rng_before']
        require(canonical(mode['rng_before']) == canonical(anchor), 'mode resets did not restore identical observed generator states')
    require(set(files) == required and len(files) == (621 if outer['backend'] == 'GPU' else 622), 'exact I04 four-mode/six-observation product inventory differs')
    summary = load(paths['capture-summary.json'])
    fixed = {'schema_version': 1, 'task': TASK, 'stage_spec_sha256': STAGE_SHA, 'native_forward_calls_total': 4, 'model_loads': 1,
        'modes': [modes[mode]['summary'] for mode in MODES], 'target_scores': 762, 'distribution_rows': 282,
        'physical_raw_rows': 896, 'valid_raw_rows': 768, 'pad_only_raw_rows': 128, 'acceptance': None}
    require(all(key in summary and canonical(summary[key]) == canonical(value) for key, value in fixed.items()), 'aggregate I04 coverage/model summary differs')
    status_path = endpoint.get(child(output, 'status.json')); status = load(status_path)
    fixed = {'schema_version': 1, 'status': 'completed', 'rank': 0, 'task': TASK, 'backend': outer['backend'].lower(),
        'stage_spec_sha256': STAGE_SHA, 'artifacts_manifest_sha256': sha(manifest_path), 'modes': MODES,
        'native_forward_calls_total': 4, 'model_loads': 1, 'acceptance': None, 'full_core_complete': False}
    require(all(key in status and canonical(status[key]) == canonical(value) for key, value in fixed.items()), 'terminal manifest/call/model binding differs')
    return {'inventory': inventory, 'manifest': manifest, 'manifest_sha256': sha(manifest_path), 'runtime': runtime, 'paths': paths,
        'modes': modes, 'status_path': str(status_path), 'loaded_model_state_sha256': sha(paths['loaded-model-state.json']),
        'capture_product_bytes': total, 'cpu_proof_checked': cpu_checked, 'configured_layer_types': types}

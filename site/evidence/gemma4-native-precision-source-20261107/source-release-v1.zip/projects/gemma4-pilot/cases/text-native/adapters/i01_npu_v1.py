"""One bounded native Ascend I01 cache-off anchor on the original ordinal/UUID.

The outer new-claim launcher must verify no conflicting process before loading;
this entry never spawns, stops or kills another process.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import json
import os
import sys

import i01_common_v1 as common
from pilot_ascend_candidate_v3 import (check_allocation, check_stack, check_version,
    normalize_runtime_uuid, observe_driver_version, get_policy, set_policy)


def main():
    args = common.arguments('npu')
    stage, inventory, refs = common.prepare(args, 'npu', __file__)
    sys.path.insert(0, str(common.HERE.parent / 'transfer'))
    from npu_three_repeat_launcher_v4 import binding, memory_observation
    allocation, physical = binding(args.allocation_receipt, args.native_mapping, args.native_source)
    check_allocation(allocation, 0)
    common.require(physical == common.ORIGINAL_NPU_UUID, 'I01 must use the original cached NPU UUID')
    memory = memory_observation()
    common.require(memory['effective_available_bytes'] >= stage['limits']['minimum_npu_host_effective_available_bytes'],
                   'effective host/cgroup free memory is below 80GiB')
    with common.bounded_native(stage, 'npu'):
        import torch
        import torch_npu
        import transformers
        import numpy
        from transformers import AutoModelForMultimodalLM
        npu = torch_npu.npu
        driver, provenance = observe_driver_version(torch_npu.utils.get_cann_version, args.driver_source)
        versions = {'torch': str(torch.__version__), 'torch_npu': str(torch_npu.__version__),
            'transformers': str(transformers.__version__), 'numpy': str(numpy.__version__),
            'cann': check_version('CANN', torch_npu.utils.get_cann_version('CANN')), 'driver': driver}
        check_stack(versions)
        common.require(versions == {'torch': '2.9.0+cpu', 'torch_npu': '2.9.0.post2',
            'transformers': '5.10.1', 'numpy': '1.26.4', 'cann': '9.1.0', 'driver': '25.5.2'}, 'actual NPU stack differs from frozen cached environment')
        common.require(npu.is_available() and npu.device_count() == 8, 'eight-device shared NPU instance is unavailable')
        npu.set_device(0)
        common.require(npu.current_device() == 0 and npu.is_bf16_supported(), 'native ordinal/BF16 differs')
        actual = normalize_runtime_uuid(getattr(npu.get_device_properties(0), 'uuid', None))
        free, total = map(int, npu.mem_get_info(0))
        common.require(actual == physical and free >= stage['limits']['minimum_free_device_bytes'], 'UUID differs or selected device has less than 35GiB free')
        before, policy = set_policy(torch, npu, numpy)
        common.check_refs(refs)
        args.output.mkdir()
        with (args.output / 'expected-inventory.json').open('xb') as stream:
            stream.write(args.expected_inventory.read_bytes())
        common.put(args.output / 'driver-version-provenance.json', provenance)
        common.put(args.output / 'policy-before-load.json', {'before': before, 'configured': policy})
        model, identity = common.load_verified_model(args, torch, AutoModelForMultimodalLM,
            common.read(common.HERE / 'upstream-identity.json'))
        after_load = get_policy(torch, npu)
        common.require(after_load == policy, 'NPU math policy changed during model loading')
        common.put(args.output / 'policy-after-load.json', after_load)
        summary = common.capture(model, torch, args.device, inventory, args.output)
        npu.synchronize(0)
        after_capture = get_policy(torch, npu)
        common.require(after_capture == policy, 'NPU math policy changed during capture')
        common.put(args.output / 'policy-after-capture.json', after_capture)
        runtime = {'backend': 'npu', 'model_identity': identity, 'versions': versions,
            'device_argument': args.device, 'device_name': npu.get_device_name(0), 'runtime_uuid': actual,
            'instance_visible_count': 8, 'compute_device_count': 1,
            'free_bytes_before_load': free, 'total_bytes': total, 'host_memory': memory,
            'allocation_receipt_sha256': common.sha(args.allocation_receipt),
            'native_mapping_sha256': common.sha(args.native_mapping), 'native_source_sha256': common.sha(args.native_source),
            'driver_version_provenance': provenance,
            'driver_version_provenance_sha256': common.sha(args.output / 'driver-version-provenance.json'),
            'math_policy': policy, 'seed': 0, 'native_capture': summary,
            'visible_device_env': {key: os.environ.get(key) for key in ('ASCEND_RT_VISIBLE_DEVICES', 'ASCEND_VISIBLE_DEVICES')},
            'python': sys.version, 'python_executable': sys.executable,
            'package_sources': {'torch': common.file_ref(torch.__file__), 'torch_npu': common.file_ref(torch_npu.__file__),
                'transformers': common.file_ref(transformers.__file__), 'numpy': common.file_ref(numpy.__file__)}}
        result = common.finalize(args, 'npu', inventory, refs, runtime)
        print(json.dumps(result, allow_nan=False), flush=True)


if __name__ == '__main__':
    main()

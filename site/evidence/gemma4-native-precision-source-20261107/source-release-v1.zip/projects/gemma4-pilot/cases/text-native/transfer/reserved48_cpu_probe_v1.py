"""Finite actual Torch2.9 CPU slab/BF16 prerequisite, never a model run.

Validate the exact source/inventory first, run all23 frozen tests without skips,
then retain a tiny real BF16 roundtrip across the32-row slab boundary. Import
state is distinct from device-context state; only initialization getters are
called, never availability/device queries. Production activation stays None.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import signal
import struct
import sys
import time
import traceback
import unittest
from unittest.mock import patch

CASE = 'projects/gemma4-pilot/cases/text-native'
OPS = CASE + '/transfer/reserved48_cpu_operations_v1.py'
TEST_NAMES = ('test_reserved48_common_v1', 'test_reserved48_expected_v1', 'test_reserved48_native_v1')


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ref(path):
    path = Path(path); require(path.is_file() and not path.is_symlink(), 'regular original CPU source required')
    return {'path': str(path.resolve()), 'sha256': sha(path), 'size_bytes': path.stat().st_size}


def flags(torch, phase):
    namespace = getattr(torch, 'npu', None)
    record = {'phase': phase, 'torch_npu_imported': 'torch_npu' in sys.modules,
        'npu_namespace_registered': namespace is not None,
        'npu_initialized': None if namespace is None else bool(namespace.is_initialized()),
        'cuda_initialized': bool(torch.cuda.is_initialized())}
    require(record['npu_initialized'] is (False if namespace is not None else None) and record['cuda_initialized'] is False,
            'CPU prerequisite observed initialized accelerator context')
    return record


def actual_roundtrip(common, torch, np, save_file, load_file, output):
    checks = []
    def check(ok, name): require(bool(ok), name); checks.append(name)
    tensor = ((torch.arange(65 * 7, dtype=torch.float32, device='cpu') % 19) - 9).reshape(1, 65, 7).to(torch.bfloat16)
    tensor[0, 0, 0] = -0.0
    original = tensor.view(torch.uint16).numpy().copy()
    check(int(original[0, 0, 0]) == 0x8000, 'negative-zero BF16 payload preserved before copy')
    row = {'L': 65, 'sample': 'actual-synthetic-CPU-not-Gemma', 'sequence': [i % 7 for i in range(65)],
           'positions': [0, 31, 32, 63]}
    from inference_capture import derive_logprobs
    selected, targets, digests, shapes = {}, [], [], []
    digest = hashlib.sha256()
    def shared(values, dtype): shapes.append(list(values.shape)); return derive_logprobs(values, dtype=dtype)
    with patch.object(common, 'VOCABULARY', 7):
        common.stream_logits(tensor, 0, row, torch, np, shared, selected, targets, digests, digest)
    check(shapes == [[32, 7], [32, 7]], 'actual Torch CPU three slabs and two32-row scored matrices')
    check(len(digests) == 65 and len(targets) == 64, 'all65 native rows including last unscored row consumed')
    check(digest.hexdigest() == hashlib.sha256(original.astype('<u2').tobytes()).hexdigest(), 'actual native stream uint16LE hash exact')
    tensor.fill_(10)
    check(all(np.array_equal(value.view(torch.uint16).numpy(), original[0, position]) for position, value in selected.items()),
          'selected clones unaffected by original buffer mutation')
    retained = torch.stack([selected[p] for p in row['positions']], dim=0).contiguous()
    path = output / 'tiny-selected-native-logits.safetensors'
    save_file({'logits': retained}, str(path), metadata={'task': 'reserved48-actual-tiny-CPU-prerequisite', 'scope': 'synthetic4x7 only'})
    loaded = load_file(str(path), device='cpu')['logits']
    expected = np.stack([original[0, p] for p in row['positions']])
    check(list(loaded.shape) == [4, 7] and loaded.dtype == torch.bfloat16 and
          np.array_equal(loaded.view(torch.uint16).numpy(), expected), 'actual safetensors readback shape/dtype/everyBF16bit exact')
    with path.open('rb') as stream:
        size = struct.unpack('<Q', stream.read(8))[0]; require(0 < size <= 131072, 'tiny safetensors header cap')
        header = json.loads(stream.read(size)); payload = stream.read()
    check(header['logits'] == {'dtype': 'BF16', 'shape': [4, 7], 'data_offsets': [0, 56]} and
          payload == expected.astype('<u2').tobytes(), 'actual safetensors raw payload bytes equal selected original BF16')
    for index, score in enumerate(targets):
        values = (original[0, index].astype('<u4') << 16).view('<f4').astype(np.float64)
        maximum = float(max(values)); scalar_lse = maximum + math.log(math.fsum(math.exp(float(v) - maximum) for v in values))
        require(abs(score['source_logsumexp'] - scalar_lse) <= 1e-12 and
                abs(score['logprob'] - (float(values[row['sequence'][index + 1]]) - scalar_lse)) <= 1e-12,
                'independent tiny scalar check disagrees with shared matrix normalization')
    check(True, 'all64 tiny source scalars independently agree with stdlib logsumexp')
    return {'checks': checks, 'checks_passed': len(checks), 'native_rows': 65, 'target_scores': 64,
        'selected_rows': 4, 'vocabulary': 7, 'full_vocabulary_production_geometry_claim': False,
        'artifact': ref(path), 'raw_stream_sha256': digest.hexdigest(), 'selected_payload_sha256': hashlib.sha256(payload).hexdigest(),
        'native_model_loads': 0, 'native_model_forward_calls': 0}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('source-root', 'expected-inventory', 'output'): p.add_argument('--' + name, type=Path, required=True)
    for name in ('operations-sha256', 'manifest-sha256', 'expected-inventory-sha256'): p.add_argument('--' + name, required=True)
    args = p.parse_args(); started = time.monotonic()
    require(sys.platform.startswith('linux') and not any(k in sys.modules for k in ('torch', 'torch_npu', 'numpy', 'transformers')),
            'fresh POSIX CPU prerequisite process required')
    source = args.source_root.resolve(strict=True); operations = source / OPS
    require(ref(operations)['sha256'] == args.operations_sha256, 'exact reviewed CPU operations source differs')
    spec = importlib.util.spec_from_file_location('_reserved48_actual_cpu_operations', operations)
    ops = importlib.util.module_from_spec(spec); spec.loader.exec_module(ops)
    ops.verify_tree(source, source.parent / 'source-manifest.json', args.manifest_sha256)
    doc, raw = ops.independent_inventory(source)
    require(sha(args.expected_inventory) == args.expected_inventory_sha256 and
            args.expected_inventory.read_bytes() == raw, 'pre-run independent inventory bytes differ')
    require(args.output.parent.is_dir() and not args.output.exists() and not args.output.is_symlink(), 'exclusive tiny CPU output required')
    args.output.mkdir(mode=0o700); os.environ['TORCH_DEVICE_BACKEND_AUTOLOAD'] = '0'
    state = {'schema_version': 1, 'task': 'reserved48-actual-tiny-cpu-prerequisite-v1', 'status': 'running',
        'started_utc': datetime.now(timezone.utc).isoformat(), 'timeout_seconds': 90, 'source': ref(__file__),
        'operations_source': ref(operations), 'source_manifest_sha256': args.manifest_sha256,
        'independent_inventory': ref(args.expected_inventory), 'production_model_loads': 0,
        'native_model_forward_calls': 0, 'agent_accelerator_initialization_requests': 0,
        'agent_hardware_or_availability_queries': 0, 'library_internal_availability_queries': 'not instrumented',
        'device_initialization_checks': 'getter_only', 'production_activation_gates': 'all None', 'acceptance': None}
    def expire(*_): raise TimeoutError('actual reserved48 CPU prerequisite90s')
    old = signal.signal(signal.SIGALRM, expire); signal.setitimer(signal.ITIMER_REAL, max(.01, 90 - (time.monotonic() - started)))
    try:
        import torch
        phases = [flags(torch, 'after_torch')]
        import numpy as np
        import safetensors
        import safetensors.torch as serialization
        require(str(torch.__version__) == '2.9.0+cpu' and torch.version.cuda is None and np.__version__ == '1.26.4',
                'exact actual Torch2.9.0+cpu/NumPy1.26.4 required')
        phases.append(flags(torch, 'after_runtime_imports'))
        adapters = source / (CASE + '/adapters'); sys.path.insert(0, str(adapters))
        sys.path.insert(0, str(source / 'skills/precision-compare/scripts'))
        import reserved48_common_v1 as common
        require(all(value is None for value in common.GATES.values()), 'CPU proof must not activate production gates')
        suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in TEST_NAMES)
        phases.append(flags(torch, 'before_tests'))
        transcript = io.StringIO(); result = unittest.TextTestRunner(stream=transcript, verbosity=2).run(suite)
        test_path = args.output / 'tests.stderr'
        with test_path.open('x', encoding='utf-8', newline='\n') as stream: stream.write(transcript.getvalue())
        require(result.testsRun == 23 and result.wasSuccessful() and not result.skipped and not result.expectedFailures and
                not result.unexpectedSuccesses, 'all23 actual reserved48 tests including Torch BF16 fixture must pass with zero skips')
        phases.append(flags(torch, 'after_tests'))
        actual = actual_roundtrip(common, torch, np, serialization.save_file, serialization.load_file, args.output)
        phases.append(flags(torch, 'after_tiny_roundtrip'))
        import torch._tensor as tensor_implementation
        import inference_capture, artifact_io, conditions
        state.update(status='completed', returncode=0, versions={'torch': str(torch.__version__), 'numpy': np.__version__,
            'safetensors': safetensors.__version__}, phase_observations=phases,
            tests={'run': result.testsRun, 'skipped': len(result.skipped), 'failures': len(result.failures), 'errors': len(result.errors),
                   'modules': list(TEST_NAMES), 'transcript': ref(test_path), 'real_torch_BF16_fixture_enabled': True},
            actual_tiny_roundtrip=actual, runtime_sources={name: ref(module.__file__) for name, module in {
                'torch': torch, 'numpy': np, 'safetensors': safetensors, 'safetensors_torch': serialization,
                'torch_tensor': tensor_implementation, 'inference_capture': inference_capture,
                'artifact_io': artifact_io, 'conditions': conditions}.items()})
        ops.verify_tree(source, source.parent / 'source-manifest.json', args.manifest_sha256, allow_cpu_runtime=True)
        require(all(value is None for value in common.GATES.values()), 'production gates changed during CPU validation')
    except BaseException as exc:
        state.update(status='failed', returncode=2, error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0); signal.signal(signal.SIGALRM, old)
        state.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started)
        ops.put(args.output / 'receipt.json', state)
    print(json.dumps({'status': state['status'], 'returncode': state['returncode'], 'receipt': ref(args.output / 'receipt.json'),
        'tests_run': state.get('tests', {}).get('run'), 'skips': state.get('tests', {}).get('skipped'), 'error': state.get('error')}, indent=2), flush=True)
    return state['returncode']


if __name__ == '__main__': raise SystemExit(main())

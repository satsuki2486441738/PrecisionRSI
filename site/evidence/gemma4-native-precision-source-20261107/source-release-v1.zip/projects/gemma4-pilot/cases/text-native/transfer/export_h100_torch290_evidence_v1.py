"""Export original small evidence from three completed H100 Torch2.9 captures.

Default: rehash all 96 retained NPY rows but leave their bytes at source. This
checks file integrity and metadata coverage, not distribution values, numerical
accuracy, loaded checkpoint bytes, scheduler ownership or cross-backend admission.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tarfile
import uuid

TASK=Path('/srv/precision-task')
INPUT_SHA='643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
COLLECTOR_SHA='5a73efe31962788baa04fa21abb1079be8a47e43393c23f3fa483e71c64b4f53'
METADATA_SHA='80dc0e0e59e5c526426b566d36a21f762a79d498986d5d6cd01098c8cb5decc3'
REVISION='1a2c7729392586f5ecddae8807ee2ef741eabb9a'
POLICY_SHA='5ef32354ed453d27c5751248b66859e433d9230a7fbf620851f6d5ec6da92516'
WRAPPER_SHA='5b8aecafd569999aebe5c369edacd9f054980bee3f75748a85189cae7690a06e'
ENV_ARCHIVE_SHA='e29d65534fb7d5ef38e5a71a08dc149f4cb7f3252e44835520c6ce357100d574'
FROZEN_POLICY={'deterministic_algorithms':False,'deterministic_warn_only':False,'cudnn_deterministic':False,
    'cudnn_benchmark':False,'cuda_matmul_allow_tf32':False,'cudnn_allow_tf32':True,'float32_matmul_precision':'highest',
    'cublas_workspace_config':None,'pythonhashseed':'0'}
HEX64=re.compile(r'^[a-f0-9]{64}$')
NORMALIZATION='Offline NumPy float64 log_softmax of copied native values'
MAX_SMALL=4*1024*1024

def require(ok,message):
    if not ok:raise ValueError(message)
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def parse(text):
    def pairs(items):
        result={}
        for key,value in items:
            require(key not in result,'duplicate JSON key'); result[key]=value
        return result
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    value=json.loads(text,object_pairs_hook=pairs,parse_constant=reject)
    canonical(value); return value
def load(path):return parse(Path(path).read_text(encoding='utf-8'))
def put(path,value):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False); f.write('\n')
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()
def digest(value):return isinstance(value,str) and HEX64.fullmatch(value)
def utc(value):
    require(isinstance(value,str),'UTC timestamp required')
    parsed=datetime.fromisoformat(value.replace('Z','+00:00'))
    require(parsed.tzinfo is not None and parsed.utcoffset().total_seconds()==0,'UTC offset required')
    return parsed.astimezone(timezone.utc)
def original(value):
    require(isinstance(value,str) and PurePosixPath(value).is_absolute() and '..' not in PurePosixPath(value).parts,
        'original absolute POSIX path required')
    return str(PurePosixPath(value))
def argument(argv,flag):
    require(isinstance(argv,list) and all(isinstance(x,str) and x for x in argv),'invalid actual argv')
    require(argv.count(flag)==1 and not any(x.startswith(flag+'=') for x in argv),'ambiguous argv '+flag)
    index=argv.index(flag); require(index+1<len(argv),'missing argv value'); return argv[index+1]

class Inventory:
    def __init__(self,task):self.task=Path(task).resolve(strict=True); self.files={}
    def add(self,value,expected=None,array=False):
        name=original(str(value)); path=Path(name)
        require(path.resolve(strict=True)==path and path.is_file() and path.is_relative_to(self.task),
            'source must be a nonsymlink regular file inside the actual task root')
        require(array==bool(path.suffix=='.npy'),'array classification differs')
        require(path.suffix not in ('.safetensors','.bin','.whl','.tar','.gz','.zip'), 'model/environment/archive export refused')
        require(array or path.stat().st_size<=MAX_SMALL,'small evidence limit exceeded')
        if name not in self.files:self.files[name]={'sha256':sha(path),'size':path.stat().st_size,'array':array}
        item=self.files[name]
        require(expected is None or digest(expected) and expected==item['sha256'],'original file SHA differs: '+name)
        return path
    def json(self,value,expected=None):return load(self.add(value,expected))

def marker_runs(marker,startup):
    rows=[]
    for line in Path(marker).read_text(encoding='utf-8').splitlines():
        require(bool(line.strip()),'empty marker event'); row=parse(line)
        require(isinstance(row,dict),'marker event must be an object'); rows.append(row)
    expected=['reserved','repeat_started','repeat_exited','repeat_started','repeat_exited','repeat_started','repeat_exited','completed']
    require([r.get('event') for r in rows]==expected,'three complete serial marker events required')
    require(rows[0].get('repeats')==3 and rows[0].get('input_sha256')==INPUT_SHA,'marker plan or input differs')
    runs=[]
    for rank in (1,2,3):
        began,ended=rows[2*rank-1:2*rank+1]
        require(type(began.get('rank')) is int and began['rank']==rank and type(ended.get('rank')) is int and ended['rank']==rank,
            'marker rank inventory differs')
        require(ended.get('status')=='completed' and type(ended.get('returncode')) is int and ended['returncode']==0,
            'marker did not observe successful capture')
        receipt=original(ended['receipt']); directory=original(began['receipt'])
        require(receipt==str(PurePosixPath(directory)/'receipt.json'),'started/exited recorder paths differ')
        require(utc(began['utc'])<=utc(ended['utc']),'marker event interval is invalid')
        runs.append({'rank':rank,'output':original(began['output']),'recorder':directory,'receipt':receipt})
    require(len({r['output'] for r in runs})==len({r['recorder'] for r in runs})==3,'distinct actual captures required')
    require(canonical(rows[-1].get('results'))==canonical([{k:r[k] for k in ('rank','status','returncode','receipt')}
        for r in [rows[2],rows[4],rows[6]]]),'terminal marker results differ')
    require(Path(marker).parent==Path(startup),'marker belongs to another startup')
    return runs

def snapshot(receipt,metadata):
    require(receipt.get('status')=='verified' and receipt.get('repository')=='google/gemma-4-12B' and
        receipt.get('revision')==REVISION and receipt.get('upstream_metadata_sha256')==METADATA_SHA,'snapshot identity differs')
    expected={x['rfilename']:x for x in metadata['files']}; rows=receipt.get('files',[]); actual={x.get('file'):x for x in rows}
    require(len(expected)==len(actual)==len(rows)==8 and set(expected)==set(actual),'model snapshot eight-file coverage differs')
    result={}
    for name,item in expected.items():
        observed=actual[name]; wanted=item['lfs']['sha256'] if 'lfs' in item else item['blobId']
        require(observed.get('verified') is True and observed.get('actual_size')==item['size'] and
            observed.get('actual_expected_algorithm_digest')==wanted and digest(observed.get('actual_sha256')),
            'snapshot file digest differs')
        if 'lfs' in item:require(observed['actual_sha256']==wanted,'snapshot LFS SHA differs')
        result[name]=observed['actual_sha256']
    return result

def check_run(run,inventory,input_doc,allocation,startup):
    out=Path(run['output']); receipt=inventory.json(run['receipt'])
    require(receipt.get('schema_version')==2 and receipt.get('backend')=='GPU' and receipt.get('status')=='completed' and
        type(receipt.get('returncode')) is int and receipt['returncode']==0,'successful real GPU recorder-v2 required')
    require(receipt.get('capture_output')==str(out) and receipt.get('collector_sha256')==COLLECTOR_SHA and
        receipt.get('input_sha256')==INPUT_SHA,'capture output, collector or input differs')
    argv=receipt['argv']; index=2 if argv[1]=='-B' else 1
    require(argv[index]==receipt['collector_path'] and argument(argv,'--input')==receipt['input_path'] and
        argument(argv,'--output')==str(out) and argument(argv,'--device')=='cuda:0','executed collector argv differs')
    dependencies=receipt['dependency_paths']; sources=receipt['source_sha256']
    require(isinstance(dependencies,list) and len(set(dependencies))==len(dependencies) and
        len({Path(x).name for x in dependencies})==len(dependencies) and
        set(sources)=={receipt['collector_path'],receipt['input_path'],*dependencies},'frozen execution source coverage differs')
    require(sources[receipt['collector_path']]==COLLECTOR_SHA and sources[receipt['input_path']]==INPUT_SHA,'source identity disagrees')
    for path,value in sources.items():require(digest(value),'invalid frozen source digest'); inventory.add(path,value)
    require({'inference_capture.py','artifact_io.py','compare_distributions.py','conditions.py','verify_snapshot.py',
        'pilot_gpu_peer_v2.py','upstream-identity.json'}<={Path(x).name for x in dependencies},'collector dependency closure missing')
    require(inventory.json(receipt['input_path'],INPUT_SHA)==input_doc,'repeat input bytes differ')
    require(argument(argv,'--allocation-receipt')==str(startup/'allocation.json') and
        argument(argv,'--allocation-receipt') in dependencies,'allocation was not frozen')
    require(argument(argv,'--numerics-policy') in dependencies and sources[argument(argv,'--numerics-policy')]==POLICY_SHA,
        'numerical policy source differs')
    frozen_policy=inventory.json(argument(argv,'--numerics-policy'),POLICY_SHA)
    require(canonical(frozen_policy)==canonical(FROZEN_POLICY),'frozen numerical policy values differ')
    wrappers=[x for x in dependencies if Path(x).name=='launch_h100_torch290_repeat_v1-20261106.py']
    require(len(wrappers)==1,'reviewed startup wrapper was not frozen'); inventory.add(wrappers[0],WRAPPER_SHA)
    for name in ('platform-allocation-source.json','native-preflight.stdout','environment-restore.json','bootstrap-receipt.json'):
        require(str(startup/name) in dependencies,'startup evidence was not frozen: '+name)
    require(digest(receipt.get('status_sha256')),'completion hash missing')
    status=inventory.json(out/'status.json',receipt['status_sha256'])
    require(status.get('status')=='completed' and type(status.get('rank')) is int and status['rank']==0,'rank completion differs')
    evidence=receipt.get('native_evidence_sha256',{})
    native={}
    for name in ('runtime.json','math-policy-after-load.json','math-policy-after.json'):
        require(digest(evidence.get(name)),'native hash missing'); native[name]=inventory.json(out/name,evidence[name])
    runtime=native['runtime.json']
    fixed={'torch':'2.9.0+cu128','transformers':'5.10.1','cuda_runtime':'12.8','numpy':'1.26.4',
        'model_repository':'google/gemma-4-12B','requested_revision':REVISION,'model_type':'gemma4_unified',
        'model_class':'Gemma4UnifiedForConditionalGeneration','input_sha256':INPUT_SHA,'device_argument':'cuda:0',
        'device_name':'NVIDIA H100 80GB HBM3','parameter_dtypes':['torch.bfloat16'],'actual_attention':'eager',
        'logprob_dtype':'float64','numerics_policy_sha256':POLICY_SHA}
    require(all(canonical(runtime.get(k))==canonical(v) for k,v in fixed.items()),'actual runtime conditions differ')
    require(runtime.get('device_uuid')==allocation['physical_device_id'] and
        runtime.get('allocation_receipt_sha256')==sha(startup/'allocation.json'),'native UUID/allocation differs')
    require(canonical(native['math-policy-after-load.json'])==canonical(native['math-policy-after.json'])==canonical(frozen_policy),
        'actual numerical policy differs from frozen policy')
    rng=runtime.get('rng_and_math_policy',{})
    require(all(type(rng.get(k)) is int and rng[k]==0 for k in
        ('seed','python_random_seed','numpy_seed','torch_initial_seed','cuda_initial_seed')) and
        canonical(rng.get('settings'))==canonical(frozen_policy),'runtime RNG seed or policy differs')
    require(digest(runtime.get('identity_receipt_sha256')),'snapshot receipt hash missing')
    model_receipt=inventory.json(out/'snapshot-verification.json',runtime['identity_receipt_sha256'])
    metadata=next(x for x in dependencies if Path(x).name=='upstream-identity.json')
    model=snapshot(model_receipt,inventory.json(metadata,METADATA_SHA))
    summary=inventory.json(out/'capture-summary.json'); events=inventory.json(out/'events.json'); exported=inventory.json(out/'exported-records.json')
    prompt=input_doc['prompt']; targets=input_doc['continuation']; sample=input_doc['sample']; shapes=summary['native_logits_shapes']
    require(isinstance(shapes,list) and len(shapes)==32 and len(shapes[0])==3,'logit shape inventory differs')
    vocab=shapes[0][2]
    require(type(vocab) is int and vocab>=100 and shapes==[[1,128,vocab]]+[[1,1,vocab]]*31,'native logit shapes differ')
    require(summary.get('sampled_distributions')==32 and not summary.get('unavailable_targets') and
        not exported.get('unavailable_targets') and len(events)==len(exported.get('positions',[]))==len(exported.get('scores',[]))==32,
        'capture coordinate inventory is incomplete')
    require(len(receipt.get('row_sha256',[]))==len(receipt.get('record_sha256',[]))==32,'recorder row hash inventory differs')
    require(all(digest(x) for x in receipt['row_sha256']+receipt['record_sha256']),'invalid record/row hash inventory')
    for suffix in ('.json','.npy'):
        require(set(out.glob('row-*'+suffix))=={out/('row-%03d%s'%(i,suffix)) for i in range(32)},'extra or missing raw rows')
    for step,token in enumerate(targets):
        record=inventory.json(out/('row-%03d.json'%step),receipt['record_sha256'][step])
        expected={'sample':sample,'step':step,'position':127+step,'history':prompt+targets[:step],'token':token,'rank':0,
            'boundary':'before_constraint','logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':NORMALIZATION,
            'scores':{'path':'row-%03d.npy'%step,'row':0}}
        require(all(canonical(record.get(k))==canonical(v) for k,v in expected.items()),'raw target/coordinate/history differs')
        expected_event={'stage':'prefill' if step==0 else 'decode','input_ids':prompt if step==0 else [targets[step-1]],
            'positions':list(range(128)) if step==0 else [127+step],'prefix_length':0 if step==0 else 127+step}
        require(canonical(events[step])==canonical(expected_event),'actual prefill/decode event differs')
        position=exported['positions'][step]; target=exported['scores'][step]
        require(all(canonical(position.get(k))==canonical(record[k]) for k in ('sample','position','history')) and
            position.get('scores')=={'path':str(out/('row-%03d.npy'%step)),'row':0},'exported distribution mapping differs')
        require(all(canonical(target.get(k))==canonical(v) for k,v in {'sample':sample,'position':128+step,'token':token}.items()),
            'exported target coordinate differs')
        value=record.get('logprob')
        require(type(value) in (int,float) and math.isfinite(value) and value<=0 and
            type(target.get('logprob')) in (int,float) and target['logprob']==value,'recorded target score differs')
        require(digest(receipt['row_sha256'][step]),'invalid row hash'); inventory.add(out/('row-%03d.npy'%step),receipt['row_sha256'][step],True)
    for name in ('stdout.log','stderr.log'):
        path=Path(run['recorder'])/name
        if path.is_file():inventory.add(path)
    return {'rank':run['rank'],'output':str(out),'receipt':run['receipt'],'receipt_sha256':sha(run['receipt']),
        'started_utc':receipt['started_utc'],'finished_utc':receipt['finished_utc'],
        'signature':{'model_files':model,'runtime':fixed,'uuid':runtime['device_uuid'],'policy':native['math-policy-after.json'],'vocab':vocab},
        'row_count':32,'array_bytes_rehashed':sum(inventory.files[str(out/('row-%03d.npy'%i))]['size'] for i in range(32))}

def export(startup,output,archive,task=TASK,include_arrays=False):
    require(os.name=='posix','native export requires original Linux paths')
    task=Path(task).resolve(strict=True); startup=Path(original(str(startup))); output=Path(output).resolve(); archive=Path(archive).resolve()
    require(startup.is_relative_to(task/'attempts') and not output.exists() and output.parent.is_dir() and
        not archive.exists() and archive.parent.is_dir() and not archive.is_relative_to(output),'new outputs and actual startup root required')
    inventory=Inventory(task)
    capture=inventory.json(startup/'capture-receipt.json')
    require(capture.get('status')=='completed' and type(capture.get('returncode')) is int and capture['returncode']==0,
        'completed startup capture receipt required')
    marker=Path(capture['marker']); inventory.add(marker)
    runs=marker_runs(marker,startup)
    allocation=inventory.json(startup/'allocation.json'); native=inventory.json(startup/'native-preflight.stdout')
    require(allocation.get('vendor')=='NVIDIA' and type(allocation.get('visible_count')) is int and allocation['visible_count']==1 and
        type(allocation.get('logical_ordinal')) is int and allocation['logical_ordinal']==0,'actual one-GPU allocation required')
    physical=allocation['physical_device_id']; require(str(uuid.UUID(physical))==physical and uuid.UUID(physical).int,'nonzero canonical UUID required')
    require(native.get('status')=='native_preflight_passed' and native.get('runtime_uuid')==physical,'native UUID source differs')
    require(digest(allocation.get('platform_source_sha256')) and digest(allocation.get('native_source_sha256')),
        'allocation source hashes missing')
    require(capture.get('allocation_sha256')==sha(startup/'allocation.json'),'startup allocation hash differs')
    source=inventory.add(startup/'platform-allocation-source.json',allocation.get('platform_source_sha256'))
    platform=load(source)
    require(platform.get('allocation_id')==allocation.get('allocation_id') and type(native.get('visible_count')) is int and native['visible_count']==1 and
        allocation.get('native_source')==str(startup/'native-preflight.stdout') and
        allocation.get('native_source_sha256')==sha(startup/'native-preflight.stdout'),'platform/native allocation source mapping differs')
    bootstrap=inventory.json(startup/'bootstrap-receipt.json'); restore=inventory.json(startup/'environment-restore.json')
    start=inventory.json(startup/'start.json')
    require(bootstrap.get('status')=='native_preflight_passed' and bootstrap.get('allocation_source_sha256')==sha(source),
        'successful native bootstrap or platform source binding differs')
    require(bootstrap.get('source_sha256')==start.get('source_sha256')==WRAPPER_SHA and
        bootstrap.get('environment_archive_sha256')==start.get('environment_archive_sha256')==restore.get('archive_sha256')==ENV_ARCHIVE_SHA,
        'reviewed startup source or environment archive identity differs')
    if (startup/'native-preflight.stderr').is_file():inventory.add(startup/'native-preflight.stderr')
    first=inventory.json(runs[0]['receipt']); inp=inventory.json(first['input_path'],INPUT_SHA)
    require(len(inp.get('prompt',[]))==128 and len(inp.get('continuation',[]))==32,'frozen 128+32 input required')
    checked=[check_run(run,inventory,inp,allocation,startup) for run in runs]
    require(all(canonical(x['signature'])==canonical(checked[0]['signature']) for x in checked[1:]),'repeated native conditions differ')
    require(all(utc(x['started_utc'])<utc(x['finished_utc']) for x in checked) and
        all(utc(a['finished_utc'])<=utc(b['started_utc']) for a,b in zip(checked,checked[1:])),'capture intervals overlap or order differs')
    output.mkdir(); mappings={}
    for index,(original_name,item) in enumerate(sorted(inventory.files.items())):
        path=Path(original_name); entry={'sha256':item['sha256'],'size':item['size']}
        if item['array'] and not include_arrays:entry.update(retained_at_source=True,integrity='full source bytes rehashed during export')
        else:
            relative=Path('payload')/('%05d'%index)/path.name; destination=output/relative; destination.parent.mkdir(parents=True)
            require(sha(path)==item['sha256'],'source changed before copy'); shutil.copyfile(path,destination)
            require(sha(destination)==item['sha256'] and sha(path)==item['sha256'],'source changed during evidence copy')
            entry['path']=relative.as_posix()
        mappings[original_name]=entry
    request={'startup':str(startup),'input':first['input_path'],'runs':runs,'allocation':str(startup/'allocation.json')}
    result={'schema_version':1,'status':'gpu_raw_hashes_and_metadata_checked','captures':3,'target_rows':96,
        'array_files_rehashed':96,'array_values_replayed':False,'include_arrays':include_arrays,
        'copied_files':sum('path' in x for x in mappings.values()),'copied_bytes':sum(x['size'] for x in mappings.values() if 'path' in x),
        'array_bytes_retained':sum(x['size'] for x in mappings.values() if x.get('retained_at_source')),
        'runs':[{k:x[k] for k in ('rank','output','receipt','receipt_sha256','started_utc','finished_utc','row_count','array_bytes_rehashed')} for x in checked],
        'acceptance':None,'limitations':['Raw file hash/metadata export only; no distribution-value replay or GPU/NPU admission',
            'Supplied platform and source receipts do not independently attest scheduler ownership or loader-consumed weights']}
    put(output/'source-map.json',{'schema_version':1,'request':request,'files':mappings,'scope':result['status'],
        'array_values_replayed':False,'acceptance':None})
    put(output/'export-summary.json',result)
    with tarfile.open(archive,'x:gz') as tf:
        for path in sorted(output.rglob('*')):
            if path.is_file():tf.add(path,arcname=path.relative_to(output).as_posix(),recursive=False)
    result.update(archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),source_map_sha256=sha(output/'source-map.json'))
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('startup','output-dir','archive'):parser.add_argument('--'+name,required=True,type=Path)
    parser.add_argument('--task-root',type=Path,default=TASK); parser.add_argument('--include-arrays',action='store_true')
    args=parser.parse_args()
    try:print(json.dumps(export(args.startup,args.output_dir,args.archive,args.task_root,args.include_arrays),allow_nan=False))
    except (OSError,ValueError,KeyError,TypeError,IndexError) as exc:parser.exit(2,type(exc).__name__+': '+str(exc)+'\n')
if __name__=='__main__':main()

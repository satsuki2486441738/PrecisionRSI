"""New I04 H100 app lifecycle; offline candidate, no old claim is consumed.

Only main/worker can observe native hardware or load a model. A portable actual
successful I03 numeric proof and actual CPU mask proof is required before claim, GPU query or restore.
New source pins remain unready until their independently reviewed bytes exist.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import ctypes
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import select
import shutil
import signal
import subprocess
import sys
import time
import uuid

TASK = Path('/srv/precision-task')
ROOT = TASK / 'i04-batch-padding-20261107-gpu-v2'
CASE = 'projects/gemma4-pilot/cases/text-native'
TASK_ID = 'gemma4-gpu-npu-i04-batch-padding-v1-20261107'
LIFECYCLE = 'h100_i04_lifecycle_v2.py'
ENTRY = 'launch-h100-i04-batch-padding-20261107-v2.sh'
SOURCE = 'platform-allocation-source.json'
GPU = CASE + '/adapters/i04_gpu_v1.py'
COMMON = CASE + '/adapters/i04_common_v1.py'
EXPECTED = CASE + '/adapters/i04_expected_inventory_v1.py'
PREREQUISITE = CASE + '/adapters/i04_prerequisite_v1.py'
SPEC = CASE + '/i04-stage-v1.json'
SPEC_SHA = '26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
INPUT_B = CASE + '/inputs/i04-prefix-stress-096-v1.json'
CPU_PREREQUISITE = CASE + '/adapters/i04_cpu_prerequisite_v2.py'
CPU_PROOF_SHA = None
I03_PROOF_SHA = '3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c'
OPERATIONS = 'h100_i04_operations_v2.py'
MANIFEST = 'source-manifest.json'
INPUT = CASE + '/inputs/discovery-v1/wikitext2-discovery-001.json'
POLICY = CASE + '/inputs/peer-math-policy-cu128-v1.json'
IO = CASE + '/transfer/h100_i01_lifecycle_v1.py'
RESTORE = CASE + '/transfer/launch_h100_torch290_repeat_v1.py'
CLEANUP = CASE + '/transfer/npu_three_repeat_launcher_v4.py'
RECORDER = 'skills/precision-compare/scripts/record_run.py'
IO_SHA = '34b00c57a2fb08e3ded9332a1e4dae760791d9a9b261983dd3809909d58caafc'
RESTORE_SHA = '5b8aecafd569999aebe5c369edacd9f054980bee3f75748a85189cae7690a06e'
CLEANUP_SHA = 'c1719e831a557cd9707374138d9219a8ae887854dd029a1ec165631d9259f485'
RECORD_SHA = '2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'
NEW_PINS = {CPU_PREREQUISITE: None, GPU: None, COMMON: None, EXPECTED: None, PREREQUISITE: None}
EXPECTED_JSON_SHA = '22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76'
EXPECTED_JSON_BYTES = 1082939
FIXED = {
    IO: IO_SHA, RESTORE: RESTORE_SHA, CLEANUP: CLEANUP_SHA, RECORDER: RECORD_SHA,
    SPEC: SPEC_SHA,
    INPUT_B: 'f4bca8e16d2e7768c6f9dff0677ea329ccf46ed254e211dc2ce2f9852f416792',
    CASE + '/adapters/i03_common_v1.py': '5cf67f53b5392e4425c4534ec6f97961066c190d24dc1280f31e66781a0fe03a',
    CASE + '/adapters/i03_prerequisite_v1.py': 'e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36',
    INPUT: '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0',
    POLICY: '5ef32354ed453d27c5751248b66859e433d9230a7fbf620851f6d5ec6da92516',
    CASE + '/adapters/i01_common_v1.py': 'fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c',
    CASE + '/adapters/pilot_gpu_torch290_candidate.py': '5a73efe31962788baa04fa21abb1079be8a47e43393c23f3fa483e71c64b4f53',
    CASE + '/adapters/pilot_ascend_candidate_v3.py': '95b7b9302543d8a14995e293c790d5de9e23abc6041a53bb1d627ae3b5cd7ee8',
    CASE + '/adapters/pilot_gpu_peer_v2.py': 'fbf0b1dc4b03576852d166bc56d3bca14d6544be8aebd120ef0b92f146429eae',
    CASE + '/adapters/verify_snapshot.py': 'cd64a5f3f380d9cc04578848ba508ace3f1df0752ca952b8d575dd2904196f26',
    CASE + '/adapters/upstream-identity.json': '80dc0e0e59e5c526426b566d36a21f762a79d498986d5d6cd01098c8cb5decc3',
    'skills/precision-compare/scripts/inference_capture.py': '5d388e846249d7fd74df1b15036f8a371e3267ada1b2fb0408bc51345ffad19c',
    'skills/precision-compare/scripts/artifact_io.py': '0260cd5ee1fd4e9d37e39bfd79efa9e663a1d48cb75b5adb31b84af9e1edbf39',
    'skills/precision-compare/scripts/conditions.py': 'e012c025395f2f0474f0b35074d8417ec5a217f3659f82218de0f5d05068036d',
    'skills/precision-compare/scripts/compare_distributions.py': '6abc2eb0a741d554127911de9845d16e0d40f3f7759c42c172eae4907bbf8fc0',
}
HEX = re.compile(r'^[a-f0-9]{64}$')
APP = re.compile(r'^app-[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?$')
MAX_SECONDS, CAPTURE_SECONDS, CLEANUP_SECONDS = 3000, 900, 20
METADATA_EXPORT_SECONDS = 960
WORK_SECONDS = MAX_SECONDS - METADATA_EXPORT_SECONDS - CLEANUP_SECONDS
MAX_TASK_BYTES, MAX_CAPTURE_BYTES = 4294967296, 1342177280
MIN_FREE, LOGICAL_TRANSPORT, ENCODED_TRANSPORT = 5368709120, 1207959552, 1610612736


def require(ok, message):
    if not ok:
        raise ValueError(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 ** 2), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    def pairs(values):
        result = {}
        for key, value in values:
            require(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def reject(value):
        raise ValueError('nonfinite JSON token ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs, parse_constant=reject)


def raw_put(path, raw):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())


def put(path, value):
    raw_put(path, (json.dumps(value, indent=2, allow_nan=False) + '\n').encode())


def original(path, root=None, limit=16 * 1024 ** 2):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= limit,
            'small original regular source required: ' + str(path))
    if root is not None:
        require(path.is_absolute() and Path(root).is_absolute(), 'absolute task/source paths required')
        require(path.resolve().is_relative_to(Path(root).resolve()), 'source path escapes new task')
        current = path
        while current != Path(root):
            require(not current.is_symlink(), 'source ancestor is symlink')
            current = current.parent
    return path


def load_pinned(path, digest, name):
    require(isinstance(digest, str) and HEX.fullmatch(digest) and sha(original(path)) == digest,
            'reviewed helper SHA differs or remains unready')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); sys.modules[name] = module
    spec.loader.exec_module(module)
    require(Path(module.__file__).resolve() == Path(path).resolve() and sha(path) == digest,
            'loaded helper file differs')
    return module


def validate_source(doc, root):
    fields = {'schema_version', 'task_id', 'allocation_id', 'vendor', 'visible_count', 'observed_utc',
        'evidence_source', 'entry_path', 'entry_sha256', 'lifecycle_path', 'lifecycle_sha256',
        'source_pins', 'expected_inventory_sha256', 'i03_prerequisite_path', 'i03_prerequisite_sha256',
        'cpu_prerequisite_path', 'cpu_prerequisite_sha256', 'operations_path', 'operations_sha256',
        'source_manifest_sha256'}
    require(isinstance(doc, dict) and set(doc) == fields and doc['schema_version'] == 1 and
            type(doc['schema_version']) is int and doc['task_id'] == TASK_ID, 'exact new I04 source schema required')
    require(isinstance(doc['allocation_id'], str) and APP.fullmatch(doc['allocation_id']) and
            doc['allocation_id'] not in {'REDACTED_APP_ID', 'REDACTED_APP_ID', 'REDACTED_APP_ID', 'REDACTED_APP_ID'}, 'fresh I04 app ID required')
    require(doc['vendor'] == 'NVIDIA' and type(doc['visible_count']) is int and doc['visible_count'] == 1,
            'one GPU allocation required')
    when = datetime.fromisoformat(doc['observed_utc'].replace('Z', '+00:00'))
    require(when.tzinfo is not None and when.utcoffset().total_seconds() == 0, 'source observation must be UTC')
    require(isinstance(doc['evidence_source'], str) and 0 < len(doc['evidence_source'].strip()) <= 4096,
            'authenticated actual platform source required')
    for name, relative in [('entry', ENTRY), ('lifecycle', LIFECYCLE), ('operations', OPERATIONS)]:
        require(doc[name + '_path'] == str(Path(root) / relative) and
                isinstance(doc[name + '_sha256'], str) and HEX.fullmatch(doc[name + '_sha256']),
                'new entry/lifecycle binding differs')
    pins = doc['source_pins']; expected = {**FIXED, **NEW_PINS}
    require(isinstance(pins, dict) and set(expected) == set(pins) and len(pins) <= 48,
            'source closure missing required I04 dependencies')
    for name, digest in pins.items():
        p = PurePosixPath(name)
        require(not p.is_absolute() and '\\' not in name and '..' not in p.parts and
                name == p.as_posix() and isinstance(digest, str) and HEX.fullmatch(digest), 'unsafe source pin')
    require(all(isinstance(digest, str) and HEX.fullmatch(digest) and pins[name] == digest
                for name, digest in expected.items()), 'source pins differ or I04 reviewed sources remain unready')
    for key in ('expected_inventory_sha256', 'i03_prerequisite_sha256', 'cpu_prerequisite_sha256', 'source_manifest_sha256'):
        require(isinstance(doc[key], str) and HEX.fullmatch(doc[key]), 'actual independent proof/inventory hash required')
    require(doc['expected_inventory_sha256'] == EXPECTED_JSON_SHA, 'frozen independent I04 JSON identity differs')
    require(doc['i03_prerequisite_sha256'] == I03_PROOF_SHA, 'actual reviewed I03 proof identity differs')
    require(isinstance(CPU_PROOF_SHA, str) and HEX.fullmatch(CPU_PROOF_SHA) and doc['cpu_prerequisite_sha256'] == CPU_PROOF_SHA,
            'actual CPU proof remains unready or differs')
    original(doc['i03_prerequisite_path'], root); original(doc['cpu_prerequisite_path'], root)
    return doc


def manifest_files(root, digest):
    root = Path(root); path = original(root / MANIFEST, root)
    require(sha(path) == digest, 'frozen source manifest differs')
    document = read(path)
    require(document.get('schema_version') == 1 and document.get('task_id') == TASK_ID and
            isinstance(document.get('files'), dict) and 0 < len(document['files']) <= 128,
            'new I04 manifest schema/member count differs')
    files = {str(path): digest}
    for relative, ref in document['files'].items():
        p = PurePosixPath(relative)
        require(not p.is_absolute() and p.as_posix() == relative and '\\' not in relative and
                all(part not in ('', '.', '..') for part in relative.split('/')) and
                set(ref) == {'sha256', 'size_bytes', 'kind'} and ref['kind'] in ('code', 'metadata'),
                'unsafe source manifest entry')
        target = original(root / relative, root, 1024 ** 2 if ref['kind'] == 'code' else 16 * 1024 ** 2)
        require(type(ref['size_bytes']) is int and target.stat().st_size == ref['size_bytes'] and
                isinstance(ref['sha256'], str) and HEX.fullmatch(ref['sha256']) and sha(target) == ref['sha256'],
                'frozen manifest source bytes differ: ' + relative)
        files[str(target)] = ref['sha256']
    return document, files


def source_files(doc, root):
    root = Path(root); manifest, result = manifest_files(root, doc['source_manifest_sha256'])
    pairs = [(root / ENTRY, doc['entry_sha256']), (root / LIFECYCLE, doc['lifecycle_sha256']),
             (root / OPERATIONS, doc['operations_sha256']),
             *[(root / 'source' / name, value) for name, value in doc['source_pins'].items()]]
    for path, digest in pairs:
        require(str(path) in result and result[str(path)] == digest, 'manifest/platform source closure differs')
    require(sha(original(root / 'expected-inventory.json', root)) == EXPECTED_JSON_SHA and
            (root / 'expected-inventory.json').stat().st_size == EXPECTED_JSON_BYTES,
            'frozen metadata inventory identity differs')
    return result


def portable(doc, root, prefix, helper_path, helper_sha, frozen_sha):
    path = original(doc[prefix + '_prerequisite_path'], root)
    digest = doc[prefix + '_prerequisite_sha256']
    require(isinstance(frozen_sha, str) and HEX.fullmatch(frozen_sha) and digest == frozen_sha and sha(path) == digest,
            'actual ' + prefix + ' portable proof remains unready or differs')
    helper = load_pinned(Path(root) / 'source' / helper_path, helper_sha, 'i04_pure_' + prefix + '_prerequisite')
    require(not any(x in sys.modules for x in ('torch', 'torch_npu', 'numpy')),
            'pre-claim prerequisite imported a numerical/native framework')
    verified = helper.prerequisite(path, digest); files = {str(path): digest}; aliases = {}
    def visit(value):
        if isinstance(value, dict):
            if set(value) == {'path', 'source_path', 'sha256'}:
                copied = original(path.parent / value['path'], root)
                require(sha(copied) == value['sha256'], 'copied ' + prefix + ' proof changed')
                files[str(copied)] = value['sha256']
                require(value['source_path'] not in aliases, 'proof alias source path duplicated')
                aliases[value['source_path']] = {'path': str(copied), 'sha256': value['sha256'], 'size_bytes': copied.stat().st_size}
            else:
                for child in value.values(): visit(child)
        elif isinstance(value, list):
            for child in value: visit(child)
    visit(read(path))
    require(len(files) == (9 if prefix == 'i03' else 22), 'portable proof raw-document count differs')
    return verified, files, aliases


def prerequisite(doc, root):
    return portable(doc, root, 'i03', PREREQUISITE, NEW_PINS[PREREQUISITE], I03_PROOF_SHA)


def cpu_prerequisite(doc, root):
    return portable(doc, root, 'cpu', CPU_PREREQUISITE, NEW_PINS[CPU_PREREQUISITE], CPU_PROOF_SHA)


def independent_expected(doc, root):
    stage = Path(root) / 'source'
    helper = load_pinned(stage / EXPECTED, NEW_PINS[EXPECTED], 'i04_pure_independent_coordinates')
    document = helper.derive(read(stage / INPUT), read(stage / INPUT_B), sha(stage / INPUT), sha(stage / INPUT_B), SPEC_SHA)
    helper.stage_check(stage / SPEC, SPEC_SHA, document)
    raw = (json.dumps(document, indent=2, allow_nan=False) + '\n').encode()
    require(len(raw) == EXPECTED_JSON_BYTES and hashlib.sha256(raw).hexdigest() == EXPECTED_JSON_SHA and
            doc['expected_inventory_sha256'] == EXPECTED_JSON_SHA,
            'independent four-call/two-request inventory differs before claim')
    require('torch' not in sys.modules and 'torch_npu' not in sys.modules,
            'pure expected inventory imported a native framework')
    return {'status': 'independent_i04_inventory_checked_before_claim', 'sha256': EXPECTED_JSON_SHA,
            'size_bytes': EXPECTED_JSON_BYTES, 'native_executions_started': 0}


def claim_once(root, app, state):
    parent = Path(root) / 'claims'; parent.mkdir(mode=0o700, exist_ok=True)
    directory = parent / app
    try:
        directory.mkdir(mode=0o700)
    except FileExistsError:
        return None
    put(directory / 'claim.json', state)
    return directory


def subreaper():
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), 'Linux child subreaper unavailable')


def supervise(argv, directory, root, deadline, helper):
    subreaper()
    directory = Path(directory); proc = None; code = 1
    state = {'schema_version': 1, 'task': 'I04', 'status': 'running', 'started_utc': utc(),
        'argv': argv, 'whole_attempt_seconds': MAX_SECONDS, 'cleanup_reserve_seconds': CLEANUP_SECONDS,
        'max_new_task_bytes_sampled': MAX_TASK_BYTES, 'storage_guard_is_sampled_not_reserved': True,
        'metadata_export_reserved_seconds': METADATA_EXPORT_SECONDS, 'controller_work_seconds': WORK_SECONDS}
    try:
        with (directory / 'worker.stdout').open('xb') as out, (directory / 'worker.stderr').open('xb') as err:
            proc = subprocess.Popen(argv, stdout=out, stderr=err, stdin=subprocess.DEVNULL, start_new_session=True)
            state['worker_pid'] = proc.pid; sample = 0
            while proc.poll() is None:
                now = time.monotonic()
                if now >= deadline - CLEANUP_SECONDS:
                    raise TimeoutError('I04 whole attempt deadline reached; model is not retried')
                if now >= sample:
                    require(tree_bytes(root) <= MAX_TASK_BYTES, 'sampled new task4GiB limit exceeded')
                    sample = now + 2
                try:
                    proc.wait(timeout=min(.2, max(.01, deadline - CLEANUP_SECONDS - now)))
                except subprocess.TimeoutExpired:
                    pass
            code = proc.returncode if proc.returncode >= 0 else 128 - proc.returncode
            require(code != 0 or not any(x['state'] != 'Z' for x in helper.descendants().values()),
                    'worker exited with unexpected live descendants')
            state['status'] = 'completed' if code == 0 else 'failed'
    except BaseException as exc:
        code = 124 if isinstance(exc, TimeoutError) else 1
        state.update(status='failed', error_type=type(exc).__name__, error=str(exc))
    finally:
        try:
            helper.cleanup(proc)
        except BaseException as exc:
            code = 1; state.update(status='cleanup_failed', cleanup_error=str(exc))
        state.update(finished_utc=utc(), returncode=code, timed_out=code == 124,
                     remaining_descendants=sorted(helper.descendants()))
        put(directory / 'controller-receipt.json', state)
    return code, state


def tree_bytes(root):
    size = 0
    for path in Path(root).rglob('*'):
        require(not path.is_symlink(), 'new task contains symlink')
        if path.is_file():
            size += path.stat().st_size
    return size


def capture_argv(python, stage, directory, folder, source):
    stage, directory, folder = Path(stage), Path(directory), Path(folder)
    return [str(python), '-B', str(stage / GPU), '--model', str(TASK / 'model-download/snapshot'),
        '--input', str(stage / INPUT), '--input-b', str(stage / INPUT_B),
        '--allocation-receipt', str(directory / 'allocation.json'), '--numerics-policy', str(stage / POLICY),
        '--stage-spec', str(stage / SPEC), '--stage-spec-sha256', SPEC_SHA,
        '--expected-inventory', str(directory / 'expected-inventory.json'),
        '--expected-inventory-sha256', source['expected_inventory_sha256'],
        '--i03-prerequisite', source['i03_prerequisite_path'],
        '--i03-prerequisite-sha256', source['i03_prerequisite_sha256'],
        '--device', 'cuda:0', '--output', str(folder / 'artifacts')]


def worker(directory):
    directory = Path(directory).resolve(strict=True); root = directory.parents[1]; stage = root / 'source'
    source = validate_source(read(directory / SOURCE), root); before = source_files(source, root)
    checked, proof_files, proof_aliases = prerequisite(source, root); before.update(proof_files)
    cpu_checked, cpu_files, cpu_aliases = cpu_prerequisite(source, root); before.update(cpu_files)
    io = load_pinned(stage / IO, IO_SHA, 'i04_reviewed_i01_io_only')
    restore = load_pinned(stage / RESTORE, RESTORE_SHA, 'i04_reviewed_restore_only')
    put(directory / 'prerequisite-validation.json', checked)
    put(directory / 'frozen-i03-prerequisite-map.json', proof_aliases)
    put(directory / 'cpu-prerequisite-validation.json', cpu_checked)
    put(directory / 'frozen-cpu-prerequisite-map.json', cpu_aliases)
    memory = restore.memory(); put(directory / 'memory-guard.json', memory)
    helper_sources = {memory['guard_source']: memory['guard_sha256']}
    io.freeze_sources(directory, {key: value for key, value in before.items()
                                  if Path(key).is_relative_to(root)}, root)
    bootstrap = {}
    for key, digest in helper_sources.items():
        path = original(key); require(sha(path) == digest, 'reused memory observer differs')
        copied = directory / 'frozen-bootstrap' / path.name; copied.parent.mkdir(parents=True, exist_ok=True)
        raw_put(copied, path.read_bytes()); bootstrap[key] = {'path': str(copied), 'sha256': digest, 'size_bytes': copied.stat().st_size}
    put(directory / 'frozen-bootstrap-map.json', bootstrap)
    expected_module = load_pinned(stage / EXPECTED, NEW_PINS[EXPECTED], 'i04_independent_expected')
    expected = directory / 'expected-inventory.json'
    expected_module.build(stage / INPUT, stage / INPUT_B, expected, stage / SPEC, SPEC_SHA)
    require(sha(expected) == source['expected_inventory_sha256'] == EXPECTED_JSON_SHA and
            expected.stat().st_size == EXPECTED_JSON_BYTES, 'pre-model independent I04 inventory differs')
    python = restore.restore_environment(directory)
    env = {'PYTHONHASHSEED': '0', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
        'TORCH_DEVICE_BACKEND_AUTOLOAD': '0',
        'PYTHONHOME': None, 'PYTHONPATH': None, 'CUBLAS_WORKSPACE_CONFIG': None,
        'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1', 'HF_HOME': str(root / 'cache'), 'TMPDIR': str(root / 'tmp')}
    for name in ('cache', 'tmp'):
        (root / name).mkdir(mode=0o700, exist_ok=True)
    effective = dict(os.environ)
    for key, value in env.items():
        if value is None:
            effective.pop(key, None)
        else:
            effective[key] = value
    adapters = stage / CASE / 'adapters'
    probe = subprocess.run([str(python), '-B', '-c', io.native_probe_code(), str(adapters)],
        env=effective, capture_output=True, timeout=120, check=False)
    raw_put(directory / 'native-preflight.stdout', probe.stdout); raw_put(directory / 'native-preflight.stderr', probe.stderr)
    require(probe.returncode == 0, 'new I04 H100 preflight failed; no model started')
    native = json.loads(probe.stdout); observed = read(directory / 'driver-receipt.json')
    require(sum(row['uuid'] == native['runtime_uuid'] and row['name'] == native['device_name']
                for row in observed['rows']) == 1, 'runtime GPU does not match original driver query')
    restored = Path(read(directory / 'environment-restore.json')['restored']).resolve()
    require(all(Path(p).resolve().is_relative_to(restored) for p in native['module_files'].values()),
            'probe imported packages outside restored environment')
    package_refs = {name: {'path': str(Path(path).resolve()), 'sha256': sha(path), 'size_bytes': Path(path).stat().st_size}
                    for name, path in native['module_files'].items()}
    runtime_copies = io.freeze_runtime_refs(directory, package_refs)
    put(directory / 'runtime-packages-before.json', runtime_copies)
    allocation = {'vendor': 'NVIDIA', 'visible_count': 1, 'logical_ordinal': 0,
        'allocation_id': source['allocation_id'], 'physical_device_id': native['runtime_uuid'],
        'evidence_source': str(directory / SOURCE), 'platform_source_sha256': sha(directory / SOURCE),
        'native_source': str(directory / 'native-preflight.stdout'), 'native_source_sha256': sha(directory / 'native-preflight.stdout')}
    put(directory / 'allocation.json', allocation); put(directory / 'execution-profile.json', {'env': env})
    dynamic = [directory / name for name in (SOURCE, 'native-preflight.stdout', 'native-preflight.stderr',
        'driver-receipt.json', 'driver.stdout', 'driver.stderr', 'allocation.json', 'expected-inventory.json',
        'execution-profile.json', 'environment-restore.json', 'memory-guard.json', 'runtime-packages-before.json',
        'prerequisite-validation.json', 'frozen-i03-prerequisite-map.json',
        'cpu-prerequisite-validation.json', 'frozen-cpu-prerequisite-map.json')]
    before.update(helper_sources); before.update({str(p): sha(p) for p in dynamic})
    before.update({ref['path']: ref['sha256'] for ref in package_refs.values()})
    put(directory / 'sources-before.json', before)
    recorder = load_pinned(stage / RECORDER, RECORD_SHA, 'i04_generic_record_run')
    run, command = recorder.record_run(root / 'runs', 'h100', 'i04-batch-padding', CAPTURE_SECONDS,
        lambda folder: capture_argv(python, stage, directory, folder, source),
        cwd=stage, execution=directory / 'execution-profile.json')
    generic = {'path': str(run / 'command.json'), 'sha256': sha(run / 'command.json')}
    put(directory / 'generic-receipt-reference.json', generic)
    require(command['status'] == 'completed' and command['returncode'] == 0, 'I04 native child failed')
    output = run / 'artifacts'
    check = "import json,sys;sys.path.insert(0,sys.argv[1]);from i04_common_v1 import validate_output;print(json.dumps(validate_output(sys.argv[2],sys.argv[3],sys.argv[4]),allow_nan=False))"
    result = subprocess.run([str(python), '-B', '-c', check, str(adapters), str(output), str(stage / INPUT), str(stage / INPUT_B)],
        env=effective, capture_output=True, timeout=180, check=False)
    raw_put(directory / 'validation.stdout', result.stdout); raw_put(directory / 'validation.stderr', result.stderr)
    require(result.returncode == 0 and tree_bytes(output) <= MAX_CAPTURE_BYTES, 'I04 recursive product validation/capture cap failed')
    validation = json.loads(result.stdout)
    require(validation.get('status') == 'i04_output_artifacts_checked' and
            validation.get('modes') == ['alone-A', 'alone-B', 'batch-left', 'batch-right'] and
            validation.get('native_forward_calls_total') == 4 and validation.get('model_loads') == 1 and
            validation.get('target_scores') == 762 and validation.get('distribution_rows') == 282 and
            validation.get('physical_raw_rows') == 896 and validation.get('valid_raw_rows') == 768 and
            validation.get('pad_only_raw_rows') == 128 and
            validation.get('artifacts_manifest_sha256') == sha(output / 'artifacts-manifest.json'),
            'I04 validator returned another task or incomplete mode inventory')
    runtime = read(output / 'runtime.json')
    require(runtime['package_sources'] == package_refs, 'capture/probe package sources differ')
    refs = dict(package_refs)
    def visit(value):
        if isinstance(value, dict):
            if set(value) == {'path', 'sha256', 'size_bytes'} and str(value['path']).endswith(('.py', '.pyi')):
                refs[str(value['path'])] = value
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)
    visit(runtime)
    runtime_copies = io.freeze_runtime_refs(directory, refs, runtime_copies)
    put(directory / 'frozen-runtime-source-map.json', runtime_copies)
    after = source_files(source, root); _, after_proof, _ = prerequisite(source, root); after.update(after_proof)
    _, after_cpu, _ = cpu_prerequisite(source, root); after.update(after_cpu)
    after.update({path: sha(path) for path in helper_sources}); after.update({str(p): sha(p) for p in dynamic})
    after.update({ref['path']: sha(ref['path']) for ref in package_refs.values()})
    require(before == after, 'frozen source, actual I03 prerequisite or binding changed')
    put(directory / 'sources-after.json', after)
    put(directory / 'capture-receipt.json', {'schema_version': 1, 'task': 'I04', 'task_id': TASK_ID,
        'backend': 'GPU', 'status': 'completed', 'returncode': 0, 'timed_out': False,
        'started_utc': command['start'], 'finished_utc': utc(), 'argv': command['argv'],
        'collector_path': str(stage / GPU), 'collector_sha256': NEW_PINS[GPU],
        'input_path': str(stage / INPUT), 'input_sha256': FIXED[INPUT],
        'input_b_path': str(stage / INPUT_B), 'input_b_sha256': FIXED[INPUT_B], 'dependency_paths': list(after),
        'source_sha256': after, 'output_dir': str(output), 'artifacts_manifest_sha256': sha(output / 'artifacts-manifest.json'),
        'expected_inventory_source_path': str(expected), 'expected_inventory_source_sha256': source['expected_inventory_sha256'],
        'stage_spec_source_path': str(stage / SPEC), 'stage_spec_source_sha256': SPEC_SHA,
        'i03_prerequisite_source_path': source['i03_prerequisite_path'], 'i03_prerequisite_source_sha256': source['i03_prerequisite_sha256'],
        'cpu_prerequisite_source_path': source['cpu_prerequisite_path'], 'cpu_prerequisite_source_sha256': source['cpu_prerequisite_sha256'],
        'generic_receipt': generic, 'allocation_path': str(directory / 'allocation.json'),
        'allocation_sha256': sha(directory / 'allocation.json'),
        'runtime_source_map_path': str(directory / 'frozen-runtime-source-map.json'),
        'runtime_source_map_sha256': sha(directory / 'frozen-runtime-source-map.json'),
        'validation': validation, 'native_capture_count': 1,
        'native_forward_calls_total': validation['native_forward_calls_total'],
        'model_loads': validation['model_loads'], 'acceptance': None})
    return 0


def launch(root=ROOT, query=subprocess.run, runner=supervise):
    root = Path(root); started = time.monotonic(); started_utc = utc(); deadline = started + WORK_SECONDS + CLEANUP_SECONDS
    require(sys.platform.startswith('linux') and root.is_dir() and not root.is_symlink(), 'new Linux I04 root required')
    source = root / SOURCE; stop = min(deadline - CLEANUP_SECONDS, time.monotonic() + 120)
    while not source.is_file() and time.monotonic() < stop:
        select.select([], [], [], min(1, max(0, stop - time.monotonic())))
    require(source.is_file(), 'I04 source missing after120s; no model started')
    original(source, root, 131072); raw = source.read_bytes(); doc = validate_source(read(source), root)
    existing = root / 'claims' / doc['allocation_id']
    if existing.exists() or existing.is_symlink():
        print(json.dumps({'status': 'refused', 'reason': 'permanent_I04_claim_exists', 'model_started': False}), flush=True)
        return 0
    sources = source_files(doc, root); checked, proof_files, aliases = prerequisite(doc, root)
    cpu_checked, cpu_files, cpu_aliases = cpu_prerequisite(doc, root)
    expected_check = independent_expected(doc, root)
    require(shutil.disk_usage(root).free >= MIN_FREE and tree_bytes(root) <= MAX_TASK_BYTES, 'new I04 free5GiB/task4GiB gate failed')
    require(time.monotonic() < deadline - CLEANUP_SECONDS, 'I04 whole attempt expired before claim')
    directory = claim_once(root, doc['allocation_id'], {'schema_version': 1, 'task': 'I04', 'task_id': TASK_ID,
        'allocation_id': doc['allocation_id'], 'entry_started_utc': started_utc,
        'entry_elapsed_before_claim_seconds': time.monotonic() - started,
        'claimed_utc': utc(), 'source_sha256': sha(source),
        'entry_sha256': doc['entry_sha256'], 'lifecycle_sha256': doc['lifecycle_sha256'],
        'i03_prerequisite_sha256': doc['i03_prerequisite_sha256'],
        'cpu_prerequisite_sha256': doc['cpu_prerequisite_sha256'], 'whole_attempt_seconds': MAX_SECONDS,
        'metadata_export_reserved_seconds': METADATA_EXPORT_SECONDS, 'controller_work_seconds': WORK_SECONDS,
        'independent_expected_sha256': expected_check['sha256'], 'independent_expected_bytes': expected_check['size_bytes'],
        'capture_seconds': CAPTURE_SECONDS, 'max_capture_bytes': MAX_CAPTURE_BYTES, 'max_new_task_bytes_sampled': MAX_TASK_BYTES,
        'logical_transport_cap': LOGICAL_TRANSPORT, 'encoded_transport_cap': ENCODED_TRANSPORT,
        'scope': 'New permanent I04 app claim; failure never releases or retries model work.'})
    if directory is None:
        return 0
    raw_put(directory / SOURCE, raw)
    try:
        put(directory / 'preclaim-prerequisite-validation.json', checked)
        put(directory / 'preclaim-prerequisite-file-sha256.json', proof_files)
        put(directory / 'preclaim-cpu-prerequisite-validation.json', cpu_checked)
        put(directory / 'preclaim-cpu-prerequisite-file-sha256.json', cpu_files)
        put(directory / 'preclaim-independent-inventory.json', expected_check)
        result = query(['nvidia-smi', '--query-gpu=uuid,name,driver_version', '--format=csv,noheader'],
                       capture_output=True, timeout=20, check=False)
        raw_put(directory / 'driver.stdout', result.stdout or b''); raw_put(directory / 'driver.stderr', result.stderr or b'')
        require(result.returncode == 0, 'native driver metadata query failed')
        rows = []
        for line in result.stdout.decode().splitlines():
            fields = [item.strip() for item in line.split(',')]; require(len(fields) == 3, 'driver columns differ')
            physical = str(uuid.UUID(fields[0].removeprefix('GPU-')))
            require(uuid.UUID(physical).int and fields[1] and re.fullmatch(r'[0-9]+(?:\.[0-9]+){1,3}', fields[2]), 'invalid native driver metadata')
            rows.append({'uuid': physical, 'name': fields[1], 'driver_version': fields[2]})
        require(rows and len({row['uuid'] for row in rows}) == len(rows), 'driver GPU inventory unavailable/duplicated')
        put(directory / 'driver-receipt.json', {'status': 'observed', 'finished_utc': utc(), 'rows': rows,
            'returncode': result.returncode, 'stdout_sha256': sha(directory / 'driver.stdout'), 'stderr_sha256': sha(directory / 'driver.stderr')})
        require(source.read_bytes() == raw and source_files(doc, root) == sources, 'source changed after permanent I04 claim')
        helper = load_pinned(root / 'source' / CLEANUP, CLEANUP_SHA, 'i04_reviewed_linux_owned_cleanup')
        code, state = runner([sys.executable, '-B', str(root / LIFECYCLE), '--worker', str(directory)],
                             directory, root, deadline, helper)
        print(json.dumps({'status': state['status'], 'returncode': code, 'claim': str(directory),
                          'app_must_be_stopped_in_platform_UI': True}), flush=True)
        return code
    except BaseException as exc:
        put(directory / 'launch-failure.json', {'status': 'failed', 'finished_utc': utc(), 'error_type': type(exc).__name__,
            'error': str(exc), 'claim_remains_spent': True, 'app_must_be_stopped_in_platform_UI': True})
        return 1


def main():
    os.umask(0o077)
    def interrupt(_signum, _frame):
        raise KeyboardInterrupt()
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(sig, interrupt)
    if len(sys.argv) == 3 and sys.argv[1] == '--worker':
        directory = Path(sys.argv[2])
        try:
            return worker(directory)
        except BaseException as exc:
            put(directory / 'capture-failure.json', {'schema_version': 1, 'task': 'I04', 'backend': 'GPU',
                'status': 'failed', 'returncode': 1, 'finished_utc': utc(), 'error_type': type(exc).__name__,
                'error': str(exc), 'claim_remains_spent': True, 'acceptance': None})
            return 1
    require(len(sys.argv) == 1, 'no unreviewed paths/app IDs accepted on CLI')
    return launch()


if __name__ == '__main__':
    raise SystemExit(main())

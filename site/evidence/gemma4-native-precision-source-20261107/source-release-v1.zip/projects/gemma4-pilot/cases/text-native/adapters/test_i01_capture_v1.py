"""CPU synthetic regressions for full-call semantics and retained BF16 evidence.

No Torch/model/accelerator imports or executions. Vocabulary is reduced only by
in-process unittest patching; production CLI has no vocabulary override.
"""
from contextlib import nullcontext
import hashlib
import json
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import i01_common_v1 as c


class Tensor:
    dtype = 'torch.bfloat16'
    def __init__(self, values, dtype=None):
        self.values = np.asarray(values)
        if dtype is not None:
            self.dtype = dtype
    @property
    def shape(self):
        return self.values.shape
    def detach(self): return self
    def cpu(self): return self
    def contiguous(self): return self
    def __getitem__(self, index): return Tensor(self.values[index], self.dtype)
    def double(self): return Tensor(self.values.astype(np.float64), 'torch.float64')
    def numpy(self): return self.values


class FakeTorch:
    long = 'long'
    inference_mode = staticmethod(nullcontext)
    @staticmethod
    def tensor(values, **kwargs): return np.asarray(values)
    @staticmethod
    def ones(shape, **kwargs): return np.ones(shape, dtype=np.int64)


class Model:
    def __init__(self, tensor, cache=None):
        self.tensor, self.cache, self.calls = tensor, cache, []
    def __call__(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(logits=self.tensor, past_key_values=self.cache)


def save_fake_raw(tensor, path):
    bits = (tensor.values.astype('<f4').view('<u4') >> 16).astype('<u2')
    header = json.dumps({'logits': {'dtype': 'BF16', 'shape': list(bits.shape),
                        'data_offsets': [0, bits.nbytes]}}, separators=(',', ':')).encode()
    header += b' ' * (-len(header) % 8)
    with path.open('xb') as stream:
        stream.write(struct.pack('<Q', len(header))); stream.write(header); stream.write(bits.tobytes())


class CaptureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.input = self.root / 'input.json'
        self.doc = {'sample': 'fixture', 'prompt': list(range(128)), 'continuation': list(range(32))}
        c.put(self.input, self.doc)
        self.input_sha = c.sha(self.input)
        self.patcher = patch.multiple(c, VOCABULARY=128, INPUT_SHA256=self.input_sha)
        self.patcher.start()
        self.inv = c.input_inventory(self.doc)
        self.expected = self.root / 'expected.json'
        c.put(self.expected, {'schema_version': 1, 'task': c.TASK, 'stage_id': c.STAGE_ID,
            'stage_spec_sha256': c.STAGE_SHA256, 'input_sha256': self.input_sha,
            'all_targets': self.inv['all_targets'], 'distribution_positions': self.inv['distribution_positions'],
            'cached_overlap_targets': self.inv['all_targets'][127:],
            'raw_logits': {'tensor_name': 'logits', 'dtype': 'BF16', 'shape': [1, 160, 128],
                           'data_bytes': 320*128, 'unscored_prediction_indices': [159]}})
        values = (np.arange(160*128, dtype=np.float32).reshape(1,160,128) % 29 - 14) / 4
        self.tensor = Tensor(values)
        self.output = self.root / 'capture'; self.output.mkdir()
        (self.output / 'expected-inventory.json').write_bytes(self.expected.read_bytes())
    def tearDown(self):
        self.patcher.stop(); self.temp.cleanup()
    def finish(self):
        for name in ('snapshot-verification', 'loaded-model-inventory', 'policy-before-load', 'policy-after-load', 'policy-after-capture'):
            c.put(self.output / (name + '.json'), {'fixture': True})
        source = self.root / 'modeling-fixture.py'; source.write_text('# synthetic fixture\n')
        args = SimpleNamespace(output=self.output, input=self.input, expected_inventory=self.expected)
        return c.finalize(args, 'gpu', self.inv, {}, {'model_identity': {'modeling_source': c.file_ref(source)}})
    def test_full_call_coordinates_and_lossless_bf16(self):
        model = Model(self.tensor)
        summary = c.capture(model, FakeTorch, 'cpu', self.inv, self.output, save_raw=save_fake_raw)
        self.assertEqual(len(model.calls), 1)
        kw = model.calls[0]
        np.testing.assert_array_equal(kw['input_ids'], [self.doc['prompt'] + self.doc['continuation']])
        np.testing.assert_array_equal(kw['position_ids'], [list(range(160))])
        self.assertEqual(kw['attention_mask'].shape, (1,160)); self.assertTrue((kw['attention_mask'] == 1).all())
        self.assertIs(kw['use_cache'], False); self.assertIsNone(kw['past_key_values']); self.assertEqual(kw['logits_to_keep'], 0)
        self.assertEqual((summary['targets'], summary['sampled_distributions']), (159,47))
        scores = c.read(self.output/'target-scores.json')['scores']
        self.assertEqual([x['position'] for x in scores], list(range(1,160)))
        self.assertEqual(scores[-1]['prediction_position'],158)
        independent = self.tensor.values[0,158,:].astype(np.float64)
        independent -= np.max(independent)
        expected = float(independent[31] - np.log(np.exp(independent).sum()))
        self.assertEqual(scores[-1]['logprob'],expected)
        positions=c.read(self.output/'distributions.json')['positions']
        self.assertEqual([x['position'] for x in positions], self.inv['positions'])
        self.assertEqual(c.read(self.output/'dist-p127.json')['roles'], ['prompt_sample','continuation'])
        raw=(self.output/'raw-native-logits.safetensors').read_bytes()
        offset=8+struct.unpack('<Q',raw[:8])[0]
        expected_bits=(self.tensor.values.astype('<f4').view('<u4')>>16).astype('<u2').tobytes()
        self.assertEqual(raw[offset:],expected_bits)
        result=self.finish();self.assertEqual(result['status'],'i01_output_artifacts_checked')
        self.assertNotIn('torch',__import__('sys').modules)
    def test_cache_shape_dtype_fail_before_completed(self):
        for value,cache in ((self.tensor,object()),(Tensor(self.tensor.values[:,:1,:]),None),
                            (Tensor(self.tensor.values,'torch.float32'),None)):
            with self.subTest(shape=list(value.shape),cache=cache is not None,dtype=value.dtype):
                with self.assertRaises(ValueError):c.capture(Model(value,cache),FakeTorch,'cpu',self.inv,self.output,save_raw=save_fake_raw)
                self.assertFalse((self.output/'status.json').exists())
                self.assertFalse((self.output/'raw-native-logits.safetensors').exists())
    def test_tampered_array_or_omitted_evidence_rejected(self):
        c.capture(Model(self.tensor),FakeTorch,'cpu',self.inv,self.output,save_raw=save_fake_raw)
        self.finish()
        path=self.output/'dist-p158.npy';raw=path.read_bytes();path.write_bytes(raw[:-1]+bytes([raw[-1]^1]))
        with self.assertRaisesRegex(ValueError,'artifact bytes changed'):c.validate_output(self.output,self.input)
        path.write_bytes(raw)
        manifest=c.read(self.output/'artifacts-manifest.json');del manifest['files']['loaded-model-inventory.json']
        (self.output/'artifacts-manifest.json').unlink();c.put(self.output/'artifacts-manifest.json',manifest)
        with self.assertRaisesRegex(ValueError,'omits required evidence'):c.validate_output(self.output,self.input)
    def test_unscored_last_native_row_nonfinite_rejected(self):
        self.tensor.values[0,159,0]=np.nan
        with self.assertRaisesRegex(ValueError,'unscored raw row 159'):c.capture(Model(self.tensor),FakeTorch,'cpu',self.inv,self.output,save_raw=save_fake_raw)
        self.assertFalse((self.output/'status.json').exists())
    def test_loaded_metadata_alias_and_storage_gap(self):
        class Parameter:
            shape=(2,3);dtype='torch.bfloat16';device='npu:0'
            def numel(self):return 6
            def untyped_storage(self):raise RuntimeError('fixture unsupported storage')
        parameter=Parameter()
        class MetadataModel:
            _tied_weights_keys={'head.weight':'embed.weight'}
            config=SimpleNamespace(to_dict=lambda:{'tie_word_embeddings':True})
            def named_modules(self,remove_duplicate):return [('',self),('head',self)]
            def named_parameters(self,remove_duplicate):return [('embed.weight',parameter),('head.weight',parameter)]
        observed=c.loaded_model_inventory(MetadataModel())
        self.assertEqual(observed['parameter_object_alias_groups'],[['embed.weight','head.weight']])
        self.assertEqual(len(observed['storage_observation_gaps']),2)
        self.assertEqual(observed['parameters'][0]['shape'],[2,3])
        self.assertFalse(observed['observable_shared_storage_groups'])
    def test_real_frozen_stage_expected_and_source_closure_without_native(self):
        import i01_expected_inventory_v1 as independent
        case=c.HERE.parent
        original_input=case/'inputs/discovery-v1/wikitext2-discovery-001.json'
        stage=case/'i01-stage-v1.json'
        expected=self.root/'real-expected.json'
        result=independent.build(original_input,expected,stage,c.STAGE_SHA256)
        self.assertEqual(result['sha256'],c.EXPECTED_SHA256)
        allocation=self.root/'allocation.json';c.put(allocation,{'fixture':'preparation-only, no ownership or native claim'})
        args=SimpleNamespace(model=self.root/'unused-model',input=original_input,allocation_receipt=allocation,
            stage_spec=stage,stage_spec_sha256=c.STAGE_SHA256,expected_inventory=expected,
            expected_inventory_sha256=c.EXPECTED_SHA256,numerics_policy=case/'inputs/peer-math-policy-cu128-v1.json',
            device='cuda:0',output=self.root/'never-created')
        with patch.multiple(c,VOCABULARY=262144,INPUT_SHA256=independent.INPUT_SHA256):
            observed,inventory,refs=c.prepare(args,'gpu',c.HERE/'i01_gpu_v1.py')
            self.assertEqual(len(inventory['all_targets']),159);self.assertEqual(len(inventory['positions']),47)
            self.assertEqual(observed['limits']['max_native_launches_per_backend'],1)
            c.check_refs(refs)
            self.assertFalse(args.output.exists())
            args.stage_spec_sha256='0'*64
            with self.assertRaisesRegex(ValueError,'stage SHA'):c.prepare(args,'gpu',c.HERE/'i01_gpu_v1.py')
        self.assertNotIn('torch',__import__('sys').modules)


if __name__ == '__main__':unittest.main()

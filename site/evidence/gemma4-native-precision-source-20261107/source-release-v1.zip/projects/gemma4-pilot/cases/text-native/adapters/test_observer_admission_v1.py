"""CPU-only observer raw, coordinate, sample, census and shared-math tests."""
from contextlib import ExitStack
import copy
import hashlib
import json
import math
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import observer_artifact_admission_v1 as n
import admit_observer_transparency_v1 as a

HERE=Path(__file__).resolve().parent


def write(path,doc):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(doc,indent=2,allow_nan=False)+'\n',encoding='utf8');return path


def pack(path,tensors):
    header={};offset=0;payload=[]
    for key,bits in sorted(tensors.items()):
        raw=np.asarray(bits,dtype='<u2').tobytes();header[key]={'dtype':'BF16','shape':list(bits.shape),'data_offsets':[offset,offset+len(raw)]};offset+=len(raw);payload.append(raw)
    raw=json.dumps(header,separators=(',',':')).encode();raw+=b' '*(-len(raw)%8);path.write_bytes(struct.pack('<Q',len(raw))+raw+b''.join(payload));return path


def rng():
    return {'python':{'format':'untruncated Python random.getstate tuple repr UTF8','sha256':'1'*64},
        'numpy':{'format':'canonical-JSON-header UTF8 + NUL + complete uint32LE state words','sha256':'2'*64,'header':{'version':1,'algorithm':'MT19937','word_count':624,
            'word_encoding':'uint32-little-endian','position':624,'has_gauss':0,'cached_gaussian_binary64_le_hex':'0000000000000000'}},
        'torch_cpu':{'format':'complete Torch generator state ByteTensor bytes','sha256':'3'*64},'device0':{'format':'complete Torch generator state ByteTensor bytes','sha256':'4'*64}}


class Endpoint:
    def __init__(self,root):self.root=Path(root);self.checked={};self.resolved={}
    def get(self,name,digest=None):
        p=self.root/name.removeprefix('/original/');actual=n.sha(p)
        if digest is not None:n.require(actual==digest,'fixture original SHA differs')
        self.checked[name]=actual;self.resolved[name]=str(p);return p
    def json(self,name,digest=None):return n.load(self.get(name,digest))


def mode_fixture(root,nonfinite_final=False):
    root=Path(root);folder=root/'capture/modes/off-before';folder.mkdir(parents=True);ep=Endpoint(root);logical='/original/capture/modes/off-before'
    sequence=[i%128 for i in range(160)];sample='fixture';positions=sorted({i*127//15 for i in range(16)}|set(range(127,159)))
    inventory={'sequence':sequence,'sample':sample,'all_targets':[{'sample':sample,'position':p,'prediction_position':p-1,'token':sequence[p]} for p in range(1,160)],
        'distribution_positions':positions,'channels':[j*3839//63 for j in range(64)],'boundaries':n.expected.boundaries(),'enabled_modes':n.MODES[1::2]}
    inventory['distribution_rows']=[{'sample':sample,'position':p,'history':sequence[:p+1],'roles':(['prompt_sample'] if p in [i*127//15 for i in range(16)] else [])+(['continuation'] if p>=127 else []),
        'target_position':p+1,'token':sequence[p+1]} for p in positions]
    values=np.tile(np.linspace(-2,2,128,dtype='<f4'),(1,160,1));bits=(values.view('<u4')>>16).astype('<u2')
    if nonfinite_final:bits[0,159,0]=0x7fc1
    raw=pack(folder/'raw-native-logits.safetensors',{'logits':bits});raw_sha=n.sha(raw)
    base={'schema_version':1,'task':n.TASK,'mode':'off-before','stage_spec_sha256':n.STAGE_SHA,'input_sha256':n.expected.INPUT_SHA,'raw_logits_sha256':raw_sha,
        'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':n.NORMALIZATION}
    rows=[];scores=[]
    v=n.prior.decode_bits(bits[0,0]);v-=v.max();v-=math.log(float(np.sum(np.exp(v))))
    for p in range(159):scores.append({**inventory['all_targets'][p],'logprob':float(v[sequence[p+1]])})
    for coordinate in inventory['distribution_rows']:
        p=coordinate['position'];stem='dist-p%03d'%p;descriptor={'path':stem+'.npy','row':0}
        np.save(folder/(stem+'.npy'),v.reshape(1,128),allow_pickle=False)
        write(folder/(stem+'.json'),{**base,**coordinate,'scores':descriptor,'logprob':scores[p]['logprob']})
        rows.append({k:coordinate[k] for k in ('sample','position','history','roles')}|{'scores':descriptor,'record':stem+'.json'})
    write(folder/'target-scores.json',{**base,'kind':'observer-native-target-scores','scores':scores});write(folder/'distributions.json',{**base,'kind':'observer-native-distribution-rows','positions':rows})
    observed={'schema_version':1,'enabled':False,'status':'disabled_control','boundary_specs':inventory['boundaries'],'boundary_counts':None,'module_invocations':None,'zero_fired_modules':None,'dispatcher':{'enabled':False}}
    o=write(folder/'observer.json',observed)
    summary={'schema_version':1,'task':n.TASK,'mode':'off-before','native_forward_calls':1,'model_loads':0,'use_cache':False,'past_key_values_is_none':True,'returned_cache':None,
        'returned_shared_kv_states':None,'logits_to_keep':0,'native_logits_shape':[1,160,128],'native_logits_dtype':'torch.bfloat16','targets':159,'distribution_positions':47,
        'unscored_native_prediction_indices':[159],'observer_enabled':False,'dispatcher_enabled':False,'boundary_snapshots':0,
        'raw_logits':{'path':logical+'/raw-native-logits.safetensors','sha256':raw_sha,'size_bytes':raw.stat().st_size},
        'observer':{'path':logical+'/observer.json','sha256':n.sha(o),'size_bytes':o.stat().st_size}}
    write(folder/'capture-summary.json',summary);baseline={'fixture_model_object':1};p=write(root/'baseline.json',baseline);after=write(folder/'model-state-after.json',baseline);policy={'fixture':True}
    write(folder/'state-control.json',{'mode':'off-before','seed_reset':{'seed':0,'settings':policy},'rng_before':rng(),'rng_after':rng(),'math_policy':policy,'baseline_model_state_sha256':n.sha(p),'model_state_after_sha256':n.sha(after)})
    return ep,inventory,baseline,n.sha(p),policy,folder


def inspect(fixture):
    ep,inventory,baseline,digest,policy,_=fixture
    with patch.object(n,'VOCABULARY',128),patch.object(n.prior,'VOCABULARY',128):return n.inspect_mode(ep,'/original/capture','off-before',inventory,baseline,digest,policy,[{'name':'','class':'fixture.Model'}],'cpu')


class RawAdmission(unittest.TestCase):
    def test_independent_full160_159targets47rows_finite(self):
        with tempfile.TemporaryDirectory() as td:
            result=inspect(mode_fixture(td));self.assertEqual((len(result['scores']),len(result['positions'])),(159,47));self.assertLessEqual(result['raw_derivation_max_abs_delta'],1e-12)
            self.assertFalse(result['census']['execution_census_measured'])
    def test_unscored_final_raw159_nonfinite_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaisesRegex(ValueError,'unscored'):inspect(mode_fixture(td,True))
    def test_target_coordinate_and_selected_row_tamper_rejected(self):
        for name in ('target','row'):
            with self.subTest(name=name),tempfile.TemporaryDirectory() as td:
                fixture=mode_fixture(td);folder=fixture[-1]
                if name=='target':
                    p=folder/'target-scores.json';doc=n.load(p);doc['scores'][127]['prediction_position']=128;write(p,doc)
                else:
                    p=folder/'dist-p127.npy';value=np.load(p);value[0,3]+=0.01;np.save(p,value,allow_pickle=False)
                with self.assertRaises(ValueError):inspect(fixture)
    def test_rng_advancement_and_persistent_state_change_rejected(self):
        for name in ('rng','state'):
            with self.subTest(name=name),tempfile.TemporaryDirectory() as td:
                fixture=mode_fixture(td);folder=fixture[-1]
                if name=='rng':p=folder/'state-control.json';doc=n.load(p);doc['rng_after']['torch_cpu']['sha256']='8'*64;write(p,doc)
                else:write(folder/'model-state-after.json',{'fixture_model_object':2})
                with self.assertRaises(ValueError):inspect(fixture)
    def test_unknown_rng_and_incomplete_numpy_state_rejected(self):
        value=rng();value['device0']={'unavailable':True,'error_type':'fixture','error':'gap'}
        with self.assertRaisesRegex(ValueError,'unknown'):n.complete_rng(value)
        value=rng();value['numpy']['header']['word_count']=623
        with self.assertRaises(ValueError):n.complete_rng(value)
    def test_scalar_buffer_content_gap_is_explicit_and_never_promoted(self):
        baseline={'buffers':[{'name':'embed_scale','content_probe_gap':{'error_type':'RuntimeError','error':'scalar BF16 view gap'}},{'name':'available','content_sha256':'5'*64}]}
        coverage=n.buffer_coverage(baseline);self.assertEqual(coverage['entries_with_content_sha256'],1);self.assertEqual(coverage['unavailable_entries'][0]['name'],'embed_scale')
        self.assertFalse(coverage['complete_loaded_model_content_attested']);self.assertNotIn('content_sha256',baseline['buffers'][0])
        baseline['buffers'][0].pop('content_probe_gap')
        with self.assertRaises(ValueError):n.buffer_coverage(baseline)


class SamplesAndCensus(unittest.TestCase):
    def test_lossless_bf16_tensor_framing_shape_nan_and_trailing_bytes(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'sample.safetensors';bits=np.array([0,0x8000,0x3f80,0xbf80],dtype='<u2').reshape(1,2,2);pack(p,{'boundary':bits})
            self.assertEqual(n.tensor_pack(p,{'boundary':[1,2,2]})['finite_coordinate_count'],4)
            with self.assertRaises(ValueError):n.tensor_pack(p,{'boundary':[2,2]})
            pack(p,{'boundary':np.full((1,2,2),0x7fc1,dtype='<u2')})
            with self.assertRaisesRegex(ValueError,'nonfinite'):n.tensor_pack(p,{'boundary':[1,2,2]})
            pack(p,{'boundary':bits});p.write_bytes(p.read_bytes()+b'\0')
            with self.assertRaisesRegex(ValueError,'length'):n.tensor_pack(p,{'boundary':[1,2,2]})
    def census(self):
        specs=n.expected.boundaries();names=['',*dict.fromkeys(x['module'] for x in specs),'unused'];modules=[{'name':x,'class':'fixture.Module'} for x in names]
        census=[{**x,'invocations':0 if x['name']=='unused' else 1,'completed_invocations':0 if x['name']=='unused' else 1} for x in modules]
        inventory={'boundaries':specs,'distribution_positions':sorted({i*127//15 for i in range(16)}|set(range(127,159))),'channels':[j*3839//63 for j in range(64)]}
        events=[{**x,'ordinal':i,'token_indices':inventory['distribution_positions'],'channel_indices':inventory['channels'],'sample_shape':[1,47,64],
            'sample_dtype':'torch.bfloat16','observed':{'shape':[1,160,3840],'dtype':'torch.bfloat16','device':'cpu'}} for i,x in enumerate(specs)]
        doc={'enabled':True,'status':'completed','error':None,'actual_module_count':len(modules),'hook_registry_restored':True,'module_invocations':census,
            'zero_fired_modules':['unused'],'fired_module_count':len(modules)-1,'total_module_invocations':len(modules)-1,'boundary_specs':specs,
            'boundary_counts':{x['id']:1 for x in specs},'boundary_events':events,'dispatcher':{'enabled':False,'observed_invocations':0,'unique_signatures':0,'signatures':[],
            'collector_generated_excluded_operations':{},'metadata_byte_budget_accounting':0,'limits':{'invocations':200000,'unique_signatures':10000,'serialized_bytes':16777216}}}
        return modules,inventory,doc
    def test_actual_census_zero_fired_is_not_static_execution(self):
        modules,inventory,doc=self.census();report=n.observer_metadata(doc,modules,inventory,True,False,'cpu')
        self.assertEqual(report['zero_fired_modules'],['unused']);self.assertFalse(report['native_kernel_identity_attested'])
        doc['module_invocations'][1]['invocations']=doc['module_invocations'][1]['completed_invocations']=0
        with self.assertRaises(ValueError):n.observer_metadata(doc,modules,inventory,True,False,'cpu')
    def test_boundary_order_batch_axis_and_disabled_execution_fabrication(self):
        modules,inventory,doc=self.census();doc['boundary_events'][0]['sample_shape']=[47,64]
        with self.assertRaises(ValueError):n.observer_metadata(doc,modules,inventory,True,False,'cpu')
        disabled={'enabled':False,'dispatcher':{'enabled':False},'boundary_specs':inventory['boundaries'],'status':'disabled_control','module_invocations':[]}
        with self.assertRaises(ValueError):n.observer_metadata(disabled,modules,inventory,False,False,'cpu')
    def test_dispatcher_tree_rejects_operand_values_and_unbounded_containers(self):
        n.metadata_tree({'container':'tuple','items':[{'python_type':'builtins.float'},{'path':'args/1','shape':[2],'dtype':'torch.bfloat16','device':'cpu','layout':'torch.strided','stride':[1]}]})
        with self.assertRaises(ValueError):n.metadata_tree({'python_type':'builtins.float','value':3.0})
        with self.assertRaises(ValueError):n.metadata_tree({'container':'list','items':[{'python_type':'builtins.int'}]*129})


def rank_binding():return {'rank':0,'logical_ordinal':0,'compute_device_count':1,'allocation_id':'fixture-app','allocation_sha256':'1'*64,
    'original_status_path':'/original/status.json','original_status_sha256':'2'*64,'original_outer_receipt_sha256':'3'*64}


class Contracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.inventory=n.load(HERE.parent/'transfer/observer-independent-expected-v2-20261107.json')
    def test_exact16_752_4_392_and_primary98_derived_from_frozen_expected(self):
        pairs,samples=a.derive_pairs(self.inventory);self.assertEqual((len(pairs),sum(p['distribution_rows'] for p in pairs),len(samples),len(samples)*len(self.inventory['boundaries'])),(16,752,4,392))
        self.assertEqual(len(self.inventory['primary_boundary_pairs']),98)
        wrong=copy.deepcopy(self.inventory);wrong['comparison_pairs'].pop()
        with self.assertRaises(ValueError):a.derive_pairs(wrong)
    def test_production_gates_reject_even_valid_declared_spec(self):
        with self.assertRaisesRegex(ValueError,'unready'):a.assess(Path('not-read.json'),'0'*64,Path('must-not-create'))
        self.assertIsNone(a.HELPER_SHA);self.assertEqual(a.ACTUAL_ENDPOINTS,{'GPU':None,'NPU':None})
    def test_rank_adapter_requires_actual_tp1_binding_and_preserves_provenance(self):
        with self.assertRaises(KeyError):a.rank_status({})
        for field,value in [('logical_ordinal',1),('compute_device_count',2),('rank',True),('original_status_sha256','invalid')]:
            binding=rank_binding();binding[field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):a.rank_status({'rank_binding':binding})
        doc=a.rank_status({'rank_binding':rank_binding()});self.assertFalse(doc['original_bytes_rewritten']);self.assertEqual(doc['original_status']['source_path'],'/original/status.json')
    def test_shared_all98_bf16_sample_comparison_known_error(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);runs=[]
            for side,bits in [('fixture-a',0),('fixture-b',0x3f80)]:
                p=root/(side+'.safetensors');pack(p,{x['id']:np.full((1,47,64),bits,dtype='<u2') for x in self.inventory['boundaries']})
                samples=n.tensor_pack(p,{x['id']:[1,47,64] for x in self.inventory['boundaries']})
                runs.append({'side':side,'model':{'fixture':'one'},'hardware':{'category':'CPU'},'software':{'fixture':'1'},'backend_policy':{'fixture':True},'mode':{'fixture':side},
                    'rank_binding':rank_binding(),'samples':samples})
            result=a.compare_samples(root/'comparison',*runs,self.inventory);self.assertEqual(len(result['metrics']['per_tensor']),98)
            self.assertEqual(result['metrics']['global']['count'],98*47*64);self.assertEqual(result['metrics']['global']['rmse']['value'],1.0)
            self.assertEqual(len(result['frozen_document_sha256']),7)
    def test_shared_full159target47row_contract_and_derived_rank_status(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);fixture=mode_fixture(root/'source');result=inspect(fixture);inventory=fixture[1];runs=[]
            for side in ('fixture-a','fixture-b'):
                runs.append({**result,'side':side,'model':{'fixture':'one'},'hardware':{'category':'CPU'},'software':{'fixture':'1'},'backend_policy':{'fixture':True},'mode':{'fixture':side},'rank_binding':rank_binding()})
            with patch.object(n,'VOCABULARY',128):report=a.compare_scores(root/'comparison',*runs,inventory)
            self.assertEqual(report['targets']['coverage'],{'expected':159,'paired':159});self.assertEqual(report['targets']['metrics']['mae_nat'],0)
            self.assertEqual(report['distributions']['position_count'],47);self.assertEqual(len(report['frozen_document_sha256']),10)
            status=n.load(root/'comparison/fixture-a-status.json');self.assertTrue(status['derived_adapter']);self.assertFalse(status['original_bytes_rewritten'])
    def test_no_collector_or_framework_loaded(self):
        self.assertFalse(any(x in sys.modules for x in ('torch','torch_npu','observer_common_v2','observer_native_v2','observer_collectors_v1')))


if __name__=='__main__':unittest.main(verbosity=2)

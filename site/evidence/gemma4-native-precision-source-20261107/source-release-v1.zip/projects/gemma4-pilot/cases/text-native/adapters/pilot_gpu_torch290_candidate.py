"""Private H100 Torch 2.9 candidate for the frozen Ascend peer workload.

This preserves the existing native capture function and model-loading semantics.
It requires a supplied allocation receipt, then verifies observed CUDA UUID,
stack, snapshot bytes and numerical policy. These observations are not scheduler
attestation or proof of the bytes actually consumed by the model loader.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import uuid

from pilot_gpu_peer_v2 import capture, check_policy, math_policy, parse_input, seed_and_check, write_json
from verify_snapshot import verify

HERE = Path(__file__).resolve().parent
REVISION = '1a2c7729392586f5ecddae8807ee2ef741eabb9a'
INPUT_SHA256 = '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
METADATA_SHA256 = '80dc0e0e59e5c526426b566d36a21f762a79d498986d5d6cd01098c8cb5decc3'
POLICY_SHA256 = '5ef32354ed453d27c5751248b66859e433d9230a7fbf620851f6d5ec6da92516'
EXPECTED_STACK = {'torch': '2.9.0+cu128', 'transformers': '5.10.1',
                  'cuda_runtime': '12.8', 'numpy': '1.26.4'}
H100_NAME = 'NVIDIA H100 80GB HBM3'
MIN_FREE_BYTES = 35 * 1024 ** 3


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def canonical_uuid(value):
    if value is None:
        raise ValueError('native CUDA UUID is unavailable')
    text = str(value).strip()
    if text.startswith('GPU-'):
        text = text[4:]
    try:
        parsed = uuid.UUID(text)
    except (ValueError, AttributeError) as exc:
        raise ValueError('malformed CUDA device UUID') from exc
    if not parsed.int:
        raise ValueError('all-zero CUDA UUID is unavailable')
    return str(parsed)


def check_input(path):
    if sha256(Path(path).read_bytes()) != INPUT_SHA256:
        raise ValueError('input differs from frozen discovery example 001')
    sample, prompt, continuation = parse_input(path)
    if len(prompt) != 128 or len(continuation) != 32:
        raise ValueError('frozen 128 + 32 workload changed')
    return sample, prompt, continuation


def check_stack(actual):
    if actual != EXPECTED_STACK:
        raise RuntimeError('actual GPU stack differs from frozen Torch 2.9 declaration: ' + repr(actual))


def check_allocation(allocation):
    if (not isinstance(allocation, dict) or allocation.get('vendor') != 'NVIDIA' or
            type(allocation.get('visible_count')) is not int or allocation['visible_count'] != 1 or
            type(allocation.get('logical_ordinal')) is not int or allocation['logical_ordinal'] != 0):
        raise ValueError('requires an explicit single-visible-GPU NVIDIA allocation at ordinal zero')
    for key in ('allocation_id', 'physical_device_id', 'evidence_source'):
        if not isinstance(allocation.get(key), str) or not allocation[key].strip():
            raise ValueError('allocation receipt missing ' + key)
    return canonical_uuid(allocation['physical_device_id'])


def check_device(torch, allocation):
    expected = check_allocation(allocation)
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError('requires exactly one visible assigned CUDA device')
    torch.cuda.set_device(0)
    props = torch.cuda.get_device_properties(0)
    observed = canonical_uuid(getattr(props, 'uuid', None))
    if observed != expected or props.name != H100_NAME:
        raise RuntimeError('actual CUDA UUID or H100 model differs from allocation')
    free, total = torch.cuda.mem_get_info(0)
    if free < MIN_FREE_BYTES or total < MIN_FREE_BYTES:
        raise RuntimeError('insufficient observed free CUDA memory for bounded BF16 pilot')
    return props, observed, int(free), int(total)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--allocation-receipt', type=Path, required=True)
    parser.add_argument('--numerics-policy', type=Path, required=True)
    parser.add_argument('--device', choices=['cuda:0'], required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    sample, prompt, continuation = check_input(args.input)
    allocation_raw = args.allocation_receipt.read_bytes()
    allocation = json.loads(allocation_raw)
    check_allocation(allocation)
    metadata_raw = (HERE / 'upstream-identity.json').read_bytes()
    policy_raw = args.numerics_policy.read_bytes()
    if sha256(metadata_raw) != METADATA_SHA256 or sha256(policy_raw) != POLICY_SHA256:
        raise ValueError('pinned metadata or CUDA numerical policy changed')
    policy = json.loads(policy_raw)
    import torch
    import numpy
    import transformers
    from transformers import AutoModelForMultimodalLM
    stack = {'torch': str(torch.__version__), 'transformers': str(transformers.__version__),
             'cuda_runtime': str(torch.version.cuda), 'numpy': str(numpy.__version__)}
    check_stack(stack)
    props, physical, free, total = check_device(torch, allocation)
    rng = seed_and_check(torch, numpy, policy)
    args.output.mkdir(parents=True, exist_ok=False)
    snapshot_receipt = verify(args.model, json.loads(metadata_raw))
    snapshot_receipt['upstream_metadata_sha256'] = METADATA_SHA256
    write_json(args.output / 'snapshot-verification.json', snapshot_receipt)
    if snapshot_receipt['status'] != 'verified':
        raise RuntimeError('local eight-file snapshot failed complete verification')
    identity_hash = sha256((args.output / 'snapshot-verification.json').read_bytes())
    model = AutoModelForMultimodalLM.from_pretrained(str(args.model), revision=REVISION,
        local_files_only=True, dtype=torch.bfloat16, attn_implementation='eager')
    if getattr(model.config, 'model_type', None) != 'gemma4_unified':
        raise RuntimeError('loaded model is not Gemma 4 Unified')
    observed_commit = getattr(model.config, '_commit_hash', None)
    if observed_commit and observed_commit.lower() != REVISION:
        raise RuntimeError('loaded config revision differs from pinned revision')
    model = model.to(args.device).eval()
    dtypes = sorted({str(p.dtype) for p in model.parameters()})
    attention = getattr(model.config, '_attn_implementation', None)
    if dtypes != ['torch.bfloat16'] or attention != 'eager':
        raise RuntimeError('actual model parameter dtype or attention differs from BF16/eager')
    after_load = math_policy(torch)
    write_json(args.output / 'math-policy-after-load.json', after_load)
    check_policy(after_load, policy)
    runtime = dict(model_argument=str(args.model), model_repository='google/gemma-4-12B',
        requested_revision=REVISION, observed_config_commit=observed_commit,
        identity_receipt_sha256=identity_hash,
        identity_receipt_verification='complete snapshot file verification; runtime-loaded bytes not independently proven',
        input_sha256=INPUT_SHA256, model_class=type(model).__name__, model_type=model.config.model_type,
        device_argument=args.device, visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
        device_name=props.name, device_total_memory=total, device_uuid=physical,
        free_bytes_before_load=free, allocation_receipt_sha256=sha256(allocation_raw),
        torch=stack['torch'], transformers=stack['transformers'], cuda_runtime=stack['cuda_runtime'],
        numpy=stack['numpy'], python=sys.version, python_executable=sys.executable,
        torch_file=str(torch.__file__), transformers_file=str(transformers.__file__),
        requested_dtype='bfloat16', requested_attention='eager', actual_attention=attention,
        parameter_dtypes=dtypes, logprob_dtype='float64', rng_and_math_policy=rng,
        numerics_policy_sha256=POLICY_SHA256, execution='single-device native forward, eval/inference_mode',
        limitations=['text-only fixed discovery request', 'supplied allocation is not independently authenticated',
                      'snapshot verification does not attest loader-consumed bytes', 'no numerical acceptance threshold'])
    write_json(args.output / 'runtime.json', runtime)
    capture(model, torch, args.device, sample, prompt, continuation, args.output, 'float64')
    torch.cuda.synchronize(0)
    after = math_policy(torch)
    write_json(args.output / 'math-policy-after.json', after)
    check_policy(after, policy)
    write_json(args.output / 'status.json', {'status': 'completed', 'rank': 0,
        'scope': 'H100 Torch 2.9 single-device fixed-history candidate; not model-wide acceptance'})


if __name__ == '__main__':
    main()

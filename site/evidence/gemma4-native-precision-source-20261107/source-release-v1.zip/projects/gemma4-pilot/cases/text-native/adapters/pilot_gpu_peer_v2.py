"""Single-device, fixed-history native Transformers inference integration pilot.

This is case-local integration code, not an accepted model evaluation.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import argparse
import os
import random
import hashlib
import json
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(REPO / 'skills' / 'precision-compare' / 'scripts'))
from inference_capture import FixedHistory, export_records, validate_history


def write_json(path, value):
    with path.open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')


def parse_input(path):
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    sample, prompt, continuation = data['sample'], data['prompt'], data['continuation']
    if not isinstance(sample, str) or not sample.strip():
        raise ValueError('sample must be a nonempty string')
    for name, tokens in [('prompt', prompt), ('continuation', continuation)]:
        if not isinstance(tokens, list) or not tokens or any(type(x) is not int or x < 0 for x in tokens):
            raise ValueError(f'{name} must be a nonempty list of nonnegative integer token IDs')
    return sample, prompt, continuation


def capture(model, torch, device, sample, prompt, continuation, output, logprob_dtype):
    """Run one unpadded prompt and fixed continuation; preserve native cache."""
    history = FixedHistory(sample, prompt, continuation, logprob_dtype=logprob_dtype)
    records, events, cache, shapes = [], [], None, []
    with torch.inference_mode():
        for step in range(len(continuation)):
            ids = prompt if step == 0 else [continuation[step - 1]]
            positions = list(range(len(prompt))) if step == 0 else [len(prompt) + step - 1]
            prefix_length = 0 if step == 0 else len(prompt) + step - 1
            kwargs = dict(input_ids=torch.tensor([ids], dtype=torch.long, device=device),
                          attention_mask=torch.ones((1, prefix_length + len(ids)), dtype=torch.long, device=device),
                          position_ids=torch.tensor([positions], dtype=torch.long, device=device),
                          use_cache=True, return_dict=True)
            if step:
                kwargs['past_key_values'] = cache
            result = model(**kwargs)
            if result.past_key_values is None:
                raise RuntimeError('native forward did not return a cache')
            cache = result.past_key_values
            logits = result.logits
            if len(logits.shape) != 3 or logits.shape[0] != 1 or logits.shape[1] != len(ids):
                raise RuntimeError(f'unexpected native logits shape: {tuple(logits.shape)}')
            shapes.append(list(logits.shape))
            # The shared helper mutates its row to force a token. Clone to preserve
            # the native model output; this adapter feeds fixed IDs explicitly.
            row = logits[0, -1, :].clone()
            records.append(history.capture_and_force(row, output / f'row-{step:03d}'))
            events.append(dict(stage='prefill' if step == 0 else 'decode',
                               input_ids=ids, positions=positions, prefix_length=prefix_length))
    checked = validate_history(prompt, continuation, events)
    exported = export_records(records, output)
    write_json(output / 'events.json', events)
    write_json(output / 'exported-records.json', exported)
    write_json(output / 'capture-summary.json', dict(history_validation=checked,
        native_logits_shapes=shapes, unavailable_targets=exported['unavailable_targets'],
        cache_type=type(cache).__name__, sampled_distributions=len(records)))
    return exported


def math_policy(torch):
    """Read actual backend flags without changing them."""
    return {
        'deterministic_algorithms': bool(torch.are_deterministic_algorithms_enabled()),
        'deterministic_warn_only': bool(torch.is_deterministic_algorithms_warn_only_enabled()),
        'cudnn_deterministic': bool(torch.backends.cudnn.deterministic),
        'cudnn_benchmark': bool(torch.backends.cudnn.benchmark),
        'cuda_matmul_allow_tf32': bool(torch.backends.cuda.matmul.allow_tf32),
        'cudnn_allow_tf32': bool(torch.backends.cudnn.allow_tf32),
        'float32_matmul_precision': torch.get_float32_matmul_precision(),
        'cublas_workspace_config': os.environ.get('CUBLAS_WORKSPACE_CONFIG'),
        'pythonhashseed': os.environ.get('PYTHONHASHSEED'),
    }
def check_policy(actual, policy):
    if (not isinstance(policy, dict) or set(policy) != set(actual)
            or json.dumps(policy, sort_keys=True, allow_nan=False) != json.dumps(actual, sort_keys=True, allow_nan=False)):
        raise ValueError('actual deterministic/TF32 settings differ from frozen numerics policy: ' + json.dumps(actual, sort_keys=True))


def seed_and_check(torch, numpy, policy):
    """Set the frozen matmul policy, reset RNGs, and check all settings."""
    before = math_policy(torch)
    torch.set_float32_matmul_precision('highest')
    torch.backends.cuda.matmul.allow_tf32 = False
    random.seed(0)
    numpy.random.seed(0)
    torch.manual_seed(0)
    torch.cuda.manual_seed_all(0)
    actual = math_policy(torch)
    check_policy(actual, policy)
    return {'seed': 0, 'python_random_seed': 0, 'numpy_seed': 0,
            'torch_initial_seed': int(torch.initial_seed()),
            'cuda_initial_seed': int(torch.cuda.initial_seed()),
            'settings_before_configuration': before, 'settings': actual,
            'policy_action': "set_float32_matmul_precision('highest'); cuda.matmul.allow_tf32=False; other flags unchanged"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', required=True, help='Explicit model repository or local snapshot path')
    parser.add_argument('--revision', required=True, help='Immutable 40-hex model revision, also for local snapshot')
    parser.add_argument('--identity-receipt', required=True, type=Path, help='Existing case-owned checkpoint/config/tokenizer identity receipt')
    parser.add_argument('--input', required=True, type=Path, help='Frozen token IDs JSON')
    parser.add_argument('--output', required=True, type=Path, help='New, nonexistent artifact directory')
    parser.add_argument('--device', required=True, help='Explicit assigned CUDA device, e.g. cuda:0')
    parser.add_argument('--dtype', required=True, choices=['bfloat16', 'float32', 'float16'])
    parser.add_argument('--attention', required=True, help='Transformers attention implementation')
    parser.add_argument('--numerics-policy', required=True, type=Path)
    parser.add_argument('--numerics-policy-sha256', required=True)
    parser.add_argument('--logprob-dtype', choices=['float32', 'float64'], default='float32')
    parser.add_argument('--local-files-only', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch(r'[0-9a-fA-F]{40}', args.revision):
        parser.error('--revision must be a full 40-hex immutable revision')
    if not re.fullmatch(r'[0-9a-fA-F]{64}', args.numerics_policy_sha256):
        parser.error('--numerics-policy-sha256 must be 64 hex characters')
    policy_bytes = args.numerics_policy.read_bytes()
    if hashlib.sha256(policy_bytes).hexdigest() != args.numerics_policy_sha256.lower():
        raise ValueError('numerics policy SHA-256 mismatch')
    policy = json.loads(policy_bytes)
    if not re.fullmatch(r'cuda:[0-9]+', args.device):
        parser.error('--device must be an explicit cuda:N device')
    input_bytes, receipt_bytes = args.input.read_bytes(), args.identity_receipt.read_bytes()
    json.loads(receipt_bytes)
    sample, prompt, continuation = parse_input(args.input)
    import torch
    import numpy
    import transformers
    from transformers import AutoModelForMultimodalLM
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; no model execution performed')
    index = int(args.device.split(':')[1])
    if index >= torch.cuda.device_count():
        raise RuntimeError('specified CUDA ordinal is not visible')
    rng = seed_and_check(torch, numpy, policy)
    args.output.mkdir(parents=True, exist_ok=False)
    model = AutoModelForMultimodalLM.from_pretrained(
        args.model, revision=args.revision, local_files_only=args.local_files_only,
        dtype=getattr(torch, args.dtype), attn_implementation=args.attention)
    if getattr(model.config, 'model_type', None) != 'gemma4_unified':
        raise RuntimeError('loaded model is not Gemma 4 Unified; no substitute is allowed')
    observed_commit = getattr(model.config, '_commit_hash', None)
    if observed_commit and observed_commit.lower() != args.revision.lower():
        raise RuntimeError('loaded config commit differs from requested revision')
    model = model.to(args.device).eval()
    after_load_policy = math_policy(torch)
    write_json(args.output / 'math-policy-after-load.json', after_load_policy)
    check_policy(after_load_policy, policy)
    props = torch.cuda.get_device_properties(index)
    info = dict(model_argument=args.model, requested_revision=args.revision,
        observed_config_commit=observed_commit, identity_receipt_sha256=hashlib.sha256(receipt_bytes).hexdigest(),
        identity_receipt_verification='NOT PERFORMED by this adapter',
        input_sha256=hashlib.sha256(input_bytes).hexdigest(), model_class=type(model).__name__,
        model_type=model.config.model_type, device_argument=args.device,
        visible_devices=__import__('os').environ.get('CUDA_VISIBLE_DEVICES'),
        device_name=props.name, device_total_memory=props.total_memory,
        device_uuid=str(getattr(props, 'uuid', None)), torch=torch.__version__,
        transformers=transformers.__version__, cuda_runtime=torch.version.cuda,
        requested_dtype=args.dtype, requested_attention=args.attention,
        actual_attention=getattr(model.config, '_attn_implementation', None),
        parameter_dtypes=sorted({str(p.dtype) for p in model.parameters()}),
        logprob_dtype=args.logprob_dtype, rng_and_math_policy=rng,
        numerics_policy_sha256=args.numerics_policy_sha256.lower(),
        execution='single-device native forward, eval/inference_mode',
        limitations=['text only', 'single request', 'cache-on fixed history only',
                     'identity receipt not independently verified', 'no numerical acceptance criterion'])
    write_json(args.output / 'runtime.json', info)
    capture(model, torch, args.device, sample, prompt, continuation, args.output, args.logprob_dtype)
    after_policy = math_policy(torch)
    write_json(args.output / 'math-policy-after.json', after_policy)
    check_policy(after_policy, policy)
    write_json(args.output / 'status.json', {'status': 'completed', 'rank': 0,
        'scope': 'integration pilot only; not complete model evaluation'})


if __name__ == '__main__':
    main()

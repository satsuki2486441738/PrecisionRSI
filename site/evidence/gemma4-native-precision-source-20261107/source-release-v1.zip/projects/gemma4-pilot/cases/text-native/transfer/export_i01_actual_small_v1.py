"""Export successful I01 numeric metadata and six portable I03 proof documents.

Stdlib only. Arrays and transport/model archives are never opened or copied.
This exports the prior numeric result; it performs no numeric/model replay.
"""
import argparse
import base64
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path,PurePosixPath
import re
import signal
import tarfile
import time

STAGE_SHA='5aa7d50bb472aab82108ad6711fdd6c5bdd4780bbecb27cdf78c734d13093c05'
MAIN_SHA='f7fe91cdcebeec910efed4579ecf379fd665cf305223a3fa77858004db81858a'
RUNNER_SHA='ce0293116b5914e7b85088971ec1c36bd7cebfe216c6f7289cb42fa19c1f32c3'
TOOL_SHA='5b9db322209a56a21acba8afcc7bb1ad8b1d903e9b8a321fbe442d294a13d902'
MAX_SMALL=4*1024**2
MAX_TOTAL=64*1024**2
HEX=re.compile(r'^[a-f0-9]{64}$')


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def load(path):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)


def put(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def flag(argv,name):
    require(isinstance(argv,list) and argv.count(name)==1 and not any(x.startswith(name+'=') for x in argv),'ambiguous argv '+name)
    index=argv.index(name);require(index+1<len(argv),'missing argv '+name);return argv[index+1]


def completed(document):
    require(document.get('status')=='completed' and type(document.get('returncode')) is int and document['returncode']==0,
        'actual controller must be completed0')


def verify_controller(controller_path):
    controller_path=Path(controller_path);state=load(controller_path);completed(state)
    require(state.get('task')=='I01' and state.get('native_executions_started')==0 and state.get('acceptance') is None and
        state.get('tool_manifest_sha256')==TOOL_SHA,'wrong successful offline I01 controller')
    run=controller_path.parent
    require(state['run']==str(run) and len(state['steps'])==1,'controller actual run/step inventory differs')
    step=state['steps'][0];require(step['step']=='01-independent-compare' and type(step['returncode']) is int and step['returncode']==0 and
        step['timed_out'] is False and step['timeout_seconds']==620,'bounded numeric child did not complete0')
    argv=step['argv'];require(len(argv)>3 and argv[1]=='-B' and sha(argv[2])==MAIN_SHA,'actual independent analysis source differs')
    spec_ref=state['comparison_spec'];report_ref=state['report']
    require(Path(spec_ref['path'])==run/'comparison-spec.json' and Path(report_ref['path'])==run/'bundle/i01-comparison-report.json' and
        sha(spec_ref['path'])==spec_ref['sha256'] and sha(report_ref['path'])==report_ref['sha256'],'controller input/result path/SHA differs')
    require(flag(argv,'--spec')==spec_ref['path'] and flag(argv,'--spec-sha256')==spec_ref['sha256'] and
        flag(argv,'--output-dir')==str(run/'bundle') and flag(argv,'--timeout-seconds')=='600','direct analysis argv differs')
    for key in ('stdout','stderr'):
        ref=step[key];path=Path(ref['path'])
        require(path==run/('01-independent-compare.'+key) and path.stat().st_size==ref['bytes'] and sha(path)==ref['sha256'],
            'actual numeric log identity differs')
    spec=load(spec_ref['path']);report=load(report_ref['path'])
    require(spec['stage_spec_sha256']==STAGE_SHA and report['stage_spec_sha256']==STAGE_SHA and report['comparison_spec_sha256']==spec_ref['sha256'] and
        report['status']=='i01_raw_bf16_and_scoped_comparisons_checked' and report['thresholds'] is None and report['acceptance'] is None and
        report['full_core_complete'] is False,'actual numeric result identity differs')
    scope=report['scope'];require(scope['independent_inputs']==1 and scope['new_repeatability_measured'] is False and scope['full_targets_per_backend']==159 and
        scope['full_distribution_positions_per_backend']==47 and scope['old_cached_continuation_targets_only']==32 and scope['historical_peer_comparisons']==6,
        'actual numeric scope differs')
    require(report['native_executions_started_by_admission']==0 and set(report['raw_derivation'])=={'GPU','NPU'} and
        report['offline_tool_source_sha256']['i01_admission_compare_v1.py']==MAIN_SHA,'actual raw admission/source proof differs')
    for proof in report['raw_derivation'].values():
        require(HEX.fullmatch(proof['raw_sha256']) and HEX.fullmatch(proof['manifest_sha256']) and
            type(proof['largest_abs_logprob_derivation_delta']) in (int,float) and 0<=proof['largest_abs_logprob_derivation_delta']<=1e-12,
            'actual independent raw BF16 derivation proof differs')
    pairs=[report['cross_backend'],*report['historical_cached_peer_contrasts']];require(len(pairs)==7,'actual comparison pair inventory differs')
    for index,pair in enumerate(pairs):
        targets,positions=(159,47) if index==0 else (32,32)
        require(pair['targets']['status']==pair['distributions']['status']=='no_thresholds' and pair['targets']['coverage']=={'expected':targets,'paired':targets} and
            pair['distributions']['position_count']==positions and pair['thresholds'] is None and pair['acceptance'] is None,'actual pair result scope differs')
    stdout=load(step['stdout']['path']);require(stdout['status']==report['status'] and stdout['cross_targets']==159 and stdout['cross_positions']==47 and
        stdout['cached_peer_contrasts']==6 and stdout['native_executions_started']==0 and stdout['acceptance'] is None,'numeric stdout/report differs')
    return state,spec,report


class Catalog:
    def __init__(self,output):self.output=output;self.files={};self.omitted={};self.total=0
    def add(self,path,expected=None,role='metadata'):
        path=Path(path);original=str(path)
        require(path.is_absolute() and '\\' not in original and '..' not in PurePosixPath(original).parts,'absolute original POSIX source required')
        # Deliberately classify BEFORE stat/open/hash: arrays may be unavailable.
        if path.suffix in ('.npy','.safetensors','.tar','.gz','.whl'):
            self.omitted.setdefault(original,{'sha256':expected,'reason':'array_or_transport_archive_not_opened_by_metadata_export'})
            return
        require(path.is_file() and not path.is_symlink() and path.stat().st_size<=MAX_SMALL,'small regular metadata source required: '+original)
        digest=sha(path);require(expected is None or digest==expected,'actual metadata source SHA differs: '+original)
        if original in self.files:require(self.files[original]['sha256']==digest,'same original path has conflicting metadata');return
        self.total+=path.stat().st_size;require(self.total<=MAX_TOTAL,'metadata source budget64MiB exceeded')
        relative='payload/%04d/%s'%(len(self.files),path.name);target=self.output/relative;target.parent.mkdir(parents=True)
        raw=path.read_bytes();require(hashlib.sha256(raw).hexdigest()==digest,'metadata source changed before copy')
        with target.open('xb') as stream:stream.write(raw)
        self.files[original]={'path':relative,'sha256':digest,'size':len(raw),'role':role}
    def endpoint(self,reference):
        mapping=Path(reference['path']);self.add(mapping,reference['sha256'],'original_endpoint_map');doc=load(mapping)
        for original,ref in doc['files'].items():
            require(PurePosixPath(original).is_absolute() and '\\' not in original and '..' not in PurePosixPath(original).parts and
                type(ref.get('size')) is int and ref['size']>=0 and isinstance(ref.get('sha256'),str) and HEX.fullmatch(ref['sha256']),'invalid endpoint source descriptor')
            if PurePosixPath(original).suffix in ('.npy','.safetensors'):
                previous=self.omitted.get(original);entry={'sha256':ref['sha256'],'size':ref['size'],'reason':'native_array_not_opened_by_metadata_export'}
                require(previous is None or previous['sha256']==entry['sha256'],'original array hash conflict across endpoint maps')
                self.omitted[original]=entry;continue
            require('path' in ref and not ref.get('retained_at_source'),'small endpoint metadata must have copied bytes')
            relative=PurePosixPath(ref['path']);require(not relative.is_absolute() and '..' not in relative.parts and '\\' not in ref['path'],'endpoint copied metadata path escapes')
            actual=(mapping.parent/str(relative)).resolve(strict=True);require(actual.is_relative_to(mapping.parent.resolve()) and actual.stat().st_size==ref['size'],
                'mapped metadata size/path differs')
            self.add(actual,ref['sha256'],'verbatim_endpoint_payload')
    def close(self):
        for original,ref in self.files.items():require(sha(original)==ref['sha256'] and sha(self.output/ref['path'])==ref['sha256'],'metadata source/copy changed')


def package(folder,archive,max_bytes=16*1024**2):
    with archive.open('xb') as destination,tarfile.open(fileobj=destination,mode='w:gz') as tar:
        for path in sorted(folder.rglob('*')):
            require(not path.is_symlink(),'metadata package contains symlink')
            if path.is_file():tar.add(path,arcname=path.relative_to(folder).as_posix(),recursive=False)
    require(archive.stat().st_size<=max_bytes,'compressed metadata archive exceeds16MiB')
    return {'basename':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)}


def export(controller,selection_receipt,output):
    controller=Path(controller).resolve(strict=True);output=Path(output).resolve()
    require(not output.exists() and output.parent.is_dir(),'exclusive new metadata output required')
    state,spec,report=verify_controller(controller);output.mkdir(mode=0o700);catalog=Catalog(output)
    catalog.add(Path(__file__).resolve(),role='metadata_exporter_source')
    for path in sorted(controller.parent.rglob('*')):
        if path.is_file():catalog.add(path,role='actual_numeric_controller_and_frozen_documents')
    for index,pair in enumerate([report['cross_backend'],*report['historical_cached_peer_contrasts']]):
        # Derive the directory from actual comparator sources, not a guessed side spelling.
        folder=Path(pair['targets']['sources']['contract']).parent
        require(folder.resolve().is_relative_to((controller.parent/'bundle').resolve()),'frozen pair document directory escapes run')
        for name,digest in pair['frozen_document_sha256'].items():catalog.add(folder/name,digest,'frozen_pair_document')
    tools=Path(state['tools_root']);manifest=tools/'tool-bundle-manifest.json';catalog.add(manifest,TOOL_SHA,'actual_tool_manifest')
    for name,ref in load(manifest)['files'].items():catalog.add(tools/name,ref['sha256'],'frozen_offline_tool_source')
    for category in ('GPU','NPU'):catalog.endpoint(spec['endpoints'][category]['source_map'])
    for key in ('gpu_map','npu_map'):catalog.endpoint(spec['old_cached'][key])
    for key in ('admission','gate'):ref=spec['old_cached'][key];catalog.add(ref['path'],ref['sha256'],'original_cached_numeric_admission')
    selection_receipt=Path(selection_receipt).resolve(strict=True);selected=load(selection_receipt)
    require(selected['status']=='ready_to_execute_frozen_cpu_controller' and selected['returncode']==0 and selected['tools_root']==str(tools) and
        selected['gpu_source_map_sha256']==spec['endpoints']['GPU']['source_map']['sha256'] and
        selected['npu_source_map_sha256']==spec['endpoints']['NPU']['source_map']['sha256'],'original machine endpoint selection differs')
    for path in sorted(selection_receipt.parent.iterdir()):
        if path.is_file():catalog.add(path,role='actual_endpoint_selection')
    for original,digest in selected['checked_source_sha256'].items():catalog.add(original,digest,'selection_import_and_export_provenance')
    proof=output/'i03-prerequisite';(proof/'proof').mkdir(parents=True)
    originals={'controller':('i01-controller.json',controller),'report':('i01-report.json',Path(state['report']['path'])),
        'comparison_spec':('i01-comparison-spec.json',Path(state['comparison_spec']['path'])),
        'analysis_source':('i01_admission_compare_v1.py',Path(state['steps'][0]['argv'][2])),
        'GPU':('gpu-source-map.json',Path(spec['endpoints']['GPU']['source_map']['path'])),
        'NPU':('npu-source-map.json',Path(spec['endpoints']['NPU']['source_map']['path']))}
    refs={}
    for key,(name,path) in originals.items():
        target=proof/'proof'/name;raw=path.read_bytes()
        with target.open('xb') as stream:stream.write(raw)
        refs[key]={'path':'proof/'+name,'source_path':str(path),'sha256':sha(path)}
        require(sha(target)==refs[key]['sha256'],'portable original proof bytes differ')
    prerequisite={'schema_version':1,'kind':'i03-i01-numeric-prerequisite','prior_stage_sha256':STAGE_SHA,
        **{key:refs[key] for key in ('controller','report','comparison_spec','analysis_source')},'source_maps':{key:refs[key] for key in ('GPU','NPU')}}
    put(proof/'prerequisite.json',prerequisite);catalog.close()
    require(sum(name.endswith('.npy') for name in catalog.omitted)==286 and sum(name.endswith('.safetensors') for name in catalog.omitted)==2,
        'expected old192 +new94 NPY and2 raw native objects were not all inventoried without reads')
    metadata={'schema_version':1,'kind':'i01-actual-numeric-small-export','controller':str(controller),'controller_sha256':sha(controller),
        'report':state['report'],'comparison_spec':state['comparison_spec'],'files':catalog.files,'omitted':catalog.omitted,
        'generated_files':{path.relative_to(output).as_posix():{'sha256':sha(path),'size':path.stat().st_size} for path in sorted(proof.rglob('*')) if path.is_file()},
        'arrays_opened_or_copied':0,'numeric_replay_performed_by_exporter':False,'acceptance':None}
    put(output/'metadata-source-map.json',metadata)
    full_archive=output.with_name(output.name+'.tar.gz');portable_archive=output.with_name(output.name+'-i03-prerequisite.tar.gz')
    portable=package(proof,portable_archive);full=package(output,full_archive);catalog.close()
    for name,ref in metadata['generated_files'].items():require(sha(output/name)==ref['sha256'],'portable proof changed during packaging')
    envelope=output.with_name(output.name+'-json-base64.txt')
    put(envelope,{'schema_version':1,'kind':'i01-actual-small-archives','archives':[{**ref,'base64':base64.b64encode(path.read_bytes()).decode('ascii')}
        for ref,path in ((full,full_archive),(portable,portable_archive))]})
    require(envelope.stat().st_size<=32*1024**2,'JSONbase64 envelope exceeds32MiB')
    result={'status':'i01_actual_small_export_completed','controller_sha256':sha(controller),'report_sha256':state['report']['sha256'],
        'metadata_source_map_sha256':sha(output/'metadata-source-map.json'),'copied_metadata_files':len(catalog.files),
        'omitted_npy_files':286,'omitted_raw_native_files':2,'arrays_opened_or_copied':0,'archives':[full,portable],
        'prerequisite_path':str(proof/'prerequisite.json'),'prerequisite_sha256':sha(proof/'prerequisite.json'),
        'json_base64_path':str(envelope),'json_base64_bytes':envelope.stat().st_size,'json_base64_sha256':sha(envelope),
        'native_executions_started':0,'acceptance':None}
    put(output.with_name(output.name+'-export-receipt.json'),result);return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--controller',type=Path,required=True)
    parser.add_argument('--selection-receipt',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    def expire(*_):raise TimeoutError('I01 small metadata exporter240s deadline reached')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,240)
    try:print(json.dumps(export(args.controller,args.selection_receipt,args.output),indent=2),flush=True)
    except BaseException as exc:
        failure=args.output.with_name(args.output.name+'-export-failure.json')
        if failure.parent.is_dir() and not failure.exists():put(failure,{'status':'failed','error_type':type(exc).__name__,'error':str(exc),
            'partial_output_preserved':True,'automatic_retry':False,'native_executions_started':0})
        raise
    finally:signal.setitimer(signal.ITIMER_REAL,0)


if __name__=='__main__':main()

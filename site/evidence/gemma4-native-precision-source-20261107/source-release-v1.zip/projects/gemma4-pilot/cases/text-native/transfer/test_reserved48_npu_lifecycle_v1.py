"""Archived NPU idle-table and parent-bound internal-entry CPU fixtures."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import reserved48_stage_contract_v1 as c
import reserved48_npu_lifecycle_v1 as n

HERE=Path(__file__).resolve().parent


class NPU(unittest.TestCase):
    def test_unready_normal_worker_and_probe_routes_do_not_query_or_create(self):
        with patch.object(Path,'read_bytes',side_effect=AssertionError('unready source IO')):
            with self.assertRaisesRegex(ValueError,'unready'):n.contract()
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)/'absent'
            for mode in ([],['--internal-worker'],['--internal-probe']):
                argv=[sys.executable,'-S','-B',n.__file__,'--config',str(root),'--config-sha256','0'*64,'--prompt-bin','2048',*mode]
                if mode:argv+=['--claim',str(root)]
                result=subprocess.run(argv,capture_output=True,timeout=15)
                self.assertNotEqual(result.returncode,0);self.assertIn(b'unready',result.stderr);self.assertFalse(root.exists())

    def test_archived_all_board_parser_keeps_unknown_or_busy_shared_process_refused(self):
        helper=c.load_module(HERE/'npu_i03_launcher_v1.py',n.IDLE_HELPER_SHA,'_reserved48_idle_fixture_pure_parser')
        archived=(HERE/'i01-readiness-20261106-a-npu-smi.stdout').read_bytes()
        self.assertEqual(helper.process_gate(archived)['status'],'explicitly_empty')
        for raw in (b'partial table',archived.replace(b'No running processes found in NPU 0',b'0 12345 python 2048')):
            with self.assertRaises(ValueError):helper.process_gate(raw)

    def test_idle_guard_only_uses_reviewed_absolute_CLI_and_preserves_stdout_on_refusal(self):
        with tempfile.TemporaryDirectory() as td:
            claim=Path(td);ctx={'document':{'npu_smi':{'path':'/srv/precision-user/.local/bin/npu-smi','sha256':n.SMI_SHA}}}
            idle=SimpleNamespace(smi_identity=lambda *_:{'sha256':n.SMI_SHA},process_gate=lambda raw:(_ for _ in ()).throw(ValueError('shared PID present')))
            result=SimpleNamespace(returncode=0,stdout=b'archived busy PID fixture',stderr=b'')
            with patch.object(subprocess,'run',return_value=result) as run:
                with self.assertRaisesRegex(ValueError,'shared PID'):n.idle_observation(c,idle,ctx,claim,1)
            self.assertEqual(run.call_count,1);self.assertEqual(run.call_args.args[0],['/srv/precision-user/.local/bin/npu-smi','info'])
            self.assertEqual((claim/'process-1.stdout').read_bytes(),result.stdout);self.assertFalse((claim/'process-1.json').exists())

    def test_direct_probe_guard_precedes_helper_import_or_native_probe(self):
        with patch.object(c,'worker_guard',side_effect=ValueError('wrong parent')),patch.object(n,'helpers',side_effect=AssertionError('native helper loaded')):
            with self.assertRaisesRegex(ValueError,'wrong parent'):n.native_probe(c,{},Path('not-created'))

    def test_CPU_protocol_does_not_inherit_injected_python_or_enable_backend_autoload(self):
        with patch.dict(os.environ,{'PYTHONPATH':'injected','PYTHONHOME':'injected','ASCEND_RT_VISIBLE_DEVICES':'fixture'}):env=n.clean_environment()
        self.assertNotIn('PYTHONPATH',env);self.assertNotIn('PYTHONHOME',env)
        self.assertEqual(env['ASCEND_RT_VISIBLE_DEVICES'],'fixture');self.assertEqual(env['TORCH_DEVICE_BACKEND_AUTOLOAD'],'0')


if __name__=='__main__':unittest.main()

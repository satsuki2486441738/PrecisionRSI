"""Stage bounded I04 single-member TAR wrappers and restore original gzip bytes.

Manifest/byte pins are supplied from an actual completed GPU export. No native
model execution, numerical admission or raw-receipt rewriting is performed.
"""
import argparse
from datetime import datetime,timezone
import hashlib
import json
import math
import os
from pathlib import Path,PurePosixPath
import re
import shutil
import signal
import tarfile
import time

STAGE_SHA='26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
CPU_SHA='8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec'
CHUNK_DATA=256*1024**2-64*1024
WRAPPER_CAP=256*1024**2
LOGICAL_CAP,ENCODED_CAP,DISK_CAP,MIN_FREE=1152*1024**2,1536*1024**2,4*1024**3,5*1024**3
METADATA_RESERVE=8*1024**2
HEX=re.compile(r'^[a-f0-9]{64}$')


def require(ok,message):
    if not ok:raise ValueError(message)


def utc():return datetime.now(timezone.utc).isoformat()


def sha(path,deadline=None):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):
            require(deadline is None or time.monotonic()<deadline,'CPU transport deadline reached');h.update(block)
    return h.hexdigest()


def parse(raw):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=reject)


def read(path):return parse(Path(path).read_bytes())


def put(path,doc):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(doc,stream,indent=2,allow_nan=False);stream.write('\n')


def safe(name):
    require(isinstance(name,str) and name and '\\' not in name,'canonical relative path required');p=PurePosixPath(name)
    require(not p.is_absolute() and str(p)==name and all(v not in ('','.','..') for v in name.split('/')),'relative path escapes root');return p


def regular(path):
    path=Path(path);require(path.is_file() and not path.is_symlink() and path.stat().st_nlink==1,'one-link original regular file required');return path


def tar_size(size):return ((512+((size+511)//512)*512+1024+10239)//10240)*10240


def accounting(archive_bytes,logical_bytes,parts):
    wire=sum(p['wrapper_size_bytes'] for p in parts)
    return {'chunk_data_bytes':archive_bytes,'wrapper_wire_bytes':wire,'wrapper_header_padding_bytes':wire-archive_bytes,
        'logical_payload_bytes':logical_bytes,'logical_cap_bytes':LOGICAL_CAP,'encoded_cap_bytes':ENCODED_CAP,
        'staged_wrappers_plus_reconstructed_plus_expanded_bytes':wire+archive_bytes+logical_bytes,
        'metadata_reserve_bytes':METADATA_RESERVE,'transport_new_disk_cap_bytes':DISK_CAP,
        'scope':'Transport wrappers, reconstructed gzip and imported GPU payload; existing native capture/model resources are separately bounded and excluded.'}


def validate(document):
    require(document.get('schema_version')==1 and document.get('kind')=='i04-gpu-archive-tar-chunks' and document.get('stage_spec_sha256')==STAGE_SHA and
        document.get('cpu_prerequisite_sha256')==CPU_SHA and document.get('original_gzip_bytes_preserved') is True and
        document.get('native_executions_started')==0 and document.get('numeric_admission_performed') is False and document.get('acceptance') is None,
        'I04 transport task/proof/non-numeric scope differs')
    archive=document['archive'];name=archive['basename'];size=archive['size_bytes'];logical=document['logical_payload_bytes']
    require(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,180}\.tar\.gz',name) and type(size) is int and 0<size<=ENCODED_CAP and HEX.fullmatch(archive['sha256']) and
        type(logical) is int and 0<logical<=LOGICAL_CAP and HEX.fullmatch(document['source_map_sha256']) and
        document['chunk_data_limit_bytes']==CHUNK_DATA and document['wrapper_wire_limit_bytes']==WRAPPER_CAP,'archive size/name/source-map caps differ')
    parts=document['parts'];require(isinstance(parts,list) and len(parts)==math.ceil(size/CHUNK_DATA) and 1<=len(parts)<=7,'exact bounded chunk inventory required')
    offset=0
    for index,part in enumerate(parts):
        count=min(CHUNK_DATA,size-offset);expected={'index':index,'offset':offset,'data_size_bytes':count,'member_name':'chunk-%04d.bin'%index,
            'wrapper_basename':name[:-7]+'-transport-%04d.tar'%index,'wrapper_size_bytes':tar_size(count)}
        require(set(part)==set(expected)|{'data_sha256','wrapper_sha256'} and all(type(part[k]) is type(v) and part[k]==v for k,v in expected.items()) and
            all(isinstance(part[k],str) and HEX.fullmatch(part[k]) for k in ('data_sha256','wrapper_sha256')) and part['wrapper_size_bytes']<=WRAPPER_CAP,
            'chunk index/coverage/member/size/hash differs')
        offset+=count
    require(offset==size,'archive chunk gap or overlap')
    expected=accounting(size,logical,parts)
    require(document['transport_accounting']==expected and expected['wrapper_wire_bytes']<=ENCODED_CAP and
        expected['staged_wrappers_plus_reconstructed_plus_expanded_bytes']+METADATA_RESERVE<=DISK_CAP,'encoded wire or new transport disk budget exceeded')
    require(document.get('assembler_sha256')==sha(__file__),'executed assembler source pin differs')
    return document


def contained(root,path):
    path=Path(path);require(path.is_absolute() and path.is_relative_to(root) and path.resolve().is_relative_to(root),'path escapes explicit R root')
    current=path
    while current!=root:require(not current.is_symlink(),'symlink in owned transport path');current=current.parent
    return path


def roots(root,subdir,manifest,manifest_sha):
    root=Path(root);require(root.is_dir() and not root.is_symlink(),'explicit existing nonsymlink R root required');root=root.resolve(strict=True)
    target=contained(root,root/str(safe(subdir)));manifest=contained(root,Path(manifest).absolute())
    require(HEX.fullmatch(manifest_sha) and regular(manifest).stat().st_size<=65536 and sha(manifest)==manifest_sha,'externally frozen manifest bytes differ')
    document=validate(read(manifest));require(shutil.disk_usage(root).free>=MIN_FREE,'observed source free storage below5GiB');return root,target,document


def verify_wrapper(path,part,deadline):
    path=regular(path);require(path.name==part['wrapper_basename'] and path.stat().st_size==part['wrapper_size_bytes'] and sha(path,deadline)==part['wrapper_sha256'],'wrapper raw bytes differ')
    with tarfile.open(path,'r:') as package:
        members=package.getmembers();require(len(members)==1,'exact one regular TAR member required');member=members[0]
        require(member.type==tarfile.REGTYPE and member.isfile() and not member.pax_headers and not member.sparse and
            member.name==part['member_name'] and member.size==part['data_size_bytes'],'wrapper member/type/size differs')
        h=hashlib.sha256();count=0
        with package.extractfile(member) as source:
            for block in iter(lambda:source.read(4*1024**2),b''):
                require(time.monotonic()<deadline,'CPU wrapper deadline reached');count+=len(block);h.update(block)
        require(count==part['data_size_bytes'] and h.hexdigest()==part['data_sha256'],'chunk data hash differs')
    return path


def tree_bytes(path):
    total=0
    for item in Path(path).rglob('*'):
        require(not item.is_symlink(),'symlink in new transport tree')
        if item.is_file():total+=item.stat().st_size
    return total


def stage(root,subdir,manifest,manifest_sha,wrapper):
    started=time.monotonic();root,target,doc=roots(root,subdir,manifest,manifest_sha);archive=doc['archive'];logical=doc['logical_payload_bytes']
    wrapper=contained(root,Path(wrapper).absolute());matches=[part for part in doc['parts'] if part['wrapper_basename']==wrapper.name]
    require(wrapper.parent==root and len(matches)==1,'fresh uploaded wrapper must be exact manifest basename in R root');part=matches[0]
    verify_wrapper(wrapper,part,started+900);target.mkdir(parents=True,exist_ok=True,mode=0o700)
    directory=target/('part-%04d'%part['index']);directory.mkdir(mode=0o700)
    put(directory/'stage-claim.json',{'claimed_utc':utc(),'manifest_sha256':manifest_sha,'source':str(wrapper),'part':part,'automatic_retry':False})
    destination=directory/part['wrapper_basename'];before=wrapper.stat();os.link(wrapper,destination)
    require(destination.stat().st_size==part['wrapper_size_bytes'] and sha(destination)==part['wrapper_sha256'],'exclusive staged link changed')
    now=wrapper.stat();require((before.st_dev,before.st_ino)==(now.st_dev,now.st_ino),'uploaded inode changed before entry removal')
    wrapper.unlink();require(destination.stat().st_nlink==1,'staged source still has another link')
    measured=tree_bytes(target);require(measured+archive['size_bytes']+logical+METADATA_RESERVE<=DISK_CAP,'measured transport/reconstruction/import cap exceeded')
    receipt={'status':'i04_wrapper_verified_and_moved','manifest_sha256':manifest_sha,'part_index':part['index'],'wrapper_sha256':part['wrapper_sha256'],
        'data_sha256':part['data_sha256'],'retained_wrapper_path':str(destination),'uploaded_source_path':str(wrapper),'source_entry_removed_after_verified_exclusive_link':True,
        'new_transport_bytes':measured,'finished_utc':utc(),'elapsed_seconds':time.monotonic()-started,'native_executions_started':0}
    put(directory/'stage-receipt.json',receipt);return receipt


def assemble(root,subdir,manifest,manifest_sha):
    started=time.monotonic();deadline=started+900;root,target,doc=roots(root,subdir,manifest,manifest_sha);archive=doc['archive'];logical=doc['logical_payload_bytes']
    require(target.is_dir(),'staged transport directory missing');output=contained(root,root/archive['basename'])
    require(not output.exists() and not output.is_symlink(),'original gzip destination/partial already exists; no overwrite or retry')
    require(tree_bytes(target)+archive['size_bytes']+logical+METADATA_RESERVE<=DISK_CAP,'new reconstruction/import budget exceeded')
    put(target/'assembly-claim.json',{'claimed_utc':utc(),'manifest_sha256':manifest_sha,'archive_sha256':archive['sha256'],'automatic_retry':False})
    state={'schema_version':1,'status':'running','started_utc':utc(),'archive':str(output),'manifest_sha256':manifest_sha,'assembler_sha256':sha(__file__),
        'cpu_timeout_seconds':900,'native_executions_started':0,'numeric_admission_performed':False,'acceptance':None}
    try:
        wrappers=[]
        for part in doc['parts']:
            directory=target/('part-%04d'%part['index']);receipt=read(regular(directory/'stage-receipt.json'))
            require(receipt.get('status')=='i04_wrapper_verified_and_moved' and receipt.get('manifest_sha256')==manifest_sha and
                receipt.get('part_index')==part['index'] and receipt.get('wrapper_sha256')==part['wrapper_sha256'],'completed exact wrapper stage receipt required')
            wrappers.append(verify_wrapper(contained(root,directory/part['wrapper_basename']),part,deadline))
        h=hashlib.sha256();written=0
        with output.open('xb') as destination:
            for path,part in zip(wrappers,doc['parts']):
                require(written==part['offset'],'gap/overlap before reconstruction');chunk=hashlib.sha256();count=0
                with tarfile.open(path,'r:') as package,package.extractfile(part['member_name']) as source:
                    for block in iter(lambda:source.read(4*1024**2),b''):
                        require(time.monotonic()<deadline,'CPU assembly deadline reached');destination.write(block);h.update(block);chunk.update(block);written+=len(block);count+=len(block)
                require(count==part['data_size_bytes'] and chunk.hexdigest()==part['data_sha256'],'chunk changed during reconstruction')
            destination.flush();os.fsync(destination.fileno())
        require(written==archive['size_bytes'] and h.hexdigest()==archive['sha256'] and output.stat().st_size==written and sha(output,deadline)==archive['sha256'],'reconstructed original gzip differs')
        require(all(sha(path,deadline)==part['wrapper_sha256'] for path,part in zip(wrappers,doc['parts'])),'staged wrapper changed')
        measured=tree_bytes(target)+written;require(measured+logical+METADATA_RESERVE<=DISK_CAP,'measured transport/import budget exceeded')
        state.update(status='i04_original_gpu_gzip_reconstructed',returncode=0,archive_bytes=written,archive_sha256=h.hexdigest(),
            source_map_sha256=doc['source_map_sha256'],transport_accounting=doc['transport_accounting'],measured_transport_and_reconstructed_bytes=measured,
            measured_plus_known_expanded_bytes=measured+logical,original_gzip_bytes_preserved=True)
    except BaseException as exc:state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),partial_files_and_claim_preserved=True,automatic_retry=False)
    finally:state.update(finished_utc=utc(),elapsed_seconds=time.monotonic()-started);put(target/'assembly-receipt.json',state)
    return state


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('mode',choices=['stage','assemble']);parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--transport-subdir',required=True);parser.add_argument('--manifest',type=Path,required=True);parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--wrapper',type=Path);args=parser.parse_args()
    def expire(*_):raise TimeoutError('I04 CPU transport900s deadline')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,900)
    try:
        if args.mode=='stage':require(args.wrapper is not None,'one uploaded wrapper required');result=stage(args.root,args.transport_subdir,args.manifest,args.manifest_sha256,args.wrapper)
        else:result=assemble(args.root,args.transport_subdir,args.manifest,args.manifest_sha256)
        print(json.dumps(result,indent=2));raise SystemExit(result.get('returncode',0))
    finally:signal.setitimer(signal.ITIMER_REAL,0)

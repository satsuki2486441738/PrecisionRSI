"""CPU package/import/controller protocol fixtures; no native or numeric replay."""
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import tarfile
import tempfile
import sys
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent


def module(path,name):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m


ops=module(HERE/'i04_compare_operations_v1.py','i04_import_protocol_fixture')
ctl=module(HERE/'run_i04_actual_compare_v1.py','i04_controller_protocol_fixture')


class Protocol(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)

    def put(self,p,d):
        p.parent.mkdir(parents=True,exist_ok=True)
        if p.exists():p.unlink()
        ops.put(p,d)

    def gpu(self):
        p=self.root/'gpu';p.mkdir();files={};original='/original/i04/runs/synthetic/artifacts'
        for i,name in enumerate(sorted(ops.LARGE)):
            relative='payload/%03d'%i;q=p/relative;q.parent.mkdir(exist_ok=True);q.write_bytes(('fixture%d'%i).encode())
            files[original+'/'+name]={'path':relative,'sha256':ops.sha(q),'size':q.stat().st_size}
        outer={'task':'I04','backend':'GPU','status':'completed','returncode':0,'timed_out':False,
            'native_capture_count':1,'native_forward_calls_total':4,'model_loads':1,'stage_spec_source_sha256':ctl.STAGE_SHA,
            'expected_inventory_source_sha256':ctl.EXPECTED_SHA,'i03_prerequisite_source_sha256':ctl.PROOF_SHA,
            'cpu_prerequisite_source_sha256':ctl.CPU_SHA,'output_dir':original,
            'validation':{'status':'i04_output_artifacts_checked','target_scores':762,'distribution_rows':282,
                'physical_raw_rows':896,'valid_raw_rows':768,'pad_only_raw_rows':128}}
        q=p/'payload/outer.json';self.put(q,outer);origin='/original/i04/claims/app-synthetic/capture-receipt.json'
        files[origin]={'path':'payload/outer.json','sha256':ops.sha(q),'size':q.stat().st_size}
        mapping={'schema_version':1,'request':{'task':'I04','backend':'GPU','outer_receipt':origin},'files':files,
            'full_array_hashes_checked':286,'retained_array_count':0,'acceptance':None}
        self.put(p/'source-map.json',mapping);self.put(p/'export-summary.json',{'synthetic_cpu_fixture':True})
        names={x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file()}
        return p,mapping,outer,names

    def test_unsafe_names_rejected(self):
        for n in ('../bad','a/../b','a//b','./a','/root','a\\b',''):
            with self.assertRaises(ValueError):ops.safe_name(n)

    def test_links_duplicates_ancestors_and_cap_rejected_before_new_directory(self):
        for kind in ('duplicate','symlink','hardlink','ancestor','size'):
            archive=self.root/(kind+'.tar');output=self.root/(kind+'-output')
            with tarfile.open(archive,'w') as t:
                for n in (['x','x'] if kind=='duplicate' else ['x','x/y'] if kind=='ancestor' else ['x']):
                    m=tarfile.TarInfo(n);m.size=2
                    if kind in ('symlink','hardlink'):m.type=tarfile.SYMTYPE if kind=='symlink' else tarfile.LNKTYPE;m.linkname='/outside';m.size=0
                    t.addfile(m,io.BytesIO(b'xx'))
            with self.assertRaises(ValueError):ops.extract(archive,output,1 if kind=='size' else 100)
            self.assertFalse(output.exists())

    def test_full286_copy_inventory_and_outer_endpoint(self):
        p,m,outer,names=self.gpu();result=ops.verify_gpu(p,names,ops.sha(p/'source-map.json'))
        self.assertEqual(result['native_array_files_checked'],286)
        endpoint=ctl.endpoint(self.root,p/'source-map.json',ops.sha(p/'source-map.json'),'GPU')
        self.assertEqual(endpoint['receipt']['source_path'],m['request']['outer_receipt'])

    def test_gpu_retained_or_wrong_large_shape_path_rejected(self):
        p,m,outer,names=self.gpu();key=next(k for k in m['files'] if k.endswith('.npy'))
        m['files'][key]['retained_at_source']=True;self.put(p/'source-map.json',m)
        with self.assertRaises(ValueError):ops.verify_gpu(p,names,ops.sha(p/'source-map.json'))
        m['files'][key].pop('retained_at_source');m['files'][key.replace('request-A','request-C')]=m['files'].pop(key);self.put(p/'source-map.json',m)
        with self.assertRaisesRegex(ValueError,'inventory'):ops.verify_gpu(p,names,ops.sha(p/'source-map.json'))

    def test_map_payload_or_external_pin_tamper_rejected(self):
        p,m,outer,names=self.gpu();q=p/next(iter(m['files'].values()))['path'];q.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'size/SHA'):ops.verify_gpu(p,names,ops.sha(p/'source-map.json'))
        with self.assertRaisesRegex(ValueError,'source-map'):ctl.endpoint(self.root,p/'source-map.json','a'*64,'GPU')

    def test_missing_unmapped_and_duplicate_payload_paths_rejected(self):
        p,m,outer,names=self.gpu();key=next(k for k in m['files'] if k.endswith('.npy'));m['files'].pop(key);self.put(p/'source-map.json',m)
        with self.assertRaises(ValueError):ops.verify_gpu(p,names,ops.sha(p/'source-map.json'))
        # A distinct copied path duplicated between two original descriptors is also refused.
        m['files'][key]=dict(next(iter(m['files'].values())));self.put(p/'source-map.json',m)
        with self.assertRaisesRegex(ValueError,'duplicate'):ops.verify_gpu(p,names,ops.sha(p/'source-map.json'))

    def test_dual_proof_four_call_and_logical_count_mutations_fail_endpoint(self):
        p,m,outer,names=self.gpu();q=p/'payload/outer.json';origin=m['request']['outer_receipt']
        for k,value in [('native_forward_calls_total',70),('cpu_prerequisite_source_sha256','b'*64),('model_loads',True)]:
            old=outer[k];outer[k]=value;self.put(q,outer);m['files'][origin].update(size=q.stat().st_size,sha256=ops.sha(q));self.put(p/'source-map.json',m)
            with self.assertRaisesRegex(ValueError,'identity'):ctl.endpoint(self.root,p/'source-map.json',ops.sha(p/'source-map.json'),'GPU')
            outer[k]=old
        outer['validation']['valid_raw_rows']=767;self.put(q,outer);m['files'][origin].update(size=q.stat().st_size,sha256=ops.sha(q));self.put(p/'source-map.json',m)
        with self.assertRaisesRegex(ValueError,'inventory'):ctl.endpoint(self.root,p/'source-map.json',ops.sha(p/'source-map.json'),'GPU')

    def test_real_tool_bundle_complete_source_closure_and_staged_controller(self):
        repo=next(p for p in HERE.parents if (p/'skills/precision-compare/scripts/record_run.py').is_file())
        archive=self.root/'tools.tar';receipt=ops.build(repo,archive);output=self.root/'staged'
        with patch.object(ops.shutil,'disk_usage',return_value=shutil._ntuple_diskusage(20*1024**3,0,20*1024**3)):
            names,size=ops.extract(archive,output,4*1024**2)
        self.assertGreater(ops.verify_tools(output,names,receipt['manifest_sha256'])['source_files_checked'],20)
        staged=module(output/ctl.CONTROLLER,'i04_actual_staged_controller_fixture')
        staged.verify_tools(output,receipt['manifest_sha256'])
        (output/ctl.MAIN).write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'source changed'):staged.verify_tools(output,receipt['manifest_sha256'])

    def test_source_map_escape_symlink_and_gpu_retained_root_rejected(self):
        p,m,outer,names=self.gpu();origin=m['request']['outer_receipt'];m['files'][origin]['path']='../outer.json';self.put(p/'source-map.json',m)
        with self.assertRaises(ValueError):ctl.endpoint(self.root,p/'source-map.json',ops.sha(p/'source-map.json'),'GPU')

    def test_report_exact18_requests_scope_not_other_stage(self):
        report={'status':'i04_raw_bf16_batch_padding_and_request_pairs_checked','task':ctl.TASK,'comparison_spec_sha256':'a'*64,
            'stage_spec_sha256':ctl.STAGE_SHA,'cpu_prerequisite_sha256':ctl.CPU_SHA,'thresholds':None,'acceptance':None,'full_core_complete':False,
            'scope':{'independent_parent_inputs':1,'derived_prefix_shape_stress_requests':1,'native_calls_per_backend':4,
                'logical_observations_per_backend':6,'target_scores_rederived':1524,'full_vocabulary_rows_rederived':564,
                'raw_physical_rows_retained':1792,'valid_raw_rows_finite_checked':1536,'pad_only_rows_separately_counted':256,
                'target_distribution_pairs':18,'matched_cross_backend_pairs':6,'within_backend_pairs':12,
                'original_large_sources_final_bytehash_checked':572,'comparison_documents':144},
            'target_distribution_pairs':[{'kind':'cross_backend_matched' if i<6 else 'within_backend_batch_padding','request':'A' if i%2==0 else 'B'} for i in range(18)]}
        ctl.validate_report(report,'a'*64)
        for key,value in [('original_large_sources_final_bytehash_checked',484),('comparison_documents',204)]:
            old=report['scope'][key];report['scope'][key]=value
            with self.assertRaisesRegex(ValueError,'scope'):ctl.validate_report(report,'a'*64)
            report['scope'][key]=old
        report['target_distribution_pairs'][0]['request']='B'
        with self.assertRaisesRegex(ValueError,'inventory'):ctl.validate_report(report,'a'*64)

    def test_original_bytes_and_strict_json(self):
        p,m,outer,names=self.gpu();before=(p/'source-map.json').read_bytes(),(p/'payload/outer.json').read_bytes()
        ctl.endpoint(self.root,p/'source-map.json',ops.sha(p/'source-map.json'),'GPU');ops.verify_gpu(p,names,ops.sha(p/'source-map.json'))
        self.assertEqual(before,((p/'source-map.json').read_bytes(),(p/'payload/outer.json').read_bytes()))
        (p/'source-map.json').write_text('{"a":1,"a":2}')
        with self.assertRaisesRegex(ValueError,'duplicate'):ctl.load(p/'source-map.json')

    @unittest.skipUnless(os.name=='posix','real POSIX generic child fixture')
    def test_real_generic_nonzero_child_cannot_become_completed_controller(self):
        root=self.root;(root/'runs').mkdir();tools=root/'tools/synthetic';tools.mkdir(parents=True)
        main=tools/ctl.MAIN;main.parent.mkdir(parents=True);main.write_text('raise SystemExit(7)\n')
        repo=next(p for p in HERE.parents if (p/ctl.RECORDER).is_file());recorder=tools/ctl.RECORDER;recorder.parent.mkdir(parents=True)
        shutil.copyfile(repo/ctl.RECORDER,recorder);python=root/'venv/bin/python';python.parent.mkdir(parents=True);python.symlink_to(sys.executable)
        # Only package/endpoint fixture setup is mocked. The controller, immutable
        # generic recorder, real child launch, return-code handling and receipts run.
        with patch.object(ctl,'verify_tools',return_value=None),patch.object(ctl,'endpoint',return_value={'synthetic_cpu_fixture':True}):
            self.assertEqual(ctl.run(root,tools,'fixture','unused','a'*64,'unused','b'*64),2)
        receipt=next((root/'runs').glob('compare-i04-invocation-*/controller-receipt.json'));actual=ctl.load(receipt)
        self.assertEqual((actual['status'],actual['child_returncode']),('failed',7))
        self.assertNotIn('report',actual);self.assertEqual(actual['native_executions_started'],0)
        original=ctl.load(actual['generic_receipt']['path']);self.assertEqual((original['status'],original['timeout']),('failed',920))


if __name__=='__main__':unittest.main()

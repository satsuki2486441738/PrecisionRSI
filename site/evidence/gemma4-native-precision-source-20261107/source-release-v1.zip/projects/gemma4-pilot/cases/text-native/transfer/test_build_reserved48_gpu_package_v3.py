"""Offline real source/proof/corpus package tests; no framework/model/device."""
import ast
import io
import json
import os
from pathlib import Path
import shlex
import signal
import subprocess
import sys
import tarfile
import tempfile
import threading
import unittest
from unittest.mock import patch

import build_reserved48_gpu_package_v3 as m


class Package(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary=tempfile.TemporaryDirectory(prefix='reserved48-package-')
        cls.output=m.local_absolute(Path(cls.temporary.name)/'prepared')
        cls.result=m.build(cls.output)
        cls.index,cls.bodies=m.inspect_archive(cls.result['archive']['path'],cls.result['archive']['sha256'],cls.result['package_index_sha256'])

    @classmethod
    def tearDownClass(cls):cls.temporary.cleanup()

    def test_four_real48_12_111_preconditions_without_claims_or_framework(self):
        self.assertEqual(len(self.result['pure_common_prepare_rehearsal']),4)
        for row in self.result['pure_common_prepare_rehearsal']:
            self.assertEqual((row['inputs_verified'],row['selected_inputs'],row['proof_refs']),(48,12,111))
            self.assertFalse(row['claims_created']);self.assertFalse(row['native_outputs_created'])
        self.assertFalse(any(x in sys.modules for x in ('torch','torch_npu','numpy','transformers')))
        self.assertEqual(self.result['native_executions_started'],0)

    def test_acyclic_actual_source_hashes_and_original_proof_identity(self):
        self.assertEqual(self.result['original_prerequisite_sha256'],m.PROOF_SHA)
        policy=self.result['resource_policy'];self.assertEqual(policy['maximum_concurrent_H100_bin_jobs'],4)
        self.assertIsNone(policy['actual_allocation_ids']);self.assertFalse(policy['NPU_native_activated_by_this_GPU_package'])
        stage=json.loads(self.bodies['p0128-v1/source/'+m.CASE+'/reserved48-stage-v3.json'])
        self.assertEqual(stage['H100_parallelism_selected'],4);self.assertEqual(stage['resources_allocated_by_spec'],0)
        expected=self.output/'generated/reserved48_expected_v3.py'
        self.assertEqual(m.sha(expected),self.result['source_sha256'][m.CASE+'/adapters/reserved48_expected_v3.py'])
        contract=m.pure(self.output/'generated/reserved48_stage_contract_v3.py','_test_reserved48_v3_contract')
        common=m.pure(self.output/'packages/p0128-v1/source'/m.CASE/'adapters/reserved48_common_v3.py','_test_reserved48_v3_common')
        life=m.pure(self.output/'generated/reserved48_gpu_lifecycle_v3.py','_test_reserved48_v3_lifecycle')
        self.assertEqual(common.GATES['prerequisite_helper_sha256'],m.sha(contract.__file__))
        self.assertEqual(life.CONTRACT_SHA,m.sha(contract.__file__))
        self.assertEqual(contract.GATES['expected_builder_sha256'],m.sha(expected))
        npu=m.pure(self.output/'generated/reserved48_npu_lifecycle_v3.py','_test_reserved48_closed_NPU_v3')
        self.assertIsNone(npu.CONTRACT_SHA)
        self.assertTrue(all(m.sha(m.REPO/name)==digest for name,digest in m.TEMPLATES.items()))

    def test_numeric_AST_lineage_rejects_a_functional_change(self):
        original=(m.REPO/m.CASE/'adapters/reserved48_common_v2.py').read_bytes()
        actual=(self.output/'generated/reserved48_common_v3.py').read_bytes()
        self.assertTrue(m.lineage(original,actual,['GATES'])['functional_AST_unchanged_after_normalization'])
        changed=actual.replace(b'VOCABULARY, CONTEXT_LIMIT = 262144, 262144',b'VOCABULARY, CONTEXT_LIMIT = 128, 262144')
        self.assertNotEqual(changed,actual)
        with self.assertRaisesRegex(ValueError,'functional AST'):m.lineage(original,changed,['GATES'])

    def test_all_prepared_refs_and_startup_are_canonical_POSIX_not_Windows_paths(self):
        for P in m.BINS:
            prefix='p%04d-v1/'%P;cfg=json.loads(self.bodies[prefix+'prepared-config.json'])
            self.assertEqual(cfg['task_root'],m.GPU_BASE+'/'+prefix[:-1]);self.assertNotIn('allocation_id',cfg)
            script=self.bodies[prefix+'launch-reserved48-gpu-v3.sh'].decode();self.assertNotIn('\\',script)
            command=shlex.split(script.splitlines()[-1]);self.assertEqual(command[:5],['exec','python3','-I','-S','-B'])
            self.assertEqual(command[5],'-c');ast.parse(command[6])
            self.assertEqual(command[-1],str(P));self.assertEqual(command[-2],self.result['bins'][m.BINS.index(P)]['prepared_config_sha256'])
            for item in (v for v in cfg.values() if isinstance(v,dict) and set(v)=={'path','sha256','size_bytes'}):
                self.assertTrue(item['path'].startswith('/data/afs-2026/'));self.assertNotIn('\\',item['path'])
            old=prefix+'source/'+m.CASE+'/adapters/reserved48_expected_v1.py'
            self.assertEqual(m.digest(self.bodies[old]),m.OLD_EXPECTED_SHA)

    def test_missing_old_pinned_lineage_is_rejected_by_real_common_prepare(self):
        path=self.output/'packages/p0128-v1/source'/m.CASE/'adapters/reserved48_expected_v1.py';raw=path.read_bytes()
        try:
            path.write_bytes(raw+b'\n')
            with patch.object(m,'BINS',(128,)),self.assertRaises(ValueError):m.rehearsal(self.output,self.output/'negative-old-lineage')
        finally:path.write_bytes(raw)

    def test_wrong_archive_pin_or_unsafe_member_refused_without_deployment(self):
        with self.assertRaisesRegex(ValueError,'external source package'):m.inspect_archive(self.result['archive']['path'],'0'*64,self.result['package_index_sha256'])
        with tempfile.TemporaryDirectory() as td:
            archive=Path(td)/'bad.tar.gz'
            with tarfile.open(archive,'w:gz') as package:
                info=tarfile.TarInfo('../escape.py');body=b'raise Exception("not executed")';info.size=len(body);package.addfile(info,io.BytesIO(body))
            with self.assertRaisesRegex(ValueError,'relative path'):m.inspect_archive(archive,m.sha(archive),'0'*64)
        self.assertFalse(Path(m.GPU_BASE).is_dir() if os.name!='nt' else False)

    def test_existing_output_never_overwritten(self):
        marker=self.output/'historical-sentinel.txt';marker.write_bytes(b'preserve existing candidate')
        with self.assertRaisesRegex(ValueError,'exclusive new'):m.build(self.output)
        self.assertEqual(marker.read_bytes(),b'preserve existing candidate')

    def test_source_fsync_external_pin_is_required_before_import(self):
        source=self.output/'packages/p0128-v1/source'
        with self.assertRaisesRegex(ValueError,'external staged-source'):m.fsync_source(source,'0'*64)
        actual=m.sha(source.parent/'source-manifest.json');checked,_=m.fsync_source(source,actual)
        self.assertEqual(checked,source.resolve())

    @unittest.skipUnless(os.name=='posix','bounded POSIX CPU fsync proxy')
    def test_original3342_fsync_protocol_is_explicitly_not_native_admissible(self):
        source=self.output/'packages/p0128-v1/source';manifest=m.sha(source.parent/'source-manifest.json')
        with tempfile.TemporaryDirectory() as td:
            result=m.fsync_probe_worker(source,Path(td),manifest)
            self.assertEqual(result['events_fsynced'],3342);self.assertEqual(result['native_forward_calls'],0)
            self.assertEqual(result['model_loads'],0);self.assertFalse(result['native_progress_admissible'])
            last=json.loads((Path(td)/'synthetic-progress.jsonl').read_bytes().splitlines()[-1])
            self.assertEqual(last['event'],'synthetic_CPU_fsync_probe_terminal')

    @unittest.skipUnless(os.name=='posix','owned CPU worker deadline')
    def test_fsync_timeout_retains_partial_logs_without_weakening_source_caps(self):
        source=self.output/'packages/p0128-v1/source';manifest=m.sha(source.parent/'source-manifest.json')
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);fake=root/'fake.py';fake.write_text('import time\ntime.sleep(60)\n');actual=subprocess.Popen
            def spawn(*args,**kw):return actual([sys.executable,'-S','-B',str(fake)],**kw)
            with patch.object(m.subprocess,'Popen',side_effect=spawn),patch.object(m,'FSYNC_WORK_SECONDS',.05):
                result=m.fsync_probe(source,root/'new-probe',manifest)
            self.assertEqual(result['status'],'incomplete_CPU_proxy_only');self.assertTrue(result['partial_files_retained'])
            self.assertFalse(result['native_progress_admissible']);self.assertTrue(result['no_automatic_cap_or_durability_adjustment'])
            self.assertTrue((root/'new-probe/controller-receipt.json').exists())

    @unittest.skipUnless(os.name=='posix','external CPU probe termination cleanup')
    def test_fsync_external_TERM_retains_receipt_and_reaps_owned_worker(self):
        source=self.output/'packages/p0128-v1/source';manifest=self.result['bins'][0]['source_manifest_sha256']
        real_popen=m.subprocess.Popen;children=[];timers=[]
        def spawn(argv,**kwargs):
            child=real_popen([sys.executable,'-S','-B','-c','import time;time.sleep(60)'],**kwargs);children.append(child)
            timer=threading.Timer(.1,lambda:os.kill(os.getpid(),signal.SIGTERM));timers.append(timer);timer.start();return child
        with tempfile.TemporaryDirectory() as td:
            try:
                with patch.object(m.subprocess,'Popen',side_effect=spawn):result=m.fsync_probe(source,Path(td)/'external-TERM',manifest)
            finally:
                for timer in timers:timer.cancel()
            self.assertEqual(result['status'],'incomplete_CPU_proxy_only');self.assertEqual(result['error_type'],'TimeoutError')
            self.assertTrue(result['partial_files_retained']);self.assertTrue(all(child.poll() is not None for child in children))
            self.assertTrue((Path(td)/'external-TERM/controller-receipt.json').exists())

    @unittest.skipUnless(os.name=='posix','direct CPU worker deadline/path guards')
    def test_direct_fsync_worker_rejects_source_output_and_enforces_deadline(self):
        source=self.output/'packages/p0128-v1/source';manifest=self.result['bins'][0]['source_manifest_sha256']
        with self.assertRaisesRegex(ValueError,'outside immutable source'):m.fsync_probe_worker(source,source,manifest)
        with tempfile.TemporaryDirectory() as td:
            with patch.object(m,'_fsync_probe_body',side_effect=lambda *_:__import__('time').sleep(60)),patch.object(m,'FSYNC_WORK_SECONDS',.05):
                with self.assertRaisesRegex(TimeoutError,'direct synthetic CPU'):m.fsync_probe_worker(source,Path(td),manifest)
            self.assertFalse((Path(td)/'probe-result.json').exists())


if __name__=='__main__':unittest.main()

"""Offline stage/proof tests: no production model, accelerator or activation."""
import copy
import os
import shutil
import sys
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import reserved48_stage_contract_v1 as c

HERE=Path(__file__).resolve().parent


class Contract(unittest.TestCase):
    def test_exact_scientific_counts_and_no_Q02_P01_or_resource_activation(self):
        stage=c.proposed_stage()
        self.assertEqual(stage['calls_per_bin']*4,stage['calls_per_backend'])
        self.assertEqual(stage['calls_per_backend'],48*(1+33+34))
        self.assertEqual(stage['input_pair_contrasts'],48*(3+3+3))
        self.assertEqual(stage['correlated_distribution_pair_positions'],432*47)
        self.assertEqual(stage['selected_original_BF16_rows_per_backend'],48*3*47)
        self.assertIsNone(stage['H100_parallelism_selected']);self.assertEqual(stage['resources_allocated_by_spec'],0)
        self.assertFalse(stage['Q02_executed']);self.assertFalse(stage['P01_executed'])
        for side in ('GPU','NPU'):
            self.assertEqual(set(stage['native_task_roots'][side]),set(map(str,c.BINS)))
            for root in stage['native_task_roots'][side].values():self.assertEqual(str(c.absolute(root)),root)
        self.assertTrue(stage['native_task_roots']['GPU']['8192'].startswith('/data/afs-2026/'))

    def test_four_finite_caps_and_distinct_CPU_budget_match_documented_matrix_facade(self):
        budget=c.proposed_budget('a'*64);limits=budget['limits'];cpu=c.proposed_cpu_budget('a'*64)['limits']
        self.assertEqual([limits['native_seconds_by_prompt_bin'][str(P)] for P in c.BINS],[1800,2700,4500,10800])
        for P in c.BINS:
            self.assertEqual(limits['whole_seconds_by_prompt_bin'][str(P)]-limits['native_seconds_by_prompt_bin'][str(P)],2700)
        self.assertEqual(120+600+300+30+960+60+630,2700)
        self.assertEqual(limits['cleanup_seconds'],60);self.assertEqual(cpu['cleanup_seconds'],20)
        self.assertEqual(cpu['minimum_free_before_start_bytes'],96*c.GIB)
        self.assertEqual(limits['initial_source_free_bytes'],64*c.GIB)
        self.assertEqual(47*262144*2*12*3,budget['known_selected_BF16_payload_bytes_per_bin_backend'])
        self.assertEqual(47*262144*8*12*3*2,budget['known_new_CPU_FP64_bytes_per_bin_both_backends'])
        self.assertEqual(limits['cpu_row_chunk'],cpu['cpu_row_chunk'])

    def test_all_production_entry_routes_refuse_before_any_source_or_claim_IO(self):
        self.assertTrue(all(v is None for v in c.GATES.values()))
        with patch.object(Path,'open',side_effect=AssertionError('unready IO')):
            for call in (lambda:c.source_context('absent','0'*64,'GPU'),lambda:c.claim_once({}),
                lambda:c.worker_guard({},Path('absent')),lambda:c.run_worker({},Path('absent'),None),
                lambda:c.supervise({},Path('absent'),'0'*64,Path('absent'))):
                with self.assertRaisesRegex(ValueError,'unready'):call()

    def test_metadata_gate_DAG_has_no_reverse_lifecycle_or_capture_source_hashes(self):
        self.assertFalse(any('lifecycle_sha' in key or 'capture_' in key for key in c.GATES))
        self.assertEqual(set(c.GATES),{'cpu_portable_sha256','native_prerequisite_sha256','stage_sha256','budget_sha256',
            'expected_inventory_sha256','native_endpoint_schema_reviewed'})
        stage=c.proposed_stage();budget=c.proposed_budget('1'*64)
        self.assertNotIn('budget_sha256',stage);self.assertNotIn('expected_inventory_sha256',stage)
        self.assertEqual(budget['stage_sha256'],'1'*64)

    def test_POSIX_identity_rejects_windows_serialization_and_traversal(self):
        self.assertEqual(str(c.absolute('/data/new-task/p0128-v1')),'/data/new-task/p0128-v1')
        for name in ('C:\\data\\new-task','/data/../old-task','/data//task'):
            with self.assertRaises(ValueError):c.absolute(name)
        for name in ('../old','/absolute','proof\\file.py','proof//file'):
            with self.assertRaises(ValueError):c.relative(name)

    def test_canonical_exclusive_run_name_preserves_existing_runs(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);run=c.new_run_directory(root,'GPU',128,'20261107T000000Z')
            self.assertEqual(run.name,'gpu-reserved48-p0128-20261107T000000Z')
            sentinel=run/'old.json';sentinel.write_bytes(b'unchanged historical fixture')
            with self.assertRaises(FileExistsError):c.new_run_directory(root,'GPU',128,'20261107T000000Z')
            self.assertEqual(sentinel.read_bytes(),b'unchanged historical fixture')
            with self.assertRaises(ValueError):c.new_run_directory(root,'NPU',8192,'2026-11-07T00:00:00+00:00')

    def test_original_frozen_capture_bytes_are_preserved(self):
        files={'reserved48_common_v1.py':'bf1bd4176fd209fd6fabfbda22bd9fb246cfdf12e72d89d7ca77417ad8546e58',
            'reserved48_native_v1.py':'d7bc0e8115769d4fcbe2aecec6e6ee550517fa7a27e7afef6b8b3844e20fe3e2',
            'reserved48_expected_v1.py':c.EXPECTED_SOURCE}
        for name,digest in files.items():self.assertEqual(c.sha(HERE.parent/'adapters'/name),digest)

    def test_actual98_CPU_and8_I04_metadata_roundtrip_preserves_kinds_and_omits_tiny_array(self):
        cpu=HERE/'reserved48-cpu-proof-local-20261106T230229Z/payload/prerequisite.json'
        i04=HERE/'i04-main-local-20261107T212400Z/payload/observer-prerequisite/prerequisite.json'
        checkers=(HERE/'export_reserved48_cpu_proof_v1.py',HERE.parent/'adapters/observer_prerequisite_v1.py')
        original_open,original_stat=Path.open,Path.stat
        def open_metadata(path,*a,**kw):
            if str(path).endswith(('.npy','.safetensors')):raise AssertionError('tiny/native array opened')
            return original_open(path,*a,**kw)
        def stat_metadata(path,*a,**kw):
            if str(path).endswith(('.npy','.safetensors')):raise AssertionError('tiny/native array statted')
            return original_stat(path,*a,**kw)
        # These two wrapper locations are deliberately fixture identifiers;
        # this temporary proof is not deployed or called observed native data.
        locations={'cpu':'/fixture-only/original/cpu/prerequisite.json','i04':'/fixture-only/original/i04/prerequisite.json'}
        with tempfile.TemporaryDirectory() as td,patch.object(Path,'open',open_metadata),patch.object(Path,'stat',stat_metadata):
            # Exercise relative CLI-style inputs against actual pure checkers,
            # which require absolute portable-proof paths internally.
            arguments=[Path(os.path.relpath(p,Path.cwd())) for p in (cpu,i04,*checkers)]
            result=c.build_prerequisite(*arguments,Path(td)/'new-proof',locations)
            self.assertEqual(result['refs'],111);self.assertFalse(result['production_gates_changed'])
            output=Path(result['prerequisite']['path']).parent
            self.assertEqual((output/'cpu/prerequisite.json').read_bytes(),cpu.read_bytes())
            self.assertEqual((output/'i04/prerequisite.json').read_bytes(),i04.read_bytes())
            self.assertEqual(c.read(output/'cpu/prerequisite.json')['kind'],'reserved48-cpu-validation-prerequisite-v1')
            checked=c.prerequisite(output/'prerequisite.json',result['prerequisite']['sha256'])
            self.assertEqual(checked['native_executions_started'],0);self.assertTrue(checked['document']['preconditions_only'])
            self.assertFalse(checked['document']['native_execution_allowed_by_prerequisite'])
            raw=next(p for p in (output/'cpu/proof').iterdir() if p.is_file());raw.write_bytes(raw.read_bytes()+b' ')
            with self.assertRaises(ValueError):c.prerequisite(output/'prerequisite.json',result['prerequisite']['sha256'])
        self.assertTrue(all(v is None for v in c.GATES.values()))

    @unittest.skipUnless(os.name=='posix','production POSIX original-path source-context fixture')
    def test_full_actual_source_manifest_and_prepared_config_reaches_platform_binding(self):
        """Real proof/corpus/source bytes; allocation is explicitly a CPU fixture."""
        case=HERE.parent;prefix=c.CASE
        with tempfile.TemporaryDirectory() as td:
            backend=Path(td)/c.NAMESPACE/'gpu';root=backend/'p0128-v1';source=root/'source';source.mkdir(parents=True)
            corpus=source/'inputs';shutil.copytree(case/'inputs/reserved-articles-v1',corpus)
            proof=source/'prerequisites';shutil.copytree(case/'runs/compare-reserved48-native-prerequisite-prepared-20261106T231753Z/prerequisite',proof)
            code={prefix+'/adapters/reserved48_expected_v1.py':case/'adapters/reserved48_expected_v1.py',
                prefix+'/adapters/reserved48_native_v1.py':case/'adapters/reserved48_native_v1.py',
                prefix+'/adapters/reserved48_common_v1.py':case/'adapters/reserved48_common_v1.py',
                prefix+'/transfer/reserved48_gpu_lifecycle_v1.py':HERE/'reserved48_gpu_lifecycle_v1.py',
                prefix+'/transfer/npu_three_repeat_launcher_v4.py':HERE/'npu_three_repeat_launcher_v4.py',
                'skills/precision-compare/scripts/record_run.py':case.parents[3]/'skills/precision-compare/scripts/record_run.py'}
            for name,original in code.items():
                target=source/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original.read_bytes())
            with patch.dict(c.BACKEND_ROOTS,{'GPU':str(backend)}):
                stage=source/'stage.json';c.put(stage,c.proposed_stage());budget=source/'budget.json';c.put(budget,c.proposed_budget(c.sha(stage)))
                expected_module=c.load_module(source/(prefix+'/adapters/reserved48_expected_v1.py'),c.EXPECTED_SOURCE,'_reserved48_context_fixture_expected')
                expected=source/'expected.json';c.put(expected,expected_module.derive(corpus/'reserved.json',corpus,c.sha(stage)))
                manifest=root/'source-manifest.json';inventory={}
                for path in source.rglob('*'):
                    if path.is_file():inventory[path.relative_to(source).as_posix()]={'sha256':c.sha(path),'size_bytes':path.stat().st_size,'kind':'code' if path.suffix=='.py' else 'metadata'}
                c.put(manifest,{'schema_version':1,'task':c.TASK,'files':{k:v['sha256'] for k,v in inventory.items()},'inventory':inventory})
                config=root/'prepared-config.json';platform=root/'platform-allocation-source.json'
                d={'schema_version':1,'task':c.TASK,'backend':'GPU','prompt_bin':128,'model_loads':1,'native_launches':1,'automatic_retry':False,
                    'task_root':str(root),'source_root':str(source),'source_manifest':c.file_ref(manifest),
                    'collector_relative_path':prefix+'/adapters/reserved48_native_v1.py','common_relative_path':prefix+'/adapters/reserved48_common_v1.py',
                    'lifecycle_relative_path':prefix+'/transfer/reserved48_gpu_lifecycle_v1.py','recorder_relative_path':'skills/precision-compare/scripts/record_run.py',
                    'cleanup_relative_path':prefix+'/transfer/npu_three_repeat_launcher_v4.py',
                    'reviewed_source_sha256':{'collector':c.sha(code[prefix+'/adapters/reserved48_native_v1.py']),
                        'common':c.sha(code[prefix+'/adapters/reserved48_common_v1.py']),'lifecycle':c.sha(HERE/'reserved48_gpu_lifecycle_v1.py')},
                    'stage_spec':c.file_ref(stage),'budget':c.file_ref(budget),'expected_inventory':c.file_ref(expected),
                    'prerequisite':c.file_ref(proof/'prerequisite.json'),'expected_builder':c.file_ref(source/(prefix+'/adapters/reserved48_expected_v1.py')),
                    'manifest':c.file_ref(corpus/'reserved.json'),'input_dir':str(corpus),'allocation_source_path':str(platform)}
                c.put(config,d);config_sha=c.sha(config)
                p={'task':c.TASK,'backend':'GPU','prompt_bin':128,'allocation_id':'app-synthetic-cpu-fixture','actual_allocation':False,
                    'prepared_config_sha256':config_sha,'stage_sha256':c.sha(stage),'budget_sha256':c.sha(budget),'expected_inventory_sha256':c.sha(expected),
                    'native_prerequisite_sha256':c.sha(proof/'prerequisite.json'),'lifecycle_sha256':d['reviewed_source_sha256']['lifecycle']}
                c.put(platform,p)
                gates={'cpu_portable_sha256':c.ACTUAL_CPU_PORTABLE_SHA,'native_prerequisite_sha256':p['native_prerequisite_sha256'],
                    'stage_sha256':p['stage_sha256'],'budget_sha256':p['budget_sha256'],'expected_inventory_sha256':p['expected_inventory_sha256'],'native_endpoint_schema_reviewed':True}
                with patch.dict(c.GATES,gates),patch.object(c.shutil,'disk_usage',return_value=SimpleNamespace(free=128*c.GIB)):
                    context=c.source_context(config,config_sha,'GPU')
                    self.assertEqual(context['config_ref']['sha256'],config_sha);self.assertEqual(context['platform']['allocation_id'],p['allocation_id'])
                    self.assertEqual(len(context['inventory']['samples']),48);self.assertFalse((root/'claims').exists())
                    p['prepared_config_sha256']='f'*64;platform.write_text(c.canonical(p),encoding='utf8')
                    with self.assertRaisesRegex(ValueError,'detached from prepared config'):c.source_context(config,config_sha,'GPU')
        self.assertTrue(all(v is None for v in c.GATES.values()))


if __name__=='__main__':unittest.main()

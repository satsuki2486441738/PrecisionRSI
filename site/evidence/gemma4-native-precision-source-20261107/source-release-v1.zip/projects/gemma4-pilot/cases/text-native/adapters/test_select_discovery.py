import unittest
import select_discovery as s


class SelectionTest(unittest.TestCase):
    def test_unique_rows_and_assignment_are_deterministic(self):
        texts=['Alpha text', '  alpha   TEXT ', 'Beta text', 'Gamma text']
        tokens={'Alpha text':[10]*50, '  alpha   TEXT ':[10]*50,
                'Beta text':[11]*50,'Gamma text':[12]*50}
        a,c,n=s.select(texts,lambda x:tokens[x],bins=(4,8),per_bin=1,continuation=2)
        b,_,_=s.select(texts,lambda x:tokens[x],bins=(4,8),per_bin=1,continuation=2)
        self.assertEqual(a,b)
        self.assertEqual(n,3)
        self.assertEqual(c,{4:1,8:1})
        self.assertEqual(len({x['row'] for x in a}),2)
        self.assertNotIn(1,{x['row'] for x in a})
        for x in a:
            self.assertEqual(x['prompt'][0],2)
            self.assertEqual(len(x['prompt']),x['bin'])
            self.assertEqual(len(x['continuation']),2)
            self.assertEqual(x['text_token_span'],[0,x['bin']-1+2])

    def test_short_and_special_tokens_leave_bins_incomplete(self):
        values={'short':[5,6], 'special':[4,2,4,4,4,4], 'long':[8]*20}
        got,counts,_=s.select(list(values),lambda x:values[x],bins=(4,8),per_bin=1,continuation=2)
        self.assertEqual(counts,{4:0,8:1})
        self.assertEqual(len(got),1)
        self.assertEqual(got[0]['row'],2)

    def test_rejects_invalid_token_ids(self):
        with self.assertRaises(ValueError):
            s.select(['text'],lambda x:[True],bins=(4,),per_bin=1,continuation=2)


if __name__=='__main__': unittest.main()

"""Freeze/admit actual I03 source maps; compare23 score pairs and4 final KV pairs.

CPU only,900s maximum. Original source maps/receipts are never rewritten.
Requires complete copied GPU arrays and an explicit source-retained NPU root.
"""
import argparse
import ast
from datetime import datetime,timezone
import itertools
from pathlib import Path,PurePosixPath
import signal
import uuid

import i03_artifact_admission_v1 as native
import compare_tensors

old=native.old
require=native.require
canonical=native.canonical
load=native.load
sha=native.sha
put=old.put
child=native.child
argument=old.argument
HELPER_SHA='b734babc65be6ec361acbc10905b6c3e02e8c5c57650efb11e3a195134a1b6eb'
COMMON_SHA='5cf67f53b5392e4425c4534ec6f97961066c190d24dc1280f31e66781a0fe03a'
PRIOR_COMMON_SHA='fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c'
COLLECTORS={'GPU':'6bd1616289966d561ff2254ba5896b1784e570de3d211a313b9e6f44c24ffe9a',
    'NPU':'3b21aabb480c230812b3b4be4a62191bc393ead34bc3bba1ae3af86c00a0ecc0'}
LAUNCHERS={'GPU':('h100_i03_lifecycle_v1.py','93d3e1fa562dae80c5507ee9d2157572aae1ea5919fc287e28f198619f73fe69'),
    'NPU':('npu_i03_launcher_v1.py','84e6b29a550e9b9222539dd9c026a6e6820bbc8e3799cccb4759beff57b0d0d8')}


def verify_tools():
    native.verify_tools()
    require(sha(native.__file__)==HELPER_SHA and Path(compare_tensors.__file__).resolve()==old.prior.REPO/'skills/precision-compare/scripts/compare_tensors.py',
        'independent artifact/tensor helper changed')


def runtime_copies(endpoint,outer,runtime,category):
    packages=runtime['package_sources'];implementations=runtime['implementation_sources']
    require(set(packages)==({'torch','transformers','numpy'} if category=='GPU' else {'torch','torch_npu','transformers','numpy'}) and
        set(implementations)=={'modeling','cache_utils'} and implementations['modeling']==runtime['model_identity']['modeling_source'],
        'complete actual package/modeling/cache implementation sources required')
    refs={ref['path']:ref for ref in [*packages.values(),*implementations.values()]}
    if category=='GPU':
        # The actual GPU lifecycle additionally freezes every Python file_ref
        # nested in runtime.sources/proof metadata, preserving all original keys.
        def visit(value):
            if isinstance(value,dict):
                if set(value)=={'path','sha256','size_bytes'} and str(value['path']).endswith(('.py','.pyi')):
                    require(value['path'] not in refs or refs[value['path']]==value,'conflicting original Python source refs')
                    refs[value['path']]=value
                for nested in value.values():visit(nested)
            elif isinstance(value,list):
                for nested in value:visit(nested)
        visit(runtime)
    frozen=endpoint.json(outer['runtime_source_map_path'],outer['runtime_source_map_sha256'])
    require(set(frozen)==set(refs) and len(frozen)>=(5 if category=='GPU' else 6),'complete runtime original/copy closure differs')
    for ref in refs.values():
        copy=frozen[ref['path']];require(set(ref)=={'path','sha256','size_bytes'} and set(copy)==set(ref) and
            copy['sha256']==ref['sha256'] and copy['size_bytes']==ref['size_bytes'],'runtime preserved-copy identity differs')
        for path in (ref['path'],copy['path']):require(endpoint.get(path,ref['sha256']).stat().st_size==ref['size_bytes'],'runtime implementation size differs')
    claim=str(PurePosixPath(outer['runtime_source_map_path']).parent)
    before=child(claim,'runtime-packages-before.json' if category=='GPU' else 'native-runtime-sources.json')
    require(before in outer['source_sha256'],'pre-model package observation not frozen')
    observed=endpoint.json(before,outer['source_sha256'][before])
    if category=='GPU':
        require(set(observed)=={r['path'] for r in packages.values()} and all(observed[r['path']]['sha256']==r['sha256'] and
            observed[r['path']]['size_bytes']==r['size_bytes'] for r in packages.values()),'GPU pre-model/package identities differ')
    else:require(canonical(observed)==canonical(packages),'NPU pre-model/package identities differ')
    return {key:ref['sha256'] for key,ref in implementations.items()}


def pinned_capture_sources(endpoint,outer,runtime,category):
    refs=runtime['sources'];pins={'i03/i01_common_v1.py':PRIOR_COMMON_SHA,'i03/i03_common_v1.py':COMMON_SHA,
        'i03/i03_prerequisite_v1.py':native.PROOF_HELPER_SHA,'i03/i03_'+category.lower()+'_v1.py':COLLECTORS[category]}
    for key,digest in pins.items():require(refs[key]['sha256']==digest,'reviewed capture dependency differs: '+key)
    prior_path=endpoint.get(refs['i03/i01_common_v1.py']['path'],PRIOR_COMMON_SHA);tree=ast.parse(prior_path.read_text())
    nested=None
    for node in tree.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PINNED' for t in node.targets):nested=ast.literal_eval(node.value)
    require(isinstance(nested,dict) and len(nested)==9,'original loader/source dependency closure differs')
    for key,digest in nested.items():require(refs[key]['sha256']==digest,'original loader helper source pin differs')
    for ref in refs.values():require(endpoint.get(ref['path'],ref['sha256']).stat().st_size==ref['size_bytes'],'actual capture source ref size differs')
    return refs


def admit(endpoint,receipt_ref,category,proof_folder):
    receipt_path=endpoint.get(receipt_ref['source_path'],receipt_ref['sha256']);outer=load(receipt_path)
    fixed={'schema_version':1,'task':'I03','task_id':native.expected.STAGE_ID,'backend':category,'status':'completed','returncode':0,'timed_out':False,
        'collector_sha256':COLLECTORS[category],'input_sha256':native.INPUT_SHA,'expected_inventory_source_sha256':native.EXPECTED_SHA,
        'stage_spec_source_sha256':native.STAGE_SHA,'i01_prerequisite_source_sha256':native.PROOF_SHA,
        'native_capture_count':1,'native_forward_calls_total':70,'model_loads':1,'acceptance':None}
    require(all(k in outer and canonical(outer[k])==canonical(v) for k,v in fixed.items()),'successful exact finite I03 outer receipt required')
    sources=outer['source_sha256'];dependencies=outer['dependency_paths'];require(isinstance(sources,dict) and isinstance(dependencies,list) and
        len(dependencies)==len(set(dependencies)) and set(dependencies)==set(sources),'outer frozen source closure differs')
    for path,digest in sources.items():require(isinstance(digest,str) and old.HEX.fullmatch(digest),'invalid source SHA');endpoint.get(path,digest)
    for basename,digest in (('i03_expected_inventory_v1.py',native.EXPECTED_SOURCE_SHA),('record_run.py',old.RECORDER_SHA),LAUNCHERS[category]):
        found=[path for path in sources if PurePosixPath(path).name==basename]
        require(len(found)==1 and sources[found[0]]==digest,'finite launcher/expected/generic source identity differs')
    argv=outer['argv'];direct=2 if len(argv)>1 and argv[1]=='-B' else 1
    require(argv[direct]==outer['collector_path'] and sources.get(outer['collector_path'])==COLLECTORS[category],'actual native direct collector differs')
    flags={'--input':outer['input_path'],'--output':outer['output_dir'],'--device':'cuda:0' if category=='GPU' else 'npu:0',
        '--allocation-receipt':outer['allocation_path'],'--stage-spec':outer['stage_spec_source_path'],'--stage-spec-sha256':native.STAGE_SHA,
        '--expected-inventory':outer['expected_inventory_source_path'],'--expected-inventory-sha256':native.EXPECTED_SHA,
        '--i01-prerequisite':outer['i01_prerequisite_source_path'],'--i01-prerequisite-sha256':native.PROOF_SHA}
    for key,value in flags.items():require(argument(argv,key)==value,'executed I03 source argument differs: '+key)
    for path,digest in ((outer['input_path'],native.INPUT_SHA),(outer['stage_spec_source_path'],native.STAGE_SHA),
            (outer['expected_inventory_source_path'],native.EXPECTED_SHA),(outer['i01_prerequisite_source_path'],native.PROOF_SHA),(outer['allocation_path'],outer['allocation_sha256'])):
        require(sources.get(path)==digest,'pre-model input/allocation/prerequisite source not frozen')
    claim=str(PurePosixPath(receipt_ref['source_path']).parent);controller=endpoint.json(child(claim,'controller-receipt.json'))
    require(controller.get('task')=='I03' and controller.get('status')=='completed' and type(controller.get('returncode')) is int and controller['returncode']==0 and
        controller.get('timed_out') is False and controller.get('remaining_descendants')==[],'native lifecycle not terminal/cleaned')
    reservation=endpoint.json(child(claim,'claim.json'))
    common_claim={'task_id':native.expected.STAGE_ID,'whole_attempt_seconds':3600,'capture_seconds':1500 if category=='GPU' else 1800,
        'logical_transport_cap':1073741824,'encoded_transport_cap':1610612736,'i01_prerequisite_sha256':native.PROOF_SHA}
    require(all(k in reservation and canonical(reservation[k])==canonical(v) for k,v in common_claim.items()),'finite permanent native claim differs')
    if category=='GPU':
        require(reservation.get('independent_expected_sha256')==native.EXPECTED_SHA and reservation.get('independent_expected_bytes')==148509 and
            reservation.get('lifecycle_sha256')==LAUNCHERS[category][1] and reservation.get('max_capture_bytes')==native.CAP_BYTES and
            reservation.get('max_new_task_bytes_sampled')==4*old.GIB and controller.get('whole_attempt_seconds')==3600 and
            controller.get('cleanup_reserve_seconds')==20 and controller.get('max_new_task_bytes_sampled')==4*old.GIB,'GPU finite claim/controller resource guards differ')
    else:require(reservation.get('expected_inventory_sha256')==native.EXPECTED_SHA and reservation.get('max_capture_product_bytes')==native.CAP_BYTES and
        reservation.get('max_new_bytes_sampled')==4*old.GIB and type(reservation.get('automatic_retries')) is int and reservation['automatic_retries']==0 and
        reservation.get('native_launches')==1 and reservation.get('native_forward_calls')==70 and reservation.get('model_loads')==1,'NPU finite claim resource/retry guards differ')
    generic=endpoint.json(outer['generic_receipt']['path'],outer['generic_receipt']['sha256'])
    require(generic.get('status')=='completed' and type(generic.get('returncode')) is int and generic['returncode']==0 and
        type(generic.get('child_returncode')) is int and generic['child_returncode']==0 and generic['argv']==argv and
        generic['timeout']==(1500 if category=='GPU' else 1800),'original bounded generic native execution differs')
    require(old.prior.npu.utc_time(outer['started_utc'])==old.prior.npu.utc_time(generic['start'])<old.prior.npu.utc_time(generic['end'])<=
        old.prior.npu.utc_time(outer['finished_utc']),'native UTC execution chain differs')
    require(old.prior.npu.utc_time(reservation['claimed_utc'])<=old.prior.npu.utc_time(controller['started_utc'])<=old.prior.npu.utc_time(generic['start']) and
        old.prior.npu.utc_time(outer['finished_utc'])<=old.prior.npu.utc_time(controller['finished_utc']),'permanent claim/controller UTC chain differs')
    result=native.inspect_output(endpoint,outer,proof_folder);runtime=result['runtime'];paths=result['paths']
    fixed={'task':native.expected.TASK,'stage_id':native.expected.STAGE_ID,'stage_spec_sha256':native.STAGE_SHA,'input_sha256':native.INPUT_SHA,
        'expected_inventory_sha256':native.EXPECTED_SHA,'expected_inventory_external_path':outer['expected_inventory_source_path'],
        'i01_prerequisite_sha256':native.PROOF_SHA,'i01_prerequisite_external_path':outer['i01_prerequisite_source_path'],
        'backend':category.lower(),'device_argument':flags['--device'],'model_repository':'google/gemma-4-12B','requested_revision':old.prior.npu.REVISION,
        'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':native.NORMALIZATION,'model_loads':1,
        'native_forward_calls_total':70,'modes':native.MODES,'seed':0,'thresholds':None,'acceptance':None,'full_core_complete':False}
    require(all(k in runtime and canonical(runtime[k])==canonical(v) for k,v in fixed.items()),'actual I03 runtime semantics differ')
    refs=pinned_capture_sources(endpoint,outer,runtime,category);implementations=runtime_copies(endpoint,outer,runtime,category)
    identity=runtime['model_identity'];require(identity['model_class']=='Gemma4UnifiedForConditionalGeneration' and identity['model_type']=='gemma4_unified' and
        identity['parameter_dtypes']==['torch.bfloat16'] and identity['actual_attention']=='eager' and identity['observed_config_commit'] in (None,old.prior.npu.REVISION) and
        'logits_to_keep' in identity['forward_signature'] and sha(paths['snapshot-verification.json'])==identity['snapshot_receipt_sha256'],'loaded model metadata differs')
    metadata=refs['projects/gemma4-pilot/cases/text-native/adapters/upstream-identity.json']
    require(metadata['sha256']==old.prior.npu.METADATA_SHA,'official upstream metadata differs')
    model=old.prior.npu.snapshot_identity(load(paths['snapshot-verification.json']),endpoint.json(metadata['path'],metadata['sha256']),identity['model_class'])
    policy=runtime['math_policy'];require(canonical(policy)==canonical(load(paths['policy-after-load.json']))==canonical(load(paths['policy-after-capture.json'])),
        'backend policy changed through modes')
    allocation=endpoint.json(outer['allocation_path'],outer['allocation_sha256']);physical=runtime['runtime_uuid']
    require(isinstance(physical,str) and str(uuid.UUID(physical))==physical and uuid.UUID(physical).int and allocation['physical_device_id']==physical and
        runtime['allocation_receipt_sha256']==outer['allocation_sha256'] and reservation['allocation_id']==allocation['allocation_id'],'actual physical allocation identity differs')
    versions=runtime['versions']
    if category=='GPU':
        require(versions=={'torch':'2.9.0+cu128','transformers':'5.10.1','cuda_runtime':'12.8','numpy':'1.26.4'} and runtime['device_name']=='NVIDIA H100 80GB HBM3' and
            canonical(policy)==canonical(old.prior.gpu.FROZEN_POLICY),'GPU stack/device/policy differs')
        initial=runtime['initial_rng_observations'];require(all(type(initial.get(k)) is int and initial[k]==0 for k in
            ('seed','python_random_seed','numpy_seed','torch_initial_seed','cuda_initial_seed')) and canonical(initial['settings'])==canonical(policy)==
            canonical(load(paths['policy-before-load.json'])['settings']),'GPU initial seed policy differs')
        require(allocation.get('vendor')=='NVIDIA' and type(allocation.get('visible_count')) is int and allocation['visible_count']==1 and
            type(allocation.get('logical_ordinal')) is int and allocation['logical_ordinal']==0,'GPU logical allocation differs')
        native_probe=endpoint.json(allocation['native_source'],allocation['native_source_sha256']);platform=endpoint.json(allocation['evidence_source'],allocation['platform_source_sha256'])
        require(sources.get(allocation['native_source'])==allocation['native_source_sha256'] and sources.get(allocation['evidence_source'])==allocation['platform_source_sha256'] and
            native_probe['status']=='native_preflight_passed' and native_probe['runtime_uuid']==physical and native_probe['device_name']==runtime['device_name'] and
            native_probe['visible_count']==1 and platform['allocation_id']==allocation['allocation_id'],'GPU actual platform/native source binding differs')
    else:
        require(versions=={'torch':'2.9.0+cpu','torch_npu':'2.9.0.post2','transformers':'5.10.1','numpy':'1.26.4','cann':'9.1.0','driver':'25.5.2'} and
            runtime['instance_visible_count']==8 and runtime['compute_device_count']==1,'NPU selected stack/device count differs')
        old.prior.npu.verify_binding({**runtime,'device':runtime['device_argument']},outer,endpoint,outer['allocation_path'],argument(argv,'--native-mapping'),argument(argv,'--native-source'))
        old.prior.npu.verify_driver_provenance(runtime,outer,endpoint,outer['output_dir'])
        required={'float32_matmul_precision':'highest','matmul_allow_hf32':False,'conv_allow_hf32':True,'deterministic_algorithms':False,'deterministic_warn_only':False,'pythonhashseed':'0'}
        require(all(k in policy and type(policy[k]) is type(v) and policy[k]==v for k,v in required.items()) and
            canonical(load(paths['policy-before-load.json'])['configured'])==canonical(policy),'NPU math policy differs')
    require(type(runtime['free_bytes_before_load']) is int and runtime['free_bytes_before_load']>=35*old.GIB and
        type(runtime['host_memory']['effective_available_bytes']) is int and runtime['host_memory']['effective_available_bytes']>=(40 if category=='GPU' else 80)*old.GIB,
        'recorded native memory boundary differs')
    result.update(category=category,model=model,hardware={'category':category,'model':runtime['device_name']},software={'framework':'torch',**versions},
        backend_policy=policy,implementation_sha256=implementations,runtime_uuid=physical,outer_receipt_sha256=receipt_ref['sha256'])
    return result


def pairs():
    full=native.MODES[:3];scores=[]
    for category in ('GPU','NPU'):
        scores.extend((category,a,category,b,'within_process_full_repeat') for a,b in itertools.combinations(full,2))
        scores.extend((category,a,category,b,'within_process_partition') for a,b in [('full-r1','token'),('full-r1','chunk63-65'),('token','chunk63-65')])
    scores.extend(('GPU',a,'NPU',b,'cross_backend_full') for a in full for b in full)
    scores.extend(('GPU',mode,'NPU',mode,'cross_backend_cached') for mode in native.MODES[3:])
    kv=[('GPU','token','GPU','chunk63-65'),('NPU','token','NPU','chunk63-65'),('GPU','token','NPU','token'),('GPU','chunk63-65','NPU','chunk63-65')]
    require(len(scores)==23 and len(set(scores))==23 and len(kv)==4,'fixed I03 comparison inventory differs')
    return scores,kv


def mode_run(run,mode):
    artifact=run['modes'][mode]
    return {**artifact,'side':run['category'].lower()+'-'+mode,'model':run['model'],'hardware':run['hardware'],'software':run['software'],
        'backend_policy':run['backend_policy'],'status_path':run['status_path'],'mode':{'mode':mode,'use_cache':artifact['mode_plan']['use_cache'],
            'forward_calls':artifact['mode_plan']['native_forward_calls'],'loaded_model_state_sha256':run['loaded_model_state_sha256'],
            'implementation_sha256':run['implementation_sha256']}}


def compare_kv(folder,a,b,inventory):
    folder.mkdir();ka,kb=a['final_kv'],b['final_kv'];require(ka is not None and kb is not None and ka['descriptors']==kb['descriptors'],'same complete KV logical inventory required')
    common={'model':a['model'],'inputs':{'sha256':native.INPUT_SHA},'numerics':{'native_dtype':'BF16','metric_dtype':'float64','parallelism':'tp1','seed':0},
        'scope':'native final KV after all160 fixed inputs; complete96 tensors; configured1024 eviction not exercised'}
    conditions={r['side']:{key:r[key] for key in ('hardware','software','backend_policy','mode')} for r in (a,b)}
    tensors=[{'name':key,'shape':shape,'present':True,'coordinates':{'sample':inventory['all_targets'][0]['sample'],'layer':int(key.split('.')[0].split('-')[1]),
        'kind':key.split('.')[1],'boundary':'after160 supplied inputs','sequence_length':160}} for key,shape in ka['descriptors'].items()]
    contract={'schema_version':2,'kind':'tensors','stage':'observations','common':common,'expected_ranks':{r['side']:[0] for r in (a,b)},
        'side_conditions':conditions,'tensors':tensors,'thresholds':None};put(folder/'kv-contract.json',contract)
    for run in (a,b):
        side=run['side'];put(folder/(side+'-environment.json'),{'rank':0,'versions':run['software'],'actual':{**common,**conditions[side]}})
        manifest={'schema_version':2,'kind':'tensors','stage':'observations','side':side,'common':common,'expected_ranks':[0],
            'ranks':[{'rank':0,'environment':side+'-environment.json','status':run['status_path']}],
            'tensors':[{**item,'shards':[{'offset':0,'value':run['final_kv']['arrays'][item['name']]}]} for item in tensors]}
        put(folder/(side+'-kv.json'),manifest)
    report=compare_tensors.compare(folder/'kv-contract.json',folder/(a['side']+'-kv.json'),folder/(b['side']+'-kv.json'))
    require(report['status']=='no_thresholds' and len(report['per_tensor'])==96 and report['global']['count']==native.KV_BYTES//2,'shared full native KV comparator rejected inventory')
    return {'sides':[a['side'],b['side']],'metrics':report,'frozen_document_sha256':{p.name:sha(p) for p in folder.iterdir()},'thresholds':None,'acceptance':None}


def assess(spec_path,spec_sha,output):
    verify_tools();require(old.HEX.fullmatch(spec_sha) and sha(spec_path)==spec_sha,'independently frozen I03 admission spec differs')
    spec=load(spec_path);require(spec['schema_version']==1 and spec['task']==native.expected.TASK and spec['stage_spec_sha256']==native.STAGE_SHA and
        spec['expected_inventory_sha256']==native.EXPECTED_SHA and spec['i01_prerequisite_sha256']==native.PROOF_SHA and
        set(spec['endpoints'])=={'GPU','NPU'} and spec['thresholds'] is None and spec['acceptance'] is None,'actual two-endpoint I03 specification required')
    output=Path(output).resolve();require(not output.exists() and output.parent.is_dir(),'exclusive new comparison directory required');output.mkdir()
    endpoints={};runs={}
    for category,info in spec['endpoints'].items():
        ref=info['source_map'];endpoint=native.Endpoint(ref['path'],ref['sha256'],info.get('retained_root') if category=='NPU' else None)
        request=endpoint.document.get('request',{}) if hasattr(endpoint,'document') else load(endpoint.manifest_path).get('request',{})
        require(request.get('task')=='I03' and request.get('backend')==category and request.get('outer_receipt')==info['receipt']['source_path'],
            'actual I03 source-map request/outer receipt binding differs')
        endpoints[category]=endpoint;runs[category]=admit(endpoint,info['receipt'],category,output/('i01-proof-'+category.lower()))
    require(canonical(runs['GPU']['model'])==canonical(runs['NPU']['model']) and runs['GPU']['configured_layer_types']==runs['NPU']['configured_layer_types'],
        'two backends do not share the fixed checkpoint/configured attention inventory')
    sources=[str(r['paths'][name]) for r in runs.values() for name in r['paths'] if name.endswith(('.npy','.safetensors'))]
    require(len(sources)==len(set(sources))==484,'each of470 full rows/10raw/4KV needs a distinct readable source')
    score_plan,kv_plan=pairs();score_reports=[];kv_reports=[]
    for ordinal,(ca,ma,cb,mb,kind) in enumerate(score_plan):
        a,b=mode_run(runs[ca],ma),mode_run(runs[cb],mb)
        report=old.compare_pair(output/('scores-%02d'%ordinal),a,b,runs[ca]['inventory']['all_targets'],runs[ca]['inventory']['distribution_positions'],
            'one fixed input; same-process full repeats and partition contrasts; independent backend model loads')
        report['kind']=kind;score_reports.append(report)
    for ordinal,(ca,ma,cb,mb) in enumerate(kv_plan):kv_reports.append(compare_kv(output/('kv-%02d'%ordinal),mode_run(runs[ca],ma),mode_run(runs[cb],mb),runs[ca]['inventory']))
    for endpoint in endpoints.values():
        for name,digest in endpoint.checked.items():require(sha(endpoint.resolved[name])==digest,'original native source changed during math')
        require(sha(endpoint.manifest_path)==endpoint.expected_sha,'source map changed during math')
    require(sha(spec_path)==spec_sha,'actual I03 specification changed during math');verify_tools()
    result={'schema_version':1,'status':'i03_raw_bf16_partition_repeat_and_final_kv_checked','task':native.expected.TASK,'stage_spec_sha256':native.STAGE_SHA,
        'comparison_spec_sha256':spec_sha,'checked_utc':datetime.now(timezone.utc).isoformat(),'source_map_sha256':{k:v.expected_sha for k,v in endpoints.items()},
        'scope':{'independent_inputs':1,'new_model_processes_per_backend':1,'native_calls_per_backend':70,'modes_per_backend':5,'full_repeat_calls_per_backend':3,
            'fresh_process_repeatability_measured':False,'cached_mode_repeatability_measured':False,'targets_per_mode':159,'distribution_rows_per_mode':47,
            'raw_native_predictor_rows_finite_checked':1600,'full_vocabulary_rows_rederived':470,'target_scores_rederived':1590,'target_distribution_pairs':23,
            'native_final_kv_pairs':4,'native_kv_tensors_per_cached_mode':96,'cache_eviction_tested':False},
        'raw_derivation':{category:{mode:{'raw_sha256':r['raw_sha256'],'largest_abs_logprob_derivation_delta':r['raw_derivation_max_abs_delta']} for mode,r in run['modes'].items()}
            for category,run in runs.items()},'target_distribution_pairs':score_reports,'native_final_kv_pairs':kv_reports,
        'state_evidence':{category:{'loaded_model_state_sha256':run['loaded_model_state_sha256'],'implementation_sha256':run['implementation_sha256'],
            'observed_cache_layer_classes':{mode:sorted({layer['class'] for layer in run['modes'][mode]['final_kv']['observation']['layers']}) for mode in native.MODES[3:]},
            'before_mode_rng_observations':run['modes']['full-r1']['rng_before']} for category,run in runs.items()},
        'native_executions_started_by_admission':0,'thresholds':None,'acceptance':None,'full_core_complete':False,
        'limitations':['One fixed input; repeats share one process/model and are not fresh-process repetitions',
            'Cached modes have one capture each; no cached-mode repeatability result',
            'Observed config/storage/version/buffer and generator evidence does not rehash loaded parameters or reset allocator/kernel warmup',
            'Native cache class/sliding behavior is observed, not forced;160 inputs do not test configured1024 eviction',
            'Source/snapshot receipts do not attest scheduler ownership or loader-consumed bytes; no operator defect attribution',
            'Top100 union probability metrics and complement-merged JS are not full-vocabulary probability errors/divergence']}
    put(output/'i03-comparison-report.json',result);return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--spec',type=Path,required=True);parser.add_argument('--spec-sha256',required=True)
    parser.add_argument('--output-dir',type=Path,required=True);parser.add_argument('--timeout-seconds',type=int,default=900);args=parser.parse_args()
    require(1<=args.timeout_seconds<=900 and hasattr(signal,'SIGALRM'),'POSIX CPU bound1..900 seconds required')
    def expire(*_):raise TimeoutError('I03 independent admission CPU deadline exceeded')
    previous=signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,args.timeout_seconds)
    try:result=assess(args.spec,args.spec_sha256,args.output_dir)
    finally:signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)
    print(old.json.dumps({'status':result['status'],'target_distribution_pairs':23,'native_final_kv_pairs':4,'native_executions_started':0,'acceptance':None}))


if __name__=='__main__':main()

"""Bounded CPU admission of the actual GPU-only observer; no device APIs.

Original two-endpoint activation globals remain None. This separately pinned
profile invokes the same frozen GPU admit/score/sample functions without
claiming a completed NPU endpoint, all16 pairs, operator cause or acceptance.
"""
import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import signal
import subprocess
import sys
import tarfile
import time
import traceback

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]
PROFILE_SHA = 'a017c169fb18ab3695273f7c3435d3d9405acd7c1d84c0fe0d3a129c9942ee3f'
NUMPY_INIT_SHA = '22cd1535fa14d74ef6f457cca149ffdc80875f460be313b8f895273f78bc402e'


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4*1024**2), b''): h.update(block)
    return h.hexdigest()


def read(path):
    def pairs(items):
        d = {}
        for k, v in items: require(k not in d, 'duplicate JSON key'); d[k] = v
        return d
    return json.loads(Path(path).read_bytes(), object_pairs_hook=pairs,
        parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))


def put(path, doc):
    with Path(path).open('x', encoding='utf-8', newline='\n') as f:
        json.dump(doc, f, indent=2, allow_nan=False); f.write('\n')


def utc(): return datetime.now(timezone.utc).isoformat()


def contained(root, path):
    path = Path(path)
    require(path.is_absolute() and path.is_relative_to(root) and path.resolve().is_relative_to(root), 'path escapes explicit CPU task')
    current = path
    while current != root:
        require(not current.is_symlink(), 'symlink in CPU task path'); current = current.parent
    return path


def regular(path, limit=None):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and (limit is None or path.stat().st_size <= limit), 'bounded original regular file required')
    return path


def profile(path):
    path = regular(Path(path).absolute(), 65536)
    require(sha(path) == PROFILE_SHA, 'frozen actual GPU-only profile differs')
    d = read(path)
    require(d['kind'] == 'actual-observer-GPU-only-CPU-admission-profile' and d['scope']['backend'] == 'GPU'
            and d['scope']['NPU_activated'] is False and d['acceptance'] is None and d['full_core_complete'] is False,
            'GPU-only non-acceptance scope required')
    return d


def tools(d, numpy_site=None, numerical=False):
    adapters = HERE.parent/'adapters'; scripts = REPO/'skills/precision-compare/scripts'
    for name, digest in d['original_sources'].items():
        p = adapters/name if name in ('admit_observer_transparency_v2.py', 'observer_artifact_admission_v2.py') else HERE/name
        require(sha(regular(p)) == digest, 'frozen observer source changed: '+name)
    for p in (scripts, adapters, HERE):
        if str(p) not in sys.path: sys.path.insert(0, str(p))
    import split_observer_gpu_transport_v1 as transport
    require(Path(transport.__file__).resolve() == HERE/'split_observer_gpu_transport_v1.py', 'splitter import path differs')
    transport.verify_tools()
    if not numerical: return transport
    numpy_site = Path(numpy_site).resolve(strict=True)
    require(sha(regular(numpy_site/'numpy/__init__.py')) == NUMPY_INIT_SHA, 'existing NumPy1.26.4 source differs')
    sys.path.insert(0, str(numpy_site)); import numpy as np
    require(np.__version__ == '1.26.4' and Path(np.__file__).resolve() == numpy_site/'numpy/__init__.py', 'actual CPU NumPy import differs')
    import admit_observer_transparency_v2 as driver
    require(Path(driver.__file__).resolve() == adapters/'admit_observer_transparency_v2.py'
            and Path(driver.native.__file__).resolve() == adapters/'observer_artifact_admission_v2.py', 'observer import closure escaped repository')
    require(driver.HELPER_SHA is None and driver.ACTUAL_ENDPOINTS == {'GPU': None, 'NPU': None}, 'original two-endpoint activation globals changed')
    driver.native.verify_tools()
    require(Path(driver.compare_tensors.__file__).resolve() == scripts/'compare_tensors.py', 'shared tensor math imported outside frozen closure')
    require(not any(k == 'torch' or k.startswith(('torch.', 'torch_npu', 'transformers')) for k in sys.modules), 'GPU-only admission imported a device/model framework')
    return transport, driver, np


def safe_import(archive, mapping_path, export_controller, output, d, deadline):
    transport = tools(d); a = d['archive']; archive = regular(archive)
    mapping_path = regular(mapping_path, d['budgets']['metadata_member_bytes'])
    require(sha(mapping_path) == d['source_map_sha256'], 'external actual source-map bytes differ')
    ctl = transport.controller(export_controller, d['export_controller_sha256'], a['size_bytes'], a['sha256'], d['source_map_sha256'], a['logical_payload_bytes'])
    audit = transport.verify_full_archive(archive, a['size_bytes'], a['sha256'], d['source_map_sha256'], a['logical_payload_bytes'], deadline, ctl)
    require(audit['regular_members'] == a['regular_members'] and audit['mapped_files'] == a['mapped_files']
            and audit['large_objects'] == a['large_files'], 'actual674/672/194 archive inventory differs')
    mapping = read(mapping_path); expected = {r['path']: {'sha256': r['sha256'], 'size_bytes': r['size']} for r in mapping['files'].values()}
    expected['source-map.json'] = {'sha256': d['source_map_sha256'], 'size_bytes': mapping_path.stat().st_size}
    output = Path(output); require(not output.exists() and not output.is_symlink(), 'exclusive new GPU import directory required'); output.mkdir()
    seen = {}; total = 0
    with tarfile.open(archive, 'r|gz') as package:
        for member in package:
            require(time.monotonic() < deadline, 'CPU import deadline reached'); relative = transport.transport.safe(member.name)
            require(member.isfile() and not member.sparse and not member.issym() and not member.islnk() and member.name not in seen,
                    'ordinary unique regular import member required')
            total += member.size; require(0 <= member.size <= 1073741824 and total <= a['logical_payload_bytes'], 'expanded import budget differs')
            require(member.name in expected or member.name == 'export-summary.json', 'unmapped import member')
            path = contained(output, output.joinpath(*relative.parts)); path.parent.mkdir(parents=True, exist_ok=True)
            h = hashlib.sha256(); count = 0
            with path.open('xb') as destination, package.extractfile(member) as source:
                for block in iter(lambda: source.read(4*1024**2), b''):
                    require(time.monotonic() < deadline, 'CPU import copy deadline reached'); destination.write(block); h.update(block); count += len(block)
            ref = {'sha256': h.hexdigest(), 'size_bytes': count}; require(count == member.size, 'truncated imported member')
            if member.name in expected: require(ref == expected[member.name], 'copied actual member size/SHA differs')
            seen[member.name] = ref
    require(set(seen) == set(expected) | {'export-summary.json'} and len(seen) == a['regular_members']
            and total == a['logical_payload_bytes'] and sha(archive) == a['sha256'], 'final complete original gzip/member closure differs')
    for name, ref in seen.items(): require(sha(output/name) == ref['sha256'], 'imported original bytes changed')
    return {'status': 'actual_GPU_observer_imported_all_members_rehashed', 'audit': audit, 'files': seen,
            'original_source_map_sha256': d['source_map_sha256'], 'original_receipts_rewritten': False,
            'numeric_admission_performed': False, 'native_executions_started': 0}


def gpu_math(driver, endpoint, receipt_ref, output, d):
    run = driver.admit(endpoint, receipt_ref, 'GPU', output/'proof-gpu')
    pairs, sample_pairs = driver.derive_pairs(run['inventory'])
    pairs = [p for p in pairs if p['left']['backend'] == p['right']['backend'] == 'GPU']
    sample_pairs = [p for p in sample_pairs if p['left']['backend'] == p['right']['backend'] == 'GPU']
    require(len(pairs) == 6 and len(sample_pairs) == 1, 'exact six within-GPU mode pairs and one enabled sample pair required')
    large = [(name, path) for name, path in run['paths'].items() if name.endswith(('.npy', '.safetensors'))]
    require(len(large) == 194 and len({str(p) for _, p in large}) == 194, '194 distinct original GPU arrays required')
    resolved = {str(Path(path).resolve()): logical for logical, path in endpoint.resolved.items()}
    for _, path in large:
        logical = resolved.get(str(Path(path).resolve()))
        require(logical in endpoint.checked and driver.sha(path) == endpoint.checked[logical],
                'each194 large original must be admitted and freshly rehashed before comparisons')
    reports = []; samples = []
    for index, pair in enumerate(pairs):
        left, right = (driver.mode_run(run, pair[k]['mode']) for k in ('left', 'right'))
        r = driver.compare_scores(output/('scores-%02d' % index), left, right, run['inventory']); r.update(id=pair['id'], kind=pair['kind']); reports.append(r)
    for pair in sample_pairs:
        left, right = (driver.mode_run(run, pair[k]['mode']) for k in ('left', 'right'))
        r = driver.compare_samples(output/'samples-00', left, right, run['inventory']); r.update(id=pair['id'], kind=pair['kind']); samples.append(r)
    for name, digest in endpoint.checked.items(): require(driver.sha(endpoint.resolved[name]) == digest, 'original admitted metadata/large bytes changed during math')
    require(driver.sha(endpoint.manifest_path) == endpoint.expected_sha, 'original map changed during math')
    require(sum(x['distributions']['position_count'] for x in reports) == 282
            and len(samples[0]['metrics']['per_tensor']) == 98, 'actual GPU-only comparison coverage differs')
    return run, reports, samples, len(large)


def reuse_verified_import(args, d, deadline):
    """Reuse the byte-verified prior import, preserving its failed CPU admission."""
    prior = d['prior_import']; root = Path(prior['source_root']); require(root.is_absolute() and root.is_dir() and not root.is_symlink(), 'explicit original import root required')
    documents = {}
    for label in ('controller', 'worker', 'receipt'):
        ref = prior[label]; path = regular(Path(ref['path']), 16*1024**2)
        require(path.parent == root.parent and path.stat().st_size == ref['size_bytes'] and sha(path) == ref['sha256'], 'original failed CPU/import receipt changed')
        documents[label] = read(path)
    ctl, worker, receipt = (documents[k] for k in ('controller', 'worker', 'receipt'))
    require(ctl['task']=='OBSERVER-GPU-only-CPU' and ctl['status']=='failed' and ctl['child_returncode']==1 and ctl['timed_out'] is False and
        ctl['remaining_owned_process_group'] is False and ctl['driver_sha256']==prior['driver_sha256'] and ctl['profile_sha256']==prior['profile_sha256'] and
        ctl['native_executions_started']==0 and worker['error_type']==prior['failure_type'] and worker['error']==prior['failure_message'] and
        worker['native_executions_started']==0, 'reuse requires the explicit prior interface failure, never a native retry')
    require(receipt['status']=='actual_GPU_observer_imported_all_members_rehashed' and receipt['original_source_map_sha256']==d['source_map_sha256'] and
        receipt['original_receipts_rewritten'] is False and receipt['numeric_admission_performed'] is False and receipt['native_executions_started']==0 and
        prior['manual_new_version_after_interface_defect'] is True and prior['native_capture_repeated'] is False, 'prior import was not fully verified independently of failed admission')
    audit = receipt['audit']; a = d['archive']
    require(audit['regular_members']==a['regular_members']==674 and audit['mapped_files']==audit['mapped_source_files_rehashed']==672 and
        audit['large_objects']==194 and audit['logical_payload_bytes']==a['logical_payload_bytes'] and
        audit['deployment_namespace_override']==d['deployment_namespace_override'], 'reused original import coverage/source override differs')
    require(sha(regular(args.archive))==a['sha256'] and Path(args.archive).stat().st_size==a['size_bytes'] and
        sha(regular(args.source_map))==sha(regular(root/'source-map.json'))==d['source_map_sha256'] and
        sha(regular(args.export_controller))==d['export_controller_sha256'], 'original gzip/export/map changed since prior import')
    files=receipt['files']; require(len(files)==674 and all(not p.is_symlink() for p in root.rglob('*')) and
        {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}==set(files), 'reused source member inventory differs')
    total=0
    for name, ref in files.items():
        require(time.monotonic()<deadline, 'CPU reuse verification deadline reached')
        rel=PurePosixPath(name);require(name and not rel.is_absolute() and str(rel)==name and all(x not in ('', '.', '..') for x in name.split('/')) and chr(92) not in name, 'unsafe original import member')
        path=regular(contained(root,root.joinpath(*rel.parts))); require(path.stat().st_size==ref['size_bytes'] and sha(path)==ref['sha256'], 'reused original member bytes changed')
        total+=ref['size_bytes']
    require(total==a['logical_payload_bytes'], 'reused original expanded-byte accounting differs')
    for label in ('controller', 'worker', 'receipt'):
        ref=prior[label];require(sha(ref['path'])==ref['sha256'], 'original prior CPU receipt changed during reuse validation')
    return root, {'status':'verified_original_import_reused_after_versioned_interface_fix','prior_import':prior,'all_original_members_rehashed':674,
        'original_large_files_rehashed':194,'reused_payload_bytes':total,'new_array_copies':0,'prior_failed_admission_preserved':True,'native_executions_started':0,'numeric_admission_performed':False}


def worker(args):
    out = Path(args.output_dir).resolve(strict=True); d = profile(args.profile); before_source = sha(__file__)
    intent = read(out/'controller-start.json')
    require(args.internal_worker and intent['controller_pid'] == os.getppid()
            and process_start(os.getppid()) == intent['controller_starttime'] and intent['profile_sha256'] == PROFILE_SHA
            and intent['driver_sha256'] == before_source, 'internal worker requires the real owning controller/source')
    put(out/'worker-once.json', {'pid': os.getpid(), 'parent_pid': os.getppid(), 'profile_sha256': PROFILE_SHA, 'automatic_retry': False})
    deadline = time.monotonic()+d['budgets']['child_work_seconds']
    def expire(*_): raise TimeoutError('GPU-only observer CPU child850s')
    signal.signal(signal.SIGALRM, expire); signal.setitimer(signal.ITIMER_REAL, d['budgets']['child_work_seconds'])
    imported, receipt = reuse_verified_import(args, d, deadline)
    put(out/'import-receipt.json', receipt)
    _, driver, np = tools(d, args.numpy_site, True); endpoint = driver.native.Endpoint(imported/'source-map.json', d['source_map_sha256'])
    mapping = read(imported/'source-map.json')
    require(mapping['request'] == {'task': 'OBSERVER', 'backend': 'GPU', 'outer_receipt': d['outer_receipt']['source_path']}
            and mapping['raw_bytes_preserved'] is True and mapping['full_array_hashes_checked'] == 194 and mapping['retained_array_count'] == 0,
            'actual copied GPU endpoint role differs')
    original_claim = str(PurePosixPath(d['outer_receipt']['source_path']).parent)
    endpoint.get(original_claim+'/controller-receipt.json', d['native_controller_sha256'])
    original_outer = endpoint.json(d['outer_receipt']['source_path'], d['outer_receipt']['sha256'])
    require(original_outer['artifacts_manifest_sha256'] == d['artifacts_manifest_sha256'], 'actual profile/native manifest differs')
    analysis = out/'analysis'; analysis.mkdir(); run, reports, samples, large = gpu_math(driver, endpoint, d['outer_receipt'], analysis, d)
    require(sha(args.profile) == PROFILE_SHA and sha(__file__) == before_source and sha(args.export_controller) == d['export_controller_sha256'], 'frozen analysis source/input changed')
    tools(d, args.numpy_site, True)
    metadata_bytes = sum(p.stat().st_size for p in analysis.rglob('*') if p.is_file())
    require(metadata_bytes <= d['budgets']['max_report_metadata_bytes'], 'GPU analysis metadata exceeds128MiB')
    report = {'schema_version': 1, 'status': 'actual_GPU_only_observer_raw_BF16_and_sampled_comparisons_checked',
        'profile_sha256': PROFILE_SHA, 'driver_sha256': before_source, 'original_source_map_sha256': d['source_map_sha256'],
        'original_outer_receipt_sha256': d['outer_receipt']['sha256'], 'source_native_controller_sha256': d['native_controller_sha256'],
        'scope': {**d['scope'], 'original_large_sources_final_bytehash_checked': large, 'new_comparison_documents': 67},
        'target_distribution_pairs': reports, 'boundary_sample_comparisons': samples,
        'raw_derivation': {m: {'raw_sha256': x['raw_sha256'], 'targets': len(x['scores']), 'full_rows': len(x['positions']),
            'largest_abs_logprob_derivation_delta': x['raw_derivation_max_abs_delta']} for m, x in run['modes'].items()},
        'execution_census': {m: x['census'] for m, x in run['modes'].items()}, 'scalar_buffer_content_gaps': run['buffer_content_gaps'],
        'offline_tool_source_sha256': d['original_sources'], 'input_reuse': receipt, 'numpy': {'version': np.__version__, 'source_sha256': sha(np.__file__)},
        'limitations': ['One fixed160-token input; four modes share one loaded model, not fresh-process repeatability',
            'GPU-only: no NPU observer numeric result or full16-pair comparison',
            '98 sampled [1,47,64] boundaries are not full hidden tensors, complete operand values or local operator causes',
            'Frontend dispatch metadata does not identify kernels, fusion or accumulation precision',
            'Original scalar BF16 buffer fingerprint gap retained; no complete loaded parameter/buffer byte attestation',
            'Top100-union/complement-merged JS is not full-vocabulary error/divergence; no quality/P01 acceptance'],
        'native_executions_started_by_this_admission': 0, 'thresholds': None, 'acceptance': None, 'full_core_complete': False}
    require(sum(len(x['frozen_document_sha256']) for x in reports+samples) == 67, '67 frozen GPU-only comparison docs required')
    put(out/'observer-gpu-only-report.json', report); signal.setitimer(signal.ITIMER_REAL, 0)
    completion = {'status': report['status'], 'report': {'path': str(out/'observer-gpu-only-report.json'),
        'sha256': sha(out/'observer-gpu-only-report.json')}, 'native_executions_started': 0, 'timed_out': False}
    put(out/'worker-receipt.json', completion)
    print(json.dumps(completion, indent=2), flush=True)


def process_start(pid): return int((Path('/proc')/str(pid)/'stat').read_text().rpartition(')')[2].split()[19])


def terminate(proc):
    if proc is None: return
    started = time.monotonic()
    try: os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError: pass
    try: proc.wait(timeout=5)
    except subprocess.TimeoutExpired: pass
    # The leader may have exited while an owned same-group descendant ignored
    # TERM. Always KILL the original isolated group, then reap adopted members.
    try: os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError: pass
    proc.wait(timeout=5)
    while time.monotonic()-started < 20:
        while True:
            try: pid, _ = os.waitpid(-proc.pid, os.WNOHANG)
            except ChildProcessError: break
            if pid == 0: break
        try: os.killpg(proc.pid, 0)
        except ProcessLookupError: return
        time.sleep(.01)
    raise RuntimeError('owned CPU process group remains after bounded cleanup')


def supervise(args):
    require(os.name == 'posix', 'bounded Linux CPU process-group controller required')
    d = profile(args.profile); tools(d); out = Path(args.output_dir).absolute(); parent = out.parent.resolve(strict=True)
    require(out.parent == parent and not parent.is_symlink() and not out.exists() and not out.is_symlink(), 'exclusive new CPU task root required')
    require(shutil.disk_usage(parent).free >= d['budgets']['minimum_free_bytes'], 'observed CPU storage below5GiB')
    require(regular(args.archive).stat().st_size == d['archive']['size_bytes']
            and sha(regular(args.source_map, 16*1024**2)) == d['source_map_sha256']
            and sha(regular(args.export_controller, 1024**2)) == d['export_controller_sha256']
            and sha(regular(Path(args.numpy_site)/'numpy/__init__.py')) == NUMPY_INIT_SHA,
            'actual archive metadata or existing NumPy source not ready before claim')
    require(ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0, 'Linux owned CPU subreaper unavailable')
    marker = parent/'observer-GPU-only-admission-v2-once-124ade18c1298b1a.json'
    put(marker, {'task': 'OBSERVER-GPU-only-CPU', 'profile_sha256': PROFILE_SHA, 'driver_sha256': sha(__file__),
        'output': str(out), 'claimed_utc': utc(), 'automatic_retry': False, 'native_executions_started': 0})
    out.mkdir(mode=0o700); started = time.monotonic(); proc = None
    state = {'schema_version': 1, 'task': 'OBSERVER-GPU-only-CPU', 'status': 'running', 'started_utc': utc(),
        'controller_pid': os.getpid(), 'controller_starttime': process_start(os.getpid()), 'profile_sha256': PROFILE_SHA,
        'driver_sha256': sha(__file__), 'whole_cpu_seconds': 900, 'child_work_seconds': 850, 'cleanup_reserve_seconds': 20,
        'native_executions_started': 0, 'numeric_admission_performed_by_controller': False, 'automatic_retry': False, 'acceptance': None}
    argv = [sys.executable, '-S', '-B', str(Path(__file__).resolve()), '--internal-worker']
    for key in ('archive', 'source_map', 'export_controller', 'profile', 'numpy_site', 'output_dir'):
        argv += ['--'+key.replace('_', '-'), str(Path(getattr(args, key)).absolute())]
    state['argv'] = argv; put(out/'controller-start.json', state)
    def expire(*_): raise TimeoutError('GPU-only observer whole CPU900s or signal')
    previous = {s: signal.signal(s, expire) for s in (signal.SIGALRM, signal.SIGTERM, signal.SIGINT, signal.SIGHUP)}
    signal.setitimer(signal.ITIMER_REAL, 900); code = 2
    try:
        env = dict(os.environ)
        for key in ('PYTHONPATH', 'PYTHONHOME'): env.pop(key, None)
        env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', TORCH_DEVICE_BACKEND_AUTOLOAD='0')
        with (out/'stdout.bin').open('xb') as stdout, (out/'stderr.bin').open('xb') as stderr:
            proc = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True, env=env)
            while proc.poll() is None:
                if time.monotonic()-started >= 880: raise TimeoutError('CPU work deadline exhausted; cleanup reserve retained')
                require(sum(p.stat().st_size for p in out.rglob('*') if p.is_file()) <= d['budgets']['max_new_task_bytes'], 'CPU task exceeds4GiB')
                try: proc.wait(timeout=.5)
                except subprocess.TimeoutExpired: pass
            code = proc.returncode
        require(code == 0, 'CPU admission child failed; preserve original diagnostic logs')
        result = read(out/'stdout.bin'); r = result['report']; require(Path(r['path']) == out/'observer-gpu-only-report.json' and sha(r['path']) == r['sha256'], 'actual report ref differs')
        require(read(r['path'])['status'] == 'actual_GPU_only_observer_raw_BF16_and_sampled_comparisons_checked', 'no actual successful GPU-only report')
        state.update(status='completed', returncode=0, report=r)
    except BaseException as exc:
        state.update(status='failed', returncode=2, error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc(), partial_evidence_preserved=True)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        try: terminate(proc)
        except BaseException as exc: state['cleanup_error'] = str(exc)
        remaining = False
        if proc is not None:
            try: os.killpg(proc.pid, 0); remaining = True
            except ProcessLookupError: pass
        if remaining or 'cleanup_error' in state: state.update(status='failed', returncode=2)
        for key in ('stdout', 'stderr'):
            p = out/(key+'.bin')
            if p.is_file(): state[key] = {'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size}
        state.update(child_returncode=proc.returncode if proc is not None else None, timed_out=state.get('error_type') == 'TimeoutError', remaining_owned_process_group=remaining,
            finished_utc=utc(), elapsed_seconds=time.monotonic()-started)
        if (out/'worker-receipt.json').is_file():
            state['worker_receipt'] = {'path': str(out/'worker-receipt.json'), 'sha256': sha(out/'worker-receipt.json')}
            state['source_timed_out'] = read(out/'worker-receipt.json').get('timed_out')
        else: state['source_timed_out'] = None
        put(out/'controller-receipt.json', state)
        for sig, old in previous.items(): signal.signal(sig, old)
    return state


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for key in ('archive', 'source-map', 'export-controller', 'profile', 'numpy-site', 'output-dir'): p.add_argument('--'+key, type=Path, required=True)
    p.add_argument('--internal-worker', action='store_true'); args = p.parse_args()
    if args.internal_worker:
        try: worker(args)
        except BaseException as exc:
            out = Path(args.output_dir)
            try:
                marker = read(out/'worker-once.json')
                if marker['pid'] == os.getpid() and not (out/'worker-receipt.json').exists():
                    put(out/'worker-receipt.json', {'status': 'failed', 'error_type': type(exc).__name__, 'error': str(exc),
                        'traceback': traceback.format_exc(), 'timed_out': isinstance(exc, TimeoutError), 'native_executions_started': 0})
            except BaseException: pass
            raise
    else:
        result = supervise(args); print(json.dumps(result, indent=2)); return result['returncode']
    return 0


if __name__ == '__main__': raise SystemExit(main())

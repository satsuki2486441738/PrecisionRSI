"""CPU-only permanent-claim/process-table/owned-cleanup regressions."""
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace
from unittest.mock import patch
import importlib.util
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import tarfile
import time
import unittest

import npu_i03_launcher_v1 as launcher
import npu_i03_operations_v1 as operations


class GuardTests(unittest.TestCase):
    def test_real_reviewed_source_pins_match_original_bytes(self):
        repo=Path(__file__).resolve().parents[5]
        for name,digest in launcher.PINS.items():
            self.assertEqual(launcher.sha(repo/name),digest,name)
    def test_permanent_claim_concurrent_and_after_failure(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root/'claims').mkdir()
            with ThreadPoolExecutor(max_workers=8) as pool:
                results = list(pool.map(lambda n:launcher.claim_once(root,{'fixture':n}),range(8)))
            self.assertEqual(sum(result is not None for result in results),1)
            chosen=next(result for result in results if result is not None)
            raw=(chosen/'claim.json').read_bytes()
            self.assertIsNone(launcher.claim_once(root,{'retry':True}))
            self.assertEqual((chosen/'claim.json').read_bytes(),raw)
    def test_i03_claim_preserves_old_i01_claim_and_capture_bytes(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);old=root/'claims'/('npu-i01-'+launcher.ORIGINAL_UUID);old.mkdir(parents=True)
            sentinel=old/'capture-receipt.json';sentinel.write_bytes(b'{"historical_I01":"unchanged"}\n')
            before=sentinel.read_bytes();claim=launcher.claim_once(root,{'task':'I03','fixture':True})
            self.assertEqual(claim.name,'npu-i03-'+launcher.ORIGINAL_UUID)
            self.assertNotEqual(claim,old);self.assertEqual(sentinel.read_bytes(),before)
            self.assertIsNone(launcher.claim_once(root,{'retry':True}))
    def test_failed_i01_proof_stops_before_claim_or_process_query(self):
        args=SimpleNamespace(task_root=Path('/synthetic/new-I03'))
        with patch.object(launcher.sys,'platform','linux'),patch.dict(launcher.os.environ,{'PYTHONHASHSEED':'0'}),\
             patch.object(launcher,'source_check',side_effect=ValueError('actual I01 proof not admitted')),\
             patch.object(launcher,'claim_once') as claim,patch.object(launcher.subprocess,'run') as query:
            with self.assertRaisesRegex(ValueError,'I01 proof not admitted'):launcher.run(args)
            claim.assert_not_called();query.assert_not_called()
    def test_process_section_empty_busy_and_unknown_fail_closed(self):
        empty=b'| 0 Ascend910 | OK |\n| NPU Chip | Process id | Process name |\n| No running processes found in NPU 0 |\n'
        self.assertEqual(launcher.process_gate(empty)['status'],'explicitly_empty')
        bads=[b'not an inventory',b'| NPU Chip | Process id | Name |\n',
              b'| NPU Chip | Process id | Name |\n| 0 0 | 123 | python |\n',
              b'| NPU Chip | Process id | Name |\n| 0 0 | 123 | python |\n'+empty,
              b'| NPU Chip | Process id | Name |\n| 0 0 | unknown | python |\n'+empty,
              b'| NPU | Chip | Process id | Name |\n| 0 | 0 | 123 | python |\n'+empty]
        for raw in bads:
            with self.subTest(raw=raw):
                with self.assertRaises(ValueError):launcher.process_gate(raw)
        with self.assertRaisesRegex(ValueError,'every observed board'):
            launcher.process_gate(b'| 1 Ascend910 | OK |\n'+empty)
        with self.assertRaisesRegex(ValueError,'duplicate empty-board'):
            launcher.process_gate(empty+b'| No running processes found in NPU 0 |\n')
    def test_actual_recorded_readiness_format_and_sha(self):
        path=Path(__file__).with_name('i01-readiness-20261106-a-npu-smi.stdout')
        self.assertEqual(launcher.sha(path),'18df4690bf3af9688092acb6a23debb2fae8311a44721cbbabc9dc64d7d10cb6')
        observed=launcher.process_gate(path.read_bytes())
        self.assertEqual(observed['explicitly_empty_board_ids'],[0,1,3,4])
    def test_cli_resolved_source_hash_rejects_changed_bytes(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'npu-smi';path.write_bytes(b'#!/bin/sh\nexit 0\n')
            before=launcher.smi_identity(path,launcher.sha(path))
            self.assertEqual(before['first_four_bytes_hex'],'23212f62')
            path.write_bytes(b'#!/bin/sh\nexit 1\n')
            with self.assertRaisesRegex(ValueError,'real bytes differ'):launcher.smi_identity(path,before['sha256'])
    def test_frozen_source_bytes_and_duplicate_json_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'source.py';path.write_bytes(b'# original\n')
            frozen={str(path):launcher.sha(path)};launcher.assert_frozen(frozen)
            path.write_bytes(b'# changed\n')
            with self.assertRaisesRegex(ValueError,'frozen source'):launcher.assert_frozen(frozen)
            path.write_text('{"task":1,"task":2}')
            with self.assertRaisesRegex(ValueError,'duplicate JSON'):launcher.read(path)
    def test_storage_rejects_links(self):
        if os.name!='posix':self.skipTest('POSIX link fixture')
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);source=root/'source';source.mkdir();(source/'data').write_bytes(b'123')
            self.assertEqual(launcher.tree_bytes(root),3)
            (source/'link').symlink_to(source/'data')
            with self.assertRaisesRegex(ValueError,'symlink'):launcher.tree_bytes(root)


class StagingTests(unittest.TestCase):
    def archive(self,root,bad=None):
        source=b'# synthetic staging fixture only\n';relative='fixture.py'
        document={'schema_version':1,'task_id':operations.TASK_ID,'files':{relative:hashlib.sha256(source).hexdigest()}}
        raw=(json.dumps(document,indent=2)+'\n').encode();archive=root/'source.tar'
        with tarfile.open(archive,'w') as tf:
            for name,data in [(operations.NAME+'/source-manifest.json',raw),(operations.NAME+'/source/'+relative,source)]:
                member=tarfile.TarInfo('../escape' if bad=='escape' and name.endswith(relative) else name);member.size=len(data)
                if bad=='symlink' and name.endswith(relative):member.type=tarfile.SYMTYPE;member.linkname='/synthetic/unrelated';member.size=0
                tf.addfile(member,io.BytesIO(data))
        return archive,operations.sha(archive),hashlib.sha256(raw).hexdigest()
    def test_verified_new_staging_preserves_history_and_never_overwrites(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);old=root/'i01-cacheoff-20261106';old.mkdir();sentinel=old/'receipt.json';sentinel.write_bytes(b'old-I01-bytes')
            archive,digest,manifest=self.archive(root);result=operations.stage_archive(root,archive,digest,manifest)
            self.assertEqual(result['source_files'],1);self.assertIs(result['native_model_started'],False)
            operations.stage_archive(root,archive,digest,manifest)
            target=root/operations.NAME/'source/fixture.py';target.write_bytes(b'changed fixture')
            with self.assertRaisesRegex(ValueError,'never overwritten'):operations.stage_archive(root,archive,digest,manifest)
            self.assertEqual(target.read_bytes(),b'changed fixture');self.assertEqual(sentinel.read_bytes(),b'old-I01-bytes')
    def test_unsafe_or_link_archive_rejected_before_staging(self):
        for bad in ('escape','symlink'):
            with self.subTest(bad=bad),tempfile.TemporaryDirectory() as folder:
                root=Path(folder);archive,digest,manifest=self.archive(root,bad)
                with self.assertRaises(ValueError):operations.stage_archive(root,archive,digest,manifest)
                self.assertFalse((root/operations.NAME).exists())


@unittest.skipUnless(sys.platform.startswith('linux'),'Linux subreaper fixtures')
class CleanupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path=Path(__file__).with_name('npu_three_repeat_launcher_v4.py')
        spec=importlib.util.spec_from_file_location('i01_test_reviewed_helpers',path)
        cls.helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(cls.helper)
        if launcher.sha(path)!=launcher.PINS[launcher.HELPER]:raise AssertionError('reviewed cleanup helper changed')
        launcher.subreaper()
    def fixture(self, exit_leader):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        root=Path(temp.name);(root/'source').mkdir()
        pidfile=root/'grandchild.pid'
        grandchild="import os,signal,time,pathlib;os.setsid();signal.signal(signal.SIGTERM,signal.SIG_IGN);pathlib.Path("+repr(str(pidfile))+").write_text(str(os.getpid()));time.sleep(30)"
        leader="import subprocess,sys,time;subprocess.Popen([sys.executable,'-c',"+repr(grandchild)+"]);time.sleep("+('0.3' if exit_leader else '30')+")"
        return root,pidfile,[sys.executable,'-B','-c',leader]
    def assert_gone(self,pidfile):
        self.assertTrue(pidfile.exists());pid=int(pidfile.read_text())
        with self.assertRaises(ProcessLookupError):os.kill(pid,0)
        self.assertEqual(self.helper.descendants(),{})
    def test_timeout_reaps_session_escaping_term_resistant_child(self):
        root,pidfile,argv=self.fixture(False)
        with self.assertRaises(TimeoutError):launcher.bounded(self.helper,argv,root/'stdout',root/'stderr',time.monotonic()+.7,root)
        self.assert_gone(pidfile)
    def test_leader_success_with_leftover_child_is_failure_and_reaped(self):
        root,pidfile,argv=self.fixture(True)
        with self.assertRaisesRegex(ValueError,'unexpected owned descendant'):
            launcher.bounded(self.helper,argv,root/'stdout',root/'stderr',time.monotonic()+3,root)
        self.assert_gone(pidfile)
    def test_successful_cpu_worker_has_no_remaining_child(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'source').mkdir()
            code=launcher.bounded(self.helper,[sys.executable,'-B','-c','print("fixture")'],root/'stdout',root/'stderr',time.monotonic()+3,root)
            self.assertEqual(code,0);self.assertEqual(self.helper.descendants(),{})


if __name__=='__main__':unittest.main()

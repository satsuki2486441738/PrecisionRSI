"""One bounded CPU full-copy export after the real H100 I04 terminal receipt.

The original286 raw/NPY sources are hashed and copied by the pinned exporter.
No model, framework or device probe is imported. This is transport provenance;
independent numerical admission remains mandatory.
"""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import signal
import sys
import time

ROOT = Path('/srv/precision-task/i04-batch-padding-20261107-gpu-v2')
CLAIM_NAME = 'REDACTED_APP_ID'
CONTROLLER_SHA='c51c33742113be3961721efa3214bfca0eccb3346dd1de3e63f051c37b233d27'
CAPTURE_SHA='17b236d2c733e3f1623e4738c0c70b4cacce5da7431041584c7f638eb6a7f4a3'
HERE = Path(__file__).resolve().parent
EXPORT_SHA = '26df0229d2c783d47f2232e308a4a224861d06f71eff2411dabe3ffcb88d8c84'
RECORD_SHA = '2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'
TOTAL, CHILD, ENVELOPE, CLEANUP = 960, 900, 920, 20
GIB = 1024 ** 3
LOGICAL_CAP,ENCODED_CAP = 1207959552,1610612736
STAGE_SHA='26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
EXPECTED_SHA='22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76'
CPU_SHA='8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec'
I03_SHA='3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c'
COLLECTOR_SHA='7f438e18d507438556566de07f94f1928e01d9aa1a62f0e3a5b53484edce2663'
LAUNCHER_SHA='4c59dd059c63a5e9929c7f290b2c31d140dea4e98ef24cb0fc5a91dc3b9cfe31'


def require(ok, message):
    if not ok: raise ValueError(message)


def utc(): return datetime.now(timezone.utc).isoformat()


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 ** 2), b''): value.update(block)
    return value.hexdigest()


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate JSON key'); result[key] = value
        return result
    def reject(value): raise ValueError('nonfinite JSON token ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs, parse_constant=reject)


def put(path, document):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(document, stream, indent=2, allow_nan=False); stream.write('\n')


def regular(path,limit=16*1024**2):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size<=limit, 'bounded original regular source required')
    return path


def preflight(root, here):
    root, here = Path(root), Path(here)
    require(root.is_dir() and not root.is_symlink() and here.is_dir() and
        not here.is_symlink() and here.resolve().is_relative_to(root.resolve()), 'new I04 task/tool roots required')
    exporter, recorder = here / 'export_i04_evidence_v1.py', here / 'record_run.py'
    require(sha(regular(exporter)) == EXPORT_SHA and sha(regular(recorder)) == RECORD_SHA, 'frozen CPU tool source differs')
    claim = root / 'claims' / CLAIM_NAME
    terminal, outer = claim / 'controller-receipt.json', claim / 'capture-receipt.json'
    controller, receipt = read(regular(terminal)), read(regular(outer))
    require(controller.get('task') == 'I04' and controller.get('status') == 'completed' and
        type(controller.get('returncode')) is int and controller['returncode'] == 0 and
        controller.get('timed_out') is False and controller.get('remaining_descendants') == [], 'GPU I04 lifecycle must be terminal and cleaned')
    fixed = {'task':'I04','backend':'GPU','status':'completed','returncode':0,'timed_out':False,
             'native_capture_count':1,'native_forward_calls_total':4,'model_loads':1}
    require(all(key in receipt and type(receipt[key]) is type(value) and receipt[key] == value for key,value in fixed.items()),
        'real successful4-call one-process GPU I04 capture required')
    require(receipt.get('stage_spec_source_sha256')==STAGE_SHA and receipt.get('expected_inventory_source_sha256')==EXPECTED_SHA and
        receipt.get('cpu_prerequisite_source_sha256')==CPU_SHA and receipt.get('i03_prerequisite_source_sha256')==I03_SHA and
        receipt.get('collector_sha256')==COLLECTOR_SHA,'actual frozen I04 capture/input/proof source identities differ')
    validation=receipt.get('validation',{})
    require(validation.get('status')=='i04_output_artifacts_checked' and validation.get('target_scores')==762 and
        validation.get('distribution_rows')==282 and validation.get('physical_raw_rows')==896 and
        validation.get('valid_raw_rows')==768 and validation.get('pad_only_raw_rows')==128,'actual full I04 output validation inventory differs')
    launcher=root/'h100_i04_lifecycle_v2.py'
    require(sha(regular(launcher))==LAUNCHER_SHA and receipt.get('source_sha256',{}).get(str(launcher))==LAUNCHER_SHA,
        'actual reviewed GPU I04 launcher binding differs')
    require(controller.get('metadata_export_reserved_seconds')==TOTAL and controller.get('controller_work_seconds')==2020,
        'actual NPU lifecycle must reserve the full CPU export envelope')
    native_claim=read(regular(claim/'claim.json'))
    require(native_claim.get('allocation_id')==CLAIM_NAME and
        native_claim.get('whole_attempt_seconds')==3000 and native_claim.get('capture_seconds')==900 and
        native_claim.get('lifecycle_sha256')==LAUNCHER_SHA and native_claim.get('cpu_prerequisite_sha256')==CPU_SHA and
        native_claim.get('metadata_export_reserved_seconds')==TOTAL and native_claim.get('controller_work_seconds')==2020,
        'actual app-scoped native claim differs')
    beginning=datetime.fromisoformat(native_claim['entry_started_utc'])
    ending=datetime.fromisoformat(controller['finished_utc'])
    require(beginning.tzinfo is not None and ending.tzinfo is not None,'recorded native same-clock UTC timestamps required')
    elapsed=(ending-beginning).total_seconds()
    require(math.isfinite(elapsed) and elapsed>=0,'recorded native same-clock duration required')
    require(elapsed + TOTAL <= 3000, 'recorded native duration plus finite CPU envelope exceeds3000s stage accounting')
    require(sha(terminal)==CONTROLLER_SHA and sha(outer)==CAPTURE_SHA,'actual original GPU terminal/capture byte pins differ')
    require(not any(name in sys.modules for name in ('torch','torch_npu','numpy')), 'CPU export runner imported a framework')
    return exporter, recorder, terminal, outer, elapsed


def verify_result(result, mapping, source_map, outer, root):
    require(mapping.get('request') == {'task':'I04','backend':'GPU','outer_receipt':str(outer)}, 'source-map request differs')
    require(mapping.get('full_array_hashes_checked') == 286 and mapping.get('retained_array_count') == 0, 'all286 GPU source arrays must be hashed and copied')
    require(not any(item.get('retained_at_source') is True for item in mapping['files'].values()),'GPU map must not retain source payload')
    positions={'A':sorted(set(i*127//15 for i in range(16))|set(range(127,159))),
               'B':sorted(set(i*63//15 for i in range(16))|set(range(63,95)))}
    modes=['alone-A','alone-B','batch-left','batch-right']
    expected={'modes/%s/raw-native-logits.safetensors'%mode for mode in modes}
    expected|={'modes/%s/request-%s/dist-p%03d.npy'%(mode,request,p) for mode in modes
        for request in ([mode[-1]] if mode.startswith('alone-') else ['A','B']) for p in positions[request]}
    output = PurePosixPath(read(outer)['output_dir'])
    copied={path:item for path,item in mapping['files'].items() if path.endswith(('.npy','.safetensors'))}
    require({PurePosixPath(path).relative_to(output).as_posix() for path in copied} == expected, 'exact four logits/282 NPY copied inventory differs')
    for original,item in copied.items():
        relative=PurePosixPath(item.get('path',''))
        require(not relative.is_absolute() and bool(relative.parts) and '..' not in relative.parts and
            '\\' not in str(relative),'copied payload relative path differs')
        payload=Path(source_map).parent.joinpath(*relative.parts)
        require(payload.resolve().is_relative_to(Path(source_map).parent.resolve()) and not payload.is_symlink() and
            payload.is_file() and type(item.get('size')) is int and payload.stat().st_size==item['size'] and
            sha(payload)==item['sha256'],'actual copied array size/SHA differs')
    require(result.get('status') == 'i04_transport_export_completed' and result.get('retained_array_count') == 0 and
        result.get('native_executions_started') == 0 and result.get('transport_allowed_by_actual_size') is True and
        type(result.get('archive_bytes')) is int and 0 < result['archive_bytes'] <= ENCODED_CAP and
        type(result.get('logical_payload_bytes')) is int and 0 <= result['logical_payload_bytes'] <= LOGICAL_CAP and
        result.get('source_map_sha256') == sha(source_map), 'actual transport receipt/budget differs')
    archive = regular(result['archive'],ENCODED_CAP)
    require(archive.resolve().is_relative_to(Path(root).resolve()) and archive.stat().st_size == result['archive_bytes'] and
        sha(archive) == result['archive_sha256'], 'actual full-copy archive size/SHA differs')
    return copied


def main():
    os.umask(0o077)
    started = time.monotonic()
    exporter, recorder, terminal, outer, prior = preflight(ROOT, HERE)
    put(ROOT / 'metadata-export-once.json', {'task':'I04-full-export','claimed_utc':utc(),
        'outer_receipt_sha256':sha(outer),'runner_sha256':sha(__file__),'native_executions_started':0,
        'cpu_envelope_seconds':TOTAL,'tools_root':str(HERE),'automatic_retry':False})
    spec = importlib.util.spec_from_file_location('i04_export_generic_recorder', recorder)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    require(Path(module.__file__).resolve() == recorder.resolve() and sha(recorder) == RECORD_SHA, 'actual generic module source differs')
    def interrupted(signum, frame): raise KeyboardInterrupt('finite CPU export signal ' + str(signum))
    previous = {sig:signal.signal(sig, interrupted) for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP,signal.SIGALRM)}
    signal.setitimer(signal.ITIMER_REAL, max(.01, TOTAL - (time.monotonic() - started)))
    state = {'schema_version':1,'task':'I04-full-export','backend':'GPU','status':'running','started_utc':utc(),
        'total_budget_seconds':TOTAL,'child_work_timeout_seconds':CHILD,'generic_envelope_timeout_seconds':ENVELOPE,
        'cleanup_reserve_seconds':CLEANUP,'prior_native_same_clock_seconds':prior,'maximum_recorded_native_plus_cpu_seconds':prior+TOTAL,
        'native_executions_started':0,'source_arrays_retained':False,'exporter_sha256':EXPORT_SHA,'generic_recorder_sha256':RECORD_SHA,
        'runner_sha256':sha(__file__),'capture_controller_sha256':sha(terminal),'outer_receipt_sha256':sha(outer),'acceptance':None}
    code, run = 1, None
    try:
        remaining = TOTAL - (time.monotonic() - started) - CLEANUP
        require(remaining >= ENVELOPE, 'CPU export work budget unavailable')
        run, command = module.record_run(ROOT / 'exports','gpu','i04-full-export',ENVELOPE,
            lambda folder:[sys.executable,'-B',str(exporter),'--outer-receipt',str(outer),'--task-root',str(ROOT),
                           '--output',str(folder / 'payload')],cwd=ROOT)
        state['generic_receipt'] = {'path':str(run / 'command.json'),'sha256':sha(run / 'command.json')}
        require(command['status'] == 'completed' and command['returncode'] == 0, 'CPU export failed; raw logs/partial output retained')
        result = read(run / 'stdout.bin'); payload = run / 'payload'; source_map = payload / 'source-map.json'
        mapping = read(source_map); copied = verify_result(result,mapping,source_map,outer,ROOT)
        require(sha(exporter) == EXPORT_SHA and sha(recorder) == RECORD_SHA and sha(terminal) == state['capture_controller_sha256'] and
            sha(outer) == state['outer_receipt_sha256'], 'frozen tool/capture source changed during CPU export')
        state.update(status='completed',source_map_path=str(source_map),source_map_sha256=sha(source_map),
            mapped_files=len(mapping['files']),copied_arrays=len(copied),retained_arrays=0,archive=result,raw_capture_and_arrays_unmodified=True)
        code = 0
    except BaseException as exc:
        state.update(status='failed',error_type=type(exc).__name__,error=str(exc),automatic_retry=False)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        for sig,handler in previous.items():signal.signal(sig,handler)
        state.update(finished_utc=utc(),elapsed_seconds=time.monotonic()-started,returncode=code)
        target = run / 'metadata-export-controller.json' if run is not None else HERE / ('export-launch-failure-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '.json')
        put(target,state)
        print(json.dumps({**state,'controller_path':str(target)},allow_nan=False),flush=True)
    return code


if __name__ == '__main__': raise SystemExit(main())

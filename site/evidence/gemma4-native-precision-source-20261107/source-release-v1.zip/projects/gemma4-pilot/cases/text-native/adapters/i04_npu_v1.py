"""One selected original NPU/model; four cache-off I04 calls, no fallback."""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import json
import os
import sys

import i04_common_v1 as common
from pilot_ascend_candidate_v3 import (check_allocation,check_stack,check_version,
    normalize_runtime_uuid,observe_driver_version,set_policy,get_policy)


def main():
    args = common.arguments('npu')
    stage, inventory, refs, proof = common.prepare(args,'npu',__file__)
    sys.path.insert(0,str(common.HERE.parent/'transfer'))
    from npu_three_repeat_launcher_v4 import binding,memory_observation
    allocation, physical = binding(args.allocation_receipt,args.native_mapping,args.native_source); check_allocation(allocation,0)
    common.require(physical == common.prior.ORIGINAL_NPU_UUID, 'I04 selected NPU UUID differs from original cached/input anchor')
    memory = memory_observation()
    common.require(memory['effective_available_bytes'] >= stage['limits']['minimum_npu_host_effective_available_bytes'], 'effective host/cgroup memory is below80GiB')
    with common.bounded_native(stage,'npu'):
        import torch
        import torch_npu
        import numpy
        import transformers
        import transformers.masking_utils as masking_utils
        from transformers import AutoModelForMultimodalLM
        npu = torch_npu.npu
        driver, provenance = observe_driver_version(torch_npu.utils.get_cann_version,args.driver_source)
        versions = {'torch':str(torch.__version__),'torch_npu':str(torch_npu.__version__),'transformers':str(transformers.__version__),
            'numpy':str(numpy.__version__),'cann':check_version('CANN',torch_npu.utils.get_cann_version('CANN')),'driver':driver}
        check_stack(versions)
        common.require(versions == {'torch':'2.9.0+cpu','torch_npu':'2.9.0.post2','transformers':'5.10.1','numpy':'1.26.4','cann':'9.1.0','driver':'25.5.2'}, 'frozen NPU stack differs')
        common.require(npu.is_available() and npu.device_count() == 8, 'eight-visible-device instance unavailable')
        npu.set_device(0); common.require(npu.current_device() == 0 and npu.is_bf16_supported(), 'selected ordinal/BF16 differs')
        actual = normalize_runtime_uuid(getattr(npu.get_device_properties(0),'uuid',None)); free,total = map(int,npu.mem_get_info(0))
        common.require(actual == physical and free >= stage['limits']['minimum_free_device_bytes'], 'native UUID/free memory differs')
        before,policy = set_policy(torch,npu,numpy); common.check_refs(refs); common.initialize_output(args,proof)
        common.put(args.output/'driver-version-provenance.json',provenance); common.put(args.output/'policy-before-load.json',{'before':before,'configured':policy})
        model,identity = common.prior.load_verified_model(args,torch,AutoModelForMultimodalLM,common.read(common.HERE/'upstream-identity.json'))
        common.require(get_policy(torch,npu) == policy, 'NPU policy changed during model load'); common.put(args.output/'policy-after-load.json',get_policy(torch,npu))
        implementations = {'modeling':identity['modeling_source'],'masking_utils':common.file_ref(masking_utils.__file__)}; common.check_refs(implementations)
        def reset():
            previous,configured = set_policy(torch,npu,numpy); common.require(configured == policy,'NPU reset policy differs')
            return {'seed':0,'before':previous,'settings':configured}
        summaries = common.capture_all(model,torch,args.device,inventory,args.output,'npu',reset,lambda:get_policy(torch,npu),lambda:npu.synchronize(0))
        after_capture = get_policy(torch,npu); common.require(after_capture == policy,'NPU policy changed during capture'); common.put(args.output/'policy-after-capture.json',after_capture)
        runtime = {'backend':'npu','model_identity':identity,'implementation_sources':implementations,'versions':versions,
            'device_argument':args.device,'device_name':npu.get_device_name(0),'runtime_uuid':actual,'instance_visible_count':8,'compute_device_count':1,
            'free_bytes_before_load':free,'total_bytes':total,'host_memory':memory,'allocation_receipt_sha256':common.sha(args.allocation_receipt),
            'native_mapping_sha256':common.sha(args.native_mapping),'native_source_sha256':common.sha(args.native_source),
            'driver_version_provenance':provenance,'driver_version_provenance_sha256':common.sha(args.output/'driver-version-provenance.json'),
            'math_policy':policy,'seed':0,'native_capture_modes':summaries,
            'visible_device_env':{key:os.environ.get(key) for key in ('ASCEND_RT_VISIBLE_DEVICES','ASCEND_VISIBLE_DEVICES')},
            'python':sys.version,'python_executable':sys.executable,
            'package_sources':{'torch':common.file_ref(torch.__file__),'torch_npu':common.file_ref(torch_npu.__file__),
                'transformers':common.file_ref(transformers.__file__),'numpy':common.file_ref(numpy.__file__)}}
        print(json.dumps(common.finalize(args,'npu',inventory,refs,runtime),allow_nan=False),flush=True)


if __name__ == '__main__': main()

"""Independent stdlib I04 selected E02, without model or device execution.

Replay all18 target pairs (159 or95 each), all6 matched cross-backend47-row
contrasts, and three reported global distribution extrema after deduplication.
Read complete selected vocabulary rows; fresh-hash all572 admitted large files.
The immutable I03 independent verifier supplies only stdlib binary/scalar tools.
No admission/shared numerical implementation or framework is imported.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path, PurePosixPath
import signal
import time

CASE='projects/gemma4-pilot/cases/text-native'
MAIN=CASE+'/adapters/admit_i04_batch_padding_v1.py'
MAIN_SHA='640b0af596111e12eb73aca20f7b8e5b101c04341af0aed2d3a5f9a1d2f19db0'
HELPER=CASE+'/adapters/i04_artifact_admission_v1.py'
HELPER_SHA='0d43e77420285436f4151d42c6cd8a6792001b004e0e0b870242f90c5bd33719'
CONTROLLER=CASE+'/transfer/run_i04_actual_compare_v1.py'
CONTROLLER_SHA='a01ab2aef1ebb99402bd04f739f9f8e751979e77d87599835d5f413c88c59178'
INDEPENDENT_SHA='863019a1bd9875d418630c4c5e547576232e225fd66a98d63d51f3023701a44e'
STAGE_SHA='26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
EXPECTED_SHA='22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76'
CPU_SHA='8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec'
I03_SHA='3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c'
INPUTS={'A':'643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0',
        'B':'f4bca8e16d2e7768c6f9dff0677ea329ccf46ed254e211dc2ce2f9852f416792'}
COLLECTORS={'GPU':'7f438e18d507438556566de07f94f1928e01d9aa1a62f0e3a5b53484edce2663',
            'NPU':'eb313464396db09e029db2f63012cd614311357247b67497c4618e977f7fad4e'}
TASK='gemma4-i04-batch-padding-v1'
MODES=['alone-A','alone-B','batch-left','batch-right']
LENGTHS={'A':160,'B':96};PROMPTS={'A':128,'B':64}
VOCAB=262144
FIELDS=('tail_merged_js','probability_rmse','max_probability_error')


def independent_module():
    path=Path(__file__).resolve().with_name('verify_i03_selected_e02_v1.py')
    if path.is_symlink() or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=INDEPENDENT_SHA:
        raise ValueError('frozen stdlib independent binary/scalar dependency differs')
    spec=importlib.util.spec_from_file_location('_i04_independent_stdlib_primitives',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


base=independent_module()
require,parse,put,number,equal=base.require,base.parse,base.put,base.number,base.equal
original,child,flag=base.original,base.child,base.flag


class Audit(base.Audit):
    def tick(self):
        if time.monotonic()>=self.deadline:raise TimeoutError('I04 independent selected E02 CPU900s deadline reached')


class Endpoint(base.Endpoint):
    """Original POSIX identities stay unchanged across copied/retained bytes."""
    def __init__(self,audit,info,backend):
        self.audit,self.backend=audit,backend;ref=info['source_map']
        self.path=audit.file(ref['path'],ref['sha256']);self.document=audit.json(self.path,ref['sha256']);self.files=self.document['files']
        require(self.document.get('schema_version')==1 and self.document.get('request',{}).get('task')=='I04' and
            self.document['request'].get('backend')==backend and self.document['request'].get('outer_receipt')==info['receipt']['source_path'],
            'original I04 endpoint request differs')
        require(backend!='GPU' or 'retained_root' not in info,'GPU must supply every original large byte')
        raw=Path(info['retained_root']) if backend=='NPU' else None
        require(raw is None or not raw.is_symlink(),'NPU retained root must not be a symlink')
        self.root=raw.resolve(strict=True) if raw is not None else None
        require(backend=='GPU' or self.root is not None and self.root.is_dir(),'explicit NPU retained root required')


def positions(request):
    require(request in LENGTHS,'unknown logical request')
    return sorted(set(i*(PROMPTS[request]-1)//15 for i in range(16))|set(range(PROMPTS[request]-1,LENGTHS[request]-1)))


def plans():
    """Six logical observations; ID0 is a valid token when inside a length."""
    result={}
    for mode in MODES:
        members=['A'] if mode=='alone-A' else ['B'] if mode=='alone-B' else ['A','B']
        width=LENGTHS[members[0]] if mode.startswith('alone-') else 160
        for slot,request in enumerate(members):
            result[(mode,request)]={'shape':[len(members),width,VOCAB],'slot':slot,'width':width,
                'physical_offset':width-LENGTHS[request] if mode=='batch-left' else 0}
    return result


def pair_inventory():
    conditions={'A':['alone-A','batch-left','batch-right'],'B':['alone-B','batch-left','batch-right']}
    result=[]
    for request,modes in conditions.items():
        for mode in modes:result.append(([f'gpu-{mode}-{request.lower()}',f'npu-{mode}-{request.lower()}'],request,'cross_backend_matched'))
    for backend in ('gpu','npu'):
        for request,modes in conditions.items():
            for a,b in itertools.combinations(modes,2):
                result.append(([f'{backend}-{a}-{request.lower()}',f'{backend}-{b}-{request.lower()}'],request,'within_backend_batch_padding'))
    return result


def target_metrics(a,b,coordinates):
    count=len(coordinates);require(count in (159,95) and len(a)==len(b)==count,'complete159/95 request target vector required')
    require(all(type(x) in (int,float) and math.isfinite(x) and x<=0 for x in a+b),'finite nonpositive target logprobs required')
    errors=[abs(x-y) for x,y in zip(a,b)];worst=errors.index(max(errors))
    na,nb=[math.fsum(-x for x in side)/count for side in (a,b)]
    return {'target_count':count,'side_a_nll_nat_per_token':na,'side_b_nll_nat_per_token':nb,
        'nll_abs_diff_nat_per_token':abs(na-nb),'mae_nat':math.fsum(errors)/count,'p99_nat':base.quantile(errors,.99),
        'max_abs_nat':errors[worst],'max_coordinate':coordinates[worst]}


def distribution_metrics(a,b):
    result=base.distribution_metrics(a,b)
    if not result['top1_agreement']:
        ia=min(range(len(a)),key=lambda i:(-a[i],i));ib=min(range(len(b)),key=lambda i:(-b[i],i))
        topa=sorted(range(len(a)),key=lambda i:(-a[i],i))[:2];topb=sorted(range(len(b)),key=lambda i:(-b[i],i))[:2]
        result['top1_mismatch']={'side_a_token':ia,'side_b_token':ib,
            'probabilities':[{'token':i,'side_a':math.exp(a[i]),'side_b':math.exp(b[i])} for i in sorted({ia,ib})],
            'side_a_margin':math.exp(a[topa[0]])-math.exp(a[topa[1]]),'side_b_margin':math.exp(b[topb[0]])-math.exp(b[topb[1]])}
    return result


def select(report):
    pairs=report['target_distribution_pairs'];wanted=pair_inventory()
    require(len(pairs)==18 and [(p['sides'],p['request'],p['kind']) for p in pairs]==wanted,'exact request-preserving18 pair order required')
    chosen=set()
    for i,pair in enumerate(pairs):
        rows=pair['distributions']['positions'];expected=positions(pair['request'])
        require(len(rows)==47 and [r['position'] for r in rows]==expected,'all47 per-request distribution coordinates required')
        require(len({r['sample'] for r in rows})==1,'unique logical sample required')
        if pair['kind']=='cross_backend_matched':chosen.update((i,p) for p in expected)
    extrema=[]
    for field in FIELDS:
        i=max(range(18),key=lambda i:number(pairs[i]['distributions']['aggregate'][field]['max']))
        claim=pairs[i]['distributions']['aggregate'][field];p=claim['max_coordinate']['position']
        require(p in positions(pairs[i]['request']),'reported global extremum outside frozen request predictors')
        row=next(r for r in pairs[i]['distributions']['positions'] if r['position']==p)
        require(claim['max_coordinate']['sample']==row['sample'],'global extremum logical sample differs')
        equal(number(row[field]),claim['max'],'reported row/global extremum')
        chosen.add((i,p));extrema.append({'metric':field,'pair_index':i,'sides':pairs[i]['sides'],'request':pairs[i]['request'],
            'position':p,'claim':claim,'reported_tie_pair_count':sum(number(x['distributions']['aggregate'][field]['max'])==number(claim['max']) for x in pairs)})
    require(282<=len(chosen)<=285,'bounded six-matched-cross-plus-extrema subset differs')
    return {'schema_version':1,'status':'subset_frozen_before_scalar_values','target_pairs':18,'request_target_counts':{'A':159,'B':95},
        'distribution_rows':[{'pair_index':i,'sides':pairs[i]['sides'],'request':pairs[i]['request'],'position':p} for i,p in sorted(chosen)],
        'distribution_extrema_claims':extrema,'matched_cross_pair_rows':282,'distribution_rows_selected':len(chosen),
        'native_KV_checks':0,'original_model_values_decoded_before_selection':False,'selection_uses_frozen_report_metrics':True,
        'tie_policy':'first pair in immutable report order; reported first row maximum; deduplicate pair/position',
        'thresholds':None,'acceptance':None}


def completed(doc):
    require(doc.get('status')=='completed' and type(doc.get('returncode')) is int and doc['returncode']==0,'actual completed0 receipt required')


def controller_chain(audit,path,digest):
    require(isinstance(digest,str) and base.HEX.fullmatch(digest),'external original controller SHA required')
    state=audit.json(path,digest);completed(state);run=Path(path).resolve(strict=True).parent;tools=Path(state['tools_root'])
    require(state.get('task')=='I04' and state.get('run')==str(run) and type(state.get('child_returncode')) is int and state['child_returncode']==0 and
        state.get('native_executions_started')==0 and state.get('whole_cpu_seconds')==960 and state.get('child_work_seconds')==920 and
        state.get('cleanup_reserve_seconds')==20 and state.get('analysis_seconds')==900 and
        state.get('timed_out') is False and not state.get('cleanup_incomplete',False),'bounded completed offline I04 controller differs')
    tool_doc=audit.json(tools/'tool-bundle-manifest.json',state['tool_manifest_sha256'])
    require(tool_doc['files'][MAIN]['sha256']==MAIN_SHA and tool_doc['files'][HELPER]['sha256']==HELPER_SHA and
        tool_doc['files'][CONTROLLER]['sha256']==CONTROLLER_SHA,
        'frozen I04 analysis/helper/controller source closure differs')
    for name,ref in tool_doc['files'].items():
        p=PurePosixPath(name);require(not p.is_absolute() and str(p)==name and '..' not in p.parts and '\\' not in name,'unsafe tool source path')
        actual=audit.file(tools/name,ref['sha256']);require(actual.stat().st_size==ref['size_bytes'],'frozen tool source size differs')
    argv=state['argv'];spec_ref,report_ref=state['comparison_spec'],state['report']
    require(len(argv)==11 and argv[1]=='-B' and Path(argv[2]).resolve()==(tools/MAIN).resolve() and
        Path(spec_ref['path']).resolve()==run/'comparison-spec.json' and Path(report_ref['path']).resolve()==run/'bundle/i04-comparison-report.json' and
        flag(argv,'--spec')==spec_ref['path'] and flag(argv,'--spec-sha256')==spec_ref['sha256'] and
        flag(argv,'--output-dir')==str(run/'bundle') and flag(argv,'--timeout-seconds')=='900','literal original numerical argv/report/spec differs')
    for key in ('stdout','stderr'):
        ref=state[key];actual=audit.file(ref['path'],ref['sha256']);require(actual.stat().st_size==ref['bytes'],'original numerical log size differs')
    if 'generic_receipt' in state:
        ref=state['generic_receipt'];generic=audit.json(ref['path'],ref['sha256']);completed(generic)
        require(generic['argv']==argv and generic['child_returncode']==0 and generic['timeout']==920 and Path(generic['cwd']).resolve()==tools.resolve(),
            'original920-second generic numerical receipt differs')
        for key in ('stdout','stderr'):
            require(Path(state[key]['path']).resolve()==Path(ref['path']).parent.resolve()/(key+'.bin'),'controller/generic raw log path differs')
        execution=generic['execution'];snapshot=audit.file(execution['snapshot'],execution['sha256'])
        require(snapshot.read_bytes()==audit.file(execution['path']).read_bytes(),'original/snapshotted CPU environment profile differs')
        profile=audit.json(snapshot,execution['sha256']);require(profile['env']['TORCH_DEVICE_BACKEND_AUTOLOAD']=='0','recorded CPU autoload guard differs')
        require(datetime.fromisoformat(state['started_utc'])<=datetime.fromisoformat(generic['start'])<=datetime.fromisoformat(generic['end'])<=
            datetime.fromisoformat(state['finished_utc']),'original same-host controller/generic time containment differs')
    else:raise ValueError('original generic numerical receipt required')
    spec=audit.json(spec_ref['path'],spec_ref['sha256']);report=audit.json(report_ref['path'],report_ref['sha256'])
    require(spec.get('task')==report.get('task')==TASK and spec.get('stage_spec_sha256')==report.get('stage_spec_sha256')==STAGE_SHA and
        spec.get('expected_inventory_sha256')==EXPECTED_SHA and spec.get('cpu_prerequisite_sha256')==report.get('cpu_prerequisite_sha256')==CPU_SHA and
        spec.get('i03_prerequisite_sha256')==I03_SHA and report.get('comparison_spec_sha256')==spec_ref['sha256'] and
        report.get('status')=='i04_raw_bf16_batch_padding_and_request_pairs_checked' and report.get('native_executions_started_by_admission')==0 and
        all(doc.get('acceptance',False) is None and doc.get('thresholds',False) is None for doc in (spec,report)) and report.get('full_core_complete') is False and
        report['scope']['target_distribution_pairs']==18 and report['scope']['original_large_sources_final_bytehash_checked']==572 and
        report['source_map_sha256']=={k:v['source_map']['sha256'] for k,v in spec['endpoints'].items()},'original I04 result/spec/scope/source-map chain differs')
    require(report['offline_tool_source_sha256']['admit_i04_batch_padding_v1.py']==MAIN_SHA and
        report['offline_tool_source_sha256']['i04_artifact_admission_v1.py']==HELPER_SHA,'executed analysis source identities differ')
    return state,spec,report


def source_chain(audit,controller_path,controller_sha):
    state,spec,report=controller_chain(audit,controller_path,controller_sha);run=Path(controller_path).parent
    require(set(spec['endpoints'])=={'GPU','NPU'},'both exact original backends required')
    runs={};large=[]
    for backend,info in spec['endpoints'].items():
        endpoint=Endpoint(audit,info,backend);outer=endpoint.json(info['receipt']['source_path'],info['receipt']['sha256']);completed(outer)
        require(outer['task']=='I04' and outer['backend']==backend and outer['collector_sha256']==COLLECTORS[backend] and
            outer['input_sha256']==INPUTS['A'] and outer['input_b_sha256']==INPUTS['B'] and outer['stage_spec_source_sha256']==STAGE_SHA and
            outer['expected_inventory_source_sha256']==EXPECTED_SHA and outer['cpu_prerequisite_source_sha256']==CPU_SHA and
            outer['i03_prerequisite_source_sha256']==I03_SHA and outer['native_capture_count']==1 and outer['native_forward_calls_total']==4 and
            outer['model_loads']==1 and outer['timed_out'] is False,'native four-call one-loaded-model source identity differs')
        generic=endpoint.json(outer['generic_receipt']['path'],outer['generic_receipt']['sha256']);completed(generic)
        require(generic['argv']==outer['argv'] and generic['child_returncode']==0 and generic['timeout']==(900 if backend=='GPU' else 1200),
            'native original generic collector receipt differs')
        native_ctl=endpoint.json(child(str(PurePosixPath(info['receipt']['source_path']).parent),'controller-receipt.json'));completed(native_ctl)
        require(native_ctl['remaining_descendants']==[],'native owned descendants remain')
        inputs={k:endpoint.json(outer['input_path' if k=='A' else 'input_b_path'],digest) for k,digest in INPUTS.items()}
        sequences={k:v['prompt']+v['continuation'] for k,v in inputs.items()}
        require(all(len(inputs[k]['prompt'])==PROMPTS[k] and len(inputs[k]['continuation'])==32 and
            all(type(x) is int and 0<=x<VOCAB for x in sequences[k]) for k in INPUTS) and sequences['B']==sequences['A'][:96] and
            inputs['B']['independent_representative_example'] is False and inputs['B']['parent_input_sha256']==INPUTS['A'],
            'exact parent/derived-prefix token identity differs')
        output=outer['output_dir'];manifest=endpoint.json(child(output,'artifacts-manifest.json'),outer['artifacts_manifest_sha256'])
        status=endpoint.json(child(output,'status.json'));require(status['status']=='completed' and status['artifacts_manifest_sha256']==outer['artifacts_manifest_sha256'],
            'native completed manifest binding differs')
        expected_large={'modes/'+m+'/raw-native-logits.safetensors' for m in MODES}
        expected_large|={'modes/'+m+'/request-'+r+'/dist-p%03d.npy'%p for m,r in plans() for p in positions(r)}
        actual_large={name for name in manifest['files'] if name.endswith(('.npy','.safetensors'))}
        require(actual_large==expected_large and len(actual_large)==286 and len(manifest['files'])==(621 if backend=='GPU' else 622),
            'exact four raw+282 full rows/recursive product inventory differs')
        require({key[len(output)+1:] for key in endpoint.files if key.startswith(output+'/')}==set(manifest['files'])|{'artifacts-manifest.json','status.json'},
            'unmapped or extra native output differs')
        for name,ref in manifest['files'].items():
            p=PurePosixPath(name);require(not p.is_absolute() and str(p)==name and '..' not in p.parts and '\\' not in name,'unsafe recursive native member')
            original_path=child(output,name);actual,mapped=endpoint.locate(original_path,ref['sha256'])
            require(mapped['size']==ref['size_bytes'],'manifest/mapped product size differs')
            if name in actual_large:large.append((endpoint,original_path,ref['sha256']))
        for name,ref in endpoint.files.items():
            if not name.endswith(('.npy','.safetensors')):endpoint.get(name,ref['sha256'])
        for name,digest in outer['source_sha256'].items():endpoint.get(name,digest)
        for (mode,request),geometry in plans().items():
            prefix=child(output,'modes/'+mode+'/request-'+request);raw=child(output,'modes/'+mode+'/raw-native-logits.safetensors')
            sequence=sequences[request];coords=[{'sample':inputs[request]['sample'],'position':p,'token':sequence[p]} for p in range(1,LENGTHS[request])]
            runs[f'{backend.lower()}-{mode}-{request.lower()}']={'endpoint':endpoint,'output':prefix,'mode':mode,'request':request,
                'geometry':geometry,'coordinates':coords,'sequence':sequence,'raw_logits':raw,'score_source':child(prefix,'target-scores.json')}
    require(len(large)==572 and len({str(e.locate(n)[0].resolve()) for e,n,_ in large})==572,'572 distinct original large files required')
    frozen=0
    for pair in report['target_distribution_pairs']:
        directory=Path(pair['targets']['sources']['contract']).parent
        require(directory.resolve().is_relative_to((run/'bundle').resolve()) and len(pair['frozen_document_sha256'])==8,'frozen eight-document comparison directory differs')
        for name,digest in pair['frozen_document_sha256'].items():
            require(PurePosixPath(name).name==name,'unsafe frozen comparison name');audit.file(directory/name,digest);frozen+=1
    require(frozen==144,'exact144 frozen comparison documents required')
    return state,spec,report,runs,large


def load_targets(runs):
    for run in runs.values():
        endpoint=run['endpoint'];scores=endpoint.json(run['score_source']);g=run['geometry'];count=LENGTHS[run['request']]-1
        require(len(scores['scores'])==count and scores['raw_logits_sha256']==endpoint.files[run['raw_logits']]['sha256'] and
            scores['slot']==g['slot'] and scores['physical_offset']==g['physical_offset'],'complete target/native source/physical geometry differs')
        for row,coordinate in zip(scores['scores'],run['coordinates']):
            p=coordinate['position'];require(all(row.get(k)==v for k,v in coordinate.items()) and row.get('prediction_position')==p-1 and
                row.get('physical_prediction_position')==g['physical_offset']+p-1 and row.get('physical_target_position')==g['physical_offset']+p and
                row.get('request')==run['request'] and row.get('slot')==g['slot'],'logical/physical causal target coordinate differs')
        run['scores']=[row['logprob'] for row in scores['scores']]


def selected_values(run,p):
    require(p in positions(run['request']) and p<LENGTHS[run['request']]-1,'selected row is padding or unscored final predictor')
    endpoint=run['endpoint'];g=run['geometry'];stem='dist-p%03d'%p
    record=endpoint.json(child(run['output'],stem+'.json'))
    wanted={'sample':run['coordinates'][0]['sample'],'position':p,'history':run['sequence'][:p+1],
        'request':run['request'],'slot':g['slot'],'physical_offset':g['physical_offset'],
        'physical_prediction_position':g['physical_offset']+p,'target_position':p+1,'token':run['sequence'][p+1],
        'raw_logits_sha256':endpoint.files[run['raw_logits']]['sha256'],'scores':{'path':stem+'.npy','row':0},'logprob':run['scores'][p]}
    require(all(k in record and record[k]==v for k,v in wanted.items()),'selected raw row logical/physical/source binding differs')
    lp=base.read_npy(endpoint.get(child(run['output'],stem+'.npy')),VOCAB)
    raw=endpoint.get(run['raw_logits']);_,header=base.native_header(raw)
    require(set(header)=={'logits'} and header['logits']['shape']==g['shape'],'exact original physical raw shape differs')
    start=(g['slot']*g['width']+g['physical_offset']+p)*VOCAB
    native=base.native_values(raw,'logits',start,VOCAB,g['shape']);derived=base.independent_logprobs(native)
    delta=max(abs(a-b) for a,b in zip(lp,derived));require(delta<=1e-12,'selected raw BF16/FP64 row derivation differs')
    require(lp[run['sequence'][p+1]]==run['scores'][p],'selected target/FP64 lookup differs')
    return lp,delta


def replay(audit,report,runs,selection):
    load_targets(runs);targets=[]
    for i,pair in enumerate(report['target_distribution_pairs']):
        audit.tick();a,b=[runs[side] for side in pair['sides']];require(a['coordinates']==b['coordinates'],'paired logical target coordinates differ')
        actual=target_metrics(a['scores'],b['scores'],a['coordinates']);shared=pair['targets'];count=LENGTHS[pair['request']]-1
        require(shared['status']=='no_thresholds' and shared['coverage']=={'expected':count,'paired':count},'complete request-specific target coverage differs')
        for key,value in actual.items():
            if key=='max_coordinate':require(value==shared['metrics'][key],'target first maximum coordinate differs')
            else:equal(value,shared['metrics'][key],'target.'+key)
        targets.append({'pair_index':i,'sides':pair['sides'],'request':pair['request'],'metrics':actual})
    distributions=[]
    for chosen in selection['distribution_rows']:
        audit.tick();pair=report['target_distribution_pairs'][chosen['pair_index']];p=chosen['position'];values=[];deltas=[]
        for side in chosen['sides']:
            lp,delta=selected_values(runs[side],p);values.append(lp);deltas.append(delta)
        actual=distribution_metrics(*values);shared=[r for r in pair['distributions']['positions'] if r['position']==p]
        require(len(shared)==1 and shared[0]['sample']==runs[chosen['sides'][0]]['coordinates'][0]['sample'],'selected original sample/position differs');shared=shared[0]
        for key in FIELDS:equal(actual[key],shared[key],'selected distribution.'+key)
        for key in ('union_count','max_error_token','top1_agreement'):
            require(type(actual[key]) is type(shared[key]) and actual[key]==shared[key],'selected top100 tie/ranking differs')
        equal(actual['top100_overlap'],shared['top100_overlap'],'top100 overlap')
        for group in ('coverage','normalization_mass'):
            for key,value in actual[group].items():equal(value,shared[group][key],group+'.'+key)
        require(('top1_mismatch' in actual)==('top1_mismatch' in shared),'reported top1 mismatch presence differs')
        if 'top1_mismatch' in actual:
            a,b=actual['top1_mismatch'],shared['top1_mismatch']
            for key in ('side_a_token','side_b_token'):require(a[key]==b[key],'top1 mismatch token differs')
            for key in ('side_a_margin','side_b_margin'):equal(a[key],b[key],'top1 mismatch margin')
            require([x['token'] for x in a['probabilities']]==[x['token'] for x in b['probabilities']],'top1 mismatch probability token inventory differs')
            for av,bv in zip(a['probabilities'],b['probabilities']):
                for key in ('side_a','side_b'):equal(av[key],bv[key],'top1 mismatch probability')
        for claim in selection['distribution_extrema_claims']:
            if claim['pair_index']==chosen['pair_index'] and claim['position']==p:
                equal(actual[claim['metric']],claim['claim']['max'],'selected global '+claim['metric'])
                if claim['metric']=='max_probability_error':require(actual['max_error_token']==claim['claim']['max_coordinate']['token'],'global probability-error token differs')
        distributions.append({**chosen,'metrics':actual,'raw_native_to_NPY_max_abs_delta':deltas})
    return targets,distributions


def final_hashes(audit,large):
    require(len(large)==572,'all572 admitted large descriptors required');pool=[]
    for endpoint,name,digest in large:
        path=endpoint.get(name,digest,force=True);pool.append({'original_path':name,'backend':endpoint.backend,
            'sha256':digest,'size':path.stat().st_size,'resolved_path':str(path)})
    require(len({r['resolved_path'] for r in pool})==572,'large byte pool aliases another source')
    return pool


def verify(controller_path,controller_sha,output,timeout=900):
    require(type(timeout) is int and timeout==900,'fixed900-second stdlib selected E02 required');audit=Audit(timeout)
    audit.file(Path(__file__).resolve());audit.file(Path(base.__file__),INDEPENDENT_SHA)
    output=Path(output);require(output.parent.is_dir() and not output.exists() and not output.is_symlink(),'exclusive new E02 output required')
    state,spec,report,runs,large=source_chain(audit,controller_path,controller_sha)
    selection=select(report);selection.update(source_controller={'path':str(controller_path),'sha256':controller_sha},source_report=state['report'])
    output.mkdir(mode=0o700);put(output/'selection.json',selection);selection_sha=hashlib.sha256((output/'selection.json').read_bytes()).hexdigest()
    targets,distributions=replay(audit,report,runs,selection)
    pool=final_hashes(audit,large);audit.recheck_small()
    require(hashlib.sha256((output/'selection.json').read_bytes()).hexdigest()==selection_sha,'durable selected subset changed')
    result={'schema_version':1,'status':'independent_i04_selected_e02_checks_matched','checked_utc':datetime.now(timezone.utc).isoformat(),
        'source_controller':{'path':str(controller_path),'sha256':controller_sha},'source_report':state['report'],'comparison_spec':state['comparison_spec'],
        'selection_sha256':selection_sha,'scope':{'target_pairs':18,'request_target_counts':{'A':159,'B':95},
            'independent_distribution_pair_rows':len(distributions),'matched_cross_backend_distribution_pair_rows':282,
            'all_distribution_pair_rows_in_original_report':846,'admitted_large_sources_final_bytehash_checked':572,'native_KV_checks':0,
            'independent_parent_inputs':1,'derived_prefix_shape_stress_requests':1,'validity_uses_lengths_and_offsets':True,
            'pad_only_rows_numerically_replayed':0,'all_raw_valid_rows_independently_replayed':False},
        'target_pair_checks':targets,'distribution_checks':distributions,'native_KV_checks':[],
        'verification':{'absolute_metric_tolerance':base.ATOL,'relative_metric_tolerance':base.RTOL,
            'raw_logprob_derivation_absolute_tolerance':1e-12,'model_acceptance_thresholds':False,'CPU_seconds':900,
            'full_pool_bytehash_passes':1,'independent_scalar_dependency_sha256':INDEPENDENT_SHA},
        'native_executions_started':0,'thresholds':None,'acceptance':None,'full_core_complete':False,
        'limitations':['Selected E02 subset, not independent scalar replay of all846 distribution contrasts or all1536 valid native predictor rows',
            'Every572 admitted large file is freshly byte-hashed; pad-only values are retained, never normalized or paired here',
            'B is the exact96-token parent prefix, not a second independent representative example; no pooling of159/95 target metrics',
            'Top100-union probability errors and complement-merged JS are not full-vocabulary errors or divergence',
            'Reported global extrema select the subset; selected values are independently checked, not a new independent global search',
            'One process/model per backend and no repeated batch conditions; no repeatability, scheduler, throughput or operator-cause claim']}
    put(output/'e02-report.json',result);put(output/'admitted-large-source-hashes.json',pool)
    put(output/'source-proof.json',{'schema_version':1,'checked_sources':audit.checked,'original_source_files':audit.originals,
        'source_map_sha256':report['source_map_sha256'],'all_admitted_large_final_hashes':572,'hash_calls':audit.hash_calls,'native_executions_started':0})
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--controller',required=True,type=Path)
    parser.add_argument('--controller-sha256',required=True);parser.add_argument('--output-dir',required=True,type=Path)
    parser.add_argument('--timeout-seconds',type=int,default=900);args=parser.parse_args()
    require(hasattr(signal,'SIGALRM'),'POSIX bounded CPU execution required')
    def expire(*_):raise TimeoutError('I04 selected E02 wall900s expired')
    old=signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,args.timeout_seconds)
    try:result=verify(args.controller,args.controller_sha256,args.output_dir,args.timeout_seconds)
    finally:signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,old)
    print(json.dumps({'status':result['status'],'selection_sha256':result['selection_sha256'],'scope':result['scope'],'native_executions_started':0}))


if __name__=='__main__':main()

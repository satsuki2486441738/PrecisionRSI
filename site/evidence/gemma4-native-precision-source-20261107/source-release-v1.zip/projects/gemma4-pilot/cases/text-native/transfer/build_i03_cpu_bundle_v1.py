"""Create the finite source-pinned independent I03 CPU package; no result data."""
import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile

CASE='projects/gemma4-pilot/cases/text-native'
BUILDER=CASE+'/adapters/build_gpu290_npu3_compare_v1.py'
PINS={BUILDER:'43115d8572e30ddedcdb4a85194ca4ddd3046e90e780be6f17f11c0bd8150c24',
 CASE+'/adapters/i01_admission_compare_v1.py':'f7fe91cdcebeec910efed4579ecf379fd665cf305223a3fa77858004db81858a',
 CASE+'/adapters/i01_expected_inventory_v1.py':'834de8fef3d6147b908450116e39a48ea75a026bfc13a290db7db25492fbb40b',
 CASE+'/adapters/i03_artifact_admission_v1.py':'b734babc65be6ec361acbc10905b6c3e02e8c5c57650efb11e3a195134a1b6eb',
 CASE+'/adapters/admit_i03_partition_repeat_v1.py':'2468a5f2a1aafe9f9437edae2bd90b3bdca15f9c1abcc6fa3b927ddb8167691c',
 CASE+'/adapters/i03_expected_inventory_v1.py':'9c0d5cad39ae932d95fee34db3ee91cbb6232ed1ab554e6004fadc189425a7f8',
 CASE+'/adapters/i03_prerequisite_v1.py':'e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36',
 CASE+'/adapters/test_i03_independent_admission_v1.py':'8d32035d07fbdecba54dbcce54169db6bf3a84c0a3be1996946493429ecc163e',
 CASE+'/adapters/test_i03_expected_inventory_v1.py':'d63009cb2b24ae2b6fa598fd0f2eb634d854901f78145c982feea2778ec3fe3c'}
CONTROLLER=CASE+'/transfer/run_i03_actual_compare_v1.py'


def require(ok,message):
 if not ok:raise ValueError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build(root,archive):
 root=Path(root).resolve(strict=True);archive=Path(archive).resolve();require(not archive.exists() and archive.parent.is_dir(),'new output archive required')
 require(sha(root/BUILDER)==PINS[BUILDER],'prior reviewed builder source changed');imports=None
 for node in ast.parse((root/BUILDER).read_text()).body:
  if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='IMPORT_PINS' for t in node.targets):imports=ast.literal_eval(node.value)
 require(isinstance(imports,dict) and len(imports)==10,'fixed10 prior import closure not found')
 pins={**imports,**PINS,CONTROLLER:sha(root/CONTROLLER)};files={}
 for name,digest in sorted(pins.items()):
  path=root/name;require(path.is_file() and not path.is_symlink() and path.stat().st_size<=1024**2 and sha(path)==digest,'fixed source changed: '+name)
  files[name]={'sha256':digest,'size_bytes':path.stat().st_size}
 manifest={'schema_version':1,'kind':'i03-offline-tool-bundle','files':files,'native_executions_started':0,'thresholds':None,'acceptance':None,
  'scope':'independent raw BF16/70call/state/cache admission,23 score pairs,4 native KV pairs; synthetic CPU tests only'}
 raw=(json.dumps(manifest,indent=2,allow_nan=False)+'\n').encode()
 with archive.open('xb') as destination,tarfile.open(fileobj=destination,mode='w') as package:
  for name,ref in files.items():
   data=(root/name).read_bytes();require(hashlib.sha256(data).hexdigest()==ref['sha256'],'source changed during package')
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;package.addfile(info,io.BytesIO(data))
  info=tarfile.TarInfo('tool-bundle-manifest.json');info.size=len(raw);info.mode=0o600;package.addfile(info,io.BytesIO(raw))
 require(archive.stat().st_size<=2*1024**2,'tool archive exceeds2MiB')
 for name,ref in files.items():require(sha(root/name)==ref['sha256'],'source changed after package')
 receipt={'status':'i03_offline_tool_bundle_created','archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),
  'manifest_sha256':hashlib.sha256(raw).hexdigest(),'regular_members':len(files)+1,'source_members':len(files),'controller_sha256':files[CONTROLLER]['sha256'],
  'native_executions_started':0,'acceptance':None}
 with archive.with_name(archive.name+'.receipt.json').open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
 print(json.dumps(receipt,indent=2));return receipt


if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--archive',type=Path,required=True)
 a=p.parse_args();build(a.root,a.archive)

"""CPU-only regressions for new observer source/claim/process boundaries."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tarfile
import tempfile
import time
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[4]


def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


job=load(HERE/'npu_observer_launcher_v1.py','observer_launcher_CPU_test')
ops=load(HERE/'npu_observer_operations_v1.py','observer_operations_CPU_test')


def put(path,doc):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(doc,indent=2)+'\n',encoding='utf8')


class MetadataPackage(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.base=Path(cls.tmp.name).resolve();cls.output=cls.base/'package'
        cls.i04=REPO/job.CASE/'transfer/i04-main-local-20261107T212400Z/observer-proof/prerequisite.json'
        cls.cpu=REPO/job.CASE/'transfer/observer-cpu-proof-local-20261106T213255Z/payload/prerequisite.json'
        cls.result=ops.build(REPO,cls.output,cls.i04,cls.cpu);cls.archive=Path(cls.result['archive'])
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def stage(self,base):
        target=base/self.archive.name;target.write_bytes(self.archive.read_bytes())
        return ops.stage_archive(base,target,job.sha(target),self.result['source_manifest_sha256'])
    def test_actual_pins_framework_free_and_budgets(self):
        job.ready();self.assertEqual(len(job.PINS),29);self.assertEqual(job.TOTAL,job.WORK+job.EXPORT+job.CLEANUP)
        self.assertEqual((job.CAPTURE,job.MAX_CAPTURE,job.MAX_BYTES,job.MIN_FREE),(1500,1024**3,4*1024**3,5*1024**3))
        self.assertFalse(any(x in sys.modules for x in ('torch','numpy','torch_npu','transformers')))
    def test_real_35ref_raw_bytes_and_geometry_are_unchanged(self):
        self.assertEqual(self.result['source_files'],64)
        with tarfile.open(self.archive,'r:gz') as t:
            entries={x.name:t.extractfile(x).read() for x in t.getmembers()}
        prefix=job.NAME+'/source/'
        self.assertEqual(entries[prefix+'prerequisites/i04/prerequisite.json'],self.i04.read_bytes())
        self.assertEqual(entries[prefix+'prerequisites/cpu/prerequisite.json'],self.cpu.read_bytes())
        for alias,source in ops.GEOMETRY_SOURCES.items():self.assertEqual(entries[prefix+alias],(REPO/source).read_bytes())
        self.assertEqual(job.sha(self.i04),job.I04_SHA);self.assertEqual(job.sha(self.cpu),job.CPU_SHA)
    def test_windows_built_real_package_pure_staged_guard(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td).resolve();self.stage(base);task=base/job.NAME;source=task/'source'
            program="""import sys,json;from pathlib import Path
sys.path.insert(0,sys.argv[1]);import npu_observer_operations_v1 as ops
job,args=ops.configuration(Path(sys.argv[2]),sys.argv[3]);result=job.source_check(args,metadata_only=True)
print(json.dumps({'proof_refs':result['proof_refs'],'files':len(result['files']),'native':result['native_executions_started'],'frameworks':[x for x in ('torch','numpy','torch_npu','transformers') if x in sys.modules]}))
"""
            result=subprocess.run([sys.executable,'-S','-B','-c',program,str(source/job.CASE/'transfer'),str(base),self.result['source_manifest_sha256']],capture_output=True,text=True,timeout=40)
            self.assertEqual(result.returncode,0,result.stderr);doc=json.loads(result.stdout)
            self.assertEqual((doc['proof_refs'],doc['native'],doc['frameworks']),(35,0,[]))
    def test_existing_native_namespace_refuses_without_overwrite(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td).resolve();self.stage(base);before=(base/job.NAME/'source-manifest.json').read_bytes()
            with self.assertRaises(ValueError):self.stage(base)
            self.assertEqual((base/job.NAME/'source-manifest.json').read_bytes(),before)
    def test_changed_original_proof_refuses_before_output(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'fake.json';p.write_bytes(self.i04.read_bytes()+b' ');out=Path(td)/'output'
            with self.assertRaises(ValueError):ops.build(REPO,out,p,self.cpu)
            self.assertFalse(out.exists())
    def test_missing_pin_refuses_before_proof_or_device(self):
        with patch.dict(job.PINS,{job.COMMON:None}):
            with self.assertRaisesRegex(ValueError,'unready'):job.source_check(argparse.Namespace())
    def test_extra_source_refuses_fresh_staged_metadata(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td).resolve();self.stage(base);task=base/job.NAME;source=task/'source';(source/'extra.json').write_text('{}')
            staged=load(source/job.LAUNCHER,'observer_forged_tree');staged_ops=load(source/job.OPERATIONS,'observer_forged_tree_ops')
            _,args=staged_ops.configuration(base,self.result['source_manifest_sha256'])
            with self.assertRaisesRegex(ValueError,'inventory'):staged.source_check(args,metadata_only=True)
    def test_archive_links_traversal_and_collisions_rejected_before_task(self):
        cases=[('../evil',tarfile.REGTYPE),('/absolute',tarfile.REGTYPE),(job.NAME+'/source/link',tarfile.SYMTYPE)]
        for name,kind in cases:
            with self.subTest(name=name),tempfile.TemporaryDirectory() as td:
                base=Path(td).resolve();p=base/'bad.tar'
                with tarfile.open(p,'w') as t:
                    info=tarfile.TarInfo(name);info.type=kind;info.size=0;info.linkname='outside' if kind==tarfile.SYMTYPE else '';t.addfile(info,io.BytesIO())
                with self.assertRaises(ValueError):ops.stage_archive(base,p,job.sha(p),'0'*64)
                self.assertFalse((base/job.NAME).exists())
    def test_typed_code_1m_vs_metadata_16m(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td).resolve();prefix=job.NAME+'/';name='oversize.py';raw=b'#'+b'x'*(1024**2)
            manifest={'schema_version':1,'task_id':job.TASK_ID,'files':{name:{'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw),'kind':'code'}}}
            mr=(json.dumps(manifest)+'\n').encode();p=base/'bad.tar'
            with tarfile.open(p,'w') as t:
                for key,value in [(prefix+'source-manifest.json',mr),(prefix+'source/'+name,raw)]:
                    info=tarfile.TarInfo(key);info.size=len(value);t.addfile(info,io.BytesIO(value))
            with self.assertRaisesRegex(ValueError,'typed'):ops.stage_archive(base,p,job.sha(p),hashlib.sha256(mr).hexdigest())
            self.assertFalse((base/job.NAME).exists())
    def test_query_reads_only_bounded_log_tail_and_original_start(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td).resolve();task=base/job.NAME;run=task/'runs/exact';run.mkdir(parents=True)
            put(task/'launch-once.json',{'run':str(run)});put(run/'start-receipt.json',{'pid':2147483647,'starttime':0})
            log=run/'stderr.bin';log.write_bytes(b'x'*8192+b'final');read_bytes=Path.read_bytes
            def guarded(path):
                if path==log:raise AssertionError('query must not read entire log')
                return read_bytes(path)
            with patch.object(Path,'read_bytes',guarded):result=ops.query(base)
            self.assertEqual(result['stderr.bin']['size_bytes'],8197);self.assertEqual(len(result['stderr.bin']['tail']),4096)
            self.assertTrue(result['stderr.bin']['tail'].endswith('final'));self.assertFalse(result['recorded_pid_matches_starttime'])


class ClaimContext(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name).resolve();root=self.base/job.NAME;source=root/'source';source.mkdir(parents=True)
        for name in (job.LAUNCHER,'allocation.json','mapping.json','native.json','driver.info','manifest.json','original.py'):
            p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(name.encode())
        self.args=argparse.Namespace(task_root=root,source_root=source,model=self.base/'model',source_manifest=source/'manifest.json',source_manifest_sha256=job.sha(source/'manifest.json'),
            allocation=source/'allocation.json',native_mapping=source/'mapping.json',native_source=source/'native.json',driver_source=source/'driver.info',
            i04_prerequisite=source/'i04.json',cpu_prerequisite=source/'cpu.json',i04_prerequisite_sha256=job.I04_SHA,cpu_prerequisite_sha256=job.CPU_SHA,
            expected_inventory_sha256=job.EXPECTED_SHA,npu_smi=Path('/srv/precision-user/.local/bin/npu-smi'),npu_smi_sha256=job.SMI_SHA)
        self.allocation={'allocation_id':'actual-b','physical_device_id':job.UUID};self.frozen={str(source/'original.py'):job.sha(source/'original.py')}
        self.claim=root/'claims'/('npu-observer-'+job.UUID)
    def tearDown(self):self.tmp.cleanup()
    def make(self):
        doc={**job.claim_fields(self.args,self.allocation),'claimed_utc':'2026-11-07T00:00:00+00:00','controller_pid':os.getppid(),'controller_starttime':123}
        claim=job.claim_once(self.args.task_root,doc);self.assertEqual(claim,self.claim)
        put(claim/'controller-start.json',{'status':'running','task':'OBSERVER','task_id':job.TASK_ID,'backend':'NPU','claim':str(claim),'source_sha256':self.frozen})
        source=Path(next(iter(self.frozen)));copy_path=claim/'frozen-source/000/original.py';copy_path.parent.mkdir(parents=True);copy_path.write_bytes(source.read_bytes())
        put(claim/'frozen-source-map.json',{str(source):{'path':str(copy_path),'sha256':job.sha(source),'size_bytes':source.stat().st_size}})
    def check(self):
        with patch.object(job,'process_start',return_value=123):return job.claimed_context(self.args,self.allocation,self.frozen,self.claim)
    def test_concurrent_permanent_claim_only_one(self):
        with ThreadPoolExecutor(max_workers=8) as pool:result=list(pool.map(lambda _:job.claim_once(self.args.task_root,{'task':'fixture'}),range(8)))
        self.assertEqual(sum(x is not None for x in result),1);self.assertIsNone(job.claim_once(self.args.task_root,{}))
    def test_direct_worker_probe_without_claim_reject_before_framework(self):
        with self.assertRaisesRegex(ValueError,'claim'):self.check()
        self.assertFalse(any(x in sys.modules for x in ('torch','numpy','torch_npu','transformers')))
    def test_real_internal_entry_calls_reject_before_native_or_recorder(self):
        self.args.worker=self.claim;self.args.probe_output=self.claim/'native-preflight.json'
        with patch.object(job,'source_check',return_value=(object(),object(),self.allocation,self.frozen)):
            with self.assertRaisesRegex(ValueError,'claim'):job.probe(self.args)
            with self.assertRaisesRegex(ValueError,'claim'):job.worker(self.args)
        self.assertFalse(any(x in sys.modules for x in ('torch','numpy','torch_npu','transformers')))
    def test_complete_spent_claim_checks_all_original_and_copy_refs(self):self.make();self.assertEqual(self.check()['task_id'],job.TASK_ID)
    def test_changed_task_proof_budget_allocation_or_parent_refused(self):
        self.make();path=self.claim/'claim.json';doc=job.read(path)
        for key,value in [('task_id','I04'),('cpu_prerequisite_sha256','0'*64),('capture_seconds',1200),('allocation_id','other'),('controller_pid',os.getppid()+1)]:
            changed={**doc,key:value};put(path,changed)
            with self.assertRaises(ValueError):self.check()
        put(path,doc);self.check()
    def test_frozen_copy_mutation_refused(self):
        self.make();(self.claim/'frozen-source/000/original.py').write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'source'):self.check()
    def test_internal_marker_is_permanent_even_on_failure(self):
        self.make();p=self.claim/'worker-once.json';job.put(p,{'spent':True})
        with self.assertRaises(FileExistsError):job.put(p,{'spent':False})
        self.assertEqual(job.read(p),{'spent':True})
    def test_worker_requires_expected_and_second_idle_gate(self):
        self.make();put(self.claim/'sources-pre-worker.json',self.frozen)
        with patch.object(job,'process_start',return_value=123),self.assertRaises(ValueError):job.claimed_context(self.args,self.allocation,self.frozen,self.claim,True)
        (self.claim/'expected-inventory.json').write_bytes((REPO/job.EXPECTED_JSON).read_bytes())
        with patch.object(job,'process_start',return_value=123),self.assertRaises(ValueError):job.claimed_context(self.args,self.allocation,self.frozen,self.claim,True)
        put(self.claim/'process-2.json',{'status':'explicitly_empty'})
        with patch.object(job,'process_start',return_value=123):job.claimed_context(self.args,self.allocation,self.frozen,self.claim,True)
    def test_real_worker_failed_recorder_import_still_spends_marker(self):
        self.make();self.args.worker=self.claim;put(self.claim/'sources-pre-worker.json',self.frozen)
        (self.claim/'expected-inventory.json').write_bytes((REPO/job.EXPECTED_JSON).read_bytes());put(self.claim/'process-2.json',{'status':'explicitly_empty'})
        with patch.object(job,'source_check',return_value=(object(),object(),self.allocation,self.frozen)),patch.object(job,'process_start',return_value=123),patch.object(job,'load',side_effect=RuntimeError('CPU fixture recorder import fails')):
            with self.assertRaisesRegex(RuntimeError,'fixture'):job.worker(self.args)
            with self.assertRaises(FileExistsError):job.worker(self.args)
        self.assertTrue((self.claim/'worker-once.json').is_file())
    def test_literal_capture_command_159_47_and_both_proofs(self):
        command=job.capture_argv(self.args,self.claim/'expected-inventory.json',self.claim/'artifacts')
        self.assertEqual(command[command.index('--backend')+1],'npu');self.assertEqual(command[command.index('--device')+1],'npu:0')
        self.assertEqual(command[command.index('--stage-spec-sha256')+1],job.STAGE_SHA)
        self.assertEqual(command[command.index('--cpu-prerequisite-sha256')+1],job.CPU_SHA)
        self.assertEqual(command[command.index('--i04-prerequisite-sha256')+1],job.I04_SHA)
        self.assertNotIn('--repeat',command)


@unittest.skipUnless(sys.platform.startswith('linux'),'Linux owned descendants')
class ProcessCleanup(unittest.TestCase):
    def test_timeout_cleans_sets_id_term_resistant_grandchild(self):
        # A fresh helper process owns the fixture; never reap test-runner siblings.
        with tempfile.TemporaryDirectory() as td:
            root=Path(td).resolve();(root/'source').mkdir();(root/'runs').mkdir()
            program="""import importlib.util,sys,os,time,signal,subprocess
from pathlib import Path
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
j=load(sys.argv[1],'j');h=load(sys.argv[2],'h');l=load(sys.argv[3],'l');l.subreaper();root=Path(sys.argv[4])
child='import os,signal,time;os.setsid();signal.signal(signal.SIGTERM,signal.SIG_IGN);print(os.getpid(),flush=True);time.sleep(60)'
leader='import subprocess,sys,time;subprocess.Popen([sys.executable,"-c",'+repr(child)+']);time.sleep(60)'
try:j.bounded(h,[sys.executable,'-c',leader],root/'stdout',root/'stderr',time.monotonic()+.8,root)
except TimeoutError:pass
else:raise RuntimeError('timeout required')
assert not h.descendants();print('owned_cleanup_checked')
"""
            result=subprocess.run([sys.executable,'-S','-B','-c',program,str(HERE/'npu_observer_launcher_v1.py'),str(REPO/job.HELPER),str(REPO/job.LEGACY),str(root)],capture_output=True,text=True,timeout=15)
            self.assertEqual(result.returncode,0,result.stderr);self.assertIn('owned_cleanup_checked',result.stdout)
    def test_leader_exits_with_owned_child_is_failed_and_reaped(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td).resolve();(root/'source').mkdir();(root/'runs').mkdir()
            program="""import importlib.util,sys,time
from pathlib import Path
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
j=load(sys.argv[1],'j');h=load(sys.argv[2],'h');l=load(sys.argv[3],'l');l.subreaper();root=Path(sys.argv[4])
leader='import subprocess,sys;subprocess.Popen([sys.executable,"-c","import time;time.sleep(60)"])'
try:j.bounded(h,[sys.executable,'-c',leader],root/'stdout',root/'stderr',time.monotonic()+3,root)
except ValueError:pass
else:raise RuntimeError('leftover must fail')
assert not h.descendants();print('leftover_reaped')
"""
            result=subprocess.run([sys.executable,'-S','-B','-c',program,str(HERE/'npu_observer_launcher_v1.py'),str(REPO/job.HELPER),str(REPO/job.LEGACY),str(root)],capture_output=True,text=True,timeout=15)
            self.assertEqual(result.returncode,0,result.stderr);self.assertIn('leftover_reaped',result.stdout)


if __name__=='__main__':unittest.main(verbosity=2)

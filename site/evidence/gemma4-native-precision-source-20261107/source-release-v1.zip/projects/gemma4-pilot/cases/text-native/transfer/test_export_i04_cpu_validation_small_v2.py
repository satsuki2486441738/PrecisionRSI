"""Synthetic21-document CPUv3 transfer tests; no model/framework execution.

The frozen checker's fixture is translated to new real temporary POSIX source
paths. Its runtime files and receipts are synthetic protocol data, not native
results. Production CLI offers no source-pin or checker bypass.
"""
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tarfile
import unittest
from unittest.mock import patch

import export_i04_cpu_validation_small_v2 as e

ADAPTERS=Path(__file__).resolve().parent.parent/'adapters'


@unittest.skipUnless(os.name=='posix','actual original-source paths require POSIX')
class Tests(unittest.TestCase):
    def setUp(self):
        sys.path.insert(0,str(ADAPTERS));self.addCleanup(lambda:sys.path.remove(str(ADAPTERS)))
        spec=importlib.util.spec_from_file_location('i04_export_shared_cpu_fixture',ADAPTERS/'test_i04_cpu_prerequisite_v2.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        self.f=module.CPUProof();self.f.setUp();self.addCleanup(self.f.doCleanups)
        self.root=self.f.base/'R';self.target=self.root/'i04-batch-padding-20261107/cpu-stage-v3'
        self.run=self.target/'runs/compare-i04-cpu-tests-20261106T180000Z';oldrun=self.f.run
        def rewrite(v):
            if isinstance(v,dict):
                for key,value in v.items():v[key]=rewrite(value)
            elif isinstance(v,list):
                for i,value in enumerate(v):v[i]=rewrite(value)
            elif isinstance(v,str):return v.replace(oldrun,str(self.run)).replace('/synthetic/R',str(self.root)).replace('/synthetic/runtime',str(self.root/'runtime'))
            return v
        for value in (self.f.refs,self.f.wrapper,self.f.stage,self.f.start,self.f.controller,self.f.probe):rewrite(value)
        self.f.save()
        for name,ref in self.f.refs.items():
            path=Path(ref['source_path']);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(self.f.bytes[name])
        self.controller=self.run/'controller-receipt.json';self.output=self.root/'exports/new-proof';self.output.parent.mkdir()
        self.checker=ADAPTERS/'i04_cpu_prerequisite_v2.py';self.select()
    def select(self):
        state=json.loads(self.controller.read_text());state['controller_path']=str(self.controller)
        (self.target/'cpu-validation-v3.stdout').write_text(json.dumps(state,indent=2)+'\n')
    def export(self):return e.export(self.root,e.sha(self.controller),self.output,self.checker)
    def test_all21_original_bytes_wrapper_archive_and_envelope_match(self):
        original={name:Path(ref['source_path']).read_bytes() for name,ref in self.f.refs.items()};result=self.export()
        self.assertEqual((result['original_raw_documents'],result['regular_archive_members'],result['native_arrays_opened']),(21,22,0))
        wrapper=json.loads(Path(result['prerequisite_path']).read_text());refs={name:wrapper[name] for name in ('controller','startup_receipt','stage_receipt','source_manifest','operations_source','probe_source')}
        for group in ('test_sources','test_logs','runtime_sources'):refs.update({group+'/'+k:v for k,v in wrapper[group].items()})
        for name,ref in refs.items():
            self.assertEqual((self.output/ref['path']).read_bytes(),original[name]);self.assertEqual(Path(ref['source_path']).read_bytes(),original[name])
        with tarfile.open(self.output.with_name(self.output.name+'.tar.gz')) as package:
            self.assertEqual(len(package.getmembers()),22);self.assertTrue(all(x.isfile() for x in package.getmembers()))
        envelope=json.loads(Path(result['json_base64_path']).read_text());raw=base64.b64decode(envelope['archive']['base64'],validate=True)
        self.assertEqual(hashlib.sha256(raw).hexdigest(),result['archive']['sha256']);self.assertEqual(envelope['prerequisite_sha256'],result['prerequisite_sha256'])
        self.assertFalse(any(name in sys.modules for name in ('torch','torch_npu','numpy')))
    def test_external_controller_sha_and_stdout_disagreement_rejected_before_output(self):
        with self.assertRaisesRegex(ValueError,'externally frozen'):e.export(self.root,'0'*64,self.output,self.checker)
        state=json.loads((self.target/'cpu-validation-v3.stdout').read_text());state['CPU_tests_passed']=20
        (self.target/'cpu-validation-v3.stdout').write_text(json.dumps(state))
        with self.assertRaisesRegex(ValueError,'stdout/controller'):self.export()
        self.assertFalse(self.output.exists())
    def test_runtime_source_mutation_rejected_without_success_archive(self):
        path=Path(self.f.refs['runtime_sources/torch']['source_path']);path.write_bytes(path.read_bytes()+b'# modified\n')
        with self.assertRaisesRegex(ValueError,'source SHA differs'):self.export()
        self.assertTrue(self.output.is_dir());self.assertFalse(self.output.with_name(self.output.name+'.tar.gz').exists())
    def test_resigned_unclean_process_group_rejected_by_frozen_checker(self):
        state=json.loads(self.controller.read_text());state['steps'][1]['cleanup']['remaining_owned_process_group']=True
        self.controller.write_text(json.dumps(state,indent=2)+'\n');self.select()
        with self.assertRaisesRegex(ValueError,'group-cleanup'):self.export()
        self.assertFalse(self.output.with_name(self.output.name+'.tar.gz').exists())
    def test_checker_tampering_and_output_reuse_rejected(self):
        fake=self.root/'tools';fake.mkdir();checker=fake/'i04_cpu_prerequisite_v2.py';checker.write_bytes(self.checker.read_bytes()+b'\n')
        (fake/'i04_prerequisite_v1.py').write_bytes(self.checker.with_name('i04_prerequisite_v1.py').read_bytes())
        with self.assertRaisesRegex(ValueError,'checker closure'):e.export(self.root,e.sha(self.controller),self.output,checker)
        self.export()
        with self.assertRaisesRegex(ValueError,'exclusive new'):self.export()
    def test_native_array_is_rejected_before_stat_or_open(self):
        with patch.object(Path,'stat',side_effect=AssertionError('array stat attempted')),patch.object(Path,'open',side_effect=AssertionError('array open attempted')):
            with self.assertRaisesRegex(ValueError,'native arrays'):e.regular('/deliberately-missing-native-array.npy')
    def test_symlink_and_oversized_runtime_metadata_rejected(self):
        path=Path(self.f.refs['runtime_sources/torch']['source_path']);other=path.with_name('copy.py');other.write_bytes(path.read_bytes());path.unlink();path.symlink_to(other)
        with self.assertRaisesRegex(ValueError,'regular CPU proof'):self.export()
        path.unlink()
        with path.open('xb') as stream:stream.seek(e.MAX_FILE);stream.write(b' ')
        with self.assertRaisesRegex(ValueError,'regular CPU proof'):e.regular(path)


if __name__=='__main__':unittest.main()

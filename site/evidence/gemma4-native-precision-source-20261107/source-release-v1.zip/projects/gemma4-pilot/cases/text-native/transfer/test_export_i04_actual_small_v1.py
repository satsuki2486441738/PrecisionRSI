"""Synthetic metadata fixtures;572 native paths are intentionally absent."""
from contextlib import redirect_stdout
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import export_i04_actual_small_v1 as e

HERE=Path(__file__).resolve().parent


def write(p,d):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');return p


class Fixture:
    def __init__(self,root):
        self.root=Path(root);self.run=self.root/'runs/numeric';self.run.mkdir(parents=True);self.tools=self.root/'tools/numeric';self.tools.parent.mkdir()
        spec=importlib.util.spec_from_file_location('i04_fixture_builder',HERE/'i04_compare_operations_v1.py');ops=importlib.util.module_from_spec(spec);spec.loader.exec_module(ops)
        repo=next(p for p in HERE.parents if (p/'skills/precision-compare/scripts/record_run.py').is_file())
        with redirect_stdout(io.StringIO()):r=ops.build(repo,self.root/'tools.tar')
        with patch.object(ops.shutil,'disk_usage',return_value=shutil._ntuple_diskusage(20*1024**3,0,20*1024**3)):
            ops.extract(self.root/'tools.tar',self.tools,4*1024**2)
        assert r['manifest_sha256']==e.TOOL_SHA
        maps={}
        for backend in ('GPU','NPU'):
            folder=self.root/backend;folder.mkdir();files={};output='/synthetic-native-must-not-exist/'+backend+'/artifacts'
            manifest={'files':{n:{'sha256':'a'*64,'size_bytes':100} for n in sorted(e.LARGE)}}
            shared=write(folder/'small.json',{'synthetic_cpu_fixture':True})
            for i in range((621 if backend=='GPU' else 622)-286):
                n='synthetic-small-%03d.json'%i;manifest['files'][n]={'sha256':e.sha(shared),'size_bytes':shared.stat().st_size}
                files[output+'/'+n]={'path':shared.name,'sha256':e.sha(shared),'size':shared.stat().st_size}
            for i,name in enumerate(sorted(e.LARGE)):
                ref={'size':100,'sha256':'a'*64}
                if backend=='GPU':ref['path']='missing-native-payloads/%03d.%s'%(i,'npy' if name.endswith('.npy') else 'safetensors')
                else:ref['retained_at_source']=True
                files[output+'/'+name]=ref
            native_manifest=write(folder/'manifest.json',manifest)
            original_manifest=output+'/artifacts-manifest.json';files[original_manifest]={'path':native_manifest.name,'size':native_manifest.stat().st_size,'sha256':e.sha(native_manifest)}
            status=write(folder/'status.json',{'status':'completed','artifacts_manifest_sha256':e.sha(native_manifest)})
            files[output+'/status.json']={'path':status.name,'size':status.stat().st_size,'sha256':e.sha(status)}
            outer={'task':'I04','backend':backend,'status':'completed','returncode':0,'timed_out':False,'native_capture_count':1,
                'native_forward_calls_total':4,'model_loads':1,'output_dir':output,'artifacts_manifest_sha256':e.sha(native_manifest),'synthetic_cpu_fixture':True}
            outer_file=write(folder/'outer.json',outer);original_outer='/synthetic-native-must-not-exist/'+backend+'/claim/capture-receipt.json'
            files[original_outer]={'path':outer_file.name,'size':outer_file.stat().st_size,'sha256':e.sha(outer_file)}
            # Multiple original identities may point to the same actual bytes.
            files['/synthetic-small-alias/'+backend+'/outer-copy.json']=dict(files[original_outer])
            mapping=write(folder/'source-map.json',{'schema_version':1,'request':{'task':'I04','backend':backend,'outer_receipt':original_outer},
                'files':files,'full_array_hashes_checked':286,'retained_array_count':0 if backend=='GPU' else 286})
            maps[backend]={'source_map':{'path':str(mapping),'sha256':e.sha(mapping)},'receipt':{'source_path':original_outer,'sha256':e.sha(outer_file)}}
        self.spec=write(self.run/'comparison-spec.json',{'schema_version':1,'task':'gemma4-i04-batch-padding-v1','stage_spec_sha256':e.STAGE_SHA,
            'expected_inventory_sha256':'22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76',
            'i03_prerequisite_sha256':'3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c',
            'cpu_prerequisite_sha256':'8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec','endpoints':maps,'thresholds':None,'acceptance':None})
        pairs=[]
        for i in range(18):
            folder=self.run/'bundle'/('scores-%02d'%i);docs={}
            for name in ['targets-contract.json','distributions-contract.json','a-env.json','b-env.json','a-targets.json','b-targets.json','a-distributions.json','b-distributions.json']:
                p=write(folder/name,{'synthetic_cpu_fixture':True,'ordinal':i,'name':name});docs[name]=e.sha(p)
            request='A' if i%2==0 else 'B';count=159 if request=='A' else 95
            pairs.append({'request':request,'kind':'cross_backend_matched' if i<6 else 'within_backend_batch_padding',
                'targets':{'status':'no_thresholds','coverage':{'expected':count,'paired':count},'sources':{'contract':str(folder/'targets-contract.json')}},
                'distributions':{'status':'no_thresholds','position_count':47},'frozen_document_sha256':docs,'thresholds':None,'acceptance':None})
        scope={'independent_parent_inputs':1,'derived_prefix_shape_stress_requests':1,'native_calls_per_backend':4,'logical_observations_per_backend':6,
            'target_scores_rederived':1524,'full_vocabulary_rows_rederived':564,'raw_physical_rows_retained':1792,'valid_raw_rows_finite_checked':1536,
            'pad_only_rows_separately_counted':256,'target_distribution_pairs':18,'matched_cross_backend_pairs':6,'within_backend_pairs':12,
            'original_large_sources_final_bytehash_checked':572,'comparison_documents':144}
        self.report=write(self.run/'bundle/i04-comparison-report.json',{'status':'i04_raw_bf16_batch_padding_and_request_pairs_checked',
            'task':'gemma4-i04-batch-padding-v1','stage_spec_sha256':e.STAGE_SHA,'comparison_spec_sha256':e.sha(self.spec),
            'cpu_prerequisite_sha256':'8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec','scope':scope,
            'source_map_sha256':{k:v['source_map']['sha256'] for k,v in maps.items()},'target_distribution_pairs':pairs,
            'thresholds':None,'acceptance':None,'full_core_complete':False,'synthetic_cpu_fixture':True})
        argv=['/synthetic/python','-B',str(self.tools/e.MAIN),'--spec',str(self.spec),'--spec-sha256',e.sha(self.spec),
            '--output-dir',str(self.run/'bundle'),'--timeout-seconds','900']
        generic=self.run/'cpu-i04-admission-fixture';generic.mkdir();profile=write(self.run/'cpu-profile.json',{'env':{'TORCH_DEVICE_BACKEND_AUTOLOAD':'0'}})
        shutil.copyfile(profile,generic/'execution.json')
        stdout=write(generic/'stdout.bin',{'status':'i04_raw_bf16_batch_padding_and_request_pairs_checked','target_distribution_pairs':18,'native_executions_started':0,'acceptance':None})
        stderr=generic/'stderr.bin';stderr.write_bytes(b'')
        command=write(generic/'command.json',{'status':'completed','returncode':0,'child_returncode':0,'argv':argv,'timeout':920,'cwd':str(self.tools),
            'start':'2026-11-07T00:00:01+00:00','end':'2026-11-07T00:00:02+00:00',
            'execution':{'path':str(profile),'snapshot':str(generic/'execution.json'),'sha256':e.sha(profile)}})
        self.controller=write(self.run/'controller-receipt.json',{'status':'completed','returncode':0,'child_returncode':0,'task':'I04','run':str(self.run),
            'tools_root':str(self.tools),'tool_manifest_sha256':e.TOOL_SHA,'whole_cpu_seconds':960,'child_work_seconds':920,'analysis_seconds':900,
            'cleanup_reserve_seconds':20,'timed_out':False,'native_executions_started':0,'acceptance':None,'scope':scope,
            'started_utc':'2026-11-07T00:00:00+00:00','finished_utc':'2026-11-07T00:00:03+00:00','argv':argv,
            'comparison_spec':{'path':str(self.spec),'sha256':e.sha(self.spec)},'report':{'path':str(self.report),'sha256':e.sha(self.report)},
            'generic_receipt':{'path':str(command),'sha256':e.sha(command)},
            'stdout':{'path':str(stdout),'sha256':e.sha(stdout),'bytes':stdout.stat().st_size},
            'stderr':{'path':str(stderr),'sha256':e.sha(stderr),'bytes':0}})


class Small(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.fx=Fixture(self.temp.name)
    def test_original_controller_tool_profile_and_scope_chain(self):
        self.assertEqual(len(e.verify_controller(self.fx.controller,e.sha(self.fx.controller))[2]['target_distribution_pairs']),18)
        with self.assertRaisesRegex(ValueError,'external actual'):e.verify_controller(self.fx.controller,'0'*64)
    def test_failed_or_changed_direct_source_scope_rejected(self):
        d=e.load(self.fx.controller);d['child_returncode']=7;write(self.fx.controller,d)
        with self.assertRaisesRegex(ValueError,'completed'):e.verify_controller(self.fx.controller,e.sha(self.fx.controller))
    def test_rebound_wrong159_95_coverage_rejected(self):
        d=e.load(self.fx.report);d['target_distribution_pairs'][1]['targets']['coverage']={'expected':159,'paired':159};write(self.fx.report,d)
        c=e.load(self.fx.controller);c['report']['sha256']=e.sha(self.fx.report);write(self.fx.controller,c)
        with self.assertRaisesRegex(ValueError,'159/95'):e.verify_controller(self.fx.controller,e.sha(self.fx.controller))
    @unittest.skipUnless(os.name=='posix','requires original absolute POSIX identities')
    def test_export_572_absent_arrays_never_stat_or_open_and8proofs_rawbytes(self):
        old_stat,old_open=Path.stat,Path.open
        def stat(p,*a,**kw):
            if '/synthetic-native-must-not-exist/' in str(p) or '/missing-native-payloads/' in str(p):raise AssertionError('native array stat attempted')
            return old_stat(p,*a,**kw)
        def opened(p,*a,**kw):
            if '/synthetic-native-must-not-exist/' in str(p) or '/missing-native-payloads/' in str(p):raise AssertionError('native array open attempted')
            return old_open(p,*a,**kw)
        output=Path(self.temp.name)/'small'
        with patch.object(Path,'stat',stat),patch.object(Path,'open',opened):result=e.export(self.fx.controller,e.sha(self.fx.controller),output)
        self.assertEqual((result['omitted_npy_files'],result['omitted_raw_native_files'],result['fresh_array_hashes_by_exporter']),(564,8,0))
        doc=e.load(output/'metadata-source-map.json');self.assertEqual(len(doc['omitted']),572)
        self.assertIn('/synthetic-small-alias/GPU/outer-copy.json',doc['files'])
        proof=e.load(result['prerequisite_path']);refs=[proof[k] for k in ('controller','report','comparison_spec','analysis_source','artifact_helper_source','tool_manifest')]+list(proof['source_maps'].values())
        self.assertEqual(len(refs),8)
        for ref in refs:self.assertEqual((output/'observer-prerequisite'/ref['path']).read_bytes(),Path(ref['source_path']).read_bytes())
    @unittest.skipUnless(os.name=='posix','requires original absolute POSIX identities')
    def test_missing_large_descriptor_or_metadata_tamper_rejected_before_export(self):
        state,spec,_,_=e.verify_controller(self.fx.controller,e.sha(self.fx.controller));ref=spec['endpoints']['GPU']['source_map'];mapping=e.load(ref['path']);key=next(n for n in mapping['files'] if n.endswith('.npy'));mapping['files'].pop(key);write(ref['path'],mapping)
        out=Path(self.temp.name)/'catalog';out.mkdir()
        with self.assertRaisesRegex(ValueError,'byte SHA'):e.Catalog(out).endpoint(spec['endpoints']['GPU'],'GPU')
        spec['endpoints']['GPU']['source_map']['sha256']=e.sha(ref['path'])
        with self.assertRaisesRegex(ValueError,'manifest inventory'):e.Catalog(out).endpoint(spec['endpoints']['GPU'],'GPU')
        # Even an unknown missing native filename is rejected before stat/open.
        with self.assertRaisesRegex(ValueError,'not metadata'):e.metadata('/synthetic-native-must-not-exist/unexpected.safetensors')
    @unittest.skipUnless(os.name=='posix','requires original absolute POSIX identities')
    def test_small_byte_change_unknown_array_and_output_reuse_fail(self):
        state,spec,_,_=e.verify_controller(self.fx.controller,e.sha(self.fx.controller));info=spec['endpoints']['NPU'];path=Path(info['source_map']['path']);mapping=e.load(path)
        mapping['files']['/synthetic-native-must-not-exist/foreign-model.safetensors']={'size':1,'sha256':'a'*64,'retained_at_source':True};write(path,mapping)
        info['source_map']['sha256']=e.sha(path);out=Path(self.temp.name)/'catalog';out.mkdir()
        with self.assertRaisesRegex(ValueError,'unexpected or missing native/model'):e.Catalog(out).endpoint(info,'NPU')
        with self.assertRaisesRegex(ValueError,'exclusive new'):e.export(self.fx.controller,e.sha(self.fx.controller),out)
    def test_strict_json_and_metadata_size(self):
        p=Path(self.temp.name)/'bad.json'
        for raw in ['{"a":1,"a":2}','{"a":NaN}']:
            p.write_text(raw)
            with self.assertRaises(ValueError):e.load(p)
        p.write_bytes(b'x')
        with patch.object(e,'MAX_SMALL',0):
            with self.assertRaisesRegex(ValueError,'16MiB'):e.metadata(p)
    @unittest.skipUnless(os.name=='posix','real POSIX metadata child/immutable generic fixture')
    def test_real_worker_exports_missing572_array_metadata_once_and_keeps_generic(self):
        tools=self.fx.root/'tools/small-export';tools.mkdir();repo=next(p for p in HERE.parents if (p/'skills/precision-compare/scripts/record_run.py').is_file())
        sources={'export_i04_actual_small_v1.py':HERE/'export_i04_actual_small_v1.py','i04_actual_small_operations_v1.py':HERE/'i04_actual_small_operations_v1.py',
            'record_run.py':repo/'skills/precision-compare/scripts/record_run.py'}
        for name,path in sources.items():shutil.copyfile(path,tools/name)
        manifest=write(tools/'tool-manifest.json',{'kind':'i04-actual-small-export-tools','files':{n:{'sha256':e.sha(tools/n),'size_bytes':(tools/n).stat().st_size} for n in sources}})
        s=importlib.util.spec_from_file_location('actual_small_operations_fixture',tools/'i04_actual_small_operations_v1.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
        (self.fx.root/'i04-batch-padding-20261107').mkdir()
        with redirect_stdout(io.StringIO()):self.assertEqual(m.worker(self.fx.root,tools,e.sha(manifest),self.fx.controller,e.sha(self.fx.controller)),0)
        controller=next((self.fx.root/'i04-batch-padding-20261107/metadata-exports').glob('cpu-i04-numeric-small-*/small-export-controller.json'));d=e.load(controller)
        self.assertEqual((d['status'],d['result']['omitted_npy_files'],d['result']['omitted_raw_native_files']),('completed',564,8))
        original=e.load(d['generic_receipt']['path']);self.assertEqual((original['status'],original['timeout'],original['child_returncode']),('completed',210,0))
        with self.assertRaises(FileExistsError):m.worker(self.fx.root,tools,e.sha(manifest),self.fx.controller,e.sha(self.fx.controller))
    @unittest.skipUnless(os.name=='posix','real POSIX controller failure receipt fixture')
    def test_budget_failure_receipt_stays_in_task_and_leaves_tool_tree_frozen(self):
        tools=self.fx.root/'tools/small-export';tools.mkdir();repo=next(p for p in HERE.parents if (p/'skills/precision-compare/scripts/record_run.py').is_file())
        sources={'export_i04_actual_small_v1.py':HERE/'export_i04_actual_small_v1.py','i04_actual_small_operations_v1.py':HERE/'i04_actual_small_operations_v1.py',
            'record_run.py':repo/'skills/precision-compare/scripts/record_run.py'}
        for n,p in sources.items():shutil.copyfile(p,tools/n)
        manifest=write(tools/'tool-manifest.json',{'kind':'i04-actual-small-export-tools','files':{n:{'sha256':e.sha(tools/n),'size_bytes':(tools/n).stat().st_size} for n in sources}})
        s=importlib.util.spec_from_file_location('small_operations_budget_failure_fixture',tools/'i04_actual_small_operations_v1.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
        task=self.fx.root/'i04-batch-padding-20261107';task.mkdir()
        with patch.object(m,'GENERIC',999),redirect_stdout(io.StringIO()):self.assertEqual(m.worker(self.fx.root,tools,e.sha(manifest),self.fx.controller,e.sha(self.fx.controller)),2)
        failure=next(task.glob('numeric-small-export-failure-*.json'));self.assertEqual(e.load(failure)['status'],'failed')
        self.assertEqual(set(p.name for p in tools.iterdir()),set(sources)|{'tool-manifest.json'})


if __name__=='__main__':unittest.main()

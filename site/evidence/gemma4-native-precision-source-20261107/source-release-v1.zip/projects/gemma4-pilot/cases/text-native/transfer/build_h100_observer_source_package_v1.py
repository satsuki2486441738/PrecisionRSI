"""Offline observer package preparation and exclusive AFS staging; never starts GPUs.

The platform owns starting/stopping a fresh GPU app. No operation here runs a
native probe, restores an environment, installs packages or loads a model.
Actual CPU validation proof pins must be ready before building/staging sources.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import sys
import tarfile
import time

HERE = Path(__file__).resolve().parent
LIFECYCLE = 'h100_observer_lifecycle_v1.py'
OPERATIONS = 'build_h100_observer_source_package_v1.py'
ENTRY = 'launch-h100-observer-transparency-20261107-v1.sh'
NAME = 'observer-transparency-20261107-gpu-v1'
MAX_MEMBER_CODE, MAX_MEMBER_METADATA = 1024 ** 2, 16 * 1024 ** 2
MAX_PACKAGE_BYTES, MAX_FILES = 64 * 1024 ** 2, 128
DEADLINE_SECONDS = 120


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    def pairs(values):
        result = {}
        for key, value in values:
            require(key not in result, 'duplicate JSON key')
            result[key] = value
        return result
    def reject(value):
        raise ValueError('nonfinite JSON constant: ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs, parse_constant=reject)


def raw_put(path, raw):
    path = Path(path)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())


def put(path, doc):
    raw_put(path, (json.dumps(doc, indent=2, allow_nan=False) + '\n').encode())


def module(path, digest=None):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= MAX_MEMBER_CODE,
            'bounded regular Python lifecycle source required')
    if digest is not None:
        require(sha(path) == digest, 'frozen lifecycle bytes differ')
    spec = importlib.util.spec_from_file_location('observer_ops_lifecycle_' + sha(path), path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    require(Path(result.__file__).resolve() == path.resolve(), 'imported lifecycle path differs')
    return result


def ready(job):
    job.ready()
    require(job.MAX_SECONDS == 3600 and job.CAPTURE_SECONDS == 1200 and job.WORK_SECONDS == 2620 and
            job.METADATA_EXPORT_SECONDS == 960 and job.CLEANUP_SECONDS == 20,
            'observer finite lifetime partition differs')

def safe(relative):
    require(isinstance(relative, str) and relative and '\\' not in relative, 'unsafe package path')
    p = PurePosixPath(relative)
    require(not p.is_absolute() and str(p) == relative and
            all(part not in ('', '.', '..') for part in relative.split('/')), 'unsafe package path')
    return p


def contained(path, root):
    path, root = Path(path), Path(root)
    require(root.is_absolute() and path.is_absolute() and not root.is_symlink() and
            path.resolve().is_relative_to(root.resolve()), 'path escapes new task/base')
    cursor = path
    while cursor != root:
        require(not cursor.is_symlink(), 'target/source ancestor is symlink')
        cursor = cursor.parent
    return path


def shell_bytes(job, lifecycle_sha):
    require(isinstance(lifecycle_sha, str) and job.HEX.fullmatch(lifecycle_sha), 'actual lifecycle SHA required')
    # No resource allocation or repeated execution here. The lifecycle consumes
    # a permanent app claim, so a platform restart cannot repeat model work.
    code = ('import hashlib,os,pathlib,sys;'
            'p=pathlib.Path(sys.argv[1]);'
            'assert p.is_absolute() and p.is_file() and not p.is_symlink();'
            'assert hashlib.sha256(p.read_bytes()).hexdigest()==sys.argv[2];'
            'os.execv(sys.executable,[sys.executable,"-B",str(p)])')
    posix_root = PurePosixPath(job.ROOT.as_posix())
    require(posix_root.is_absolute() and str(posix_root).startswith('/data/afs-2026/') and
            '..' not in posix_root.parts and '\\' not in str(posix_root), 'canonical absolute Linux startup root required')
    require("'" not in code and "'" not in str(posix_root), 'shell literal quoting unsupported')
    return ('#!/bin/bash\nset -eu\nunset PYTHONHOME PYTHONPATH\n'
            'export PYTHONHASHSEED=0 PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 TORCH_DEVICE_BACKEND_AUTOLOAD=0\n'
            "exec python3 -I -B -c '" + code + "' '" + str(posix_root / LIFECYCLE) + "' '" + lifecycle_sha + "'\n").encode()


def collect_dual_proofs(i04, i04_sha, cpu, cpu_sha, helper, helper_sha, job):
    i04, cpu = Path(i04).resolve(strict=True), Path(cpu).resolve(strict=True)
    require(sha(i04) == i04_sha == job.I04_PROOF_SHA and sha(cpu) == cpu_sha == job.CPU_PROOF_SHA,
            'actual distinct dual portable proof bytes differ')
    validator = job.load_pinned(helper, helper_sha, 'observer_operations_dual_prerequisite')
    verified = validator.prerequisite(i04, i04_sha, cpu, cpu_sha)
    require(len(verified['refs']) == 35 and verified['native_executions_started'] == 0,
            'complete actual35-ref preclaim proof required')
    result = {}
    for wrapper, prefix, count in ((i04, 'prerequisite-i04', 9), (cpu, 'prerequisite-cpu', 25)):
        result[prefix + '/prerequisite.json'] = wrapper.read_bytes()
        def walk(value):
            if isinstance(value, dict):
                if set(value) in ({'path', 'source_path', 'sha256'}, {'path', 'source_path', 'sha256', 'size_bytes'}):
                    relative = str(safe(value['path'])); source = contained(wrapper.parent / relative, wrapper.parent)
                    require(source.is_file() and not source.is_symlink() and source.stat().st_size <= MAX_MEMBER_METADATA and
                            sha(source) == value['sha256'], 'raw original portable proof changed')
                    require('size_bytes' not in value or value['size_bytes'] == source.stat().st_size,
                            'CPU portable proof raw source byte count differs')
                    key = prefix + '/' + relative; require(key not in result, 'duplicate original portable proof member')
                    result[key] = source.read_bytes()
                else:
                    for child in value.values(): walk(child)
            elif isinstance(value, list):
                for child in value: walk(child)
        walk(read(wrapper))
        require(sum(key.startswith(prefix + '/') for key in result) == count, 'dual proof8/24 original member count differs')
    # The35th source is the unchanged portable CPU checker, already frozen in
    # source/ by the required code closure, not redundantly rewritten in proofs.
    require(len(result) == 34, '8+24 raw docs and two wrappers required')
    for value in verified['refs'].values():
        p = Path(value['path']); require(p.is_file() and not p.is_symlink() and p.stat().st_size == value['size_bytes'] and
                sha(p) == value['sha256'], 'actual dual proof reference changed during collection')
    return result, verified

def build(repo, output, i04_proof, i04_sha, cpu_proof, cpu_sha, expected_inventory, geometry):
    started = time.monotonic(); repo = Path(repo).resolve(strict=True); output = Path(output).absolute()
    job = module(HERE / LIFECYCLE); ready(job)
    require(i04_sha == job.I04_PROOF_SHA and cpu_sha == job.CPU_PROOF_SHA, 'only actual reviewed dual portable proofs accepted')
    require(not output.exists() and not output.is_symlink(), 'new build output already exists')
    files, kinds = {}, {}
    for relative, digest in job.source_pins().items():
        source = contained(repo / str(safe(relative)), repo)
        require(source.is_file() and not source.is_symlink() and source.stat().st_size <= MAX_MEMBER_CODE and sha(source) == digest,
                'reviewed source closure missing or changed: ' + relative)
        key = 'source/' + relative; files[key] = source.read_bytes(); kinds[key] = 'code'
    for name in (LIFECYCLE, OPERATIONS):
        source = HERE / name
        require(source.is_file() and not source.is_symlink() and source.stat().st_size <= MAX_MEMBER_CODE, 'bounded lifecycle/package source required')
        files[name] = source.read_bytes(); kinds[name] = 'code'
    files[ENTRY] = shell_bytes(job, hashlib.sha256(files[LIFECYCLE]).hexdigest()); kinds[ENTRY] = 'code'
    require(set(geometry) == set(job.GEOMETRY), 'all four independent actual geometry sources required')
    for name, digest in job.GEOMETRY.items():
        source = Path(geometry[name]).absolute()
        require(source.is_file() and not source.is_symlink() and source.stat().st_size <= MAX_MEMBER_METADATA and sha(source) == digest,
                'actual original geometry source changed: ' + name)
        files['geometry/' + name] = source.read_bytes(); kinds['geometry/' + name] = 'metadata'
    expected = Path(expected_inventory).absolute()
    require(expected.is_file() and not expected.is_symlink() and sha(expected) == job.EXPECTED_JSON_SHA and
            expected.stat().st_size == job.EXPECTED_JSON_BYTES, 'frozen independent observer inventory bytes differ')
    verifier = job.load_pinned(repo / job.EXPECTED, job.NEW_PINS[job.EXPECTED], 'observer_ops_independent_expected')
    verifier.verify(expected, repo / job.INPUT, repo / job.SPEC, job.SPEC_SHA,
        geometry['gpu-loaded-inventory.json'], geometry['npu-loaded-inventory.json'], geometry['config.json'], geometry['modeling_gemma4_unified.py'])
    files['expected-inventory.json'] = expected.read_bytes(); kinds['expected-inventory.json'] = 'metadata'
    copied, verified = collect_dual_proofs(i04_proof, i04_sha, cpu_proof, cpu_sha,
        repo / job.PREREQUISITE, job.NEW_PINS[job.PREREQUISITE], job)
    require(not set(copied) & set(files), 'duplicate proof/source target'); files.update(copied)
    kinds.update({name: 'metadata' for name in copied})
    require(len(files) <= MAX_FILES and sum(map(len, files.values())) <= MAX_PACKAGE_BYTES, 'source/proof package limit exceeded')
    manifest = {'schema_version': 1, 'task_id': job.TASK_ID,
        'files': {key: {'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw), 'kind': kinds[key]} for key, raw in sorted(files.items())},
        'expected_inventory_sha256': job.EXPECTED_JSON_SHA, 'i04_prerequisite_sha256': i04_sha,
        'cpu_prerequisite_sha256': cpu_sha, 'dual_proof_ref_count': 35, 'native_executions_started': 0}
    manifest_raw = (json.dumps(manifest, indent=2, allow_nan=False) + '\n').encode(); files[job.MANIFEST] = manifest_raw
    require(time.monotonic() - started < DEADLINE_SECONDS, 'CPU build120s exceeded')
    output.mkdir(mode=0o700)
    for relative in (LIFECYCLE, OPERATIONS, ENTRY, job.MANIFEST, 'expected-inventory.json'): raw_put(output / relative, files[relative])
    archive = output / (NAME + '-source-v1.tar.gz')
    with archive.open('xb') as destination, tarfile.open(fileobj=destination, mode='w:gz', format=tarfile.USTAR_FORMAT) as package:
        for relative, raw in sorted(files.items()):
            info = tarfile.TarInfo(NAME + '/' + relative); info.size = len(raw); info.mode = 0o600
            package.addfile(info, io.BytesIO(raw))
    require(archive.stat().st_size <= MAX_PACKAGE_BYTES and time.monotonic() - started < DEADLINE_SECONDS,
            'actual package size/build120s exceeded; failed artifacts preserved')
    for relative, digest in job.source_pins().items(): require(sha(repo / relative) == digest, 'source changed during package build')
    require(sha(expected) == job.EXPECTED_JSON_SHA and not any(name in sys.modules for name in ('torch', 'torch_npu', 'numpy', 'transformers')),
            'source-only preparation changed expected bytes or imported a framework')
    receipt = {'status': 'observer_gpu_source_package_prepared_not_executed', 'task_id': job.TASK_ID,
        'archive': str(archive), 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
        'source_manifest_sha256': hashlib.sha256(manifest_raw).hexdigest(), 'members': len(files),
        'entry_sha256': hashlib.sha256(files[ENTRY]).hexdigest(), 'lifecycle_sha256': hashlib.sha256(files[LIFECYCLE]).hexdigest(),
        'operations_sha256': hashlib.sha256(files[OPERATIONS]).hexdigest(), 'cpu_prerequisite_sha256': cpu_sha,
        'i04_prerequisite_sha256': i04_sha, 'actual_dual_proof_refs_checked': 35, 'native_executions_started': 0,
        'allocation_source_created': False, 'elapsed_seconds': time.monotonic() - started}
    put(output / 'build-receipt.json', receipt); return receipt

def stage(base, archive, archive_sha, manifest_sha):
    started = time.monotonic(); base = Path(base).absolute(); archive = Path(archive).absolute()
    job = module(HERE / LIFECYCLE); ready(job)
    require(base == job.TASK and base.is_dir() and not base.is_symlink(), 'exact original AFS task base required')
    contained(archive, base)
    require(archive.is_file() and not archive.is_symlink() and archive.stat().st_size <= MAX_PACKAGE_BYTES and
            sha(archive) == archive_sha, 'uploaded archive path/size/hash differs')
    root = base / NAME; require(not root.exists() and not root.is_symlink(), 'new observer root already exists; no overwrite/retry')
    data = {}
    with tarfile.open(archive, 'r:*') as package:
        for item in package:
            safe(item.name)
            require(item.name.startswith(NAME + '/') and item.isfile() and not item.issym() and not item.islnk() and
                    item.name not in data and 0 <= item.size <= MAX_MEMBER_METADATA and len(data) < MAX_FILES + 1,
                    'source archive must contain unique bounded regular members')
            raw = package.extractfile(item).read(item.size + 1)
            require(len(raw) == item.size, 'truncated source member'); data[item.name] = raw
            require(sum(map(len, data.values())) <= MAX_PACKAGE_BYTES and time.monotonic() - started < DEADLINE_SECONDS,
                    'expanded source size/stage120s exceeded')
    prefix = NAME + '/'; manifest_raw = data[prefix + job.MANIFEST]
    require(hashlib.sha256(manifest_raw).hexdigest() == manifest_sha, 'externally pinned source manifest differs')
    manifest = json.loads(manifest_raw)
    require(manifest.get('task_id') == job.TASK_ID and manifest.get('cpu_prerequisite_sha256') == job.CPU_PROOF_SHA and
            set(data) == {prefix + x for x in manifest['files']} | {prefix + job.MANIFEST},
            'exact package/source manifest closure differs')
    for relative, ref in manifest['files'].items():
        safe(relative); raw = data[prefix + relative]
        require(set(ref) == {'kind', 'sha256', 'size_bytes'} and ref['kind'] in ('code', 'metadata') and
                len(raw) == ref['size_bytes'] and hashlib.sha256(raw).hexdigest() == ref['sha256'] and
                len(raw) <= (MAX_MEMBER_CODE if ref['kind'] == 'code' else MAX_MEMBER_METADATA),
                'manifest member hash/size/type cap differs')
    names = {name[len(prefix):] for name in data}
    require(all(not any(parent.as_posix() in names for parent in PurePosixPath(name).parents
                        if parent.as_posix() != '.') for name in names),
            'archive file collides with another member ancestor; no partial root created')
    require(data[prefix + OPERATIONS] == Path(__file__).read_bytes() and data[prefix + LIFECYCLE] == (HERE / LIFECYCLE).read_bytes(),
            'executed operations/lifecycle differ from frozen package')
    require(__import__('shutil').disk_usage(base).free >= job.MIN_FREE, 'source free5GiB gate failed')
    root.mkdir(mode=0o700)
    for name, raw in data.items():
        target = contained(base / name, base); target.parent.mkdir(parents=True, exist_ok=True); raw_put(target, raw)
    verified = validate(root, manifest_sha)
    receipt = {'status': 'observer_gpu_source_staged_not_executed', **verified, 'archive': str(archive),
        'archive_sha256': archive_sha, 'elapsed_seconds': time.monotonic() - started,
        'native_executions_started': 0, 'allocation_source_created': False}
    require(receipt['elapsed_seconds'] < DEADLINE_SECONDS, 'stage120s exceeded; partial new root preserved')
    put(root / 'deployment-receipt.json', receipt)
    return receipt


def validate(root, manifest_sha):
    root = Path(root).absolute(); job = module(root / LIFECYCLE); ready(job)
    require(root == job.ROOT, 'exact new observer root required')
    manifest, files = job.manifest_files(root, manifest_sha)
    source = {'source_manifest_sha256': manifest_sha,
        'source_pins': job.source_pins(),
        'entry_sha256': sha(root / ENTRY), 'lifecycle_sha256': sha(root / LIFECYCLE),
        'operations_sha256': sha(root / OPERATIONS), 'expected_inventory_sha256': job.EXPECTED_JSON_SHA,
        'i04_prerequisite_path': str(root / 'prerequisite-i04/prerequisite.json'), 'i04_prerequisite_sha256': job.I04_PROOF_SHA,
        'cpu_prerequisite_path': str(root / 'prerequisite-cpu/prerequisite.json'), 'cpu_prerequisite_sha256': job.CPU_PROOF_SHA}
    job.source_files(source, root); job.dual_prerequisite(source, root)
    job.independent_expected(source, root)
    check_shell_and_operations(root, job)
    require(not any(name in sys.modules for name in ('torch', 'torch_npu', 'numpy')), 'pure verification imported a framework')
    return {'task_id': job.TASK_ID, 'source_manifest_sha256': manifest_sha, 'files_checked': len(files),
        'expected_inventory_sha256': job.EXPECTED_JSON_SHA, 'cpu_prerequisite_sha256': job.CPU_PROOF_SHA,
        'i04_prerequisite_sha256': job.I04_PROOF_SHA, 'native_executions_started': 0}


def check_shell_and_operations(root, job):
    """Same production guard, also replayed on Linux against Windows tar bytes."""
    root=Path(root)
    require((root / ENTRY).read_bytes() == shell_bytes(job, sha(root / LIFECYCLE)) and
            sha(root / OPERATIONS) == sha(__file__), 'frozen generated shell/operations differ')


def publish(root, manifest_sha, app, observed_utc, evidence):
    root = Path(root).absolute(); verified = validate(root, manifest_sha); job = module(root / LIFECYCLE)
    doc = {'schema_version': 1, 'task_id': job.TASK_ID, 'allocation_id': app, 'vendor': 'NVIDIA', 'visible_count': 1,
        'observed_utc': observed_utc, 'evidence_source': evidence, 'source_pins': job.source_pins(),
        'expected_inventory_sha256': job.EXPECTED_JSON_SHA, 'source_manifest_sha256': manifest_sha,
        'i04_prerequisite_path': str(root / 'prerequisite-i04/prerequisite.json'), 'i04_prerequisite_sha256': job.I04_PROOF_SHA,
        'cpu_prerequisite_path': str(root / 'prerequisite-cpu/prerequisite.json'), 'cpu_prerequisite_sha256': job.CPU_PROOF_SHA}
    for label, name in [('entry', ENTRY), ('lifecycle', LIFECYCLE), ('operations', OPERATIONS)]:
        doc[label + '_path'] = str(root / name); doc[label + '_sha256'] = sha(root / name)
    job.validate_source(doc, root)
    source = root / job.SOURCE; temporary = root / '.platform-allocation-source.prepared'
    require(not source.exists() and not source.is_symlink() and not temporary.exists() and not temporary.is_symlink(),
            'allocation source/prepared history exists; never overwrite or retry')
    put(temporary, doc)
    # link is atomic and refuses an existing final source; the completed source
    # appears only after its original bytes have been flushed and verified.
    require(read(temporary) == doc, 'prepared actual allocation source readback differs')
    os.link(temporary, source); require(source.read_bytes() == temporary.read_bytes(), 'atomic actual source readback differs')
    temporary.unlink()
    receipt = {'status': 'actual_allocation_source_published_not_model_result', 'source': str(source),
        'source_sha256': sha(source), 'allocation_id': app, 'preflight': verified, 'native_executions_started': 0}
    put(root / 'allocation-publication-receipt.json', receipt)
    return receipt


def query(root, app):
    root = Path(root).absolute(); job = module(root / LIFECYCLE)
    require(job.APP.fullmatch(app), 'exact app ID required')
    directory = root / 'claims' / app; result = []
    for name in ('claim.json', 'launch-failure.json', 'capture-failure.json', 'controller-receipt.json', 'capture-receipt.json'):
        path = contained(directory / name, root)
        if not path.is_file():
            result.append({'path': str(path), 'present': False}); continue
        require(not path.is_symlink() and path.stat().st_size <= MAX_MEMBER_METADATA, 'small regular receipt required')
        doc = read(path)
        result.append({'path': str(path), 'sha256': sha(path), **{key: doc.get(key) for key in
            ('status', 'returncode', 'timed_out', 'remaining_descendants', 'output_dir', 'native_forward_calls_total', 'model_loads')}})
    return {'task': 'OBSERVER', 'receipts': result, 'native_executions_started': 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['build', 'stage', 'validate', 'publish', 'query'])
    for flag in ('repo', 'output', 'i04-proof', 'cpu-proof', 'base', 'root', 'archive', 'expected-inventory', 'gpu-inventory', 'npu-inventory', 'config', 'modeling-source'):
        parser.add_argument('--' + flag, type=Path)
    for flag in ('i04-proof-sha256', 'cpu-proof-sha256', 'archive-sha256', 'manifest-sha256', 'app', 'observed-utc', 'evidence'):
        parser.add_argument('--' + flag)
    args = parser.parse_args()
    if args.mode == 'build':
        result = build(args.repo, args.output, args.i04_proof, args.i04_proof_sha256, args.cpu_proof, args.cpu_proof_sha256, args.expected_inventory, {'gpu-loaded-inventory.json': args.gpu_inventory, 'npu-loaded-inventory.json': args.npu_inventory, 'config.json': args.config, 'modeling_gemma4_unified.py': args.modeling_source})
    elif args.mode == 'stage': result = stage(args.base, args.archive, args.archive_sha256, args.manifest_sha256)
    elif args.mode == 'validate': result = validate(args.root, args.manifest_sha256)
    elif args.mode == 'publish': result = publish(args.root, args.manifest_sha256, args.app, args.observed_utc, args.evidence)
    else: result = query(args.root, args.app)
    print(json.dumps(result, indent=2, allow_nan=False), flush=True)


if __name__ == '__main__': main()

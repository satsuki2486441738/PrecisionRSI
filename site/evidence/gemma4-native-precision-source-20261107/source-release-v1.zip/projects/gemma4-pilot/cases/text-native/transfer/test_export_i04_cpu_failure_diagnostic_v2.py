"""Synthetic failure transfer and nonexecuting package-discovery regressions.

Fake installed packages raise immediately if executed. No native/framework call
or actual model/test execution occurs; real immutable CPU source bytes are read.
"""
import base64
import hashlib
import json
import os
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

import export_i04_cpu_failure_diagnostic_v2 as e

CASE=Path(__file__).resolve().parent.parent


def put(path,doc):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(doc,indent=2)+'\n')


@unittest.skipUnless(os.name=='posix','actual source paths require POSIX')
class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)/'R'
        self.target=self.root/'i04-batch-padding-20261107/cpu-stage-v2';self.run=self.target/'runs/compare-i04-cpu-tests-20261106T174936Z';self.run.mkdir(parents=True)
        packet=CASE/'runs/compare-i04-cpu-source-package-v2-20261106T173400Z/i04-cpu-stage-v2.tar.gz'
        with tarfile.open(packet) as package:manifest=package.extractfile('source-manifest.json').read()
        self.assertEqual(hashlib.sha256(manifest).hexdigest(),e.MANIFEST_SHA);(self.target/'source-manifest.json').write_bytes(manifest)
        for name in ('adapters/test_i04_expected_inventory_v1.py','adapters/test_i04_capture_v1.py','transfer/i04_cpu_mask_probe_v1.py'):
            path=self.target/'source'/e.CASE/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((CASE/name).read_bytes())
        (self.root/'i04_cpu_stage_operations_v2.py').write_bytes((CASE/'transfer/i04_cpu_stage_operations_v2.py').read_bytes())
        self.steps=[]
        for i,label in enumerate(('expected','capture')):
            refs={}
            for stream in ('stdout','stderr'):
                path=self.run/(label+'.'+stream);path.write_text('Synthetic failure fixture '+label+' '+stream+'\n')
                refs[stream]={'path':str(path),'sha256':e.sha(path),'bytes':path.stat().st_size}
            self.steps.append({'argv':['synthetic-python','-m','unittest',label],'returncode':i,'timed_out':False,'cleanup':{'remaining_owned_process_group':False},**refs})
        self.controller=self.run/'controller-receipt.json';self.state={'task':'I04-CPU-validation','status':'failed','returncode':2,
            'native_executions_started':0,'model_loads':0,'native_claim_created':False,'manifest_sha256':e.MANIFEST_SHA,
            'source':str(self.target/'source'),'steps':self.steps,'error':'fresh-process capture CPU tests must pass with no skips','synthetic_fixture':True}
        for path in (self.target/'cpu-validation-v2-start.json',self.target/'stage-receipt.json',self.run/'start-receipt.json'):put(path,{'synthetic_fixture':True})
        (self.target/'cpu-validation-v2.stderr').write_bytes(b'')
        stage=self.root/'runs/compare-i04-static-stage-synthetic/controller-receipt.json';put(stage,{'synthetic_fixture':True,'status':'completed'})
        put(self.target/'cpu-stage-source-reference.json',{'path':str(stage),'sha256':e.sha(stage)})
        real_stdlib=e.stdlib_paths(Path(sys.base_prefix),list(sys.path));self.base=self.root/'known-base-python3.12.13'
        for changed in (patch.object(e,'BASE_PREFIX',self.base),patch.object(e.sys,'base_prefix',str(self.base)),patch.object(e,'stdlib_paths',lambda base,paths:real_stdlib)):
            changed.start();self.addCleanup(changed.stop)
        site=self.root/'venv/lib/python3.12/site-packages';base_site=self.base/'lib/python3.12/site-packages'
        site.mkdir(parents=True);base_site.mkdir(parents=True)
        cfg=self.root/'venv/pyvenv.cfg';cfg.write_text('home = '+str(self.base/'bin')+'\ninclude-system-site-packages = true\nversion = 3.12.13\n')
        identities={}
        for package,files in e.SOURCE_PLAN.items():
            environment='venv' if package=='transformers' else 'base';package_site=site if environment=='venv' else base_site
            for name in files:
                path=package_site/package/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text("raise AssertionError('package source MUST NOT execute')\n")
            info=package_site/(package+'-0.0.0.dist-info');info.mkdir();(info/'METADATA').write_text('Name: '+package+'\nVersion: 0.0.0\n')
            identities[package]={'environment':environment,'sha256':e.sha(package_site/package/'__init__.py'),'version':'0.0.0'}
        changed=patch.object(e,'PACKAGE_IDENTITIES',identities);changed.start();self.addCleanup(changed.stop)
        self.output=self.root/'exports/diagnostic';self.output.parent.mkdir();self.save()
    def save(self):
        put(self.controller,self.state);put(self.target/'cpu-validation-v2.stdout',{**self.state,'controller_path':str(self.controller)})
    def export(self):return e.export(self.root,e.sha(self.controller),self.output)
    def test_failure_bytes_and_actual_source_snapshots_preserved_without_package_execution(self):
        original=self.controller.read_bytes();result=self.export();self.assertEqual(result['status'],'i04_failed_cpu_diagnostic_metadata_exported_v2')
        self.assertFalse(result['cpu_validation_succeeded']);self.assertFalse(result['cpu_prerequisite_produced']);self.assertEqual(result['native_arrays_opened'],0)
        mapping=json.loads((self.output/'metadata-source-map.json').read_text());self.assertEqual(mapping['cpu_validation_returncode'],2)
        for source,ref in mapping['files'].items():self.assertEqual(Path(source).read_bytes(),(self.output/ref['path']).read_bytes())
        self.assertEqual(self.controller.read_bytes(),original);self.assertFalse((self.output/'prerequisite.json').exists())
        inspection=json.loads((self.output/'installed-source-inspection.json').read_text());self.assertEqual(set(inspection['packages']),set(e.SOURCE_PLAN));self.assertFalse(inspection['dynamic_import_flags_measured'])
        self.assertFalse(e.framework_modules())
        envelope=json.loads(Path(result['json_base64_path']).read_text());self.assertEqual(hashlib.sha256(base64.b64decode(envelope['archive']['base64'],validate=True)).hexdigest(),result['archive']['sha256'])
        with tarfile.open(self.output.with_name(self.output.name+'.tar.gz')) as package:self.assertTrue(all(x.isfile() and not x.name.endswith(('.npy','.safetensors')) for x in package.getmembers()))
    def test_completed_state_cannot_be_promoted_by_failure_diagnostic(self):
        self.state.update(status='completed',returncode=0);self.save()
        with self.assertRaisesRegex(ValueError,'exact original failed'):self.export()
        self.assertFalse(self.output.exists())
    def test_external_pin_and_stdout_disagreement_fail_before_output(self):
        with self.assertRaisesRegex(ValueError,'machine binding'):e.export(self.root,'0'*64,self.output)
        selected=json.loads((self.target/'cpu-validation-v2.stdout').read_text());selected['returncode']=1;put(self.target/'cpu-validation-v2.stdout',selected)
        with self.assertRaisesRegex(ValueError,'machine binding'):self.export()
        self.assertFalse(self.output.exists())
    def test_corrupted_raw_step_log_refuses_a_successful_diagnostic_archive(self):
        Path(self.steps[1]['stderr']['path']).write_text('changed')
        with self.assertRaises(ValueError):self.export()
        self.assertFalse(self.output.with_name(self.output.name+'.tar.gz').exists())
    def test_discovery_never_imports_a_framework_even_when_initializers_raise(self):
        def guarded(name,*a,**k):
            if any(name==p or name.startswith(p+'.') for p in e.SOURCE_PLAN):raise AssertionError('framework import attempted '+name)
            return original_import(name,*a,**k)
        import builtins
        original_import=builtins.__import__
        with patch.object(builtins,'__import__',guarded):result=self.export()
        self.assertEqual(result['framework_modules_imported_by_exporter'],[]);self.assertEqual(result['device_queries_executed'],0)
    def test_native_array_rejected_before_stat_or_open(self):
        with patch.object(Path,'stat',side_effect=AssertionError('native array stat attempted')),patch.object(Path,'open',side_effect=AssertionError('native array open attempted')):
            with self.assertRaisesRegex(ValueError,'excluded before'):e.regular('/deliberately-missing-model.safetensors')
    def test_fallback_package_from_another_environment_is_rejected(self):
        from types import SimpleNamespace
        foreign=self.root/'foreign/__init__.py';foreign.parent.mkdir();foreign.write_text('# unrelated environment\n')
        with patch.object(e.importlib.util,'find_spec',return_value=SimpleNamespace(origin=str(foreign),submodule_search_locations=[str(foreign.parent)])):
            with self.assertRaisesRegex(ValueError,'origin/class/source SHA'):self.export()
    def test_system_site_requires_explicit_original_pyvenv_authorization(self):
        cfg=self.root/'venv/pyvenv.cfg';cfg.write_text(cfg.read_text().replace('= true','= false'))
        with self.assertRaisesRegex(ValueError,'authorize the known system-site'):self.export()
        self.assertFalse(self.output.with_name(self.output.name+'.tar.gz').exists())
    def test_known_base_package_source_hash_cannot_silently_change(self):
        path=self.base/'lib/python3.12/site-packages/torch_npu/__init__.py';path.write_text('# changed installed package\n')
        with self.assertRaisesRegex(ValueError,'origin/class/source SHA'):self.export()
    def test_source_symlink_size_and_output_reuse_fail_closed(self):
        self.export()
        with self.assertRaisesRegex(ValueError,'exclusive new'):self.export()
        path=self.root/'large.json'
        with path.open('xb') as stream:stream.seek(e.MAX_FILE);stream.write(b' ')
        with self.assertRaisesRegex(ValueError,'bounded original'):e.regular(path)
        small=self.root/'small.json';small.write_text('{}');alias=self.root/'alias.json';alias.symlink_to(small)
        with self.assertRaisesRegex(ValueError,'bounded original'):e.regular(alias)


if __name__=='__main__':unittest.main()

"""Build/stage/run a new source-pinned CPU-only I04 validation bundle.

No allocation, device probe, model entry, native claim or model load is called.
Stage verifies eight original I03 proof documents before any framework import.
Run owns only finite CPU test/probe children and preserves their raw logs.
"""
import argparse
import ast
import ctypes
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import subprocess
import sys
import tarfile
import time
import traceback

CASE = 'projects/gemma4-pilot/cases/text-native'
OPS = CASE+'/transfer/i04_cpu_stage_operations_v3.py'
PROBE = CASE+'/transfer/i04_cpu_mask_probe_v2.py'
SELF_TEST = CASE+'/transfer/test_i04_cpu_stage_operations_v3.py'
COMMON = CASE+'/adapters/i04_common_v1.py'
PROOF_HELPER = CASE+'/adapters/i04_prerequisite_v1.py'
EXPECTED = CASE+'/adapters/i04_expected_inventory_v1.py'
STAGE = CASE+'/i04-stage-v1.json'
INPUT_A = CASE+'/inputs/discovery-v1/wikitext2-discovery-001.json'
INPUT_B = CASE+'/inputs/i04-prefix-stress-096-v1.json'
EXPECTED_JSON = CASE+'/transfer/i04-independent-expected-20261107.json'
PROOF = CASE+'/transfer/i04-actual-i03-prerequisite/prerequisite.json'
FIXTURE_MANIFEST = CASE+'/transfer/tools/i03-cpu-compare-v1-20261106T154150Z/tool-bundle-manifest.json'
STAGE_SHA = '26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
PROOF_SHA = '3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c'
EXPECTED_SHA = '22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76'
FIXED = {
    CASE+'/adapters/i01_common_v1.py':'fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c',
    CASE+'/adapters/i03_common_v1.py':'5cf67f53b5392e4425c4534ec6f97961066c190d24dc1280f31e66781a0fe03a',
    CASE+'/adapters/i03_prerequisite_v1.py':'e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36',
    COMMON:'f982ab5aa3c0585df85b8861290b43d1f4e276e3888a6df02c07100bf98dde0a',
    CASE+'/adapters/i04_gpu_v1.py':'7f438e18d507438556566de07f94f1928e01d9aa1a62f0e3a5b53484edce2663',
    CASE+'/adapters/i04_npu_v1.py':'eb313464396db09e029db2f63012cd614311357247b67497c4618e977f7fad4e',
    PROBE:'036788fadb665d766bed7c6ea4832ae0d80732eb588f06df5abee96f955429f1',
    PROOF_HELPER:'8d42c0eb525c92c23c5324dc751149b47f3c20b8e74d65d4ba76de6c1ca068f0',
    CASE+'/adapters/test_i04_capture_v2.py':'5b07f6f30e87b4005876d0fa26dbcb8896136430681b9b3ed77aef0181cf962f',
    EXPECTED:'b8f134724a295072a77e292864ebf12e0e5944f184690ba36f0f9d55937f1752',
    CASE+'/adapters/test_i04_expected_inventory_v1.py':'f567bc9397a801593e49efe081e97510c550e88eb0245aa7a5eadba7e732ce99',
    CASE+'/adapters/admit_i03_partition_repeat_v1.py':'2468a5f2a1aafe9f9437edae2bd90b3bdca15f9c1abcc6fa3b927ddb8167691c',
    CASE+'/adapters/i03_artifact_admission_v1.py':'b734babc65be6ec361acbc10905b6c3e02e8c5c57650efb11e3a195134a1b6eb',
    STAGE:STAGE_SHA,INPUT_A:'643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0',
    INPUT_B:'f4bca8e16d2e7768c6f9dff0677ea329ccf46ed254e211dc2ce2f9852f416792',EXPECTED_JSON:EXPECTED_SHA,
    FIXTURE_MANIFEST:'d4db95a5ae22091417698109d0dd9836ff5665d66667c530aaf85a4f597ccf87'}
SUBDIR = 'i04-batch-padding-20261107/cpu-stage-v3'
MAX_ARCHIVE, MAX_EXPANDED = 16*1024**2,64*1024**2


def require(ok,message):
    if not ok: raise ValueError(message)


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    def pairs(items):
        out = {}
        for key,value in items: require(key not in out,'duplicate JSON key'); out[key] = value
        return out
    def reject(value): raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)


def put(path,doc):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream: json.dump(doc,stream,indent=2,allow_nan=False); stream.write('\n')


def utc(): return datetime.now(timezone.utc).isoformat()


def safe(name):
    p = PurePosixPath(name)
    require(isinstance(name,str) and name and not p.is_absolute() and str(p) == name and '\\' not in name and
        all(x not in ('','.','..') for x in name.split('/')),'unsafe/noncanonical archive path')
    return p


def regular(path):
    path = Path(path); require(path.is_file() and not path.is_symlink(),'original regular source required'); return path


def pure_module(path,name):
    spec = importlib.util.spec_from_file_location(name,path); module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    require(Path(module.__file__).resolve() == Path(path).resolve(),'actual imported pure helper path differs')
    require(not any(n in sys.modules for n in ('torch','torch_npu','numpy')),'CPU staging imported a framework')
    return module


def verify_tree(source,manifest,digest):
    source,manifest = Path(source),Path(manifest)
    require(not source.is_symlink() and source.resolve().is_relative_to(manifest.parent.resolve()),'CPU source root escapes staged packet')
    source = source.resolve(strict=True)
    require(sha(regular(manifest)) == digest,'externally frozen source manifest SHA differs')
    doc = read(manifest)
    require(doc.get('kind') == 'i04-cpu-only-stage-bundle-v3' and doc.get('stage_spec_sha256') == STAGE_SHA and
        doc.get('i03_prerequisite_sha256') == PROOF_SHA and doc.get('expected_inventory_sha256') == EXPECTED_SHA and
        doc.get('native_executions_started') == 0 and doc.get('model_loads') == 0 and doc.get('expected_CPU_tests') == 21,
        'CPU-only I04 manifest scope differs')
    files = doc['files']; actual = set()
    for path in source.rglob('*'):
        require(not path.is_symlink(),'staged source tree contains symlink')
        if path.is_file(): actual.add(path.relative_to(source).as_posix())
    require(actual == set(files),'staged source inventory is not exact')
    for name,ref in files.items():
        safe(name); path = regular(source/name)
        require(path.stat().st_size == ref['size_bytes'] <= 16*1024**2 and sha(path) == ref['sha256'],'staged source size/SHA differs: '+name)
    for name,digest in FIXED.items(): require(files[name]['sha256'] == digest,'fixed capture/spec/input source differs')
    require(files[OPS]['sha256'] == sha(__file__),'standalone CPU operations source differs from bundled copy')
    gate = pure_module(source/PROOF_HELPER,'i04_cpu_pure_actual_prerequisite')
    checked = gate.prerequisite(source/PROOF,PROOF_SHA)
    expected = pure_module(source/EXPECTED,'i04_cpu_independent_expected')
    expected.verify(source/EXPECTED_JSON,source/INPUT_A,source/INPUT_B,source/STAGE)
    return doc,{'prerequisite_sha256':checked['prerequisite_sha256'],'prior_report_sha256':checked['document']['report']['sha256'],
        'original_proof_documents_checked':len(checked['refs']),'expected_inventory_sha256':sha(source/EXPECTED_JSON),'native_executions_started':0}


def build(repo,output):
    repo = Path(repo).resolve(strict=True); output = Path(output)
    require(not output.exists() and output.parent.is_dir(),'exclusive new packet output directory required')
    pinned = dict(FIXED); original = repo/(CASE+'/adapters/i01_common_v1.py')
    require(sha(original) == FIXED[CASE+'/adapters/i01_common_v1.py'],'old verified loader changed')
    for node in ast.parse(original.read_text(encoding='utf-8')).body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id == 'PINNED' for t in node.targets): pinned.update(ast.literal_eval(node.value))
    require(len(pinned) == len(FIXED)+9,'old9 dependency closure absent')
    for name in (OPS,SELF_TEST): pinned[name] = sha(regular(repo/name))
    contents = {}
    for name,digest in pinned.items():
        p = regular(repo/name); raw = p.read_bytes(); require(len(raw) <= 2*1024**2 and hashlib.sha256(raw).hexdigest() == digest,'fixed source bytes differ')
        if name.endswith('.py'): ast.parse(raw)
        contents[name] = raw
    original_proof = repo/(CASE+'/transfer/i03-numeric-small-local-20261106T170703Z/payload/i04-prerequisite/prerequisite.json')
    gate = pure_module(repo/PROOF_HELPER,'i04_packet_pure_actual_proof'); checked = gate.prerequisite(original_proof,PROOF_SHA)
    contents[PROOF] = original_proof.read_bytes()
    for ref in [checked['document'][key] for key in ('controller','report','comparison_spec','analysis_source','artifact_helper_source','tool_manifest')]+list(checked['document']['source_maps'].values()):
        name = str(PurePosixPath(PROOF).parent/safe(ref['path'])); raw = (original_proof.parent/ref['path']).read_bytes()
        require(hashlib.sha256(raw).hexdigest() == ref['sha256'],'actual portable proof changed')
        contents[name] = raw
    expected = pure_module(repo/EXPECTED,'i04_packet_pure_expected'); expected.verify(repo/EXPECTED_JSON,repo/INPUT_A,repo/INPUT_B,repo/STAGE)
    files = {name:{'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)} for name,raw in sorted(contents.items())}
    manifest = {'schema_version':1,'kind':'i04-cpu-only-stage-bundle-v3','files':files,'stage_spec_sha256':STAGE_SHA,
        'i03_prerequisite_sha256':PROOF_SHA,'expected_inventory_sha256':EXPECTED_SHA,'expected_CPU_tests':21,
        'model_loads':0,'native_executions_started':0,'acceptance':None}
    raw_manifest = (json.dumps(manifest,indent=2,allow_nan=False)+'\n').encode()
    output.mkdir(mode=0o700); archive = output/'i04-cpu-stage-v3.tar.gz'
    with archive.open('xb') as stream,tarfile.open(fileobj=stream,mode='w:gz') as package:
        for name,raw in [('source-manifest.json',raw_manifest),*[(str(PurePosixPath('source')/name),raw) for name,raw in sorted(contents.items())]]:
            info = tarfile.TarInfo(name); info.size = len(raw); info.mode = 0o600; package.addfile(info,io.BytesIO(raw))
    require(archive.stat().st_size <= MAX_ARCHIVE and sum(len(x) for x in contents.values())+len(raw_manifest) <= MAX_EXPANDED,'CPU packet size cap exceeded')
    receipt = {'status':'i04_cpu_stage_packet_created','archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),
        'manifest_sha256':hashlib.sha256(raw_manifest).hexdigest(),'source_files':len(files),'regular_members':len(files)+1,
        'ops_sha256':files[OPS]['sha256'],'probe_sha256':files[PROBE]['sha256'],'prerequisite_sha256':PROOF_SHA,'native_executions_started':0}
    put(output/'receipt.json',receipt); return receipt


def extract(archive,target,archive_sha,manifest_sha):
    require(not target.exists() and target.parent.is_dir(),'exclusive new CPU stage directory required')
    archive = regular(archive); require(archive.stat().st_size <= MAX_ARCHIVE and sha(archive) == archive_sha,'CPU stage archive SHA/size differs')
    with tarfile.open(archive,'r:gz') as package:
        members = package.getmembers(); names = [str(safe(m.name)) for m in members]; name_set = set(names)
        require(0 < len(members) <= 128 and len(names) == len(name_set) and all(m.isfile() and not m.issym() and not m.islnk() and m.size >= 0 for m in members),
            'unique regular CPU packet members required')
        require(all(not any(str(parent) in name_set for parent in PurePosixPath(name).parents if str(parent) != '.') for name in names),'archive file/ancestor collision')
        require(sum(m.size for m in members) <= MAX_EXPANDED,'CPU packet expanded size exceeds64MiB')
        manifest_member = next(m for m in members if m.name == 'source-manifest.json')
        raw_manifest = package.extractfile(manifest_member).read(65537); require(len(raw_manifest) <= 65536 and hashlib.sha256(raw_manifest).hexdigest() == manifest_sha,'CPU packet source manifest pin differs')
        doc = json.loads(raw_manifest); require(name_set == {'source-manifest.json'}|{'source/'+name for name in doc['files']},'CPU packet/source manifest member inventory differs')
        target.mkdir(mode=0o700)
        for member in members:
            path = target/member.name; path.parent.mkdir(parents=True,exist_ok=True)
            with package.extractfile(member) as source,path.open('xb') as destination: shutil.copyfileobj(source,destination,1024**2)
            require(path.stat().st_size == member.size,'extracted CPU source size differs')
    return target/'source',target/'source-manifest.json'


def stage(base,archive,archive_sha,manifest_sha):
    base = Path(base); require(base.is_dir() and not base.is_symlink(),'explicit nonsymlink R root required'); base = base.resolve(strict=True)
    target = base/SUBDIR
    archive = Path(archive)
    require(not archive.is_symlink() and archive.resolve(strict=True).is_relative_to(base),'uploaded CPU archive escapes R')
    current = target.parent
    while current != base:
        require(not current.is_symlink(),'CPU stage parent contains symlink'); current = current.parent
    require(target.resolve().is_relative_to(base),'CPU stage escapes explicit R')
    target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    require(shutil.disk_usage(base).free >= 2*MAX_EXPANDED,'CPU stage observed storage below128MiB')
    source,manifest = extract(Path(archive),target,archive_sha,manifest_sha)
    doc,checked = verify_tree(source,manifest,manifest_sha)
    receipt = {'status':'i04_cpu_stage_checked_not_native','finished_utc':utc(),'source':str(source),'manifest_sha256':manifest_sha,
        'files_checked':len(doc['files']),**checked,'model_loads':0,'native_claim_created':False}
    put(target/'stage-receipt.json',receipt); return receipt


def subreaper():
    libc = ctypes.CDLL(None,use_errno=True)
    require(libc.prctl(36,1,0,0,0) == 0,'owned CPU subprocess subreaper unavailable')


def clean_group(process):
    """Reap only this newly created session/group, even after its leader exits."""
    group = process.pid
    def reap():
        # Let Popen reap its own leader and preserve its actual return code.
        # Only adopted same-group descendants are reaped below afterwards.
        if process.poll() is None: return
        while True:
            try: pid,_ = os.waitpid(-group,os.WNOHANG)
            except ChildProcessError: return
            if pid == 0: return
    def alive():
        try: os.killpg(group,0); return True
        except ProcessLookupError: return False
    try: os.killpg(group,signal.SIGTERM)
    except ProcessLookupError: pass
    end = time.monotonic()+.5
    while time.monotonic() < end:
        reap()
        if not alive(): break
        time.sleep(.02)
    # A TERM-resistant descendant can outlive an already-reaped leader. Never
    # stop cleanup just because process.wait/poll completed for that leader.
    if alive():
        try: os.killpg(group,signal.SIGKILL)
        except ProcessLookupError: pass
    end = time.monotonic()+2
    while time.monotonic() < end:
        reap()
        if not alive(): break
        time.sleep(.02)
    process.wait(timeout=2); reap()
    require(not alive(),'owned CPU process group cleanup incomplete')
    return {'owned_process_group':group,'remaining_owned_process_group':False}


def child(argv,cwd,timeout,stdout,stderr):
    env = dict(os.environ)
    for name in ('PYTHONPATH','PYTHONHOME'): env.pop(name,None)
    env.update(TORCH_DEVICE_BACKEND_AUTOLOAD='0',PYTHONHASHSEED='0',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1')
    subreaper()
    process = None; code = None; timed_out = False; cleanup = None
    try:
        with stdout.open('xb') as out,stderr.open('xb') as err:
            process = subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
            try: code = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired: timed_out = True
    finally:
        if process is not None: cleanup = clean_group(process)
    return {'argv':argv,'returncode':code if code is not None else process.returncode,'timed_out':timed_out,
        'stdout':{'path':str(stdout),'sha256':sha(stdout),'bytes':stdout.stat().st_size},
        'stderr':{'path':str(stderr),'sha256':sha(stderr),'bytes':stderr.stat().st_size},'timeout_seconds':timeout,'cleanup':cleanup}


RUNTIME_SOURCE_NAMES = {'torch','numpy','transformers','masking_utils','configuration','import_utils','torch_npu_npu'}
PROBE_PHASES = ['after_torch','after_transformers','after_configuration','after_masking_utils','before_masks','after_masks']


def validate_probe(probe, check_runtime_bytes=True):
    """Observe imports separately from initialization; do not query hardware."""
    require(probe.get('status') == 'i04_cpu_only_actual_mask_factories_checked' and
        type(probe.get('valid_query_key_cells_checked')) is int and probe['valid_query_key_cells_checked'] == 192 and
        probe.get('versions') == {'torch':'2.9.0+cpu','transformers':'5.10.1','numpy':'1.26.4'},
        'actual pinned CPU factory/count/version evidence differs')
    require(all(type(probe.get(name)) is int and probe[name] == 0 for name in
        ('model_loads','native_model_forward_calls','agent_accelerator_initialization_requests','agent_hardware_or_availability_queries')) and
        probe.get('torch_npu_imported') is True and probe.get('npu_initialized') is False and probe.get('cuda_initialized') is False and
        probe.get('device_backend_autoload') == '0' and probe.get('device_initialization_checks') == 'getter_only' and
        probe.get('library_internal_availability_queries') == 'not_counted_and_not_prohibited',
        'CPU import/initialization/query scope differs; import is not initialization')
    phases = probe.get('phase_observations',[])
    require([item.get('phase') for item in phases] == PROBE_PHASES,'six ordered CPU import/mask phases required')
    for index,item in enumerate(phases):
        require(set(item) == {'phase','torch_npu_imported','npu_namespace_registered','npu_initialized','cuda_initialized'} and
            item['cuda_initialized'] is False and
            (item['torch_npu_imported'] is False and item['npu_namespace_registered'] is False and item['npu_initialized'] is None if index < 2 else
             item['torch_npu_imported'] is True and item['npu_namespace_registered'] is True and item['npu_initialized'] is False),
            'actual CPU phase import/registration/initialization observation differs')
    observations = probe.get('observations',[])
    require(len(observations) == 8 and {(item.get('side'),item.get('factory')) for item in observations} ==
        {(side,factory) for side in ('left','right') for factory in ('sliding_attention','full_attention','direct_full','direct_sliding')} and
        all(item.get('shape') == [2,1,4,4] and item.get('dtype') == 'torch.bfloat16' and item.get('device') == 'cpu' for item in observations),
        'actual CPU BF16 mask observation inventory differs')
    sources = probe.get('sources',{})
    require(set(sources) == RUNTIME_SOURCE_NAMES,'seven actual CPU imported/getter source files required')
    for name,ref in sources.items():
        require(isinstance(ref,dict) and set(ref) == {'path','sha256','size_bytes'} and
            isinstance(ref['path'],str) and Path(ref['path']).is_absolute() and Path(ref['path']).suffix in ('.py','.pyi') and
            type(ref['size_bytes']) is int and 0 < ref['size_bytes'] <= 16*1024**2 and
            isinstance(ref['sha256'],str) and re.fullmatch('[a-f0-9]{64}',ref['sha256']), 'bounded original CPU runtime Python source required')
        if check_runtime_bytes:
            source = regular(ref['path'])
            require(source.stat().st_size == ref['size_bytes'] and sha(source) == ref['sha256'], 'CPU runtime source bytes changed after observation')
    require(sources['import_utils']['path'].endswith('/transformers/utils/import_utils.py') and
        sources['torch_npu_npu']['path'].endswith('/torch_npu/npu/__init__.py'),'actual CPU availability/getter source roles differ')
    return probe


def run(base,manifest_sha):
    require(os.name == 'posix','POSIX finite CPU process cleanup required')
    require(not Path(base).is_symlink(),'explicit CPU validation base cannot be a symlink')
    base = Path(base).resolve(strict=True); target = base/SUBDIR; source = target/'source'; manifest = target/'source-manifest.json'
    current = target
    while current != base:
        require(not current.is_symlink(),'CPU validation path contains symlink'); current = current.parent
    require(target.resolve(strict=True).is_relative_to(base),'CPU validation root escapes R')
    doc,checked = verify_tree(source,manifest,manifest_sha)
    parent = target/'runs'; require(not parent.is_symlink(),'CPU run parent contains symlink'); parent.mkdir(mode=0o700,exist_ok=True)
    folder = parent/('compare-i04-cpu-tests-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')); folder.mkdir(mode=0o700)
    state = {'schema_version':1,'status':'running','started_utc':utc(),'task':'I04-CPU-validation','manifest_sha256':manifest_sha,
        'source':str(source),'whole_timeout_seconds':300,'work_timeout_seconds':240,'owned_cleanup_reserve_seconds':20,
        'model_loads':0,'native_executions_started':0,'native_claim_created':False,'before':checked,'steps':[],
        'automatic_retry':False,'module_import_policy':'observed_not_forbidden',
        'agent_hardware_or_availability_queries':0,'library_internal_availability_queries':'not_counted_and_not_prohibited'}
    put(folder/'start-receipt.json',state); started = time.monotonic()
    def expire(*_): raise TimeoutError('I04 CPU-only validation300s timeout')
    def interrupt(signum,frame): raise KeyboardInterrupt('owned CPU validation signal '+str(signum))
    previous = {sig:signal.signal(sig,interrupt) for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
    previous[signal.SIGALRM] = signal.signal(signal.SIGALRM,expire); signal.setitimer(signal.ITIMER_REAL,300)
    try:
        python = str(base/'venv/bin/python'); adapters = source/(CASE+'/adapters')
        groups = [('expected','test_i04_expected_inventory_v1',8,30),('capture','test_i04_capture_v2',13,150)]
        passed = {}
        for label,module,count,timeout in groups:
            step = child([python,'-B','-m','unittest','-v',module],adapters,timeout,folder/(label+'.stdout'),folder/(label+'.stderr'))
            state['steps'].append(step); log = (folder/(label+'.stderr')).read_text(errors='replace')
            require(step['returncode'] == 0 and not step['timed_out'] and 'Ran '+str(count)+' tests' in log and
                'skipped' not in log and log.rstrip().endswith('OK'),'fresh-process '+label+' CPU tests must pass with no skips')
            if label == 'capture': require('test_pinned_factory_masks_valid_queries_for_both_padding_sides' in log,'actual native CPU factory test missing')
            passed[label] = count
        require(time.monotonic()-started < 160,'CPU work budget unavailable for mask probe and owned cleanup')
        probe_step = child([python,'-B',str(source/PROBE)],source,60,folder/'mask-probe.stdout',folder/'mask-probe.stderr')
        state['steps'].append(probe_step); require(probe_step['returncode'] == 0 and not probe_step['timed_out'],'actual CPU mask-source probe failed')
        probe = read(folder/'mask-probe.stdout')
        validate_probe(probe)
        _,after = verify_tree(source,manifest,manifest_sha); require(checked == after,'CPU staged proof/expected source changed')
        require(time.monotonic()-started <= 240,'CPU validation work exceeded240s')
        require(passed == {'expected':8,'capture':13},'both fresh CPU test groups required')
        state.update(status='completed',returncode=0,CPU_tests_passed=21,CPU_test_groups_passed=passed,CPU_tests_skipped=0,actual_mask_probe=probe,after=after)
    except BaseException as exc:
        state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),automatic_retry=False)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        for sig,handler in previous.items(): signal.signal(sig,handler)
        state.update(finished_utc=utc(),elapsed_seconds=time.monotonic()-started); put(folder/'controller-receipt.json',state)
    return {**state,'controller_path':str(folder/'controller-receipt.json')}


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('mode',choices=['build','stage','run'])
    for name in ('repo','output','base','archive'): parser.add_argument('--'+name,type=Path)
    for name in ('archive-sha256','manifest-sha256'): parser.add_argument('--'+name)
    args = parser.parse_args()
    if args.mode == 'build': result = build(args.repo,args.output)
    elif args.mode == 'stage': result = stage(args.base,args.archive,args.archive_sha256,args.manifest_sha256)
    else: result = run(args.base,args.manifest_sha256)
    print(json.dumps(result,indent=2,allow_nan=False),flush=True); return result.get('returncode',0)


if __name__ == '__main__': raise SystemExit(main())

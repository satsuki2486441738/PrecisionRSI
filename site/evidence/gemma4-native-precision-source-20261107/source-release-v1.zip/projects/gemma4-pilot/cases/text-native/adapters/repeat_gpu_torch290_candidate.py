"""Run three bounded H100 candidate captures in the already-selected environment.

No installation, platform allocation or GPU work occurs on import. Each actual
collector call is owned by record_execution_v2.run, including its timeout,
SIGTERM handling, process-group cleanup and real terminal receipt. The launcher
does not synthesize or upgrade any historical execution receipt.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import time

import record_execution_v2 as recorder
from pilot_gpu_torch290_candidate import EXPECTED_STACK, INPUT_SHA256, POLICY_SHA256, check_allocation, check_input

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]


def stamp():
    return datetime.now(timezone.utc).isoformat()


def make_plan(output_root, side, rank, instant=None):
    if side != 'h100-torch290' or rank not in (1, 2, 3):
        raise ValueError('side or repeat rank differs from the frozen three-repeat plan')
    instant = instant or datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    return (Path(output_root) / f'{side}-pilot-r{rank}-{instant}',
            Path(output_root) / f'{side}-recorder-r{rank}-{instant}')


def dependencies(allocation, policy, environment):
    scripts = REPO / 'skills' / 'precision-compare' / 'scripts'
    result = [HERE / name for name in ('pilot_gpu_peer_v2.py', 'verify_snapshot.py', 'upstream-identity.json',
                                      'record_execution_v2.py', 'repeat_gpu_torch290_candidate.py')]
    result += [scripts / name for name in ('inference_capture.py', 'artifact_io.py',
                                         'compare_distributions.py', 'conditions.py')]
    return result + [Path(allocation), Path(policy), Path(environment)]


def run_three(*, model, input_path, allocation, policy, environment, output_root, marker,
              total_timeout=3600, per_run_timeout=900, run_one=recorder.run, clock=time.monotonic):
    if os.name != 'posix':
        raise RuntimeError('POSIX recorder lifecycle required; no collector started')
    if type(total_timeout) is not int or not 1 <= total_timeout <= 3600:
        raise ValueError('total timeout must be 1..3600 seconds')
    if type(per_run_timeout) is not int or not 1 <= per_run_timeout <= 900:
        raise ValueError('per-run timeout must be 1..900 seconds')
    output_root, marker = Path(output_root), Path(marker)
    if not output_root.is_dir() or not marker.parent.is_dir():
        raise ValueError('explicit output root and marker parent must already exist')
    if marker.exists():
        raise FileExistsError('marker exists; automatic repetition is forbidden')
    check_input(input_path)
    check_allocation(json.loads(Path(allocation).read_text()))
    policy_raw = Path(policy).read_bytes()
    if hashlib.sha256(policy_raw).hexdigest() != POLICY_SHA256:
        raise ValueError('frozen CUDA numerical policy differs')
    declaration = json.loads(Path(environment).read_text())
    if declaration.get('expected_stack') != EXPECTED_STACK:
        raise ValueError('environment declaration differs from fixed Torch 2.9 stack')
    deps = dependencies(allocation, policy, environment)
    if any(not p.is_file() for p in deps):
        raise ValueError('collector dependencies are incomplete')
    deadline = clock() + total_timeout
    results = []
    with marker.open('x', encoding='utf-8') as log:
        def event(kind, **kwargs):
            log.write(json.dumps({'utc': stamp(), 'event': kind, **kwargs}, allow_nan=False) + '\n')
            log.flush(); os.fsync(log.fileno())
        event('reserved', repeats=3, total_timeout=total_timeout, per_run_timeout=per_run_timeout,
              input_sha256=INPUT_SHA256, python=sys.executable)
        try:
            for rank in (1, 2, 3):
                remaining = int(deadline - clock())
                if remaining < 1:
                    event('deadline_exceeded', completed_repeats=len(results)); return 1
                output, receipt_dir = make_plan(output_root, 'h100-torch290', rank)
                event('repeat_started', rank=rank, output=str(output), receipt=str(receipt_dir))
                result = run_one(HERE / 'pilot_gpu_torch290_candidate.py', input_path, output,
                    receipt_dir, min(per_run_timeout, remaining),
                    ['--model', str(model), '--allocation-receipt', str(allocation),
                     '--numerics-policy', str(policy), '--device', 'cuda:0'], deps, 'GPU')
                results.append({'rank': rank, 'status': result.get('status'),
                                'returncode': result.get('returncode'), 'receipt': str(receipt_dir / 'receipt.json')})
                event('repeat_exited', **results[-1])
                if result.get('status') != 'completed' or result.get('returncode') != 0:
                    event('failed', completed_repeats=sum(r['status'] == 'completed' for r in results)); return 1
        except BaseException as exc:
            event('interrupted_or_failed', reason=type(exc).__name__ + ': ' + str(exc), results=results)
            raise
        event('completed', results=results, limitation='three serial TP1 captures, no distributed model')
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('model', 'input', 'allocation-receipt', 'numerics-policy', 'environment', 'output-root', 'marker'):
        parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--total-timeout', type=int, default=3600)
    parser.add_argument('--per-run-timeout', type=int, default=900)
    args = parser.parse_args()
    # During recorder.run its own handlers take ownership and kill its child
    # process group. Between calls no child exists; this handler ends the plan.
    def interrupted(signum, _frame):
        raise InterruptedError('received signal ' + str(signum))
    for signum in (signal.SIGTERM, signal.SIGINT):
        signal.signal(signum, interrupted)
    return run_three(model=args.model, input_path=args.input, allocation=args.allocation_receipt,
        policy=args.numerics_policy, environment=args.environment, output_root=args.output_root,
        marker=args.marker, total_timeout=args.total_timeout, per_run_timeout=args.per_run_timeout)


if __name__ == '__main__':
    raise SystemExit(main())

"""Synthetic CPU-only I04 geometry, BF16, padding and shared-math regressions.

Real sequence lengths160/96 and all47 positions are retained. Only vocabulary
size is patched to128 inside tests; production CLI has no such override.
No Torch, collector, model, device or native launcher is imported/executed.
"""
from contextlib import ExitStack
import copy
import hashlib
import json
import math
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import i04_artifact_admission_v1 as n
import admit_i04_batch_padding_v1 as a

HERE=Path(__file__).resolve().parent


def write(path,doc):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(doc,indent=2,allow_nan=False)+'\n',encoding='utf-8');return path


def rng():
    return {'python':{'format':'untruncated Python random.getstate tuple repr UTF8','sha256':'1'*64},
        'numpy':{'format':'canonical-JSON-header UTF8 + NUL + complete uint32LE state words','sha256':'2'*64,
            'header':{'version':1,'algorithm':'MT19937','word_count':624,'word_encoding':'uint32-little-endian','position':624,'has_gauss':0,
                'cached_gaussian_binary64_le_hex':'0000000000000000'}},
        'torch_cpu':{'format':'complete Torch generator state ByteTensor bytes','sha256':'3'*64},
        'device0':{'format':'complete Torch generator state ByteTensor bytes','sha256':'4'*64}}


def safetensors(path,bits):
    header={'logits':{'dtype':'BF16','shape':list(bits.shape),'data_offsets':[0,bits.size*2]}}
    raw=json.dumps(header,separators=(',',':')).encode();raw+=b' '*(-len(raw)%8)
    path.write_bytes(struct.pack('<Q',len(raw))+raw+bits.astype('<u2').tobytes())


class Endpoint:
    """Fixture storage only; real portable-map failures are tested separately."""
    def __init__(self,root):self.root=Path(root);self.files={};self.checked={}
    def add(self,name,value):
        path=self.root/('file-%04d'%len(self.files)+Path(name).suffix)
        if isinstance(value,bytes):path.write_bytes(value)
        else:write(path,value)
        self.files[name]=path;return path
    def get(self,name,digest=None):
        n.require(name in self.files,'missing synthetic original source')
        path=self.files[name];actual=n.sha(path)
        n.require(digest is None or digest==actual,'synthetic original source SHA differs')
        self.checked[name]=actual;return path
    def json(self,name,digest=None):return n.load(self.get(name,digest))


class Fixture:
    def __init__(self,root,mode='batch-right',endpoint=None):
        self.root=Path(root);self.endpoint=endpoint or Endpoint(root);self.output='/synthetic/non-native/artifacts'
        self.mode=mode;self.prefix=self.output+'/modes/'+mode
        sequence=[i%128 for i in range(160)]
        first={'sample':'synthetic-A','prompt':sequence[:128],'continuation':sequence[128:]}
        second={'sample':'synthetic-B','prompt':sequence[:64],'continuation':sequence[64:96],
            'kind':'derived_prefix_shape_stress','independent_representative_example':False,'parent_input_sha256':n.INPUT_SHAS['A'],
            'parent_sample':first['sample'],'parent_token_span':[0,96]}
        self.inventory=n.expected.derive(first,second,n.INPUT_SHAS['A'],n.INPUT_SHAS['B'],n.STAGE_SHA)
        # Keep the independently derived production coordinates/lengths. Only
        # synthetic tensor vocabulary/byte descriptors are reduced afterwards.
        for plan in self.inventory['modes']:
            plan['raw_logits']['shape'][-1]=128
            plan['raw_logits']['data_bytes']=math.prod(plan['raw_logits']['shape'])*2
        self.plan=next(item for item in self.inventory['modes'] if item['id']==mode)
        self.baseline={'synthetic_fixture':True};self.baseline_sha='a'*64;self.policy={'synthetic_fixture':True}
        shape=self.plan['raw_logits']['shape'];self.bits=np.full(shape,0x7fc1,dtype='<u2')
        logprobs={}
        for observation in self.plan['observations']:
            request=observation['request'];length=observation['sequence_length'];offset=observation['physical_offset'];slot=observation['slot']
            values=(((np.arange(length)[:,None]*7+np.arange(128)[None,:]*11+(3 if request=='B' else 0))%47)-23).astype('<f4')/4
            self.bits[slot,offset:offset+length]=(values.view('<u4')>>16).astype('<u2')
            z=values.astype(np.float64);z-=z.max(axis=1)[:,None];logprobs[request]=z-np.log(np.exp(z).sum(axis=1))[:,None]
        self.raw=self.endpoint.add(self.prefix+'/raw-native-logits.safetensors',b'');safetensors(self.raw,self.bits)
        raw_sha=n.sha(self.raw);summaries=[]
        for observation in self.plan['observations']:
            request=observation['request'];r=self.inventory['requests'][request];lp=logprobs[request];sub=self.prefix+'/request-'+request
            base={'schema_version':1,'task':n.TASK,'mode':mode,'request':request,'stage_spec_sha256':n.STAGE_SHA,
                'input_sha256s':n.INPUT_SHAS,'request_input_sha256':n.INPUT_SHAS[request],'raw_logits_sha256':raw_sha,
                'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':n.NORMALIZATION,
                'slot':observation['slot'],'physical_offset':observation['physical_offset']}
            scores=[{**coord,'request':request,'slot':observation['slot'],'logprob':float(lp[p,r['input_ids'][p+1]])}
                for p,coord in enumerate(observation['all_targets'])]
            self.endpoint.add(sub+'/target-scores.json',{**base,'kind':'i04-native-target-scores','scores':scores});items=[]
            for coord in observation['distribution_positions']:
                p=coord['position'];stem='dist-p%03d'%p;roles=(['prompt_sample'] if p in [i*(r['prompt_length']-1)//15 for i in range(16)] else [])
                roles+=['continuation'] if p>=r['prompt_length']-1 else [];descriptor={'path':stem+'.npy','row':0}
                items.append({**coord,'roles':roles,'scores':descriptor,'record':stem+'.json'})
                self.endpoint.add(sub+'/'+stem+'.json',{**base,**coord,'roles':roles,'scores':descriptor,
                    'target_position':p+1,'token':r['input_ids'][p+1],'logprob':scores[p]['logprob']})
                path=self.endpoint.add(sub+'/'+stem+'.npy',b'')
                with path.open('wb') as stream:np.save(stream,lp[p:p+1],allow_pickle=False)
            self.endpoint.add(sub+'/distributions.json',{**base,'kind':'i04-native-distribution-rows','positions':items})
            summaries.append({'request':request,'sample':r['sample'],'slot':observation['slot'],'physical_offset':observation['physical_offset'],
                'sequence_length':r['sequence_length'],'targets':r['sequence_length']-1,'sampled_distributions':47,
                'unscored_logical_predictors':[r['sequence_length']-1]})
        self.product('events.json',[{**self.plan,'mode':mode,'call_index':0,'use_cache':False,'past_key_values_is_none':True,
            'logits_to_keep':0,'labels_supplied':False,'shared_kv_states_supplied':False,'returned_cache':None,'returned_shared_kv_states':None,
            'native_logits_shape':shape,'native_logits_dtype':'torch.bfloat16'}])
        self.product('model-state-after.json',self.baseline)
        self.product('state-control.json',{'mode':mode,'seed_reset':{'seed':0,'settings':self.policy},'rng_before':rng(),'rng_after':rng(),
            'math_policy':self.policy,'baseline_model_state_sha256':self.baseline_sha,'model_state_after_sha256':n.sha(self.path('model-state-after.json'))})
        counts=n.pad_inventory(self.bits,self.plan);valid=sum(x['sequence_length'] for x in self.plan['observations'])
        self.product('raw-row-inventory.json',{'schema_version':1,'task':n.TASK,'mode':mode,'raw_logits_sha256':raw_sha,
            'physical_raw_rows':shape[0]*shape[1],'valid_raw_rows':valid,'valid_nonfinite_coordinates':0,
            'pad_only_rows':self.plan['pad_only_rows'],'pad_only_nonfinite_counts':counts})
        self.product('capture-summary.json',{'schema_version':1,'task':n.TASK,'mode':mode,'native_forward_calls':1,'use_cache':False,
            'raw_logits':n.ref(self.endpoint,self.prefix+'/raw-native-logits.safetensors'),'native_logits_shape':shape,'native_logits_dtype':'torch.bfloat16',
            'observations':summaries,'targets':sum(x['targets'] for x in summaries),'sampled_distributions':47*len(summaries),
            'physical_raw_rows':shape[0]*shape[1],'valid_raw_rows':valid,'pad_only_raw_rows':len(self.plan['pad_only_rows']),
            'pad_only_nonfinite_counts':counts})
    def product(self,name,doc):return self.endpoint.add(self.prefix+'/'+name,doc)
    def path(self,name):return self.endpoint.get(self.prefix+'/'+name)
    def edit(self,name,fn):
        p=self.path(name);doc=n.load(p);fn(doc);write(p,doc)
    def inspect(self):return n.inspect_mode(self.endpoint,self.output,self.plan,self.inventory,self.baseline,self.baseline_sha,self.policy,'npu:0')
    def change_word(self,slot,position,index,word):
        self.bits[slot,position,index]=word;safetensors(self.raw,self.bits);digest=n.sha(self.raw)
        for logical,path in self.endpoint.files.items():
            if not logical.startswith(self.prefix+'/') or path.suffix!='.json':continue
            doc=n.load(path)
            if isinstance(doc,dict):
                if 'raw_logits_sha256' in doc:doc['raw_logits_sha256']=digest
                if 'raw_logits' in doc:doc['raw_logits']['sha256']=digest
                write(path,doc)


class ArtifactTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.stack=ExitStack();self.addCleanup(self.stack.close)
        self.stack.enter_context(patch.object(n,'VOCABULARY',128))
    def fixture(self,mode='batch-right'):
        root=Path(self.tmp.name)/('fixture-%03d'%len(list(Path(self.tmp.name).iterdir())));root.mkdir();return Fixture(root,mode)

    def test_all_four_real_length_plans_rederive_six_observations_and_keep_pad_nan(self):
        totals=[0,0,0,0,0];raws=[]
        for mode in n.MODES:
            f=self.fixture(mode);before=n.sha(f.raw);r=f.inspect();raws.append(r)
            totals[0]+=sum(len(o['scores']) for o in r['observations'].values())
            totals[1]+=sum(len(o['positions']) for o in r['observations'].values())
            inv=r['pad_inventory'];totals[2]+=inv['physical_raw_rows'];totals[3]+=inv['valid_raw_rows'];totals[4]+=inv['pad_only_nonfinite_counts']['rows']
            self.assertEqual(n.sha(f.raw),before)
            self.assertEqual(inv['pad_only_nonfinite_counts']['nonfinite'],inv['pad_only_nonfinite_counts']['coordinates'])
        self.assertEqual(totals,[762,282,896,768,128])

    def test_B_right_final_valid95_is_checked_and_pad159_is_not_scored(self):
        f=self.fixture('batch-right');result=f.inspect();self.assertEqual(result['observations']['B']['summary']['unscored_logical_predictors'],[95])
        self.assertTrue(np.isnan(n.decode_bits(f.bits[1,159])).all())
        f.change_word(1,95,0,0x7fc2)
        with self.assertRaisesRegex(ValueError,'unscored final'):f.inspect()

    def test_B_left_final_valid159_checked_while63_is_padding(self):
        f=self.fixture('batch-left');self.assertTrue(np.isnan(n.decode_bits(f.bits[1,63])).all());f.inspect()
        f.change_word(1,159,0,0x7fc2)
        with self.assertRaisesRegex(ValueError,'unscored final'):f.inspect()

    def test_left_offset_and_right_B159_target_inventions_rejected(self):
        f=self.fixture('batch-left');f.edit('request-B/target-scores.json',lambda d:d['scores'][0].update(physical_prediction_position=0))
        with self.assertRaisesRegex(ValueError,'physical target'):f.inspect()
        f=self.fixture('batch-right');f.edit('request-B/target-scores.json',lambda d:d['scores'].extend(copy.deepcopy(d['scores'][:64])))
        with self.assertRaisesRegex(ValueError,'request-specific'):f.inspect()

    def test_valid_token_zero_does_not_become_padding(self):
        f=self.fixture('batch-left');b=next(o for o in f.plan['observations'] if o['request']=='B')
        self.assertEqual(f.plan['input_ids'][1][64],0);self.assertEqual(f.plan['attention_mask'][1][64],1)
        f.change_word(1,64,0,0x7f80)
        with self.assertRaisesRegex(ValueError,'valid native row'):f.inspect()

    def test_pad_nonfinite_counts_cannot_be_coerced_or_hidden(self):
        f=self.fixture('batch-right');f.edit('raw-row-inventory.json',lambda d:d['pad_only_nonfinite_counts'].update(nonfinite=0))
        with self.assertRaisesRegex(ValueError,'pad-only raw inventory'):f.inspect()

    def test_missing_logical_observation_or_full_row_cannot_be_shared_away(self):
        f=self.fixture('batch-right');del f.endpoint.files[f.prefix+'/request-B/distributions.json']
        with self.assertRaisesRegex(ValueError,'missing'):f.inspect()
        f=self.fixture('batch-right');f.edit('request-B/distributions.json',lambda d:d['positions'].pop())
        with self.assertRaisesRegex(ValueError,'request-specific'):f.inspect()

    def test_NPY_or_model_state_tamper_rejected(self):
        f=self.fixture('alone-B');path=f.path('request-B/dist-p000.npy')
        arr=np.load(path,allow_pickle=False);arr[0,0]-=.125
        with path.open('wb') as stream:np.save(stream,arr,allow_pickle=False)
        with self.assertRaisesRegex(ValueError,'NPY reconstruction'):f.inspect()
        f=self.fixture('alone-A');f.edit('model-state-after.json',lambda d:d.update(changed=True))
        with self.assertRaisesRegex(ValueError,'persistent loaded'):f.inspect()

    def test_batch_raw_cannot_be_replaced_by_only_B96_physical_rows(self):
        f=self.fixture('batch-right');safetensors(f.raw,f.bits[1:2,:96,:])
        with self.assertRaisesRegex(ValueError,'physical dtype/shape'):f.inspect()

    def test_exact18_pairs_cross_first_and_length_specific_shared_comparison(self):
        plans=a.pairs();self.assertEqual(len(plans),18);self.assertTrue(all(p[-1]=='cross_backend_matched' for p in plans[:6]))
        self.assertTrue(all(ra==rb for _,_,ra,_,_,rb,_ in plans))
        status=write(Path(self.tmp.name)/'completed.json',{'rank':0,'status':'completed'})
        runs={}
        for category in ('GPU','NPU'):
            modes={}
            for mode in n.MODES:modes[mode]=self.fixture(mode).inspect()
            runs[category]={'category':category,'modes':modes,'model':{'synthetic_checkpoint':'one'},'hardware':{'category':category},
                'software':{'synthetic':'CPU only'},'backend_policy':{'synthetic':True},'status_path':str(status),
                'loaded_model_state_sha256':'a'*64,'implementation_sha256':{'synthetic':'b'*64}}
        count=0
        for index,(ca,ma,ra,cb,mb,rb,kind) in enumerate(plans):
            request=self.fixture('alone-'+ra).inventory['requests'][ra]
            report=a.compare_pair(Path(self.tmp.name)/('pair-%02d'%index),a.observation_run(runs[ca],ma,ra),a.observation_run(runs[cb],mb,rb),request)
            self.assertEqual(report['targets']['coverage']['paired'],159 if ra=='A' else 95)
            self.assertEqual(report['distributions']['position_count'],47);count+=len(report['frozen_document_sha256'])
        self.assertEqual(count,144)


class FrozenProofAndTransport(unittest.TestCase):
    def test_actual_CPU21_raw_proof_copies_preserve_original_sources_and_reject_getter_tamper(self):
        proof=HERE.parent/'transfer/i04-cpu-proof-local-20261106T183346Z/payload/prerequisite.json'
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);ep=Endpoint(root);logical='/synthetic/I04/cpu/prerequisite.json';doc=n.load(proof);refs=[]
            def visit(value):
                if isinstance(value,dict):
                    if set(value)=={'path','source_path','sha256'}:refs.append(value)
                    else:
                        for item in value.values():visit(item)
                elif isinstance(value,list):
                    for item in value:visit(item)
            visit(doc);ep.add(logical,proof.read_bytes())
            for item in refs:ep.add('/synthetic/I04/cpu/'+item['path'],(proof.parent/item['path']).read_bytes())
            _,checked,names=n.copy_portable(ep,logical,a.CPU_PROOF_SHA,n.cpu_proof,root/'new-copy',21)
            self.assertEqual((len(checked['refs']),len(names)),(21,22))
            getter=doc['runtime_sources']['torch_npu_npu'];ep.files['/synthetic/I04/cpu/'+getter['path']].write_bytes(b'changed getter')
            with self.assertRaisesRegex(ValueError,'source SHA'):
                n.copy_portable(ep,logical,a.CPU_PROOF_SHA,n.cpu_proof,root/'reject-copy',21)

    def test_execution_source_closure_checks_before_after_and_original_bytes(self):
        with tempfile.TemporaryDirectory() as temp:
            ep=Endpoint(Path(temp));logical='/synthetic/original/code.py';path=ep.add(logical,b'# synthetic source\n')
            sources={logical:n.sha(path)};claim='/synthetic/claim';outer={'source_sha256':sources,'dependency_paths':[logical]}
            ep.add(claim+'/sources-before.json',sources);after=ep.add(claim+'/sources-after.json',sources)
            self.assertEqual(a.frozen_sources(ep,outer,claim),sources)
            write(after,{**sources,'/injected/unfrozen.py':'a'*64})
            with self.assertRaisesRegex(ValueError,'maps differ'):a.frozen_sources(ep,outer,claim)
            write(after,sources);path.write_bytes(b'mutated original source')
            with self.assertRaisesRegex(ValueError,'source SHA'):a.frozen_sources(ep,outer,claim)

    def test_actual_expected_shared_omission_rejected(self):
        case=HERE.parent;expected=case/'transfer/i04-independent-expected-20261107.json'
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'changed-expected.json';doc=n.load(expected);doc['requests']['B']['all_targets'].pop();write(path,doc)
            with self.assertRaisesRegex(ValueError,'independently derived'):
                n.expected.verify(path,case/'inputs/discovery-v1/wikitext2-discovery-001.json',case/'inputs/i04-prefix-stress-096-v1.json',case/'i04-stage-v1.json')

    def test_actual_I03_portable_raw_bytes_and_tamper(self):
        proof=HERE.parent/'transfer/i03-numeric-small-local-20261106T170703Z/payload/i04-prerequisite/prerequisite.json'
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);ep=Endpoint(root);logical='/synthetic/I04/prerequisite/prerequisite.json';doc=n.load(proof)
            ep.add(logical,proof.read_bytes())
            refs=[doc[k] for k in ('controller','report','comparison_spec','analysis_source','artifact_helper_source','tool_manifest')]+list(doc['source_maps'].values())
            for item in refs:ep.add('/synthetic/I04/prerequisite/'+item['path'],(proof.parent/item['path']).read_bytes())
            _,checked,names=n.copy_portable(ep,logical,n.I03_PROOF_SHA,n.i03_proof,root/'new-copy',8)
            self.assertEqual((len(checked['refs']),len(names)),(8,9))
            ep.files['/synthetic/I04/prerequisite/'+refs[0]['path']].write_bytes(b'changed raw original proof')
            with self.assertRaisesRegex(ValueError,'source SHA'):n.copy_portable(ep,logical,n.I03_PROOF_SHA,n.i03_proof,root/'never-accepted',8)

    def test_no_GPU_retained_fallback_and_bad_source_hash_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);original='/original/modes/alone-B/raw-native-logits.safetensors'
            mapping={'schema_version':1,'files':{original:{'retained_at_source':True,'sha256':'a'*64,'size':2}}}
            path=write(root/'source-map.json',mapping);ep=n.Endpoint(path,n.sha(path))
            with self.assertRaisesRegex(ValueError,'explicit'):ep.get(original)
            payload=root/'payload';payload.write_bytes(b'original')
            mapping['files'][original]={'path':'payload','sha256':'b'*64,'size':8};write(path,mapping);ep=n.Endpoint(path,n.sha(path))
            with self.assertRaisesRegex(ValueError,'SHA'):ep.get(original)

    def test_production_native_source_pins_match_reviewed_bytes_and_do_not_import_frameworks(self):
        for name,digest in a.LAUNCHERS.values():self.assertEqual(n.sha(HERE.parent/'transfer'/name),digest)
        self.assertEqual(a.CPU_PROOF_SHA,'8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec')
        self.assertFalse(any(name in __import__('sys').modules for name in ('torch','torch_npu','i04_common_v1')))

    def test_actual_immutable_tool_import_closure(self):
        a.verify_tools()
        self.assertEqual(n.sha(n.__file__),a.HELPER_SHA)


if __name__=='__main__':unittest.main()

"""Freeze a deterministic, limited WikiText-2 discovery pilot for Gemma 4.

Only train rows are used; this is not a validation set or a representative
multi-domain workload. Source and tokenizer hashes are verified before selection.
"""
import argparse
import hashlib
import json
import platform
from pathlib import Path

SOURCE_SHA = 'e83889baabc497075506f91975be5fac0d45c5290b6b20582c8cd1e853d0c9f7'
TOKENIZER_SHA = '42cacba08980fc39bfe2c73cb8c4486b9d00f2f2671072c6cb9c45ee2c5cfaae'
DATA_REV = 'b08601e04326c79dfdd32d625aee71d232d685c3'
MODEL_REV = '1a2c7729392586f5ecddae8807ee2ef741eabb9a'
SEED = 'gemma4-wikitext-discovery-v1'
BINS = (128, 512, 2048)
PER_BIN = 4
CONTINUATION = 32


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8*1024*1024), b''): h.update(b)
    return h.hexdigest()


def normalized(text):
    return ' '.join(text.split()).casefold()


def select(rows, encode, bins=BINS, per_bin=PER_BIN, continuation=CONTINUATION):
    # Deduplicate normalized content first, retaining the smallest source row ID.
    # Rank unique candidates by a stable seed+content hash, then fill the largest
    # unmet eligible bin first; a row is never used in more than one bin.
    unique={}
    for i,text in enumerate(rows):
        if not isinstance(text,str): continue
        norm=normalized(text)
        if not norm: continue
        digest=sha_bytes(norm.encode('utf-8'))
        unique.setdefault(digest,(i,text))
    ranked=sorted(unique.items(), key=lambda x: (sha_bytes((SEED+':'+x[0]).encode()),x[0]))
    counts={n:0 for n in bins}; selected=[]
    for digest,(row,text) in ranked:
        ids=encode(text)
        if not isinstance(ids,list) or any(type(x) is not int or x < 0 for x in ids):
            raise ValueError('tokenizer returned invalid IDs')
        # Insert BOS once, with no automatic special tokens or EOS.  Reject any
        # literal special IDs from content, rather than introducing hidden stops.
        if any(t in (0,1,2) for t in ids): continue
        for n in sorted(bins,reverse=True):
            text_prompt=n-1
            if counts[n] < per_bin and len(ids) >= text_prompt+continuation:
                counts[n]+=1
                selected.append({'row':row,'normalized_sha256':digest,
                    'source_text_sha256':sha_bytes(text.encode('utf-8')),
                    'source_token_count':len(ids),'bin':n,
                    'text_token_span':[0,text_prompt+continuation],
                    'prompt':[2]+ids[:text_prompt],
                    'continuation':ids[text_prompt:text_prompt+continuation]})
                break
        if all(counts[n]>=per_bin for n in bins): break
    return selected,counts,len(unique)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source',required=True,type=Path)
    ap.add_argument('--tokenizer',required=True,type=Path)
    ap.add_argument('--output',required=True,type=Path,help='new output directory')
    a=ap.parse_args()
    if sha_file(a.source)!=SOURCE_SHA or sha_file(a.tokenizer)!=TOKENIZER_SHA:
        raise ValueError('source or tokenizer SHA-256 does not match pinned upstream metadata')
    import pyarrow, pyarrow.parquet as pq
    import tokenizers
    if pyarrow.__version__!='22.0.0' or tokenizers.__version__!='0.22.1':
        raise ValueError('requires pyarrow 22.0.0 and tokenizers 0.22.1')
    tokenizer=tokenizers.Tokenizer.from_file(str(a.tokenizer))
    if tokenizer.token_to_id('<bos>')!=2 or tokenizer.token_to_id('<eos>')!=1:
        raise ValueError('unexpected Gemma tokenizer special-token IDs')
    rows=pq.read_table(a.source,columns=['text']).column('text').to_pylist()
    chosen,counts,unique=select(rows,lambda text: tokenizer.encode(text,add_special_tokens=False).ids)
    a.output.mkdir(parents=True,exist_ok=False)
    samples=[]
    for index,item in enumerate(chosen,1):
        sample='wikitext2-discovery-%03d'%index
        payload={'sample':sample,'prompt':item.pop('prompt'),'continuation':item.pop('continuation')}
        path=a.output/(sample+'.json')
        with path.open('x',encoding='utf-8',newline='\n') as f:
            json.dump(payload,f,ensure_ascii=False,separators=(',',':')); f.write('\n')
        samples.append({'sample':sample,'source_split':'train','source_row_zero_based':item.pop('row'),
                        'file':path.name,'file_sha256':sha_file(path),**item})
    manifest={'state':'frozen_discovery_pilot','scope':'WikiText English encyclopedia text only; not representative of multilingual/code/math or deployment quality. Synthetic stress is excluded.',
      'source':{'repository':'Salesforce/wikitext','revision':DATA_REV,'subset':'wikitext-2-raw-v1','split':'train',
                'file':'wikitext-2-raw-v1/train-00000-of-00001.parquet','sha256':SOURCE_SHA,'license':'CC-BY-SA-4.0',
                'license_url':'https://huggingface.co/datasets/Salesforce/wikitext'},
      'tokenizer':{'repository':'google/gemma-4-12B','revision':MODEL_REV,'file':'tokenizer.json','sha256':TOKENIZER_SHA,
                   'library':'tokenizers','version':tokenizers.__version__,'add_special_tokens':False,
                   'bos_id':2,'eos_added':False,'pad_added':False,'mask':'all ones','positions':'zero based consecutive'},
      'selection':{'seed':SEED,'normalization':'Unicode whitespace collapse plus casefold; SHA-256',
                   'rank':'SHA-256(seed + colon + normalized SHA-256), then normalized SHA-256',
                   'duplicate_policy':'first source row per normalized digest',
                   'assignment':'largest unmet eligible bin first; one row per bin',
                   'prompt_bins_including_bos':list(BINS),'requested_per_bin':PER_BIN,
                   'continuation_tokens':CONTINUATION,'observed_per_bin':counts,'unique_nonempty_rows':unique,
                   'truncation':'first selected token span; no EOS; original source row retained in pinned parquet',
                   'validation':'not selected; future validation must be independent and exclude discovery sources and normalized hashes'},
      'runtime':{'python':platform.python_version(),'pyarrow':pyarrow.__version__,'tokenizers':tokenizers.__version__},
      'samples':samples}
    with (a.output/'discovery.json').open('x',encoding='utf-8',newline='\n') as f:
        json.dump(manifest,f,indent=2,ensure_ascii=False); f.write('\n')
    print(json.dumps({'samples':len(samples),'counts':counts,'manifest_sha256':sha_file(a.output/'discovery.json')}))
    return 0


if __name__=='__main__': raise SystemExit(main())

"""Export actual I04 numerical metadata without stat/open/copy of572 arrays.

Original receipt bytes and original POSIX source identities are preserved.
Producer array hashes are descriptors; this exporter never claims fresh hashes.
"""
import argparse
import base64
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path,PurePosixPath
import re
import signal
import sys
import tarfile

CASE='projects/gemma4-pilot/cases/text-native'
MAIN=CASE+'/adapters/admit_i04_batch_padding_v1.py'
HELPER=CASE+'/adapters/i04_artifact_admission_v1.py'
CONTROLLER=CASE+'/transfer/run_i04_actual_compare_v1.py'
CONTROLLER_SHA='a01ab2aef1ebb99402bd04f739f9f8e751979e77d87599835d5f413c88c59178'
MAIN_SHA='640b0af596111e12eb73aca20f7b8e5b101c04341af0aed2d3a5f9a1d2f19db0'
HELPER_SHA='0d43e77420285436f4151d42c6cd8a6792001b004e0e0b870242f90c5bd33719'
TOOL_SHA='06c4467c5b5b17bc5a5626fbded4e581b907ff89197976a063cf6da04c4292cb'
STAGE_SHA='26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
MAX_SMALL,MAX_TOTAL,MAX_GZIP,MAX_ENVELOPE=16*1024**2,128*1024**2,32*1024**2,64*1024**2
HEX=re.compile(r'^[a-f0-9]{64}$')
MODES=['alone-A','alone-B','batch-left','batch-right']
POSITIONS={'A':sorted(set(i*127//15 for i in range(16))|set(range(127,159))),
 'B':sorted(set(i*63//15 for i in range(16))|set(range(63,95)))}
LARGE={'modes/'+m+'/raw-native-logits.safetensors' for m in MODES}
LARGE|={'modes/%s/request-%s/dist-p%03d.npy'%(m,r,p) for m in MODES
 for r in ([m[-1]] if m.startswith('alone-') else ['A','B']) for p in POSITIONS[r]}


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def load(path):
    def pairs(items):
        out={}
        for k,v in items:require(k not in out,'duplicate JSON key');out[k]=v
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)


def put(path,doc):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(doc,stream,indent=2,allow_nan=False);stream.write('\n')


def origin(name):
    p=PurePosixPath(str(name));require(p.is_absolute() and '..' not in p.parts and '\\' not in str(name),'original absolute POSIX identity required');return str(name)


def relative(name):
    p=PurePosixPath(name);require(bool(name) and not p.is_absolute() and str(p)==name and '\\' not in name and
        all(x not in ('','.','..') for x in name.split('/')),'canonical contained relative path required');return p


def metadata(path):
    p=Path(path)
    # This guard precedes is_file/stat/open, even for unknown missing native paths.
    require(p.suffix not in ('.npy','.safetensors','.tar','.gz','.whl'),'native array/archive is not metadata')
    require(p.is_file() and not p.is_symlink() and p.stat().st_size<=MAX_SMALL,'bounded regular16MiB metadata required');return p


def verify_controller(path,digest):
    path=metadata(path);require(HEX.fullmatch(digest) and sha(path)==digest,'external actual controller SHA differs')
    state=load(path);run=path.parent;tools=Path(state['tools_root'])
    require(state.get('task')=='I04' and state.get('run')==str(run) and state.get('status')=='completed' and
        type(state.get('returncode')) is int and state['returncode']==0 and type(state.get('child_returncode')) is int and state['child_returncode']==0 and
        state.get('timed_out') is False and state.get('native_executions_started')==0 and state.get('whole_cpu_seconds')==960 and
        state.get('child_work_seconds')==920 and state.get('analysis_seconds')==900 and state.get('cleanup_reserve_seconds')==20 and
        state.get('tool_manifest_sha256')==TOOL_SHA and state.get('acceptance',object()) is None,'actual finite completed I04 controller required')
    source=metadata(tools/CONTROLLER);require(sha(source)==CONTROLLER_SHA,'reviewed controller source differs')
    sys.dont_write_bytecode=True
    spec=importlib.util.spec_from_file_location('_i04_small_frozen_controller',source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.verify_tools(tools,TOOL_SHA)
    argv=state['argv'];require(len(argv)==11 and argv[1]=='-B' and Path(argv[2])==tools/MAIN and sha(argv[2])==MAIN_SHA,
        'literal actual numerical main differs')
    expected={'--spec':str(run/'comparison-spec.json'),'--spec-sha256':state['comparison_spec']['sha256'],
        '--output-dir':str(run/'bundle'),'--timeout-seconds':'900'}
    for key,value in expected.items():
        require(argv.count(key)==1 and argv[argv.index(key)+1]==value,'literal actual analysis argv differs')
    for key,wanted in [('comparison_spec',run/'comparison-spec.json'),('report',run/'bundle/i04-comparison-report.json')]:
        ref=state[key];require(Path(ref['path'])==wanted and sha(metadata(wanted))==ref['sha256'],'original spec/report SHA differs')
    comparison=load(state['comparison_spec']['path']);report=load(state['report']['path']);module.validate_report(report,state['comparison_spec']['sha256'])
    require(state['scope']==report['scope'] and report['source_map_sha256']=={k:v['source_map']['sha256'] for k,v in comparison['endpoints'].items()},
        'controller/report/endpoint scope differs')
    require(comparison.get('task')==module.TASK and comparison.get('stage_spec_sha256')==STAGE_SHA and
        comparison.get('expected_inventory_sha256')==module.EXPECTED_SHA and comparison.get('i03_prerequisite_sha256')==module.PROOF_SHA and
        comparison.get('cpu_prerequisite_sha256')==module.CPU_SHA and set(comparison.get('endpoints',{}))=={'GPU','NPU'} and
        comparison.get('thresholds',object()) is None and comparison.get('acceptance',object()) is None,'dual-proof original comparison specification differs')
    generic_ref=state['generic_receipt'];generic_path=metadata(generic_ref['path']);require(sha(generic_path)==generic_ref['sha256'],'original generic byte SHA differs')
    generic=load(generic_path)
    require(generic.get('status')=='completed' and type(generic.get('returncode')) is int and generic['returncode']==0 and
        type(generic.get('child_returncode')) is int and generic['child_returncode']==0 and generic['argv']==argv and
        generic['timeout']==920 and Path(generic['cwd'])==tools,'original successful920-second generic execution differs')
    execution=generic['execution'];snapshot=metadata(execution['snapshot']);profile=metadata(execution['path'])
    require(sha(snapshot)==execution['sha256'] and snapshot.read_bytes()==profile.read_bytes(),'original/snapshot CPU profile differs')
    for key in ('stdout','stderr'):
        ref=state[key];p=metadata(ref['path']);require(p==generic_path.parent/(key+'.bin') and p.stat().st_size==ref['bytes'] and sha(p)==ref['sha256'],
            'original generic stdout/stderr bytes differ')
    require(load(state['stdout']['path'])=={'status':report['status'],'target_distribution_pairs':18,'native_executions_started':0,'acceptance':None},
        'numerical stdout/report differs')
    require(datetime.fromisoformat(state['started_utc'])<=datetime.fromisoformat(generic['start'])<=datetime.fromisoformat(generic['end'])<=
        datetime.fromisoformat(state['finished_utc']),'same-host controller/generic clock containment differs')
    for pair in report['target_distribution_pairs']:
        count=159 if pair['request']=='A' else 95
        require(pair['targets']['status']==pair['distributions']['status']=='no_thresholds' and
            pair['targets']['coverage']=={'expected':count,'paired':count} and pair['distributions']['position_count']==47 and
            pair['thresholds'] is None and pair['acceptance'] is None,'request-specific159/95 score scope differs')
    return state,comparison,report,load(tools/'tool-bundle-manifest.json')


class Catalog:
    def __init__(self,output):self.output=Path(output);self.files={};self.sources={};self.omitted={};self.total=0;self.copies={}
    def add(self,actual,expected=None,role='metadata',original=None):
        actual=Path(actual);key=origin(str(actual) if original is None else original)
        require(key not in self.omitted and PurePosixPath(key).suffix not in ('.npy','.safetensors'),'proven native arrays must never be accessed')
        actual=metadata(actual);digest=sha(actual);require(expected is None or expected==digest,'small metadata source SHA differs: '+key)
        if key in self.files:require(self.files[key]['sha256']==digest,'original source alias conflicts');return
        identity=(str(actual.resolve(strict=True)),digest)
        if identity not in self.copies:
            relative_path='payload/%04d/%s'%(len(self.copies),actual.name);target=self.output/relative_path;target.parent.mkdir(parents=True)
            raw=actual.read_bytes();require(hashlib.sha256(raw).hexdigest()==digest,'source changed before metadata copy')
            self.total+=len(raw);require(self.total<=MAX_TOTAL,'metadata payload exceeds128MiB')
            with target.open('xb') as stream:stream.write(raw)
            self.copies[identity]={'path':relative_path,'sha256':digest,'size':len(raw)}
        self.files[key]={**self.copies[identity],'role':role};self.sources[key]=str(actual)
    def close(self):
        for key,ref in self.files.items():require(sha(self.sources[key])==ref['sha256'] and sha(self.output/ref['path'])==ref['sha256'],'metadata source/copy changed')
    def endpoint(self,info,backend):
        ref=info['source_map'];mapping=metadata(ref['path']);require(sha(mapping)==ref['sha256'],'admitted endpoint map byte SHA differs')
        self.add(mapping,ref['sha256'],'original_endpoint_source_map');doc=load(mapping);outer_name=info['receipt']['source_path']
        require(doc.get('schema_version')==1 and doc['request']=={'task':'I04','backend':backend,'outer_receipt':outer_name} and
            doc.get('full_array_hashes_checked')==286 and doc.get('retained_array_count')==(0 if backend=='GPU' else 286),'exact actual endpoint transport identity differs')
        def small(name,digest=None):
            origin(name);require(PurePosixPath(name).suffix not in ('.npy','.safetensors'),'attempted native array access')
            item=doc['files'][name];r=relative(item['path']);actual=mapping.parent.joinpath(*r.parts)
            require(not item.get('retained_at_source') and actual.resolve(strict=True).is_relative_to(mapping.parent.resolve()),'small original source has no contained copied bytes')
            require(type(item.get('size')) is int and item['size']>=0 and HEX.fullmatch(item['sha256']) and
                (digest is None or digest==item['sha256']),'small mapped source descriptor differs')
            self.add(actual,item['sha256'],'verbatim_endpoint_source',name);require(self.files[name]['size']==item['size'],'small copied metadata size differs');return actual
        outer=load(small(outer_name,info['receipt']['sha256']));require(outer['task']=='I04' and outer['backend']==backend and
            outer['status']=='completed' and type(outer['returncode']) is int and outer['returncode']==0 and
            outer['timed_out'] is False and outer['native_capture_count']==1 and outer['native_forward_calls_total']==4 and outer['model_loads']==1,
            'actual completed four-call endpoint differs')
        output=origin(outer['output_dir']);manifest=load(small(output+'/artifacts-manifest.json',outer['artifacts_manifest_sha256']))
        require(len(manifest['files'])==(621 if backend=='GPU' else 622) and {n for n in manifest['files'] if n.endswith(('.npy','.safetensors'))}==LARGE,
            'manifest exact4raw/282NPY geometry differs')
        require({n[len(output)+1:] for n in doc['files'] if n.startswith(output+'/')}==set(manifest['files'])|{'artifacts-manifest.json','status.json'},
            'complete original small/large output manifest inventory differs')
        pool={output+'/'+name:manifest['files'][name] for name in LARGE}
        require({name for name in doc['files'] if name.endswith(('.npy','.safetensors'))}==set(pool),'unexpected or missing native/model array in endpoint map')
        for name,source_ref in pool.items():
            # Do NOT resolve, exists, is_file, stat, open, hash or copy this path.
            item=doc['files'][name]
            require(type(item.get('size')) is int and item['size']>0 and item['size']==source_ref['size_bytes'] and
                HEX.fullmatch(item['sha256']) and item['sha256']==source_ref['sha256'],'proven omitted array identity differs')
            if backend=='GPU':require('path' in item and not item.get('retained_at_source'),'GPU admitted array must have a copied descriptor');relative(item['path'])
            else:require(item.get('retained_at_source') is True and 'path' not in item,'NPU original array descriptor must be retained')
            require(name not in self.omitted,'two backends alias a native array')
            self.omitted[name]={'backend':backend,'sha256':item['sha256'],'size':item['size'],'reason':'exact_admitted_I04_native_array_not_statted_opened_or_copied','hash_source':'prior admitted map/manifest; no fresh array hash by exporter'}
        for name in doc['files']:
            if name in pool:continue
            small(name)


def export(controller_path,controller_sha,output):
    controller_path=Path(controller_path).resolve(strict=True);output=Path(output).resolve()
    require(not output.exists() and output.parent.is_dir(),'exclusive new I04 small export required')
    state,spec,report,tool_doc=verify_controller(controller_path,controller_sha);output.mkdir(mode=0o700);catalog=Catalog(output)
    catalog.add(Path(__file__).resolve(),role='small_exporter_source')
    for backend in ('GPU','NPU'):catalog.endpoint(spec['endpoints'][backend],backend)
    require(len(catalog.omitted)==572 and sum(n.endswith('.npy') for n in catalog.omitted)==564 and
        sum(n.endswith('.safetensors') for n in catalog.omitted)==8,'exact572 omitted descriptors required')
    # This owned numerical run has only metadata and original generic logs. It
    # never contains or traverses either endpoint native output directory.
    for parent,directories,names in os.walk(controller_path.parent,followlinks=False):
        require(all(not (Path(parent)/n).is_symlink() for n in directories),'numeric metadata tree contains symlink')
        for name in names:catalog.add(Path(parent)/name,role='actual_numeric_run_metadata')
    frozen=0
    for pair in report['target_distribution_pairs']:
        folder=Path(pair['targets']['sources']['contract']).parent
        require(folder.resolve(strict=True).is_relative_to(controller_path.parent/'bundle') and len(pair['frozen_document_sha256'])==8,'frozen eight-document directory differs')
        for name,digest in pair['frozen_document_sha256'].items():
            require(PurePosixPath(name).name==name,'frozen comparison name escapes');catalog.add(folder/name,digest,'frozen_comparison_document');frozen+=1
    require(frozen==144,'all144 numerical comparison documents required')
    tools=Path(state['tools_root']);catalog.add(tools/'tool-bundle-manifest.json',TOOL_SHA,'frozen_tool_manifest')
    for name,ref in tool_doc['files'].items():catalog.add(tools/name,ref['sha256'],'frozen_numerical_source')
    proof=output/'observer-prerequisite';(proof/'proof').mkdir(parents=True)
    originals={'controller':('i04-controller.json',controller_path),'report':('i04-report.json',Path(state['report']['path'])),
        'comparison_spec':('i04-comparison-spec.json',Path(state['comparison_spec']['path'])),'analysis_source':('i04-analysis.py',tools/MAIN),
        'artifact_helper_source':('i04-artifact-helper.py',tools/HELPER),'tool_manifest':('i04-tool-manifest.json',tools/'tool-bundle-manifest.json'),
        'GPU':('gpu-source-map.json',Path(spec['endpoints']['GPU']['source_map']['path'])),'NPU':('npu-source-map.json',Path(spec['endpoints']['NPU']['source_map']['path']))}
    refs={}
    for key,(name,path) in originals.items():
        raw=metadata(path).read_bytes();target=proof/'proof'/name
        with target.open('xb') as stream:stream.write(raw)
        refs[key]={'path':'proof/'+name,'source_path':str(path),'sha256':sha(path)};require(sha(target)==refs[key]['sha256'],'portable original proof bytes differ')
    put(proof/'prerequisite.json',{'schema_version':1,'kind':'observer-i04-numeric-prerequisite','prior_stage_sha256':STAGE_SHA,
        **{k:refs[k] for k in ('controller','report','comparison_spec','analysis_source','artifact_helper_source','tool_manifest')},
        'source_maps':{k:refs[k] for k in ('GPU','NPU')}})
    generated={p.relative_to(output).as_posix():{'sha256':sha(p),'size':p.stat().st_size} for p in proof.rglob('*') if p.is_file()}
    catalog.close();put(output/'metadata-source-map.json',{'schema_version':1,'kind':'i04-actual-numeric-small-export',
        'controller':{'path':str(controller_path),'sha256':controller_sha},'report':state['report'],'comparison_spec':state['comparison_spec'],
        'files':catalog.files,'omitted':catalog.omitted,'generated_files':generated,'arrays_statted_opened_or_copied':0,
        'fresh_array_hashes_by_exporter':0,'numeric_replay_performed_by_exporter':False,'native_executions_started':0,'acceptance':None})
    require(sum(p.stat().st_size for p in output.rglob('*') if p.is_file())<=MAX_TOTAL,'complete metadata products exceed128MiB')
    paths=[output.with_name(output.name+'.tar.gz'),output.with_name(output.name+'-observer-prerequisite.tar.gz')];archives=[]
    for folder,target in zip((output,proof),paths):
        with target.open('xb') as destination,tarfile.open(fileobj=destination,mode='w:gz') as package:
            for p in sorted(folder.rglob('*')):
                require(not p.is_symlink(),'small export contains symlink')
                if p.is_file():package.add(p,arcname=p.relative_to(folder).as_posix(),recursive=False)
        require(target.stat().st_size<=MAX_GZIP,'small gzip exceeds32MiB');archives.append({'basename':target.name,'bytes':target.stat().st_size,'sha256':sha(target)})
    catalog.close();require(sha(controller_path)==controller_sha,'actual controller changed')
    for name,ref in generated.items():require(sha(output/name)==ref['sha256'],'portable proof changed')
    envelope=output.with_name(output.name+'-json-base64.txt');put(envelope,{'schema_version':1,'kind':'i04-actual-small-archives',
        'archives':[{**ref,'base64':base64.b64encode(p.read_bytes()).decode('ascii')} for ref,p in zip(archives,paths)]})
    require(envelope.stat().st_size<=MAX_ENVELOPE,'base64 envelope exceeds64MiB')
    result={'status':'i04_actual_small_export_completed','controller_sha256':controller_sha,'report_sha256':state['report']['sha256'],
        'metadata_source_map_sha256':sha(output/'metadata-source-map.json'),'copied_metadata_original_aliases':len(catalog.files),
        'unique_payload_files':len(catalog.copies),'unique_metadata_source_bytes':catalog.total,'frozen_comparison_documents_checked':144,
        'omitted_npy_files':564,'omitted_raw_native_files':8,'arrays_statted_opened_or_copied':0,'fresh_array_hashes_by_exporter':0,
        'archives':archives,'prerequisite_path':str(proof/'prerequisite.json'),'prerequisite_sha256':sha(proof/'prerequisite.json'),
        'prerequisite_raw_documents':8,'json_base64_path':str(envelope),'json_base64_bytes':envelope.stat().st_size,
        'json_base64_sha256':sha(envelope),'native_executions_started':0,'acceptance':None}
    put(output.with_name(output.name+'-export-receipt.json'),result);return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--controller',required=True,type=Path);p.add_argument('--controller-sha256',required=True)
    p.add_argument('--output',required=True,type=Path);a=p.parse_args()
    def expire(*_):raise TimeoutError('I04 small metadata export200s work deadline')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,200)
    try:print(json.dumps(export(a.controller,a.controller_sha256,a.output),indent=2),flush=True)
    finally:signal.setitimer(signal.ITIMER_REAL,0)


if __name__=='__main__':main()

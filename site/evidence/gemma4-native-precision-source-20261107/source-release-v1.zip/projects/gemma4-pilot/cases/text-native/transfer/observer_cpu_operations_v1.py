"""Exclusive source stage and bounded tiny observer CPU prerequisite only.

The frozen I04 CPUv3 source is reused only for child/subreaper/owned-PG cleanup;
its old stage/run/main are never called. No native allocation or model claim.
"""
import argparse
import ast
from datetime import datetime,timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path,PurePosixPath
import re
import shutil
import signal
import sys
import tarfile
import time
import traceback

CASE='projects/gemma4-pilot/cases/text-native'
SELF=CASE+'/transfer/observer_cpu_operations_v1.py'
COLLECTOR=CASE+'/adapters/observer_collectors_v1.py'
TEST=CASE+'/adapters/test_observer_collectors_v1.py'
PROBE=CASE+'/transfer/probe_observer_cpu_v1.py'
HELPER=CASE+'/transfer/i04_cpu_stage_operations_v3.py'
FROZEN={COLLECTOR:'774b5cb210f294a23d6865f863d5facdf537c3ed3064ae39027425797b83101c',
    TEST:'f58dbb0ee596d465ff35008ca92d30c1f6ca162ad363c198d5754c4c4af30d43',
    PROBE:'d10abe1986188ba56a24d1cccf2102860d340d3beddef3e352f3265df6c103b2',
    HELPER:'36973a846475161e3ab05ff65c75bd56a535bcaad2056f3e42e6fa498d4002a2'}
SUBDIR='observer-transparency-20261107/cpu-prerequisite-v1'
ARCHIVE='observer-cpu-prerequisite-v1.tar.gz'
MAX_CODE,MAX_EXPANDED,MAX_ARCHIVE=1024**2,4*1024**2,1024**2
TOTAL,WORK,CLEANUP=210,190,20


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def utc():return datetime.now(timezone.utc).isoformat()
def read(path):
    def pairs(items):
        out={}
        for k,v in items:require(k not in out,'duplicate JSON key');out[k]=v
        return out
    return json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,parse_constant=lambda value:(_ for _ in ()).throw(ValueError(value)))
def put(path,doc):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(doc,stream,indent=2,allow_nan=False);stream.write('\n')
def ref(path):return {'path':str(Path(path).resolve()),'sha256':sha(path),'size_bytes':Path(path).stat().st_size}


def safe(name):
    require(isinstance(name,str) and name and not PurePosixPath(name).is_absolute() and str(PurePosixPath(name))==name and
        '\\' not in name and all(x not in ('','.','..') for x in name.split('/')),'noncanonical relative source path')
    return PurePosixPath(name)


def guard(root,path):
    path=Path(path);require(path.is_absolute() and path.is_relative_to(root) and path.resolve().is_relative_to(root),'CPU prerequisite path escapes explicit root')
    current=path
    while current!=root:require(not current.is_symlink(),'symlink in owned CPU prerequisite path');current=current.parent
    return path


def verify_tree(source,manifest,digest,check_executed=False):
    source,manifest=Path(source),Path(manifest)
    require(source.is_dir() and not source.is_symlink() and not manifest.is_symlink() and sha(manifest)==digest,'external CPU source manifest differs')
    doc=read(manifest);files=doc['files']
    require(doc.get('kind')=='observer-tiny-cpu-source-v1' and doc.get('production_model_loads')==0 and
        doc.get('native_executions_started')==0 and set(files)==set(FROZEN)|{SELF},'exact five CPU source files required')
    actual=set()
    for path in source.rglob('*'):
        require(not path.is_symlink(),'source tree contains symlink')
        if path.is_file():actual.add(path.relative_to(source).as_posix())
    require(actual==set(files),'CPU source tree inventory differs')
    for name,item in files.items():
        safe(name);path=source/name
        require(path.is_file() and path.stat().st_nlink==1 and 0<path.stat().st_size<=MAX_CODE and
            item=={'sha256':sha(path),'size_bytes':path.stat().st_size},'original CPU source bytes differ')
        if name in FROZEN:require(item['sha256']==FROZEN[name],'reviewed CPU source pin differs')
    if check_executed:require(Path(__file__).resolve()==(source/SELF).resolve() and sha(__file__)==files[SELF]['sha256'],'executed CPU operations source differs')
    require(not any(n in sys.modules for n in ('torch','torch_npu','numpy','transformers')),'CPU staging imported a framework')
    return doc


def build(repo,output):
    repo=Path(repo).resolve(strict=True);output=Path(output);require(not output.exists() and output.parent.is_dir(),'exclusive CPU package output required')
    contents={}
    for name,digest in {**FROZEN,SELF:sha(__file__)}.items():
        path=repo/name;require(path.is_file() and not path.is_symlink(),'original CPU source required')
        raw=path.read_bytes();require(0<len(raw)<=MAX_CODE and hashlib.sha256(raw).hexdigest()==digest,'frozen CPU source changed');ast.parse(raw);contents[name]=raw
    doc={'schema_version':1,'kind':'observer-tiny-cpu-source-v1','production_model_loads':0,'native_executions_started':0,
        'files':{name:{'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)} for name,raw in sorted(contents.items())},
        'whole_cpu_seconds':TOTAL,'cleanup_reserve_seconds':CLEANUP,'pure_tests':14,'actual_tiny_probe_timeout_seconds':90,'acceptance':None}
    body=(json.dumps(doc,indent=2,allow_nan=False)+'\n').encode();output.mkdir(mode=0o700);archive=output/ARCHIVE
    with archive.open('xb') as stream,tarfile.open(fileobj=stream,mode='w:gz') as package:
        for name,raw in [('source-manifest.json',body),*[('source/'+name,raw) for name,raw in sorted(contents.items())]]:
            info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;package.addfile(info,io.BytesIO(raw))
    require(archive.stat().st_size<=MAX_ARCHIVE and sum(len(x) for x in contents.values())+len(body)<=MAX_EXPANDED,'CPU source packet exceeds finite cap')
    receipt={'status':'observer_cpu_source_packet_created','archive':ref(archive),'manifest_sha256':hashlib.sha256(body).hexdigest(),
        'source_files':5,'regular_members':6,'native_executions_started':0,'production_model_loads':0}
    put(output/'packet-receipt.json',receipt);return receipt


def stage(root,archive,archive_sha,manifest_sha):
    root=Path(root);require(root.is_dir() and not root.is_symlink(),'explicit existing CPU source root required');root=root.resolve(strict=True)
    archive=guard(root,Path(archive));target=guard(root,root/SUBDIR)
    require(archive.parent==root and archive.is_file() and archive.stat().st_size<=MAX_ARCHIVE and sha(archive)==archive_sha and not target.exists(),
        'new exclusive uploaded CPU source packet required')
    require(shutil.disk_usage(root).free>=64*1024**2,'CPU prerequisite source free storage below64MiB')
    with tarfile.open(archive,'r:gz') as package:
        members=package.getmembers();require(len(members)==6 and len({x.name for x in members})==6,'CPU archive member inventory differs')
        require(all(x.type==tarfile.REGTYPE and x.isfile() and not x.sparse and not x.pax_headers and 0<x.size<=MAX_CODE for x in members),
            'only finite regular CPU source members allowed')
        for item in members:safe(item.name)
        require(sum(x.size for x in members)<=MAX_EXPANDED,'CPU expanded archive cap exceeded')
        contents={x.name:package.extractfile(x).read() for x in members}
    require('source-manifest.json' in contents and hashlib.sha256(contents['source-manifest.json']).hexdigest()==manifest_sha,'external CPU source manifest SHA differs')
    doc=json.loads(contents['source-manifest.json']);files=doc['files']
    require(set(files)==set(FROZEN)|{SELF} and set(contents)=={'source-manifest.json'}|{'source/'+x for x in files},'exact CPU source archive closure differs')
    for name,item in files.items():
        safe(name);body=contents['source/'+name]
        require(item=={'sha256':hashlib.sha256(body).hexdigest(),'size_bytes':len(body)} and (name not in FROZEN or item['sha256']==FROZEN[name]),'CPU archive source bytes differ');ast.parse(body)
    # All validation precedes the first new source-directory write.
    target.parent.mkdir(mode=0o700,parents=True,exist_ok=True);target.mkdir(mode=0o700)
    for name,body in contents.items():
        path=target.joinpath(*safe(name).parts);path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        with path.open('xb') as stream:stream.write(body)
    verify_tree(target/'source',target/'source-manifest.json',manifest_sha)
    result={'status':'observer_cpu_sources_staged_not_native','source_files':5,'manifest_sha256':manifest_sha,'archive_sha256':archive_sha,
        'source_root':str(target/'source'),'production_model_loads':0,'native_executions_started':0,'native_claim_created':False,'finished_utc':utc()}
    put(target/'stage-receipt.json',result);return result


def validate_probe(path):
    doc=read(path);result=doc.get('result',{})
    require(doc.get('status')=='completed' and doc.get('returncode')==0 and doc.get('timeout_seconds')==90 and
        doc.get('source',{}).get('sha256')==FROZEN[PROBE] and doc.get('collectors_source',{}).get('sha256')==FROZEN[COLLECTOR] and
        result.get('checks_passed')==29 and len(set(result.get('checks',[])))==29 and result.get('tiny_cpu_forward_calls')==5 and
        result.get('production_model_loads')==result.get('production_model_forward_calls')==0 and result.get('tiny_boundary_count')==4 and
        result.get('production_boundary_count')==98,'actual tiny Torch CPU result scope differs')
    require(doc.get('agent_hardware_or_availability_queries')==doc.get('agent_accelerator_initialization_requests')==0 and
        doc.get('library_internal_availability_queries')=='not instrumented' and doc.get('versions',{}).get('torch','').split('+')[0]=='2.9.0',
        'CPU prerequisite version/context/query scope differs')
    phases=doc.get('phase_observations',[])
    require([x.get('phase') for x in phases]==['after_torch','before_tiny_cpu_calls','after_tiny_cpu_calls'] and
        all(type(x.get('torch_npu_imported')) is bool and type(x.get('npu_namespace_registered')) is bool and
            x.get('npu_initialized') is (False if x['npu_namespace_registered'] else None) and x.get('cuda_initialized') is False for x in phases),
        'tiny CPU prerequisite observed initialized accelerator context')
    require(set(doc.get('runtime_sources',{}))=={'torch','numpy','safetensors','torch_dispatch','module_hooks'},'exact actual CPU runtime source inventory differs')
    require(len(result.get('mode_outputs',[]))==4 and len({x['raw_bits_sha256'] for x in result['mode_outputs']})==1 and
        [x['mode'] for x in result['mode_outputs']]==['off-before','hooks-only','off-after','hooks-plus-dispatch-metadata'],
        'actual tiny CPU transparency output mismatch')
    for item in [*[x['artifact'] for x in result['mode_outputs']],result['selected_samples']]:
        source=Path(item['path']);require(source.resolve().is_relative_to(Path(path).parent.resolve()) and source.is_file() and not source.is_symlink() and
            source.stat().st_size<=65536 and ref(source)==item,'original tiny CPU artifacts changed')
    return doc


def run(root,manifest_sha):
    started=time.monotonic();root=Path(root);require(os.name=='posix' and root.is_dir() and not root.is_symlink(),'POSIX original CPU root required');root=root.resolve(strict=True)
    target=guard(root,root/SUBDIR);source=target/'source';manifest=target/'source-manifest.json';verify_tree(source,manifest,manifest_sha,True)
    require(shutil.disk_usage(target).free>=64*1024**2,'CPU prerequisite free storage below64MiB')
    put(target/'cpu-attempt-once.json',{'claimed_utc':utc(),'kind':'CPU-only attempt marker; not native allocation/model claim',
        'manifest_sha256':manifest_sha,'native_claim_created':False,'native_executions_started':0,'automatic_retry':False})
    runs=target/'runs';runs.mkdir(mode=0o700);folder=runs/('compare-observer-tiny-cpu-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));folder.mkdir(mode=0o700)
    state={'schema_version':1,'task':'observer-cpu-validation-v1','status':'running','started_utc':utc(),'source_manifest_sha256':manifest_sha,
        'source_root':str(source),'whole_cpu_seconds':TOTAL,'cleanup_reserve_seconds':CLEANUP,'steps':[],'native_executions_started':0,
        'production_model_loads':0,'native_claim_created':False,'automatic_retry':False,'acceptance':None}
    put(folder/'controller-start.json',state)
    helper_spec=importlib.util.spec_from_file_location('observer_reviewed_cpu_children_only',source/HELPER);helper=importlib.util.module_from_spec(helper_spec);helper_spec.loader.exec_module(helper)
    require(sha(helper.__file__)==FROZEN[HELPER] and not any(x in sys.modules for x in ('torch','torch_npu','numpy','transformers')),'pure cleanup helper import/source differs')
    def expire(*_):raise KeyboardInterrupt('observer CPU whole210s deadline/signal')
    previous={sig:signal.signal(sig,expire) for sig in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
    signal.setitimer(signal.ITIMER_REAL,max(.01,TOTAL-(time.monotonic()-started)))
    try:
        tests=helper.child([sys.executable,'-S','-B','-m','unittest','test_observer_collectors_v1','-v'],source/(CASE+'/adapters'),30,folder/'tests.stdout',folder/'tests.stderr')
        state['steps'].append(tests);text=Path(tests['stderr']['path']).read_text('utf8')
        require(tests['returncode']==0 and tests['timed_out'] is False and tests['cleanup']['remaining_owned_process_group'] is False and
            re.search(r'Ran 14 tests? in ',text) and re.search(r'\nOK\s*$',text) and 'skipped' not in text,'14 fresh pure collector tests must pass with no skips')
        require(time.monotonic()-started+120<WORK,'insufficient finite actual CPU probe envelope')
        probe=helper.child([sys.executable,'-B',str(source/PROBE),'--collectors',str(source/COLLECTOR),'--collectors-sha256',FROZEN[COLLECTOR],
            '--output',str(folder/'probe')],source/(CASE+'/transfer'),120,folder/'probe.stdout',folder/'probe.stderr')
        state['steps'].append(probe)
        require(probe['returncode']==0 and probe['timed_out'] is False and probe['cleanup']['remaining_owned_process_group'] is False,'real tiny Torch CPU probe did not complete0')
        result=validate_probe(folder/'probe/receipt.json');summary=read(folder/'probe.stdout')
        require(summary['status']=='completed' and Path(summary['receipt'])==folder/'probe/receipt.json' and
            summary['receipt_sha256']==sha(folder/'probe/receipt.json'),'actual CPU probe stdout/source receipt differs')
        # Freeze the actual import bytes before a later native job changes any
        # environment. Original package paths remain in the original receipt.
        frozen=folder/'runtime-sources';frozen.mkdir();catalog={};copied=0
        for name,item in result['runtime_sources'].items():
            actual=Path(item['path']);require(actual.is_file() and not actual.is_symlink() and actual.stat().st_size<=4*1024**2 and ref(actual)==item,'actual CPU package source changed')
            body=actual.read_bytes();copied+=len(body);require(copied<=16*1024**2,'CPU runtime source closure exceeds16MiB')
            copy=frozen/(name+'.py')
            with copy.open('xb') as stream:stream.write(body)
            require(sha(copy)==item['sha256'] and ref(actual)==item,'actual CPU runtime copied bytes differ');catalog[name]={'source':item,'copy':ref(copy)}
        put(folder/'runtime-source-map.json',catalog);verify_tree(source,manifest,manifest_sha,True)
        require(time.monotonic()-started<WORK,'CPU completion exhausted cleanup reserve')
        state.update(status='completed',returncode=0,pure_tests=14,pure_test_skips=0,actual_tiny_probe_checks=29,
            probe=ref(folder/'probe/receipt.json'),runtime_source_map=ref(folder/'runtime-source-map.json'),remaining_owned_process_groups=[],
            scope='Tiny synthetic CPU nn.Module/dispatcher/BF16 evidence only; no Gemma/native backend or operator accuracy conclusion.')
    except BaseException as exc:state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),partial_files_preserved=True)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        for sig,handler in previous.items():signal.signal(sig,handler)
        state.update(finished_utc=utc(),elapsed_seconds=time.monotonic()-started);put(folder/'controller-receipt.json',state)
    print(json.dumps({'status':state['status'],'returncode':state['returncode'],'receipt':ref(folder/'controller-receipt.json'),
        'pure_tests':state.get('pure_tests'),'actual_tiny_probe_checks':state.get('actual_tiny_probe_checks'),'error':state.get('error')},indent=2),flush=True)
    return state['returncode']


def main():
    parser=argparse.ArgumentParser(description=__doc__);subs=parser.add_subparsers(dest='mode',required=True)
    p=subs.add_parser('build');p.add_argument('--repo',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p=subs.add_parser('stage');p.add_argument('--root',type=Path,required=True);p.add_argument('--archive',type=Path,required=True);p.add_argument('--archive-sha256',required=True);p.add_argument('--manifest-sha256',required=True)
    p=subs.add_parser('run');p.add_argument('--root',type=Path,required=True);p.add_argument('--manifest-sha256',required=True);args=parser.parse_args()
    if args.mode=='build':print(json.dumps(build(args.repo,args.output),indent=2))
    elif args.mode=='stage':print(json.dumps(stage(args.root,args.archive,args.archive_sha256,args.manifest_sha256),indent=2))
    else:return run(args.root,args.manifest_sha256)
    return 0


if __name__=='__main__':raise SystemExit(main())

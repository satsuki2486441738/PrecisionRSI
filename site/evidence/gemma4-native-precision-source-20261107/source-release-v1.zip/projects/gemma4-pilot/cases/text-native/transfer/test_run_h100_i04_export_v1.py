"""Synthetic CPU transport fixtures; no model, framework or device execution."""
import importlib.util
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('gpu_export_runner_fixture',HERE/'run_h100_i04_export_v1.py')
tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)


class Runner(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)/'new-i04-task';self.here=self.root/'tools/export';self.here.mkdir(parents=True)
        shutil.copyfile(HERE/'export_i04_evidence_v1.py',self.here/'export_i04_evidence_v1.py')
        repo=next(p for p in HERE.parents if (p/'skills/precision-compare/scripts/record_run.py').is_file())
        shutil.copyfile(repo/'skills/precision-compare/scripts/record_run.py',self.here/'record_run.py')
        self.claim=self.root/'claims'/tool.CLAIM_NAME;self.claim.mkdir(parents=True)
        self.terminal=self.claim/'controller-receipt.json';self.outer=self.claim/'capture-receipt.json'
        self.controller={'task':'I04','status':'completed','returncode':0,'timed_out':False,'remaining_descendants':[],
            'started_utc':'2026-11-06T15:00:12+00:00','finished_utc':'2026-11-06T15:06:00+00:00',
            'metadata_export_reserved_seconds':960,'controller_work_seconds':2020}
        self.launcher=self.root/'h100_i04_lifecycle_v2.py';shutil.copyfile(HERE/self.launcher.name,self.launcher)
        self.receipt={'task':'I04','backend':'GPU','status':'completed','returncode':0,'timed_out':False,
            'native_capture_count':1,'native_forward_calls_total':4,'model_loads':1,
            'stage_spec_source_sha256':tool.STAGE_SHA,'expected_inventory_source_sha256':tool.EXPECTED_SHA,
            'cpu_prerequisite_source_sha256':tool.CPU_SHA,'i03_prerequisite_source_sha256':tool.I03_SHA,
            'collector_sha256':tool.COLLECTOR_SHA,'source_sha256':{str(self.launcher):tool.LAUNCHER_SHA},
            'validation':{'status':'i04_output_artifacts_checked','target_scores':762,'distribution_rows':282,
                'physical_raw_rows':896,'valid_raw_rows':768,'pad_only_raw_rows':128},
            'output_dir':self.root.as_posix()+'/runs/synthetic/artifacts','synthetic_cpu_fixture':True}
        self.native_claim={'allocation_id':tool.CLAIM_NAME,'entry_started_utc':'2026-11-06T15:00:00+00:00',
            'whole_attempt_seconds':3000,'capture_seconds':900,'lifecycle_sha256':tool.LAUNCHER_SHA,
            'cpu_prerequisite_sha256':tool.CPU_SHA,'metadata_export_reserved_seconds':960,'controller_work_seconds':2020}
        self.save(self.claim/'claim.json',self.native_claim);self.save(self.terminal,self.controller);self.save(self.outer,self.receipt)
        # Production requires exact actual receipt bytes. Only fixture constants are replaced.
        self.patches=[patch.object(tool,'CONTROLLER_SHA',tool.sha(self.terminal)),patch.object(tool,'CAPTURE_SHA',tool.sha(self.outer))]
        for p in self.patches:p.start();self.addCleanup(p.stop)
        self.payload=self.root/'synthetic-payload';self.payload.mkdir();self.map_path=self.payload/'source-map.json'
        self.archive=self.root/'synthetic.tar.gz';self.archive.write_bytes(b'synthetic transport fixture')
        positions={'A':sorted(set(i*127//15 for i in range(16))|set(range(127,159))),
                   'B':sorted(set(i*63//15 for i in range(16))|set(range(63,95)))}
        names={'modes/%s/raw-native-logits.safetensors'%m for m in ['alone-A','alone-B','batch-left','batch-right']}
        names|={'modes/%s/request-%s/dist-p%03d.npy'%(m,r,p) for m in ['alone-A','alone-B','batch-left','batch-right']
            for r in ([m[-1]] if m.startswith('alone-') else ['A','B']) for p in positions[r]}
        files={}
        for i,name in enumerate(sorted(names)):
            p=self.payload/('copied-%03d'%i);p.write_bytes(('fixture%d'%i).encode())
            files[self.receipt['output_dir']+'/'+name]={'path':p.name,'sha256':tool.sha(p),'size':p.stat().st_size}
        self.mapping={'request':{'task':'I04','backend':'GPU','outer_receipt':str(self.outer)},'files':files,
            'full_array_hashes_checked':286,'retained_array_count':0}
        self.save(self.map_path,self.mapping)
        self.result={'status':'i04_transport_export_completed','retained_array_count':0,'native_executions_started':0,
            'transport_allowed_by_actual_size':True,'archive':str(self.archive),'archive_bytes':self.archive.stat().st_size,
            'archive_sha256':tool.sha(self.archive),'logical_payload_bytes':1000,'source_map_sha256':tool.sha(self.map_path)}

    def save(self,p,d):
        if p.exists():p.unlink()
        tool.put(p,d)

    def verify(self):return tool.verify_result(self.result,self.mapping,self.map_path,self.outer,self.root)

    def test_preflight_frozen_tools_actual_app_and_same_clock_elapsed(self):
        self.assertEqual(tool.preflight(self.root,self.here)[-1],360)

    def test_actual_unmodified_terminal_byte_pin_required(self):
        self.controller['extra_unbound']=True;self.save(self.terminal,self.controller)
        with self.assertRaisesRegex(ValueError,'byte pins'):tool.preflight(self.root,self.here)

    def test_source_or_dirty_terminal_rejected(self):
        self.controller['remaining_descendants']=[123];self.save(self.terminal,self.controller)
        with self.assertRaisesRegex(ValueError,'terminal and cleaned'):tool.preflight(self.root,self.here)
        self.controller['remaining_descendants']=[];self.save(self.terminal,self.controller)
        self.launcher.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'launcher binding'):tool.preflight(self.root,self.here)

    def test_wrong_proof_inventory_and_strict_counts_rejected(self):
        for key,value in [('cpu_prerequisite_source_sha256','b'*64),('model_loads',True)]:
            old=self.receipt[key];self.receipt[key]=value;self.save(self.outer,self.receipt)
            with self.assertRaises(ValueError):tool.preflight(self.root,self.here)
            self.receipt[key]=old
        self.receipt['validation']['distribution_rows']=281;self.save(self.outer,self.receipt)
        with self.assertRaisesRegex(ValueError,'inventory'):tool.preflight(self.root,self.here)

    def test_wrong_app_and_native_timeout_rejected(self):
        for key,value in [('allocation_id','app-other'),('capture_seconds',1200)]:
            old=self.native_claim[key];self.native_claim[key]=value;self.save(self.claim/'claim.json',self.native_claim)
            with self.assertRaisesRegex(ValueError,'native claim'):tool.preflight(self.root,self.here)
            self.native_claim[key]=old

    def test_cumulative3000_and_timezone_requirements(self):
        self.controller['finished_utc']='2026-11-06T16:00:00+00:00';self.save(self.terminal,self.controller)
        with self.assertRaisesRegex(ValueError,'3000s'):tool.preflight(self.root,self.here)
        self.controller['finished_utc']='2026-11-06T15:06:00';self.save(self.terminal,self.controller)
        with self.assertRaisesRegex(ValueError,'UTC timestamps'):tool.preflight(self.root,self.here)

    def test_exact286_full_copied_and_fresh_hash(self):
        self.assertEqual(len(self.verify()),286)
        item=next(iter(self.mapping['files'].values()));(self.payload/item['path']).write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'copied array size/SHA'):self.verify()

    def test_retained_missing_and_escaping_payload_rejected(self):
        key=next(iter(self.mapping['files']));self.mapping['files'][key]['retained_at_source']=True
        with self.assertRaisesRegex(ValueError,'must not retain'):self.verify()
        self.mapping['files'][key].pop('retained_at_source');old=self.mapping['files'][key]['path'];self.mapping['files'][key]['path']='../escape'
        with self.assertRaisesRegex(ValueError,'relative path'):self.verify()
        self.mapping['files'][key]['path']=old;self.mapping['files'].pop(key)
        with self.assertRaisesRegex(ValueError,'inventory'):self.verify()

    def test_transport_caps_map_and_archive_bytes(self):
        for key,value in [('logical_payload_bytes',tool.LOGICAL_CAP+1),('archive_bytes',tool.ENCODED_CAP+1),('source_map_sha256','b'*64)]:
            old=self.result[key];self.result[key]=value
            with self.assertRaises(ValueError):self.verify()
            self.result[key]=old
        self.archive.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'size/SHA'):self.verify()

    def test_duplicate_json_and_permanent_task_claim(self):
        p=self.root/'metadata-export-once.json';tool.put(p,{'automatic_retry':False});before=p.read_bytes()
        with self.assertRaises(FileExistsError):tool.put(p,{'retry':True})
        self.assertEqual(p.read_bytes(),before)
        p.write_text('{"status":"completed","status":"failed"}')
        with self.assertRaisesRegex(ValueError,'duplicate JSON'):tool.read(p)


if __name__=='__main__':unittest.main()

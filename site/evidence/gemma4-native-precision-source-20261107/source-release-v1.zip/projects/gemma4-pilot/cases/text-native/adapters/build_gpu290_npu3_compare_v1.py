"""Build frozen comparison inputs from actual H100-2.9 and Ascend-v3 evidence.

Raw receipts and original POSIX paths are never rewritten. Copied files resolve
through each endpoint's source-map; only NPU NPY files may resolve at their
original paths, under an explicit retained root. Every row must be readable.
This one discovery request remains one input example across six serial captures.
"""
import argparse
import itertools
import json
import math
from pathlib import Path, PurePosixPath
import sys
import uuid

import numpy as np

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[4]
sys.path.insert(0,str(HERE.parent/'transfer'))
import summarize_npu_repeats_v3 as npu
import export_h100_torch290_evidence_v1 as gpu

require=npu.require
sha=npu.sha
put=npu.put
load=npu.load_json
canonical=npu.canonical
origin=npu.origin
child=npu.child
argument=npu.argument
VOCAB_SIZE=262144
ADAPTER='fixed-gpu290-npu3-v1'
IMPORT_PINS={
 'projects/gemma4-pilot/cases/text-native/adapters/summarize_npu_repeats_v3.py':'4fa327f5650656545180351cdf41486483b9769acaaa8fbf2a4b2cf3e0704fcc',
 'projects/gemma4-pilot/cases/text-native/transfer/export_h100_torch290_evidence_v1.py':'cf9a1cb13a7b022122e2c91b538875aefac2c53d5590e5c7d60bf72c12e2bafd',
 'projects/gemma4-pilot/cases/text-native/adapters/record_execution_v2.py':'d0dd1968ba05d5f7c58b97f054287b3ed478809d38743e45f2f4e42ab6e7d79b',
 'skills/precision-compare/scripts/artifact_io.py':'0260cd5ee1fd4e9d37e39bfd79efa9e663a1d48cb75b5adb31b84af9e1edbf39',
 'skills/precision-compare/scripts/compare_distributions.py':'6abc2eb0a741d554127911de9845d16e0d40f3f7759c42c172eae4907bbf8fc0',
 'skills/precision-compare/scripts/conditions.py':'e012c025395f2f0474f0b35074d8417ec5a217f3659f82218de0f5d05068036d',
 'skills/precision-compare/scripts/compare_target_scores.py':'084f1b80ea01ec29035fcfc0515bf82f0b619a98a94a70a847ef360f2ca900cc',
 'skills/precision-compare/scripts/score_metrics.py':'f645a0092bb97229380c5da6302316978324baf38579476f980bb63da2d6a7da',
 'skills/precision-compare/scripts/validate_artifacts.py':'1205fd42ba7fb4fe0b7fdc4c881d4b84993c599aa29db80a64f84f2abe484f52',
 'skills/precision-compare/scripts/compare_tensors.py':'0fb059a93a948bafd6f88013a6a8013fda9ca8a2ef8effd3e658f6b9c74efa6e',
}


def verify_tools():
    for name,digest in IMPORT_PINS.items():
        require(sha(REPO/name)==digest,'comparison import source changed: '+name)
        module=sys.modules.get(Path(name).stem)
        require(module is not None and Path(module.__file__).resolve()==REPO/name,
            'comparison module resolved outside pinned closure: '+name)
    require(Path(npu.__file__).resolve()==REPO/'projects/gemma4-pilot/cases/text-native/adapters/summarize_npu_repeats_v3.py' and
        Path(gpu.__file__).resolve()==REPO/'projects/gemma4-pilot/cases/text-native/transfer/export_h100_torch290_evidence_v1.py',
        'comparison helper import resolved outside pinned closure')


class Endpoint(npu.Sources):
    """Hash-checked map resolver; no fallback from a missing copied file."""
    def __init__(self,path,expected,retained_root=None):
        require(isinstance(expected,str) and npu.HEX64.fullmatch(expected),'frozen source-map SHA required')
        super().__init__(path)
        require(sha(self.manifest_path)==expected,'source-map hash differs')
        self.expected_sha=expected
        self.retained_root=Path(retained_root).resolve(strict=True) if retained_root is not None else None
        require(self.retained_root is None or self.retained_root.is_dir(),'retained root must be an existing directory')
        self.resolved={}

    def get(self,name,expected=None):
        name=origin(name); entry=self.files[name]
        require(isinstance(entry,dict) and isinstance(entry.get('sha256'),str) and npu.HEX64.fullmatch(entry['sha256']) and
            type(entry.get('size')) is int and entry['size']>=0,'invalid portable source entry')
        if entry.get('retained_at_source') is True:
            require(self.retained_root is not None and PurePosixPath(name).suffix=='.npy' and 'path' not in entry,
                'full rows unavailable: copied full GPU arrays or explicit NPU retained root required')
            path=Path(name)
            require(path.is_absolute() and path.is_relative_to(self.retained_root) and
                path.resolve(strict=True).is_relative_to(self.retained_root), 'retained array escapes explicit NPU root')
            path=path.resolve(strict=True)
        else:
            relative=entry.get('path')
            require(isinstance(relative,str) and relative and not Path(relative).is_absolute(), 'copied source path must be relative')
            path=(self.manifest_path.parent/relative).resolve(strict=True)
            require(path.is_relative_to(self.manifest_path.parent),'copied source escapes bundle')
        require(path.is_file() and path.stat().st_size==entry['size'],'mapped source size/type changed')
        actual=sha(path)
        require(actual==entry['sha256'] and (expected is None or actual==expected),'mapped source SHA differs: '+name)
        self.checked[name]=actual; self.resolved[name]=str(path)
        return path

    def json(self,name,expected=None):return load(self.get(name,expected))


def gpu_plan(endpoint,startup):
    capture=endpoint.json(child(startup,'capture-receipt.json'))
    require(capture.get('status')=='completed' and type(capture.get('returncode')) is int and capture['returncode']==0,
        'GPU startup did not complete')
    marker=origin(capture['marker'])
    require(marker==child(startup,'three-repeat.jsonl'),'GPU marker belongs to another startup')
    rows=[gpu.parse(line) for line in endpoint.get(marker).read_text(encoding='utf-8').splitlines()]
    require(all(isinstance(row,dict) for row in rows) and [r.get('event') for r in rows]==[
        'reserved','repeat_started','repeat_exited','repeat_started','repeat_exited','repeat_started','repeat_exited','completed'],
        'GPU marker must contain exactly three successful serial captures')
    require(rows[0].get('repeats')==3 and rows[0].get('input_sha256')==gpu.INPUT_SHA,'GPU marker input differs')
    runs=[]
    for rank in (1,2,3):
        began,ended=rows[2*rank-1:2*rank+1]
        require(type(began.get('rank')) is int and type(ended.get('rank')) is int and began['rank']==ended['rank']==rank and
            ended.get('status')=='completed' and type(ended.get('returncode')) is int and ended['returncode']==0,
            'GPU marker repeat rank or status differs')
        recorder=origin(began['receipt']); receipt=origin(ended['receipt']); output=origin(began['output'])
        require(receipt==child(recorder,'receipt.json') and npu.utc_time(began['utc'])<=npu.utc_time(ended['utc']),
            'GPU marker recorder path/time differs')
        runs.append({'rank':rank,'output':output,'receipt':receipt,'recorder':recorder})
    require(len({r['output'] for r in runs})==len({r['receipt'] for r in runs})==3 and
        canonical(rows[-1].get('results'))==canonical([{k:r[k] for k in ('rank','status','returncode','receipt')}
            for r in (rows[2],rows[4],rows[6])]),'GPU marker reused source or terminal inventory differs')
    return capture,runs


def gpu_binding(endpoint,startup,capture):
    allocation_name=child(startup,'allocation.json'); native_name=child(startup,'native-preflight.stdout')
    allocation=endpoint.json(allocation_name); native=endpoint.json(native_name)
    physical=allocation.get('physical_device_id')
    require(isinstance(physical,str) and str(uuid.UUID(physical))==physical and uuid.UUID(physical).int,
        'GPU physical UUID absent')
    require(allocation.get('vendor')=='NVIDIA' and type(allocation.get('visible_count')) is int and allocation['visible_count']==1 and
        type(allocation.get('logical_ordinal')) is int and allocation['logical_ordinal']==0 and
        native.get('status')=='native_preflight_passed' and native.get('runtime_uuid')==physical and
        type(native.get('visible_count')) is int and native['visible_count']==1 and
        type(native.get('logical_ordinal')) is int and native['logical_ordinal']==0 and native.get('bf16') is True and
        native.get('device_name')=='NVIDIA H100 80GB HBM3','GPU allocation/native mapping differs')
    for name in ('platform_source_sha256','native_source_sha256'):
        require(gpu.digest(allocation.get(name)),'GPU allocation source digest missing')
    platform_name=child(startup,'platform-allocation-source.json')
    platform=endpoint.json(platform_name,allocation['platform_source_sha256'])
    require(isinstance(platform.get('allocation_id'),str) and platform['allocation_id'] and
        platform['allocation_id']==allocation.get('allocation_id') and allocation.get('evidence_source')==platform_name and
        allocation.get('native_source')==native_name and sha(endpoint.get(native_name))==allocation['native_source_sha256'] and
        capture.get('allocation_sha256')==sha(endpoint.get(allocation_name)), 'GPU platform-to-native allocation hash chain differs')
    start=endpoint.json(child(startup,'start.json')); bootstrap=endpoint.json(child(startup,'bootstrap-receipt.json'))
    restore=endpoint.json(child(startup,'environment-restore.json'))
    require(bootstrap.get('status')=='native_preflight_passed' and
        bootstrap.get('allocation_source_sha256')==allocation['platform_source_sha256'] and
        start.get('source_sha256')==bootstrap.get('source_sha256')==gpu.WRAPPER_SHA and
        start.get('environment_archive_sha256')==bootstrap.get('environment_archive_sha256')==restore.get('archive_sha256')==gpu.ENV_ARCHIVE_SHA,
        'GPU bootstrap source/environment/allocation chain differs')
    return allocation


def gpu_run(endpoint,side,run,startup,allocation,input_name,document):
    out=run['output']; receipt=endpoint.json(run['receipt']); argv=receipt.get('argv')
    require(receipt.get('schema_version')==2 and receipt.get('backend')=='GPU' and receipt.get('status')=='completed' and
        type(receipt.get('returncode')) is int and receipt['returncode']==0 and receipt.get('capture_output')==out and
        receipt.get('input_path')==input_name and receipt.get('input_sha256')==gpu.INPUT_SHA and
        receipt.get('collector_sha256')==gpu.COLLECTOR_SHA,'GPU recorder identity/status differs')
    require(isinstance(argv,list) and len(argv)>3 and all(isinstance(x,str) and x for x in argv),'GPU collector argv missing')
    index=2 if argv[1]=='-B' else 1
    require(argv[index]==receipt.get('collector_path') and argument(argv,'--input')==input_name and argument(argv,'--output')==out and
        argument(argv,'--device')=='cuda:0' and argument(argv,'--allocation-receipt')==child(startup,'allocation.json'),
        'GPU executed input/output/device/allocation argv differs')
    dependencies=receipt['dependency_paths']; sources=receipt['source_sha256']
    require(isinstance(dependencies,list) and len(set(dependencies))==len(dependencies) and
        len({PurePosixPath(p).name for p in dependencies})==len(dependencies) and
        set(sources)=={receipt['collector_path'],input_name,*dependencies} and
        sources[receipt['collector_path']]==gpu.COLLECTOR_SHA and sources[input_name]==gpu.INPUT_SHA,'GPU frozen source closure differs')
    for name,digest in sources.items():
        require(gpu.digest(digest),'GPU frozen dependency digest invalid'); endpoint.get(name,digest)
    require({'inference_capture.py','artifact_io.py','compare_distributions.py','conditions.py','verify_snapshot.py',
        'pilot_gpu_peer_v2.py','upstream-identity.json','record_execution_v2.py','repeat_gpu_torch290_candidate.py'}<=
        {PurePosixPath(x).name for x in dependencies},'GPU required execution source absent')
    for name in ('allocation.json','platform-allocation-source.json','native-preflight.stdout','environment-restore.json','bootstrap-receipt.json'):
        require(child(startup,name) in dependencies,'GPU binding/startup source was not an executed dependency')
    wrappers=[x for x in dependencies if PurePosixPath(x).name=='launch_h100_torch290_repeat_v1-20261106.py']
    require(len(wrappers)==1 and sources[wrappers[0]]==gpu.WRAPPER_SHA,'GPU reviewed wrapper dependency differs')
    policy_name=argument(argv,'--numerics-policy')
    require(policy_name in dependencies and sources[policy_name]==gpu.POLICY_SHA,'GPU policy was not an executed frozen source')
    policy=endpoint.json(policy_name,gpu.POLICY_SHA)
    require(canonical(policy)==canonical(gpu.FROZEN_POLICY),'GPU frozen policy values differ')
    require(gpu.digest(receipt.get('status_sha256')),'GPU completion hash missing')
    status_path=endpoint.get(child(out,'status.json'),receipt['status_sha256']); status=load(status_path)
    require(status.get('status')=='completed' and type(status.get('rank')) is int and status['rank']==0,'GPU rank completion differs')
    native={}
    for name in ('runtime.json','math-policy-after-load.json','math-policy-after.json'):
        digest=receipt.get('native_evidence_sha256',{}).get(name)
        require(gpu.digest(digest),'GPU native evidence digest absent'); native[name]=endpoint.json(child(out,name),digest)
    runtime=native['runtime.json']
    fixed={'torch':'2.9.0+cu128','transformers':'5.10.1','cuda_runtime':'12.8','numpy':'1.26.4',
        'model_repository':'google/gemma-4-12B','requested_revision':npu.REVISION,'model_type':'gemma4_unified',
        'model_class':'Gemma4UnifiedForConditionalGeneration','input_sha256':gpu.INPUT_SHA,'device_argument':'cuda:0',
        'device_name':'NVIDIA H100 80GB HBM3','parameter_dtypes':['torch.bfloat16'],'requested_dtype':'bfloat16',
        'requested_attention':'eager','actual_attention':'eager','logprob_dtype':'float64','numerics_policy_sha256':gpu.POLICY_SHA}
    require(all(canonical(runtime.get(k))==canonical(v) for k,v in fixed.items()) and
        runtime.get('observed_config_commit') in (None,npu.REVISION),'GPU actual model/runtime conditions differ')
    rng=runtime.get('rng_and_math_policy',{})
    require(all(type(rng.get(k)) is int and rng[k]==0 for k in ('seed','python_random_seed','numpy_seed','torch_initial_seed','cuda_initial_seed')) and
        canonical(rng.get('settings'))==canonical(policy)==canonical(native['math-policy-after-load.json'])==canonical(native['math-policy-after.json']),
        'GPU actual policy or seed differs')
    require(runtime.get('device_uuid')==allocation['physical_device_id'] and
        runtime.get('allocation_receipt_sha256')==sha(endpoint.get(child(startup,'allocation.json'))),'GPU native UUID/allocation hash differs')
    require(gpu.digest(runtime.get('identity_receipt_sha256')),'GPU snapshot digest absent')
    snapshot=endpoint.json(child(out,'snapshot-verification.json'),runtime['identity_receipt_sha256'])
    metadata_name=next(x for x in dependencies if PurePosixPath(x).name=='upstream-identity.json')
    model=npu.snapshot_identity(snapshot,endpoint.json(metadata_name,npu.METADATA_SHA),runtime['model_class'])
    require(snapshot.get('upstream_metadata_sha256')==npu.METADATA_SHA,'GPU snapshot metadata pin differs')
    exported=endpoint.json(child(out,'exported-records.json')); events=endpoint.json(child(out,'events.json')); capture=endpoint.json(child(out,'capture-summary.json'))
    sample,prompt,targets=(document[k] for k in ('sample','prompt','continuation'))
    require(capture.get('native_logits_shapes')==[[1,128,VOCAB_SIZE]]+[[1,1,VOCAB_SIZE]]*31 and
        capture.get('sampled_distributions')==32 and not capture.get('unavailable_targets') and not exported.get('unavailable_targets') and
        len(events)==len(exported.get('positions',[]))==len(exported.get('scores',[]))==32,'GPU full-vocabulary capture coverage differs')
    require(len(receipt.get('row_sha256',[]))==len(receipt.get('record_sha256',[]))==32 and
        all(gpu.digest(x) for x in receipt['row_sha256']+receipt['record_sha256']),'GPU recorded row hash inventory differs')
    for suffix in ('.json','.npy'):
        require(endpoint.row_inventory(out,suffix)=={child(out,'row-%03d%s'%(i,suffix)) for i in range(32)},'GPU extra or missing raw row inventory')
    positions=[];scores=[];target_positions=[]
    for step,token in enumerate(targets):
        coordinate={'sample':sample,'position':127+step,'history':prompt+targets[:step]}
        record=endpoint.json(child(out,'row-%03d.json'%step),receipt['record_sha256'][step])
        expected={**coordinate,'step':step,'token':token,'rank':0,'boundary':'before_constraint','logits_dtype':'torch.bfloat16',
            'logprob_dtype':'float64','normalization':npu.NORMALIZATION,'scores':{'path':'row-%03d.npy'%step,'row':0}}
        require(all(k in record and canonical(record[k])==canonical(v) for k,v in expected.items()),'GPU row provenance/history differs')
        event={'stage':'prefill' if step==0 else 'decode','input_ids':prompt if step==0 else [targets[step-1]],
            'positions':list(range(128)) if step==0 else [127+step],'prefix_length':0 if step==0 else 127+step}
        require(canonical(events[step])==canonical(event),'GPU native history event differs')
        row_name=child(out,'row-%03d.npy'%step); observed=exported['positions'][step]; score=exported['scores'][step]
        require(all(canonical(observed.get(k))==canonical(v) for k,v in coordinate.items()) and
            canonical(observed.get('scores'))==canonical({'path':row_name,'row':0}),'GPU exported row mapping differs')
        target={'sample':sample,'position':128+step,'token':token}
        require(all(canonical(score.get(k))==canonical(v) for k,v in target.items()),'GPU target coordinate differs')
        path=endpoint.get(row_name,receipt['row_sha256'][step]); array=np.load(path,mmap_mode='r',allow_pickle=False)
        require(array.shape==(VOCAB_SIZE,) and array.dtype==np.dtype('float64') and np.isfinite(array).all(),'GPU full row shape/dtype/finiteness differs')
        value=record.get('logprob')
        require(type(value) in (int,float) and math.isfinite(value) and value<=0 and type(score.get('logprob')) in (int,float) and
            0<=token<VOCAB_SIZE and value==score['logprob']==float(array[token]),'GPU selected target differs from full row')
        del array
        positions.append({**coordinate,'scores':{'path':str(path),'row':0}})
        target_positions.append(target); scores.append({**target,'logprob':value})
    return {'side':side,'root':out,'receipt_source':run['receipt'],'receipt_sha256':sha(endpoint.get(run['receipt'])),
        'status_path':str(status_path),'model':model,'hardware':{'category':'GPU','model':runtime['device_name']},
        'software':{'framework':'torch',**{k:runtime[k] for k in ('torch','transformers','cuda_runtime','numpy')}},
        'backend_policy':policy,'runtime_uuid':runtime['device_uuid'],'vocab':VOCAB_SIZE,'positions':positions,
        'targets':target_positions,'scores':scores,'started_utc':receipt['started_utc'],'finished_utc':receipt['finished_utc']}


def prepare(gpu_map,gpu_sha,npu_map,npu_sha,npu_retained_root):
    verify_tools()
    ge=Endpoint(gpu_map,gpu_sha); ne=Endpoint(npu_map,npu_sha,npu_retained_root)
    gr=ge.document['request']; nr=ne.document['request']
    startup=origin(gr['startup']); capture,gpu_runs=gpu_plan(ge,startup); allocation=gpu_binding(ge,startup,capture)
    require(canonical(gr.get('runs'))==canonical(gpu_runs),'GPU map request differs from original marker')
    input_name=origin(gr['input']); document=ge.json(input_name,gpu.INPUT_SHA)
    require(gpu.INPUT_SHA==npu.INPUT_SHA and len(document.get('prompt',[]))==128 and len(document.get('continuation',[]))==32 and
        isinstance(document.get('sample'),str) and document['sample'] and
        all(type(x) is int and 0<=x<VOCAB_SIZE for x in document['prompt']+document['continuation']), 'fixed input identity or tokens differ')
    require(ne.json(nr['input'],npu.INPUT_SHA)==document,'GPU/NPU frozen input bytes differ')
    runs=[gpu_run(ge,'h100-r%d'%r['rank'],r,startup,allocation,input_name,document) for r in gpu_runs]
    npu_runs=nr['runs']
    require(isinstance(npu_runs,dict) and len(npu_runs)==3 and len(set(npu_runs.values()))==3,'three independent NPU capture roots required')
    runs.extend(npu.read_run('npu-r%d'%i,root,nr['input'],document,ne,nr['allocation'],nr['native_mapping'],nr['native_source'])
        for i,root in enumerate(npu_runs.values(),1))
    require(all(r['vocab']==VOCAB_SIZE and canonical(r['model'])==canonical(runs[0]['model']) and
        canonical(r['targets'])==canonical(runs[0]['targets']) for r in runs),'cross-backend model/vocabulary/target identity differs')
    for group in (runs[:3],runs[3:]):
        signature=lambda r:canonical({k:r[k] for k in ('model','hardware','software','backend_policy','runtime_uuid','vocab','targets')})
        require(all(signature(r)==signature(group[0]) for r in group),'within-backend repeated conditions differ')
        require(all(npu.utc_time(r['started_utc'])<npu.utc_time(r['finished_utc']) for r in group) and
            all(npu.utc_time(a['finished_utc'])<=npu.utc_time(b['started_utc']) for a,b in zip(group,group[1:])), 'serial capture intervals overlap')
    rows=[p['scores']['path'] for r in runs for p in r['positions']]
    require(len(rows)==len(set(rows))==192,'full rows reused across captures/endpoints')
    receipts=[str(endpoint.get(r['receipt_source'])) for endpoint,group in ((ge,runs[:3]),(ne,runs[3:])) for r in group]
    require(len(set(receipts))==6,'recorder receipt bytes/path reused across captures')
    numerics={'parameter_dtypes':['torch.bfloat16'],'attention':'eager','native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64',
        'seed':0,'cache':True,'parallelism':'tp1','normalization':npu.NORMALIZATION}
    common={'model':runs[0]['model'],'inputs':{'sha256':gpu.INPUT_SHA},'numerics':numerics,
        'scope':'one fixed 128-prompt + 32-target text discovery request; three serial captures per backend'}
    base={'schema_version':1,'common':common,'expected_ranks':{r['side']:[0] for r in runs},
        'side_conditions':{r['side']:{k:r[k] for k in ('hardware','software','backend_policy')} for r in runs},'thresholds':None}
    documents={'target-contract.json':{**base,'kind':'target-scores','targets':runs[0]['targets']},
        'distribution-contract.json':{**base,'schema_version':2,'kind':'distributions','vocab_size':VOCAB_SIZE,
            'normalization_tolerance':1e-5,'renormalization':'none','positions':[{k:p[k] for k in ('sample','position','history')} for p in runs[0]['positions']]}}
    for r in runs:
        side=r['side']; env=side+'-environment.json'
        documents[env]={'rank':0,'versions':r['software'],'actual':{**common,**base['side_conditions'][side]}}
        manifest={'common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':env,'status':r['status_path']}]}
        documents[side+'-targets.json']={**manifest,'schema_version':1,'kind':'target-scores','scores':r['scores']}
        documents[side+'-distributions.json']={**manifest,'schema_version':2,'kind':'distributions','positions':r['positions']}
    checked={'scope':{'fixed_input_examples':1,'captures_per_backend':3,'target_positions_per_capture':32,'full_vocabulary':VOCAB_SIZE,
        'full_rows_checked_per_backend':96,'cross_pairs_share_the_same_input':True},'acceptance':None,
        'runs':[{k:r[k] for k in ('side','root','receipt_source','receipt_sha256','runtime_uuid','started_utc','finished_utc')} for r in runs],
        'resolved_sources':{'GPU':{k:{'path':ge.resolved[k],'sha256':v} for k,v in sorted(ge.checked.items())},
            'NPU':{k:{'path':ne.resolved[k],'sha256':v} for k,v in sorted(ne.checked.items())}}}
    documents['checked-sources.json']=checked
    return documents,checked


def build(gpu_map,gpu_sha,npu_map,npu_sha,npu_retained_root,output):
    output=Path(output).resolve()
    require(not output.exists() and output.parent.is_dir(),'new comparison output directory required')
    documents,checked=prepare(gpu_map,gpu_sha,npu_map,npu_sha,npu_retained_root)
    output.mkdir()
    for name,doc in documents.items():put(output/name,doc)
    sources={'gpu_map':{'path':str(Path(gpu_map).resolve(strict=True)),'sha256':gpu_sha},
        'npu_map':{'path':str(Path(npu_map).resolve(strict=True)),'sha256':npu_sha},
        'npu_retained_root':str(Path(npu_retained_root).resolve(strict=True))}
    admission={'schema_version':1,'adapter':ADAPTER,'sources':sources,'toolchain':IMPORT_PINS,'acceptance':None,
        'scope':checked['scope'],'documents':{name:{'path':name,'sha256':sha(output/name)} for name in documents}}
    put(output/'admission.json',admission)
    return {'admission':str(output/'admission.json'),'admission_sha256':sha(output/'admission.json'),'acceptance':None,
        'scope':checked['scope'],'next':'Run admit_gpu290_npu3_v1.py with this independently frozen admission SHA and a new output file.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('gpu-source-map','npu-source-map','npu-retained-root','output-dir'):parser.add_argument('--'+name,required=True,type=Path)
    for name in ('gpu-map-sha256','npu-map-sha256'):parser.add_argument('--'+name,required=True)
    a=parser.parse_args()
    try:print(json.dumps(build(a.gpu_source_map,a.gpu_map_sha256,a.npu_source_map,a.npu_map_sha256,a.npu_retained_root,a.output_dir)))
    except (OSError,ValueError,KeyError,TypeError,IndexError) as exc:parser.exit(2,type(exc).__name__+': '+str(exc)+'\n')


if __name__=='__main__':main()

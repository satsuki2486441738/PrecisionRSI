"""Small independent E02 regressions; all binary tensors here are synthetic."""
import ast
import copy
import hashlib
import json
import math
from pathlib import Path
import struct
import tempfile
import unittest

import verify_observer_gpu_e02_v1 as m


def sf(path, tensors, metadata=None, trailing=b''):
    header = {}; payload = b''
    for key, (shape, words) in tensors.items():
        raw = struct.pack('<' + 'H' * len(words), *words)
        header[key] = {'dtype': 'BF16', 'shape': shape, 'data_offsets': [len(payload), len(payload) + len(raw)]}; payload += raw
    if metadata is not None: header['__metadata__'] = metadata
    raw = json.dumps(header, separators=(',', ':')).encode(); raw += b' ' * ((-len(raw)) % 8)
    path.write_bytes(struct.pack('<Q', len(raw)) + raw + payload + trailing)


class Payload(unittest.TestCase):
    def test_headers_change_whole_file_SHA_but_payload_identity_is_actual_and_framed(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); x, y = root / 'a.safetensors', root / 'b.safetensors'
            tensors = {'logits': ([1, 2, 2], [0x3f80, 0x4000, 0xbf80, 0])}
            sf(x, tensors, {'mode': 'off-before'}); sf(y, tensors, {'mode': 'hooks-only', 'different': 'header'})
            a, b = [m.tensor_payload(p, {'logits': [1, 2, 2]}) for p in (x, y)]
            self.assertNotEqual(a['source']['sha256'], b['source']['sha256'])
            result = m.same_payloads({'a': a, 'b': b}); self.assertTrue(result['all_equal']); self.assertTrue(result['physical_data_payloads_equal'])
            self.assertEqual(a['BF16_values'], 4); self.assertTrue(result['numeric_zero_was_not_used_as_bit_equality_evidence'])

    def test_signed_zero_bits_and_named_tensor_framing_prevent_false_identity(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); x, y = root / 'a.safetensors', root / 'b.safetensors'
            sf(x, {'x': ([1, 2], [0, 0])}); sf(y, {'x': ([1, 2], [0x8000, 0])})
            a, b = [m.tensor_payload(p, {'x': [1, 2]}) for p in (x, y)]
            self.assertEqual(m.base.native_values(x, 'x', 0, 2), m.base.native_values(y, 'x', 0, 2))
            self.assertFalse(m.same_payloads({'a': a, 'b': b})['all_equal'])
            sf(y, {'y': ([1, 2], [0, 0])})
            b = m.tensor_payload(y, {'y': [1, 2]})
            self.assertEqual(a['physical_data_payload_sha256'], b['physical_data_payload_sha256'])
            self.assertNotEqual(a['canonical_framed_sha256'], b['canonical_framed_sha256'])

    def test_geometry_dtype_offsets_and_trailing_bytes_are_not_ignored(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / 'a.safetensors'; sf(p, {'logits': ([1, 2], [0, 0])})
            with self.assertRaises(ValueError): m.tensor_payload(p, {'logits': [2, 1]})
            sf(p, {'logits': ([1, 2], [0, 0])}, trailing=b'x')
            with self.assertRaises(ValueError): m.tensor_payload(p, {'logits': [1, 2]})
            raw = p.read_bytes().replace(b'BF16', b'FP32'); p.write_bytes(raw)
            with self.assertRaises(ValueError): m.tensor_payload(p, {'logits': [1, 2]})


class Arithmetic(unittest.TestCase):
    def test_target_reductions_have_nonzero_signal_and_preserve159_coordinates(self):
        coords = [{'sample': 'synthetic', 'position': i + 1, 'token': i % 2} for i in range(159)]
        a = [-1.0] * 159; b = a[:]; b[75] = -2.5
        result = m.base.target_metrics(a, b, coords)
        self.assertEqual(result['target_count'], 159); self.assertEqual(result['max_coordinate'], coords[75])
        self.assertEqual(result['max_abs_nat'], 1.5); self.assertAlmostEqual(result['mae_nat'], 1.5 / 159)
        self.assertAlmostEqual(result['side_b_nll_nat_per_token'], 1 + 1.5 / 159)
        with self.assertRaises(ValueError): m.base.target_metrics(a[:-1], b[:-1], coords[:-1])

    def test_nonzero_fullV_distribution_independent_metrics_and_corruption_rejection(self):
        a = m.base.independent_logprobs([float(i % 17) / 10 for i in range(128)])
        b = m.base.independent_logprobs([float(i % 19) / 11 for i in range(128)])
        actual = m.base.distribution_metrics(a, b)
        self.assertGreater(actual['tail_merged_js'], 0); self.assertGreater(actual['probability_rmse'], 0)
        shared = copy.deepcopy(actual); shared['tail_merged_js'] = {'value': actual['tail_merged_js'], 'status': 'no_thresholds'}
        m.compare_distribution(actual, shared)
        for key in ('max_probability_error', 'top100_overlap'):
            bad = copy.deepcopy(shared); bad[key] += .01
            with self.assertRaises(ValueError): m.compare_distribution(actual, bad)
        bad = copy.deepcopy(shared); bad['coverage']['side_a_union'] = .1
        with self.assertRaises(ValueError): m.compare_distribution(actual, bad)

    def test_nonzero_tensor_and_global_concatenated_index_zero_norm(self):
        result = m.base.tensor_metrics([1., 2., 3.], [1., 4., 3.])
        self.assertEqual(result['max_flat_index'], 1); self.assertEqual(result['max_abs'], 2.)
        self.assertAlmostEqual(result['rmse'], math.sqrt(4 / 3))
        self.assertAlmostEqual(result['side_a_norm'], math.sqrt(14))
        self.assertIsNone(m.base.tensor_metrics([0., 0.], [0., 0.])['cosine'])


class Protocol(unittest.TestCase):
    def test_actual_reused_import_map_is_distinct_from_original_CLI_map_but_same_bytes(self):
        spec = m.parse((Path(m.__file__).parent / 'observer_gpu_only_e02_spec_v1.json').read_bytes())
        controller = m.parse(m.case_path(spec['objects']['controller']['case_path']).read_bytes())
        supplied = controller['argv'][controller['argv'].index('--source-map') + 1]
        self.assertFalse(supplied.endswith('/' + spec['objects']['source_map']['case_path']))
        self.assertTrue(supplied.endswith('/' + spec['objects']['original_input_source_map']['case_path']))
        self.assertEqual(spec['objects']['source_map']['sha256'], spec['objects']['original_input_source_map']['sha256'])
        for key in ('source_map', 'original_input_source_map'):
            self.assertEqual(m.sha(m.case_path(spec['objects'][key]['case_path'])), spec['objects'][key]['sha256'])

    def test_frozen_actual_selection_has6pairs282rows98tensors194pool_and_rejects_omission(self):
        spec = m.parse((Path(m.__file__).parent / 'observer_gpu_only_e02_spec_v1.json').read_bytes()); m.validate_spec(spec)
        for key in ('pair_modes', 'distribution_positions', 'sample_boundaries'):
            bad = copy.deepcopy(spec); bad[key].pop()
            with self.assertRaises(ValueError): m.validate_spec(bad)
        bad = copy.deepcopy(spec); bad['scope']['large_sources'] = 193
        with self.assertRaises(ValueError): m.validate_spec(bad)

    def test_source_does_not_call_original_comparators_or_framework_API(self):
        tree = ast.parse(Path(m.__file__).read_text(encoding='utf8'))
        imported = [node.module for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)]
        imported += [alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names]
        self.assertFalse(any(name and name.split('.')[0] in ('torch', 'torch_npu', 'transformers', 'compare_tensors',
            'compare_distributions', 'score_metrics') for name in imported))
        source = Path(m.__file__).read_text(encoding='utf8')
        self.assertIn('base.distribution_metrics', source); self.assertIn('base.tensor_metrics', source)
        self.assertIn('force=True', source)

    def test_existing_noncanonical_output_refused_before_any_original_array(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / 'old-run'; p.mkdir(); (p / 'sentinel').write_bytes(b'preserve')
            with self.assertRaises(ValueError): m.verify('/absent', 'a' * 64, p)
            self.assertEqual((p / 'sentinel').read_bytes(), b'preserve')


if __name__ == '__main__': unittest.main()

"""Independent expected-v2 regressions, using the frozen48 input bytes only."""
import copy
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import reserved48_expected_v1 as old
import reserved48_expected_v2 as expected
import reserved48_common_v2 as capture

HERE=Path(__file__).resolve().parent
INPUTS=HERE.parent/'inputs/reserved-articles-v1'


class Expected(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.doc=expected.derive(INPUTS/'reserved.json',INPUTS,'a'*64)

    def test_v2_retains_every_original_numeric_coordinate_and_scope(self):
        prior=old.derive(INPUTS/'reserved.json',INPUTS,'a'*64);candidate=copy.deepcopy(self.doc)
        candidate['schema_version']=1;candidate['kind']='reserved48-independent-expected-inventory'
        candidate.pop('native_capture_schema_version');candidate.pop('native_progress')
        self.assertEqual(candidate,prior)
        self.assertEqual(self.doc['counts']['pairs_total'],432);self.assertEqual(self.doc['counts']['distribution_pair_positions'],20304)
        self.assertEqual(self.doc['counts']['all_target_scores_per_backend'],396144)

    def test_independent_progress_plan_matches_capture_side_without_importing_a_framework(self):
        collector_rows=capture.inventory(INPUTS/'reserved.json',INPUTS)
        with tempfile.TemporaryDirectory() as td:
            for P in expected.BINS:
                rows=[r for r in collector_rows if r['P']==P]
                progress=capture.Progress(Path(td)/('p%d.jsonl'%P),rows,'gpu')
                planned=self.doc['native_progress']['per_prompt_bin'][str(P)]
                self.assertEqual(progress.plan,planned['planned_cells']);self.assertEqual(sum(len(x['spans']) for x in progress.plan),816)
                progress.fail(RuntimeError('synthetic metadata test end, no model'))
                result=capture.validate_progress(progress.path,rows);self.assertEqual(result['not_entered_cells'],36)
        self.assertFalse(any(x in sys.modules for x in ('torch','torch_npu','numpy','transformers')))

    def test_longest_bin_is_not_silently_truncated_or_repartitioned(self):
        rows=[x for x in self.doc['samples'] if x['prompt_length']==8192];self.assertEqual(len(rows),12)
        for row in rows:
            self.assertEqual(row['sequence_length'],8224);self.assertEqual(len(row['all_target_positions']),8223)
            self.assertEqual(row['distribution_positions'][-1],8222);self.assertEqual(row['unscored_finite_native_prediction_positions'],[8223])
            self.assertEqual([x['native_calls'] for x in row['modes']],[1,33,34])
            self.assertEqual(row['modes'][2]['input_spans_zero_based_half_open'][:2],[[0,4095],[4095,8192]])
            self.assertTrue(all('ones' in x['attention_mask_rule'] for x in row['modes']))

    def test_build_remains_unready_before_file_access_and_original_source_unchanged(self):
        self.assertIsNone(expected.STAGE_SHA256)
        with patch.object(Path,'open',side_effect=AssertionError('unready file IO')):
            with self.assertRaisesRegex(ValueError,'unready'):expected.build('absent','absent','absent','absent','0'*64)
        self.assertEqual(old.sha(HERE/'reserved48_expected_v1.py'),'ad229e986bab26fb697ab58120d63b948123c3ad52a1a51383a09495e719c05e')
        self.assertFalse(self.doc['native_progress']['native_execution_allowed_by_inventory'])


if __name__=='__main__':unittest.main()

"""OFFLINE v2 progress-aligned draft: one new H100 app and one reserved48 twelve-input bin.

No old claim/app is reused. The source-contract pin is intentionally None, so
neither direct workers nor normal entry can restore/query/claim/run a model.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import shutil
import tarfile
import uuid

CONTRACT_SHA = None
IO_SHA = '34b00c57a2fb08e3ded9332a1e4dae760791d9a9b261983dd3809909d58caafc'
RESTORE_SHA = '5b8aecafd569999aebe5c369edacd9f054980bee3f75748a85189cae7690a06e'


def contract():
    if not isinstance(CONTRACT_SHA, str): raise ValueError('reserved48 GPU lifecycle contract remains unready')
    path = Path(__file__).with_name('reserved48_stage_contract_v3.py')
    import hashlib
    if hashlib.sha256(path.read_bytes()).hexdigest() != CONTRACT_SHA: raise ValueError('stage-contract source changed')
    spec = importlib.util.spec_from_file_location('_reserved48_GPU_contract', path); module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    module.ready(); return module


def clean_environment():
    env = dict(os.environ)
    for key in ('PYTHONHOME','PYTHONPATH','CUBLAS_WORKSPACE_CONFIG'): env.pop(key, None)
    env.update(PYTHONHASHSEED='0', PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1', TORCH_DEVICE_BACKEND_AUTOLOAD='0',
        HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    return env


def prepare(c, context, claim):
    d = context['document']; source = context['source']; root = context['root']
    io = c.load_module(source/d['gpu_io_relative_path'], IO_SHA, '_reserved48_reused_GPU_io')
    restore = c.load_module(source/d['gpu_restore_relative_path'], RESTORE_SHA, '_reserved48_reused_GPU_restore')
    memory = restore.memory(); c.require(memory['effective_available_bytes'] >= 40*c.GIB, 'GPU effective host/cgroup40GiB guard')
    c.put(claim/'memory-guard.json', memory)
    guard=c.file_ref(memory['guard_source']);c.require(guard['sha256']==memory['guard_sha256'],'actual reused memory observer changed')
    copied=claim/'frozen-bootstrap'/Path(guard['path']).name;copied.parent.mkdir()
    with copied.open('xb') as f:f.write(Path(guard['path']).read_bytes())
    c.put(claim/'frozen-bootstrap-map.json',{guard['path']:c.file_ref(copied)})
    driver = subprocess.run(['nvidia-smi','--query-gpu=uuid,name,driver_version','--format=csv,noheader'], capture_output=True, timeout=20)
    for name, raw in (('driver.stdout',driver.stdout),('driver.stderr',driver.stderr)):
        with (claim/name).open('xb') as f: f.write(raw)
    c.require(driver.returncode == 0, 'driver query failed; this bin claim stays spent')
    rows = []
    for line in driver.stdout.decode('utf8').splitlines():
        fields = [x.strip() for x in line.split(',')]; c.require(len(fields) == 3, 'native driver columns differ')
        physical = str(uuid.UUID(fields[0].removeprefix('GPU-'))); c.require(uuid.UUID(physical).int and fields[1] and fields[2], 'native driver identity missing')
        rows.append({'uuid':physical,'name':fields[1],'driver_version':fields[2]})
    c.put(claim/'driver-receipt.json', {'status':'observed','returncode':driver.returncode,'rows':rows,
        'stdout_sha256':c.sha(claim/'driver.stdout'),'stderr_sha256':c.sha(claim/'driver.stderr'),'observed_utc':c.utc()})
    # Reviewed restore verifies the unchanged archive and actual restore volume;
    # its work is a descendant of the finite outer controller.
    c.require(c.sha(restore.ENV_ARCHIVE)==restore.ENV_ARCHIVE_SHA,'reviewed environment archive changed')
    with tarfile.open(restore.ENV_ARCHIVE) as archive: expanded=sum(x.size for x in archive if x.isfile())
    restore_parent=Path(restore.RUNTIME_PARENT)
    c.require(shutil.disk_usage(restore_parent).free>=expanded+512*1024**2+2*c.GIB,'actual restore volume lacks expanded env+512MiB scratch+2GiB headroom')
    c.put(claim/'environment-volume-guard.json',{'archive_sha256':restore.ENV_ARCHIVE_SHA,'expanded_regular_bytes':expanded,
        'restore_volume':str(restore_parent),'required_available_bytes':expanded+512*1024**2+2*c.GIB,'observed_available_bytes':shutil.disk_usage(restore_parent).free})
    python = restore.restore_environment(claim)
    probe = subprocess.run([str(python),'-B','-c',io.native_probe_code(),str(source/c.CASE/'adapters')],
        env=clean_environment(),capture_output=True,timeout=120)
    for name, raw in (('native-preflight.stdout',probe.stdout),('native-preflight.stderr',probe.stderr)):
        with (claim/name).open('xb') as f: f.write(raw)
    c.require(probe.returncode == 0, 'fresh H100 preflight failed')
    observed = json.loads(probe.stdout); physical = observed['runtime_uuid']
    c.require(observed['status'] == 'native_preflight_passed' and observed['visible_count'] == 1 and
        observed['device_name'] == 'NVIDIA H100 80GB HBM3' and
        sum(x['uuid'] == physical and x['name'] == observed['device_name'] for x in rows) == 1,
        'fresh visible H100 and raw-driver UUID disagree')
    restored = Path(c.read(claim/'environment-restore.json')['restored']).resolve()
    c.require(all(Path(path).resolve().is_relative_to(restored) for path in observed['module_files'].values()), 'probe imported outside new restored environment')
    process = subprocess.run(['nvidia-smi','--query-compute-apps=pid,gpu_uuid','--format=csv,noheader'],capture_output=True,timeout=20)
    for name, raw in (('process.stdout',process.stdout),('process.stderr',process.stderr)):
        with (claim/name).open('xb') as f: f.write(raw)
    c.require(process.returncode == 0, 'GPU compute-process observation failed')
    for line in process.stdout.decode('utf8').splitlines():
        fields = [x.strip() for x in line.split(',')]; c.require(len(fields) == 2 and fields[0].isdigit(), 'unknown GPU process row fails closed')
        c.require(str(uuid.UUID(fields[1].removeprefix('GPU-'))) != physical, 'selected H100 is busy; no model or unrelated stop')
    packages = {name:c.file_ref(path) for name,path in observed['module_files'].items()}
    frozen_packages = io.freeze_runtime_refs(claim, packages); c.put(claim/'runtime-packages-before.json',frozen_packages)
    allocation = {'vendor':'NVIDIA','visible_count':1,'logical_ordinal':0,'physical_device_id':physical,
        'allocation_id':context['platform']['allocation_id'],'evidence_source':d['allocation_source']['path'],
        'platform_source_sha256':d['allocation_source']['sha256'],'native_source':str(claim/'native-preflight.stdout'),
        'native_source_sha256':c.sha(claim/'native-preflight.stdout')}
    c.put(claim/'allocation.json',allocation)
    dynamic = [p for p in claim.rglob('*') if p.is_file() and p.name not in ('worker.stdout','worker.stderr') and not p.name.endswith(('.tar','.gz','.whl'))]
    dynamic.append(Path(guard['path']))
    return python, claim/'allocation.json', dynamic


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--config',type=Path,required=True);p.add_argument('--config-sha256',required=True)
    p.add_argument('--prompt-bin',type=int,choices=(128,512,2048,8192),required=True)
    p.add_argument('--internal-worker',action='store_true');p.add_argument('--claim',type=Path);args=p.parse_args()
    c=contract()
    with c.entry_deadline(args.prompt_bin):
        context=c.source_context(args.config,args.config_sha256,'GPU');c.require(context['bin']==args.prompt_bin,'CLI/prepared bin mismatch')
        c.require(c.sha(__file__)==context['document']['reviewed_source_sha256']['lifecycle'],'actual new GPU lifecycle source differs')
        if args.internal_worker:
            c.require(args.claim is not None,'direct worker requires an existing claim');c.run_worker(context,args.claim,lambda ctx,claim:prepare(c,ctx,claim));return 0
        result=c.supervise(context,args.config,args.config_sha256,Path(__file__).resolve());print(json.dumps(result,indent=2));return result.get('returncode',0)


if __name__=='__main__':raise SystemExit(main())

"""Fresh-child gate regressions; never import Torch or call environment probes."""
import ast
import json
from pathlib import Path
import subprocess
import sys
import unittest

HERE = Path(__file__).resolve().parent


class NativeGateTests(unittest.TestCase):
    def run_child(self, source):
        return subprocess.run([sys.executable, '-S', '-B', '-c', source], cwd=HERE, text=True,
                              capture_output=True, timeout=20)

    def test_fresh_import_is_stdlib_only_and_all_gates_unready(self):
        result = self.run_child("import sys,json;import reserved48_native_v1 as n;import reserved48_common_v1 as c;"
            "assert all(v is None for v in c.GATES.values());"
            "assert not any(k in sys.modules for k in ('torch','torch_npu','numpy','transformers'));print('closed')")
        self.assertEqual(result.returncode, 0, result.stderr); self.assertEqual(result.stdout.strip(), 'closed')

    def test_both_backend_entries_refuse_before_paths_frameworks_or_hardware(self):
        for backend in ('gpu', 'npu'):
            source = """import sys
from pathlib import Path
from types import SimpleNamespace
import reserved48_native_v1 as n
args=SimpleNamespace(backend=%r,device=%r)
n.common.arguments=lambda:args
try:n.main()
except ValueError as error:
 assert 'remains unready' in str(error)
else:raise AssertionError('unready native executed')
assert not any(k in sys.modules for k in ('torch','torch_npu','numpy','transformers'))
assert not any(k in sys.modules for k in ('i03_common_v1','pilot_gpu_peer_v2','pilot_ascend_candidate_v3'))
print('blocked-before-allocation-model-import')
""" % (backend, 'cuda:0' if backend == 'gpu' else 'npu:0')
            result = self.run_child(source)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout.strip(), 'blocked-before-allocation-model-import')

    def test_individual_missing_gate_cannot_be_inferred(self):
        source = """from types import SimpleNamespace
import reserved48_common_v1 as c
original=dict(c.GATES)
for missing in original:
 c.GATES={k:('1'*64 if k.endswith('_sha256') else True) for k in original}
 c.GATES[missing]=None
 try:c.prepare(SimpleNamespace(),'never-accessed-entry.py')
 except ValueError as error:assert 'remains unready' in str(error)
 else:raise AssertionError(missing)
print('all seven missing gates refused')
"""
        result = self.run_child(source)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_cli_does_not_create_output_or_claim(self):
        argv = [sys.executable, '-S', '-B', str(HERE / 'reserved48_native_v1.py'), '--backend', 'gpu',
                '--device', 'cuda:0', '--prompt-bin', '8192']
        for name in ('model', 'manifest', 'input-dir', 'allocation-receipt', 'allocation-source', 'source-manifest',
                     'stage-spec', 'expected-inventory', 'prerequisite-helper', 'prerequisite', 'budget', 'launch-receipt', 'output'):
            argv += ['--' + name, 'never-created-reserved48-test/' + name]
        for name in ('allocation-source', 'source-manifest', 'stage-spec', 'expected-inventory', 'prerequisite-helper',
                     'prerequisite', 'budget', 'launch-receipt'):
            argv += ['--' + name + '-sha256', '1' * 64]
        result = subprocess.run(argv, cwd=HERE, text=True, capture_output=True, timeout=20)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('remains unready', result.stderr)
        self.assertFalse((HERE / 'never-created-reserved48-test').exists())

    def test_no_generation_or_performance_mode_in_public_cli(self):
        result = subprocess.run([sys.executable, '-S', '-B', str(HERE / 'reserved48_native_v1.py'), '--help'],
                                cwd=HERE, text=True, capture_output=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertNotIn('--generate', result.stdout); self.assertNotIn('--benchmark', result.stdout)
        tree = ast.parse((HERE / 'reserved48_native_v1.py').read_text(encoding='utf-8'))
        top = [node for node in tree.body if isinstance(node, (ast.Import, ast.ImportFrom))]
        self.assertFalse(any('torch' in ast.unparse(node) or 'numpy' in ast.unparse(node) for node in top))


if __name__ == '__main__': unittest.main()

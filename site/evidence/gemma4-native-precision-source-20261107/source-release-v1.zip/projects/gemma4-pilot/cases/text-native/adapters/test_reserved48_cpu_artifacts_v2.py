"""Independent schema2/partial-cohort CPU fixtures; none is native evidence."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import reserved48_cpu_artifacts_v2 as a
import derive_compare_reserved48_cpu_v2 as w

HERE = Path(__file__).resolve().parent


def rows(P=128):
    result = []
    for index in range(12):
        L = P + 32; split = P // 2 - 1
        plans = {'full': [[0, L]], 'token': [[0, P]] + [[p, p + 1] for p in range(P, L)],
                 'chunk': [[0, split], [split, P]] + [[p, p + 1] for p in range(P, L)]}
        result.append({'sample': 'synthetic-%d-%02d' % (P, index), 'prompt_length': P, 'sequence_length': L,
            'input_ids': [2] + [0] * (L - 1), 'input_sha256': '1' * 64,
            'distribution_positions': sorted(set(j * (P - 1) // 15 for j in range(16)) | set(range(P - 1, P + 31))),
            'modes': [{'mode': mode, 'input_spans_zero_based_half_open': plans[mode]} for mode in a.MODES]})
    return result


def pairs():
    result = [{'a_backend': 'GPU', 'a_mode': mode, 'b_backend': 'NPU', 'b_mode': mode} for mode in a.MODES]
    for side in ('GPU', 'NPU'):
        result += [{'a_backend': side, 'a_mode': x, 'b_backend': side, 'b_mode': y}
                   for x, y in (('full', 'token'), ('full', 'chunk'), ('token', 'chunk'))]
    return result


def progress_records(expected, backend='GPU', failure=False):
    """Build the protocol independently; no collector module is imported."""
    plan = a.progress_plan(expected); result = []
    states = [{'sample': x['sample'], 'mode': x['mode'], 'state': 'not_entered',
               'forward_attempts': 0, 'forward_returns': 0} for x in plan]
    def emit(kind, phase='environment_preflight', **values):
        result.append({'index': len(result), 'event': kind, 'utc': '2026-11-07T00:00:00+00:00',
            'elapsed_monotonic_seconds': len(result) / 1000, 'pid': 17, 'phase': phase, **values})
    emit('plan', schema_version=1, task=a.TASK, backend=backend.lower(), planned_cells=plan,
         planned_model_loads=1, native_execution_allowed_by_progress=False)
    for cell, state in zip(plan, states):
        identity = {key: cell[key] for key in ('sample', 'mode')}
        emit('mode_entered', 'mode_reset_and_state_checks', **identity); state['state'] = 'entered_no_forward_marker'
        for index, span in enumerate(cell['spans']):
            emit('forward_entered', 'native_model_forward_and_synchronize', **identity,
                 call_index=index, input_span=span, first_forward_of_cell=index == 0)
            state['forward_attempts'] += 1; state['state'] = 'forward_entered_return_unobserved'
            if failure:
                error = {'classification': 'runtime_message_mentions_OOM_type_unconfirmed', 'typed_torch_OOM': False,
                    'runtime_message_mentions_OOM': True, 'type': 'builtins.RuntimeError', 'message': 'synthetic OOM text',
                    'traceback': 'synthetic fixture traceback', 'active_cell_only_no_unstarted_cell_OOM_attribution': True,
                    'independent_device_allocation_query_performed': False}
                emit('terminal', status='source_capture_failed', error=error, cell_ledger=copy.deepcopy(states),
                     numerical_admission_performed=False, acceptance=None)
                return result
            emit('forward_returned', 'native_model_forward_and_synchronize', **identity,
                 call_index=index, device_synchronize_returned=True)
            state['forward_returns'] += 1; state['state'] = 'forward_returned_capture_incomplete'
        summary = {'path': '/synthetic/output/samples/' + cell['sample'] + '/' + cell['mode'] + '/capture-summary.json',
                   'sha256': 'a' * 64, 'size_bytes': 123}
        emit('mode_capture_completed', 'source_CPU_derivation_and_evidence', **identity, summary=summary)
        state['state'] = 'source_capture_completed_not_independent_admission'
    emit('terminal', status='source_capture_completed', cell_ledger=states, numerical_admission_performed=False,
         acceptance=None, model_loads_observed_by_entry=1)
    return result


def raw_records(records): return ('\n'.join(a.canonical(x) for x in records) + '\n').encode()


def coverage(status='unstarted'):
    return {side: {str(P): {'status': status, 'reason': 'synthetic external coverage declaration'} for P in a.BINS}
            for side in ('GPU', 'NPU')}


class Progress(unittest.TestCase):
    def test_independent_complete36_816_plan_and_source_summaries(self):
        result = a.inspect_progress(raw_records(progress_records(rows())), rows(), 'GPU')
        self.assertEqual(result['forward_attempts'], 816); self.assertEqual(result['forward_returns'], 816)
        self.assertEqual(result['not_entered_cells'], 0); self.assertEqual(len(result['summary_events']), 36)
        self.assertFalse(result['independent_numeric_admission'])

    def test_failure_preserves_active_cell_and35_unentered_without_OOM_attribution(self):
        raw = raw_records(progress_records(rows(), failure=True))
        result = a.inspect_progress(raw, rows(), 'GPU', False)
        self.assertEqual(result['forward_attempts'], 1); self.assertEqual(result['forward_returns'], 0)
        self.assertEqual(result['not_entered_cells'], 35)
        self.assertEqual(result['source_failure']['classification'], 'runtime_message_mentions_OOM_type_unconfirmed')
        with self.assertRaisesRegex(ValueError, 'failed progress'): a.inspect_progress(raw, rows(), 'GPU')

    def test_missing_terminal_truncation_duplicate_and_unknown_events_rejected(self):
        records = progress_records(rows()); variants = [records[:-1], records + [records[-1]]]
        wrong = copy.deepcopy(records); wrong[2]['event'] = 'unknown'; variants.append(wrong)
        wrong = copy.deepcopy(records); wrong[2]['call_index'] = 1; variants.append(wrong)
        wrong = copy.deepcopy(records); wrong[3]['device_synchronize_returned'] = False; variants.append(wrong)
        wrong = copy.deepcopy(records); wrong[-1]['cell_ledger'][0]['state'] = 'not_entered'; variants.append(wrong)
        for value in variants:
            with self.subTest(change=len(value)), self.assertRaises((ValueError, KeyError)): a.inspect_progress(raw_records(value), rows(), 'GPU')
        with self.assertRaises(ValueError): a.inspect_progress(raw_records(records)[:-1], rows(), 'GPU')
        raw = raw_records(records).replace(b'"index":0', b'"index":0,"index":0', 1)
        with self.assertRaisesRegex(ValueError, 'duplicate'): a.inspect_progress(raw, rows(), 'GPU')

    def test_NPU_known_driver_prefix_exact_raw_status_and_progress_binding(self):
        api = {'call': "torch_npu.utils.get_cann_version('DRIVER')", 'status': 'error', 'error_type': 'UnicodeDecodeError',
               'error': 'synthetic prior encoding failure', 'traceback': 'synthetic retained error trace'}
        event = {'event': 'driver_version_api_observation', 'observation': api}
        status = {'status': 'completed', 'synthetic': True}; progress = {'path': '/original/progress.jsonl', 'sha256': 'a' * 64, 'size_bytes': 42}
        final = dict(status, progress=progress); runtime = {'driver_version_provenance': {'api': api}}
        raw = raw_records([event, final]); result = a.inspect_native_stdout(raw, 'NPU', status, progress, runtime)
        self.assertEqual(result['record_count'], 2); self.assertFalse(result['raw_bytes_rewritten'])
        for bad in (raw_records([dict(event, event='unknown'), final]), raw_records([event, event, final]),
                    raw_records([event, dict(final, progress=dict(progress, sha256='b' * 64))])):
            with self.assertRaises(ValueError): a.inspect_native_stdout(bad, 'NPU', status, progress, runtime)
        with self.assertRaises(ValueError): a.inspect_native_stdout(raw, 'GPU', status, progress, runtime)
        with self.assertRaises(ValueError): a.inspect_native_stdout(raw, 'NPU', status, progress,
            {'driver_version_provenance': {'api': dict(api, error='different bytes')}})

    def test_failure_diagnostics_real_hashes_missing_terminal_is_unknown(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); controller = root / 'controller.json'; log = root / 'native-progress.jsonl'
            a.put(controller, {'task': 'RESERVED48', 'backend': 'GPU', 'prompt_bin': 128, 'status': 'failed', 'returncode': 1,
                               'timeout_observations': {'source_reported_timeout': None}})
            log.write_bytes(raw_records(progress_records(rows(), failure=True)))
            catalog = {'/original/controller.json': a.ref(controller), '/original/native-progress.jsonl': a.ref(log)}
            item = {'status': 'failed', 'reason': 'synthetic protocol test', 'failure_evidence': {'files': catalog,
                    'controller_source_path': '/original/controller.json', 'progress_source_path': '/original/native-progress.jsonl'}}
            pins = copy.deepcopy(a.ENDPOINT_PINS); pins['GPU']['128']['controller'] = a.sha(controller)
            with patch.object(a, 'ENDPOINT_PINS', pins):
                result = a.inspect_failure_evidence(a.Audit(30), item, rows(), 'GPU', 128)
                self.assertEqual(result['observed_not_entered_cells'], 35); self.assertFalse(result['unexecuted_cells_inferred'])
                log.write_bytes(raw_records(progress_records(rows(), failure=True))[:-5]); catalog['/original/native-progress.jsonl'] = a.ref(log)
                result = a.inspect_failure_evidence(a.Audit(30), item, rows(), 'GPU', 128)
                self.assertIsNone(result['cell_ledger']); self.assertIn('unknown', result['progress_status'])
                controller.write_bytes(controller.read_bytes() + b' ')
                with self.assertRaises(ValueError): a.inspect_failure_evidence(a.Audit(30), item, rows(), 'GPU', 128)


class ClosedAndNumerical(unittest.TestCase):
    def test_all_actual_gates_None_before_file_output_framework_IO(self):
        self.assertTrue(all(value is None for value in a.GATES.values()))
        self.assertTrue(all(value is None for side in a.SOURCE_PINS.values() for value in side.values()))
        self.assertTrue(all(value is None for side in a.ENDPOINT_PINS.values() for P in side.values() for value in P.values()))
        with patch.object(a, 'sha', side_effect=AssertionError('must refuse before IO')):
            with self.assertRaisesRegex(ValueError, 'unready'): a.request('/absent', 'a' * 64)
        with self.assertRaisesRegex(ValueError, 'unready'): a.endpoint_ready('GPU', 128)

    def test_frozen_v1_numerical_AST_unchanged_and_no_collector_validator_import(self):
        def functions(path): return {node.name: node for node in ast.parse(path.read_text(encoding='utf8')).body if isinstance(node, ast.FunctionDef)}
        for old, new, names in ((HERE / 'reserved48_cpu_artifacts_v1.py', HERE / 'reserved48_cpu_artifacts_v2.py',
                ('bf16_scalar', 'admit_source_scalars', 'selected_array', 'native_row_bytes', 'derive_selected', 'admit_cache_metadata', 'admit_observation')),
                (HERE / 'derive_compare_reserved48_cpu_v1.py', HERE / 'derive_compare_reserved48_cpu_v2.py',
                ('source_view', 'target_map', 'source_profile', 'write_rank', 'compare_pair'))):
            before, after = functions(old), functions(new)
            for name in names: self.assertEqual(ast.dump(before[name]), ast.dump(after[name]), name)
        source = (HERE / 'reserved48_cpu_artifacts_v2.py').read_text(encoding='utf8')
        self.assertNotIn('common.validate_progress', source); self.assertNotIn('import reserved48_common', source)

    def test_real_numpy_fullV_selected_BF16_to_new_FP64_32row_slabs(self):
        import test_reserved48_cpu_artifacts_v1 as fixture
        import numpy as np
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); row, targets, _, selection, _, native_rows = fixture.fixture(262144)
            native = root / 'selected-native-logits.safetensors'; fixture.save_bf16(native, row, native_rows, 262144)
            result = a.derive_selected(native, a.ref(native), row, selection, targets['scores'], root / 'new.npy', a.Audit(60))
            self.assertFalse(result['original_GPU_or_NPU_FP64_array']); self.assertFalse(result['independent_all_target_normalizers'])
            matrix = np.load(root / 'new.npy', mmap_mode='r', allow_pickle=False)
            try: self.assertEqual(matrix.shape, (47, 262144)); self.assertLess(float(np.max(np.abs(matrix + __import__('math').log(262144)))), 1e-12)
            finally: matrix._mmap.close()


class PartialCoverage(unittest.TestCase):
    def fixture(self, root, complete_sides=('GPU',), bin_count=4):
        inventory = {'task': a.TASK, 'manifest_sha256': a.MANIFEST_SHA,
                     'samples': [row for P in a.BINS for row in rows(P)], 'pairs_per_input': pairs()}
        request = {key: {'sha256': str(index) * 64} for index, key in enumerate(
            ('stage_spec', 'expected_inventory', 'budget', 'native_budget', 'cpu_prerequisite', 'native_prerequisite', 'manifest'), 1)}
        request['coverage'] = coverage(); request['source_maps'] = {'GPU': {}, 'NPU': {}}
        registry = {}; references = []
        def sealed(path, value):
            path = str(path); registry[path] = value
            return {'path': path, 'sha256': hashlib.sha256(a.canonical(value).encode()).hexdigest(), 'size_bytes': len(a.canonical(value))}
        for P in a.BINS[:bin_count]:
            folder = root / str(P); catalog = {}; reports = []
            for side in complete_sides:
                item = {'status': 'completed', 'reason': 'synthetic admitted endpoint', 'endpoint': {'synthetic': side + str(P)}}
                request['coverage'][side][str(P)] = item; request['source_maps'][side][str(P)] = item['endpoint']
            indices = w.available_pair_indices(inventory, complete_sides)
            for row in inventory['samples']:
                if row['prompt_length'] != P: continue
                for side in complete_sides:
                    for mode in a.MODES:
                        stem = folder / (side + row['sample'] + mode)
                        scalar = {'sample': row['sample'], 'scores': [{'sample': row['sample'], 'position': p,
                            'token': row['input_ids'][p], 'logprob': -1.0} for p in range(1, row['sequence_length'])]}
                        catalog['/'.join((side, row['sample'], mode))] = {'sample': row['sample'], 'backend': side, 'mode': mode,
                            'profile': {'backend': side, 'partition': mode, 'source_software': {'torch': 'synthetic'},
                                'source_backend_policy': {'frozen': True}, 'derivation': a.DERIVATION, 'normalization_location': 'new_common_CPU_artifact'},
                            'source_scalar_view': sealed(str(stem) + '-scores', scalar), 'derivation': sealed(str(stem) + '-derive', {})}
                for index in indices:
                    distribution = {'status': 'no_thresholds', 'position_count': 47,
                        'positions': [{'synthetic': True}] * 47, 'aggregate': {'synthetic': True}}
                    report = {'kind': 'reserved48_input_pair', 'task': a.TASK, 'sample': row['sample'], 'prompt_length': P,
                        'pair': inventory['pairs_per_input'][index], 'distribution': distribution, 'target_metrics': {},
                        'continuation_target_metrics': {}, 'acceptance': None, 'thresholds': None, 'native_executions_started': 0,
                        'independent_all_target_normalizers': False}
                    reports.append(sealed(folder / (row['sample'] + '-pair%d' % index), report))
            report = {'schema_version': 2, 'kind': 'reserved48_cpu_bin_report', 'task': a.TASK,
                'status': 'completed' if len(complete_sides) == 2 else 'completed_available_endpoints', 'prompt_bin': P,
                'bindings': w.common_bindings(request), 'coverage': {side: request['coverage'][side][str(P)] for side in ('GPU', 'NPU')},
                'available_backends': list(complete_sides), 'available_pair_indices': indices,
                'source_maps': {side: request['coverage'][side][str(P)]['endpoint'] for side in complete_sides},
                'input_count': 12, 'native_observations': 36 * len(complete_sides), 'planned_native_observations': 72,
                'planned_input_pairs': 108, 'input_pairs': 12 * len(indices), 'missing_input_pairs': 108 - 12 * len(indices),
                'distribution_pair_positions': 47 * 12 * len(indices), 'native_executions_started': 0,
                'independent_all_target_normalizers': False, 'full_unselected_raw_audit': False,
                'acceptance': None, 'thresholds': None, 'full_cohort_NLL': None, 'observations': catalog, 'input_pair_reports': reports}
            references.append(sealed(folder / 'bin-report.json', report))
        return request, inventory, registry, references

    def test_explicit48_432_inventory_and_available_pairs_never_substitute_failed_cells(self):
        inventory = {'pairs_per_input': pairs()}
        self.assertEqual(w.available_pair_indices(inventory, ('GPU',)), [3, 4, 5])
        self.assertEqual(w.available_pair_indices(inventory, ('NPU',)), [6, 7, 8])
        self.assertEqual(len(w.available_pair_indices(inventory, ('GPU', 'NPU'))), 9)
        request = {'coverage': coverage()}; a.check_coverage(request)
        request['coverage']['GPU']['128']['endpoint'] = {'one_successful_cell': True}
        with self.assertRaisesRegex(ValueError, 'substitute'): a.check_coverage(request)
        request['coverage']['GPU'].pop('8192')
        with self.assertRaisesRegex(ValueError, 'all48/432'): a.check_coverage(request)

    def test_GPU_full48_NLL_and3families_complete_while_NPU_pending(self):
        with tempfile.TemporaryDirectory() as td:
            request, inventory, registry, references = self.fixture(Path(td))
            def get(value, root=None, audit=None): return registry[value['path']]
            summarize = SimpleNamespace(summarize=lambda positions: {'synthetic_count': len(positions)})
            sys.path.insert(0, str(a.SCRIPTS)); import score_metrics
            with patch.object(w, 'pinned_json', side_effect=get), patch.object(a, 'libraries', return_value=(None,
                    {'score_metrics': score_metrics, 'compare_distributions': summarize})):
                reports, catalog, actual_pairs = w.sealed_available_bins(request, inventory, references)
                result = w.reduce_complete_families(request, inventory, catalog, actual_pairs, a.Audit(30))
            self.assertEqual(len(reports), 4); self.assertEqual(len(catalog), 144); self.assertEqual(len(actual_pairs), 144)
            self.assertTrue(result['per_backend']['GPU']['complete48']); self.assertFalse(result['per_backend']['NPU']['complete48'])
            self.assertIsNone(result['per_backend']['NPU']['all_mode_corpus_NLL'])
            self.assertEqual(result['per_backend']['GPU']['all_mode_corpus_NLL']['full']['target_count'], 132048)
            self.assertEqual(result['per_backend']['GPU']['all_mode_corpus_NLL']['full']['nll_nat_per_token'], 1.0)
            self.assertEqual(result['completed_48_input_pair_families'], 3)
            for index, item in enumerate(result['per_pair_family']):
                self.assertEqual(item['complete48'], index in (3, 4, 5))
                if index not in (3, 4, 5): self.assertIsNone(item['corpus'])

    def test_incomplete_gpu_bin_nulls_full48_NLL_and_missing_pairs_policy_alias_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            request, inventory, registry, references = self.fixture(Path(td), bin_count=3)
            def get(value, root=None, audit=None): return registry[value['path']]
            with patch.object(w, 'pinned_json', side_effect=get), patch.object(a, 'libraries', side_effect=AssertionError('no complete family math')):
                _, catalog, actual_pairs = w.sealed_available_bins(request, inventory, references)
                result = w.reduce_complete_families(request, inventory, catalog, actual_pairs, a.Audit(30))
                self.assertIsNone(result['per_backend']['GPU']['all_mode_corpus_NLL']); self.assertEqual(result['completed_48_input_pair_families'], 0)
                report = registry[references[0]['path']]; report['input_pair_reports'][-1] = report['input_pair_reports'][0]
                with self.assertRaisesRegex(ValueError, 'duplicated'): w.sealed_available_bins(request, inventory, references)
            request, inventory, registry, references = self.fixture(Path(td), bin_count=2)
            item = next(iter(registry[references[1]['path']]['observations'].values())); item['profile']['source_software']['torch'] = 'drift'
            with patch.object(w, 'pinned_json', side_effect=lambda value, root=None, audit=None: registry[value['path']]):
                with self.assertRaisesRegex(ValueError, 'policy drift'): w.sealed_available_bins(request, inventory, references)

    def test_actual_partial_aggregate_report_retains48_432_without_success_only_headline(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); request, inventory, registry, references = self.fixture(root, bin_count=3)
            budget = root / 'budget.json'; a.put(budget, {'synthetic': 'budget controller stub, not executed production caps'})
            request['budget'] = a.ref(budget); request['cpu_workspace_root'] = str(root)
            for value in references: registry[value['path']]['bindings'] = w.common_bindings(request)
            def fake_budget(output, *_):
                output = Path(output); output.mkdir()
                return SimpleNamespace(output=output, audit=a.Audit(60), tick=lambda: None, check_workspace=lambda: 0)
            with patch.object(w, 'pinned_json', side_effect=lambda value, root=None, audit=None: registry[value['path']]), \
                    patch.object(w, 'Budget', side_effect=fake_budget), patch.object(a, 'libraries', side_effect=AssertionError('no full48 family')):
                result = w.aggregate(request, inventory, references, root / 'partial')
            document = a.load(result['path'])
            self.assertEqual(document['planned_independent_articles'], 48); self.assertEqual(document['planned_input_pair_contrasts'], 432)
            self.assertEqual(document['actual_input_pair_contrasts'], 108); self.assertEqual(document['actual_new_common_CPU_FP64_matrices'], 108)
            self.assertIsNone(document['full_cohort_NLL']); self.assertIsNone(document['corpus']); self.assertFalse(document['success_only_headline'])
            self.assertFalse(document['full9pair_cohort_complete']); self.assertFalse(document['per_backend']['GPU']['complete48'])
            self.assertIsNone(document['per_backend']['GPU']['all_mode_corpus_NLL'])
            self.assertEqual(document['coverage']['GPU']['8192']['status'], 'unstarted')
            self.assertFalse(document['diagnostics']['GPU']['8192']['unexecuted_cells_inferred'])


class OriginalLinks(unittest.TestCase):
    """Real copied bytes for NEW link admission; old numeric admission is stubbed.

    The fixture is explicitly not a native endpoint. Mocking the separately
    tested v1-derived numerical admission isolates new outer/source/progress
    wiring and cannot be used by the production CLI or activate its None gates.
    """
    def fixture(self, root):
        base = '/synthetic/root'; output = base + '/runs/gpu-reserved48-p0128-20261107T000000Z/artifacts'
        claim = base + '/claims/app-synthetic'; files = {}; refs = {}; physical = {}
        def add(path, document=None, raw=None):
            if path not in physical:
                physical[path] = root / 'payload' / ('%04d' % len(physical)) / Path(path).name
                physical[path].parent.mkdir(parents=True)
            if raw is None: raw = (a.canonical(document) + '\n').encode()
            physical[path].write_bytes(raw); digest = hashlib.sha256(raw).hexdigest()
            files[path] = {'path': physical[path].relative_to(root).as_posix(), 'sha256': digest, 'size': len(raw)}
            refs[path] = {'path': path, 'sha256': digest, 'size_bytes': len(raw)}
            return refs[path]
        source_root = base + '/source'; source_pins = {}
        for key in ('collector', 'common', 'lifecycle', 'contract', 'expected'):
            source_pins[key] = add(source_root + '/' + key + '.py', raw=('# synthetic ' + key + '\n').encode())['sha256']
        stage = add(source_root + '/stage.json', {'synthetic': 'stage'})
        budget = add(source_root + '/budget.json', {'synthetic': 'budget'})
        expected = add(source_root + '/expected.json', {'synthetic': 'expected'})
        prerequisite = add(source_root + '/prerequisite.json', {'synthetic': 'prerequisite'})
        typed = {'schema_version': 1, 'task': a.TASK, 'files': {}, 'inventory': {}}
        for key in source_pins:
            name = key + '.py'; item = refs[source_root + '/' + name]
            typed['files'][name] = item['sha256']; typed['inventory'][name] = {
                'sha256': item['sha256'], 'size_bytes': item['size_bytes'], 'kind': 'code'}
        manifest_ref = add(base + '/source-manifest.json', typed)
        config = {'task': a.TASK, 'backend': 'GPU', 'prompt_bin': 128, 'model_loads': 1, 'native_launches': 1, 'automatic_retry': False,
            'source_root': source_root, 'reviewed_source_sha256': {key: source_pins[key] for key in ('collector', 'common', 'lifecycle')},
            'expected_builder': refs[source_root + '/expected.py'], 'stage_spec': stage, 'budget': budget,
            'expected_inventory': expected, 'prerequisite': prerequisite, 'source_manifest': manifest_ref}
        config_ref = add(base + '/prepared-config.json', config)
        platform = {'task': a.TASK, 'backend': 'GPU', 'prompt_bin': 128, 'allocation_id': 'app-synthetic',
            'prepared_config_sha256': config_ref['sha256'], 'stage_sha256': stage['sha256'], 'budget_sha256': budget['sha256'],
            'expected_inventory_sha256': expected['sha256'], 'native_prerequisite_sha256': prerequisite['sha256'],
            'lifecycle_sha256': source_pins['lifecycle']}
        platform_ref = add(base + '/platform-allocation-source.json', platform)
        allocation_ref = add(claim + '/allocation.json', {'allocation_id': 'app-synthetic'})
        claim_doc = {'task': a.TASK, 'backend': 'GPU', 'prompt_bin': 128, 'allocation_id': 'app-synthetic', 'config': config_ref,
            'allocation_source': platform_ref, 'permanent_claim': True, 'automatic_retry': False, 'native_launches': 1,
            'model_loads': 1, 'native_forward_calls': 816}
        add(claim + '/claim.json', claim_doc)
        frozen = {'synthetic/common': refs[source_root + '/common.py']}
        runtime_sources = {}
        packages = {'package/torch', 'package/numpy', 'package/transformers', 'implementation/modeling',
                    'implementation/cache_utils', 'implementation/masking_utils', 'implementation/safetensors_torch'}
        for index, key in enumerate(sorted(packages)):
            original = add('/synthetic/runtime/%02d.py' % index, raw=('# ' + key + '\n').encode())
            copied = add(output + '/runtime-sources/%02d.py' % index, raw=physical[original['path']].read_bytes())
            runtime_sources[key] = {'original': original, 'frozen_copy': copied}
        copied = add(output + '/runtime-sources/common.py', raw=physical[frozen['synthetic/common']['path']].read_bytes())
        runtime_sources['synthetic/common'] = {'original': frozen['synthetic/common'], 'frozen_copy': copied}
        add(output + '/runtime-source-map.json', runtime_sources); add(output + '/frozen-source-refs.json', frozen)
        source_hashes = {path: value['sha256'] for path, value in refs.items() if path.startswith(source_root + '/') or
                         path in (manifest_ref['path'], config_ref['path'], platform_ref['path'], claim + '/claim.json')}
        add(claim + '/sources-before.json', source_hashes); add(claim + '/sources-after.json', source_hashes)
        records = progress_records(rows()); products = {}; summaries = []
        for event in records:
            if event['event'] == 'mode_capture_completed':
                relative = 'samples/' + event['sample'] + '/' + event['mode'] + '/capture-summary.json'
                summary = {'sample': event['sample'], 'mode': event['mode'], 'synthetic': 'source link fixture'}
                item = add(output + '/' + relative, summary); event['summary'] = item; summaries.append(summary)
                products[relative] = {'sha256': item['sha256'], 'size_bytes': item['size_bytes']}
        progress_ref = add(claim + '/native-progress.jsonl', raw=raw_records(records))
        protocol = a.inspect_progress(physical[progress_ref['path']].read_bytes(), rows(), 'GPU')
        protocol = {key: value for key, value in protocol.items() if key not in ('summary_events', 'source_failure')}
        status = {'status': 'completed', 'synthetic': 'protocol only, not native evidence'}; add(output + '/status.json', status)
        runtime = {'allocation_receipt': allocation_ref, 'source_manifest': manifest_ref, 'expected_inventory': expected,
            'prerequisite': prerequisite, 'stage_spec': stage, 'budget': budget, 'runtime_sources': runtime_sources,
            'native_observations': summaries, 'model_identity': {'modeling_source': runtime_sources['implementation/modeling']['original']}}
        add(output + '/runtime.json', runtime); add(output + '/artifacts-manifest.json', {'files': products})
        generic_dir = base + '/runs/gpu-reserved48-p0128-20261107T000000Z/recorded'
        argv = ['/synthetic/python', '-B', source_root + '/collector.py', '--progress-path', progress_ref['path'],
            '--prerequisite', prerequisite['path'], '--prerequisite-sha256', prerequisite['sha256'],
            '--prerequisite-helper-sha256', source_pins['contract'], '--budget', budget['path'], '--budget-sha256', budget['sha256']]
        generic_ref = add(generic_dir + '/command.json', {'status': 'completed', 'returncode': 0, 'child_returncode': 0, 'argv': argv})
        add(claim + '/generic-receipt-reference.json', {'source': generic_ref, 'status': 'completed', 'returncode': 0,
            'child_returncode': 0, 'timeout_scope': 'original_generic_native_process_only'})
        stdout_ref = add(generic_dir + '/stdout.bin', raw=raw_records([dict(status, progress=progress_ref)]))
        outer = {'schema_version': 1, 'input_manifest_sha256': a.MANIFEST_SHA, 'native_capture_schema_version': 2, 'progress_schema_version': 1,
            'native_prerequisite_source_sha256': prerequisite['sha256'], 'thresholds': None, 'acceptance': None, 'full_core_complete': False,
            'generic_receipt': generic_ref, 'allocation_path': allocation_ref['path'], 'allocation_sha256': allocation_ref['sha256'],
            'source_sha256': source_hashes, 'argv': argv,
            'native_progress': {'status': 'source_capture_completed', 'source': progress_ref, 'transition_protocol': protocol,
                'summary_hashes_checked': 36, 'native_numeric_admission': False, 'unexecuted_cells_inferred': False},
            'native_stdout': {'raw_source': stdout_ref, 'record_count': 1, 'driver_api_event': None, 'raw_bytes_rewritten': False}}
        outer_ref = add(claim + '/capture-receipt.json', outer)
        controller = {'task': 'RESERVED48', 'backend': 'GPU', 'prompt_bin': 128, 'status': 'completed', 'returncode': 0,
            'timed_out': False, 'timed_out_scope': 'outer_controller_only', 'remaining_descendants': [], 'automatic_retry': False,
            'capture_receipt': outer_ref, 'native_generic': {'source': generic_ref, 'status': 'completed', 'returncode': 0,
                'child_returncode': 0, 'generic_deadline_reached': False}, 'timeout_observations': {
                'outer_controller_deadline': False, 'original_generic_native_deadline': False, 'source_reported_timeout': None}}
        controller_ref = add(claim + '/controller-receipt.json', controller)
        mapping = root / 'source-map.json'; a.put(mapping, {'schema_version': 1, 'request': {'task': 'RESERVED48',
            'backend': 'GPU', 'prompt_bin': 128, 'outer_receipt': outer_ref['path']}, 'files': files})
        info = {'source_map': a.ref(mapping), 'receipt': {'source_path': outer_ref['path'], 'sha256': outer_ref['sha256']}}
        endpoint = a.Endpoint(a.Audit(60), info, 'GPU', 128)
        result = {'endpoint': endpoint, 'output': output, 'rows': rows(), 'runtime': runtime, 'outer': outer}
        gates = dict(a.GATES, native_prerequisite_sha256=prerequisite['sha256'], native_budget_sha256=budget['sha256'],
                     expected_builder_sha256=source_pins['expected'])
        pins = copy.deepcopy(a.ENDPOINT_PINS); pins['GPU']['128'] = {'source_map': a.sha(mapping), 'receipt': outer_ref['sha256'],
            'controller': controller_ref['sha256'], 'prepared_config': config_ref['sha256']}
        sources = copy.deepcopy(a.SOURCE_PINS); sources['GPU'] = source_pins
        return result, gates, pins, sources, stage['sha256'], expected['sha256'], add, physical

    def test_original_outer_progress_stdout_summary_controller_source_hash_closure(self):
        with tempfile.TemporaryDirectory() as td:
            result, gates, pins, sources, stage, expected, add, physical = self.fixture(Path(td))
            with patch.object(a, 'GATES', gates), patch.object(a, 'ENDPOINT_PINS', pins), patch.object(a, 'SOURCE_PINS', sources), \
                    patch.object(a, 'admit_endpoint_base', return_value=result):
                admitted = a.admit_endpoint(result['endpoint'], {'synthetic': True}, stage, expected)
                self.assertEqual(admitted['progress']['forward_returns'], 816)
                self.assertEqual(len(admitted['progress']['summary_events']), 36)
                summary = admitted['progress']['summary_events'][0]['source']['path']; physical[summary].write_bytes(b'changed after capture')
                with self.assertRaisesRegex(ValueError, 'byte count|byte SHA|source byte'):
                    a.admit_endpoint(result['endpoint'], {}, stage, expected)

    def test_controller_detachment_and_rehashed_stdout_progress_forgery_rejected(self):
        for mode in ('controller', 'stdout'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as td:
                result, gates, pins, sources, stage, expected, add, physical = self.fixture(Path(td))
                if mode == 'controller':
                    name = '/synthetic/root/claims/app-synthetic/controller-receipt.json'; doc = a.load(physical[name])
                    doc['capture_receipt']['sha256'] = 'f' * 64; add(name, doc)
                    pins['GPU']['128']['controller'] = a.sha(physical[name])
                else:
                    value = result['outer']['native_stdout']['raw_source']; raw = a.load(physical[value['path']])
                    raw['progress']['sha256'] = 'f' * 64; new = add(value['path'], raw=raw_records([raw]))
                    result['outer']['native_stdout']['raw_source'] = new
                    outer_ref = add('/synthetic/root/claims/app-synthetic/capture-receipt.json', result['outer'])
                    pins['GPU']['128']['receipt'] = outer_ref['sha256']
                    controller_name = '/synthetic/root/claims/app-synthetic/controller-receipt.json'
                    controller = a.load(physical[controller_name]); controller['capture_receipt'] = outer_ref
                    pins['GPU']['128']['controller'] = add(controller_name, controller)['sha256']
                # Deliberately re-sign every changed map byte and all permitted
                # external pins: rejection must come from the inner binding,
                # not a stale synthetic wrapper checksum.
                mapping = result['endpoint'].path; document = a.load(mapping)
                for original, actual in physical.items():
                    document['files'][original] = {'path': actual.relative_to(mapping.parent).as_posix(),
                        'sha256': a.sha(actual), 'size': actual.stat().st_size}
                mapping.write_text(a.canonical(document) + '\n', encoding='utf8')
                pins['GPU']['128']['source_map'] = a.sha(mapping)
                info = {'source_map': a.ref(mapping), 'receipt': {'source_path': document['request']['outer_receipt'],
                        'sha256': pins['GPU']['128']['receipt']}}
                result['endpoint'] = a.Endpoint(a.Audit(60), info, 'GPU', 128)
                with patch.object(a, 'GATES', gates), patch.object(a, 'ENDPOINT_PINS', pins), patch.object(a, 'SOURCE_PINS', sources), \
                        patch.object(a, 'admit_endpoint_base', return_value=result), self.assertRaises((ValueError, KeyError)):
                    a.admit_endpoint(result['endpoint'], {}, stage, expected)


if __name__ == '__main__': unittest.main()

"""One bounded metadata-only reserved48 CPU export, never a probe rerun."""
from datetime import datetime,timezone
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

PRODUCER_SHA='5b6d11ce989e84c3d777f0136fd3e74c5ac410f66bb78f35ea3fb6c317e9bdcd'
RECORDER_SHA='2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'
SUBDIR='reserved48-english-20261107/cpu-prerequisite-v1'
TOTAL,GENERIC,CLEANUP=120,95,20


def require(ok,message):
    if not ok:raise ValueError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def put(path,doc):
    with Path(path).open('x',encoding='utf8') as stream:json.dump(doc,stream,indent=2,allow_nan=False);stream.write('\n')


def run(root):
    started=time.monotonic();root=Path(root);require(os.name=='posix' and root.is_dir() and not root.is_symlink(),'explicit original POSIX root required');root=root.resolve(strict=True)
    here=Path(__file__).resolve().parent;producer=here/'export_reserved48_cpu_proof_v1.py';recorder=here/'record_run.py'
    require(here.is_relative_to(root/'tools') and not Path(__file__).is_symlink(),'staged CPU export source required')
    for path,digest in ((producer,PRODUCER_SHA),(recorder,RECORDER_SHA)):
        require(isinstance(digest,str) and len(digest)==64 and path.is_file() and not path.is_symlink() and sha(path)==digest,'reviewed CPU export source SHA differs or remains unready')
    target=root/SUBDIR;require(target.is_dir() and not target.is_symlink() and target.resolve().is_relative_to(root) and
        (root/'exports').is_dir() and not (root/'exports').is_symlink() and not (root/'runs').is_symlink(),'owned existing CPU/exports/runs paths required')
    put(target/'cpu-proof-export-worker-once.json',{'kind':'CPU metadata export attempt; not native claim','claimed_utc':datetime.now(timezone.utc).isoformat(),
        'producer_sha256':PRODUCER_SHA,'runner_sha256':sha(__file__),'automatic_retry':False,'native_executions_started':0})
    folder=root/'runs'/('compare-reserved48-cpu-proof-export-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));folder.mkdir(mode=0o700)
    output=root/'exports'/('reserved48-tiny-cpu-proof-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    state={'schema_version':1,'task':'reserved48-actual-CPU-proof-export','status':'running','started_utc':datetime.now(timezone.utc).isoformat(),
        'producer_sha256':PRODUCER_SHA,'recorder_sha256':RECORDER_SHA,'runner_sha256':sha(__file__),'whole_cpu_seconds':TOTAL,
        'generic_seconds':GENERIC,'producer_seconds':90,'cleanup_reserve_seconds':CLEANUP,'output':str(output),'native_executions_started':0,'production_model_loads':0,'automatic_retry':False,'acceptance':None}
    put(folder/'controller-start.json',state);code=2
    def stop(signum,_):raise KeyboardInterrupt('reserved48 CPU export bounded signal '+str(signum))
    handlers={sig:signal.signal(sig,stop) for sig in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
    signal.setitimer(signal.ITIMER_REAL,max(.01,TOTAL-(time.monotonic()-started)))
    try:
        spec=importlib.util.spec_from_file_location('original_recorded_reserved48_CPU_export',recorder);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        require(not any(name in sys.modules for name in ('torch','torch_npu','numpy','transformers')),'CPU export controller imported a framework')
        require(time.monotonic()-started+GENERIC<TOTAL-CLEANUP,'insufficient finite generic export envelope')
        generic,command=module.record_run(folder,'cpu','reserved48-proof-export',GENERIC,
            lambda _: [sys.executable,'-S','-B',str(producer),'--root',str(root),'--output',str(output)],cwd=here)
        state['generic_receipt']={'path':str(generic/'command.json'),'sha256':sha(generic/'command.json')};state['child_returncode']=command['child_returncode'];state['timed_out']=command['status']=='timed_out'
        require(command['status']=='completed' and command['returncode']==command['child_returncode']==0,'CPU proof exporter failed; preserve original logs')
        result=read(generic/'stdout.bin');require(result['status'] in ('actual_reserved48_CPU_proof_exported','reserved48_CPU_diagnostic_exported_not_prerequisite') and
            result['native_executions_started']==result['production_native_arrays_read']==result['tiny_CPU_tensor_stat_open_copy_count']==0,'CPU proof export scope differs')
        for entry in (result['archive'],result['envelope']):
            path=Path(entry['path']);require(path.resolve().is_relative_to((root/'exports').resolve()) and path.is_file() and not path.is_symlink() and
                path.stat().st_size==entry['bytes'] and sha(path)==entry['sha256'],'actual CPU export archive/envelope changed')
        require(sha(producer)==PRODUCER_SHA and sha(recorder)==RECORDER_SHA,'CPU source changed during export')
        state.update(status='completed' if result['native_prerequisite_valid'] else 'diagnostic_only',returncode=0,result=result);code=0
    except BaseException as exc:state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),partial_files_preserved=True)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        for sig,handler in handlers.items():signal.signal(sig,handler)
        state.update(finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started);put(folder/'controller-receipt.json',state)
    print(json.dumps({'status':state['status'],'receipt':str(folder/'controller-receipt.json'),'receipt_sha256':sha(folder/'controller-receipt.json'),
        'result':state.get('result'),'error':state.get('error'),'native_executions_started':0},indent=2),flush=True)
    return code


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True);args=parser.parse_args();raise SystemExit(run(args.root))

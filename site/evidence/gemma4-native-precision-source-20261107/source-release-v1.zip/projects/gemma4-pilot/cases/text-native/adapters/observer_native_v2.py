"""Backend-parameterized one-model observer pilot; no native work on import.

The common stage/actual-I04 prerequisite gate runs before Torch. Outer new-stage
launchers must provide one-shot claims, fresh idle/binding checks and hard owned
process cleanup. These candidate entry pins remain unready until frozen.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import inspect
import hashlib
import json
import os
from pathlib import Path
import sys

import observer_common_v2 as common

COMMON_SOURCE_SHA256='89270de32c6f6b5c60fd8d6408058ab2afe36188730c7c95c321ffd36221f3e2'


def verify_pairing():
    actual=Path(common.__file__);expected=Path(__file__).resolve().parent/'observer_common_v2.py'
    if actual.is_symlink() or actual.resolve()!=expected or hashlib.sha256(actual.read_bytes()).hexdigest()!=COMMON_SOURCE_SHA256:
        raise ValueError('native v2 requires its frozen observer common v2 source bytes')
    return {'common_path':str(actual.resolve()),'common_sha256':COMMON_SOURCE_SHA256,'native_executions_started':0}


def implementation_sources(model,identity,torch,masking_utils):
    import torch.utils._python_dispatch as python_dispatch
    import torch.nn.modules.module as module_api
    refs={'modeling':identity['modeling_source'],'masking_utils':common.file_ref(masking_utils.__file__),
        'torch_dispatch':common.file_ref(python_dispatch.__file__),'module_hooks':common.file_ref(module_api.__file__)}
    for name,module in model.named_modules(remove_duplicate=False):
        if 'RotaryEmbedding' in type(module).__name__:
            source=inspect.getsourcefile(type(module));common.require(source is not None,'actual rotary implementation source unavailable')
            refs['rotary/'+name]=common.file_ref(source)
    common.require(any(name.startswith('rotary/') for name in refs),'actual rotary implementation was not observed')
    common.check_refs(refs);return refs


def run_gpu(args,stage,inventory,refs,proof):
    from pilot_gpu_torch290_candidate import check_allocation,check_device,check_stack,POLICY_SHA256
    from pilot_gpu_peer_v2 import seed_and_check,math_policy,check_policy
    allocation=common.read(args.allocation_receipt);check_allocation(allocation)
    common.require(common.sha(args.numerics_policy)==POLICY_SHA256,'frozen GPU numerical policy differs')
    policy=common.read(args.numerics_policy)
    sys.path.insert(0,str(common.HERE.parent/'transfer'))
    from npu_three_repeat_launcher_v4 import memory_observation
    memory=memory_observation()
    common.require(memory['effective_available_bytes']>=stage['limits']['minimum_gpu_host_effective_available_bytes'],'GPU host/cgroup effective memory below frozen bound')
    with common.bounded_native(stage,'gpu'):
        import torch
        import numpy
        import transformers
        import transformers.masking_utils as masking_utils
        from transformers import AutoModelForMultimodalLM
        versions={'torch':str(torch.__version__),'transformers':str(transformers.__version__),'cuda_runtime':str(torch.version.cuda),'numpy':numpy.__version__}
        check_stack(versions);props,physical,free,total=check_device(torch,allocation)
        common.require(free>=stage['limits']['minimum_free_device_bytes'],'GPU free device memory below frozen bound')
        rng=seed_and_check(torch,numpy,policy);common.check_refs(refs);common.initialize_output(args,proof)
        common.put(args.output/'policy-before-load.json',rng)
        model,identity=common.prior.load_verified_model(args,torch,AutoModelForMultimodalLM,common.read(common.HERE/'upstream-identity.json'))
        after_load=math_policy(torch);check_policy(after_load,policy);common.put(args.output/'policy-after-load.json',after_load)
        implementations=implementation_sources(model,identity,torch,masking_utils)
        summaries=common.capture_all(model,torch,args.device,inventory,args.output,'gpu',lambda:seed_and_check(torch,numpy,policy),
            lambda:math_policy(torch),lambda:torch.cuda.synchronize(0))
        after=math_policy(torch);check_policy(after,policy);common.put(args.output/'policy-after-capture.json',after)
        runtime={'backend':'gpu','versions':versions,'model_identity':identity,'implementation_sources':implementations,
            'device_argument':args.device,'device_name':props.name,'runtime_uuid':physical,'free_bytes_before_load':free,'total_bytes':total,
            'host_memory':memory,'allocation_receipt_sha256':common.sha(args.allocation_receipt),'numerics_policy_sha256':POLICY_SHA256,
            'math_policy':after,'seed':0,'initial_rng_observations':rng,'native_capture_modes':summaries,
            'visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'python':sys.version,'python_executable':sys.executable,
            'package_sources':{'torch':common.file_ref(torch.__file__),'numpy':common.file_ref(numpy.__file__),'transformers':common.file_ref(transformers.__file__)}}
        print(json.dumps(common.finalize(args,inventory,refs,runtime),allow_nan=False),flush=True)


def run_npu(args,stage,inventory,refs,proof):
    from pilot_ascend_candidate_v3 import check_allocation,check_stack,check_version,normalize_runtime_uuid,observe_driver_version,set_policy,get_policy
    sys.path.insert(0,str(common.HERE.parent/'transfer'))
    from npu_three_repeat_launcher_v4 import binding,memory_observation
    allocation,physical=binding(args.allocation_receipt,args.native_mapping,args.native_source);check_allocation(allocation,0)
    common.require(physical==common.prior.ORIGINAL_NPU_UUID,'observer NPU must retain original selected UUID')
    memory=memory_observation()
    common.require(memory['effective_available_bytes']>=stage['limits']['minimum_npu_host_effective_available_bytes'],'NPU host/cgroup effective memory below frozen bound')
    with common.bounded_native(stage,'npu'):
        import torch
        import torch_npu
        import numpy
        import transformers
        import transformers.masking_utils as masking_utils
        from transformers import AutoModelForMultimodalLM
        npu=torch_npu.npu;driver,provenance=observe_driver_version(torch_npu.utils.get_cann_version,args.driver_source)
        versions={'torch':str(torch.__version__),'torch_npu':str(torch_npu.__version__),'transformers':transformers.__version__,
            'numpy':numpy.__version__,'cann':check_version('CANN',torch_npu.utils.get_cann_version('CANN')),'driver':driver}
        check_stack(versions)
        common.require(versions=={'torch':'2.9.0+cpu','torch_npu':'2.9.0.post2','transformers':'5.10.1','numpy':'1.26.4','cann':'9.1.0','driver':'25.5.2'},'frozen NPU observer stack differs')
        common.require(npu.is_available() and npu.device_count()==8,'eight-logical-visible NPU instance unavailable')
        npu.set_device(0);common.require(npu.current_device()==0 and npu.is_bf16_supported(),'original selected NPU0/BF16 differs')
        actual=normalize_runtime_uuid(getattr(npu.get_device_properties(0),'uuid',None));free,total=map(int,npu.mem_get_info(0))
        common.require(actual==physical and free>=stage['limits']['minimum_free_device_bytes'],'actual NPU UUID/free memory differs')
        before,policy=set_policy(torch,npu,numpy);common.check_refs(refs);common.initialize_output(args,proof)
        common.put(args.output/'driver-version-provenance.json',provenance);common.put(args.output/'policy-before-load.json',{'before':before,'configured':policy})
        model,identity=common.prior.load_verified_model(args,torch,AutoModelForMultimodalLM,common.read(common.HERE/'upstream-identity.json'))
        common.require(get_policy(torch,npu)==policy,'NPU observer policy changed during load');common.put(args.output/'policy-after-load.json',get_policy(torch,npu))
        implementations=implementation_sources(model,identity,torch,masking_utils)
        def reset():
            previous,configured=set_policy(torch,npu,numpy);common.require(configured==policy,'NPU observer reset policy differs')
            return {'seed':0,'before':previous,'settings':configured}
        summaries=common.capture_all(model,torch,args.device,inventory,args.output,'npu',reset,lambda:get_policy(torch,npu),lambda:npu.synchronize(0))
        after=get_policy(torch,npu);common.require(after==policy,'NPU observer policy changed during capture');common.put(args.output/'policy-after-capture.json',after)
        runtime={'backend':'npu','versions':versions,'model_identity':identity,'implementation_sources':implementations,
            'device_argument':args.device,'device_name':npu.get_device_name(0),'runtime_uuid':actual,'instance_visible_count':8,'compute_device_count':1,
            'free_bytes_before_load':free,'total_bytes':total,'host_memory':memory,'allocation_receipt_sha256':common.sha(args.allocation_receipt),
            'native_mapping_sha256':common.sha(args.native_mapping),'native_source_sha256':common.sha(args.native_source),
            'driver_version_provenance':provenance,'driver_version_provenance_sha256':common.sha(args.output/'driver-version-provenance.json'),
            'math_policy':after,'seed':0,'native_capture_modes':summaries,'python':sys.version,'python_executable':sys.executable,
            'visible_device_env':{key:os.environ.get(key) for key in ('ASCEND_RT_VISIBLE_DEVICES','ASCEND_VISIBLE_DEVICES')},
            'package_sources':{'torch':common.file_ref(torch.__file__),'torch_npu':common.file_ref(torch_npu.__file__),
                'numpy':common.file_ref(numpy.__file__),'transformers':common.file_ref(transformers.__file__)}}
        print(json.dumps(common.finalize(args,inventory,refs,runtime),allow_nan=False),flush=True)


def main():
    verify_pairing()
    args=common.arguments();stage,inventory,refs,proof=common.prepare(args,__file__)
    if args.backend=='gpu':run_gpu(args,stage,inventory,refs,proof)
    else:run_npu(args,stage,inventory,refs,proof)


if __name__=='__main__':main()

"""Stage two exact TAR wrappers and reconstruct only the immutable actual gzip.

Stage verifies then moves one uploaded wrapper into an exclusive transport part
directory. Assemble never extracts general members: it streams the one exact
regular member from each wrapper into an exclusive original gzip path. All
failed claims/partial files remain; there is no automatic retry.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import tarfile
import time

ARCHIVE_NAME='gpu-i03-full-REDACTED_APP_ID-20261106T153711Z.tar.gz'
ARCHIVE_BYTES=529888535
ARCHIVE_SHA='406294d2a911e81b4dfbd90f05f14cf958976f7b2999a988c0714ff33979c894'
CHUNK_BYTES=256*1024**2
LOGICAL_BYTES=1041054681
MANIFEST_NAME='i03-gpu-transport-manifest-v1.json'
MANIFEST_SHA='0fe4af4c53098df852b4cad41c691a324a19d06c451435f25a4adfa46ca71226'
WIRE_CAP,DISK_CAP,MIN_FREE=1536*1024**2,4*1024**3,5*1024**3
HEX=re.compile(r'^[a-f0-9]{64}$')


def require(ok,message):
    if not ok:raise ValueError(message)


def utc():return datetime.now(timezone.utc).isoformat()


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def read(path):
    def pairs(items):
        result={}
        for key,value in items:require(key not in result,'duplicate JSON key');result[key]=value
        return result
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)


def put(path,document):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(document,stream,indent=2,allow_nan=False);stream.write('\n')


def tar_size(size):return ((512+((size+511)//512)*512+1024+10239)//10240)*10240


def regular(path):
    path=Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_nlink==1,'one-link original regular file required')
    return path


def contained(root,path):
    path=Path(path)
    require(path.is_absolute() and path.is_relative_to(root) and path.resolve().is_relative_to(root),'path escapes explicit R root')
    current=path
    while current!=root:
        require(not current.is_symlink(),'symlink in task-owned path');current=current.parent
    return path


def roots(root,subdir,manifest):
    root=Path(root);require(root.is_dir() and not root.is_symlink(),'explicit existing nonsymlink R root required');root=root.resolve(strict=True)
    rel=PurePosixPath(subdir)
    require(isinstance(subdir,str) and subdir and not rel.is_absolute() and '\\' not in subdir and str(rel)==subdir and
        all(p not in ('','.','..') for p in subdir.split('/')),'canonical relative transport subdir required')
    target=contained(root,root/subdir)
    manifest=contained(root,Path(manifest).absolute())
    require(HEX.fullmatch(MANIFEST_SHA) and regular(manifest).stat().st_size<=16384 and sha(manifest)==MANIFEST_SHA,'fixed actual machine manifest SHA differs')
    document=read(manifest);validate_manifest(document)
    require(shutil.disk_usage(root).free>=MIN_FREE,'observed source free storage below5GiB')
    return root,target,document


def validate_manifest(document):
    require(document.get('schema_version')==1 and document.get('kind')=='i03-gpu-archive-tar-chunks' and
        document.get('archive')=={'basename':ARCHIVE_NAME,'size_bytes':ARCHIVE_BYTES,'sha256':ARCHIVE_SHA} and
        document.get('chunk_data_limit_bytes')==CHUNK_BYTES and document.get('original_gzip_bytes_preserved') is True and
        document.get('native_executions_started')==0 and document.get('acceptance') is None,'actual archive/manifest identity differs')
    parts=document['parts'];require(isinstance(parts,list) and len(parts)==2,'exact two wrappers required')
    offset=0
    for index,part in enumerate(parts):
        size=min(CHUNK_BYTES,ARCHIVE_BYTES-offset)
        expected={'index':index,'offset':offset,'data_size_bytes':size,'member_name':'chunk-%04d.bin'%index,
            'wrapper_basename':ARCHIVE_NAME[:-7]+'-transport-%04d.tar'%index,'wrapper_size_bytes':tar_size(size)}
        require(set(part)==set(expected)|{'data_sha256','wrapper_sha256'} and all(type(part[k]) is type(v) and part[k]==v for k,v in expected.items()) and
            all(isinstance(part[k],str) and HEX.fullmatch(part[k]) for k in ('data_sha256','wrapper_sha256')),'wrapper index/member/offset/size/hash differs')
        require(0<size<=256*1024**2,'data chunk exceeds256MiB');offset+=size
    require(offset==ARCHIVE_BYTES,'archive coverage gap/overlap')
    wire=sum(p['wrapper_size_bytes'] for p in parts)
    expected={'chunk_data_bytes':ARCHIVE_BYTES,'wrapper_wire_bytes':wire,'wrapper_header_and_padding_bytes':wire-ARCHIVE_BYTES,
        'encoded_transport_cap_bytes':WIRE_CAP,'logical_artifact_payload_bytes':LOGICAL_BYTES,'logical_artifact_cap_bytes':1024**3,
        'parts_plus_reconstructed_plus_artifact_payload_bytes':wire+ARCHIVE_BYTES+LOGICAL_BYTES,'new_disk_cap_bytes':DISK_CAP}
    require(document['transport_accounting']==expected and wire<=WIRE_CAP and LOGICAL_BYTES<=1024**3 and
        wire+ARCHIVE_BYTES+LOGICAL_BYTES<DISK_CAP,'actual transport/storage accounting differs')


def verify_wrapper(path,part,deadline):
    path=regular(path)
    require(path.name==part['wrapper_basename'] and path.stat().st_size==part['wrapper_size_bytes'] and sha(path)==part['wrapper_sha256'],'wrapper raw size/SHA differs')
    with tarfile.open(path,'r:') as package:
        members=package.getmembers()
        require(len(members)==1,'exact one regular wrapper member required')
        item=members[0]
        require(item.name==part['member_name'] and item.type==tarfile.REGTYPE and item.isfile() and not item.issym() and not item.islnk() and
            not item.pax_headers and not item.sparse and item.size==part['data_size_bytes'],'wrapper member/type/size differs')
        h=hashlib.sha256();count=0
        with package.extractfile(item) as stream:
            for block in iter(lambda:stream.read(4*1024**2),b''):
                require(time.monotonic()<deadline,'CPU transport deadline reached');count+=len(block);h.update(block)
        require(count==part['data_size_bytes'] and h.hexdigest()==part['data_sha256'],'wrapper data bytes/SHA differ')
    return path


def tree_bytes(path):
    total=0
    for item in Path(path).rglob('*'):
        require(not item.is_symlink(),'symlink in new transport tree')
        if item.is_file():total+=item.stat().st_size
    return total


def stage(root,subdir,manifest,wrapper):
    started=time.monotonic();root,target,document=roots(root,subdir,manifest)
    wrapper=contained(root,Path(wrapper).absolute());matches=[p for p in document['parts'] if p['wrapper_basename']==wrapper.name]
    require(wrapper.parent==root,'only a fresh wrapper uploaded in the R root may be moved')
    require(len(matches)==1,'uploaded wrapper basename not in fixed manifest');part=matches[0]
    verify_wrapper(wrapper,part,started+900)
    target.mkdir(mode=0o700,parents=True,exist_ok=True)
    require(target.is_dir() and not target.is_symlink(),'transport root differs')
    directory=target/('part-%04d'%part['index']);directory.mkdir(mode=0o700,exist_ok=False)
    put(directory/'stage-claim.json',{'claimed_utc':utc(),'manifest_sha256':MANIFEST_SHA,'source':str(wrapper),'part':part,'automatic_retry':False})
    destination=directory/part['wrapper_basename'];before=wrapper.stat()
    # Link is exclusive; original upload is removed only after byte verification.
    # This keeps the immutable wrapper bytes while freeing its upload-directory entry.
    os.link(wrapper,destination)
    require(destination.stat().st_size==part['wrapper_size_bytes'] and sha(destination)==part['wrapper_sha256'],'staged wrapper changed')
    now=wrapper.stat();require((now.st_dev,now.st_ino)==(before.st_dev,before.st_ino),'uploaded source inode changed')
    wrapper.unlink();require(destination.stat().st_nlink==1,'staged wrapper still has an unexpected hardlink')
    measured=tree_bytes(target)
    require(measured+ARCHIVE_BYTES+LOGICAL_BYTES<DISK_CAP,'new transport plus reconstruction/expanded-artifact budget exceeded')
    receipt={'status':'wrapper_verified_and_moved','finished_utc':utc(),'part_index':part['index'],'manifest_sha256':MANIFEST_SHA,
        'uploaded_source_path':str(wrapper),'retained_wrapper_path':str(destination),'wrapper_sha256':sha(destination),'data_sha256':part['data_sha256'],
        'wrapper_bytes':destination.stat().st_size,'source_entry_removed_after_verified_exclusive_link':True,'new_transport_bytes':measured,
        'native_executions_started':0,'elapsed_seconds':time.monotonic()-started}
    put(directory/'stage-receipt.json',receipt);return receipt


def assemble(root,subdir,manifest):
    started=time.monotonic();root,target,document=roots(root,subdir,manifest);deadline=started+900
    require(target.is_dir(),'staged transport directory missing')
    output=contained(root,root/ARCHIVE_NAME)
    require(not output.exists() and not output.is_symlink(),'original destination/partial already exists; never overwrite or retry')
    require(tree_bytes(target)+ARCHIVE_BYTES+LOGICAL_BYTES<DISK_CAP,'new transport/reconstruction/expanded-artifact budget exceeded')
    put(target/'assembly-claim.json',{'claimed_utc':utc(),'archive_sha256':ARCHIVE_SHA,'manifest_sha256':MANIFEST_SHA,'cpu_timeout_seconds':900,'automatic_retry':False})
    state={'schema_version':1,'status':'running','started_utc':utc(),'archive':str(output),'manifest_sha256':MANIFEST_SHA,
        'assembler_sha256':sha(__file__),'cpu_timeout_seconds':900,'native_executions_started':0,'acceptance':None}
    try:
        wrappers=[]
        for part in document['parts']:
            directory=target/('part-%04d'%part['index']);path=contained(root,directory/part['wrapper_basename'])
            receipt=read(regular(directory/'stage-receipt.json'))
            require(receipt.get('status')=='wrapper_verified_and_moved' and receipt.get('manifest_sha256')==MANIFEST_SHA and
                receipt.get('part_index')==part['index'] and receipt.get('wrapper_sha256')==part['wrapper_sha256'],'completed exact wrapper stage receipt required')
            wrappers.append(verify_wrapper(path,part,deadline))
        total=hashlib.sha256();written=0
        with output.open('xb') as destination:
            for path,part in zip(wrappers,document['parts']):
                require(written==part['offset'],'gap/overlap before chunk write');chunk=hashlib.sha256();count=0
                with tarfile.open(path,'r:') as package,package.extractfile(part['member_name']) as source:
                    for block in iter(lambda:source.read(4*1024**2),b''):
                        require(time.monotonic()<deadline,'CPU reconstruction deadline reached');destination.write(block);total.update(block);chunk.update(block);count+=len(block);written+=len(block)
                require(count==part['data_size_bytes'] and chunk.hexdigest()==part['data_sha256'],'chunk changed during reconstruction')
            destination.flush();os.fsync(destination.fileno())
        require(written==ARCHIVE_BYTES and total.hexdigest()==ARCHIVE_SHA and output.stat().st_size==ARCHIVE_BYTES and sha(output)==ARCHIVE_SHA,'reconstructed original gzip size/SHA differs')
        require(all(sha(path)==part['wrapper_sha256'] for path,part in zip(wrappers,document['parts'])),'wrapper changed during reconstruction')
        measured=tree_bytes(target)+output.stat().st_size
        require(measured+LOGICAL_BYTES<DISK_CAP,'measured new transport plus expanded-artifact budget exceeded')
        state.update(status='i03_original_gpu_gzip_reconstructed',returncode=0,archive_bytes=written,archive_sha256=sha(output),
            encoded_wrapper_wire_bytes=document['transport_accounting']['wrapper_wire_bytes'],logical_artifact_payload_bytes=LOGICAL_BYTES,
            measured_transport_and_reconstructed_bytes=measured,measured_plus_known_expanded_artifact_bytes=measured+LOGICAL_BYTES,
            new_disk_cap_bytes=DISK_CAP,original_gzip_bytes_preserved=True)
    except BaseException as exc:
        state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),partial_files_and_claim_preserved=True,automatic_retry=False)
    finally:
        state.update(finished_utc=utc(),elapsed_seconds=time.monotonic()-started);put(target/'assembly-receipt.json',state)
    return state


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('mode',choices=['stage','assemble'])
    parser.add_argument('--root',type=Path,required=True);parser.add_argument('--transport-subdir',required=True);parser.add_argument('--manifest',type=Path,required=True);parser.add_argument('--wrapper',type=Path)
    args=parser.parse_args()
    def expire(*_):raise TimeoutError('I03 CPU transport900s bound exceeded')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,900)
    try:
        if args.mode=='stage':
            require(args.wrapper is not None,'one uploaded wrapper path required');result=stage(args.root,args.transport_subdir,args.manifest,args.wrapper)
        else:result=assemble(args.root,args.transport_subdir,args.manifest)
        print(json.dumps(result,indent=2));return result.get('returncode',0)
    finally:signal.setitimer(signal.ITIMER_REAL,0)


if __name__=='__main__':raise SystemExit(main())

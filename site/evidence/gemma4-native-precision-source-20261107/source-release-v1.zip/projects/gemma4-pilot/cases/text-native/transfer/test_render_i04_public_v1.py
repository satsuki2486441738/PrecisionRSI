"""Synthetic public-contract regressions; no actual model/native evidence."""
import ast
import base64
import copy
import hashlib
import gzip
import importlib.util
import io
import json
import math
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('i04_private_public_renderer',HERE/'render_i04_public_v1.py')
tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)


def archive_ref(files,kind=None):
    stream=io.BytesIO()
    with tarfile.open(fileobj=stream,mode='w:gz',format=tarfile.USTAR_FORMAT) as package:
        for name,data in files.items():
            info=tarfile.TarInfo(name);info.size=len(data)
            if kind:info.type=kind;info.size=0;info.linkname='/synthetic/outside'
            package.addfile(info,io.BytesIO(data))
    raw=stream.getvalue();return {'bytes':len(raw),'sha256':tool.sha(raw),'base64':base64.b64encode(raw).decode()}


class SyntheticMain:
    """Only pure public transforms use this; render() cannot accept this object."""
    def __init__(self):
        self.docs={};self.files={};self.report={'raw_derivation':{},'source_map_sha256':{'GPU':'a'*64,'NPU':'b'*64},'target_distribution_pairs':[]}
        self.map_sha='c'*64;self.envelope_sha='d'*64;self.archive=type('Archive',(),{'ref':{'sha256':'e'*64}})()
        self.mapping={'controller':{'sha256':'f'*64}};self.controller={'report':{'sha256':'1'*64},'comparison_spec':{'sha256':'2'*64},'elapsed_seconds':12.5}
        self.spec={'endpoints':{}}
        for backend in ('GPU','NPU'):
            self.report['raw_derivation'][backend]={}
            for mode in ('alone-A','alone-B','batch-left','batch-right'):
                requests=[mode[-1]] if mode.startswith('alone-') else ['A','B']
                self.report['raw_derivation'][backend][mode]={'raw_sha256':'3'*64,'pad_inventory':{'rows':64 if mode.startswith('batch') else 0,
                    'coordinates':64*262144 if mode.startswith('batch') else 0,'rows_with_nonfinite':64 if mode=='batch-right' else 0,
                    'nan':64*262144 if mode=='batch-right' else 0,'positive_infinity':0,'negative_infinity':0,'nonfinite':64*262144 if mode=='batch-right' else 0},
                    'observations':{r:{'targets':tool.LENGTHS[r]-1,'distributions':47,'largest_abs_logprob_derivation_delta':7.1e-15} for r in requests}}
            generic='/private/'+backend+'/command.json';self.add(generic,{'status':'completed','returncode':0,'child_returncode':0,'wall_seconds':40.25 if backend=='GPU' else 20.75,
                'start':'2026-11-07T00:00:00+00:00','end':'2026-11-07T00:00:41+00:00'})
            outer='/private/'+backend+'/outer.json';self.add(outer,{'generic_receipt':{'path':generic,'sha256':self.files[generic]['sha256']}})
            self.spec['endpoints'][backend]={'receipt':{'source_path':outer,'sha256':self.files[outer]['sha256']}}
        for index,(sides,request,kind) in enumerate(tool.pairs()):
            count=tool.LENGTHS[request]-1;coords=[{'sample':'private-input-REDACTED_PLATFORM_HOST','position':i,'token':(i-1)%128} for i in range(1,count+1)]
            folder='/private/frozen/pair-%02d/'%index;condition={};target_docs=[];vectors=[]
            for side in sides:
                backend=side.split('-')[0].upper();mode=side[len(backend)+1:-(len(request)+1)]
                mode_index={'alone-A':0,'alone-B':0,'batch-left':1,'batch-right':2}[mode]
                offset=64 if request=='B' and mode=='batch-left' else 0
                delta=(.25 if backend=='NPU' else 0)+mode_index*.05
                values=[-2.-i/1000-delta for i in range(count)];vectors.append(values)
                name=folder+side+'-targets.json';self.add(name,{'scores':[{**c,'logprob':x} for c,x in zip(coords,values)]});target_docs.append(name)
                condition[side]={'hardware':{'category':backend,'model':'NVIDIA H100 80GB HBM3' if backend=='GPU' else 'Ascend910_9382',
                        'gpu_uuid':'REDACTED_DEVICE_UUID','account':'REDACTED_ACCOUNT'},
                    'software':{'framework':'torch','torch':'2.9.0+cu128' if backend=='GPU' else '2.9.0+cpu','transformers':'5.10.1','numpy':'1.26.4','private_path':'/srv/precision-user'},
                    'backend_policy':{'deterministic_algorithms':False,'pythonhashseed':'0','float32_matmul_precision':'highest'},
                    'execution_mode':{'mode':mode,'request':request,'slot':0 if mode.startswith('alone') or request=='A' else 1,'physical_offset':offset,
                        'native_batch_size':1 if mode.startswith('alone') else 2,'physical_width':tool.LENGTHS[request] if mode.startswith('alone') else 160,
                        'logical_sequence_length':tool.LENGTHS[request],'use_cache':False,'native_forward_calls':1,'same_process_model_loads':1,
                        'loaded_model_state_sha256':'4'*64,'implementation_sha256':{'modeling':'5'*64,'masking_utils':'6'*64}}}
            contract=folder+'targets-contract.json';self.add(contract,{'targets':coords,'side_conditions':condition,'common':{'numerics':{
                'parameter_dtypes':['torch.bfloat16'],'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','attention':'eager','seed':0,'parallelism':'tp1',
                'normalization':'Offline NumPy float64 log_softmax of copied native values'}}})
            metrics=tool.calculate(*vectors);metrics['max_coordinate']={**coords[metrics.pop('max_target_index_zero_based')]}
            rows=[]
            for j,p in enumerate(tool.positions(request)):
                row={'sample':coords[0]['sample'],'position':p,'union_count':102,'tail_merged_js':{'value':.001,'status':'no_thresholds'},'top1_agreement':j!=0,
                    'top100_overlap':.99,'probability_rmse':.002,'max_probability_error':.003,'max_error_token':90001,
                    'coverage':{'side_a_top100':.8,'side_b_top100':.81,'side_a_union':.82,'side_b_union':.83},'normalization_mass':{'side_a':1.,'side_b':1.}}
                if j==0:row['top1_mismatch']={'side_a_token':10,'side_b_token':90001,'probabilities':[{'token':10,'side_a':.3,'side_b':.2},{'token':90001,'side_a':.25,'side_b':.4}],
                    'side_a_margin':.05,'side_b_margin':.2}
                rows.append(row)
            aggregate={field:{'mean':value,'p99':value,'max':value,'max_coordinate':{'sample':coords[0]['sample'],'position':rows[0]['position'],
                **({'token':90001} if field=='max_probability_error' else {})}} for field,value in [('probability_rmse',.002),('max_probability_error',.003),('tail_merged_js',.001)]}
            aggregate.update(top1_agreement={'count':46,'total':47,'fraction':46/47},top100_overlap={'mean':.99},coverage={k:{'mean':v,'p1':v,'min':v} for k,v in rows[0]['coverage'].items()})
            self.report['target_distribution_pairs'].append({'sides':sides,'request':request,'kind':kind,'targets':{'coverage':{'expected':count,'paired':count},'metrics':metrics,
                'sources':{'contract':contract,'side_a':target_docs[0],'side_b':target_docs[1]}},'distributions':{'status':'no_thresholds','position_count':47,'positions':rows,
                'aggregate':aggregate,'normalization_tolerance':1e-5,'renormalization':'none'}})
    def add(self,name,doc):self.docs[name]=doc;self.files[name]={'sha256':tool.sha(tool.encoded(doc))}
    def json(self,name,digest=None):
        if digest:self.assert_sha(name,digest)
        return copy.deepcopy(self.docs[name])
    def assert_sha(self,name,digest):assert self.files[name]['sha256']==digest


class SyntheticE02:
    def __init__(self,main):
        self.controller_sha='7'*64;self.envelope_sha='8'*64;self.controller={'report':{'sha256':'9'*64},'elapsed_seconds':5.25}
        target_checks=[];dist_checks=[]
        for i,p in enumerate(main.report['target_distribution_pairs']):
            metrics=copy.deepcopy(p['targets']['metrics']);metrics.pop('p99_method')
            target_checks.append({'sides':p['sides'],'request':p['request'],'metrics':metrics})
            if i<6:
                for row in p['distributions']['positions']:
                    values={k:v for k,v in row.items() if k not in ('sample','position')};values['direct_complement_mass']={'side_a':.18,'side_b':.17}
                    dist_checks.append({'sides':p['sides'],'request':p['request'],'position':row['position'],'metrics':values,'raw_native_to_NPY_max_abs_delta':[7.1e-15,3.5e-15]})
        self.report={'status':'independent_i04_selected_e02_checks_matched','selection_sha256':'a'*64,
            'scope':{'target_pairs':18,'request_target_counts':{'A':159,'B':95},'matched_cross_backend_distribution_pair_rows':282,'independent_distribution_pair_rows':282,
                'admitted_large_sources_final_bytehash_checked':572,'native_KV_checks':0},
            'verification':{'absolute_metric_tolerance':1e-12,'relative_metric_tolerance':5e-12,'raw_logprob_derivation_absolute_tolerance':1e-12,
                'model_acceptance_thresholds':False,'CPU_seconds':900,'full_pool_bytehash_passes':1},'target_pair_checks':target_checks,'distribution_checks':dist_checks}


class Regression(unittest.TestCase):
    def test_archive_hash_duplicate_link_escape_and_native_array_rejections(self):
        good=archive_ref({'metadata.json':b'{"synthetic":true}'});a=tool.Archive(good);self.assertEqual(a.json('metadata.json'),{'synthetic':True})
        with patch.object(a.package,'extractfile',side_effect=AssertionError('do not repeatedly decompress original gzip')):
            self.assertEqual(a.json('metadata.json'),{'synthetic':True})
        with self.assertRaises(ValueError):tool.Archive({**good,'sha256':'0'*64})
        for files,kind in [({'../escape':b'x'},None),({'native.npy':b'x'},None),({'metadata.json':b''},tarfile.SYMTYPE),({'x':b'a','x/y':b'b'},None)]:
            with self.assertRaises(ValueError):tool.Archive(archive_ref(files,kind))
        with self.assertRaises(ValueError):a.raw('metadata.json','0'*64)
        header=tarfile.TarInfo('oversized.json');header.size=17*1024**2;raw=gzip.compress(header.tobuf(format=tarfile.USTAR_FORMAT)+b'\0'*1024)
        ref={'bytes':len(raw),'sha256':tool.sha(raw),'base64':base64.b64encode(raw).decode()}
        with patch.object(tarfile.TarFile,'extractfile',side_effect=AssertionError('oversized member payload must never be read')):
            with self.assertRaises(ValueError):tool.Archive(ref)

    def test_no_pending_unexecuted_inputs_can_create_candidate(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);path=root/'spec.json';output=root/'must-not-exist'
            for document in ({'schema_version':1,'kind':'i04-public-render-inputs','actual_main_and_E02_verified':False},
                    {'schema_version':1,'kind':'i04-public-render-inputs','actual_main_and_E02_verified':True,'main_envelope':None,'E02_envelope':None}):
                raw=tool.encoded(document);path.write_bytes(raw)
                with self.assertRaises(ValueError):tool.render(path,tool.sha(raw),output)
                self.assertFalse(output.exists())

    def test_159_95_quantiles_and_target_coordinate_offset(self):
        for count,expected in ((159,1.42),(95,2.06)):
            a=[-2.]*count;b=a[:];b[:3]=[-3.,-4.,-5.];m=tool.calculate(a,b)
            self.assertAlmostEqual(m['p99_nat'],expected);self.assertAlmostEqual(m['mae_nat'],6/count);self.assertEqual(m['max_target_index_zero_based'],2)
        with self.assertRaises(ValueError):tool.calculate([-1.]*159,[-1.]*95)
        raw={'target_count':95,'side_a_nll_nat_per_token':1.,'side_b_nll_nat_per_token':2.,'nll_abs_diff_nat_per_token':1.,'mae_nat':1.,'p99_nat':1.,
            'p99_method':'global linear h=0.99*(N-1)','max_abs_nat':1.,'max_coordinate':{'sample':'private','position':95,'token':90000}}
        self.assertEqual(tool.target_metrics(raw)['max_target_index_zero_based'],94)

    def test_all18_846_rows_12vectors_preserve_values_and_remove_private_identities(self):
        source=SyntheticMain();runs,targets,dist=tool.collect_targets(source)
        self.assertEqual((len(runs),len(targets),sum(len(x['positions']) for x in dist)),(12,18,846))
        self.assertTrue(all(x['kind']=='cross_backend_matched' for x in targets[:6]));self.assertEqual(sum(r['target_count'] for r in runs),1524)
        for public,raw in zip(dist,source.report['target_distribution_pairs']):
            for a,b in zip(public['positions'],raw['distributions']['positions']):
                self.assertEqual(a['probability_rmse'],b['probability_rmse']);self.assertEqual(a['coverage'],b['coverage']);self.assertEqual(a['normalization_mass'],b['normalization_mass'])
            self.assertEqual(public['aggregate']['coverage'],raw['distributions']['aggregate']['coverage'])
        tool.privacy({'runs':runs,'pairs':targets,'distributions':dist})
        text=json.dumps([runs,targets,dist]);self.assertNotIn('90001',text);self.assertNotIn('private-input',text);self.assertNotIn('REDACTED_ACCOUNT',text)
        mismatch=dist[0]['positions'][0]['top1_mismatch'];self.assertEqual(mismatch['side_a_top1_candidate_index'],0);self.assertEqual(mismatch['side_b_top1_candidate_index'],1)
        self.assertEqual(mismatch['probabilities'][1]['side_b'],.4)

    def test_frozen_peer_vectors_history_coordinates_or_new_policy_cannot_silently_change(self):
        main=SyntheticMain();pair=main.report['target_distribution_pairs'][-1];main.docs[pair['targets']['sources']['side_a']]['scores'][0]['token']=127
        with self.assertRaises(ValueError):tool.collect_targets(main)
        main=SyntheticMain();first=main.report['target_distribution_pairs'][0];contract=main.docs[first['targets']['sources']['contract']]
        contract['side_conditions'][first['sides'][0]]['backend_policy']['unreviewed_fast_math']=True
        with self.assertRaises(ValueError):tool.collect_targets(main)

    def test_seven_artifact_templates_replay18_zero_arrays_and_tamper_rejection(self):
        main=SyntheticMain();e02=SyntheticE02(main);coverage={'synthetic_not_native':True,'full_core_complete':False}
        docs=tool.public_documents(main,e02,coverage);self.assertEqual(len(docs),7)
        self.assertIn(b'1792',docs['report.md']);self.assertIn(b'256',docs['report.md'])
        ast.parse(docs['replay-targets.py']);cost=json.loads(docs['execution-cost.json'])
        self.assertFalse(cost['P01_complete']);self.assertFalse(cost['headline_speed_comparison_supported']);self.assertIsNone(cost['total_currency_cost'])
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary)
            for name,raw in docs.items():(root/name).write_bytes(raw)
            argv=[sys.executable,'-S','-B',str(root/'replay-targets.py'),str(root/'selected-targets.json'),str(root/'selected-metrics.json')]
            result=subprocess.run(argv,capture_output=True,text=True);self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertEqual(json.loads(result.stdout)['arrays_read'],0);self.assertEqual(json.loads(result.stdout)['target_pairs_checked'],18)
            target=root/'selected-targets.json';raw=bytearray(target.read_bytes());raw[-2]=32;target.write_bytes(raw)
            result=subprocess.run(argv,capture_output=True,text=True);self.assertEqual(result.returncode,2)
            for name,raw in docs.items():(root/name).write_bytes(raw)
            metric=root/'selected-metrics.json';changed=json.loads(metric.read_bytes());changed['target_pairs'][0]['metrics']['mae_nat']+=1
            changed_raw=tool.encoded(changed);metric.write_bytes(changed_raw)
            script=(root/'replay-targets.py').read_text().replace(tool.sha(docs['selected-metrics.json']),tool.sha(changed_raw));(root/'replay-targets.py').write_text(script)
            result=subprocess.run(argv,capture_output=True,text=True);self.assertEqual(result.returncode,2)

    def test_allowlisted_coverage_counts_and_privacy_are_not_inferred(self):
        with tempfile.TemporaryDirectory() as temporary:
            p=Path(temporary)/'coverage.json';doc=json.loads((HERE.parents[4]/'site/evidence/gemma4-h100-ascend-partitions-20261107/coverage.json').read_bytes())
            p.write_bytes(tool.encoded(doc));ref={'path':str(p),'sha256':tool.sha(p.read_bytes())};self.assertEqual(tool.validated_coverage(ref),doc)
            doc['counts']['pending']+=1;p.write_bytes(tool.encoded(doc));ref['sha256']=tool.sha(p.read_bytes())
            with self.assertRaises(ValueError):tool.validated_coverage(ref)
            doc['counts']['pending']-=1;doc['tasks'][0]['task_id']='invented-49th-task';p.write_bytes(tool.encoded(doc));ref['sha256']=tool.sha(p.read_bytes())
            with self.assertRaises(ValueError):tool.validated_coverage(ref)
        for document in ({'device_uuid':'aaa'},{'allowed':'/srv/precision-user'},{'allowed':'REDACTED_PLATFORM_HOST'},{'token':123}):
            with self.assertRaises(ValueError):tool.privacy(document)


if __name__=='__main__':unittest.main()

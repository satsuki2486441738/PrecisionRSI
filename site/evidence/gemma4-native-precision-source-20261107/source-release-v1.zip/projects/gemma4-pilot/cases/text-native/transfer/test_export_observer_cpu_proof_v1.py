"""Synthetic original-byte protocol fixtures; never actual CPU/native proof."""
import base64
import copy
import hashlib
import json
import os
from pathlib import Path,PurePosixPath
import tarfile
import tempfile
import unittest
from unittest.mock import patch

import export_observer_cpu_proof_v1 as tool

HERE=Path(__file__).resolve().parent
PACKET=HERE.parent/'runs/compare-observer-cpu-source-package-20261106T201224Z/observer-cpu-prerequisite-v1.tar.gz'


class Fixture:
    def __init__(self,physical,virtual=False):
        self.root=Path(physical)/'R';self.root.mkdir();(self.root/'exports').mkdir()
        root=PurePosixPath('/synthetic/R') if virtual else PurePosixPath(self.root.as_posix())
        target=root/tool.SUBDIR;source=target/'source';run=target/'runs/compare-observer-tiny-cpu-20261106T204813Z'
        self.origins={'start':str(target/'cpu-start-once.json'),'attempt':str(target/'cpu-attempt-once.json'),'stage':str(target/'stage-receipt.json'),
            'manifest':str(target/'source-manifest.json'),'controller_start':str(run/'controller-start.json'),'controller':str(run/'controller-receipt.json'),
            'validation_stdout':str(target/'cpu-validation.stdout'),'validation_stderr':str(target/'cpu-validation.stderr'),
            'tests_stdout':str(run/'tests.stdout'),'tests_stderr':str(run/'tests.stderr'),'probe_stdout':str(run/'probe.stdout'),
            'probe_stderr':str(run/'probe.stderr'),'probe_receipt':str(run/'probe/receipt.json'),'runtime_map':str(run/'runtime-source-map.json')}
        self.origins.update({'code_'+name:str(source/value[0]) for name,value in tool.CODE.items()})
        self.origins.update({'runtime_'+name:str(run/('runtime-sources/'+name+'.py')) for name in tool.RUNTIME})
        self.files={}
        with tarfile.open(PACKET,'r:gz') as package:
            self.files['manifest']=package.extractfile('source-manifest.json').read()
            for name,value in tool.CODE.items():self.files['code_'+name]=package.extractfile('source/'+value[0]).read()
        for name in tool.RUNTIME:self.files['runtime_'+name]=('# synthetic package source '+name+'\n').encode()
        def ref(name):return {'path':self.origins[name],'sha256':tool.sha(self.files[name]),'size_bytes':len(self.files[name])}
        def add(name,document):self.files[name]=tool.encoded(document)
        python=str(root/'venv/bin/python')
        add('start',{'status':'observer_tiny_CPU_spawned_not_result','pid':999999999,'starttime':0,
            'source_sha256':tool.CODE['operations'][1],'source_manifest_sha256':tool.MANIFEST_SHA,'whole_cpu_seconds':210,'cleanup_reserve_seconds':20,
            'production_model_loads':0,'native_executions_started':0,'native_claim_created':False,'automatic_retry':False,
            'argv':[python,'-S','-B',str(source/tool.CODE['operations'][0]),'run','--root',str(root),'--manifest-sha256',tool.MANIFEST_SHA],
            'stdout':self.origins['validation_stdout'],'stderr':self.origins['validation_stderr']})
        add('stage',{'status':'observer_cpu_sources_staged_not_native','source_files':5,'manifest_sha256':tool.MANIFEST_SHA,'archive_sha256':tool.ARCHIVE_SHA,
            'production_model_loads':0,'native_executions_started':0,'native_claim_created':False})
        add('attempt',{'manifest_sha256':tool.MANIFEST_SHA,'native_claim_created':False,'native_executions_started':0,'automatic_retry':False})
        self.files['validation_stderr']=b'';self.files['tests_stdout']=b'';self.files['tests_stderr']=b'\nRan 14 tests in 0.001s\n\nOK\n';self.files['probe_stderr']=b''
        aliases={name:{'source':{'path':'/synthetic/base/site-packages/'+name+'/__init__.py','sha256':tool.sha(self.files['runtime_'+name]),
            'size_bytes':len(self.files['runtime_'+name])},'copy':ref('runtime_'+name)} for name in tool.RUNTIME};add('runtime_map',aliases)
        modes=['off-before','hooks-only','off-after','hooks-plus-dispatch-metadata'];phases=[{'phase':p,'torch_npu_imported':False,
            'npu_namespace_registered':False,'npu_initialized':None,'cuda_initialized':False} for p in ('after_torch','before_tiny_cpu_calls','after_tiny_cpu_calls')]
        add('probe_receipt',{'task':'observer-tiny-cpu-prerequisite-v1','status':'completed','returncode':0,'timeout_seconds':90,
            'source':ref('code_probe'),'collectors_source':ref('code_collector'),'production_model_loads':0,'production_model_forward_calls':0,
            'agent_hardware_or_availability_queries':0,'agent_accelerator_initialization_requests':0,'library_internal_availability_queries':'not instrumented',
            'versions':{'torch':'2.9.0+cpu','numpy':'1.26.4','safetensors':'synthetic'},'phase_observations':phases,
            'runtime_sources':{name:item['source'] for name,item in aliases.items()},
            'result':{'checks_passed':29,'checks':['synthetic protocol check%d'%i for i in range(29)],'tiny_cpu_forward_calls':5,
                'production_model_loads':0,'production_model_forward_calls':0,'production_boundary_count':98,'tiny_boundary_count':4,'tiny_module_count':5,
                'mode_outputs':[{'mode':mode,'raw_bits_sha256':'a'*64,'artifact':{'path':str(run/('probe/'+mode+'.safetensors')),'sha256':'b'*64,'size_bytes':256}} for mode in modes],
                'selected_samples':{'path':str(run/'probe/boundary-samples.safetensors'),'sha256':'c'*64,'size_bytes':512}}})
        add('probe_stdout',{'status':'completed','receipt':self.origins['probe_receipt'],'receipt_sha256':tool.sha(self.files['probe_receipt']),'checks_passed':29})
        common={'task':'observer-cpu-validation-v1','started_utc':'2026-11-06T20:48:13+00:00','source_manifest_sha256':tool.MANIFEST_SHA,
            'source_root':str(source),'whole_cpu_seconds':210,'cleanup_reserve_seconds':20}
        add('controller_start',{**common,'status':'running'})
        steps=[]
        argvs=[[python,'-S','-B','-m','unittest','test_observer_collectors_v1','-v'],
            [python,'-B',str(source/tool.CODE['probe'][0]),'--collectors',str(source/tool.CODE['collector'][0]),'--collectors-sha256',tool.CODE['collector'][1],
                '--output',str(run/'probe')]]
        for i,(prefix,timeout) in enumerate(zip(('tests','probe'),(30,120))):
            steps.append({'argv':argvs[i],'returncode':0,'timed_out':False,'timeout_seconds':timeout,'cleanup':{'owned_process_group':10000+i,'remaining_owned_process_group':False},
                **{stream:{'path':self.origins[prefix+'_'+stream],'sha256':tool.sha(self.files[prefix+'_'+stream]),'bytes':len(self.files[prefix+'_'+stream])} for stream in ('stdout','stderr')}})
        add('controller',{**common,'status':'completed','returncode':0,'native_executions_started':0,'production_model_loads':0,'native_claim_created':False,
            'automatic_retry':False,'pure_tests':14,'pure_test_skips':0,'actual_tiny_probe_checks':29,'remaining_owned_process_groups':[],'elapsed_seconds':1.25,
            'steps':steps,'probe':ref('probe_receipt'),'runtime_source_map':ref('runtime_map')})
        add('validation_stdout',{'status':'completed','returncode':0,'receipt':ref('controller'),'pure_tests':14,'actual_tiny_probe_checks':29,'error':None})
        self.controller_sha=tool.sha(self.files['controller']);self.probe_sha=tool.sha(self.files['probe_receipt']);self.run=run
    def pins(self):
        from contextlib import ExitStack
        stack=ExitStack();stack.enter_context(patch.object(tool,'ACTUAL_CONTROLLER_SHA',self.controller_sha));stack.enter_context(patch.object(tool,'ACTUAL_PROBE_SHA',self.probe_sha));return stack
    def materialize(self):
        for name,raw in self.files.items():
            path=Path(self.origins[name]);assert path.is_relative_to(self.root);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
    def portable(self,folder):
        folder=Path(folder);folder.mkdir();(folder/'proof').mkdir();catalog={}
        for index,(name,raw) in enumerate(sorted(self.files.items())):
            member='proof/%02d-%s.txt'%(index,name);(folder/member).write_bytes(raw)
            catalog[name]={'path':member,'source_path':self.origins[name],'sha256':tool.sha(raw),'size_bytes':len(raw)}
        summary=tool.audit(self.files,self.origins);document={'schema_version':1,'kind':'observer-tiny-cpu-prerequisite-v1','native_prerequisite_valid':True,'files':catalog,'summary':summary}
        path=folder/'prerequisite.json';path.write_bytes(tool.encoded(document));return path


class Protocol(unittest.TestCase):
    def test24_raw_portable_original_bytes_runtime_alias_and_machine_SHA(self):
        with tempfile.TemporaryDirectory() as temporary:
            fixture=Fixture(temporary,True)
            with fixture.pins():
                path=fixture.portable(Path(temporary)/'portable');proof=tool.verify_portable(path,tool.sha(path.read_bytes()))
                self.assertEqual(len(proof['refs']),24);self.assertEqual(proof['document']['summary']['actual_tiny_probe_checks'],29)
                self.assertEqual(len(proof['document']['summary']['runtime_source_aliases']),5)
                with self.assertRaisesRegex(ValueError,'external'):tool.verify_portable(path,'0'*64)

    def test_failed_diagnostic_or_changed_runtime_source_cannot_be_prerequisite(self):
        with tempfile.TemporaryDirectory() as temporary:
            fixture=Fixture(temporary,True)
            with fixture.pins():
                path=fixture.portable(Path(temporary)/'portable');doc=tool.parse(path.read_bytes());item=doc['files']['runtime_torch']
                (path.parent/item['path']).write_bytes(b'# changed frozen source\n')
                with self.assertRaisesRegex(ValueError,'bytes differ'):tool.verify_portable(path,tool.sha(path.read_bytes()))
                doc['kind']='observer-cpu-failed-diagnostic-v1';doc['native_prerequisite_valid']=False;path.write_bytes(tool.encoded(doc))
                with self.assertRaisesRegex(ValueError,'not a native'):tool.verify_portable(path,tool.sha(path.read_bytes()))

    def test_resigned_context_initialized_alias_or_unclean_group_metadata_rejected(self):
        for mutate in ('context','alias','group','argv'):
            with self.subTest(mutate=mutate),tempfile.TemporaryDirectory() as temporary:
                fixture=Fixture(temporary,True)
                if mutate=='context':
                    doc=tool.parse(fixture.files['probe_receipt']);doc['phase_observations'][-1]['cuda_initialized']=True;fixture.files['probe_receipt']=tool.encoded(doc)
                elif mutate=='alias':
                    doc=tool.parse(fixture.files['runtime_map']);doc['torch']['source']['sha256']='0'*64;fixture.files['runtime_map']=tool.encoded(doc)
                else:
                    doc=tool.parse(fixture.files['controller'])
                    if mutate=='group':doc['steps'][1]['cleanup']['remaining_owned_process_group']=True
                    else:doc['steps'][1]['argv'][-1]='/synthetic/wrong-output'
                    fixture.files['controller']=tool.encoded(doc)
                # Re-sign outer pointers to test semantic closure as well as the
                # first immutable externally observed raw-controller SHA gate.
                with fixture.pins(),self.assertRaises(ValueError):tool.audit(fixture.files,fixture.origins)

    @unittest.skipUnless(os.name=='posix','original source-host export protocol is POSIX')
    def test_success_export25_regular_members_envelope_and_zero_array_reads(self):
        with tempfile.TemporaryDirectory() as temporary:
            fixture=Fixture(temporary);fixture.materialize()
            def guard(method):
                def wrapped(path,*args,**kwargs):
                    if str(path).endswith(('.npy','.safetensors')):raise AssertionError('tensor payload must not be touched')
                    return method(path,*args,**kwargs)
                return wrapped
            with fixture.pins(),patch.object(Path,'stat',guard(Path.stat)),patch.object(Path,'open',guard(Path.open)),patch.object(Path,'is_file',guard(Path.is_file)):
                result=tool.export(fixture.root,fixture.root/'exports/actual-cpu-proof')
            self.assertTrue(result['native_prerequisite_valid']);self.assertEqual(result['regular_members'],25)
            envelope=tool.parse(Path(result['envelope']['path']).read_bytes());raw=base64.b64decode(envelope['archive']['base64'],validate=True)
            self.assertEqual(tool.sha(raw),envelope['archive']['sha256'])
            with tarfile.open(result['archive']['path'],'r:gz') as package:
                members=package.getmembers();self.assertEqual(len(members),25);self.assertTrue(all(x.type==tarfile.REGTYPE for x in members))
                for m in members:self.assertEqual(tool.sha(package.extractfile(m).read()),envelope['files'][m.name]['sha256'])
            self.assertEqual(result['tiny_CPU_tensor_payloads_opened_or_copied'],0)

    @unittest.skipUnless(os.name=='posix','original source-host export protocol is POSIX')
    def test_failed_CPU_exports_diagnostic_only_preserving_original_bytes(self):
        with tempfile.TemporaryDirectory() as temporary:
            fixture=Fixture(temporary);fixture.materialize();path=Path(fixture.origins['controller']);doc=tool.parse(path.read_bytes());doc['status']='failed';doc['returncode']=2;path.write_bytes(tool.encoded(doc));original=path.read_bytes()
            with fixture.pins():result=tool.export(fixture.root,fixture.root/'exports/failed-cpu-proof')
            self.assertFalse(result['native_prerequisite_valid']);self.assertEqual(result['status'],'observer_CPU_diagnostic_exported_not_prerequisite')
            wrapper=tool.parse(Path(result['wrapper_path']).read_bytes());item=wrapper['files']['controller']
            self.assertEqual((Path(result['wrapper_path']).parent/item['path']).read_bytes(),original)
            with self.assertRaisesRegex(ValueError,'not a native'):tool.verify_portable(result['wrapper_path'],result['wrapper_sha256'])

    def test_portable_link_escape_output_source_types_and_pending_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            fixture=Fixture(temporary,True)
            with fixture.pins():
                path=fixture.portable(Path(temporary)/'portable');doc=tool.parse(path.read_bytes());doc['files']['start']['path']='../outside'
                path.write_bytes(tool.encoded(doc))
                with self.assertRaisesRegex(ValueError,'relative'):tool.verify_portable(path,tool.sha(path.read_bytes()))
                with self.assertRaisesRegex(ValueError,'descriptor-only'):tool.original(Path(temporary)/'native.npy')


if __name__=='__main__':unittest.main()

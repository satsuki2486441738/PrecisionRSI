"""Validate three real Ascend candidate-v3 recorder runs and within-NPU repeats.

Run this beside retained arrays for full checks. A downloaded small bundle can
use --source-map and --metadata-only: it replays recorded target scores but does
not claim to validate or replay the retained full distributions. No GPU run,
cross-backend admission, execution receipt or acceptance decision is fabricated.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
from pathlib import Path, PurePosixPath
import re
import sys
import uuid

import numpy as np

REPO = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(REPO / 'skills/precision-compare/scripts'))
from conditions import canonical, load_json
from compare_distributions import compare as compare_distributions
from compare_target_scores import compare as compare_targets
from validate_artifacts import validate
from record_execution_v2 import REQUIRED_DEPENDENCIES, POLICIES

REVISION = '1a2c7729392586f5ecddae8807ee2ef741eabb9a'
INPUT_SHA = '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
COLLECTOR_SHA = '95b7b9302543d8a14995e293c790d5de9e23abc6041a53bb1d627ae3b5cd7ee8'
DRIVER_SOURCE = '/usr/local/Ascend/driver/version.info'
DRIVER_SOURCE_SHA = '1bc07a765a4b4c765510ec7979113ea03b0217f1dcc0c2eb4646d011d7f88902'
DRIVER_VERSION = '25.5.2'
GIB = 1024 ** 3
METADATA_SHA = '80dc0e0e59e5c526426b566d36a21f762a79d498986d5d6cd01098c8cb5decc3'
HEX64 = re.compile(r'^[a-f0-9]{64}$')
NORMALIZATION = 'Offline NumPy float64 log_softmax of copied native values'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def put(path, document):
    with Path(path).open('x', encoding='utf-8') as f:
        json.dump(document, f, indent=2, allow_nan=False); f.write('\n')


def origin(value):
    require(isinstance(value, str) and PurePosixPath(value).is_absolute() and
            '..' not in PurePosixPath(value).parts, 'original source must be an absolute POSIX path')
    return str(PurePosixPath(value))


def child(root, name):
    return str(PurePosixPath(origin(root)) / name)


class Sources:
    def __init__(self, source_map=None):
        self.manifest_path = Path(source_map).resolve(strict=True) if source_map else None
        self.document = load_json(self.manifest_path) if self.manifest_path else None
        self.files = self.document['files'] if self.document else None
        if self.document:
            require(self.document.get('schema_version') == 1 and isinstance(self.files, dict), 'invalid source map')
        self.checked = {}

    def get(self, name, expected=None):
        name = origin(name)
        if self.files is None:
            path = Path(name).resolve(strict=True)
        else:
            entry = self.files[name]
            require(isinstance(entry, dict) and isinstance(entry.get('sha256'), str) and
                    HEX64.fullmatch(entry['sha256']), 'invalid mapped source digest')
            if entry.get('retained_at_source') is True:
                raise FileNotFoundError('full array retained at original source: ' + name)
            path = (self.manifest_path.parent / entry['path']).resolve(strict=True)
            require(path.is_relative_to(self.manifest_path.parent) and path.is_file(), 'mapped file escapes bundle')
            require(path.stat().st_size == entry['size'] and sha(path) == entry['sha256'], 'mapped source changed')
        require(path.is_file(), 'source is not a regular file')
        actual = self.checked.setdefault(name, sha(path))
        require(expected is None or actual == expected, 'source SHA mismatch: ' + name)
        return path

    def optional(self, name):
        name = origin(name)
        if self.files is not None and name not in self.files:
            return None
        path = Path(name) if self.files is None else None
        if path is not None and not path.is_file():
            return None
        return self.get(name)

    def row_inventory(self, artifacts, suffix):
        if self.files is None:
            return {str(p.resolve()) for p in Path(artifacts).glob('row-*' + suffix)}
        return {name for name in self.files if str(PurePosixPath(name).parent) == artifacts and
                re.fullmatch(r'row-\d+' + re.escape(suffix), PurePosixPath(name).name)}


def argument(argv, flag):
    require(argv.count(flag) == 1 and not any(x.startswith(flag + '=') for x in argv), 'ambiguous argv ' + flag)
    index = argv.index(flag)
    require(index + 1 < len(argv), 'missing argv value ' + flag)
    return argv[index + 1]


def utc_time(value):
    require(isinstance(value,str), 'execution UTC timestamp absent')
    parsed=datetime.fromisoformat(value.replace('Z','+00:00'))
    require(parsed.tzinfo is not None and parsed.utcoffset().total_seconds() == 0, 'execution timestamp is not UTC')
    return parsed.astimezone(timezone.utc)


def snapshot_identity(receipt, metadata, model_class):
    require(receipt.get('status') == 'verified' and receipt.get('repository') == 'google/gemma-4-12B'
            and receipt.get('revision') == REVISION, 'snapshot receipt identity is not verified')
    entries = receipt.get('files')
    require(isinstance(entries, list) and all(isinstance(x, dict) for x in entries), 'snapshot receipt files missing')
    indexed = {x.get('file'): x for x in entries}
    expected = {x['rfilename']: x for x in metadata['files']}
    require(len(indexed) == len(entries) == len(expected) == 8 and set(indexed) == set(expected), 'eight-file model coverage differs')
    result = {'repository': 'google/gemma-4-12B', 'revision': REVISION, 'model_class': model_class}
    for name, item in expected.items():
        record = indexed[name]
        wanted = item['lfs']['sha256'] if 'lfs' in item else item['blobId']
        require(record.get('verified') is True and record.get('actual_size') == item['size'] and
                record.get('actual_expected_algorithm_digest') == wanted and
                isinstance(record.get('actual_sha256'), str) and HEX64.fullmatch(record['actual_sha256']),
                'snapshot file identity differs: ' + name)
        if 'lfs' in item:
            require(record['actual_sha256'] == wanted, 'snapshot LFS SHA differs')
        result[name + '_sha256'] = record['actual_sha256']
    return result


def verify_driver_provenance(runtime, receipt, sources, artifacts):
    """Check the recorded API error/return and exact frozen native metadata bytes."""
    driver_source=origin(argument(receipt['argv'],'--driver-source'))
    require(driver_source==DRIVER_SOURCE and driver_source in receipt['dependency_paths'] and
            receipt['source_sha256'].get(driver_source)==DRIVER_SOURCE_SHA,
            'installed native driver metadata was not the pinned executed dependency')
    actual=sources.get(driver_source,DRIVER_SOURCE_SHA).read_bytes()
    values={}
    for line in actual.decode('utf-8').splitlines():
        if not line.strip() or line.lstrip().startswith('#'): continue
        key,separator,value=line.partition('=');key=key.strip()
        if not separator or key not in ('Version','package_version'): continue
        require(key not in values,'duplicate installed native driver version key')
        values[key]=value.strip()
    require(values.get('Version')==DRIVER_VERSION and values.get('package_version',DRIVER_VERSION)==DRIVER_VERSION,
            'installed native driver package Version differs')
    digest=runtime.get('driver_version_provenance_sha256')
    require(isinstance(digest,str) and HEX64.fullmatch(digest),'driver provenance file digest missing')
    provenance=load_json(sources.get(child(artifacts,'driver-version-provenance.json'),digest))
    require(isinstance(provenance,dict) and canonical(provenance)==canonical(runtime.get('driver_version_provenance')),
            'driver provenance file differs from checked runtime')
    native=provenance.get('native_source',{});api=provenance.get('api',{})
    require(isinstance(native,dict) and native.get('path')==driver_source and native.get('resolved_path')==driver_source and
            native.get('sha256')==DRIVER_SOURCE_SHA and type(native.get('size_bytes')) is int and
            native['size_bytes']==len(actual) and native.get('selected_key')=='Version' and
            native.get('parsed_version')==DRIVER_VERSION and native.get('package_version')==values.get('package_version') and
            provenance.get('selected_version')==DRIVER_VERSION and
            provenance.get('selected_source')=='native_driver_version_info' and
            runtime['versions'].get('driver')==DRIVER_VERSION,'native driver provenance identity differs')
    require(isinstance(api,dict) and api.get('call')=="torch_npu.utils.get_cann_version('DRIVER')",
            'native driver API observation absent')
    if api.get('status')=='error':
        require(provenance.get('fallback_used') is True and
                all(isinstance(api.get(k),str) and api[k].strip() for k in ('error_type','error','traceback')),
                'driver API failure was not retained verbatim in fallback provenance')
    else:
        require(api.get('status')=='returned' and provenance.get('fallback_used') is False and
                api.get('parsed_version')==DRIVER_VERSION and isinstance(api.get('value'),str) and
                api['value'].strip()==DRIVER_VERSION,'driver API result conflicts with installed package metadata')
    return provenance


def verify_binding(runtime, receipt, sources, allocation_source, mapping_source, native_source):
    allocation = load_json(sources.get(allocation_source))
    mapping = load_json(sources.get(mapping_source))
    native = load_json(sources.get(native_source))
    dependencies = receipt['dependency_paths']
    require(all(x in dependencies for x in (allocation_source, mapping_source, native_source)), 'binding sources were not frozen dependencies')
    require(argument(receipt['argv'], '--allocation-receipt') == allocation_source and
            runtime.get('allocation_receipt_sha256') == sha(sources.get(allocation_source)), 'runtime allocation differs')
    device = runtime.get('device')
    require(device == 'npu:0' and allocation.get('vendor') == 'Ascend' and
            type(allocation.get('visible_count')) is int and allocation['visible_count'] == 8 and
            type(allocation.get('logical_ordinal')) is int and allocation['logical_ordinal'] == 0,
            'allocation or selected logical device differs')
    physical = allocation.get('physical_device_id')
    require(isinstance(physical, str) and str(uuid.UUID(physical)) == physical and uuid.UUID(physical).int,
            'actual native UUID is missing or unavailable')
    require(runtime.get('runtime_uuid') == physical and mapping.get('runtime_uuid') == physical and
            mapping.get('physical_device_id') == physical and mapping.get('method') == 'runtime_uuid' and
            mapping.get('vendor') == 'Ascend' and mapping.get('allocation_id') == allocation.get('allocation_id') and
            mapping.get('device') == device and mapping.get('logical_ordinal') == 0 and mapping.get('visible_count') == 8,
            'native UUID or mapping differs')
    require(all(isinstance(allocation.get(k), str) and allocation[k].strip()
                for k in ('allocation_id', 'evidence_source')), 'allocation identifier or evidence source absent')
    source = mapping.get('source', {})
    require(source.get('source_path') == native_source and source.get('file', {}).get('sha256') == sha(sources.get(native_source)),
            'native mapping source identity differs')
    source_ref = source.get('file', {}).get('path')
    require(isinstance(source_ref, str) and str(PurePosixPath(mapping_source).parent / source_ref) == native_source,
            'native mapping file reference resolves to another source')
    acl = native.get('cann_user_physical_mapping', {})
    observed = acl.get('value', {})
    require(native.get('native_requested') is True and acl.get('ok') is True and
            native.get('status') == 'native_observations_recorded_needs_allocation_mapping_review' and
            type(native.get('availability', {}).get('visible_count')) is int and native['availability']['visible_count'] == 8 and
            type(native.get('device', {}).get('current_ordinal')) is int and native['device']['current_ordinal'] == 0 and
            all(type(observed.get(k)) is int and observed[k] == 0 for k in
                ('user_ordinal','reverse_user_ordinal','forward_returncode','reverse_returncode')) and
            type(observed.get('physical_device_id')) is int and observed['physical_device_id'] >= 0 and
            native.get('device', {}).get('runtime_uuid') == physical, 'native mapping API observations differ')
    return physical


def read_run(label, root, input_source, document, sources, allocation_source, mapping_source, native_source,
             metadata_only=False):
    root = origin(root); artifacts = child(root, 'artifacts')
    receipt = load_json(sources.get(child(root, 'recorder/receipt.json')))
    require(receipt.get('schema_version') == 2 and receipt.get('backend') == 'NPU' and
            receipt.get('status') == 'completed' and type(receipt.get('returncode')) is int and receipt['returncode'] == 0,
            'native recorder-v2 did not complete successfully')
    require(receipt.get('capture_output') == artifacts and receipt.get('input_path') == input_source,
            'original input/output path differs from executed collector')
    argv = receipt.get('argv')
    require(isinstance(argv, list) and len(argv) > 3 and all(isinstance(x, str) and x for x in argv), 'collector argv absent')
    script_index = 2 if argv[1] == '-B' else 1
    require(argv[script_index] == receipt.get('collector_path') and argument(argv, '--input') == input_source and
            argument(argv, '--output') == artifacts and argument(argv, '--device') == 'npu:0', 'actual collector argv differs')
    require(receipt.get('collector_sha256') == COLLECTOR_SHA and receipt.get('input_sha256') == sha(sources.get(input_source)),
            'collector or fixed input digest differs')
    dependencies = receipt.get('dependency_paths'); inventory = receipt.get('source_sha256')
    require(isinstance(dependencies, list) and len(set(dependencies)) == len(dependencies) and isinstance(inventory, dict) and
            set(inventory) == {receipt['collector_path'], input_source, *dependencies}, 'recorder source inventory differs')
    require(REQUIRED_DEPENDENCIES['NPU'] <= {PurePosixPath(p).name for p in dependencies} and
            len({PurePosixPath(p).name for p in dependencies}) == len(dependencies), 'required dependency closure differs')
    require(inventory[receipt['collector_path']] == COLLECTOR_SHA and inventory[input_source] == receipt['input_sha256'],
            'recorded source inventory disagrees with execution identity')
    for original, digest in inventory.items():
        require(isinstance(digest, str) and HEX64.fullmatch(digest), 'invalid execution source hash')
        sources.get(original, digest)
    metadata_source = next(p for p in dependencies if PurePosixPath(p).name == 'upstream-identity.json')
    require(sha(sources.get(metadata_source)) == METADATA_SHA, 'upstream metadata changed')
    metadata = load_json(sources.get(metadata_source))
    native_hashes = receipt.get('native_evidence_sha256', {})
    native = {}
    for name in ('runtime.json', *POLICIES['NPU'], 'snapshot-verification.json'):
        native[name] = load_json(sources.get(child(artifacts, name), native_hashes.get(name)))
        require(isinstance(native_hashes.get(name), str), 'native execution hash missing')
    require(isinstance(receipt.get('status_sha256'),str) and HEX64.fullmatch(receipt['status_sha256']), 'completion status hash absent')
    status_path = sources.get(child(artifacts, 'status.json'), receipt['status_sha256'])
    status = load_json(status_path)
    require(status.get('status') == 'completed' and type(status.get('rank')) is int and status['rank'] == 0,
            'capture status is not completed rank zero')
    runtime = native['runtime.json']; policy = runtime.get('math_policy')
    require(runtime.get('input_sha256') == receipt['input_sha256'] and runtime.get('requested_revision') == REVISION and
            runtime.get('model_repository') == 'google/gemma-4-12B' and runtime.get('model_type') == 'gemma4_unified' and
            runtime.get('model_class') == 'Gemma4UnifiedForConditionalGeneration' and
            runtime.get('observed_config_commit') in (None, REVISION) and
            runtime.get('parameter_dtypes') == ['torch.bfloat16'] and runtime.get('actual_attention') == 'eager' and
            runtime.get('logprob_dtype') == 'float64' and runtime.get('seed') == 0, 'native model/input/numerics differ')
    require(isinstance(policy, dict) and canonical(policy) == canonical(native[POLICIES['NPU'][0]]) ==
            canonical(native[POLICIES['NPU'][1]]), 'actual policy changed during capture')
    expected_policy = {'float32_matmul_precision': 'highest', 'matmul_allow_hf32': False,
        'conv_allow_hf32': True, 'deterministic_algorithms': False, 'deterministic_warn_only': False, 'pythonhashseed': '0'}
    require(all(k in policy and type(policy[k]) is type(v) and policy[k] == v for k, v in expected_policy.items()), 'NPU policy differs')
    versions = runtime.get('versions')
    require(isinstance(versions, dict) and {'torch','torch_npu','transformers','cann','driver'} <= set(versions) and
            all(isinstance(v, str) and v for v in versions.values()) and
            versions.get('torch', '').split('+')[0] == '2.9.0' and versions.get('torch_npu') == '2.9.0.post2' and
            versions.get('transformers') == '5.10.1', 'actual native stack differs')
    verify_driver_provenance(runtime,receipt,sources,artifacts)
    physical = verify_binding(runtime, receipt, sources, allocation_source, mapping_source, native_source)
    started, finished = utc_time(receipt.get('started_utc')), utc_time(receipt.get('finished_utc'))
    require(started < finished, 'execution time interval is invalid')
    round_source=child(root,'round-native-preflight.json')
    require(round_source in dependencies, 'fresh round preflight was not an execution dependency')
    preflight=load_json(sources.get(round_source))
    require(preflight.get('status') == 'preflight_passed' and preflight.get('runtime_uuid') == physical and
            preflight.get('bf16') is True and type(preflight.get('visible_count')) is int and preflight['visible_count'] == 8 and
            type(preflight.get('logical_ordinal')) is int and preflight['logical_ordinal'] == 0 and
            preflight.get('allocation_id') == load_json(sources.get(allocation_source))['allocation_id'] and
            isinstance(preflight.get('policy'),dict) and
            set(preflight['policy'])=={'float32_matmul_precision','matmul_allow_hf32','conv_allow_hf32'} and
            canonical(preflight['policy'])==canonical({k:policy[k] for k in preflight['policy']}) and
            type(preflight.get('free_bytes')) is int and preflight['free_bytes']>=35*GIB and
            type(preflight.get('total_bytes')) is int and preflight['total_bytes']>=preflight['free_bytes'] and
            type(preflight.get('host_memory',{}).get('effective_available_bytes')) is int and
            preflight['host_memory']['effective_available_bytes']>=80*GIB and
            preflight['host_memory'].get('minimum_bytes')==80*GIB and
            all(preflight.get('versions', {}).get(k) == versions[k] for k in ('torch','torch_npu','transformers')) and
            utc_time(preflight.get('utc')) <= started, 'fresh round preflight differs from captured runtime')
    model = snapshot_identity(native['snapshot-verification.json'], metadata, runtime['model_class'])
    require(native['snapshot-verification.json'].get('upstream_metadata_sha256') == METADATA_SHA, 'snapshot metadata pin differs')
    before = sources.optional(child(artifacts, 'policy-before-load.json'))
    if before is not None:
        require(canonical(load_json(before).get('configured')) == canonical(policy), 'configured policy differs from observed policy')
    exported = load_json(sources.get(child(artifacts, 'exported-records.json')))
    events = load_json(sources.get(child(artifacts, 'events.json')))
    summary = load_json(sources.get(child(artifacts, 'capture-summary.json')))
    sample, prompt, targets = (document[k] for k in ('sample', 'prompt', 'continuation'))
    count = len(targets); shapes = summary.get('native_logits_shapes')
    require(isinstance(shapes, list) and len(shapes) == count and len(shapes[0]) == 3, 'native logit shape inventory differs')
    vocab = shapes[0][2]
    require(type(vocab) is int and vocab >= 100 and shapes == [[1, len(prompt), vocab]] + [[1, 1, vocab]] * (count-1), 'native logits shape differs')
    require(summary.get('sampled_distributions') == count and not summary.get('unavailable_targets') and
            not exported.get('unavailable_targets') and len(exported.get('positions', [])) == len(exported.get('scores', [])) == len(events) == count,
            'incomplete captured coordinate inventory')
    require(len(receipt.get('row_sha256', [])) == len(receipt.get('record_sha256', [])) == count, 'recorder row hash inventory differs')
    require(all(isinstance(h, str) and HEX64.fullmatch(h) for h in receipt['row_sha256'] + receipt['record_sha256']),
            'invalid captured file hash inventory')
    for suffix in ('.json', '.npy'):
        expected = {child(artifacts, 'row-%03d%s' % (i, suffix)) for i in range(count)}
        require(sources.row_inventory(artifacts, suffix) == expected, 'extra or missing raw row inventory')
    positions, target_positions, scores, selected = [], [], [], []
    for step, token in enumerate(targets):
        prediction = len(prompt)-1+step; history = prompt+targets[:step]
        coordinate = {'sample': sample, 'position': prediction, 'history': history}
        target_coordinate = {'sample': sample, 'position': prediction+1, 'token': token}
        event = {'stage': 'prefill' if step == 0 else 'decode', 'input_ids': prompt if step == 0 else [targets[step-1]],
            'positions': list(range(len(prompt))) if step == 0 else [prediction], 'prefix_length': 0 if step == 0 else prediction}
        require(canonical(events[step]) == canonical(event), 'native prefill/decode history differs')
        record_source = child(artifacts, 'row-%03d.json' % step)
        array_source = child(artifacts, 'row-%03d.npy' % step)
        record = load_json(sources.get(record_source, receipt['record_sha256'][step]))
        expected = {**coordinate, 'step': step, 'token': token, 'rank': 0, 'boundary': 'before_constraint',
            'logits_dtype': 'torch.bfloat16', 'logprob_dtype': 'float64', 'normalization': NORMALIZATION}
        require(all(k in record and canonical(record[k]) == canonical(v) for k,v in expected.items()), 'raw capture record provenance differs')
        descriptor = record.get('scores')
        require(isinstance(descriptor, dict) and descriptor == {'path': 'row-%03d.npy' % step, 'row': 0}, 'raw row descriptor differs')
        observed = exported['positions'][step]; score = exported['scores'][step]
        require(all(canonical(observed.get(k)) == canonical(v) for k,v in coordinate.items()) and
                all(canonical(score.get(k)) == canonical(v) for k,v in target_coordinate.items()), 'exported coordinates differ')
        require(type(observed.get('scores', {}).get('row')) is int and observed['scores']['row'] == 0 and
                str(PurePosixPath(artifacts) / observed['scores']['path']) == array_source, 'exported row source differs')
        value = record.get('logprob')
        require(type(value) in (float, int) and type(score.get('logprob')) in (float, int) and
                math.isfinite(value) and value <= 0 and value == score.get('logprob'), 'recorded target logprob differs')
        if not metadata_only:
            arr_path = sources.get(array_source, receipt['row_sha256'][step])
            array = np.load(arr_path, mmap_mode='r', allow_pickle=False)
            require(array.shape == (vocab,) and array.dtype == np.dtype('float64') and np.isfinite(array).all(), 'full distribution values/shape/dtype differ')
            require(0 <= token < vocab and float(array[token]) == value, 'target does not equal captured full-vocabulary row')
            positions.append({**coordinate, 'scores': {'path': str(arr_path), 'row': 0}})
            del array
        target_positions.append(target_coordinate); scores.append({**target_coordinate, 'logprob': value})
        selected.append({'step': step, 'target_logprob': value, 'record_sha256': receipt['record_sha256'][step],
                         'row_sha256': receipt['row_sha256'][step]})
    return {'side': label, 'root': root, 'status_path': str(status_path), 'model': model,
        'hardware': {'category': 'NPU', 'model': runtime['device_name']}, 'software': {'framework': 'torch', **versions},
        'backend_policy': policy, 'runtime_uuid': physical, 'vocab': vocab, 'positions': positions,
        'targets': target_positions, 'scores': scores, 'selected': selected,
        'receipt_source': child(root, 'recorder/receipt.json'), 'receipt_sha256': sha(sources.get(child(root, 'recorder/receipt.json'))),
        'started_utc':receipt['started_utc'], 'finished_utc':receipt['finished_utc'], 'array_values_checked': not metadata_only}


def summarize(input_source, run_sources, allocation_source, mapping_source, native_source, output, source_map=None,
              metadata_only=False):
    sources = Sources(source_map); input_source = origin(input_source)
    inp = sources.get(input_source); document = load_json(inp)
    require(sha(inp) == INPUT_SHA and len(document.get('prompt', [])) == 128 and len(document.get('continuation', [])) == 32,
            'input is not frozen discovery 001 at 128 + 32')
    require(len(run_sources) == 3 and len(set(run_sources)) == 3 and len(set(run_sources.values())) == 3 and
            all(re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', x) for x in run_sources), 'three distinct repeat side IDs and roots required')
    runs = [read_run(label, root, input_source, document, sources, origin(allocation_source), origin(mapping_source),
                    origin(native_source), metadata_only) for label, root in run_sources.items()]
    signature = lambda r: canonical({k:r[k] for k in ('model', 'hardware', 'software', 'backend_policy', 'runtime_uuid', 'vocab', 'targets')})
    require(all(signature(r) == signature(runs[0]) for r in runs[1:]), 'NPU repeated conditions or device identity differ')
    require(all(utc_time(a['finished_utc']) <= utc_time(b['started_utc']) for a,b in zip(runs,runs[1:])),
            'repeated capture intervals overlap or run order differs')
    output = Path(output).resolve()
    require(not output.exists() and output.parent.is_dir(), 'new summary output directory required')
    output.mkdir()
    put(output/'summary-request.json', {'input':input_source, 'runs':run_sources, 'allocation':origin(allocation_source),
        'native_mapping':origin(mapping_source), 'native_source':origin(native_source)})
    numerics = {'parameter_dtypes': ['torch.bfloat16'], 'attention': 'eager', 'native_logits_dtype': 'torch.bfloat16',
        'logprob_dtype': 'float64', 'seed': 0, 'cache': True, 'parallelism': 'tp1', 'normalization': NORMALIZATION}
    common = {'model': runs[0]['model'], 'inputs': {'sha256': INPUT_SHA}, 'numerics': numerics,
              'scope': 'one fixed text discovery request; three serial same-NPU captures'}
    base = {'schema_version': 1, 'common': common, 'expected_ranks': {r['side']:[0] for r in runs},
        'side_conditions': {r['side']:{k:r[k] for k in ('hardware','software','backend_policy')} for r in runs}, 'thresholds': None}
    target_contract = {**base, 'kind': 'target-scores', 'targets': runs[0]['targets']}
    distribution_contract = {**base, 'schema_version': 2, 'kind': 'distributions', 'vocab_size': runs[0]['vocab'],
        'normalization_tolerance': 1e-5, 'renormalization': 'none',
        'positions': [{k:p[k] for k in ('sample','position','history')} for p in runs[0]['positions']]}
    put(output/'target-contract.json', target_contract)
    if not metadata_only: put(output/'distribution-contract.json', distribution_contract)
    manifests = {}; checks = {}
    for run in runs:
        side = run['side']; env = side+'-environment.json'
        actual = {**common, **base['side_conditions'][side]}
        put(output/env, {'rank':0, 'versions':run['software'], 'actual':actual})
        manifest = {'common':common, 'side':side, 'expected_ranks':[0],
            'ranks':[{'rank':0,'environment':env,'status':run['status_path']}]}
        target = output/(side+'-targets.json'); put(target, {**manifest,'schema_version':1,'kind':'target-scores','scores':run['scores']})
        dist = output/(side+'-distributions.json')
        if not metadata_only:
            put(dist, {**manifest,'schema_version':2,'kind':'distributions','positions':run['positions']})
            checks[side] = validate(output/'distribution-contract.json', dist)
            require(checks[side].get('status') == 'validated', 'shared full-distribution validator rejected native capture: '+canonical(checks[side]))
        manifests[side] = (target, dist)
    pairs = []
    for a,b in itertools.combinations(manifests,2):
        target = compare_targets(output/'target-contract.json', manifests[a][0], manifests[b][0])
        require(target.get('status') == 'no_thresholds', 'shared target comparator rejected captures: '+canonical(target))
        pair = {'sides':[a,b],'targets':target}
        if not metadata_only:
            pair['distributions'] = compare_distributions(output/'distribution-contract.json',manifests[a][1],manifests[b][1])
            require(pair['distributions'].get('status') == 'no_thresholds', 'shared distribution comparator rejected captures: '+canonical(pair['distributions']))
        pairs.append(pair)
    summary = {'schema_version':1, 'status':'metadata_and_recorded_targets_checked' if metadata_only else 'npu_repeat_artifacts_checked',
        'input_sha256':INPUT_SHA, 'expected_captures':3, 'captures_checked':3, 'target_positions_per_capture':32,
        'full_vocabulary_rows_checked':0 if metadata_only else 96, 'vocabulary_size':runs[0]['vocab'],
        'pairs':pairs, 'distribution_validations':checks, 'acceptance':None,
        'limitations':['Three runs of one discovery request on the same NPU; no GPU/NPU comparison or model-wide acceptance',
            'Recorded receipts and supplied mappings do not independently attest execution or loaded checkpoint bytes',
            'Full distributions remain at source and were not replayed in this metadata-only pass' if metadata_only else
            'Full retained derived rows were checked; original native logits were not retained']}
    put(output/'summary.json', summary)
    put(output/'selected-targets.json', {'scope':'private recorded target-score replay; no raw inputs/arrays',
        'input_sha256':INPUT_SHA,'runs':[{k:r[k] for k in ('side','receipt_source','receipt_sha256','started_utc','finished_utc','selected','array_values_checked')} for r in runs]})
    put(output/'checked-source-inventory.json', {'scope':'sources read and checked by this pass','sha256':sources.checked})
    return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('input','allocation','native-mapping','native-source'):
        parser.add_argument('--'+name)
    parser.add_argument('--run',action='append',help='npu-r1=/original/absolute/runroot; exactly three')
    parser.add_argument('--source-map',type=Path)
    parser.add_argument('--metadata-only',action='store_true')
    parser.add_argument('--output-dir',required=True,type=Path)
    args=parser.parse_args()
    try:
        request = Sources(args.source_map).document.get('request', {}) if args.source_map else {}
        runs={}
        for value in args.run or []:
            label,sep,path=value.partition('='); require(sep and label not in runs,'invalid or duplicate side'); runs[label]=origin(path)
        runs = runs or request.get('runs', {})
        result=summarize(args.input or request.get('input'),runs,args.allocation or request.get('allocation'),
            args.native_mapping or request.get('native_mapping'),args.native_source or request.get('native_source'),
            args.output_dir,args.source_map,args.metadata_only)
        print(json.dumps({k:result[k] for k in ('status','captures_checked','full_vocabulary_rows_checked','acceptance')}))
    except (OSError,ValueError,KeyError,TypeError,IndexError) as exc:
        parser.exit(2,type(exc).__name__+': '+str(exc)+'\n')


if __name__=='__main__': main()

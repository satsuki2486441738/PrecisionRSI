"""Independent stdlib observer stage/geometry/coordinate inventory builder.

No collector, native entry, NumPy or framework import. Static loaded inventories
and exact modeling/config source bytes constrain geometry, not executed kernels.
Declared prerequisite hashes are not validated by this coordinate-only module.
"""
import argparse
import ast
import hashlib
import itertools
import json
import math
from pathlib import Path,PurePosixPath
import re

TASK='gemma4-observer-transparency-v1'
STAGE_ID='gemma4-gpu-npu-observer-v1-20261107'
INPUT_SHA='643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
MODES=['off-before','hooks-only','off-after','hooks-plus-dispatch-metadata']
REFERENCE_SHA={
    'frozen_plan_json':'5e1d06885e2ac2c3b3f59f74a92afcfc3d4a7078957885cd2a0b7cc5e72194d1',
    'GPU_loaded_inventory':'482a36375a1d8689f9e4ff6515c7e9f281e873a3a77f63c7cfa118c95ded8550',
    'NPU_loaded_inventory':'d4ccecc13a0d946452d0d448089a941963e5cc1e104dba057db74fa628e39093',
    'modeling_source':'e356db9089642559f227c0bc1134986bdd5274066431be91a5400d38355818fb',
    'original_config':'14f38c5492ffc9cbcdf808647ca0c025bb5b9b4eb737526347134d500ace6098',
    'module_name_class_signature':'54d24190ade712b1f3a8e81e9569997fa2548a2ee41e2bc8ddc457d943da8103',
    'parameter_name_shape_dtype_numel_signature':'35bd6ff42846d93a92980279f9194dcddd94ddd7530c20a0b171ddb87f76f768'}
LIMITS={'gpu_capture_timeout_seconds':1200,'npu_capture_timeout_seconds':1500,'whole_attempt_timeout_seconds_per_backend':3600,
    'controller_work_timeout_seconds':2620,'cpu_metadata_export_whole_timeout_seconds':960,'owned_cleanup_reserve_seconds':20,
    'independent_CPU_admission_seconds':900,'maximum_capture_product_bytes_per_backend':1073741824,
    'maximum_new_task_storage_bytes_per_backend':4294967296,'minimum_free_source_storage_bytes':5368709120,
    'maximum_logical_artifact_transport_bytes_per_direction':1073741824,'maximum_encoded_transport_bytes_per_direction':1610612736,
    'minimum_gpu_host_effective_available_bytes':42949672960,'minimum_npu_host_effective_available_bytes':85899345920,
    'minimum_free_device_bytes':37580963840,'maximum_code_source_bytes':1048576,'maximum_metadata_member_bytes':16777216,
    'max_native_model_processes_per_backend':1,'automatic_native_retries':0}
PRODUCTS={'raw_logits_files':4,'raw_logits_tensor_name':'logits','raw_logits_shape_per_mode':[1,160,262144],'raw_logits_dtype':'BF16',
    'raw_logits_data_bytes':335544320,'all_valid_native_logits_rows_required_finite_per_mode':160,'scored_targets_per_mode':159,
    'scored_targets_total':636,'unscored_prediction_indices_per_mode':[159],'FP64_distribution_rows_per_mode':47,'FP64_distribution_rows_total':188,
    'FP64_row_shape':[1,262144],'FP64_row_data_bytes':394264576,'native_boundary_BF16_tensor_keys_total':196,
    'native_boundary_safetensors_files':2,'large_files_total':194,'numeric_data_bytes_excluding_headers':730988032,'native_KV_files':0}
FULL=[5,11,17,23,29,35,41,47]
HEX=re.compile('[a-f0-9]{64}')


def require(ok,message):
    if not ok:raise ValueError(message)


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def signature(value):return digest(canonical(value).encode())
def fields(document,wanted):return isinstance(document,dict) and all(k in document and canonical(document[k])==canonical(v) for k,v in wanted.items())
def read(path):
    def pairs(items):
        out={}
        for k,v in items:require(k not in out,'duplicate JSON key');out[k]=v
        return out
    return json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))


def boundaries():
    result=[{'id':'embedding.scaled.output','module':'model.language_model.embed_tokens','when':'output'}]
    for i in range(48):
        for side in ('input','output'):result.append({'id':'block.%02d.%s'%(i,side),'module':'model.language_model.layers.'+str(i),'when':side})
    return result+[{'id':'norm.final.output','module':'model.language_model.norm','when':'output'}]


def posix_root(value):
    require(isinstance(value,str) and value.startswith('/') and '\\' not in value and str(PurePosixPath(value))==value and
        all(x not in ('','.','..') for x in value.split('/')[1:]),'explicit canonical absolute POSIX native root required')
    return value


def stage_check(stage):
    require(stage.get('schema_version')==1 and stage.get('stage_id')==STAGE_ID and stage.get('task')==TASK and
        stage.get('status')=='prepared_not_executed' and stage.get('native_executions_started_by_preparation')==0 and
        stage.get('native_authorization_from_this_file_alone') is False and stage.get('acceptance',object()) is None and
        stage.get('full_core_complete') is False,'prepared observer stage identity/status differs')
    require(stage.get('modes')==MODES and fields(stage,{'model_loads_per_backend':1,'total_forward_calls_per_backend':4}) and
        stage.get('input_sha256')==INPUT_SHA and stage.get('static_reference_sha256')==REFERENCE_SHA,'four-mode/input/static source stage binding differs')
    require(stage.get('limits')==LIMITS and all(type(v) is int for v in stage['limits'].values()) and
        LIMITS['controller_work_timeout_seconds']+LIMITS['cpu_metadata_export_whole_timeout_seconds']+LIMITS['owned_cleanup_reserve_seconds']==3600,
        'finite3600=2620+960+20 observer resource limits differ')
    require(canonical(stage.get('products_per_backend'))==canonical(PRODUCTS),'exact194-file/4raw/188row/196key payload differs')
    require(canonical(stage.get('static_geometry'))==canonical({'modules':875,'named_parameter_entries_including_alias':630,
        'unique_parameter_objects_from_recorded_alias_groups':629,'hidden_width':3840,'vocabulary':262144,'text_blocks':48,
        'full_attention_block_indices':FULL,'static_inventory_is_not_executed_module_or_kernel_coverage':True}),
        'stage static loaded geometry declaration differs')
    model=stage.get('model',{})
    require(canonical(model)==canonical({'repository':'google/gemma-4-12B','revision':'1a2c7729392586f5ecddae8807ee2ef741eabb9a','parameter_dtype':'torch.bfloat16',
        'attention_implementation':'eager','tensor_parallel':1,'one_loaded_model_per_backend':True}),'observer model/environment configuration differs')
    logical=stage.get('input_semantics',{})
    wanted_logical={'samples':1,'prompt_tokens':128,'continuation_tokens':32,'sequence_tokens':160,'past_key_values':None,
        'use_cache':False,'logits_to_keep':0,'return_dict':True,'labels':None,'returned_cache_required':None,'returned_shared_kv_states_required':None}
    require(all(k in logical and canonical(logical[k])==canonical(v) for k,v in wanted_logical.items()),
        'full160/cache-off input semantics differ')
    scope=stage.get('backend_scope',{})
    require(set(scope)=={'GPU','NPU'} and scope['GPU']=={'requested_platform':'H100','devices':1,'device_argument':'cuda:0','tensor_parallel':1} and
        scope['NPU']=={'devices':1,'device_argument':'npu:0','tensor_parallel':1,'same_original_selected_UUID_required':True,
            'instance_visible_logical_devices':8,'physical_board_count_claim':None},'one-device TP1/8logical-visible instance scope differs')
    roots=stage.get('native_task_roots',{});require(set(roots)=={'GPU','NPU'},'both explicit native roots required')
    for value in roots.values():posix_root(value)
    require(roots['GPU']!=roots['NPU'],'native backend roots must be separate')
    proof=stage.get('prerequisites',{})
    require(set(proof)=={'actual_i04_numeric_wrapper_sha256','actual_observer_tiny_CPU_wrapper_sha256','required_before_native',
        'declared_hashes_are_not_proof_validation','no_native_from_prepared_stage_or_expected_inventory_alone'} and
        all(proof[k] is True for k in ('required_before_native','declared_hashes_are_not_proof_validation','no_native_from_prepared_stage_or_expected_inventory_alone')) and
        all(proof[k] is None or isinstance(proof[k],str) and HEX.fullmatch(proof[k]) for k in ('actual_i04_numeric_wrapper_sha256','actual_observer_tiny_CPU_wrapper_sha256')),
        'declared prerequisite SHA structure differs; declarations never validate proof')
    boundary=stage.get('boundaries',{})
    require(fields(boundary,{'count_per_enabled_mode':98,'embedding_module':'model.language_model.embed_tokens',
        'block_module_prefix':'model.language_model.layers.','final_norm_module':'model.language_model.norm','final_boundary_id':'norm.final.output',
        'actual_hidden_shape_required':[1,160,3840],'actual_dtype_required':'torch.bfloat16','sample_shape_required':[1,47,64],
        'enabled_modes':MODES[1::2],'sample_files_per_backend':2,'BF16_tensor_keys_per_backend':196,'sample_data_bytes_per_backend':1179136}),
        'exact98 final-norm boundary/1x47x64 shape differs')
    comparison=stage.get('comparison_inventory',{})
    require(fields(comparison,{'target_distribution_pairs':16,'within_backend_mode_pairs_per_backend':6,
        'matched_cross_backend_mode_pairs':4,'distribution_pair_rows_total':752,'primary_cross_backend_boundary_mode':'hooks-only',
        'primary_cross_backend_boundary_pairs':98}),'16 model pairs/98 primary trajectory differs')
    observer=stage.get('observer_controls',{})
    for key in ('same_loaded_model_device_input_mask_positions_policy_for_all_modes','model_eval_all_module_training_flags_false','seed_reset_before_each_mode',
        'RNG_before_equals_after_each_mode','RNG_before_same_host_equals_first_mode_after_seed_reset','unknown_RNG_bytes_fail_closed',
        'all_actual_modules_censused_when_hooks_enabled','zero_fired_module_names_retained','original_local_module_hook_registries_restored_exactly','hooks_removed_on_exception'):
        require(observer.get(key) is True,'strict observer state/RNG/registry control differs: '+key)
    require(type(observer.get('seed')) is int and observer['seed']==0 and observer.get('boundary_invocations_required_each_enabled_mode')==1,'seed0/single boundary invocation differs')
    dispatcher=stage.get('dispatcher',{})
    require(fields(dispatcher,{'enabled_mode':MODES[3],'original_function_calls_per_interception':1,
        'arguments_and_result_replaced':False,'maximum_invocations':200000,'maximum_unique_signatures':10000,'maximum_serialized_bytes':16777216,
        'kernel_or_fusion_or_accumulator_precision_attribution':False}),'bounded frontend-only dispatcher controls differ')
    return stage


def config_geometry(config):
    text=config.get('text_config',{})
    wanted={'vocab_size':262144,'hidden_size':3840,'intermediate_size':15360,'num_hidden_layers':48,'num_attention_heads':16,'num_key_value_heads':8,
        'head_dim':256,'num_global_key_value_heads':1,'global_head_dim':512,'hidden_activation':'gelu_pytorch_tanh','attention_bias':False,
        'attention_dropout':0.0,'sliding_window':1024,'num_kv_shared_layers':0,'enable_moe_block':False,'hidden_size_per_layer_input':0,'final_logit_softcapping':30.0}
    require(config.get('architectures')==['Gemma4UnifiedForConditionalGeneration'] and config.get('dtype')=='bfloat16' and
        all(text.get(k)==v for k,v in wanted.items()) and len(text.get('layer_types',[]))==48 and
        text['layer_types']==['full_attention' if i in FULL else 'sliding_attention' for i in range(48)],'official text config geometry differs')
    return text


def source_boundaries(source):
    tree=ast.parse(source);classes={x.name:x for x in tree.body if isinstance(x,ast.ClassDef)}
    require('Gemma4UnifiedTextScaledWordEmbedding' in classes and 'Gemma4UnifiedTextModel' in classes,'actual boundary source classes absent')
    methods={name:next((x for x in classes[name].body if isinstance(x,ast.FunctionDef) and x.name=='forward'),None)
        for name in ('Gemma4UnifiedTextScaledWordEmbedding','Gemma4UnifiedTextModel')}
    embed=methods['Gemma4UnifiedTextScaledWordEmbedding'];text=methods['Gemma4UnifiedTextModel']
    require(embed is not None and text is not None and any(isinstance(x,ast.Return) and isinstance(x.value,ast.BinOp) and isinstance(x.value.op,ast.Mult) and
        any(isinstance(n,ast.Attribute) and n.attr=='embed_scale' for n in ast.walk(x.value)) for x in embed.body),
        'scaled embedding output is not established in actual source')
    assignments=[x for x in ast.walk(text) if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name) and x.targets[0].id=='hidden_states' and
        isinstance(x.value,ast.Call) and isinstance(x.value.func,ast.Attribute) and isinstance(x.value.func.value,ast.Name) and x.value.func.value.id=='self' and x.value.func.attr=='norm']
    require(len(assignments)==1 and any(isinstance(x,ast.keyword) and x.arg=='last_hidden_state' and isinstance(x.value,ast.Name) and
        x.value.id=='hidden_states' for x in ast.walk(text)),'final norm output is not established as returned hidden state')
    return {'scaled_embedding_forward_line':embed.lineno,'text_final_norm_line':assignments[0].lineno,
        'boundaries':'scaled embedding output and final norm output; hidden width3840, not LM vocabulary width262144',
        'scope':'AST/static source only; no forward or kernel executed'}


def validate_geometry_documents(gpu,npu,config,source):
    text=config_geometry(config);source_observation=source_boundaries(source);normalized=[]
    for side,doc in (('GPU',gpu),('NPU',npu)):
        require(doc.get('kind')=='loaded-model-metadata-inventory' and isinstance(doc.get('modules'),list) and isinstance(doc.get('parameters'),list),
            'actual loaded static inventory kind differs')
        modules=doc['modules'];params=[{k:x[k] for k in ('name','shape','dtype','numel')} for x in doc['parameters']]
        require(len(modules)==875 and len({x['name'] for x in modules})==875 and signature(modules)==REFERENCE_SHA['module_name_class_signature'],
            'actual875 module graph signature differs')
        require(len(params)==630 and len({x['name'] for x in params})==630 and all(x['dtype']=='torch.bfloat16' and x['numel']==math.prod(x['shape']) for x in params) and
            signature(params)==REFERENCE_SHA['parameter_name_shape_dtype_numel_signature'],'actual630 parameter shape/dtype/numel signature differs')
        aliases=doc.get('parameter_object_alias_groups');expected_alias=[['model.language_model.embed_tokens.weight','lm_head.weight']]
        require(aliases==expected_alias and doc.get('observable_shared_storage_groups')==expected_alias and
            doc.get('tied_weight_declarations',{}).get('_tied_weights_keys')=={'lm_head.weight':'model.language_model.embed_tokens.weight'},
            'actual embedding/head object/storage alias declaration differs')
        unique_count=len(params)-sum(len(group)-1 for group in aliases);pmap={x['name']:x for x in params};mmap={x['name']:x for x in modules}
        require(unique_count==629 and sum(x['numel'] for x in params)==12966363136 and
            sum(x['numel'] for x in params)-pmap['lm_head.weight']['numel']==11959730176,'actual unique parameter count/numel differs')
        require(config_geometry(doc['config'])=={**text,**{k:v for k,v in doc['config']['text_config'].items() if k not in text}},'loaded text config geometry differs')
        for boundary in boundaries():require(boundary['module'] in mmap,'static boundary module absent')
        require(mmap['model.language_model.embed_tokens']['class'].endswith('.Gemma4UnifiedTextScaledWordEmbedding') and
            mmap['model.language_model.norm']['class'].endswith('.Gemma4UnifiedRMSNorm'),'actual embedding/final norm module classes differ')
        blocks=[x['name'] for x in modules if x['class'].endswith('.Gemma4UnifiedTextDecoderLayer')]
        require(blocks==['model.language_model.layers.'+str(i) for i in range(48)],'actual48 decoder block inventory differs')
        for i,kind in enumerate(text['layer_types']):
            prefix='model.language_model.layers.'+str(i)+'.';full=kind=='full_attention'
            shapes={'self_attn.q_proj.weight':[8192,3840] if full else [4096,3840],
                'self_attn.k_proj.weight':[512,3840] if full else [2048,3840],
                'self_attn.o_proj.weight':[3840,8192] if full else [3840,4096],
                'self_attn.q_norm.weight':[512] if full else [256],'self_attn.k_norm.weight':[512] if full else [256],
                'mlp.gate_proj.weight':[15360,3840],'mlp.up_proj.weight':[15360,3840],'mlp.down_proj.weight':[3840,15360]}
            for name in ('input_layernorm','post_attention_layernorm','pre_feedforward_layernorm','post_feedforward_layernorm'):shapes[name+'.weight']=[3840]
            if not full:shapes['self_attn.v_proj.weight']=[2048,3840]
            require(all(pmap.get(prefix+key,{}).get('shape')==shape for key,shape in shapes.items()),'actual per-block projection/norm/MLP geometry differs')
            if full:require(prefix+'self_attn.v_proj' not in mmap and prefix+'self_attn.v_proj.weight' not in pmap,'full attention must not invent v_proj')
            require(prefix+'self_attn.v_norm' in mmap and prefix+'self_attn.v_norm.weight' not in pmap,'actual unweighted V norm geometry differs')
        normalized.append({'modules':modules,'parameters':params})
    require(normalized[0]==normalized[1],'GPU/NPU actual static graphs/geometries differ')
    return {'modules':875,'named_parameter_entries_including_alias':630,'unique_parameter_objects_from_recorded_alias_groups':629,
        'hidden_width':3840,'vocabulary':262144,'text_blocks':48,'full_attention_block_indices':FULL,
        'static_inventory_is_not_executed_module_or_kernel_coverage':True,'source_observation':source_observation,
        'module_name_class_signature_sha256':REFERENCE_SHA['module_name_class_signature'],
        'parameter_signature_sha256':REFERENCE_SHA['parameter_name_shape_dtype_numel_signature']}


def load_geometry(gpu_inventory,npu_inventory,config,modeling_source):
    paths={'GPU_loaded_inventory':gpu_inventory,'NPU_loaded_inventory':npu_inventory,'original_config':config,'modeling_source':modeling_source};raw={}
    for key,path in paths.items():
        path=Path(path);require(path.is_file() and not path.is_symlink() and path.stat().st_size<=1024**2,'bounded regular actual reference required')
        raw[key]=path.read_bytes();require(digest(raw[key])==REFERENCE_SHA[key],'original static/source reference bytes differ: '+key)
    result=validate_geometry_documents(json.loads(raw['GPU_loaded_inventory']),json.loads(raw['NPU_loaded_inventory']),
        json.loads(raw['original_config']),raw['modeling_source'].decode('utf8'))
    for key,path in paths.items():require(digest(Path(path).read_bytes())==REFERENCE_SHA[key],'static reference changed during validation')
    result['source_sha256']={key:REFERENCE_SHA[key] for key in paths};return result


def derive(document,input_sha256,stage,stage_sha256,geometry):
    stage_check(stage);require(input_sha256==INPUT_SHA and isinstance(stage_sha256,str) and HEX.fullmatch(stage_sha256),'original input/frozen stage SHA required')
    require(geometry.get('modules')==875 and geometry.get('named_parameter_entries_including_alias')==630 and
        geometry.get('unique_parameter_objects_from_recorded_alias_groups')==629 and geometry.get('source_sha256')==
        {k:REFERENCE_SHA[k] for k in ('GPU_loaded_inventory','NPU_loaded_inventory','original_config','modeling_source')},'verified actual geometry summary required')
    prompt,continuation=document.get('prompt'),document.get('continuation');sample=document.get('sample')
    require(isinstance(sample,str) and sample.strip() and isinstance(prompt,list) and len(prompt)==128 and isinstance(continuation,list) and len(continuation)==32,
        'exact original128+32 sequence required')
    sequence=prompt+continuation;require(all(type(x) is int and 0<=x<262144 for x in sequence),'valid native vocabulary token IDs required')
    positions=sorted({i*127//15 for i in range(16)}|set(range(127,159)));channels=[j*3839//63 for j in range(64)];specs=boundaries()
    require(len(positions)==47 and len(set(channels))==64 and len(specs)==98,'independent47x64/98 inventory invariant failed')
    targets=[{'sample':sample,'position':p,'prediction_position':p-1,'token':sequence[p]} for p in range(1,160)]
    rows=[{'sample':sample,'position':p,'history':sequence[:p+1],'roles':(['prompt_sample'] if p in [i*127//15 for i in range(16)] else [])+
        (['continuation'] if p>=127 else []),'target_position':p+1,'token':sequence[p+1]} for p in positions]
    pairs=[]
    for side in ('GPU','NPU'):
        for left,right in itertools.combinations(MODES,2):pairs.append({'id':'within/'+side+'/'+left+'/'+right,'kind':'within_backend_observer_modes',
            'left':{'backend':side,'mode':left},'right':{'backend':side,'mode':right},'targets':159,'distribution_rows':47})
    for mode in MODES:pairs.append({'id':'cross/'+mode,'kind':'matched_cross_backend_mode','left':{'backend':'GPU','mode':mode},
        'right':{'backend':'NPU','mode':mode},'targets':159,'distribution_rows':47})
    return {'schema_version':1,'task':TASK,'stage_id':STAGE_ID,'stage_spec_sha256':stage_sha256,'input_sha256':INPUT_SHA,
        'modes':MODES,'sequence':sequence,'sample':sample,'raw_logits':{'dtype':'BF16','shape':[1,160,262144],'tensor_name':'logits','files':4},
        'targets_per_mode':159,'distribution_positions':positions,'channels':channels,'boundaries':specs,'sample_shape':[1,47,64],'enabled_modes':MODES[1::2],
        'module_name_class_signature_sha256':REFERENCE_SHA['module_name_class_signature'],'parameter_signature_sha256':REFERENCE_SHA['parameter_name_shape_dtype_numel_signature'],
        'numeric_data_bytes_excluding_headers':730988032,'target_distribution_pair_count':16,'primary_cross_boundary_pairs':98,
        'input_ids':[sequence],'attention_mask':[[1]*160],'position_ids':[list(range(160))],'all_targets':targets,'distribution_rows':rows,
        'unscored_prediction_indices':[159],'products_per_backend':PRODUCTS,'comparison_pairs':pairs,
        'primary_boundary_pairs':[{'boundary':x['id'],'left':{'backend':'GPU','mode':'hooks-only'},'right':{'backend':'NPU','mode':'hooks-only'},
            'native_sample_shape':[1,47,64],'native_dtype':'BF16','upstream_propagation_possible':True} for x in specs],
        'native_files_per_backend':{'raw_logits':['modes/'+mode+'/raw-native-logits.safetensors' for mode in MODES],
            'distribution_rows':['modes/'+mode+'/dist-p%03d.npy'%p for mode in MODES for p in positions],
            'selected_boundaries':['modes/'+mode+'/boundary-samples.safetensors' for mode in MODES[1::2]]},
        'static_geometry':geometry,'prerequisite_hashes_declared':stage['prerequisites'],
        'native_gate_status':'proof_hashes_missing' if any(stage['prerequisites'][k] is None for k in ('actual_i04_numeric_wrapper_sha256','actual_observer_tiny_CPU_wrapper_sha256')) else 'hashes_declared_but_proofs_not_validated',
        'native_executions_started':0,'native_execution_allowed_by_inventory':False,'thresholds':None,'acceptance':None,'full_core_complete':False,
        'scope':['Independent coordinates/static geometry only.','875static modules do not imply875fired modules or any executed kernel.',
            '159known targets; raw prediction159 retained but has no known target160.','Per-boundary selected sample is [1,47,64], not full hidden activations.',
            'Frontend dispatcher metadata is not a native kernel or accumulator precision proof.']}


def build(input_path,output,stage_path,stage_sha256,gpu_inventory,npu_inventory,config,modeling_source):
    input_path,output,stage_path=Path(input_path),Path(output),Path(stage_path)
    require(input_path.is_file() and not input_path.is_symlink() and digest(input_path.read_bytes())==INPUT_SHA,'original input byte SHA differs')
    require(stage_path.is_file() and not stage_path.is_symlink() and digest(stage_path.read_bytes())==stage_sha256,'externally frozen stage byte SHA differs')
    require(not output.exists() and not output.is_symlink() and output.parent.is_dir(),'new exclusive independent expected output required')
    geometry=load_geometry(gpu_inventory,npu_inventory,config,modeling_source);document=derive(read(input_path),INPUT_SHA,read(stage_path),stage_sha256,geometry)
    raw=(json.dumps(document,indent=2,allow_nan=False)+'\n').encode();require(len(raw)<=2*1024**2,'expected metadata exceeds2MiB')
    require(digest(input_path.read_bytes())==INPUT_SHA and digest(stage_path.read_bytes())==stage_sha256,'input/stage changed during expected derivation')
    with output.open('xb') as stream:stream.write(raw)
    return {'status':'observer_independent_expected_prepared_not_native','path':str(output),'sha256':digest(raw),'size_bytes':len(raw),
        'stage_spec_sha256':stage_sha256,'native_executions_started':0,'native_execution_allowed_by_inventory':False,'acceptance':None}


def verify(expected,input_path,stage_path,stage_sha256,gpu_inventory,npu_inventory,config,modeling_source):
    expected,input_path,stage_path=Path(expected),Path(input_path),Path(stage_path)
    require(expected.is_file() and not expected.is_symlink() and expected.stat().st_size<=2*1024**2,'bounded regular independent expected JSON required')
    before=digest(expected.read_bytes())
    require(input_path.is_file() and not input_path.is_symlink() and digest(input_path.read_bytes())==INPUT_SHA and
        stage_path.is_file() and not stage_path.is_symlink() and digest(stage_path.read_bytes())==stage_sha256,'original input/frozen stage byte SHA differs')
    wanted=derive(read(input_path),INPUT_SHA,read(stage_path),stage_sha256,load_geometry(gpu_inventory,npu_inventory,config,modeling_source))
    actual=read(expected);require(canonical(actual)==canonical(wanted),'independent expected coordinates/metadata/proof declarations differ')
    require(digest(expected.read_bytes())==before and digest(input_path.read_bytes())==INPUT_SHA and digest(stage_path.read_bytes())==stage_sha256,
        'independent expected/input/stage changed during verification')
    return actual


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('input','output','stage-spec','gpu-inventory','npu-inventory','config','modeling-source'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--stage-spec-sha256',required=True);args=parser.parse_args()
    print(json.dumps(build(args.input,args.output,args.stage_spec,args.stage_spec_sha256,args.gpu_inventory,args.npu_inventory,args.config,args.modeling_source),indent=2))


if __name__=='__main__':main()

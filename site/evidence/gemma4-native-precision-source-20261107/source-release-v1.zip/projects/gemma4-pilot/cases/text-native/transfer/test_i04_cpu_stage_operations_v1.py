"""CPU archive/process guards only; never invoke native probe or model paths."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i04_cpu_ops_under_test',HERE/'i04_cpu_stage_operations_v1.py')
tool = importlib.util.module_from_spec(spec); spec.loader.exec_module(tool)


class GuardTests(unittest.TestCase):
    def test_canonical_paths(self):
        for name in ('../escape','/absolute','a//b','a/../b','a/./b','a\\b',''):
            with self.assertRaises(ValueError): tool.safe(name)
        self.assertEqual(str(tool.safe('source/a.py')),'source/a.py')

    def archive(self,root,members):
        path = root/'packet.tar.gz'
        with tarfile.open(path,'w:gz') as package:
            for name,kind in members:
                info = tarfile.TarInfo(name); info.size = 1
                if kind == 'link': info.type = tarfile.SYMTYPE; info.linkname = '/outside'; info.size = 0
                package.addfile(info,io.BytesIO(b'x'))
        return path

    def test_reject_archive_links_duplicates_and_ancestor_collisions_before_write(self):
        for members in ([('source/x.py','link')],[('source/x','file'),('source/x','file')],[('source/x','file'),('source/x/y','file')]):
            with tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary); archive = self.archive(root,members); target = root/'new'
                with self.assertRaises(ValueError): tool.extract(archive,target,tool.sha(archive),'a'*64)
                self.assertFalse(target.exists())

    def test_exact_archive_manifest_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); raw = b'# CPU synthetic regular source\n'; name = 'synthetic.py'
            manifest = {'files':{name:{'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}}}
            encoded = json.dumps(manifest).encode(); archive = root/'packet.tar.gz'
            with tarfile.open(archive,'w:gz') as package:
                for member,data in [('source-manifest.json',encoded),('source/'+name,raw)]:
                    info = tarfile.TarInfo(member); info.size = len(data); package.addfile(info,io.BytesIO(data))
            target = root/'new'; source,metadata = tool.extract(archive,target,tool.sha(archive),hashlib.sha256(encoded).hexdigest())
            self.assertEqual((source/name).read_bytes(),raw)
            with self.assertRaisesRegex(ValueError,'exclusive'): tool.extract(archive,target,tool.sha(archive),hashlib.sha256(encoded).hexdigest())
            self.assertEqual((source/name).read_bytes(),raw)

    def test_framework_free_pure_helper_and_actual_proof(self):
        repo = HERE.parents[4]; source = repo/tool.PROOF_HELPER
        helper = tool.pure_module(source,'i04_cpu_guard_pure_proof')
        proof = repo/(tool.CASE+'/transfer/i03-numeric-small-local-20261106T170703Z/payload/i04-prerequisite/prerequisite.json')
        actual = helper.prerequisite(proof,tool.PROOF_SHA)
        self.assertEqual(len(actual['refs']),8); self.assertEqual(actual['native_executions_started'],0)

    @unittest.skipUnless(os.name == 'posix','POSIX owned CPU group cleanup')
    def test_owned_cpu_timeout_has_raw_logs_and_stops_group(self):
        import sys
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            result = tool.child([sys.executable,'-c','import time;print("CPU",flush=True);time.sleep(30)'],root,.1,root/'stdout',root/'stderr')
            self.assertTrue(result['timed_out']); self.assertNotEqual(result['returncode'],0)
            self.assertEqual((root/'stdout').read_bytes(),b'CPU\n')

    def test_changed_source_is_rejected_before_any_helper_import(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); source = root/'source'; source.mkdir()
            path = source/'synthetic.py'; path.write_bytes(b'original CPU source')
            doc = {'kind':'i04-cpu-only-stage-bundle','stage_spec_sha256':tool.STAGE_SHA,
                'i03_prerequisite_sha256':tool.PROOF_SHA,'expected_inventory_sha256':tool.EXPECTED_SHA,
                'native_executions_started':0,'model_loads':0,'expected_CPU_tests':21,
                'files':{'synthetic.py':{'sha256':tool.sha(path),'size_bytes':path.stat().st_size}}}
            manifest = root/'source-manifest.json'; tool.put(manifest,doc); digest = tool.sha(manifest)
            path.write_bytes(b'changed CPU source')
            with patch.object(tool,'pure_module') as importer,self.assertRaisesRegex(ValueError,'source size/SHA'):
                tool.verify_tree(source,manifest,digest)
            importer.assert_not_called()


if __name__ == '__main__': unittest.main()

"""Pure CPU progress bridge fixtures; no Torch/device/model is executed."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import reserved48_common_v2 as c
import reserved48_native_v2 as native

HERE=Path(__file__).resolve().parent


def rows():
    return [{'sample':'synthetic-%02d'%i,'P':128,'L':160,'plans':{
        'full':[[0,160]],'token':[[0,128]]+[[p,p+1] for p in range(128,160)],
        'chunk':[[0,63],[63,128]]+[[p,p+1] for p in range(128,160)]}} for i in range(12)]


def summary(folder,row,mode):
    path=folder/(row['sample']+'-'+mode+'.json')
    path.write_text(c.canonical({'sample':row['sample'],'mode':mode,'native_calls':len(row['plans'][mode]),'valid_rows':160,'targets':159,'selected_rows':47}),encoding='utf8')
    return path


class NumericAST(unittest.TestCase):
    def test_original_frozen_bytes_and_unchanged_numeric_loader_helper_AST(self):
        pins={'reserved48_common_v1.py':'bf1bd4176fd209fd6fabfbda22bd9fb246cfdf12e72d89d7ca77417ad8546e58',
            'reserved48_native_v1.py':'d7bc0e8115769d4fcbe2aecec6e6ee550517fa7a27e7afef6b8b3844e20fe3e2'}
        for name,digest in pins.items():self.assertEqual(hashlib.sha256((HERE/name).read_bytes()).hexdigest(),digest)
        def functions(name):return {x.name:x for x in ast.parse((HERE/name).read_bytes()).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
        old,new=functions('reserved48_common_v1.py'),functions('reserved48_common_v2.py')
        for name in old:
            if name not in ('arguments','capture_mode','capture_all'):self.assertEqual(ast.dump(old[name]),ast.dump(new[name]),name)
        # Strip only new progress callbacks/parameter from the two control loops.
        class Strip(ast.NodeTransformer):
            def visit_Expr(self,node):
                if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and isinstance(node.value.func.value,ast.Name) and node.value.func.value.id=='progress':return None
                return self.generic_visit(node)
            def visit_Assign(self,node):
                if len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id=='progress':return None
                return self.generic_visit(node)
            def visit_Call(self,node):
                node=self.generic_visit(node)
                if isinstance(node.func,ast.Name) and node.func.id=='capture_mode' and node.args and isinstance(node.args[-1],ast.Name) and node.args[-1].id=='progress':node.args.pop()
                return node
        for name in ('capture_mode','capture_all'):
            candidate=Strip().visit(copy.deepcopy(new[name]));candidate.args.args=[x for x in candidate.args.args if x.arg!='progress']
            self.assertEqual(ast.dump(old[name]),ast.dump(candidate),name)
        a,b=functions('reserved48_native_v1.py'),functions('reserved48_native_v2.py')
        for name in a:
            if name!='main':self.assertEqual(ast.dump(a[name]),ast.dump(b[name]),name)

    def test_native_v2_None_gates_refuse_before_progress_or_framework_work(self):
        self.assertTrue(all(v is None for v in c.GATES.values()))
        with patch.object(c,'arguments',return_value=SimpleNamespace()),patch.object(c,'Progress',side_effect=AssertionError('progress created before gates')):
            with self.assertRaisesRegex(ValueError,'unready'):native.main()
        self.assertFalse(any(x in sys.modules for x in ('torch','torch_npu','numpy','transformers')))


class Progress(unittest.TestCase):
    def test_full36_cells816_calls_durable_terminal_and_original_summary_refs(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);plan=rows();p=c.Progress(root/'native-progress.jsonl',plan,'gpu')
            p.phase('model_load');p.phase('after_model_load')
            for row in plan:
                for mode in c.MODES:
                    p.enter_cell(row['sample'],mode)
                    for i,(start,end) in enumerate(row['plans'][mode]):
                        p.phase('input_or_cache_preparation');p.forward_started(i,start,end);p.forward_returned(i);p.phase('source_CPU_derivation_and_evidence')
                    p.complete_cell(summary(root,row,mode))
            p.phase('final_artifact_validation');p.complete();result=c.validate_progress(p.path,plan)
            self.assertEqual(result['status'],'source_capture_completed');self.assertEqual(result['forward_attempts'],816)
            self.assertEqual(result['forward_returns'],816);self.assertEqual(result['not_entered_cells'],0)
            self.assertFalse(result['independent_numeric_admission']);self.assertLess(p.path.stat().st_size,c.Progress.MAX_BYTES)
            with self.assertRaises(ValueError):p.fail(RuntimeError('later unrelated error'))

    def test_typed_OOM_at_first_forward_does_not_attribute_OOM_to35_unentered_cells(self):
        class SyntheticOOM(RuntimeError):pass
        with tempfile.TemporaryDirectory() as td:
            plan=rows();p=c.Progress(Path(td)/'native-progress.jsonl',plan,'gpu');p.enter_cell(plan[0]['sample'],'full');p.forward_started(0,0,160)
            p.fail(SyntheticOOM('CUDA out of memory, synthetic exception only'),SimpleNamespace(OutOfMemoryError=SyntheticOOM))
            result=c.validate_progress(p.path,plan);terminal=json.loads(p.path.read_text().splitlines()[-1])
            self.assertEqual((result['forward_attempts'],result['forward_returns'],result['not_entered_cells']),(1,0,35))
            self.assertEqual(terminal['error']['classification'],'typed_torch_out_of_memory')
            self.assertTrue(terminal['error']['active_cell_only_no_unstarted_cell_OOM_attribution'])
            self.assertFalse(terminal['error']['independent_device_allocation_query_performed'])

    def test_NPU_RuntimeError_OOM_text_remains_type_unconfirmed_and_before_forward_is_visible(self):
        with tempfile.TemporaryDirectory() as td:
            plan=rows();p=c.Progress(Path(td)/'native-progress.jsonl',plan,'npu');p.enter_cell(plan[0]['sample'],'full');p.phase('input_or_cache_preparation')
            p.fail(RuntimeError('NPU out of memory. Synthetic diagnostic, no device.'))
            result=c.validate_progress(p.path,plan);terminal=json.loads(p.path.read_text().splitlines()[-1])
            self.assertEqual(result['forward_attempts'],0);self.assertEqual(result['cell_ledger'][0]['state'],'entered_no_forward_marker')
            self.assertEqual(terminal['error']['classification'],'runtime_message_mentions_OOM_type_unconfirmed');self.assertFalse(terminal['error']['typed_torch_OOM'])

    def test_model_load_failure_proves_no_planned_mode_entered_and_never_claims_loaded_model(self):
        with tempfile.TemporaryDirectory() as td:
            plan=rows();p=c.Progress(Path(td)/'native-progress.jsonl',plan,'npu');p.phase('model_load');p.fail(MemoryError('synthetic host allocation failure'))
            result=c.validate_progress(p.path,plan);terminal=json.loads(p.path.read_text().splitlines()[-1])
            self.assertEqual(result['not_entered_cells'],36);self.assertEqual(result['forward_returns'],0)
            self.assertEqual(terminal['error']['classification'],'python_host_memory_error');self.assertNotIn('model_loads_observed_by_entry',terminal)

    def test_missing_truncated_reordered_or_forged_terminal_and_duplicate_claim_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);plan=rows();p=c.Progress(root/'native-progress.jsonl',plan,'gpu')
            with self.assertRaises(FileExistsError):c.Progress(p.path,plan,'gpu')
            with self.assertRaises(ValueError):c.validate_progress(p.path,plan)
            with self.assertRaises(ValueError):p.forward_started(0,0,160)
            p.enter_cell(plan[0]['sample'],'full')
            with self.assertRaises(ValueError):p.forward_returned(0)
            with self.assertRaises(ValueError):p.forward_started(0,0,159)
            p.forward_started(0,0,160);p.fail(TimeoutError('synthetic bounded timeout'))
            original=p.path.read_bytes();records=[json.loads(x) for x in original.splitlines()]
            for change in ('false_success','missing_entry','false_all_unentered'):
                modified=copy.deepcopy(records)
                if change=='false_success':modified[-1]['status']='source_capture_completed'
                elif change=='missing_entry':modified.pop(1)
                else:modified[-1]['cell_ledger'][0]['state']='not_entered'
                target=root/(change+'.jsonl');target.write_text('\n'.join(c.canonical(x) for x in modified)+'\n',encoding='utf8')
                with self.assertRaises(ValueError):c.validate_progress(target,plan)
            self.assertEqual(p.path.read_bytes(),original)


if __name__=='__main__':unittest.main()

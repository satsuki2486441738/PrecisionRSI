"""Meaningful CPU contracts, never native-model/padding execution evidence."""
import copy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import i04_common_v1 as common
import i04_prerequisite_v1 as gate

HERE = Path(__file__).resolve().parent
CASE = HERE.parent


class Row:
    def __init__(self,values): self.values = np.asarray(values)
    def __getitem__(self,key): return Row(self.values[key])
    def double(self): return self
    def numpy(self): return self.values.astype(np.float64)


def synthetic_inputs():
    seq = [(i*7+3)%16 for i in range(160)]; seq[0] = 0
    return ({'sample':'synthetic-A','prompt':seq[:128],'continuation':seq[128:]},
        {'sample':'synthetic-B','prompt':seq[:64],'continuation':seq[64:96],
         'parent_input_sha256':common.INPUT_SHA256,'parent_token_span':[0,96],'independent_representative_example':False})


class CoordinateAndDerivation(unittest.TestCase):
    def inventory(self):
        a,b = synthetic_inputs()
        with patch.object(common,'VOCABULARY',16): return common.coordinates(a,b)

    def test_actual_independent_expected_core_and_frozen_inputs(self):
        a = common.read(CASE/'inputs/discovery-v1/wikitext2-discovery-001.json')
        b = common.read(CASE/'inputs/i04-prefix-stress-096-v1.json')
        independent = common.read(CASE/'transfer/i04-independent-expected-20261107.json')
        self.assertTrue(all(common.canonical(independent[k]) == common.canonical(v) for k,v in common.expected_core(common.coordinates(a,b)).items()))
        self.assertEqual(common.sha(CASE/'i04-stage-v1.json'),common.STAGE_SHA256)
        self.assertEqual(common.sha(CASE/'inputs/i04-prefix-stress-096-v1.json'),common.INPUT_B_SHA256)

    def test_lengths_counts_padding_offsets_and_valid_zero_token(self):
        inventory = self.inventory(); plans = inventory['modes']
        self.assertEqual(sum(len(o['all_targets']) for p in plans for o in p['observations']),762)
        self.assertEqual(sum(len(o['distribution_positions']) for p in plans for o in p['observations']),282)
        self.assertEqual(sum(len(p['pad_only_rows']) for p in plans),128)
        self.assertEqual(sum(sum(sum(row) for row in p['attention_mask']) for p in plans),768)
        left,right = plans[2:]; b = left['observations'][1]
        self.assertEqual((b['physical_offset'],b['all_targets'][-1]['physical_prediction_position']), (64,158))
        self.assertEqual(left['input_ids'][1][64],0); self.assertEqual(left['attention_mask'][1][64],1)
        self.assertEqual(left['position_ids'][1][64:],[*range(96)])
        self.assertEqual(right['position_ids'][1][:96],[*range(96)])
        self.assertEqual(right['attention_mask'][1][96:],[0]*64)
        self.assertEqual([len(r['distribution_positions']) for r in inventory['requests'].values()],[47,47])

    def test_same_prefix_requests_stay_distinct_and_wrong_prefix_fails(self):
        a,b = synthetic_inputs(); b['continuation'][0] ^= 1
        with patch.object(common,'VOCABULARY',16),self.assertRaisesRegex(ValueError,'exact original prefix'): common.coordinates(a,b)
        inventory = self.inventory()
        self.assertNotEqual(inventory['requests']['A']['sample'],inventory['requests']['B']['sample'])
        for mode in inventory['modes'][2:]: self.assertEqual([o['request'] for o in mode['observations']],['A','B'])

    def test_logical_extraction_ignores_left_pad_NaN_and_right_physical_last(self):
        inventory = self.inventory()
        for plan in inventory['modes'][2:]:
            shape = plan['raw_logits']['shape']; values = np.zeros(shape,dtype=np.float64)
            for obs in plan['observations']:
                for p in range(obs['sequence_length']):
                    values[obs['slot'],obs['physical_offset']+p,:] = np.arange(16)*(.01+p*.0001)+obs['slot']*.05*np.arange(16)
            for item in plan['pad_only_rows']: values[item['slot'],item['physical_position'],:] = np.nan
            with tempfile.TemporaryDirectory() as temporary,patch.object(common,'VOCABULARY',16):
                path = Path(temporary)/'artifacts/modes'/plan['id']; path.mkdir(parents=True)
                summaries,rows = common.derive_observations(Row(values),inventory,plan,path,{'sha256':'a'*64})
                self.assertEqual(sum(x['targets'] for x in summaries),254)
                self.assertEqual(rows['pad_only_nonfinite_counts']['nan'],64*16)
                self.assertEqual(rows['valid_nonfinite_coordinates'],0)
                score = common.read(path/'request-B/target-scores.json')['scores'][-1]
                physical = plan['observations'][1]['physical_offset']+94
                logits = values[1,physical,:]; shifted = logits-logits.max(); expected = shifted-np.log(np.exp(shifted).sum())
                self.assertAlmostEqual(score['logprob'],float(expected[score['token']]),places=14)
                self.assertEqual(score['physical_prediction_position'],physical)
                self.assertEqual(score['position'],95)
                self.assertNotEqual(physical,159)
                self.assertEqual(common.read(path/'request-B/distributions.json')['positions'][-1]['position'],94)

    def test_valid_final_unscored_row_nonfinite_is_not_silently_dropped(self):
        inventory = self.inventory(); plan = inventory['modes'][1]
        values = np.zeros(plan['raw_logits']['shape']); values[0,95,0] = np.inf
        with tempfile.TemporaryDirectory() as temporary,patch.object(common,'VOCABULARY',16):
            path = Path(temporary)/'artifacts/modes'/plan['id']; path.mkdir(parents=True)
            with self.assertRaisesRegex(ValueError,'valid logical'):
                common.derive_observations(Row(values),inventory,plan,path,{'sha256':'a'*64})

    def test_binary_header_rejects_wrong_batch_shape_or_native_dtype(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)/'raw.safetensors'; header = {'logits':{'dtype':'BF16','shape':[2,3,4],'data_offsets':[0,48]}}
            raw = json.dumps(header).encode(); path.write_bytes(struct.pack('<Q',len(raw))+raw+b'\0'*48)
            common.safetensors_header(path,{'logits':[2,3,4]})
            with self.assertRaises(ValueError): common.safetensors_header(path,{'logits':[1,6,4]})

    def test_prior_source_bytes_and_no_framework_import(self):
        for name,digest in common.PINNED.items(): self.assertEqual(common.sha(common.REPO/name),digest)
        self.assertNotIn('torch',sys.modules); self.assertNotIn('torch_npu',sys.modules)


class ProofFixture(unittest.TestCase):
    """Synthetic result documents tied to real immutable analysis/tool bytes."""
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name); (self.base/'proof').mkdir(); self.path = self.base/'prerequisite.json'
        self.run = '/synthetic/I03/run'; self.tools = '/synthetic/I03/tools'
        toolfile = CASE/'transfer/tools/i03-cpu-compare-v1-20261106T154150Z/tool-bundle-manifest.json'
        self.assertEqual(common.sha(toolfile),gate.TOOL_MANIFEST_SHA)
        self.documents = {'tool_manifest':common.read(toolfile)}
        source_names = {'analysis_source':'admit_i03_partition_repeat_v1.py','artifact_helper_source':'i03_artifact_admission_v1.py'}
        self.raw_sources = {key:(HERE/name).read_bytes() for key,name in source_names.items()}
        refs = {key:{'path':'proof/'+key+('.py' if key in source_names else '.json'),'source_path':source,'sha256':''} for key,source in {
            'controller':self.run+'/controller-receipt.json','report':self.run+'/bundle/i03-comparison-report.json',
            'comparison_spec':self.run+'/comparison-spec.json','analysis_source':self.tools+'/'+gate.MAIN,
            'artifact_helper_source':self.tools+'/'+gate.HELPER,'tool_manifest':self.tools+'/tool-bundle-manifest.json',
            'GPU_map':'/synthetic/GPU/source-map.json','NPU_map':'/synthetic/NPU/source-map.json'}.items()}
        self.wrapper = {'schema_version':1,'kind':'i04-i03-numeric-prerequisite','prior_stage_sha256':gate.STAGE_SHA,
            **{key:refs[key] for key in ('controller','report','comparison_spec','analysis_source','artifact_helper_source','tool_manifest')},
            'source_maps':{'GPU':refs['GPU_map'],'NPU':refs['NPU_map']}}
        spec = {'schema_version':1,'task':gate.TASK,'stage_spec_sha256':gate.STAGE_SHA,'expected_inventory_sha256':gate.EXPECTED_SHA,
            'i01_prerequisite_sha256':gate.I01_PROOF_SHA,'thresholds':None,'acceptance':None,'endpoints':{}}
        for backend in ('GPU','NPU'):
            outer = '/synthetic/'+backend+'/capture-receipt.json'; outer_sha = ('a' if backend == 'GPU' else 'b')*64
            self.documents[backend+'_map'] = {'request':{'task':'I03','backend':backend,'outer_receipt':outer},
                'full_array_hashes_checked':242,'retained_array_count':0 if backend == 'GPU' else 242,'files':{outer:{'sha256':outer_sha}}}
            spec['endpoints'][backend] = {'source_map':{'path':refs[backend+'_map']['source_path'],'sha256':''},'receipt':{'source_path':outer,'sha256':outer_sha}}
        self.documents['comparison_spec'] = spec
        kinds = ['within_process_full_repeat']*6+['within_process_partition']*6+['cross_backend_full']*9+['cross_backend_cached']*2
        self.documents['report'] = {'task':gate.TASK,'status':'i03_raw_bf16_partition_repeat_and_final_kv_checked','stage_spec_sha256':gate.STAGE_SHA,
            'comparison_spec_sha256':'','source_map_sha256':{},'scope':gate.SCOPE.copy(),'thresholds':None,'acceptance':None,'full_core_complete':False,
            'native_executions_started_by_admission':0,'target_distribution_pairs':[{'kind':kind,'targets':{'status':'no_thresholds','coverage':{'expected':159,'paired':159}},
                'distributions':{'status':'no_thresholds','position_count':47},'thresholds':None,'acceptance':None} for kind in kinds],
            'native_final_kv_pairs':[{'metrics':{'status':'no_thresholds','per_tensor':[{}]*96,'global':{'count':27525120}},'thresholds':None,'acceptance':None} for _ in range(4)],
            'raw_derivation':{backend:{mode:{'raw_sha256':'c'*64,'largest_abs_logprob_derivation_delta':0.0} for mode in gate.MODES} for backend in ('GPU','NPU')}}
        self.documents['controller'] = {'task':'I03','status':'completed','returncode':0,'child_returncode':0,'timed_out':False,
            'native_executions_started':0,'whole_cpu_seconds':900,'child_work_seconds':870,'analysis_seconds':850,'tool_manifest_sha256':gate.TOOL_MANIFEST_SHA,
            'acceptance':None,'run':self.run,'tools_root':self.tools,'started_utc':'2026-11-06T16:00:00+00:00','finished_utc':'2026-11-06T16:00:30+00:00',
            'scope':gate.SCOPE.copy(),'argv':['/synthetic/python','-B',refs['analysis_source']['source_path'],'--spec',refs['comparison_spec']['source_path'],
                '--spec-sha256','','--output-dir',self.run+'/bundle','--timeout-seconds','850']}
        self.refs = refs; self.save()

    def save_ref(self,key):
        p = self.base/self.refs[key]['path']
        raw = self.raw_sources[key] if key in self.raw_sources else ((json.dumps(self.documents[key],indent=2,allow_nan=False)+'\n').encode())
        if key == 'tool_manifest': raw = (CASE/'transfer/tools/i03-cpu-compare-v1-20261106T154150Z/tool-bundle-manifest.json').read_bytes()
        p.write_bytes(raw); self.refs[key]['sha256'] = common.sha(p)

    def save(self):
        for key in ('analysis_source','artifact_helper_source','tool_manifest','GPU_map','NPU_map'): self.save_ref(key)
        for backend in ('GPU','NPU'):
            self.documents['comparison_spec']['endpoints'][backend]['source_map']['sha256'] = self.refs[backend+'_map']['sha256']
        self.save_ref('comparison_spec'); report = self.documents['report']
        report['comparison_spec_sha256'] = self.refs['comparison_spec']['sha256']; report['source_map_sha256'] = {b:self.refs[b+'_map']['sha256'] for b in ('GPU','NPU')}
        self.save_ref('report'); controller = self.documents['controller']
        for key in ('report','comparison_spec'): controller[key] = {'path':self.refs[key]['source_path'],'sha256':self.refs[key]['sha256']}
        controller['argv'][controller['argv'].index('--spec-sha256')+1] = self.refs['comparison_spec']['sha256']
        self.save_ref('controller'); self.path.write_text(json.dumps(self.wrapper,indent=2)+'\n',encoding='utf-8')
        self.digest = common.sha(self.path)

    def test_exact8_documents_pass_without_model_or_native(self):
        result = gate.prerequisite(self.path,self.digest)
        self.assertEqual(len(result['refs']),8); self.assertEqual(result['native_executions_started'],0)

    def test_resigned_failed_controller_missing_pair_and_shifted_spec_rejected(self):
        self.documents['controller']['returncode'] = 1; self.save()
        with self.assertRaisesRegex(ValueError,'successful bounded'): gate.prerequisite(self.path,self.digest)
        self.documents['controller']['returncode'] = 0; self.documents['report']['native_final_kv_pairs'].pop(); self.save()
        with self.assertRaisesRegex(ValueError,'pair inventory'): gate.prerequisite(self.path,self.digest)
        self.documents['report']['native_final_kv_pairs'] *= 0
        self.documents['comparison_spec']['stage_spec_sha256'] = 'd'*64; self.save()
        with self.assertRaises(ValueError): gate.prerequisite(self.path,self.digest)

    def test_native_admission_boolean_return_and_ambiguous_argv_fail(self):
        self.documents['controller']['returncode'] = False; self.save()
        with self.assertRaises(ValueError): gate.prerequisite(self.path,self.digest)
        self.documents['controller']['returncode'] = 0; self.documents['controller']['argv'] += ['--spec=other']; self.save()
        with self.assertRaisesRegex(ValueError,'unique literal'): gate.prerequisite(self.path,self.digest)

    def test_raw_analysis_tamper_and_unsafe_or_duplicate_copy_paths_fail(self):
        p = self.base/self.refs['analysis_source']['path']; p.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'proof bytes'): gate.prerequisite(self.path,self.digest)
        self.save(); self.wrapper['report']['path'] = '../escape'; self.path.write_text(json.dumps(self.wrapper)); self.digest = common.sha(self.path)
        with self.assertRaises(ValueError): gate.prerequisite(self.path,self.digest)

    def test_pure_helper_import_with_python_S_has_no_framework(self):
        program = "import importlib.util,sys; s=importlib.util.spec_from_file_location('pure',sys.argv[1]); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); assert not any(x in sys.modules for x in ('torch','torch_npu','numpy'))"
        result = subprocess.run([sys.executable,'-S','-B','-c',program,str(HERE/'i04_prerequisite_v1.py')],capture_output=True,timeout=20)
        self.assertEqual(result.returncode,0,result.stderr.decode(errors='replace'))


class NativeMaskFactoryCPU(unittest.TestCase):
    def test_pinned_factory_masks_valid_queries_for_both_padding_sides(self):
        if importlib.util.find_spec('torch') is None or importlib.util.find_spec('transformers') is None:
            self.skipTest('Actual Torch2.9/Transformers5.10.1 CPU fixture requires the isolated native CPU environment; no install or accelerator initialization here.')
        # The fresh child records the config import that registers TorchNPU.
        # Its initialization-state getters remain false around all 192 cells.
        path = CASE/'transfer/i04_cpu_mask_probe_v2.py'
        self.assertEqual(common.sha(path),'036788fadb665d766bed7c6ea4832ae0d80732eb588f06df5abee96f955429f1')
        env = dict(os.environ); env['TORCH_DEVICE_BACKEND_AUTOLOAD'] = '0'
        result = subprocess.run([sys.executable,'-B',str(path)],env=env,capture_output=True,timeout=65)
        self.assertEqual(result.returncode,0,result.stderr.decode(errors='replace'))
        observed = json.loads(result.stdout)
        self.assertEqual(observed['valid_query_key_cells_checked'],192)
        self.assertEqual(len(observed['observations']),8)
        self.assertEqual(set(observed['sources']),{'torch','numpy','transformers','masking_utils','configuration','import_utils','torch_npu_npu'})
        self.assertIs(observed['torch_npu_imported'],True)
        self.assertIs(observed['npu_initialized'],False); self.assertIs(observed['cuda_initialized'],False)
        self.assertEqual(observed['agent_hardware_or_availability_queries'],0)
        self.assertEqual(observed['library_internal_availability_queries'],'not_counted_and_not_prohibited')
        phases = observed['phase_observations']
        self.assertEqual([x['phase'] for x in phases],['after_torch','after_transformers','after_configuration','after_masking_utils','before_masks','after_masks'])
        self.assertTrue(all(x['npu_initialized'] is False and x['cuda_initialized'] is False for x in phases[2:]))
        self.assertEqual(observed['model_loads'],0); self.assertEqual(observed['native_model_forward_calls'],0)


if __name__ == '__main__': unittest.main()

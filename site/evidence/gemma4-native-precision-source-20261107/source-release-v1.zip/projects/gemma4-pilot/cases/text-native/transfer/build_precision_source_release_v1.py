"""Prepare a PRIVATE derived source ZIP through the owning evidence_bundle API.

No model, accelerator, remote connection, public-tree or Git action is used.
The explicit allowlist binds original bytes. Sanitized exports are NOT the
observed executable, and source pins are not silently repaired after rewriting.
"""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import ipaddress
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]
CAP, FILE_CAP = 64 * 1024**2, 16 * 1024**2
CLI_GUARD = '''\nSOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
'''
GATE_NAMES = {'GATES', 'NEW_PINS', 'CONTRACT_SHA', 'CPU_PROOF_SHA'}


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
def load(path): return json.loads(Path(path).read_bytes())


def relative(value):
    p = PurePosixPath(value)
    require(type(value) is str and value and not p.is_absolute() and str(p) == value and '\\' not in value and ':' not in value and
            all(part not in ('', '.', '..') for part in value.split('/')), 'canonical relative member required')
    return p


def write(path, raw):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream: stream.write(raw)


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m


def gate_keys(node):
    if isinstance(node, ast.Dict): return [ast.literal_eval(key) for key in node.keys]
    if isinstance(node, ast.DictComp): return list(ast.literal_eval(node.generators[0].iter))
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'fromkeys':
        return list(ast.literal_eval(node.args[0]))
    raise ValueError('unreviewed deployment gate expression')


def deactivate(text, item):
    changes = []; raw = text.encode(); tree = ast.parse(raw); edits = []
    if item['deployment_gate_module']:
        for node in tree.body:
            if not isinstance(node, ast.Assign): continue
            names = {target.id for target in node.targets if isinstance(target, ast.Name)} & GATE_NAMES
            if not names: continue
            value = node.value
            if isinstance(value, ast.Dict):
                require(value.keys and all(key is not None for key in value.keys), 'explicit deployment gate keys required')
                replacement = ast.unparse(ast.Dict(keys=value.keys, values=[ast.Constant(value=None) for _ in value.keys])).encode()
            elif isinstance(value, (ast.DictComp, ast.Call)):
                keys = gate_keys(value); require(keys and all(type(key) is str for key in keys), 'named deployment gate keys required')
                replacement = repr(dict.fromkeys(keys, None)).encode()
            else: replacement = b'None'
            lines = raw.splitlines(keepends=True)
            start = sum(map(len, lines[:value.lineno - 1])) + value.col_offset
            end = sum(map(len, lines[:value.end_lineno - 1])) + value.end_col_offset
            if raw[start:end] != replacement:
                edits.append((start, end, replacement)); changes.append({'rule': 'deployment_gate_reset', 'assignments': sorted(names),
                    'original_expression_sha256': sha(raw[start:end]), 'exported_expression': replacement.decode(), 'count': 1})
        for start, end, replacement in sorted(edits, reverse=True): raw = raw[:start] + replacement + raw[end:]
    if item['native_cli']:
        tree = ast.parse(raw); offset = 0; lines = raw.splitlines(keepends=True)
        for index, node in enumerate(tree.body):
            if index == 0 and isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                offset = sum(map(len, lines[:node.end_lineno])); continue
            if isinstance(node, ast.ImportFrom) and node.module == '__future__':
                offset = sum(map(len, lines[:node.end_lineno])); continue
            break
        raw = raw[:offset] + CLI_GUARD.encode() + raw[offset:]
        changes.append({'rule': 'native_CLI_refusal_before_runtime_imports', 'count': 1,
                        'default_deployment_enabled': None})
    ast.parse(raw); return raw.decode(), changes


def private_literals(texts):
    """Learn only literal deployment roots/identities, never publish originals."""
    rules = {}; accounts = set()
    patterns = [
        (r'/data/afs-[^/\s\'"()]+/[0-9]+/projects/[^/\s\'"()]+', '/srv/precision-task', 'AFS_task_root'),
        (r'/data/afs-[^/\s\'"()]+/[0-9]+', '/srv/precision-account', 'AFS_account_root'),
        (r'/srv/precision-user/user-job-dir/app/slai/user-[^/\s\'"()]+/[^/\s\'"()]+/gemma4_precision_[0-9]+', '/srv/npu-precision-task', 'NPU_task_root'),
        (r'[A-Za-z]:[/\\]+Users[/\\]+[^\'"\r\n]*?precision-skills-gemma4', '/workspace/PrecisionRSI', 'Windows_repository_root'),
        (r'/mnt/[a-z]/Users/[^/\s\'"()]+/[^\'"\r\n]*?precision-skills-gemma4', '/workspace/PrecisionRSI', 'WSL_repository_root'),
        (r'/home/[A-Za-z0-9_.-]+', '/srv/precision-user', 'home_account_root')]
    joined = '\n'.join(texts)
    for pattern, replacement, role in patterns:
        for match in re.finditer(pattern, joined): rules[match.group()] = (replacement, role)
    for match in re.finditer(r'/data/afs-[^/\s\'"()]+/([0-9]+)|/slai/user-([A-Za-z][A-Za-z0-9_]{6,})', joined):
        accounts.add(next(value for value in match.groups() if value))
    accounts -= {'synthetic', 'fixture', 'example', 'redacted', 'username'}
    for account in accounts: rules[account] = ('REDACTED_ACCOUNT', 'account_identifier')
    for match in re.finditer(r'(?<![A-Za-z0-9-])app-[a-z0-9]{8}(?![A-Za-z0-9-])', joined):
        rules[match.group()] = ('REDACTED_APP_ID', 'actual_app_identifier')
    for match in re.finditer(r'\b[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\b', joined):
        rules[match.group()] = ('REDACTED_DEVICE_UUID', 'device_UUID_literal')
    for match in re.finditer(r'(?<![0-9A-Za-z])(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?![0-9A-Za-z])', joined):
        try: address = ipaddress.ip_address(match.group())
        except ValueError: continue
        if address.is_private and not address.is_loopback and not address.is_unspecified:
            rules[match.group()] = ('REDACTED_PLATFORM_HOST', 'private_IP_literal')
    return [(old, new, role) for old, (new, role) in sorted(rules.items(), key=lambda row: (-len(row[0]), row[0]))]


def scan(text, learned):
    require('\0' not in text and not re.search(r'-{5}BEGIN [A-Z ]*PRIVATE KEY-{5}', text) and
            not re.search(r'hf_[A-Za-z0-9]{20,}', text), 'secret/binary signature in source export')
    require(not re.search(r'https?://[^/\s:]+:[^/@\s]+@', text), 'URL credential in source export')
    for original, _, role in learned:
        require(original not in text, 'unredacted private literal: ' + role)
    require(not re.search(r'/data/afs-[^/\s]+/[0-9]+|user-[A-Za-z][A-Za-z0-9_]{6,}|[A-Za-z]:[/\\]+Users[/\\]+', text),
            'unredacted deployment/account root')


def public_inputs(items, originals):
    by_target = {item['member']: originals[item['member']] for item in items}
    prefix = 'projects/gemma4-pilot/cases/text-native/inputs/'
    discovery = load_json = json.loads(by_target[prefix + 'discovery-v1/discovery.json'])
    reserved = json.loads(by_target[prefix + 'reserved-articles-v1/reserved.json'])
    for manifest in (discovery, reserved):
        source = manifest['source']
        require(source['repository'] == 'Salesforce/wikitext' and source['revision'] == 'b08601e04326c79dfdd32d625aee71d232d685c3' and
            source['sha256'] == 'e83889baabc497075506f91975be5fac0d45c5290b6b20582c8cd1e853d0c9f7' and
            source['license'] == 'CC-BY-SA-4.0', 'only verified attributed public WikiText token inputs may be released')
    count = 0
    for folder, manifest in (('discovery-v1/', discovery), ('reserved-articles-v1/', reserved)):
        for descriptor in manifest['samples']:
            raw = by_target[prefix + folder + descriptor['file']]
            require(sha(raw) == descriptor.get('file_sha256', descriptor.get('sha256')), 'frozen public input bytes differ')
            doc = json.loads(raw); sequence = doc['prompt'] + doc['continuation']
            require(doc['sample'] == descriptor['sample'] and len(doc['continuation']) == 32 and sequence[0] == 2 and
                all(type(value) is int and 0 <= value < 262144 for value in sequence), 'public token input identity/geometry differs')
            count += 1
    stress = json.loads(by_target[prefix + 'i04-prefix-stress-096-v1.json'])
    parent = json.loads(by_target[prefix + 'discovery-v1/wikitext2-discovery-001.json'])
    require(stress['prompt'] + stress['continuation'] == (parent['prompt'] + parent['continuation'])[:96], 'derived public prefix input differs')
    require(count == 56, 'eight discovery and48 reserved public inputs required')
    return {'public_token_inputs': 57, 'source_manifests': 2, 'license': 'CC-BY-SA-4.0', 'source_repository': 'Salesforce/wikitext',
        'source_revision': reserved['source']['revision'], 'source_sha256': reserved['source']['sha256'],
        'license_url': 'https://creativecommons.org/licenses/by-sa/4.0/', 'public_data_not_user_private_text': True}


def check_exports(folder, items):
    native = []; parsed = 0
    for item in items:
        path = folder.joinpath(*relative(item['member']).parts)
        if path.suffix == '.py': ast.parse(path.read_bytes()); parsed += 1
        if item['native_cli']: native.append(path)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', TORCH_DEVICE_BACKEND_AUTOLOAD='0')
    for path in native:
        result = subprocess.run([sys.executable, '-I', '-S', '-B', str(path)], cwd=folder, env=env, capture_output=True, timeout=10)
        require(result.returncode != 0 and b'SOURCE_RELEASE_NATIVE_DISABLED' in result.stderr, 'exported native entry did not refuse before imports')
    code = "import importlib.util,pathlib,sys; r=pathlib.Path(sys.argv[1]); a=r/'projects/gemma4-pilot/cases/text-native/adapters'; sys.path.insert(0,str(a)); import reserved48_cpu_artifacts_v2 as m; assert all(x is None for x in m.GATES.values()); s=r/'skills/precision-compare/scripts'; sys.path.insert(0,str(s)); import score_metrics,evidence_bundle; assert score_metrics.reduce_scores({('x',0,0):-1.},{('x',0,0):-1.})['mae_nat']==0; assert not any(n in sys.modules for n in ('torch','torch_npu','transformers')); print('CPU_IMPORT_NO_NATIVE_OK')"
    result = subprocess.run([sys.executable, '-I', '-S', '-B', '-c', code, str(folder)], env=env, capture_output=True, timeout=10)
    require(result.returncode == 0 and b'CPU_IMPORT_NO_NATIVE_OK' in result.stdout, 'safe CPU import/small scalar check failed: ' + result.stderr.decode(errors='replace'))
    return {'Python_AST_parsed': parsed, 'native_CLI_default_refusals_checked': len(native), 'safe_CPU_imports': 3,
        'tiny_source_scalar_reduction_checked': True, 'framework_imports': 0, 'native_model_executions': 0}


def build(manifest_path, output):
    started = time.monotonic(); manifest_path = Path(manifest_path); plan_raw = manifest_path.read_bytes(); plan = json.loads(plan_raw)
    require(plan['kind'] == 'allowlisted-derived-precision-source-release-v1' and plan['max_expanded_bytes'] == CAP and
        plan['max_file_bytes'] == FILE_CAP and plan['public_or_git_writes'] is False, 'explicit finite private source release plan required')
    output = Path(output).absolute()
    require(output.parent.is_dir() and not output.exists() and not output.is_symlink() and output.resolve().is_relative_to(HERE), 'exclusive private transfer output required')
    originals = {}; source_paths = {}; total = 0; members = set()
    for item in plan['files']:
        member = relative(item['member']).as_posix(); require(member not in members, 'duplicate export member'); members.add(member)
        source = REPO.joinpath(*relative(item['source']).parts)
        require(source.resolve(strict=True).is_relative_to(REPO) and source.is_file() and not source.is_symlink() and
            source.suffix in ('.py', '.json', '.md', '.txt', '') and source.stat().st_size <= FILE_CAP, 'bounded allowlisted original source required')
        raw = source.read_bytes(); require(sha(raw) == item['sha256'] and len(raw) == item['size_bytes'], 'allowlisted original bytes changed')
        if source.suffix == '.py' and '/adapters/' in member and not source.name.startswith('test_'):
            tree = ast.parse(raw)
            loads_model = any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and
                              node.func.attr == 'from_pretrained' for node in ast.walk(tree))
            require(not (loads_model and b'__main__' in raw) or item['native_cli'],
                    'direct model-loading adapter CLI missing native refusal classification')
        originals[member] = raw; source_paths[member] = source; total += len(raw)
    require(total < CAP, 'source allowlist exceeds64MiB')
    data = public_inputs(plan['files'], originals)
    learned = private_literals([raw.decode('utf8') for raw in originals.values()])
    transformed = {}; ledger = []; pairs = []
    for item in plan['files']:
        member = item['member']; text = originals[member].decode('utf8'); changes = []
        for old, new, role in learned:
            count = text.count(old)
            if count:
                text = text.replace(old, new); changes.append({'rule': role, 'original_literal_sha256': sha(old.encode()),
                    'exported_literal': new, 'count': count})
        if member.endswith('.py'): text, activation = deactivate(text, item); changes += activation
        scan(text, learned); raw = text.encode('utf8'); transformed[member] = raw
        if raw != originals[member]: pairs.append((originals[member].decode('utf8'), text))
        ledger.append({'path': member, 'original_repository_relative_path': item['source'], 'family': item['family'], 'role': item['role'],
            'original_sha256': sha(originals[member]), 'exported_sha256': sha(raw), 'original_bytes': len(originals[member]),
            'exported_bytes': len(raw), 'derived_export': raw != originals[member], 'per_change': changes,
            'native_deployment_gate_module': item['deployment_gate_module'], 'native_CLI_disabled': item['native_cli']})
    output.mkdir(mode=0o700); stage = output/'original-staging'; stage.mkdir()
    for member, raw in originals.items(): write(stage.joinpath(*relative(member).parts), raw)
    write(stage/'SOURCE-SELECTION.json', plan_raw)
    bundle_tool = REPO/'skills/precision-compare/scripts/evidence_bundle.py'; tool = module(bundle_tool, '_source_release_owning_bundle')
    archive = output/'source-release-v1.zip'
    packed = tool.pack(stage, archive, pairs, max_file_bytes=FILE_CAP, max_expanded_bytes=CAP)
    verified = tool.verify(archive, max_expanded_bytes=CAP); extracted = output/'verified-export'
    tool.extract(archive, extracted, max_expanded_bytes=CAP)
    for item in ledger:
        path = extracted.joinpath(*relative(item['path']).parts)
        require(path.read_bytes() == transformed[item['path']], 'owning archive transformation differs from pre-reviewed export')
        scan(path.read_text(encoding='utf8'), learned)
    checked = check_exports(extracted, plan['files'])
    for member, path in source_paths.items(): require(path.read_bytes() == originals[member], 'original source changed during release')
    index = {'schema_version': 1, 'kind': 'derived-precision-source-release-v1', 'status': 'private_review_candidate_not_published',
        'archive': {'filename': archive.name, 'sha256': packed['archive_sha256'], 'size_bytes': archive.stat().st_size},
        'owning_export_format': 'evidence_bundle.py indexed ZIP/EXPORT.json', 'owning_tool_sha256': sha(bundle_tool.read_bytes()),
        'source_selection_sha256': sha(plan_raw), 'max_expanded_bytes': CAP, 'max_file_bytes': FILE_CAP,
        'files': ledger, 'public_input_provenance': data, 'verification': checked,
        'archive_verified': packed['archive_sha256'] == verified['archive_sha256'],
        'all_original_files_preserved': True, 'exact_observed_executable_equivalence_claimed': False,
        'old_source_pins_repaired_or_activation_authorized': False, 'model_weights_arrays_environments_or_private_platform_proofs_included': False,
        'scope': plan['scope'], 'excluded': plan['excluded'], 'native_execution': False, 'public_or_git_modified': False,
        'elapsed_seconds': time.monotonic()-started}
    for value in (encoded(index).decode(), plan_raw.decode()): scan(value, learned)
    write(output/'source-release-v1.index.json', encoded(index))
    readme = next(item for item in plan['files'] if item['role'] == 'source_release_README')
    write(output/'README.md', transformed[readme['member']])
    print(json.dumps({'status': index['status'], 'archive': index['archive'], 'index_sha256': sha(encoded(index)),
        'members': len(ledger)+1, 'original_bytes': total, 'verification': checked, 'public_input_provenance': data}, indent=2))
    return index


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True); args = parser.parse_args(); build(args.manifest, args.output)

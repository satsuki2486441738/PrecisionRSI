"""Export/verify actual reserved48 CPU metadata; never rerun a probe or model.

The224-byte tiny safetensor remains a descriptor. Original source paths/aliases,
all71 frozen sources, inventory and logs are preserved without JSON rewriting.
"""
import argparse
import ast
import base64
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import signal
import tarfile
import time

CASE = 'projects/gemma4-pilot/cases/text-native'
SUBDIR = 'reserved48-english-20261107/cpu-prerequisite-v1'
SELF = CASE + '/transfer/reserved48_cpu_operations_v1.py'
PROBE = CASE + '/transfer/reserved48_cpu_probe_v1.py'
COMMON = CASE + '/adapters/reserved48_common_v1.py'
EXPECTED = CASE + '/adapters/reserved48_expected_v1.py'
DATA = CASE + '/inputs/reserved-articles-v1/reserved.json'
CONFIG = CASE + '/transfer/local-snapshot-20261106T054650Z/config.json'
SOURCE_MANIFEST_SHA = 'ba24710328bce699707d9720272f2caedd16bf06ea87bd115dd2392bea7757d2'
SOURCE_ARCHIVE_SHA = '2a0de8fc70e0875470955bddf4bd6e1d90c99d33bd1a6c105f3a0b7dbb819dbe'
OPS_SHA = '6bec7f57c21f8ec033166768ba7736ed10677c3dd650b0fcc9e194247d638db4'
ACTUAL_CONTROLLER_SHA = '0ca1eee4722818f0323cce51edf4fb1e1f035f2dfc0c66cdf3ea8e2f72d19715'
ACTUAL_PROBE_SHA = '7868314bf203c892c8a9d90390bb9f25b00ad48c34dda842e946a7d638149047'
ACTUAL_INVENTORY_SHA = 'f0daf25cfa44f41385e348397b7766b07cf427014134e484b6e242bd5f242be6'
ACTUAL_RUNTIME_MAP_SHA = '83f197a9734765b2332356cc5ba365c3ead7d8f4cf2aa4023371f72d14bd2b02'
ACTUAL_TINY = {'sha256': '977bc2a8c38796342f1f764bc4f3ed271e79769e2749ceadc285479132a6f9d2', 'size_bytes': 224}
FROZEN = {
 COMMON: 'bf1bd4176fd209fd6fabfbda22bd9fb246cfdf12e72d89d7ca77417ad8546e58',
 CASE + '/adapters/reserved48_native_v1.py': 'd7bc0e8115769d4fcbe2aecec6e6ee550517fa7a27e7afef6b8b3844e20fe3e2',
 EXPECTED: 'ad229e986bab26fb697ab58120d63b948123c3ad52a1a51383a09495e719c05e',
 CASE + '/adapters/test_reserved48_common_v1.py': 'd829d846e412cb5eccc1980fe3458d860ce7cae2bbe8f0212938239eea34cf68',
 CASE + '/adapters/test_reserved48_expected_v1.py': 'ede777ad404b068110771826c7ac81bbd9f4ce7a0db415366b2635bf076f24df',
 CASE + '/adapters/test_reserved48_native_v1.py': '4599130cd52557966f47afc5002de4d3a8844c1a2976f39ea85e7d2e7ffc485f',
 PROBE: '0fb33d04d85d492d7cf8863e598be082ac1743a6987eaac2a6dd2d4972cc541c',
 CASE + '/transfer/i04_cpu_stage_operations_v3.py': '36973a846475161e3ab05ff65c75bd56a535bcaad2056f3e42e6fa498d4002a2',
 DATA: '10f6b1a6976507e1af65706ddd4bb61d9276c43ae443b2a6852935e2967dca37',
 CONFIG: '14f38c5492ffc9cbcdf808647ca0c025bb5b9b4eb737526347134d500ace6098'}
RUNTIME = {'torch', 'numpy', 'safetensors', 'safetensors_torch', 'torch_tensor', 'inference_capture', 'artifact_io', 'conditions'}
PHASES = ['after_torch', 'after_runtime_imports', 'before_tests', 'after_tests', 'after_tiny_roundtrip']
KIND = 'reserved48-cpu-validation-prerequisite-v1'
MAX_MEMBER, MAX_RAW, MAX_GZIP, MAX_ENVELOPE = 16*1024**2, 64*1024**2, 16*1024**2, 24*1024**2
HEX = re.compile(r'[a-f0-9]{64}')


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def parse(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            require(key not in out, 'duplicate JSON key'); out[key] = value
        return out
    doc = json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
    json.dumps(doc, allow_nan=False)
    return doc


def put(path, doc):
    with Path(path).open('xb') as stream: stream.write(encoded(doc))


def origin(value):
    require(isinstance(value, str) and value.startswith('/') and '\\' not in value and str(PurePosixPath(value)) == value and
            all(x not in ('', '.', '..') for x in value.split('/')[1:]), 'original canonical absolute POSIX path required')
    return PurePosixPath(value)


def relative(value):
    require(isinstance(value, str) and value and '\\' not in value and not PurePosixPath(value).is_absolute() and
            str(PurePosixPath(value)) == value and all(x not in ('', '.', '..') for x in value.split('/')), 'canonical relative proof path required')
    return PurePosixPath(value)


def reject_array(path):
    require(not str(path).lower().endswith(('.npy', '.safetensors', '.tar', '.gz', '.bin', '.pt', '.whl', '.part')),
            'array/archive is descriptor-only and cannot be opened as CPU proof metadata')


def original(path, root=None):
    path = Path(path); reject_array(path)
    require(path.is_absolute() and path.is_file() and not path.is_symlink() and path.stat().st_size <= MAX_MEMBER,
            'bounded original regular metadata required')
    if root is not None:
        require(path.is_relative_to(root) and path.resolve().is_relative_to(root), 'original CPU metadata escapes explicit root')
        cursor = path
        while cursor != root:
            require(not cursor.is_symlink(), 'symlink in original CPU metadata path'); cursor = cursor.parent
    with path.open('rb') as stream: raw = stream.read(MAX_MEMBER + 1)
    require(len(raw) <= MAX_MEMBER, 'metadata grew beyond bounded read')
    return raw


def literal(source, name):
    tree = ast.parse(source)
    matches = [ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign) and
               any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]
    require(len(matches) == 1, 'unique literal source declaration required: ' + name)
    return matches[0]


def expected_source_closure(manifest, sources):
    """Independently derive10+12+48+1 originals from frozen bytes, without import."""
    require(sha(sources[COMMON]) == FROZEN[COMMON] and sha(sources[DATA]) == FROZEN[DATA], 'original common/data manifest changed')
    old = literal(sources[COMMON], 'OLD_PINS')
    require(isinstance(old, dict) and len(old) == 12 and all(isinstance(k, str) and HEX.fullmatch(v) for k, v in old.items()),
            'reviewed12-helper literal closure differs')
    require(all(v is None for v in literal(sources[COMMON], 'GATES').values()) and
            literal(sources[EXPECTED], 'STAGE_SHA256') is None, 'CPU proof must retain unactivated production gates')
    wanted = {**FROZEN}; require(not set(wanted) & set(old), 'overlapping frozen source identities'); wanted.update(old)
    data = parse(sources[DATA]); require(data['state'] == 'frozen_reserved_english_article_validation' and len(data['samples']) == 48 and
        data['requested_per_bin'] == 12 and data['continuation_tokens'] == 32 and data['selection_on_model_outputs'] is False,
        'original reserved48 data manifest semantics differ')
    for item in data['samples']:
        name = item['file']; require(PurePosixPath(name).name == name and name.endswith('.json') and '\\' not in name, 'flat original input filename required')
        key = CASE + '/inputs/reserved-articles-v1/' + name
        require(key not in wanted and HEX.fullmatch(item['sha256']), 'duplicate or invalid reserved input source'); wanted[key] = item['sha256']
    wanted[SELF] = OPS_SHA
    require(len(wanted) == 71 and set(manifest['files']) == set(sources) == set(wanted), 'all71 original source files required')
    for name, digest in wanted.items():
        relative(name); raw = sources[name]
        require(sha(raw) == digest and manifest['files'][name] == {'sha256': digest, 'size_bytes': len(raw)}, 'source manifest/hash/size changed: ' + name)
    return wanted


def audit(files, roles):
    """Verify original successful CPU metadata; no framework or tensor access."""
    require(isinstance(files, dict) and isinstance(roles, dict) and set(roles.values()) == set(files) and
            len(files) <= 128 and sum(map(len, files.values())) <= MAX_RAW, 'complete bounded original metadata closure required')
    get = lambda name: files[roles[name]]
    doc = lambda name: parse(get(name))
    controller, probe, inventory, runtime = (doc(n) for n in ('controller', 'probe', 'inventory', 'runtime_map'))
    require(sha(get('controller')) == ACTUAL_CONTROLLER_SHA and sha(get('probe')) == ACTUAL_PROBE_SHA and
            sha(get('inventory')) == ACTUAL_INVENTORY_SHA and sha(get('runtime_map')) == ACTUAL_RUNTIME_MAP_SHA,
            'machine-observed actual controller/probe/inventory/runtime-map bytes differ')
    start, stage, attempt, manifest = (doc(n) for n in ('start', 'stage', 'attempt', 'manifest'))
    argv = start['argv']; require(isinstance(argv, list) and argv.count('--root') == 1, 'literal original CPU start argv required')
    root = origin(argv[argv.index('--root') + 1]); target = root / SUBDIR; source = target / 'source'
    run = origin(roles['controller']).parent; require(run.parent == target / 'runs' and
        re.fullmatch(r'compare-reserved48-actual-cpu-\d{8}T\d{6}Z', run.name), 'actual CPU run namespace differs')
    base = {'start': target/'cpu-start-once.json', 'attempt': target/'cpu-attempt-once.json', 'stage': target/'stage-receipt.json',
        'manifest': target/'source-manifest.json', 'validation_stdout': target/'cpu-validation.stdout', 'validation_stderr': target/'cpu-validation.stderr',
        'controller_start': run/'controller-start.json', 'controller': run/'controller-receipt.json', 'inventory': run/'independent-inventory.json',
        'probe_stdout': run/'probe.stdout', 'probe_stderr': run/'probe.stderr', 'probe': run/'probe/receipt.json',
        'tests_stderr': run/'probe/tests.stderr', 'runtime_map': run/'runtime-source-map.json'}
    require(all(roles[k] == str(v) for k, v in base.items()), 'original CPU metadata identities differ')
    require(sha(get('manifest')) == SOURCE_MANIFEST_SHA and manifest['kind'] == 'reserved48-actual-tiny-cpu-source-v1' and
        manifest['tests'] == 23 and manifest['production_model_loads'] == manifest['native_executions_started'] == 0 and
        (manifest['whole_cpu_seconds'], manifest['work_seconds'], manifest['cleanup_reserve_seconds'], manifest['probe_seconds'], manifest['child_seconds']) == (180,160,20,90,120),
        'actual CPU71-source manifest and finite scope differ')
    sources = {name: files[str(source/relative(name))] for name in manifest['files']}
    wanted = expected_source_closure(manifest, sources)
    require(all(roles['source/'+name] == str(source/name) for name in wanted), 'original71-source path identities differ')
    python = argv[0]; expected_argv = [python, '-S', '-B', str(source/SELF), 'run', '--root', str(root), '--manifest-sha256', SOURCE_MANIFEST_SHA]
    require(argv == expected_argv and start['status'] == 'reserved48_actual_CPU_spawned_not_result' and start['source_sha256'] == OPS_SHA and
        start['source_manifest_sha256'] == SOURCE_MANIFEST_SHA and (start['whole_cpu_seconds'],start['cleanup_reserve_seconds']) == (180,20) and
        start['production_model_loads'] == start['native_executions_started'] == 0 and start['native_claim_created'] is False and start['automatic_retry'] is False and
        start['stdout'] == roles['validation_stdout'] and start['stderr'] == roles['validation_stderr'], 'actual once-only CPU start provenance differs')
    require(stage['status'] == 'reserved48_cpu_sources_staged_not_native' and stage['source_files'] == 71 and
        stage['manifest_sha256'] == SOURCE_MANIFEST_SHA and stage['archive_sha256'] == SOURCE_ARCHIVE_SHA and
        stage['production_model_loads'] == stage['native_executions_started'] == 0 and stage['native_claim_created'] is False and
        attempt['manifest_sha256'] == SOURCE_MANIFEST_SHA and attempt['independent_inventory_sha256'] == ACTUAL_INVENTORY_SHA and
        attempt['automatic_retry'] is False and attempt['native_claim_created'] is False and attempt['production_model_loads'] == 0,
        'source stage/CPU-only permanent attempt differs')
    require(controller['task'] == 'reserved48-cpu-validation-v1' and controller['status'] == 'completed' and
        type(controller['returncode']) is int and controller['returncode'] == 0 and controller['source_manifest_sha256'] == SOURCE_MANIFEST_SHA and
        controller['source_root'] == str(source) and (controller['whole_cpu_seconds'],controller['cleanup_reserve_seconds'],controller['child_seconds'],controller['probe_seconds']) == (180,20,120,90) and
        controller['automatic_retry'] is controller['native_claim_created'] is False and controller['production_model_loads'] == controller['native_executions_started'] == 0 and
        controller['actual_tests'] == 23 and controller['test_skips'] == 0 and controller['actual_tiny_checks'] == 8 and controller['remaining_owned_process_groups'] == [] and
        0 <= controller['elapsed_seconds'] < 160, 'actual terminal23zeroSkip/8tiny/cleanup scope differs')
    initial = doc('controller_start')
    require(initial['status'] == 'running' and all(initial[k] == controller[k] for k in
        ('task','started_utc','source_manifest_sha256','source_root','whole_cpu_seconds','cleanup_reserve_seconds','child_seconds','probe_seconds')),
        'original controller-start scope differs')
    ref = lambda name: {'path': roles[name], 'sha256': sha(get(name)), 'size_bytes': len(get(name))}
    terminal = doc('validation_stdout')
    require(terminal['status'] == 'completed' and terminal['returncode'] == 0 and terminal['receipt'] == ref('controller') and
        terminal['actual_tests'] == 23 and terminal['actual_tiny_checks'] == 8, 'actual CPU stdout/controller raw binding differs')
    require(controller['probe'] == ref('probe') and controller['independent_inventory'] == ref('inventory') and controller['runtime_source_map'] == ref('runtime_map'),
        'actual original probe/inventory/runtime refs differ')
    steps = controller['steps']; require(len(steps) == 1, 'exact one original owned CPU child required'); step = steps[0]
    child = [python, '-B', str(source/PROBE), '--source-root', str(source), '--operations-sha256', OPS_SHA, '--manifest-sha256', SOURCE_MANIFEST_SHA,
        '--expected-inventory', roles['inventory'], '--expected-inventory-sha256', ACTUAL_INVENTORY_SHA, '--output', str(run/'probe')]
    require(step['argv'] == child and step['returncode'] == 0 and step['timed_out'] is False and step['timeout_seconds'] == 120 and
        type(step['cleanup']['owned_process_group']) is int and step['cleanup']['owned_process_group'] > 0 and step['cleanup']['remaining_owned_process_group'] is False,
        'original owned CPU child argv/timeout/cleanup differs')
    for stream in ('stdout','stderr'):
        name = 'probe_'+stream; require(step[stream] == {'path': roles[name], 'sha256': sha(get(name)), 'bytes': len(get(name))}, 'original CPU child log bytes differ')
    require(probe['task'] == 'reserved48-actual-tiny-cpu-prerequisite-v1' and probe['status'] == 'completed' and probe['returncode'] == 0 and
        probe['timeout_seconds'] == 90 and probe['source'] == ref('source/'+PROBE) and probe['operations_source'] == ref('source/'+SELF) and
        probe['source_manifest_sha256'] == SOURCE_MANIFEST_SHA and probe['independent_inventory'] == ref('inventory'), 'actual CPU probe source/scope differs')
    require(all(type(probe[k]) is int and probe[k] == 0 for k in ('production_model_loads','native_model_forward_calls',
        'agent_accelerator_initialization_requests','agent_hardware_or_availability_queries')) and probe['library_internal_availability_queries'] == 'not instrumented' and
        probe['device_initialization_checks'] == 'getter_only' and probe['production_activation_gates'] == 'all None', 'CPU-only source/query/activation scope differs')
    tests = probe['tests']; require(tests['run'] == 23 and tests['skipped'] == tests['failures'] == tests['errors'] == 0 and
        tests['modules'] == ['test_reserved48_common_v1','test_reserved48_expected_v1','test_reserved48_native_v1'] and
        tests['real_torch_BF16_fixture_enabled'] is True and tests['transcript'] == ref('tests_stderr'), 'actual23 test transcript scope differs')
    text = get('tests_stderr').decode('utf8'); require(re.search(r'Ran 23 tests? in ', text) and re.search(r'\nOK\s*$',text) and 'skipped' not in text, 'all23 tests must pass without skips')
    phases = probe['phase_observations']; require([p['phase'] for p in phases] == PHASES and all(type(p['torch_npu_imported']) is bool and
        type(p['npu_namespace_registered']) is bool and p['npu_initialized'] is (False if p['npu_namespace_registered'] else None) and p['cuda_initialized'] is False for p in phases),
        'actual five getter-only CPU initialization phases differ')
    require(probe['versions']['torch'] == '2.9.0+cpu' and probe['versions']['numpy'] == '1.26.4' and probe['versions']['safetensors'] == '0.8.0', 'actual CPU runtime versions differ')
    tiny = probe['actual_tiny_roundtrip']; require(tiny['checks_passed'] == len(set(tiny['checks'])) == 8 and
        (tiny['native_rows'],tiny['target_scores'],tiny['selected_rows'],tiny['vocabulary']) == (65,64,4,7) and
        tiny['native_model_loads'] == tiny['native_model_forward_calls'] == 0 and tiny['full_vocabulary_production_geometry_claim'] is False,
        'actual tiny65-row/64-target/eight-check scope differs')
    descriptor = tiny['artifact']; require(descriptor == {'path': str(run/'probe/tiny-selected-native-logits.safetensors'), **ACTUAL_TINY} and
        HEX.fullmatch(tiny['raw_stream_sha256']) and HEX.fullmatch(tiny['selected_payload_sha256']), 'actual224-byte tiny descriptor differs')
    require(inventory['kind'] == 'reserved48-independent-expected-inventory' and inventory['stage_spec_sha256'] is None and
        inventory['manifest_sha256'] == FROZEN[DATA] and inventory['config_sha256'] == FROZEN[CONFIG] and
        len(inventory['samples']) == inventory['counts']['inputs'] == 48 and inventory['counts']['inputs_per_bin'] == 12 and
        inventory['native_executions_started'] == 0 and inventory['thresholds'] is inventory['acceptance'] is None, 'original pre-stage independent inventory scope differs')
    summary = doc('probe_stdout'); require(summary['status'] == 'completed' and summary['returncode'] == 0 and summary['receipt'] == ref('probe') and
        summary['tests_run'] == 23 and summary['skips'] == 0, 'actual probe stdout raw binding differs')
    require(set(runtime) == set(probe['runtime_sources']) == RUNTIME, 'all eight actual runtime source aliases required')
    expected_roles = {**{k: str(v) for k,v in base.items()}, **{'source/'+name: str(source/name) for name in wanted}}
    aliases = {}
    for name in sorted(RUNTIME):
        item = runtime[name]; raw = probe['runtime_sources'][name]; origin(raw['path'])
        require(item['source'] == raw and item['copy']['path'] == str(run/('runtime-sources/'+name+'.py')), 'original runtime alias/copy paths differ')
        for kind in ('source','copy'):
            role = ('runtime_original/' if kind == 'source' else 'runtime_copy/')+name; actual = item[kind]; expected_roles[role] = actual['path']
            require(ref(role) == actual and actual['path'].endswith(('.py','.pyi')), 'runtime original and copied byte provenance differs')
        require(item['source']['sha256'] == item['copy']['sha256'] and item['source']['size_bytes'] == item['copy']['size_bytes'], 'runtime alias bytes differ')
        aliases[name] = item
    require(roles == expected_roles and set(files) == set(expected_roles.values()), 'all derived original metadata/source aliases must be retained exactly')
    return {'actual_tests':23,'test_skips':0,'actual_tiny_checks':8,'native_rows_in_tiny_CPU_fixture':65,'source_files':71,
        'original_document_count':len(files),'independent_inventory_sha256':ACTUAL_INVENTORY_SHA,'runtime_source_aliases':aliases,
        'phase_observations':phases,'omitted_tiny_CPU_tensor_descriptor':descriptor,'tiny_tensor_payload_freshly_verified_by_export':False,
        'production_model_loads':0,'native_model_forward_calls':0,'native_executions_started':0,'production_stage_spec_sha256':None,
        'scope':'Original actual tiny Torch CPU and23 zero-skip tests only; no production model/backend, representative numerical quality, speed or native activation claim.'}


def prerequisite(path, digest):
    path = Path(path); raw = original(path); require(sha(raw) == digest, 'external actual CPU wrapper SHA differs'); wrapper = parse(raw)
    require(wrapper['kind'] == KIND and wrapper['native_prerequisite_valid'] is True and wrapper['native_execution_allowed_by_export'] is False,
            'failed/partial diagnostic is not an actual CPU prerequisite')
    files, refs, seen = {}, {}, set(); total = 0
    for source_path, item in wrapper['files'].items():
        origin(source_path); require(set(item) == {'path','source_path','sha256','size_bytes'} and item['source_path'] == source_path and HEX.fullmatch(item['sha256']), 'exact original portable ref required')
        rel = relative(item['path']); require(str(rel).startswith('proof/') and str(rel) not in seen, 'distinct portable proof path required')
        p = path.parent.joinpath(*rel.parts); require(p.resolve().is_relative_to(path.parent.resolve()), 'portable proof escapes root')
        body = original(p, path.parent.resolve()); total += len(body); require(total <= MAX_RAW and sha(body) == item['sha256'] and len(body) == item['size_bytes'], 'portable original metadata bytes differ')
        files[source_path] = body; refs[source_path] = {'path':str(p.resolve()),'sha256':sha(body),'size_bytes':len(body)}; seen.add(str(rel))
    require(wrapper['summary'] == audit(files, wrapper['roles']), 'portable CPU summary differs from original proof')
    require(sha(original(path)) == digest, 'actual CPU wrapper changed during checks')
    return {'document':wrapper,'refs':refs,'prerequisite_sha256':digest,'native_executions_started':0}


verify_portable = prerequisite


def export(root, output):
    root = Path(root); require(os.name == 'posix' and root.is_dir() and not root.is_symlink(), 'explicit original POSIX root required'); root = root.resolve(strict=True)
    target = root/SUBDIR; started = time.monotonic(); old = signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError('reserved48 CPU proof export90s')))
    signal.setitimer(signal.ITIMER_REAL,90)
    try:
        files, roles = {}, {}; total = 0
        def add(role, p, outside=False):
            nonlocal total
            p = Path(p); reject_array(p)
            if not p.exists(): return
            key = str(p); body = original(p, None if outside else root)
            if key in files: require(files[key] == body, 'aliased original CPU bytes changed')
            else:
                total += len(body); require(total <= MAX_RAW, 'CPU proof metadata exceeds64MiB'); files[key] = body
            roles[role] = key
        for role, name in {'start':'cpu-start-once.json','attempt':'cpu-attempt-once.json','stage':'stage-receipt.json','manifest':'source-manifest.json',
                           'validation_stdout':'cpu-validation.stdout','validation_stderr':'cpu-validation.stderr'}.items(): add(role,target/name)
        terminal = parse(files[roles['validation_stdout']]); controller_path = Path(terminal['receipt']['path'])
        require(controller_path.parent.parent == target/'runs', 'actual CPU controller escapes source task'); run = controller_path.parent
        for role, name in {'controller_start':'controller-start.json','controller':'controller-receipt.json','inventory':'independent-inventory.json','probe_stdout':'probe.stdout',
                           'probe_stderr':'probe.stderr','probe':'probe/receipt.json','tests_stderr':'probe/tests.stderr','runtime_map':'runtime-source-map.json'}.items(): add(role,run/name)
        manifest = parse(files[roles['manifest']])
        require(sha(files[roles['manifest']]) == SOURCE_MANIFEST_SHA, 'actual source manifest changed before traversal')
        for name in manifest['files']: add('source/'+name,target/'source'/str(relative(name)))
        # Authenticate the actual metadata before following global runtime source
        # aliases. The tiny tensor descriptor is never passed to add()/Path IO.
        if roles.get('probe') in files and sha(files[roles['probe']]) == ACTUAL_PROBE_SHA and roles.get('runtime_map') in files and sha(files[roles['runtime_map']]) == ACTUAL_RUNTIME_MAP_SHA:
            runtime = parse(files[roles['runtime_map']])
            for name, item in runtime.items():
                require(name in RUNTIME, 'unexpected actual runtime alias'); add('runtime_original/'+name,item['source']['path'],True)
                p = Path(item['copy']['path']); require(p == run/('runtime-sources/'+name+'.py'), 'runtime copy escapes exact owned namespace'); add('runtime_copy/'+name,p)
        valid, error = False, None
        try: summary = audit(files,roles); valid = True
        except (ValueError,KeyError,TypeError,IndexError) as exc: summary = {'production_model_loads':0,'native_executions_started':0}; error = str(exc)
        output = Path(output); exports = root/'exports'
        require(exports.is_dir() and not exports.is_symlink() and exports.resolve().is_relative_to(root) and
            output.is_absolute() and output.parent == exports and output.resolve().is_relative_to(root) and
            not output.exists() and not output.is_symlink(), 'exclusive new original-root exports directory required')
        output.mkdir(mode=0o700); (output/'proof').mkdir(); catalog = {}
        for index, (source_path, body) in enumerate(sorted(files.items())):
            suffix = '.py' if source_path.endswith(('.py','.pyi')) else '.txt' if source_path.endswith(('.stderr','.stdout')) else '.json'
            member = 'proof/%03d%s' % (index,suffix)
            with (output/member).open('xb') as stream: stream.write(body)
            require(sha(original(Path(source_path))) == sha(body), 'original CPU source changed while copying')
            catalog[source_path] = {'path':member,'source_path':source_path,'sha256':sha(body),'size_bytes':len(body)}
        wrapper = {'schema_version':1,'kind':KIND if valid else 'reserved48-cpu-failed-diagnostic-v1','native_prerequisite_valid':valid,
            'files':catalog,'roles':roles,'summary':summary,'diagnostic_reason':error,'native_execution_allowed_by_export':False,
            'production_model_loads':0,'native_executions_started':0,'acceptance':None}
        wrapper_path = output/'prerequisite.json'; put(wrapper_path,wrapper)
        if valid: prerequisite(wrapper_path,sha(wrapper_path.read_bytes()))
        members = {'prerequisite.json':{'sha256':sha(wrapper_path.read_bytes()),'size_bytes':wrapper_path.stat().st_size},
            **{v['path']:{'sha256':v['sha256'],'size_bytes':v['size_bytes']} for v in catalog.values()}}
        archive = output.with_name(output.name+'.tar.gz')
        with archive.open('xb') as stream, tarfile.open(fileobj=stream,mode='w:gz',format=tarfile.USTAR_FORMAT) as package:
            for name, item in sorted(members.items()):
                body = (output/name).read_bytes(); require(sha(body) == item['sha256'], 'copied proof member changed')
                info = tarfile.TarInfo(name); info.size = len(body); info.mode = 0o600; package.addfile(info,io.BytesIO(body))
        require(archive.stat().st_size <= MAX_GZIP, 'CPU proof gzip exceeds16MiB')
        for source_path, body in files.items(): require(sha(original(Path(source_path))) == sha(body), 'original CPU metadata changed during archiving')
        raw = archive.read_bytes(); envelope = {'schema_version':1,'kind':'reserved48-cpu-proof-small-transport-v1','native_prerequisite_valid':valid,
            'prerequisite_sha256':sha(wrapper_path.read_bytes()),'archive':{'path':str(archive),'bytes':len(raw),'sha256':sha(raw),'base64':base64.b64encode(raw).decode()},
            'regular_members':len(members),'files':members,'production_native_arrays_read':0,'tiny_CPU_tensor_stat_open_copy_count':0,'native_executions_started':0,'acceptance':None}
        envelope_path = output.with_name(output.name+'-json-base64.txt'); put(envelope_path,envelope); require(envelope_path.stat().st_size <= MAX_ENVELOPE, 'CPU proof envelope exceeds24MiB')
        return {'status':'actual_reserved48_CPU_proof_exported' if valid else 'reserved48_CPU_diagnostic_exported_not_prerequisite','native_prerequisite_valid':valid,
            'wrapper_path':str(wrapper_path),'wrapper_sha256':envelope['prerequisite_sha256'],'archive':{k:v for k,v in envelope['archive'].items() if k!='base64'},
            'envelope':{'path':str(envelope_path),'bytes':envelope_path.stat().st_size,'sha256':sha(envelope_path.read_bytes())},'regular_members':len(members),
            'original_documents':len(files),'elapsed_seconds':time.monotonic()-started,'production_native_arrays_read':0,'tiny_CPU_tensor_stat_open_copy_count':0,
            'native_executions_started':0,'diagnostic_reason':error,'acceptance':None}
    finally: signal.setitimer(signal.ITIMER_REAL,0); signal.signal(signal.SIGALRM,old)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('--root',type=Path); p.add_argument('--output',type=Path)
    p.add_argument('--verify-portable',type=Path); p.add_argument('--sha256'); args = p.parse_args()
    if args.verify_portable:
        r = prerequisite(args.verify_portable,args.sha256); print(json.dumps({'status':'actual_reserved48_CPU_portable_proof_checked','documents':len(r['refs']),
            'prerequisite_sha256':r['prerequisite_sha256'],'native_executions_started':0},indent=2))
    else:
        require(args.root is not None and args.output is not None,'root and new output required'); print(json.dumps(export(args.root,args.output),indent=2))

"""Verify an actual I04 GPU full gzip, then wrap its unchanged bytes for UI upload.

Inputs are actual export receipt pins, never inferred archive identities. Full
mapped-file byte hashes are checked without extracting another1GiB array copy.
No numerical replay, model/device call, resource operation or Git write occurs.
"""
import argparse
import hashlib
from pathlib import Path,PurePosixPath
import re
import shutil
import signal
import tarfile
import time

import reassemble_i04_gpu_transport_v1 as transport

ASSEMBLER_SHA='1b56613bd3c6d3a97260415bc90de8fd8aec03d1f88eb52610975055593a0e2d'
require=transport.require


def verify_tools():
    require(Path(transport.__file__).resolve()==Path(__file__).with_name('reassemble_i04_gpu_transport_v1.py').resolve() and
        transport.sha(transport.__file__)==ASSEMBLER_SHA,'frozen colocated transport dependency differs')


def verify_full_archive(archive,size,digest,map_sha,logical,deadline):
    archive=transport.regular(archive)
    require(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,180}\.tar\.gz',archive.name) and type(size) is int and 0<size<=transport.ENCODED_CAP and
        type(logical) is int and 0<logical<=transport.LOGICAL_CAP and transport.HEX.fullmatch(digest) and transport.HEX.fullmatch(map_sha) and
        archive.stat().st_size==size and transport.sha(archive,deadline)==digest,'actual externally frozen gzip size/SHA differs')
    with tarfile.open(archive,'r:gz') as package:
        members=[];names=set();total=0
        # Check declared sizes before skipping each member's data. Do not let an
        # arbitrary huge member expand before the logical budget is inspected.
        for item in package:
            require(time.monotonic()<deadline,'full archive audit deadline reached');transport.safe(item.name)
            require(item.isfile() and not item.sparse and item.name not in names and 0<=item.size<=transport.LOGICAL_CAP,'unique regular GPU payload members required')
            names.add(item.name);members.append(item);total+=item.size
            require(len(members)<=4096 and total<=transport.LOGICAL_CAP,'GPU archive expanded budget exceeded')
        require(total==logical and {'source-map.json','export-summary.json'}<=names and
            all(all(str(parent) not in names for parent in PurePosixPath(name).parents if str(parent)!='.') for name in names),'payload size/topology differs')
        source_map=next(m for m in members if m.name=='source-map.json');require(source_map.size<=4*1024**2,'bounded source-map JSON required')
        raw=package.extractfile(source_map).read(source_map.size+1)
        require(len(raw)==source_map.size and hashlib.sha256(raw).hexdigest()==map_sha,'actual top source-map SHA differs')
        doc=transport.parse(raw);require(doc.get('schema_version')==1 and doc.get('request',{}).get('task')=='I04' and doc['request'].get('backend')=='GPU' and
            doc.get('full_array_hashes_checked')==286 and doc.get('retained_array_count')==0,'complete copied I04 GPU286 source map required')
        files=doc['files'];by_copied={};npy=raw_count=0
        for original,ref in files.items():
            require(isinstance(original,str) and PurePosixPath(original).is_absolute() and '..' not in PurePosixPath(original).parts and '\\' not in original and
                not ref.get('retained_at_source') and type(ref.get('size')) is int and ref['size']>=0 and transport.HEX.fullmatch(ref['sha256']),
                'original GPU path/hash/size or copied-byte descriptor differs')
            relative=str(transport.safe(ref['path']));require(relative.startswith('payload/') and relative not in by_copied,'unique copied payload path required')
            by_copied[relative]=ref
            if original.endswith('.npy'):npy+=1
            if original.endswith('.safetensors'):
                require(PurePosixPath(original).name=='raw-native-logits.safetensors','model weights or unknown native tensor file must not be transported');raw_count+=1
        require((npy,raw_count)==(282,4) and names==set(by_copied)|{'source-map.json','export-summary.json'} and len(by_copied)==len(files),
            'exact282NPY/four raw and original mapped member coverage required')
        require(doc['request'].get('outer_receipt') in files,'original outer receipt must be in copied evidence')
        for item in members:
            if item.name in ('source-map.json','export-summary.json'):continue
            ref=by_copied[item.name];require(item.size==ref['size'],'mapped GPU payload size differs')
            h=hashlib.sha256();count=0
            with package.extractfile(item) as source:
                for block in iter(lambda:source.read(4*1024**2),b''):
                    require(time.monotonic()<deadline,'mapped GPU payload audit deadline reached');h.update(block);count+=len(block)
            require(count==ref['size'] and h.hexdigest()==ref['sha256'],'mapped GPU payload SHA differs')
        summary_member=next(m for m in members if m.name=='export-summary.json');require(summary_member.size<=4*1024**2,'bounded export summary required')
        summary=transport.parse(package.extractfile(summary_member).read(summary_member.size+1))
        require(summary.get('status')=='payload_copied_and_rehashed' and summary.get('source_map_sha256')==map_sha,'actual completed exporter summary binding differs')
    require(archive.stat().st_size==size and transport.sha(archive,deadline)==digest,'actual gzip changed during mapped-file audit')
    return {'regular_members':len(members),'mapped_files':len(files),'mapped_source_files_rehashed':len(files),'large_objects':286,'npy_files':282,'raw_logits_files':4}


class LimitedReader:
    def __init__(self,source,size,deadline):self.source,self.remaining,self.deadline=source,size,deadline;self.digest=hashlib.sha256()
    def read(self,size=-1):
        require(time.monotonic()<self.deadline,'split CPU deadline reached');size=self.remaining if size<0 else min(size,self.remaining)
        data=self.source.read(size);require(len(data)==size,'actual gzip truncated during split');self.remaining-=len(data);self.digest.update(data);return data


def split(archive,size,digest,map_sha,logical,output):
    started=time.monotonic();deadline=started+900;verify_tools();archive=Path(archive);output=Path(output)
    require(output.parent.is_dir() and not output.exists() and not output.is_symlink(),'exclusive new local transport directory required')
    require(shutil.disk_usage(output.parent).free>=transport.MIN_FREE,'observed local storage below5GiB')
    audit=verify_full_archive(archive,size,digest,map_sha,logical,deadline)
    planned=[];offset=0
    while offset<size:
        index=len(planned);count=min(transport.CHUNK_DATA,size-offset)
        planned.append({'index':index,'offset':offset,'data_size_bytes':count,'member_name':'chunk-%04d.bin'%index,
            'wrapper_basename':archive.name[:-7]+'-transport-%04d.tar'%index,'wrapper_size_bytes':transport.tar_size(count)});offset+=count
    budget=transport.accounting(size,logical,planned)
    require(1<=len(planned)<=7 and all(p['wrapper_size_bytes']<=transport.WRAPPER_CAP for p in planned) and
        budget['wrapper_wire_bytes']<=transport.ENCODED_CAP and budget['staged_wrappers_plus_reconstructed_plus_expanded_bytes']+transport.METADATA_RESERVE<=transport.DISK_CAP,
        'planned wrapper wire/new storage exceeds unchanged stage limits')
    output.mkdir(mode=0o700);parts=[]
    with archive.open('rb') as source:
        for plan in planned:
            wrapper=output/plan['wrapper_basename'];reader=LimitedReader(source,plan['data_size_bytes'],deadline)
            with wrapper.open('xb') as destination,tarfile.open(fileobj=destination,mode='w:',format=tarfile.USTAR_FORMAT) as package:
                info=tarfile.TarInfo(plan['member_name']);info.size=plan['data_size_bytes'];info.mode=0o600;info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
                package.addfile(info,reader)
            require(reader.remaining==0 and wrapper.stat().st_size==plan['wrapper_size_bytes'],'exact wrapper coverage/size differs')
            parts.append({**plan,'data_sha256':reader.digest.hexdigest(),'wrapper_sha256':transport.sha(wrapper,deadline)})
        require(source.tell()==size and source.read(1)==b'','full original gzip chunk coverage differs')
    require(archive.stat().st_size==size and transport.sha(archive,deadline)==digest,'actual gzip changed during split')
    document={'schema_version':1,'kind':'i04-gpu-archive-tar-chunks','stage_spec_sha256':transport.STAGE_SHA,'cpu_prerequisite_sha256':transport.CPU_SHA,
        'archive':{'basename':archive.name,'size_bytes':size,'sha256':digest},'source_map_sha256':map_sha,'logical_payload_bytes':logical,
        'chunk_data_limit_bytes':transport.CHUNK_DATA,'wrapper_wire_limit_bytes':transport.WRAPPER_CAP,'parts':parts,'transport_accounting':budget,
        'source_archive_audit':audit,'splitter_sha256':transport.sha(__file__),'assembler_sha256':ASSEMBLER_SHA,
        'original_gzip_bytes_preserved':True,'numeric_admission_performed':False,'native_executions_started':0,'acceptance':None}
    transport.validate(document);manifest=output/'i04-gpu-transport-manifest-v1.json';transport.put(manifest,document)
    receipt={'status':'i04_gpu_transport_wrappers_created','manifest':str(manifest.resolve()),'manifest_sha256':transport.sha(manifest),'archive_sha256':digest,
        'parts':parts,'source_archive_audit':audit,'transport_accounting':budget,'elapsed_seconds':time.monotonic()-started,'native_executions_started':0,
        'numeric_admission_performed':False,'acceptance':None};transport.put(output/'split-receipt.json',receipt);return receipt


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--archive',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--archive-bytes',type=int,required=True);parser.add_argument('--archive-sha256',required=True);parser.add_argument('--source-map-sha256',required=True)
    parser.add_argument('--logical-bytes',type=int,required=True);args=parser.parse_args()
    def expire(*_):raise TimeoutError('I04 local split900s deadline')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,900)
    try:print(transport.json.dumps(split(args.archive,args.archive_bytes,args.archive_sha256,args.source_map_sha256,args.logical_bytes,args.output),indent=2))
    finally:signal.setitimer(signal.ITIMER_REAL,0)

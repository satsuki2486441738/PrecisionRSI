"""Freeze two actual I03 endpoint maps and execute bounded independent CPU math."""
import argparse
from collections import Counter
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path,PurePosixPath
import signal
import subprocess
import sys
import time
import traceback

CASE='projects/gemma4-pilot/cases/text-native'
MAIN=CASE+'/adapters/admit_i03_partition_repeat_v1.py'
MAIN_SHA='2468a5f2a1aafe9f9437edae2bd90b3bdca15f9c1abcc6fa3b927ddb8167691c'
HELPER=CASE+'/adapters/i03_artifact_admission_v1.py'
HELPER_SHA='b734babc65be6ec361acbc10905b6c3e02e8c5c57650efb11e3a195134a1b6eb'
STAGE_SHA='6e53e3cdf3e7fad8f56b43cb99a42bdb999ac074a5a40a3c1e7df72eeb504005'
EXPECTED_SHA='5c8cdcc3c5b88732ccd589d95fa5ce86bd9eac71f83620e3bc48bcfc3b3b9a25'
PROOF_SHA='2d26531b83af3a3f0acf63c9b8472ce547a5bd288de6f92cd390a38a6011d840'
TASK='gemma4-i03-partition-repeat-v1'


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def load(path):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_text(),object_pairs_hook=pairs,parse_constant=reject)


def put(path,doc):
    with Path(path).open('x',encoding='utf-8') as stream:json.dump(doc,stream,indent=2,allow_nan=False);stream.write('\n')


def verify_tools(tools,manifest_sha):
    manifest=tools/'tool-bundle-manifest.json';require(sha(manifest)==manifest_sha,'external tool manifest SHA differs')
    doc=load(manifest);require(doc['kind']=='i03-offline-tool-bundle' and doc['native_executions_started']==0 and doc['acceptance'] is None,'wrong tool bundle')
    require(doc['files'][MAIN]['sha256']==MAIN_SHA and doc['files'][HELPER]['sha256']==HELPER_SHA,'frozen independent admission source changed')
    for name,ref in doc['files'].items():
        require(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and '\\' not in name,'unsafe tool member')
        path=(tools/name).resolve(strict=True);require(path.is_relative_to(tools) and path.is_file() and path.stat().st_size==ref['size_bytes'] and
            sha(path)==ref['sha256'],'tool source changed: '+name)
    require(sha(__file__)==doc['files'][CASE+'/transfer/run_i03_actual_compare_v1.py']['sha256'],'controller not from frozen bundle')


def endpoint(root,path,digest,category,retained_root=None):
    path=Path(path).resolve(strict=True);require(path.is_relative_to(root) and sha(path)==digest,'actual endpoint source-map SHA/path differs')
    mapping=load(path);request=mapping['request'];original=request['outer_receipt']
    require(request['task']=='I03' and request['backend']==category and PurePosixPath(original).is_absolute() and '\\' not in original and '..' not in PurePosixPath(original).parts,
        'actual endpoint I03/backend/original receipt differs')
    ref=mapping['files'][original];relative=PurePosixPath(ref['path'])
    require(not relative.is_absolute() and '..' not in relative.parts and '\\' not in ref['path'],'copied outer receipt escapes map')
    actual=(path.parent/str(relative)).resolve(strict=True)
    require(actual.is_relative_to(path.parent) and actual.is_file() and actual.stat().st_size==ref['size'] and sha(actual)==ref['sha256'],'mapped original outer receipt differs')
    outer=load(actual);require(outer['task']=='I03' and outer['backend']==category and outer['status']=='completed' and type(outer['returncode']) is int and
        outer['returncode']==0 and outer['timed_out'] is False and outer['native_forward_calls_total']==70 and outer['model_loads']==1 and
        outer['stage_spec_source_sha256']==STAGE_SHA and outer['expected_inventory_source_sha256']==EXPECTED_SHA and outer['i01_prerequisite_source_sha256']==PROOF_SHA,
        'actual completed five-mode source identity differs')
    result={'source_map':{'path':str(path),'sha256':digest},'receipt':{'source_path':original,'sha256':ref['sha256']}}
    if category=='NPU':
        retained=Path(retained_root).resolve(strict=True);require(retained==root/'i03-partition-repeat-20261106','explicit new NPU retained root differs')
        require(Path(outer['output_dir']).is_relative_to(retained),'original NPU output escapes new source task');result['retained_root']=str(retained)
    return result


def run(root,tools,manifest_sha,gpu_map,gpu_sha,npu_map,npu_sha):
    require(os.name=='posix' and not Path(root).is_symlink(),'POSIX original task root required')
    root=Path(root).resolve(strict=True);tools=Path(tools).resolve(strict=True);require(tools.is_relative_to(root/'tools'),'new tool import must be below R/tools')
    verify_tools(tools,manifest_sha);folder=root/'runs'/('compare-i03-invocation-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));folder.mkdir(mode=0o700)
    state={'schema_version':1,'task':'I03','status':'running','started_utc':datetime.now(timezone.utc).isoformat(),'run':str(folder),
        'tools_root':str(tools),'tool_manifest_sha256':manifest_sha,'whole_cpu_seconds':900,'child_work_seconds':870,'analysis_seconds':850,
        'native_executions_started':0,'acceptance':None};put(folder/'controller-start.json',state)
    started=time.monotonic();process=None;code=2
    def expire(*_):raise TimeoutError('I03 offline controller whole900s deadline reached')
    previous=signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,900)
    try:
        spec={'schema_version':1,'task':TASK,'stage_spec_sha256':STAGE_SHA,'expected_inventory_sha256':EXPECTED_SHA,'i01_prerequisite_sha256':PROOF_SHA,
            'endpoints':{'GPU':endpoint(root,gpu_map,gpu_sha,'GPU'),'NPU':endpoint(root,npu_map,npu_sha,'NPU',root/'i03-partition-repeat-20261106')},
            'thresholds':None,'acceptance':None}
        spec_path=folder/'comparison-spec.json';put(spec_path,spec);state['comparison_spec']={'path':str(spec_path),'sha256':sha(spec_path)}
        args=[str(root/'venv/bin/python'),'-B',str(tools/MAIN),'--spec',str(spec_path),'--spec-sha256',sha(spec_path),'--output-dir',str(folder/'bundle'),'--timeout-seconds','850']
        state['argv']=args;put(folder/'execution-start.json',state)
        print(json.dumps({'status':'running','controller':str(folder/'controller-receipt.json'),'native_executions_started':0}),flush=True)
        with (folder/'stdout.json').open('xb') as out,(folder/'stderr.txt').open('xb') as err:
            process=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
            try:code=process.wait(timeout=max(.01,870-(time.monotonic()-started)))
            except subprocess.TimeoutExpired:
                state['timed_out']=True;os.killpg(process.pid,signal.SIGTERM)
                try:code=process.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=5)
        require(code==0 and not state.get('timed_out',False),'independent I03 numeric child did not complete0')
        report_path=folder/'bundle/i03-comparison-report.json';report=load(report_path)
        require(report['status']=='i03_raw_bf16_partition_repeat_and_final_kv_checked' and report['comparison_spec_sha256']==sha(spec_path) and
            report['stage_spec_sha256']==STAGE_SHA and report['thresholds'] is None and report['acceptance'] is None and report['full_core_complete'] is False,
            'actual I03 report identity differs')
        require(report['scope']['independent_inputs']==1 and report['scope']['target_distribution_pairs']==23 and report['scope']['native_final_kv_pairs']==4 and
            len(report['target_distribution_pairs'])==23 and len(report['native_final_kv_pairs'])==4 and
            Counter(pair['kind'] for pair in report['target_distribution_pairs'])=={'within_process_full_repeat':6,'within_process_partition':6,'cross_backend_full':9,'cross_backend_cached':2},
            'actual23score/4KV coverage differs')
        verify_tools(tools,manifest_sha);state.update(status='completed',returncode=0,report={'path':str(report_path),'sha256':sha(report_path)},scope=report['scope'])
    except BaseException as exc:state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),partial_output_preserved=True,automatic_retry=False)
    finally:
        if process is not None and process.poll() is None:
            try:os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:state['cleanup_incomplete']=True
        signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)
        for key,name in [('stdout','stdout.json'),('stderr','stderr.txt')]:
            p=folder/name
            if p.is_file():state[key]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
        state.update(child_returncode=code,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started)
        put(folder/'controller-receipt.json',state)
    print(json.dumps({'status':state['status'],'receipt':str(folder/'controller-receipt.json'),'report':state.get('report'),'error':state.get('error')},indent=2),flush=True)
    return state['returncode']


def self_test():
    """Synthetic endpoint/source-scope rejections; no capture or numeric replay."""
    import tempfile
    with tempfile.TemporaryDirectory() as temporary:
        root=Path(temporary);mapping=root/'source-map.json'
        put(mapping,{'request':{'task':'I01','backend':'GPU','outer_receipt':'/synthetic/capture.json'},'files':{}})
        for digest in ('0'*64,sha(mapping)):
            try:endpoint(root,mapping,digest,'GPU')
            except ValueError:pass
            else:raise AssertionError('wrong map pin/task accepted')
        outer=root/'outer.json';put(outer,{'task':'I03','backend':'GPU','status':'completed','returncode':0,'timed_out':False,
            'native_forward_calls_total':69,'model_loads':1,'stage_spec_source_sha256':STAGE_SHA,'expected_inventory_source_sha256':EXPECTED_SHA,
            'i01_prerequisite_source_sha256':PROOF_SHA})
        mapping.unlink();put(mapping,{'request':{'task':'I03','backend':'GPU','outer_receipt':'/synthetic/capture.json'},
            'files':{'/synthetic/capture.json':{'path':outer.name,'sha256':sha(outer),'size':outer.stat().st_size}}})
        try:endpoint(root,mapping,sha(mapping),'GPU')
        except ValueError as exc:require('five-mode source identity' in str(exc),'unexpected synthetic failure')
        else:raise AssertionError('missing70th call accepted')
    print('synthetic_I03_endpoint_pin_scope_regressions_passed; native_executions_started=0')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--self-test',action='store_true')
    for name in ('root','tools-root','gpu-source-map','npu-source-map'):parser.add_argument('--'+name,type=Path)
    for name in ('tool-manifest-sha256','gpu-map-sha256','npu-map-sha256'):parser.add_argument('--'+name)
    args=parser.parse_args()
    if args.self_test:self_test();return 0
    require(all(getattr(args,name) is not None for name in ('root','tools_root','gpu_source_map','npu_source_map','tool_manifest_sha256','gpu_map_sha256','npu_map_sha256')),
        'all independently supplied actual endpoint/tool paths and pins required')
    return run(args.root,args.tools_root,args.tool_manifest_sha256,args.gpu_source_map,args.gpu_map_sha256,args.npu_source_map,args.npu_map_sha256)


if __name__=='__main__':raise SystemExit(main())

"""Private I03 five-mode collection on one unchanged loaded BF16/eager model.

No Torch import or native work occurs on import. Backend entries provide a
verified model, Torch and process-local seed/policy callbacks. A successful I01
numeric report, original source maps and analysis bytes are mandatory inputs.
New launchers own exclusive claims, allocation/conflict checks and whole budgets.
"""
import argparse
from contextlib import contextmanager
import gc
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import random
import re
import shutil
import signal
import struct
import sys
import time

import i01_common_v1 as prior
import i03_prerequisite_v1 as proof_helper
import numpy as np

HERE, REPO = prior.HERE, prior.REPO
require, sha, read, put, file_ref, check_refs = prior.require, prior.sha, prior.read, prior.put, prior.file_ref, prior.check_refs
derive_logprobs, Array = prior.derive_logprobs, prior.Array
INPUT_SHA256, REVISION, NORMALIZATION = prior.INPUT_SHA256, prior.REVISION, prior.NORMALIZATION
VOCABULARY = 262144
STAGE_ID = 'gemma4-gpu-npu-i03-partition-repeat-v1-20261106'
STAGE_SHA256 = '6e53e3cdf3e7fad8f56b43cb99a42bdb999ac074a5a40a3c1e7df72eeb504005'
TASK = 'gemma4-i03-partition-repeat-v1'
PRIOR_STAGE_SHA256 = prior.STAGE_SHA256
PRIOR_COMMON_SHA256 = 'fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c'
PREREQUISITE_SOURCE_SHA256 = 'e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36'
I01_ANALYSIS_SHA256 = 'f7fe91cdcebeec910efed4579ecf379fd665cf305223a3fa77858004db81858a'
MODES = ['full-r1', 'full-r2', 'full-r3', 'token', 'chunk63-65']
CALL_COUNTS = [1, 1, 1, 33, 34]
NUM_LAYERS, SLIDING_LAYERS, FULL_LAYERS = 48, 40, 8
SLIDING_HEADS, SLIDING_DIM, FULL_HEADS, FULL_DIM = 8, 256, 1, 512
KV_DATA_BYTES = 55050240
CAPTURE_CAP = 1342177280
HEX = re.compile(r'^[a-f0-9]{64}$')


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def coordinates(document):
    require(isinstance(document.get('sample'), str) and document['sample'].strip(), 'sample required')
    prompt, continuation = document.get('prompt'), document.get('continuation')
    require(isinstance(prompt, list) and len(prompt) == 128 and isinstance(continuation, list) and len(continuation) == 32,
            'exact original 128+32 token input required')
    sequence = prompt + continuation
    require(all(type(token) is int and 0 <= token < VOCABULARY for token in sequence), 'invalid token ID')
    positions = sorted(set(i * 127 // 15 for i in range(16)) | set(range(127, 159)))
    return {'sample': document['sample'], 'sequence': sequence, 'positions': positions,
        'all_targets': [{'sample': document['sample'], 'position': p, 'token': sequence[p]} for p in range(1, 160)],
        'distribution_positions': [{'sample': document['sample'], 'position': p, 'history': sequence[:p+1]} for p in positions]}


def mode_plan(mode, inventory):
    require(mode in MODES, 'unknown I03 mode')
    spans = [(0, 160)] if mode.startswith('full-') else ([(0, 128)] if mode == 'token' else [(0, 63), (63, 128)]) + [(p, p+1) for p in range(128, 160)]
    calls = []
    for i, (start, end) in enumerate(spans):
        calls.append({'call_index': i, 'stage': 'full' if mode.startswith('full-') else ('decode' if start >= 128 else 'prefill'),
            'start': start, 'end': end, 'prefix_length': start, 'attention_mask_length': end,
            'position_ids': list(range(start, end)), 'input_ids': inventory['sequence'][start:end]})
    return {'id': mode, 'use_cache': not mode.startswith('full-'), 'native_forward_calls': len(calls),
            'cached_decode_calls': 0 if mode.startswith('full-') else 32, 'calls': calls}


def expected_core(inventory):
    return {'schema_version': 1, 'task': TASK, 'stage_id': STAGE_ID, 'stage_spec_sha256': STAGE_SHA256,
        'input_sha256': INPUT_SHA256, 'sequence_length': 160, 'vocabulary_size': VOCABULARY,
        'all_targets': inventory['all_targets'], 'distribution_positions': inventory['distribution_positions'],
        'modes': [mode_plan(mode, inventory) for mode in MODES]}


def safe_relative(name):
    require(isinstance(name, str) and name and '\\' not in name, 'POSIX relative path required')
    path = PurePosixPath(name)
    require(not path.is_absolute() and str(path) == name and all(p not in ('', '.', '..') for p in name.split('/')), 'unsafe relative path')
    return path


def prerequisite(path, digest):
    checked = proof_helper.prerequisite(path, digest)
    return checked['document'], checked['refs']


def arguments(backend):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('model', 'input', 'allocation-receipt', 'stage-spec', 'expected-inventory', 'i01-prerequisite', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    for name in ('stage-spec-sha256', 'expected-inventory-sha256', 'i01-prerequisite-sha256'):
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--device', required=True, choices=['cuda:0'] if backend == 'gpu' else ['npu:0'])
    for name in (('numerics-policy',) if backend == 'gpu' else ('driver-source', 'native-mapping', 'native-source')):
        parser.add_argument('--' + name, type=Path, required=True)
    return parser.parse_args()


def prepare(args, backend, entry):
    require(Path(proof_helper.__file__).resolve() == HERE / 'i03_prerequisite_v1.py' and sha(proof_helper.__file__) == PREREQUISITE_SOURCE_SHA256, 'pure prerequisite helper source differs')
    require(args.stage_spec_sha256 == STAGE_SHA256 and sha(args.stage_spec) == STAGE_SHA256, 'I03 prepared finite stage SHA differs')
    stage = read(args.stage_spec)
    require(stage.get('stage_id') == STAGE_ID and stage.get('status') == 'prepared_not_executed' and
            stage.get('modes') == MODES and stage.get('expected_native_calls') == CALL_COUNTS and
            stage.get('total_forward_calls_per_backend') == 70 and stage.get('acceptance') is None, 'I03 finite stage semantics differ')
    require(sha(args.input) == INPUT_SHA256, 'original input bytes required')
    inventory = coordinates(read(args.input))
    require(HEX.fullmatch(args.expected_inventory_sha256) and sha(args.expected_inventory) == args.expected_inventory_sha256, 'new independent I03 expected inventory SHA differs')
    expected = read(args.expected_inventory)
    require(all(key in expected and canonical(expected[key]) == canonical(value) for key, value in expected_core(inventory).items()), 'I03 independently derived expected coordinates/events differ')
    proof, proof_refs = prerequisite(args.i01_prerequisite, args.i01_prerequisite_sha256)
    require(args.output.parent.is_dir() and not args.output.exists(), 'exclusive new output under existing run directory required')
    require(shutil.disk_usage(args.output.parent).free >= stage['limits']['minimum_free_source_storage_bytes'], 'source free storage is below new 5GiB minimum')
    prior.check_import_paths()
    require(Path(prior.__file__).resolve() == HERE / 'i01_common_v1.py' and sha(prior.__file__) == PRIOR_COMMON_SHA256, 'reviewed loader helper differs')
    refs = {}
    for name, digest in prior.PINNED.items():
        refs[name] = file_ref(REPO / name); require(refs[name]['sha256'] == digest, 'reviewed original dependency changed')
    for name in ('i01_common_v1.py', 'i03_prerequisite_v1.py', 'i03_common_v1.py', Path(entry).name): refs['i03/' + name] = file_ref(HERE / name)
    for key in ('input', 'allocation_receipt', 'stage_spec', 'expected_inventory', 'i01_prerequisite',
                *(['numerics_policy'] if backend == 'gpu' else ['driver_source', 'native_mapping', 'native_source'])):
        refs['input/' + key] = file_ref(getattr(args, key))
    refs.update({'i01-proof/' + key: ref for key, ref in proof_refs.items()})
    return stage, inventory, refs, proof


def initialize_output(args, proof):
    args.output.mkdir()
    for original, target in ((args.input, 'input.json'), (args.stage_spec, 'stage-spec.json'), (args.expected_inventory, 'expected-inventory.json')):
        with (args.output / target).open('xb') as stream: stream.write(original.read_bytes())
    directory = args.output / 'prerequisite'; directory.mkdir()
    with (directory / 'prerequisite.json').open('xb') as stream: stream.write(args.i01_prerequisite.read_bytes())
    refs = [proof[name] for name in ('report', 'comparison_spec', 'controller', 'analysis_source')] + list(proof['source_maps'].values())
    require(len({ref['path'] for ref in refs}) == 6, 'distinct prerequisite copy paths required')
    for ref in refs:
        target = directory.joinpath(*safe_relative(ref['path']).parts); target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write((args.i01_prerequisite.parent / ref['path']).read_bytes())
        require(sha(target) == ref['sha256'], 'prerequisite copy changed')


@contextmanager
def bounded_native(stage, backend):
    require(hasattr(signal, 'SIGALRM'), 'native entry requires POSIX bounded execution')
    seconds = stage['limits'][backend + '_capture_timeout_seconds']
    require(seconds == (1500 if backend == 'gpu' else 1800), 'I03 capture budget differs')
    def expire(signum, frame): raise TimeoutError('I03 native entry timeout')
    previous = signal.signal(signal.SIGALRM, expire); signal.setitimer(signal.ITIMER_REAL, seconds)
    try: yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0); signal.signal(signal.SIGALRM, previous)


def tensor_metadata(tensor):
    record = {'shape': list(tensor.shape), 'dtype': str(tensor.dtype), 'device': str(tensor.device), 'numel': int(tensor.numel())}
    for name, operation in (('stride', lambda: list(tensor.stride())), ('version', lambda: int(tensor._version)),
                            ('storage', lambda: {'data_ptr': int(tensor.untyped_storage().data_ptr()),
                                'nbytes': int(tensor.untyped_storage().nbytes()), 'offset': int(tensor.storage_offset())})):
        try: record[name] = operation()
        except Exception as exc: record[name] = {'unavailable': True, 'error_type': type(exc).__name__, 'error': str(exc)}
    return record


def model_state(model, torch):
    parameters = [{'name': name, **tensor_metadata(value)} for name, value in model.named_parameters(remove_duplicate=False)]
    buffers, copied = [], 0
    for name, value in model.named_buffers(remove_duplicate=False):
        ref = {'name': name, **tensor_metadata(value)}
        size = int(value.numel()) * int(value.element_size())
        if copied + size <= 8 * 1024**2:
            try:
                raw = value.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes()
                ref['content_sha256'] = hashlib.sha256(raw).hexdigest(); copied += len(raw)
            except Exception as exc: ref['content_probe_gap'] = {'error_type': type(exc).__name__, 'error': str(exc)}
        else: ref['content_probe_gap'] = {'reason': '8MiB CPU buffer fingerprint budget'}
        buffers.append(ref)
    return {'model_object_id': id(model), 'class': type(model).__module__ + '.' + type(model).__qualname__,
        'config': model.config.to_dict(), 'module_training_flags': [[name, bool(module.training)] for name, module in model.named_modules()],
        'parameters': parameters, 'buffers': buffers,
        'scope': 'Observed object/storage/config/version and bounded buffer fingerprints; no claim of rehashed loaded parameter bytes or allocator/kernel reset'}


def numpy_rng_observation(state=None):
    algorithm, words, position, has_gauss, cached_gaussian = np.random.get_state() if state is None else state
    require(isinstance(algorithm,str) and isinstance(words,np.ndarray) and words.ndim == 1 and
            words.dtype.kind == 'u' and words.dtype.itemsize == 4 and words.size > 0 and
            type(position) is int and 0 <= position <= words.size and type(has_gauss) is int and has_gauss in (0,1),
            'unsupported NumPy RandomState structure')
    header = {'version':1,'algorithm':algorithm,'word_count':int(words.size),'word_encoding':'uint32-little-endian',
        'position':position,'has_gauss':has_gauss,'cached_gaussian_binary64_le_hex':struct.pack('<d',float(cached_gaussian)).hex()}
    payload = canonical(header).encode('utf-8') + b'\0' + words.astype('<u4',copy=False).tobytes(order='C')
    return {'format':'canonical-JSON-header UTF8 + NUL + complete uint32LE state words',
            'header':header,'sha256':hashlib.sha256(payload).hexdigest()}


def rng_observation(torch, backend):
    result = {'python': {'format':'untruncated Python random.getstate tuple repr UTF8',
                         'sha256':hashlib.sha256(repr(random.getstate()).encode()).hexdigest()},
        'numpy': numpy_rng_observation()}
    operations = {'torch_cpu': torch.get_rng_state, 'device0': lambda: getattr(torch, 'cuda' if backend == 'gpu' else 'npu').get_rng_state(0)}
    for name, operation in operations.items():
        try: result[name] = {'format':'complete Torch generator state ByteTensor bytes',
                            'sha256': hashlib.sha256(operation().cpu().numpy().tobytes()).hexdigest()}
        except Exception as exc: result[name] = {'unavailable': True, 'error_type': type(exc).__name__, 'error': str(exc)}
    return result


def cache_observation(cache, prefix, layer_types):
    if cache is None:
        require(prefix == 0, 'cached prefix cannot be absent after input consumption')
        return {'present': False, 'sequence_length': 0, 'layers': []}
    require(cache.get_seq_length() == prefix and len(cache.layers) == NUM_LAYERS, 'native cache length/layer inventory differs')
    layers = []
    for index, layer in enumerate(cache.layers):
        heads, dim = (SLIDING_HEADS, SLIDING_DIM) if layer_types[index] == 'sliding_attention' else (FULL_HEADS, FULL_DIM)
        require(layer.get_seq_length() == prefix, 'cache layer cumulative sequence differs')
        record = {'index': index, 'class': type(layer).__module__ + '.' + type(layer).__qualname__,
            'configured_attention': layer_types[index], 'sequence_length': int(layer.get_seq_length()),
            'is_sliding': getattr(layer, 'is_sliding', None), 'sliding_window': getattr(layer, 'sliding_window', None),
            'is_initialized': bool(layer.is_initialized)}
        for name in ('keys', 'values'):
            tensor = getattr(layer, name)
            require(list(tensor.shape) == [1, heads, prefix, dim] and str(tensor.dtype) == 'torch.bfloat16', 'native cache K/V shape/dtype differs')
            record[name] = tensor_metadata(tensor)
        layers.append(record)
    require(getattr(cache, 'offloading', False) is False, 'offloaded cache is outside this native comparison')
    return {'present': True, 'class': type(cache).__module__ + '.' + type(cache).__qualname__,
            'sequence_length': int(cache.get_seq_length()), 'offloading': getattr(cache, 'offloading', None), 'layers': layers}


def check_storage(output):
    size = 0
    for path in Path(output).rglob('*'):
        require(not path.is_symlink(), 'capture output contains link')
        if path.is_file(): size += path.stat().st_size
    require(size <= CAPTURE_CAP, 'I03 capture product cap exceeded')
    return size


def save_tensors(tensors, path, mode, boundary):
    from safetensors.torch import save_file
    require(not Path(path).exists(), 'native safetensors output already exists')
    save_file(tensors, str(path), metadata={'task': TASK, 'mode': mode, 'boundary': boundary})


def safetensors_header(path, descriptors):
    with Path(path).open('rb') as stream:
        raw = stream.read(8); require(len(raw) == 8, 'truncated safetensors length')
        length = struct.unpack('<Q', raw)[0]; require(0 < length <= 131072, 'unbounded safetensors header')
        header = prior.parse_json(stream.read(length))
    require(set(header) - {'__metadata__'} == set(descriptors), 'native tensor key inventory differs')
    offsets = []
    for name, shape in descriptors.items():
        ref = header[name]; require(ref['dtype'] == 'BF16' and ref['shape'] == shape and set(ref) == {'dtype', 'shape', 'data_offsets'}, 'native tensor shape/dtype differs')
        start, end = ref['data_offsets']; require(type(start) is int and type(end) is int and end-start == math.prod(shape)*2, 'native tensor offsets differ')
        offsets.append((start, end))
    position = 0
    for start, end in sorted(offsets): require(start == position, 'native tensor payload gap/overlap'); position = end
    require(Path(path).stat().st_size == 8 + length + position, 'native tensor payload byte count differs')
    return header


def derive_mode_rows(native_cpu, inventory, directory, mode):
    raw_path = directory / 'raw-native-logits.safetensors'
    save_tensors({'logits': native_cpu}, raw_path, mode, 'native output before score processing')
    safetensors_header(raw_path, {'logits': [1, 160, VOCABULARY]})
    raw_ref = file_ref(raw_path)
    base = {'schema_version': 1, 'task': TASK, 'mode': mode, 'stage_spec_sha256': STAGE_SHA256,
        'input_sha256': INPUT_SHA256, 'raw_logits_sha256': raw_ref['sha256'],
        'native_logits_dtype': 'torch.bfloat16', 'logprob_dtype': 'float64', 'normalization': NORMALIZATION}
    targets, distributions = [], []
    sequence = inventory['sequence']
    for p in range(160):
        values = native_cpu[0, p, :].double().numpy()
        require(np.isfinite(values).all(), 'native raw row is nonfinite')
        if p == 159: continue
        row = derive_logprobs(values, dtype='float64'); target = sequence[p+1]; value = float(row[target])
        require(math.isfinite(value) and value <= 0, 'invalid raw-derived target score')
        targets.append({'sample': inventory['sample'], 'position': p+1, 'prediction_position': p,
            'token': target, 'logprob': value})
        if p in inventory['positions']:
            prefix = 'dist-p%03d' % p
            descriptor = {'path': prefix + '.npy', 'row': 0}
            with (directory / descriptor['path']).open('xb') as stream: np.save(stream, row.reshape(1, VOCABULARY), allow_pickle=False)
            roles = (['prompt_sample'] if p in [i*127//15 for i in range(16)] else []) + (['continuation'] if p >= 127 else [])
            record = dict(base, sample=inventory['sample'], position=p, history=sequence[:p+1], roles=roles,
                target_position=p+1, token=target, logprob=value, scores=descriptor)
            put(directory / (prefix + '.json'), record)
            distributions.append({**{key: record[key] for key in ('sample', 'position', 'history', 'roles', 'scores')}, 'record': prefix + '.json'})
        check_storage(directory.parent.parent)
    put(directory / 'target-scores.json', dict(base, kind='i03-native-target-scores', scores=targets))
    put(directory / 'distributions.json', dict(base, kind='i03-native-distribution-rows', positions=distributions))
    return raw_ref


def final_cache(cache, directory, mode, layer_types):
    observation = cache_observation(cache, 160, layer_types)
    tensors, inventory = {}, []
    for index, layer in enumerate(cache.layers):
        for attribute, suffix in (('keys', 'key'), ('values', 'value')):
            key = 'layer-%03d.%s' % (index, suffix)
            tensor = getattr(layer, attribute)
            # Separate CPU buffers retain every native BF16 bit, including where
            # original native storages alias. Original aliases stay in metadata.
            tensors[key] = tensor.detach().cpu().contiguous().clone()
            inventory.append({'key': key, 'layer': index, 'kind': suffix, 'shape': list(tensor.shape),
                'dtype': 'BF16', 'data_bytes': int(tensor.numel()) * 2,
                'array': {'path': 'final-native-kv.safetensors', 'key': key}})
    path = directory / 'final-native-kv.safetensors'
    require(len(inventory) == NUM_LAYERS*2 and sum(item['data_bytes'] for item in inventory) == KV_DATA_BYTES, 'complete native final K/V byte inventory differs')
    save_tensors(tensors, path, mode, 'final native K/V after all160 input tokens')
    safetensors_header(path, {key: list(value.shape) for key, value in tensors.items()})
    document = {'schema_version': 1, 'kind': 'i03-final-native-cache', 'task': TASK, 'mode': mode,
        'input_sha256': INPUT_SHA256, 'stage_spec_sha256': STAGE_SHA256, 'native_dtype': 'torch.bfloat16',
        'cache': observation, 'tensors': inventory, 'data_bytes': KV_DATA_BYTES, 'safetensors': file_ref(path)}
    put(directory / 'final-cache.json', document)
    return document


def capture_mode(model, torch, device, inventory, directory, mode, retired_caches=()):
    import weakref
    plan = mode_plan(mode, inventory)
    directory.mkdir()
    config = model.config.get_text_config()
    layer_types = list(config.layer_types)
    require(len(layer_types) == NUM_LAYERS and layer_types.count('sliding_attention') == SLIDING_LAYERS and layer_types.count('full_attention') == FULL_LAYERS and
        config.num_key_value_heads == SLIDING_HEADS and config.num_global_key_value_heads == FULL_HEADS and config.head_dim == SLIDING_DIM and
        config.global_head_dim == FULL_DIM and config.num_kv_shared_layers == 0, 'configured model attention layout differs')
    cache, chunks, events = None, [], []
    with torch.inference_mode():
        for call in plan['calls']:
            before = cache_observation(cache, call['start'], layer_types) if plan['use_cache'] else {'present': False, 'sequence_length': 0, 'layers': []}
            incoming = cache
            result = model(input_ids=torch.tensor([call['input_ids']], dtype=torch.long, device=device),
                attention_mask=torch.ones((1, call['attention_mask_length']), dtype=torch.long, device=device),
                position_ids=torch.tensor([call['position_ids']], dtype=torch.long, device=device),
                past_key_values=cache, use_cache=plan['use_cache'], logits_to_keep=0, return_dict=True)
            logits = result.logits
            require(list(logits.shape) == [1, call['end']-call['start'], VOCABULARY] and str(logits.dtype) == 'torch.bfloat16', 'native segment logits shape/dtype differs')
            require(getattr(result, 'shared_kv_states', None) is None, 'unexpected shared K/V returned; no cross-call shared state permitted')
            cache = getattr(result, 'past_key_values', None)
            if plan['use_cache']:
                require(cache is not None and (incoming is None or cache is incoming), 'cached native call lost/replaced its input cache')
                if incoming is None:
                    require(all(reference() is not cache for reference in retired_caches), 'previous mode cache leaked into fresh cached mode')
                after = cache_observation(cache, call['end'], layer_types)
                require(all(t['device'] == device for layer in after['layers'] for t in (layer['keys'], layer['values'])), 'native K/V moved off selected device')
            else:
                require(cache is None, 'full cache-off call returned a cache')
                after = {'present': False, 'sequence_length': 0, 'layers': []}
            chunks.append(logits.detach().cpu().contiguous())
            events.append({**call, 'mode': mode, 'use_cache': plan['use_cache'], 'past_key_values_is_none': incoming is None,
                'logits_to_keep': 0, 'labels_supplied': False, 'shared_kv_states_supplied': False,
                'native_logits_shape': list(logits.shape), 'native_logits_dtype': str(logits.dtype),
                'cache_before': before, 'cache_after': after})
    native_cpu = torch.cat(chunks, dim=1).contiguous()
    require(list(native_cpu.shape) == [1, 160, VOCABULARY] and str(native_cpu.dtype) == 'torch.bfloat16', 'lossless native segment concatenation differs')
    raw = derive_mode_rows(native_cpu, inventory, directory, mode)
    kv = final_cache(cache, directory, mode, layer_types) if plan['use_cache'] else None
    put(directory / 'events.json', events)
    if kv is None: put(directory / 'final-cache.json', {'schema_version': 1, 'task': TASK, 'mode': mode, 'cache': None, 'reason': 'full mode returned no cache'})
    summary = {'schema_version': 1, 'task': TASK, 'mode': mode, 'native_forward_calls': len(events),
        'use_cache': plan['use_cache'], 'cached_decode_calls': plan['cached_decode_calls'],
        'native_logits_shape': [1,160,VOCABULARY], 'native_logits_dtype': 'torch.bfloat16',
        'targets': 159, 'sampled_distributions': 47, 'unscored_native_prediction_indices': [159],
        'raw_logits': raw, 'final_cache_sequence_length': 160 if kv else None,
        'final_kv_tensors': NUM_LAYERS*2 if kv else 0}
    put(directory / 'capture-summary.json', summary)
    return summary, weakref.ref(cache) if cache is not None else None


def capture_all(model, torch, device, inventory, output, backend, seed_callback, policy_callback, synchronize):
    output = Path(output)
    (output / 'modes').mkdir()
    baseline = model_state(model, torch)
    put(output / 'loaded-model-state.json', baseline)
    policy = policy_callback()
    summaries, retired, rng_anchor = [], [], None
    for mode in MODES:
        gc.collect(); synchronize()
        require(canonical(model_state(model, torch)) == canonical(baseline), 'persistent model state changed before mode')
        reset = seed_callback()
        require(canonical(policy_callback()) == canonical(policy), 'backend policy changed before mode')
        rng_before = rng_observation(torch, backend)
        if rng_anchor is None: rng_anchor = rng_before
        require(canonical(rng_before) == canonical(rng_anchor), 'seed/state reset did not restore observed RNG state')
        directory = output / 'modes' / mode
        summary, reference = capture_mode(model, torch, device, inventory, directory, mode, retired)
        synchronize()
        after = model_state(model, torch)
        put(directory / 'model-state-after.json', after)
        require(canonical(after) == canonical(baseline), 'persistent model state changed during mode')
        require(canonical(policy_callback()) == canonical(policy), 'backend policy changed during mode')
        put(directory / 'state-control.json', {'schema_version': 1, 'mode': mode, 'seed_reset': reset,
            'rng_before': rng_before, 'rng_after': rng_observation(torch, backend), 'math_policy': policy,
            'baseline_model_state_sha256': sha(output / 'loaded-model-state.json'),
            'model_state_after_sha256': sha(directory / 'model-state-after.json'),
            'scope': 'same loaded model; fresh cache; controlled observed seed/state; allocator/kernel warmup not reset'})
        summaries.append(summary)
        if reference is not None: retired.append(reference)
        check_storage(output)
    require([summary['native_forward_calls'] for summary in summaries] == CALL_COUNTS and sum(CALL_COUNTS) == 70, 'I03 five-mode call inventory differs')
    put(output / 'capture-summary.json', {'schema_version': 1, 'task': TASK, 'stage_spec_sha256': STAGE_SHA256,
        'modes': summaries, 'native_forward_calls_total': 70, 'model_loads': 1,
        'full_repeats_scope': 'same process and same loaded model; not three fresh processes', 'acceptance': None})
    return summaries


def finalize(args, backend, inventory, refs, runtime):
    prior.check_import_paths(); check_refs(refs)
    check_refs(runtime['implementation_sources'])
    runtime.update(task=TASK, stage_id=STAGE_ID, stage_spec_sha256=STAGE_SHA256, input_sha256=INPUT_SHA256,
        expected_inventory_sha256=args.expected_inventory_sha256, expected_inventory_external_path=str(args.expected_inventory.resolve()),
        i01_prerequisite_sha256=args.i01_prerequisite_sha256, i01_prerequisite_external_path=str(args.i01_prerequisite.resolve()),
        sources=refs, model_repository='google/gemma-4-12B', requested_revision=REVISION,
        native_logits_dtype='torch.bfloat16', logprob_dtype='float64', normalization=NORMALIZATION,
        model_loads=1, native_forward_calls_total=70, modes=MODES, thresholds=None, acceptance=None, full_core_complete=False,
        limitations=['one fixed input', 'three full repeats share one process/model; cached repeatability unmeasured',
            'allocator/kernel warmup not reset', 'partition/cache differences are not operator-defect attribution',
            'configured1024 sliding eviction untested at160tokens', 'snapshot/source receipts do not attest scheduler or loader-consumed bytes'])
    put(args.output / 'runtime.json', runtime)
    files = {p.relative_to(args.output).as_posix(): {'sha256': sha(p), 'size_bytes': p.stat().st_size}
             for p in sorted(args.output.rglob('*')) if p.is_file()}
    put(args.output / 'artifacts-manifest.json', {'schema_version': 1, 'kind': 'i03-capture-artifacts', 'task': TASK,
        'backend': backend, 'stage_spec_sha256': STAGE_SHA256, 'input_sha256': INPUT_SHA256,
        'expected_inventory_sha256': args.expected_inventory_sha256, 'i01_prerequisite_sha256': args.i01_prerequisite_sha256,
        'files': files, 'acceptance': None})
    validate_output(args.output, args.input, require_completed=False)
    check_refs(refs); check_refs(runtime['implementation_sources'])
    put(args.output / 'status.json', {'schema_version': 1, 'status': 'completed', 'rank': 0, 'task': TASK,
        'backend': backend, 'stage_spec_sha256': STAGE_SHA256, 'artifacts_manifest_sha256': sha(args.output / 'artifacts-manifest.json'),
        'modes': MODES, 'native_forward_calls_total': 70, 'model_loads': 1, 'acceptance': None, 'full_core_complete': False})
    return validate_output(args.output, args.input)


def validate_output(output, input_path, require_completed=True):
    """Offline closure/schema/coordinate checks; independent admission redoes math."""
    output = Path(output)
    require(sha(input_path) == INPUT_SHA256, 'validation input bytes differ')
    inventory = coordinates(read(input_path)); manifest = read(output / 'artifacts-manifest.json')
    require(manifest.get('kind') == 'i03-capture-artifacts' and manifest.get('task') == TASK and
        manifest.get('stage_spec_sha256') == STAGE_SHA256 and manifest.get('input_sha256') == INPUT_SHA256 and
        manifest.get('backend') in ('gpu','npu'), 'I03 manifest identity differs')
    files = manifest['files']
    actual = {p.relative_to(output).as_posix() for p in output.rglob('*') if p.is_file()}
    require(actual == set(files) | {'artifacts-manifest.json'} | ({'status.json'} if require_completed else set()), 'I03 artifact inventory is not exact')
    for name, ref in files.items():
        safe_relative(name); path = output / name
        require(not path.is_symlink() and ref == {'sha256': sha(path), 'size_bytes': path.stat().st_size}, 'I03 artifact byte identity differs: ' + name)
    require(sha(output/'input.json') == INPUT_SHA256 and sha(output/'stage-spec.json') == STAGE_SHA256,
            'retained input or finite stage bytes differ')
    expected = read(output / 'expected-inventory.json')
    require(sha(output / 'expected-inventory.json') == manifest['expected_inventory_sha256'] and
        all(key in expected and canonical(expected[key]) == canonical(value) for key,value in expected_core(inventory).items()), 'I03 output expected inventory differs')
    prerequisite(output / 'prerequisite/prerequisite.json', manifest['i01_prerequisite_sha256'])
    required = {'input.json','stage-spec.json','expected-inventory.json','prerequisite/prerequisite.json',
        'snapshot-verification.json','loaded-model-inventory.json','loaded-model-state.json','runtime.json',
        'policy-before-load.json','policy-after-load.json','policy-after-capture.json','capture-summary.json'}
    proof = read(output / 'prerequisite/prerequisite.json')
    proof_refs = [proof[key] for key in ('report','comparison_spec','controller','analysis_source')] + list(proof['source_maps'].values())
    required.update('prerequisite/' + ref['path'] for ref in proof_refs)
    if manifest['backend'] == 'npu': required.add('driver-version-provenance.json')
    call_total, rng_anchor = 0, None
    configured_types = read(output/'loaded-model-state.json')['config']['text_config']['layer_types']
    require(len(configured_types) == NUM_LAYERS and configured_types.count('sliding_attention') == SLIDING_LAYERS and
            configured_types.count('full_attention') == FULL_LAYERS, 'retained model attention layout differs')
    for mode in MODES:
        prefix = 'modes/' + mode + '/'; directory = output / 'modes' / mode; plan = mode_plan(mode, inventory)
        names = {'raw-native-logits.safetensors','target-scores.json','distributions.json','events.json','final-cache.json',
                 'capture-summary.json','model-state-after.json','state-control.json'}
        names.update('dist-p%03d%s' % (p,suffix) for p in inventory['positions'] for suffix in ('.json','.npy'))
        if plan['use_cache']: names.add('final-native-kv.safetensors')
        required.update(prefix + name for name in names)
        safetensors_header(directory / 'raw-native-logits.safetensors', {'logits':[1,160,VOCABULARY]})
        raw_sha = sha(directory / 'raw-native-logits.safetensors')
        scores_doc = read(directory / 'target-scores.json'); scores = scores_doc['scores']
        require(scores_doc.get('task') == TASK and scores_doc.get('mode') == mode and scores_doc.get('raw_logits_sha256') == raw_sha and len(scores) == 159, 'mode score source/count differs')
        for row, coordinate in zip(scores, inventory['all_targets']):
            require(all(row.get(k) == v for k,v in coordinate.items()) and row.get('prediction_position') == coordinate['position']-1 and
                type(row.get('logprob')) in (int,float) and math.isfinite(row['logprob']) and row['logprob'] <= 0, 'mode target coordinate/value differs')
        distributions = read(directory / 'distributions.json')
        require(distributions.get('task') == TASK and distributions.get('mode') == mode and distributions.get('raw_logits_sha256') == raw_sha and len(distributions['positions']) == 47, 'mode distribution source/count differs')
        for item, coordinate in zip(distributions['positions'], inventory['distribution_positions']):
            p = coordinate['position']; name = 'dist-p%03d' % p
            require(all(item.get(k) == v for k,v in coordinate.items()) and item.get('record') == name+'.json' and
                item.get('scores') == {'path':name+'.npy','row':0}, 'mode distribution coordinate/path differs')
            record = read(directory / item['record'])
            require(record.get('raw_logits_sha256') == raw_sha and record.get('token') == inventory['sequence'][p+1] and
                record.get('target_position') == p+1 and record.get('logprob') == scores[p]['logprob'], 'mode row provenance/target differs')
            array = Array(directory, {'path':name+'.npy'})
            require(array.shape == [1,VOCABULARY] and array.dtype == np.dtype('float64'), 'mode full FP64 array shape/dtype differs')
            values = np.load(directory/(name+'.npy'),mmap_mode='r',allow_pickle=False)
            try: require(np.isfinite(values).all() and values.max() <= 0 and float(values[0,inventory['sequence'][p+1]]) == scores[p]['logprob'], 'mode row values differ')
            finally: values._mmap.close()
        events = read(directory / 'events.json')
        require(len(events) == plan['native_forward_calls'], 'mode native call count differs')
        for event, call in zip(events, plan['calls']):
            require(all(event.get(k) == v for k,v in call.items()) and event.get('mode') == mode and
                event.get('use_cache') is plan['use_cache'] and event.get('logits_to_keep') == 0 and
                event.get('labels_supplied') is False and event.get('shared_kv_states_supplied') is False and
                event.get('past_key_values_is_none') is (call['call_index'] == 0) and
                event.get('native_logits_shape') == [1,call['end']-call['start'],VOCABULARY] and
                event.get('native_logits_dtype') == 'torch.bfloat16', 'mode causal event differs')
            if plan['use_cache']:
                require(event['cache_after']['sequence_length'] == call['end'] and len(event['cache_after']['layers']) == NUM_LAYERS and
                    event['cache_before']['sequence_length'] == call['start'], 'mode cache growth differs')
            else: require(event['cache_after']['present'] is False, 'full mode cache must be absent')
        call_total += len(events)
        cache = read(directory / 'final-cache.json')
        if plan['use_cache']:
            require(cache.get('mode') == mode and len(cache['tensors']) == NUM_LAYERS*2 and cache.get('data_bytes') == KV_DATA_BYTES and
                cache['cache']['sequence_length'] == 160 and len(cache['cache']['layers']) == NUM_LAYERS, 'mode final K/V inventory differs')
            descriptors = {}
            for index in range(NUM_LAYERS):
                # Configured layers alternate, so use the actual retained
                # configured attention type rather than an assumed grouping.
                configured = cache['cache']['layers'][index]['configured_attention']
                require(configured == configured_types[index] and cache['cache']['layers'][index]['index'] == index,
                        'final cache layer index/configuration differs')
                heads,dim = (SLIDING_HEADS,SLIDING_DIM) if configured == 'sliding_attention' else (FULL_HEADS,FULL_DIM)
                for suffix in ('key','value'):descriptors['layer-%03d.%s'%(index,suffix)] = [1,heads,160,dim]
            require(len({item['key'] for item in cache['tensors']}) == NUM_LAYERS*2 and
                {item['key']:item['shape'] for item in cache['tensors']} == descriptors and
                all(item['dtype'] == 'BF16' and item['array'] == {'path':'final-native-kv.safetensors','key':item['key']} and
                    item['data_bytes'] == math.prod(item['shape'])*2 for item in cache['tensors']), 'final native K/V tensor coordinates differ')
            safetensors_header(directory/'final-native-kv.safetensors',descriptors)
            require(cache['safetensors'] == file_ref(directory/'final-native-kv.safetensors'), 'mode final K/V source differs')
        else: require(cache.get('cache',object()) is None, 'full mode final cache must be absent')
        mode_summary = read(directory/'capture-summary.json')
        require(mode_summary.get('mode') == mode and mode_summary.get('native_forward_calls') == plan['native_forward_calls'] and
            mode_summary.get('cached_decode_calls') == plan['cached_decode_calls'] and mode_summary.get('targets') == 159 and
            mode_summary.get('sampled_distributions') == 47 and mode_summary.get('raw_logits') == file_ref(directory/'raw-native-logits.safetensors'),
            'mode native summary differs')
        require(canonical(read(directory/'model-state-after.json')) == canonical(read(output/'loaded-model-state.json')), 'persistent model state differs')
        control = read(directory/'state-control.json')
        require(control.get('mode') == mode and control.get('seed_reset',{}).get('seed') == 0 and
            control.get('baseline_model_state_sha256') == sha(output/'loaded-model-state.json') and
            control.get('model_state_after_sha256') == sha(directory/'model-state-after.json') and
            canonical(control['math_policy']) == canonical(read(output/'runtime.json')['math_policy']), 'mode observed state-control chain differs')
        if rng_anchor is None: rng_anchor = control['rng_before']
        require(canonical(control['rng_before']) == canonical(rng_anchor), 'retained before-mode RNG reset states differ')
    require(set(files) == required and call_total == 70, 'I03 exact five-mode product/call inventory differs')
    summary = read(output/'capture-summary.json')
    require(summary.get('native_forward_calls_total') == 70 and summary.get('model_loads') == 1 and
            [item['mode'] for item in summary['modes']] == MODES, 'aggregate mode summary differs')
    if require_completed:
        status = read(output/'status.json')
        require(status.get('status') == 'completed' and status.get('task') == TASK and
                status.get('artifacts_manifest_sha256') == sha(output/'artifacts-manifest.json'), 'I03 terminal manifest binding differs')
    return {'status':'i03_output_artifacts_checked','modes':MODES,'native_forward_calls_total':70,'model_loads':1,
        'targets_per_mode':159,'distribution_positions_per_mode':47,'final_cached_layers':NUM_LAYERS,
        'artifacts_manifest_sha256':sha(output/'artifacts-manifest.json'),'output_bytes':check_storage(output),
        'native_executions_started_by_validator':0,'numeric_rederivation':'delegated to independent native-raw admission','acceptance':None}

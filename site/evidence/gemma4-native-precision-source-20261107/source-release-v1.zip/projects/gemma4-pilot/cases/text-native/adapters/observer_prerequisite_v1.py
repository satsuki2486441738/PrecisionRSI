"""Pure metadata gates for actual I04 numerics and observer tiny-CPU proof.

The I04 path checks exactly eight original small documents, never native arrays
or numerical replay. The distinct actual CPU wrapper remains gated until its
downloaded bytes are verified and the None pin is explicitly frozen.
"""
from collections import Counter
from datetime import datetime
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path,PurePosixPath
import re
import sys

HERE=Path(__file__).resolve().parent
CASE='projects/gemma4-pilot/cases/text-native'
I04_PROOF_SHA256='59830ffb67bafb2c0497ef954392fb4fc830dc388afc16a7750195cd09986e54'
CPU_PROOF_SHA256='1c5bbfc0089a78cf5d8564a666feb11bf24144cbbb6814a7003da12cce2ebd63'
CPU_EXPORT_SOURCE_SHA256='cbad23821a46454426a0e61a017a3adb618b8f7a319aea9c92f383d248fe2bf5'
I04_STAGE='26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
I04_EXPECTED='22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76'
I04_MASK_CPU='8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec'
I03_PROOF='3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c'
ANALYSIS='640b0af596111e12eb73aca20f7b8e5b101c04341af0aed2d3a5f9a1d2f19db0'
ARTIFACT_HELPER='0d43e77420285436f4151d42c6cd8a6792001b004e0e0b870242f90c5bd33719'
CONTROLLER_SOURCE='a01ab2aef1ebb99402bd04f739f9f8e751979e77d87599835d5f413c88c59178'
TOOL='06c4467c5b5b17bc5a5626fbded4e581b907ff89197976a063cf6da04c4292cb'
CONTROLLER='5d18a78e14433e5b1e812ca4335704182cbeac1f18ce5fd5ceee30d0ad1cd3f0'
REPORT='b65819037bacac5d9098834a364c3512defb0f77435160f53a0a340a5a8d0c48'
SPEC='7c99bd31179aa73c6dc1f261a4e322b20b322f15b9d616f850fa8d918ded180a'
MAPS={'GPU':'e5bd620ac93e9cae801144fb4e2a6248c607a5e2ef4446e3df6c7bc6a67f36a8','NPU':'4773fd132100afdb000b5531cc824811ed3282215b6df34ff909607f43af528e'}
TASK='gemma4-i04-batch-padding-v1'
MODES=['alone-A','alone-B','batch-left','batch-right']
CONDITIONS={'A':['alone-A','batch-left','batch-right'],'B':['alone-B','batch-left','batch-right']}
HEX=re.compile('[a-f0-9]{64}')
SCOPE={'independent_parent_inputs':1,'derived_prefix_shape_stress_requests':1,'new_model_processes_per_backend':1,
    'native_calls_per_backend':4,'native_modes_per_backend':4,'logical_observations_per_backend':6,'target_scores_rederived':1524,
    'full_vocabulary_rows_rederived':564,'raw_physical_rows_retained':1792,'valid_raw_rows_finite_checked':1536,'pad_only_rows_separately_counted':256,
    'target_distribution_pairs':18,'matched_cross_backend_pairs':6,'within_backend_pairs':12,'original_large_sources_final_bytehash_checked':572,
    'comparison_documents':144,'cache_eviction_tested':False,'fresh_process_repeatability_measured':False,'batch_padding_repeatability_measured':False}


def require(ok,message):
    if not ok:raise ValueError(message)
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):
    def pairs(items):
        out={}
        for k,v in items:require(k not in out,'duplicate JSON key');out[k]=v
        return out
    doc=json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,parse_constant=lambda value:(_ for _ in ()).throw(ValueError(value)))
    canonical(doc);return doc
def ref(path,limit=16*1024**2):
    path=Path(path);require(path.is_file() and not path.is_symlink() and path.stat().st_size<=limit,'bounded regular original proof required')
    return {'path':str(path.resolve()),'sha256':sha(path),'size_bytes':path.stat().st_size}
def absolute(value):
    require(isinstance(value,str) and value.startswith('/') and '\\' not in value and str(PurePosixPath(value))==value and
        all(x not in ('','.','..') for x in value.split('/')[1:]),'original canonical absolute POSIX source identity required');return PurePosixPath(value)
def relative(value):
    require(isinstance(value,str) and '\\' not in value and str(PurePosixPath(value))==value and value.startswith('proof/') and
        all(x not in ('','.','..') for x in value.split('/')),'canonical proof/ copy path required');return PurePosixPath(value)
def flag(argv,name):
    require(isinstance(argv,list) and all(isinstance(x,str) for x in argv) and argv.count(name)==1 and not any(x.startswith(name+'=') for x in argv),'unique literal argv flag required')
    i=argv.index(name);require(i+1<len(argv),'literal argv flag value missing');return argv[i+1]
def positions(request):
    prompt=128 if request=='A' else 64;return sorted({i*(prompt-1)//15 for i in range(16)}|set(range(prompt-1,prompt+31)))
def pairs():
    result=[([f'gpu-{mode}-{request.lower()}',f'npu-{mode}-{request.lower()}'],request,'cross_backend_matched') for request,modes in CONDITIONS.items() for mode in modes]
    for backend in ('gpu','npu'):
        for request,modes in CONDITIONS.items():result.extend(([f'{backend}-{a}-{request.lower()}',f'{backend}-{b}-{request.lower()}'],request,'within_backend_batch_padding') for a,b in itertools.combinations(modes,2))
    return result


def i04_prerequisite(path,digest):
    path=Path(path);require(digest==I04_PROOF_SHA256 and ref(path,65536)['sha256']==digest,'actual I04 wrapper byte SHA differs')
    doc=read(path);names=('controller','report','comparison_spec','analysis_source','artifact_helper_source','tool_manifest')
    require(set(doc)=={'schema_version','kind','prior_stage_sha256','source_maps',*names} and doc['schema_version']==1 and
        doc['kind']=='observer-i04-numeric-prerequisite' and doc['prior_stage_sha256']==I04_STAGE and set(doc['source_maps'])=={'GPU','NPU'},
        'complete actual eight-document I04 prerequisite required')
    items={name:doc[name] for name in names};items.update({side+'_map':item for side,item in doc['source_maps'].items()})
    require(len({x.get('path') for x in items.values()})==8 and len({x.get('source_path') for x in items.values()})==8,'distinct actual eight original/copy identities required')
    refs={};documents={}
    for name,item in items.items():
        require(set(item)=={'path','source_path','sha256'} and isinstance(item['sha256'],str) and HEX.fullmatch(item['sha256']),'exact actual proof ref required')
        absolute(item['source_path']);local=path.parent.joinpath(*relative(item['path']).parts)
        require(local.resolve().is_relative_to(path.parent.resolve()),'portable I04 proof escapes wrapper root')
        current=local
        while current!=path.parent:require(not current.is_symlink(),'symlink in portable I04 proof');current=current.parent
        refs[name]=ref(local);require(refs[name]['sha256']==item['sha256'],'copied I04 original byte SHA differs')
        if name not in ('analysis_source','artifact_helper_source'):documents[name]=read(local)
    require(doc['controller']['sha256']==CONTROLLER and doc['report']['sha256']==REPORT and doc['comparison_spec']['sha256']==SPEC and
        doc['analysis_source']['sha256']==ANALYSIS and doc['artifact_helper_source']['sha256']==ARTIFACT_HELPER and doc['tool_manifest']['sha256']==TOOL and
        {side:item['sha256'] for side,item in doc['source_maps'].items()}==MAPS,'fixed actual I04 source/terminal identities differ')
    controller,report,spec,tool=(documents[name] for name in ('controller','report','comparison_spec','tool_manifest'))
    require(controller['task']=='I04' and controller['status']=='completed' and controller['returncode']==controller['child_returncode']==0 and
        controller['timed_out'] is False and controller['native_executions_started']==0 and controller['acceptance'] is None and
        (controller['whole_cpu_seconds'],controller['child_work_seconds'],controller['analysis_seconds'],controller['cleanup_reserve_seconds'])==(960,920,900,20),
        'actual independent I04 controller did not complete0 within fixed CPU envelope')
    run=absolute(controller['run']);tools=absolute(controller['tools_root'])
    require(absolute(doc['controller']['source_path'])==run/'controller-receipt.json' and controller['report']=={'path':doc['report']['source_path'],'sha256':REPORT} and
        controller['comparison_spec']=={'path':doc['comparison_spec']['source_path'],'sha256':SPEC} and
        absolute(doc['report']['source_path'])==run/'bundle/i04-comparison-report.json' and absolute(doc['comparison_spec']['source_path'])==run/'comparison-spec.json' and
        controller['tool_manifest_sha256']==TOOL and absolute(doc['tool_manifest']['source_path'])==tools/'tool-bundle-manifest.json',
        'actual controller/report/spec/tool original path and SHA chain differs')
    require(controller['argv'][1:3]==['-B',str(tools/(CASE+'/adapters/admit_i04_batch_padding_v1.py'))] and
        flag(controller['argv'],'--spec')==doc['comparison_spec']['source_path'] and flag(controller['argv'],'--spec-sha256')==SPEC and
        flag(controller['argv'],'--output-dir')==str(run/'bundle') and flag(controller['argv'],'--timeout-seconds')=='900',
        'actual direct scientific-analysis argv differs')
    for value in (controller['started_utc'],controller['finished_utc']):
        stamp=datetime.fromisoformat(value.replace('Z','+00:00'));require(stamp.tzinfo is not None and stamp.utcoffset().total_seconds()==0,'original UTC timestamp required')
    require(type(controller['elapsed_seconds']) in (int,float) and math.isfinite(controller['elapsed_seconds']) and 0<=controller['elapsed_seconds']<=960,
        'recorded source-host controller CPU interval differs')
    require(tool['kind']=='i04-offline-tool-bundle' and len(tool['files'])==27 and tool['native_executions_started']==0,'actual27-source manifest differs')
    expected_sources={CASE+'/adapters/admit_i04_batch_padding_v1.py':ANALYSIS,CASE+'/adapters/i04_artifact_admission_v1.py':ARTIFACT_HELPER,
        CASE+'/transfer/run_i04_actual_compare_v1.py':CONTROLLER_SOURCE}
    require(all(tool['files'][name]['sha256']==value for name,value in expected_sources.items()),'reviewed main/helper/controller source pins differ')
    require(absolute(doc['analysis_source']['source_path'])==tools/(CASE+'/adapters/admit_i04_batch_padding_v1.py') and
        absolute(doc['artifact_helper_source']['source_path'])==tools/(CASE+'/adapters/i04_artifact_admission_v1.py'),'actual scientific source original identities differ')
    require(report['status']=='i04_raw_bf16_batch_padding_and_request_pairs_checked' and report['task']==spec['task']==TASK and
        report['stage_spec_sha256']==spec['stage_spec_sha256']==I04_STAGE and report['comparison_spec_sha256']==SPEC and
        report['cpu_prerequisite_sha256']==spec['cpu_prerequisite_sha256']==I04_MASK_CPU and spec['expected_inventory_sha256']==I04_EXPECTED and
        spec['i03_prerequisite_sha256']==I03_PROOF and report['native_executions_started_by_admission']==0 and
        report['thresholds'] is report['acceptance'] is spec['thresholds'] is spec['acceptance'] is None and report['full_core_complete'] is False and
        canonical(report['scope'])==canonical(controller['scope'])==canonical(SCOPE),'actual1524/564/1792/1536/256 I04 scope/proofs differ')
    require(set(spec['endpoints'])=={'GPU','NPU'} and report['source_map_sha256']==MAPS,'both actual admitted backend maps required')
    basename_sources={'admit_i04_batch_padding_v1.py','i04_artifact_admission_v1.py','i04_expected_inventory_v1.py',
        'i04_cpu_prerequisite_v2.py','i04_prerequisite_v1.py','i03_artifact_admission_v1.py'}
    require(len(report['offline_tool_source_sha256'])==16 and all(
        (name if '/' in name else CASE+'/adapters/'+name) in tool['files'] and (('/' in name) or name in basename_sources) and
        tool['files'][name if '/' in name else CASE+'/adapters/'+name]['sha256']==digest for name,digest in report['offline_tool_source_sha256'].items()),
        'actual offline analysis source closure differs')
    for side in ('GPU','NPU'):
        mapping=documents[side+'_map'];endpoint=spec['endpoints'][side];item=doc['source_maps'][side]
        require(endpoint['source_map']=={'path':item['source_path'],'sha256':MAPS[side]} and mapping['schema_version']==1 and
            mapping['request']=={'task':'I04','backend':side,'outer_receipt':endpoint['receipt']['source_path']} and mapping['raw_bytes_preserved'] is True and
            mapping['full_array_hashes_checked']==286 and mapping['retained_array_count']==(286 if side=='NPU' else 0) and
            mapping['files'][endpoint['receipt']['source_path']]['sha256']==endpoint['receipt']['sha256'],'actual backend-map/original outer receipt chain differs')
        large={name:value for name,value in mapping['files'].items() if name.endswith(('.npy','.safetensors'))}
        raw=[name for name in large if name.endswith('/raw-native-logits.safetensors')]
        require(len(large)==286 and len(raw)==4 and sum(name.endswith('.npy') for name in large)==282,'exact four raw and282 FP64 source descriptors required')
        prefixes={name.rpartition('/modes/')[0] for name in raw};require(len(prefixes)==1,'one native artifact root required');prefix=next(iter(prefixes))
        wanted=set()
        for mode in MODES:
            wanted.add(prefix+'/modes/'+mode+'/raw-native-logits.safetensors')
            for request in ([mode[-1]] if mode.startswith('alone-') else ['A','B']):
                wanted.update(prefix+'/modes/'+mode+'/request-'+request+'/dist-p%03d.npy'%p for p in positions(request))
        require(set(large)==wanted,'exact actual286 raw/row logical inventory differs')
        for name,value in large.items():
            absolute(name);require(HEX.fullmatch(value['sha256']) and type(value['size']) is int and value['size']>0,'bounded declared array identity required')
            require((value.get('retained_at_source') is True and 'path' not in value) if side=='NPU' else ('path' in value and not value.get('retained_at_source')),
                'actual GPUcopy/NPUretained roles differ')
    comparisons=report['target_distribution_pairs'];require([(x['sides'],x['request'],x['kind']) for x in comparisons]==pairs(),'exact18 cross-first comparisons required')
    for pair in comparisons:
        count=159 if pair['request']=='A' else 95;target,distribution=pair['targets'],pair['distributions']
        require(target['status']==distribution['status']=='no_thresholds' and target['coverage']=={'expected':count,'paired':count} and target['metrics']['target_count']==count and
            distribution['position_count']==len(distribution['positions'])==47 and [x['position'] for x in distribution['positions']]==positions(pair['request']) and
            len(pair['frozen_document_sha256'])==8 and all(HEX.fullmatch(v) for v in pair['frozen_document_sha256'].values()) and
            pair['thresholds'] is pair['acceptance'] is None,'actual per-request target/47-row/frozen8 source coverage differs')
    require(set(report['raw_derivation'])=={'GPU','NPU'},'both raw derivation sides required')
    for side,modes in report['raw_derivation'].items():
        require(list(modes)==MODES,'all four actual native raw modes required')
        mapping=documents[side+'_map']
        for mode,item in modes.items():
            requests=[mode[-1]] if mode.startswith('alone-') else ['A','B'];pad=item['pad_inventory'];is_batch=mode.startswith('batch')
            require(set(item['observations'])==set(requests) and pad['mode']==mode and pad['task']==TASK and pad['raw_logits_sha256']==item['raw_sha256'] and
                pad['physical_raw_rows']==(320 if is_batch else 160 if mode=='alone-A' else 96) and
                pad['valid_raw_rows']==(256 if is_batch else 160 if mode=='alone-A' else 96) and pad['valid_nonfinite_coordinates']==0 and
                len(pad['pad_only_rows'])==(64 if is_batch else 0),'actual raw valid/pad separation differs')
            require(any(name.endswith('/modes/'+mode+'/raw-native-logits.safetensors') and value['sha256']==item['raw_sha256'] for name,value in mapping['files'].items()),
                'actual native raw SHA is absent from original source map')
            for request,value in item['observations'].items():
                delta=value['largest_abs_logprob_derivation_delta'];require(value['targets']==(159 if request=='A' else 95) and value['distributions']==47 and
                    type(delta) in (int,float) and math.isfinite(delta) and 0<=delta<=1e-12,'actual raw-BF16 derivation proof differs')
    for item in refs.values():require(ref(item['path'])==item,'original I04 copied proof changed during verification')
    require(sha(path)==digest,'actual I04 wrapper changed during checks')
    return {'document':doc,'refs':refs,'prerequisite_sha256':digest,'native_executions_started':0,
        'scope':'Eight original metadata documents checked; no native arrays read or numerical work repeated.'}


def prerequisite(i04_path,i04_digest,cpu_path,cpu_digest):
    frameworks_before={name for name in ('torch','torch_npu','numpy','transformers') if name in sys.modules}
    require(isinstance(CPU_PROOF_SHA256,str) and HEX.fullmatch(CPU_PROOF_SHA256) and cpu_digest==CPU_PROOF_SHA256,
        'actual downloaded observer CPU proof pin remains unready')
    scientific=i04_prerequisite(i04_path,i04_digest)
    source=HERE.parent/'transfer/export_observer_cpu_proof_v1.py';require(ref(source)['sha256']==CPU_EXPORT_SOURCE_SHA256,'reviewed portable CPU checker source differs')
    spec=importlib.util.spec_from_file_location('observer_actual_CPU_metadata_checker',source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    cpu=module.verify_portable(Path(cpu_path).absolute(),cpu_digest)
    require({name for name in ('torch','torch_npu','numpy','transformers') if name in sys.modules}==frameworks_before,
        'dual proof verification imported a framework')
    refs={**{'i04/'+k:v for k,v in scientific['refs'].items()},**{'cpu/'+k:v for k,v in cpu['refs'].items()},
        'i04-wrapper':ref(i04_path),'cpu-wrapper':ref(cpu_path),'CPU-checker-source':ref(source)}
    return {'proofs':{'i04':scientific,'cpu':cpu},'refs':refs,'i04_prerequisite_sha256':i04_digest,'cpu_prerequisite_sha256':cpu_digest,'native_executions_started':0}

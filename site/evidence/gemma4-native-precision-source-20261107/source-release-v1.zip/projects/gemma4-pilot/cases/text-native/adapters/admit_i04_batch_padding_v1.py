"""Admit all I04 raw BF16 data; compare18 request-specific condition pairs.

CPU only,900s maximum. Original source maps/receipts are never rewritten.
Requires complete copied GPU arrays and an explicit source-retained NPU root.
"""
import argparse
import ast
from datetime import datetime,timezone
import itertools
from pathlib import Path,PurePosixPath
import signal
import uuid

import i04_artifact_admission_v1 as native

old=native.old
require=native.require
canonical=native.canonical
load=native.load
sha=native.sha
put=old.put
child=native.child
argument=old.argument
HELPER_SHA='0d43e77420285436f4151d42c6cd8a6792001b004e0e0b870242f90c5bd33719'
COMMON_SHA='f982ab5aa3c0585df85b8861290b43d1f4e276e3888a6df02c07100bf98dde0a'
PRIOR_COMMON_SHA='fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c'
COLLECTORS={'GPU':'7f438e18d507438556566de07f94f1928e01d9aa1a62f0e3a5b53484edce2663',
    'NPU':'eb313464396db09e029db2f63012cd614311357247b67497c4618e977f7fad4e'}
LAUNCHERS={'GPU':('h100_i04_lifecycle_v2.py','4c59dd059c63a5e9929c7f290b2c31d140dea4e98ef24cb0fc5a91dc3b9cfe31'),
    'NPU':('npu_i04_launcher_v1.py','1ac8477196bfb40f2f38f4577e2b7383ae0654866518e4d7d214bdb913f5d451')}
CPU_PROOF_SHA='8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec'


def verify_tools():
    native.verify_tools()
    require(isinstance(HELPER_SHA,str) and old.HEX.fullmatch(HELPER_SHA) and sha(native.__file__)==HELPER_SHA,
        'independent I04 artifact helper remains unready or changed')


def runtime_copies(endpoint,outer,runtime,category):
    packages=runtime['package_sources'];implementations=runtime['implementation_sources']
    require(set(packages)==({'torch','transformers','numpy'} if category=='GPU' else {'torch','torch_npu','transformers','numpy'}) and
        set(implementations)=={'modeling','masking_utils'} and implementations['modeling']==runtime['model_identity']['modeling_source'],
        'complete actual package/modeling/masking implementation sources required')
    refs={ref['path']:ref for ref in [*packages.values(),*implementations.values()]}
    if category=='GPU':
        # The actual GPU lifecycle additionally freezes every Python file_ref
        # nested in runtime.sources/proof metadata, preserving all original keys.
        def visit(value):
            if isinstance(value,dict):
                if set(value)=={'path','sha256','size_bytes'} and str(value['path']).endswith(('.py','.pyi')):
                    require(value['path'] not in refs or refs[value['path']]==value,'conflicting original Python source refs')
                    refs[value['path']]=value
                for nested in value.values():visit(nested)
            elif isinstance(value,list):
                for nested in value:visit(nested)
        visit(runtime)
    frozen=endpoint.json(outer['runtime_source_map_path'],outer['runtime_source_map_sha256'])
    require(set(frozen)==set(refs) and len(frozen)>=(5 if category=='GPU' else 6),'complete runtime original/copy closure differs')
    for ref in refs.values():
        copy=frozen[ref['path']];require(set(ref)=={'path','sha256','size_bytes'} and set(copy)==set(ref) and
            copy['sha256']==ref['sha256'] and copy['size_bytes']==ref['size_bytes'],'runtime preserved-copy identity differs')
        for path in (ref['path'],copy['path']):require(endpoint.get(path,ref['sha256']).stat().st_size==ref['size_bytes'],'runtime implementation size differs')
    claim=str(PurePosixPath(outer['runtime_source_map_path']).parent)
    before=child(claim,'runtime-packages-before.json' if category=='GPU' else 'native-runtime-sources.json')
    require(before in outer['source_sha256'],'pre-model package observation not frozen')
    observed=endpoint.json(before,outer['source_sha256'][before])
    if category=='GPU':
        require(set(observed)=={r['path'] for r in packages.values()} and all(observed[r['path']]['sha256']==r['sha256'] and
            observed[r['path']]['size_bytes']==r['size_bytes'] for r in packages.values()),'GPU pre-model/package identities differ')
    else:require(canonical(observed)==canonical(packages),'NPU pre-model/package identities differ')
    return {key:ref['sha256'] for key,ref in implementations.items()}


def pinned_capture_sources(endpoint,outer,runtime,category):
    refs=runtime['sources'];case='projects/gemma4-pilot/cases/text-native'
    pins={'i04/i04_common_v1.py':COMMON_SHA,'i04/i04_prerequisite_v1.py':native.I03_HELPER_SHA,
        'i04/i04_'+category.lower()+'_v1.py':COLLECTORS[category],
        case+'/adapters/i01_common_v1.py':PRIOR_COMMON_SHA,
        case+'/adapters/i03_common_v1.py':'5cf67f53b5392e4425c4534ec6f97961066c190d24dc1280f31e66781a0fe03a',
        case+'/adapters/i03_prerequisite_v1.py':'e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36'}
    for key,digest in pins.items():require(refs[key]['sha256']==digest,'reviewed capture dependency differs: '+key)
    source=endpoint.get(refs[case+'/adapters/i01_common_v1.py']['path'],PRIOR_COMMON_SHA)
    nested=None
    for node in ast.parse(source.read_text()).body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PINNED' for t in node.targets):nested=ast.literal_eval(node.value)
    require(isinstance(nested,dict) and len(nested)==9,'original loader dependency closure differs')
    for key,digest in nested.items():require(refs[key]['sha256']==digest,'original loader source pin differs')
    for ref in refs.values():
        require(set(ref)=={'path','sha256','size_bytes'} and endpoint.get(ref['path'],ref['sha256']).stat().st_size==ref['size_bytes'],
            'actual capture original source reference differs')
    return refs


def frozen_sources(endpoint,outer,claim):
    sources=outer['source_sha256'];dependencies=outer['dependency_paths']
    require(isinstance(sources,dict) and isinstance(dependencies,list) and len(dependencies)==len(set(dependencies)) and
        set(dependencies)==set(sources),'outer frozen source closure differs')
    for path,digest in sources.items():
        require(isinstance(digest,str) and old.HEX.fullmatch(digest),'invalid frozen source SHA')
        endpoint.get(path,digest)
    require(canonical(endpoint.json(child(claim,'sources-before.json')))==canonical(sources)==
        canonical(endpoint.json(child(claim,'sources-after.json'))),'pre/post native frozen-source maps differ')
    return sources


def admit(endpoint,receipt_ref,category,cpu_sha,proof_folder):
    require(cpu_sha==CPU_PROOF_SHA,'only the actual frozen successful CPUv3 proof is allowed')
    receipt_path=endpoint.get(receipt_ref['source_path'],receipt_ref['sha256']);outer=load(receipt_path)
    fixed={'schema_version':1,'task':'I04','task_id':native.expected.STAGE_ID,'backend':category,'status':'completed','returncode':0,'timed_out':False,
        'collector_sha256':COLLECTORS[category],'input_sha256':native.INPUT_SHAS['A'],'input_b_sha256':native.INPUT_SHAS['B'],'expected_inventory_source_sha256':native.EXPECTED_SHA,
        'stage_spec_source_sha256':native.STAGE_SHA,'i03_prerequisite_source_sha256':native.I03_PROOF_SHA,'cpu_prerequisite_source_sha256':cpu_sha,
        'native_capture_count':1,'native_forward_calls_total':4,'model_loads':1,'acceptance':None}
    require(all(k in outer and canonical(outer[k])==canonical(v) for k,v in fixed.items()),'successful exact finite I04 outer receipt required')
    claim=str(PurePosixPath(receipt_ref['source_path']).parent)
    sources=frozen_sources(endpoint,outer,claim)
    for basename,digest in (('i04_expected_inventory_v1.py',native.EXPECTED_SOURCE_SHA),('record_run.py',old.RECORDER_SHA),('i04_cpu_prerequisite_v2.py',native.CPU_HELPER_SHA),LAUNCHERS[category]):
        require(isinstance(digest,str) and old.HEX.fullmatch(digest),'actual reviewed lifecycle source remains unready')
        found=[path for path in sources if PurePosixPath(path).name==basename]
        require(len(found)==1 and sources[found[0]]==digest,'finite launcher/expected/generic source identity differs')
    argv=outer['argv'];direct=2 if len(argv)>1 and argv[1]=='-B' else 1
    require(argv[direct]==outer['collector_path'] and sources.get(outer['collector_path'])==COLLECTORS[category],'actual native direct collector differs')
    flags={'--input':outer['input_path'],'--input-b':outer['input_b_path'],'--output':outer['output_dir'],'--device':'cuda:0' if category=='GPU' else 'npu:0',
        '--allocation-receipt':outer['allocation_path'],'--stage-spec':outer['stage_spec_source_path'],'--stage-spec-sha256':native.STAGE_SHA,
        '--expected-inventory':outer['expected_inventory_source_path'],'--expected-inventory-sha256':native.EXPECTED_SHA,
        '--i03-prerequisite':outer['i03_prerequisite_source_path'],'--i03-prerequisite-sha256':native.I03_PROOF_SHA}
    for key,value in flags.items():require(argument(argv,key)==value,'executed I04 source argument differs: '+key)
    for path,digest in ((outer['input_path'],native.INPUT_SHAS['A']),(outer['input_b_path'],native.INPUT_SHAS['B']),(outer['stage_spec_source_path'],native.STAGE_SHA),
            (outer['expected_inventory_source_path'],native.EXPECTED_SHA),(outer['i03_prerequisite_source_path'],native.I03_PROOF_SHA),(outer['cpu_prerequisite_source_path'],cpu_sha),(outer['allocation_path'],outer['allocation_sha256'])):
        require(sources.get(path)==digest,'pre-model input/allocation/prerequisite source not frozen')
    for key in ('i03','cpu'):
        logical=outer[key+'_prerequisite_source_path'];proof=endpoint.json(logical)
        def proof_files(value):
            if isinstance(value,dict):
                if set(value)=={'path','source_path','sha256'}:
                    copied=child(str(PurePosixPath(logical).parent),native.safe_relative(value['path']))
                    require(sources.get(copied)==value['sha256'],'portable proof raw document absent from pre-model freeze')
                else:
                    for item in value.values():proof_files(item)
            elif isinstance(value,list):
                for item in value:proof_files(item)
        proof_files(proof)
    claim=str(PurePosixPath(receipt_ref['source_path']).parent);controller=endpoint.json(child(claim,'controller-receipt.json'))
    require(controller.get('task')=='I04' and controller.get('status')=='completed' and type(controller.get('returncode')) is int and controller['returncode']==0 and
        controller.get('timed_out') is False and controller.get('remaining_descendants')==[],'native lifecycle not terminal/cleaned')
    reservation=endpoint.json(child(claim,'claim.json'))
    common_claim={'task_id':native.expected.STAGE_ID,'whole_attempt_seconds':3000,'capture_seconds':900 if category=='GPU' else 1200,
        'logical_transport_cap':1207959552,'encoded_transport_cap':1610612736,'i03_prerequisite_sha256':native.I03_PROOF_SHA,'cpu_prerequisite_sha256':cpu_sha,
        'metadata_export_reserved_seconds':960,'controller_work_seconds':2020}
    require(all(k in reservation and canonical(reservation[k])==canonical(v) for k,v in common_claim.items()),'finite permanent native claim differs')
    if category=='GPU':
        require(reservation.get('independent_expected_sha256')==native.EXPECTED_SHA and reservation.get('independent_expected_bytes')==1082939 and
            reservation.get('lifecycle_sha256')==LAUNCHERS[category][1] and reservation.get('max_capture_bytes')==native.CAP_BYTES and
            reservation.get('max_new_task_bytes_sampled')==4*old.GIB and controller.get('whole_attempt_seconds')==3000 and
            controller.get('cleanup_reserve_seconds')==20 and controller.get('max_new_task_bytes_sampled')==4*old.GIB,'GPU finite claim/controller resource guards differ')
    else:require(reservation.get('expected_inventory_sha256')==native.EXPECTED_SHA and reservation.get('max_capture_product_bytes')==native.CAP_BYTES and
        reservation.get('max_new_bytes_sampled')==4*old.GIB and type(reservation.get('automatic_retries')) is int and reservation['automatic_retries']==0 and
        reservation.get('native_launches')==1 and reservation.get('native_forward_calls')==4 and reservation.get('model_loads')==1,'NPU finite claim resource/retry guards differ')
    generic=endpoint.json(outer['generic_receipt']['path'],outer['generic_receipt']['sha256'])
    require(generic.get('status')=='completed' and type(generic.get('returncode')) is int and generic['returncode']==0 and
        type(generic.get('child_returncode')) is int and generic['child_returncode']==0 and generic['argv']==argv and
        generic['timeout']==(900 if category=='GPU' else 1200),'original bounded generic native execution differs')
    require(old.prior.npu.utc_time(outer['started_utc'])==old.prior.npu.utc_time(generic['start'])<old.prior.npu.utc_time(generic['end'])<=
        old.prior.npu.utc_time(outer['finished_utc']),'native UTC execution chain differs')
    require(old.prior.npu.utc_time(reservation['claimed_utc'])<=old.prior.npu.utc_time(controller['started_utc'])<=old.prior.npu.utc_time(generic['start']) and
        old.prior.npu.utc_time(outer['finished_utc'])<=old.prior.npu.utc_time(controller['finished_utc']),'permanent claim/controller UTC chain differs')
    result=native.inspect_output(endpoint,outer,cpu_sha,proof_folder);runtime=result['runtime'];paths=result['paths']
    fixed={'task':native.expected.TASK,'stage_id':native.expected.STAGE_ID,'stage_spec_sha256':native.STAGE_SHA,'input_sha256s':native.INPUT_SHAS,
        'expected_inventory_sha256':native.EXPECTED_SHA,'expected_inventory_external_path':outer['expected_inventory_source_path'],
        'i03_prerequisite_sha256':native.I03_PROOF_SHA,'i03_prerequisite_external_path':outer['i03_prerequisite_source_path'],
        'backend':category.lower(),'device_argument':flags['--device'],'model_repository':'google/gemma-4-12B','requested_revision':old.prior.npu.REVISION,
        'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':native.NORMALIZATION,'model_loads':1,
        'native_forward_calls_total':4,'modes':native.MODES,'target_scores':762,'distribution_rows':282,
        'physical_raw_rows':896,'valid_raw_rows':768,'pad_only_raw_rows':128,'seed':0,'thresholds':None,'acceptance':None,'full_core_complete':False}
    require(all(k in runtime and canonical(runtime[k])==canonical(v) for k,v in fixed.items()),'actual I04 runtime semantics differ')
    refs=pinned_capture_sources(endpoint,outer,runtime,category);implementations=runtime_copies(endpoint,outer,runtime,category)
    identity=runtime['model_identity'];require(identity['model_class']=='Gemma4UnifiedForConditionalGeneration' and identity['model_type']=='gemma4_unified' and
        identity['parameter_dtypes']==['torch.bfloat16'] and identity['actual_attention']=='eager' and identity['observed_config_commit'] in (None,old.prior.npu.REVISION) and
        'logits_to_keep' in identity['forward_signature'] and sha(paths['snapshot-verification.json'])==identity['snapshot_receipt_sha256'],'loaded model metadata differs')
    metadata=refs['projects/gemma4-pilot/cases/text-native/adapters/upstream-identity.json']
    require(metadata['sha256']==old.prior.npu.METADATA_SHA,'official upstream metadata differs')
    model=old.prior.npu.snapshot_identity(load(paths['snapshot-verification.json']),endpoint.json(metadata['path'],metadata['sha256']),identity['model_class'])
    policy=runtime['math_policy'];require(canonical(policy)==canonical(load(paths['policy-after-load.json']))==canonical(load(paths['policy-after-capture.json'])),
        'backend policy changed through modes')
    allocation=endpoint.json(outer['allocation_path'],outer['allocation_sha256']);physical=runtime['runtime_uuid']
    require(isinstance(physical,str) and str(uuid.UUID(physical))==physical and uuid.UUID(physical).int and allocation['physical_device_id']==physical and
        runtime['allocation_receipt_sha256']==outer['allocation_sha256'] and reservation['allocation_id']==allocation['allocation_id'],'actual physical allocation identity differs')
    versions=runtime['versions']
    if category=='GPU':
        require(versions=={'torch':'2.9.0+cu128','transformers':'5.10.1','cuda_runtime':'12.8','numpy':'1.26.4'} and runtime['device_name']=='NVIDIA H100 80GB HBM3' and
            canonical(policy)==canonical(old.prior.gpu.FROZEN_POLICY),'GPU stack/device/policy differs')
        initial=runtime['initial_rng_observations'];require(all(type(initial.get(k)) is int and initial[k]==0 for k in
            ('seed','python_random_seed','numpy_seed','torch_initial_seed','cuda_initial_seed')) and canonical(initial['settings'])==canonical(policy)==
            canonical(load(paths['policy-before-load.json'])['settings']),'GPU initial seed policy differs')
        require(allocation.get('vendor')=='NVIDIA' and type(allocation.get('visible_count')) is int and allocation['visible_count']==1 and
            type(allocation.get('logical_ordinal')) is int and allocation['logical_ordinal']==0,'GPU logical allocation differs')
        native_probe=endpoint.json(allocation['native_source'],allocation['native_source_sha256']);platform=endpoint.json(allocation['evidence_source'],allocation['platform_source_sha256'])
        require(sources.get(allocation['native_source'])==allocation['native_source_sha256'] and sources.get(allocation['evidence_source'])==allocation['platform_source_sha256'] and
            native_probe['status']=='native_preflight_passed' and native_probe['runtime_uuid']==physical and native_probe['device_name']==runtime['device_name'] and
            native_probe['visible_count']==1 and platform['allocation_id']==allocation['allocation_id'],'GPU actual platform/native source binding differs')
        require(platform.get('task_id')==native.STAGE_ID and platform.get('expected_inventory_sha256')==native.EXPECTED_SHA and
            platform.get('i03_prerequisite_sha256')==native.I03_PROOF_SHA and platform.get('cpu_prerequisite_sha256')==cpu_sha and
            platform.get('lifecycle_sha256')==LAUNCHERS[category][1] and reservation.get('source_sha256')==allocation['platform_source_sha256'],
            'GPU actual source/claim/prerequisite chain differs')
        driver=endpoint.json(child(claim,'driver-receipt.json'),sources[child(claim,'driver-receipt.json')])
        require(driver.get('status')=='observed' and driver.get('returncode')==0 and len([row for row in driver['rows']
            if row.get('uuid')==physical and row.get('name')==runtime['device_name'] and isinstance(row.get('driver_version'),str)])==1 and
            sha(endpoint.get(child(claim,'driver.stdout')))==driver['stdout_sha256'] and
            sha(endpoint.get(child(claim,'driver.stderr')))==driver['stderr_sha256'],'GPU raw native driver evidence differs')
    else:
        require(versions=={'torch':'2.9.0+cpu','torch_npu':'2.9.0.post2','transformers':'5.10.1','numpy':'1.26.4','cann':'9.1.0','driver':'25.5.2'} and
            runtime['instance_visible_count']==8 and runtime['compute_device_count']==1,'NPU selected stack/device count differs')
        old.prior.npu.verify_binding({**runtime,'device':runtime['device_argument']},outer,endpoint,outer['allocation_path'],argument(argv,'--native-mapping'),argument(argv,'--native-source'))
        old.prior.npu.verify_driver_provenance(runtime,outer,endpoint,outer['output_dir'])
        required={'float32_matmul_precision':'highest','matmul_allow_hf32':False,'conv_allow_hf32':True,'deterministic_algorithms':False,'deterministic_warn_only':False,'pythonhashseed':'0'}
        require(all(k in policy and type(policy[k]) is type(v) and policy[k]==v for k,v in required.items()) and
            canonical(load(paths['policy-before-load.json'])['configured'])==canonical(policy),'NPU math policy differs')
    require(type(runtime['free_bytes_before_load']) is int and runtime['free_bytes_before_load']>=35*old.GIB and
        type(runtime['host_memory']['effective_available_bytes']) is int and runtime['host_memory']['effective_available_bytes']>=(40 if category=='GPU' else 80)*old.GIB,
        'recorded native memory boundary differs')
    result.update(category=category,model=model,hardware={'category':category,'model':runtime['device_name']},software={'framework':'torch',**versions},
        backend_policy=policy,implementation_sha256=implementations,runtime_uuid=physical,outer_receipt_sha256=receipt_ref['sha256'])
    return result


def pairs():
    """Six cross-backend matches first; twelve within-backend, never A/B."""
    observations={'A':['alone-A','batch-left','batch-right'],'B':['alone-B','batch-left','batch-right']}
    result=[('GPU',mode,request,'NPU',mode,request,'cross_backend_matched')
        for request,modes in observations.items() for mode in modes]
    for category in ('GPU','NPU'):
        for request,modes in observations.items():
            result.extend((category,a,request,category,b,request,'within_backend_batch_padding') for a,b in itertools.combinations(modes,2))
    require(len(result)==len(set(result))==18 and all(a==b for _,_,a,_,_,b,_ in result),'fixed request-specific18pair inventory differs')
    return result


def observation_run(run,mode,request):
    item=run['modes'][mode]['observations'][request];plan=run['modes'][mode]['mode_plan']
    coordinates=next(o for o in plan['observations'] if o['request']==request)
    return {**item,'side':run['category'].lower()+'-'+mode+'-'+request.lower(),'request':request,
        'model':run['model'],'hardware':run['hardware'],'software':run['software'],'backend_policy':run['backend_policy'],
        'status_path':run['status_path'],'mode':{'mode':mode,'request':request,'slot':coordinates['slot'],
            'physical_offset':coordinates['physical_offset'],'native_batch_size':len(plan['input_ids']),
            'physical_width':plan['raw_logits']['shape'][1],'logical_sequence_length':coordinates['sequence_length'],
            'use_cache':False,'native_forward_calls':1,'same_process_model_loads':1,
            'loaded_model_state_sha256':run['loaded_model_state_sha256'],'implementation_sha256':run['implementation_sha256']}}


def comparison_documents(a,b,request):
    require(a['request']==b['request'] and canonical(a['model'])==canonical(b['model']),'comparison must use the same logical request/checkpoint')
    targets=request['all_targets'];positions=request['distribution_positions']
    common={'model':a['model'],'inputs':{'sha256':native.INPUT_SHAS[a['request']],'request':a['request'],
        'parent_input_sha256':native.INPUT_SHAS['A'],'sequence_length':request['sequence_length']},
        'numerics':{'parameter_dtypes':['torch.bfloat16'],'attention':'eager','native_logits_dtype':'torch.bfloat16',
            'logprob_dtype':'float64','seed':0,'parallelism':'tp1','normalization':native.NORMALIZATION},
        'scope':'one fixed parent input; derived-prefix request B is shape stress, not an independent example; cache-off batch/padding contrasts'}
    conditions={r['side']:{'hardware':r['hardware'],'software':r['software'],'backend_policy':r['backend_policy'],'execution_mode':r['mode']} for r in (a,b)}
    base={'schema_version':1,'common':common,'expected_ranks':{r['side']:[0] for r in (a,b)},'side_conditions':conditions,'thresholds':None}
    docs={'targets-contract.json':{**base,'kind':'target-scores','targets':targets},
        'distributions-contract.json':{**base,'schema_version':2,'kind':'distributions','vocab_size':native.VOCABULARY,
            'normalization_tolerance':1e-5,'renormalization':'none','positions':positions}}
    for run in (a,b):
        side=run['side'];environment=side+'-environment.json'
        docs[environment]={'rank':0,'versions':run['software'],'actual':{**common,**conditions[side]}}
        manifest={'common':common,'side':side,'expected_ranks':[0],
            'ranks':[{'rank':0,'environment':environment,'status':run['status_path']}]}
        require(len(run['scores'])==len(targets) and len(run['positions'])==len(positions)==47,
            'complete request-specific target/distribution inventories required')
        docs[side+'-targets.json']={**manifest,'schema_version':1,'kind':'target-scores','scores':run['scores']}
        docs[side+'-distributions.json']={**manifest,'schema_version':2,'kind':'distributions','positions':run['positions']}
    return docs


def compare_pair(folder,a,b,request):
    docs=comparison_documents(a,b,request);require(len(docs)==8,'eight immutable comparison documents per pair required')
    folder.mkdir()
    for name,doc in docs.items():put(folder/name,doc)
    checks={side:old.prior.npu.validate(folder/'distributions-contract.json',folder/(side+'-distributions.json')) for side in (a['side'],b['side'])}
    require(all(check['status']=='validated' and check['item_count']==47 for check in checks.values()),'shared distribution validation rejected request inventory')
    target=old.prior.npu.compare_targets(folder/'targets-contract.json',folder/(a['side']+'-targets.json'),folder/(b['side']+'-targets.json'))
    distributions=old.prior.npu.compare_distributions(folder/'distributions-contract.json',folder/(a['side']+'-distributions.json'),folder/(b['side']+'-distributions.json'))
    require(target['status']==distributions['status']=='no_thresholds' and
        target['coverage']=={'expected':request['sequence_length']-1,'paired':request['sequence_length']-1} and distributions['position_count']==47,
        'shared target/distribution comparison rejected complete request coverage')
    return {'sides':[a['side'],b['side']],'request':a['request'],'targets':target,'distributions':distributions,'validations':checks,
        'frozen_document_sha256':{name:sha(folder/name) for name in docs},'thresholds':None,'acceptance':None}


def assess(spec_path,spec_sha,output):
    main_sha=sha(__file__)
    verify_tools();require(old.HEX.fullmatch(spec_sha) and sha(spec_path)==spec_sha,'externally frozen I04 comparison spec differs')
    spec=load(spec_path)
    require(spec.get('schema_version')==1 and spec.get('task')==native.TASK and spec.get('stage_spec_sha256')==native.STAGE_SHA and
        spec.get('expected_inventory_sha256')==native.EXPECTED_SHA and spec.get('i03_prerequisite_sha256')==native.I03_PROOF_SHA and
        spec.get('cpu_prerequisite_sha256')==CPU_PROOF_SHA and
        set(spec.get('endpoints',{}))=={'GPU','NPU'} and spec.get('thresholds',object()) is None and spec.get('acceptance',object()) is None,
        'two-endpoint actual I04 specification and CPU proof SHA required')
    output=Path(output).resolve();require(not output.exists() and output.parent.is_dir(),'exclusive new comparison folder required');output.mkdir()
    endpoints={};runs={}
    for category in ('GPU','NPU'):
        info=spec['endpoints'][category];ref=info['source_map']
        require(category!='GPU' or 'retained_root' not in info,'GPU must provide all original raw/NPY bytes')
        endpoint=native.Endpoint(ref['path'],ref['sha256'],info.get('retained_root') if category=='NPU' else None)
        request=load(endpoint.manifest_path).get('request',{})
        require(request.get('task')=='I04' and request.get('backend')==category and request.get('outer_receipt')==info['receipt']['source_path'],
            'source-map request does not identify this original I04 outer receipt')
        endpoints[category]=endpoint;runs[category]=admit(endpoint,info['receipt'],category,spec['cpu_prerequisite_sha256'],output/('proof-'+category.lower()))
    require(canonical(runs['GPU']['model'])==canonical(runs['NPU']['model']) and
        runs['GPU']['configured_layer_types']==runs['NPU']['configured_layer_types'],'backend checkpoint/configuration identities differ')
    large=[(category,name,str(path)) for category,run in runs.items() for name,path in run['paths'].items() if name.endswith(('.npy','.safetensors'))]
    require(len(large)==572 and len({path for _,_,path in large})==572 and
        all(sum(c==category for c,_,_ in large)==286 for category in ('GPU','NPU')),'each backend requires distinct282NPY+4raw sources')
    reports=[]
    for ordinal,(ca,ma,ra,cb,mb,rb,kind) in enumerate(pairs()):
        a,b=observation_run(runs[ca],ma,ra),observation_run(runs[cb],mb,rb)
        report=compare_pair(output/('scores-%02d'%ordinal),a,b,runs[ca]['inventory']['requests'][ra]);report['kind']=kind;reports.append(report)
    for endpoint in endpoints.values():
        for logical,digest in endpoint.checked.items():require(sha(endpoint.resolved[logical])==digest,'original source changed during numerical comparison')
        require(sha(endpoint.manifest_path)==endpoint.expected_sha,'source map changed during numerical comparison')
    require(sha(spec_path)==spec_sha and sha(__file__)==main_sha,'I04 comparison spec or executed main source changed');verify_tools()
    result={'schema_version':1,'status':'i04_raw_bf16_batch_padding_and_request_pairs_checked','task':native.TASK,
        'stage_spec_sha256':native.STAGE_SHA,'comparison_spec_sha256':spec_sha,'checked_utc':datetime.now(timezone.utc).isoformat(),
        'source_map_sha256':{key:endpoint.expected_sha for key,endpoint in endpoints.items()},
        'offline_tool_source_sha256':{**old.prior.IMPORT_PINS,'admit_i04_batch_padding_v1.py':main_sha,
            'i04_artifact_admission_v1.py':HELPER_SHA,'i04_expected_inventory_v1.py':native.EXPECTED_SOURCE_SHA,
            'i04_cpu_prerequisite_v2.py':native.CPU_HELPER_SHA,'i04_prerequisite_v1.py':native.I03_HELPER_SHA,
            'i03_artifact_admission_v1.py':native.PRIOR_SHA},
        'cpu_prerequisite_sha256':spec['cpu_prerequisite_sha256'],
        'scope':{'independent_parent_inputs':1,'derived_prefix_shape_stress_requests':1,'new_model_processes_per_backend':1,
            'native_calls_per_backend':4,'native_modes_per_backend':4,'logical_observations_per_backend':6,
            'target_scores_rederived':1524,'full_vocabulary_rows_rederived':564,'raw_physical_rows_retained':1792,
            'valid_raw_rows_finite_checked':1536,'pad_only_rows_separately_counted':256,
            'target_distribution_pairs':18,'matched_cross_backend_pairs':6,'within_backend_pairs':12,
            'original_large_sources_final_bytehash_checked':572,'comparison_documents':144,'cache_eviction_tested':False,
            'fresh_process_repeatability_measured':False,'batch_padding_repeatability_measured':False},
        'target_distribution_pairs':reports,'raw_derivation':{category:{mode:{'raw_sha256':item['raw_sha256'],
            'pad_inventory':item['pad_inventory'],'observations':{request:{'targets':len(o['scores']),'distributions':len(o['positions']),
                'largest_abs_logprob_derivation_delta':o['raw_derivation_max_abs_delta']} for request,o in item['observations'].items()}}
            for mode,item in run['modes'].items()} for category,run in runs.items()},
        'native_executions_started_by_admission':0,'thresholds':None,'acceptance':None,'full_core_complete':False,
        'limitations':['One parent input; B is its exact96-token prefix and not an independent representative example',
            'Three logical conditions per request share one loaded process/model; no new repeats or cache/scheduler measurement',
            'Pad-only raw BF16 payload is retained unchanged, counted separately, never normalized or paired',
            'All request metrics remain per pair; no unweighted averaging of NLL or percentiles across request lengths',
            'Source/snapshot/runtime receipts are not scheduler or loader-consumed-byte attestation; no operator cause inferred',
            'Top100-union probability errors and complement-merged JS are not full-vocabulary errors/divergence']}
    put(output/'i04-comparison-report.json',result);return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec',type=Path,required=True);parser.add_argument('--spec-sha256',required=True)
    parser.add_argument('--output-dir',type=Path,required=True);parser.add_argument('--timeout-seconds',type=int,default=900)
    args=parser.parse_args();require(hasattr(signal,'SIGALRM') and 1<=args.timeout_seconds<=900,'finite POSIX CPU1..900s required')
    def expire(*_):raise TimeoutError('I04 independent admission CPU deadline exceeded')
    previous=signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,args.timeout_seconds)
    try:result=assess(args.spec,args.spec_sha256,args.output_dir)
    finally:signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)
    print(old.json.dumps({'status':result['status'],'target_distribution_pairs':18,'native_executions_started':0,'acceptance':None}))


if __name__=='__main__':main()


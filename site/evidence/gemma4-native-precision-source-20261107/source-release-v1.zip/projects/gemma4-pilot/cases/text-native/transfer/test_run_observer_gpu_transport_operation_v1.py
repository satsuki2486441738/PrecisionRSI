"""Synthetic process/receipt regressions; no real platform or archive data."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('observer_transport_recorded',HERE/'run_observer_gpu_transport_operation_v1.py')
tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)


@unittest.skipUnless(os.name=='posix','Owned POSIX process groups')
class Protocol(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        (self.root/'runs').mkdir();self.target=self.root/'transports/synthetic';self.tools=self.target/'tools';self.tools.mkdir(parents=True)
        self.document={'parts':[{'index':0,'wrapper_basename':'synthetic.tar','wrapper_sha256':'a'*64}],
            'archive':{'sha256':'b'*64,'size_bytes':1},'source_map_sha256':'c'*64}
        (self.root/'synthetic.tar').write_bytes(b'CPU synthetic wrapper')

    def fake_assembler(self,source):
        (self.tools/tool.ASSEMBLER).write_text(source,encoding='utf-8')

    def invoke(self,mode,wrapper=None):
        with patch.object(tool,'verify_tools',return_value=self.document):
            code=tool.run(self.root,self.tools,'d'*64,'e'*64,'transports/synthetic',mode,wrapper)
        paths=list((self.root/'runs').glob('*/controller-receipt.json'));self.assertEqual(len(paths),1)
        return code,tool.read(paths[0])

    def test_real_child7_failed_and_permanent_claim(self):
        self.fake_assembler('raise SystemExit(7)\n');code,state=self.invoke('stage',self.root/'synthetic.tar')
        self.assertEqual((code,state['status'],state['child_returncode']),(2,'failed',7));self.assertFalse(state['remaining_owned_process_group'])
        self.assertTrue((self.root/'synthetic.tar').is_file())
        with self.assertRaises(FileExistsError):self.invoke('stage',self.root/'synthetic.tar')

    def test_zero_exit_without_matching_receipt_is_failed(self):
        self.fake_assembler('print("{}")\n');code,state=self.invoke('assemble')
        self.assertEqual((code,state['status']),(2,'failed'));self.assertFalse(state['remaining_owned_process_group'])
        self.assertTrue((self.target/'assemble-operation-claim.json').exists())

    def test_real_sleep_timeout_reaps_owned_process_group(self):
        self.fake_assembler('import time\ntime.sleep(60)\n')
        with patch.object(tool,'CHILD',.05):code,state=self.invoke('stage',self.root/'synthetic.tar')
        self.assertEqual((code,state['status'],state['timed_out']),(2,'failed',True));self.assertFalse(state['remaining_owned_process_group'])

    def test_boundary_symlink_and_unknown_wrapper_fail_before_claim(self):
        self.fake_assembler('raise SystemExit(0)\n');outside=self.root.parent/'outside-synthetic.tar'
        with self.assertRaises(ValueError):self.invoke('stage',outside)
        (self.root/'alias').symlink_to(self.target,target_is_directory=True)
        with self.assertRaises(ValueError):tool.contained(self.root,self.root/'alias/file')

    def test_real_frozen_assembler_subprocess_stage_and_original_gzip_roundtrip(self):
        sys.path.insert(0,str(HERE))
        try:
            source=importlib.util.spec_from_file_location('observer_prior_transport_fixture',HERE/'test_observer_gpu_transport_v1.py')
            old=importlib.util.module_from_spec(source);source.loader.exec_module(old)
            sender=self.root/'synthetic-sender';sender.mkdir()
            fixture=old.Fixture(sender)
            with patch.object(old.s,'NATIVE_PINS',fixture.native_pins):created=fixture.split(self.root/'tiny-wrappers')
            manifest=Path(created['manifest'])
        finally:sys.path.pop(0)
        shutil.copyfile(HERE/tool.ASSEMBLER,self.tools/tool.ASSEMBLER);shutil.copyfile(Path(tool.__file__),self.tools/Path(tool.__file__).name)
        shutil.copyfile(manifest,self.tools/tool.TRANSPORT)
        files={name:{'sha256':tool.sha(self.tools/name),'size_bytes':(self.tools/name).stat().st_size} for name in
            (tool.ASSEMBLER,tool.TRANSPORT,Path(tool.__file__).name)}
        tool.put(self.tools/tool.TOOLS,{'kind':'observer-gpu-transport-tools','files':files,'native_executions_started':0})
        args=[sys.executable,'-S','-B',str(self.tools/Path(tool.__file__).name)]
        suffix=['--root',str(self.root),'--tools-root',str(self.tools),'--tool-manifest-sha256',tool.sha(self.tools/tool.TOOLS),
            '--transport-manifest-sha256',created['manifest_sha256'],'--transport-subdir','transports/synthetic']
        for part in created['parts']:
            uploaded=self.root/part['wrapper_basename'];shutil.copyfile(self.root/'tiny-wrappers'/part['wrapper_basename'],uploaded)
            result=subprocess.run(args+['stage']+suffix+['--wrapper',str(uploaded)],capture_output=True,text=True,timeout=20)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr);self.assertFalse(uploaded.exists())
        result=subprocess.run(args+['assemble']+suffix,capture_output=True,text=True,timeout=20)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertEqual((self.root/'gpu-observer-synthetic-not-native.tar.gz').read_bytes(),fixture.archive.read_bytes())
        states=[tool.read(p) for p in (self.root/'runs').glob('*/controller-receipt.json')]
        self.assertEqual(len(states),len(created['parts'])+1)
        self.assertTrue(all(x['status']=='completed' and x['returncode']==x['child_returncode']==0 and not x['remaining_owned_process_group'] for x in states))


if __name__=='__main__':unittest.main()

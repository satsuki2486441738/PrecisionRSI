"""Stream-audit OBSERVER GPU evidence, then wrap unchanged gzip bytes for UI.

All native objects are byte-hashed, never loaded as tensors or extracted here.
The export controller, map and archive each require external actual SHA pins.
Only transport metadata changes; numerical admission remains a separate task.
"""
import argparse
import hashlib
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import tarfile
import time

import reassemble_observer_gpu_transport_v1 as transport

ASSEMBLER_SHA = '4116c0b2924f842111b24abe8c3822609b07fd5334342e3c4616b054d1e273b5'
EXPORTER_SHA = '1d9c0b12aba73c73e33b14840a23f60094d7d427decc20f482289912cc1ffcc0'
RUNNER_SHA = 'e6bbae27c95af75a543e4f28193823e5354e7cfa39a80b00a964b3a75d2946e8'
NATIVE_PINS = {
    'outer_sha256': '71538b5c387d56997f5b1bf3553d8f29236f6f1255f63e3943080a3b5bb01765',
    'controller_sha256': '6a0e0777938a1d68d12cb95b1d8648cad8cfea7f1ae731bce817437a5df7e29c',
    'artifacts_manifest_sha256': 'cec57b3ccc5bba9841cf74256d86937c1427bab1b6264d5126df8326e683a229',
    'source_manifest_sha256': 'bcca74886a74808fa1d6b3bd09734b7b4eed8bd549a30f3793ef21b44a2e5437',
    'launcher_sha256': '3083f7b09f37f6c67e2bc49293231ace71038abc7c298025341882534c4a211a',
    'collector_sha256': 'e0fd43dd50f31b7e4f8280616f7b2655ff22e1166e41e6c229206777b61f3191'}
MODES = ('off-before', 'hooks-only', 'off-after', 'hooks-plus-dispatch-metadata')
POSITIONS = sorted({i*127//15 for i in range(16)} | set(range(127, 159)))
require = transport.require


def verify_tools():
    require(Path(transport.__file__).resolve() == Path(__file__).with_name('reassemble_observer_gpu_transport_v1.py').resolve()
            and transport.sha(transport.__file__) == ASSEMBLER_SHA, 'frozen colocated assembler differs')


def source_path(value):
    require(isinstance(value, str) and value.startswith('/') and '\\' not in value
            and str(PurePosixPath(value)) == value
            and all(p not in ('', '.', '..') for p in value.split('/')[1:]),
            'original canonical absolute POSIX path required')
    return PurePosixPath(value)


def controller(path, digest, size, archive_sha, map_sha, logical):
    path = transport.regular(path)
    require(path.stat().st_size <= 1024**2 and transport.HEX.fullmatch(digest)
            and transport.sha(path) == digest, 'actual export controller bytes differ')
    doc = transport.read(path)
    require(doc.get('task') == 'observer-CPU-transport-export' and doc.get('backend') == 'GPU'
            and doc.get('status') == 'completed' and doc.get('returncode') == 0
            and doc.get('child_returncode') == 0 and doc.get('timed_out') is False
            and doc.get('native_executions_started') == 0 and doc.get('numeric_admission_performed') is False
            and doc.get('raw_capture_unmodified') is True and doc.get('source_arrays_retained') is False,
            'completed original GPU transport controller required')
    require(doc.get('exporter_sha256') == EXPORTER_SHA and doc.get('runner_sha256') == RUNNER_SHA
            and (doc['whole_CPU_seconds'], doc['generic_seconds'], doc['export_work_seconds'],
                 doc['cleanup_reserve_seconds']) == (960, 920, 900, 20), 'reviewed export source/deadlines differ')
    require(0 <= doc['prior_native_attempt_seconds']
            and doc['cumulative_native_and_reserved_export_seconds'] == doc['prior_native_attempt_seconds'] + 960
            and doc['cumulative_native_and_reserved_export_seconds'] <= 3600,
            'cumulative native attempt/export budget differs')
    result = doc['result']
    require(result.get('status') == 'observer_transport_export_completed'
            and (result['archive_bytes'], result['archive_sha256'], result['source_map_sha256'],
                 result['logical_payload_bytes']) == (size, archive_sha, map_sha, logical)
            and result.get('retained_array_count') == 0 and result.get('transport_allowed_by_actual_size') is True
            and result.get('max_logical_transport_bytes') == transport.LOGICAL_CAP
            and result.get('max_encoded_transport_bytes') == transport.ENCODED_CAP
            and result.get('native_executions_started') == 0 and result.get('model_acceptance') is None
            and doc.get('source_map_sha256') == map_sha, 'controller actual archive/map/size binding differs')
    pins = doc['actual_native_terminal_pins']
    require(all(pins.get(k) == v for k, v in NATIVE_PINS.items()), 'actual native receipt/source pins differ')
    return doc


def verify_full_archive(archive, size, digest, map_sha, logical, deadline, export_controller=None):
    archive = transport.regular(archive)
    require(type(size) is int and 0 < size <= transport.ENCODED_CAP
            and type(logical) is int and 0 < logical <= transport.LOGICAL_CAP
            and transport.HEX.fullmatch(digest) and transport.HEX.fullmatch(map_sha)
            and archive.stat().st_size == size and transport.sha(archive, deadline) == digest,
            'actual externally frozen gzip size/SHA differs')
    members, bodies, total = {}, {}, 0
    # One decompression pass: source-map is last in the real archive. Retain
    # hashes and bounded JSON only, never full native tensors or NPY payloads.
    with tarfile.open(archive, 'r|gz') as package:
        for item in package:
            require(time.monotonic() < deadline, 'full archive stream deadline reached')
            transport.safe(item.name)
            require(item.isfile() and not item.sparse and not item.islnk() and not item.issym()
                    and item.name not in members and 0 <= item.size <= transport.LOGICAL_CAP,
                    'unique ordinary regular GPU payload members required')
            total += item.size
            require(len(members) < 4096 and total <= transport.LOGICAL_CAP, 'expanded GPU payload budget exceeded')
            retain = item.name in ('source-map.json', 'export-summary.json') or item.name.endswith('/capture-receipt.json')
            require(not retain or item.size <= 16*1024**2, 'bounded retained metadata JSON required')
            h = hashlib.sha256(); count = 0; chunks = []
            with package.extractfile(item) as source:
                for block in iter(lambda: source.read(4*1024**2), b''):
                    require(time.monotonic() < deadline, 'GPU member hash deadline reached')
                    count += len(block); h.update(block)
                    if retain: chunks.append(block)
            require(count == item.size, 'truncated GPU member')
            members[item.name] = {'size': count, 'sha256': h.hexdigest()}
            if retain: bodies[item.name] = b''.join(chunks)
    names = set(members)
    require(total == logical and {'source-map.json', 'export-summary.json'} <= names
            and all(all(str(p) not in names for p in PurePosixPath(n).parents if str(p) != '.') for n in names),
            'actual payload size/topology differs')
    require(members['source-map.json']['sha256'] == map_sha, 'actual top source-map SHA differs')
    mapping = transport.parse(bodies['source-map.json']); request = mapping['request']
    require(mapping.get('schema_version') == 1 and request.get('task') == 'OBSERVER' and request.get('backend') == 'GPU'
            and mapping.get('raw_bytes_preserved') is True and mapping.get('full_array_hashes_checked') == 194
            and mapping.get('retained_array_count') == 0 and mapping.get('acceptance') is None,
            'complete copied OBSERVER GPU194 source map required')
    require(all(mapping['actual_native_terminal_pins'].get(k) == v for k, v in NATIVE_PINS.items()),
            'mapped actual native source pins differ')
    override = mapping['deployment_namespace_override']
    require(override.get('frozen_stage_spec_sha256') == transport.STAGE_SHA
            and override.get('independent_expected_inventory_sha256') == transport.EXPECTED_SHA
            and override.get('lifecycle_sha256') == NATIVE_PINS['launcher_sha256']
            and override.get('literal_stage_root_agreement_claimed') is False
            and override.get('numeric_geometry_changed') is False
            and override['frozen_stage_declared_GPU_root'].endswith('/observer-transparency-20261107-gpu-v1')
            and override['approved_GPU_root'].endswith('/observer-transparency-20261107-gpu-v2'),
            'approved GPU namespace override must remain explicit')
    files = mapping['files']; by_copied = {}; binary = set()
    require(isinstance(files, dict) and len(files) <= 4094, 'bounded mapped original files required')
    for original, ref in files.items():
        source_path(original)
        require(not ref.get('retained_at_source') and type(ref.get('size')) is int and ref['size'] >= 0
                and isinstance(ref.get('sha256'), str) and transport.HEX.fullmatch(ref['sha256']),
                'copied GPU path/hash/size descriptor differs')
        relative = str(transport.safe(ref['path']))
        require(relative.startswith('payload/') and relative not in by_copied, 'unique copied payload path required')
        by_copied[relative] = ref
        if original.endswith(('.npy', '.safetensors')): binary.add(original)
        else: require(ref['size'] <= 16*1024**2, 'small metadata exceeds16MiB')
        require(members.get(relative) == {'size': ref['size'], 'sha256': ref['sha256']}, 'mapped GPU payload size/SHA differs')
    require(names == set(by_copied) | {'source-map.json', 'export-summary.json'}, 'all mapped member coverage required')
    outer_source = request['outer_receipt']; source_path(outer_source)
    require(outer_source in files and files[outer_source]['sha256'] == NATIVE_PINS['outer_sha256'], 'original outer receipt pin differs')
    outer_body = bodies[files[outer_source]['path']]; outer = transport.parse(outer_body)
    output = source_path(outer['output_dir'])
    expected = {str(output/'modes'/mode/('dist-p%03d.npy' % p)) for mode in MODES for p in POSITIONS}
    expected |= {str(output/'modes'/mode/'raw-native-logits.safetensors') for mode in MODES}
    expected |= {str(output/'modes'/mode/'boundary-samples.safetensors') for mode in ('hooks-only', 'hooks-plus-dispatch-metadata')}
    require(binary == expected and len(binary) == 194, 'exact188 NPY/four raw/two boundary sample inventory required')
    require(outer.get('artifacts_manifest_sha256') == NATIVE_PINS['artifacts_manifest_sha256']
            and outer.get('deployment_namespace_override') == override, 'outer manifest/namespace override binding differs')
    if export_controller is not None:
        require(export_controller['outer_receipt'] == outer_source
                and export_controller['actual_native_terminal_pins'] == mapping['actual_native_terminal_pins'],
                'export controller and mapped native receipts differ')
    summary = transport.parse(bodies['export-summary.json'])
    require(summary.get('status') == 'payload_copied_and_rehashed' and summary.get('source_map_sha256') == map_sha
            and summary.get('mapped_files') == len(files) and summary.get('retained_arrays') == 0,
            'completed exporter summary binding differs')
    require(archive.stat().st_size == size and transport.sha(archive, deadline) == digest, 'gzip changed during stream audit')
    return {'regular_members': len(members), 'mapped_files': len(files), 'mapped_source_files_rehashed': len(files),
            'large_objects': 194, 'npy_files': 188, 'raw_logits_files': 4, 'boundary_sample_files': 2,
            'large_file_bytes': sum(files[x]['size'] for x in binary), 'logical_payload_bytes': total,
            'deployment_namespace_override': override, 'native_tensor_values_read': 0, 'numeric_admission_performed': False}


class LimitedReader:
    def __init__(self, source, size, deadline): self.source, self.remaining, self.deadline = source, size, deadline; self.digest = hashlib.sha256()
    def read(self, size=-1):
        require(time.monotonic() < self.deadline, 'split CPU deadline reached')
        size = self.remaining if size < 0 else min(size, self.remaining); data = self.source.read(size)
        require(len(data) == size, 'gzip truncated during split'); self.remaining -= len(data); self.digest.update(data); return data


def split(archive, size, digest, map_sha, logical, output, controller_path, controller_sha, basename):
    started = time.monotonic(); deadline = started + 900; verify_tools(); archive = Path(archive); output = Path(output)
    require(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,180}\.tar\.gz', basename), 'unique portable transport basename required')
    require(output.parent.is_dir() and not output.exists() and not output.is_symlink(), 'exclusive new local transport directory required')
    require(shutil.disk_usage(output.parent).free >= transport.MIN_FREE, 'local storage below5GiB')
    ctl = controller(controller_path, controller_sha, size, digest, map_sha, logical)
    audit = verify_full_archive(archive, size, digest, map_sha, logical, deadline, ctl)
    planned = []; offset = 0
    while offset < size:
        index = len(planned); count = min(transport.CHUNK_DATA, size-offset)
        planned.append({'index': index, 'offset': offset, 'data_size_bytes': count, 'member_name': 'chunk-%04d.bin' % index,
                        'wrapper_basename': basename[:-7]+'-transport-%04d.tar' % index, 'wrapper_size_bytes': transport.tar_size(count)})
        offset += count
    budget = transport.accounting(size, logical, planned)
    require(1 <= len(planned) <= 7 and all(p['wrapper_size_bytes'] <= transport.WRAPPER_CAP for p in planned)
            and budget['wrapper_wire_bytes'] <= transport.ENCODED_CAP
            and budget['staged_wrappers_plus_reconstructed_plus_expanded_bytes'] + transport.METADATA_RESERVE <= transport.DISK_CAP,
            'wrapper wire/new scratch storage cap exceeded')
    output.mkdir(mode=0o700); parts = []
    with archive.open('rb') as source:
        for plan in planned:
            wrapper = output/plan['wrapper_basename']; reader = LimitedReader(source, plan['data_size_bytes'], deadline)
            with wrapper.open('xb') as destination, tarfile.open(fileobj=destination, mode='w:', format=tarfile.USTAR_FORMAT) as package:
                info = tarfile.TarInfo(plan['member_name']); info.size = plan['data_size_bytes']; info.mode = 0o600
                info.uid = info.gid = info.mtime = 0; info.uname = info.gname = ''; package.addfile(info, reader)
            require(reader.remaining == 0 and wrapper.stat().st_size == plan['wrapper_size_bytes'], 'exact wrapper coverage differs')
            parts.append({**plan, 'data_sha256': reader.digest.hexdigest(), 'wrapper_sha256': transport.sha(wrapper, deadline)})
        require(source.tell() == size and source.read(1) == b'', 'original gzip chunk coverage differs')
    require(archive.stat().st_size == size and transport.sha(archive, deadline) == digest
            and transport.sha(controller_path) == controller_sha, 'original gzip/controller changed during split')
    document = {'schema_version': 1, 'kind': 'observer-gpu-archive-tar-chunks', 'stage_spec_sha256': transport.STAGE_SHA,
                'cpu_prerequisite_sha256': transport.CPU_SHA, 'expected_inventory_sha256': transport.EXPECTED_SHA,
                'i04_prerequisite_sha256': transport.I04_SHA, 'archive': {'basename': basename, 'size_bytes': size, 'sha256': digest},
                'source_map_sha256': map_sha, 'logical_payload_bytes': logical, 'chunk_data_limit_bytes': transport.CHUNK_DATA,
                'wrapper_wire_limit_bytes': transport.WRAPPER_CAP, 'parts': parts, 'transport_accounting': budget,
                'source_archive_audit': audit, 'source_export_controller_sha256': controller_sha,
                'splitter_sha256': transport.sha(__file__), 'assembler_sha256': ASSEMBLER_SHA,
                'original_gzip_bytes_preserved': True, 'numeric_admission_performed': False, 'native_executions_started': 0, 'acceptance': None}
    transport.validate(document); manifest = output/'observer-gpu-transport-manifest-v1.json'; transport.put(manifest, document)
    receipt = {'status': 'observer_gpu_transport_wrappers_created', 'manifest': str(manifest.resolve()),
               'manifest_sha256': transport.sha(manifest), 'archive_sha256': digest, 'parts': parts,
               'source_archive_audit': audit, 'transport_accounting': budget, 'elapsed_seconds': time.monotonic()-started,
               'native_executions_started': 0, 'numeric_admission_performed': False, 'acceptance': None}
    transport.put(output/'split-receipt.json', receipt); return receipt


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True); parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--archive-bytes', type=int, required=True); parser.add_argument('--archive-sha256', required=True)
    parser.add_argument('--source-map-sha256', required=True); parser.add_argument('--logical-bytes', type=int, required=True)
    parser.add_argument('--export-controller', type=Path, required=True); parser.add_argument('--export-controller-sha256', required=True)
    parser.add_argument('--transport-basename', required=True); args = parser.parse_args()
    def expire(*_): raise TimeoutError('OBSERVER local split900s deadline')
    signal.signal(signal.SIGALRM, expire); signal.setitimer(signal.ITIMER_REAL, 900)
    try: print(transport.json.dumps(split(args.archive, args.archive_bytes, args.archive_sha256, args.source_map_sha256,
               args.logical_bytes, args.output, args.export_controller, args.export_controller_sha256, args.transport_basename), indent=2))
    finally: signal.setitimer(signal.ITIMER_REAL, 0)

"""Render private I04 publication candidates only from frozen actual evidence.

CLI --spec/--spec-sha256/--output-dir; the spec supplies actual main and E02
transport envelopes and the separately reviewed49-task public coverage ledger.
No source-host paths are rewritten, no native arrays opened and no public/Git
files written. Missing/unexecuted inputs fail before candidate creation.
"""
import argparse
import base64
from collections import Counter
import copy
import hashlib
import io
import json
import math
from pathlib import Path,PurePosixPath
import re
import tarfile

CASE='projects/gemma4-pilot/cases/text-native'
SOURCES={'main':('adapters/admit_i04_batch_padding_v1.py','640b0af596111e12eb73aca20f7b8e5b101c04341af0aed2d3a5f9a1d2f19db0'),
    'helper':('adapters/i04_artifact_admission_v1.py','0d43e77420285436f4151d42c6cd8a6792001b004e0e0b870242f90c5bd33719'),
    'controller':('transfer/run_i04_actual_compare_v1.py','a01ab2aef1ebb99402bd04f739f9f8e751979e77d87599835d5f413c88c59178')}
E02_SOURCES={'runner_sha256':'ca5e3a2e7550a410c620c20724312f6f0cd249db7703cc7d8d853160daadac45',
    'verifier_sha256':'2cdb98c37f2e3690ed9b7918ff0b223f4f662d90014c0bbd649c2dc76ecc639c',
    'independent_scalar_source_sha256':'863019a1bd9875d418630c4c5e547576232e225fd66a98d63d51f3023701a44e',
    'generic_sha256':'2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'}
TOOL_SHA='06c4467c5b5b17bc5a5626fbded4e581b907ff89197976a063cf6da04c4292cb'
STAGE_SHA='26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
EXPECTED_SHA='22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76'
CPU_SHA='8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec'
I03_SHA='3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c'
BASELINE_COVERAGE_SHA='18fc77f052edc307587ca57c3a183d0c52b36c9c83e56349b64d5c0352f32905'
INPUTS={'A':'643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0','B':'f4bca8e16d2e7768c6f9dff0677ea329ccf46ed254e211dc2ce2f9852f416792'}
TASK='gemma4-i04-batch-padding-v1';LENGTHS={'A':160,'B':96};PROMPTS={'A':128,'B':64}
CONDITIONS={'A':['alone-A','batch-left','batch-right'],'B':['alone-B','batch-left','batch-right']}
MODEL={'repository':'google/gemma-4-12B','variant':'base','revision':'1a2c7729392586f5ecddae8807ee2ef741eabb9a','parameter_dtype':'BF16','attention':'eager'}
HEX=re.compile(r'^[a-f0-9]{64}$');MAX_SMALL=16*1024**2


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def encoded(value):return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def parse(raw):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=reject)


def frozen(ref):
    require(isinstance(ref,dict) and set(ref)=={'path','sha256'} and isinstance(ref['sha256'],str) and HEX.fullmatch(ref['sha256']),
        'actual external path/SHA reference required; no pending inputs')
    p=Path(ref['path']);require(p.is_file() and not p.is_symlink() and p.stat().st_size<=64*1024**2,'bounded original input required')
    raw=p.read_bytes();require(sha(raw)==ref['sha256'],'frozen input SHA differs');return raw


def relative(name):
    p=PurePosixPath(name);require(isinstance(name,str) and name and not p.is_absolute() and str(p)==name and '\\' not in name and
        all(x not in ('','.','..') for x in name.split('/')),'canonical relative member required');return name


def origin(name):
    p=PurePosixPath(name);require(isinstance(name,str) and p.is_absolute() and str(p)==name and '..' not in p.parts and '\\' not in name,'original POSIX identity required');return name


def child(name,suffix):return str(PurePosixPath(origin(name))/relative(suffix))
def completed(doc):require(doc.get('status')=='completed' and type(doc.get('returncode')) is int and doc['returncode']==0,'actual completed0 receipt required')
def positions(request):return sorted(set(i*(PROMPTS[request]-1)//15 for i in range(16))|set(range(PROMPTS[request]-1,LENGTHS[request]-1)))
def public_side(side):return side.lower()


def pairs():
    import itertools
    result=[([f'gpu-{m}-{r.lower()}',f'npu-{m}-{r.lower()}'],r,'cross_backend_matched') for r,ms in CONDITIONS.items() for m in ms]
    for b in ('gpu','npu'):
        for r,ms in CONDITIONS.items():result.extend(([f'{b}-{a}-{r.lower()}',f'{b}-{c}-{r.lower()}'],r,'within_backend_batch_padding') for a,c in itertools.combinations(ms,2))
    return result


def metric_number(value):
    if isinstance(value,dict):value=value['value']
    require(type(value) in (int,float) and math.isfinite(value),'finite scalar metric required');return value


class Archive:
    def __init__(self,ref):
        require(type(ref.get('bytes')) is int and 0<ref['bytes']<=32*1024**2 and HEX.fullmatch(ref['sha256']),'bounded original gzip reference required')
        raw=base64.b64decode(ref['base64'],validate=True);require(len(raw)==ref['bytes'] and sha(raw)==ref['sha256'],'transport gzip bytes/SHA differ')
        self.ref=ref;self.package=tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz');self.members={};self.hashes={};self.data={};total=0
        # Inspect each header before advancing/decompressing its payload. Cache
        # bounded metadata bytes to avoid repeated random gzip decompression.
        for m in self.package:
            relative(m.name);require(m.name not in self.members and m.type==tarfile.REGTYPE and m.isfile() and not m.sparse and 0<=m.size<=MAX_SMALL,
                'unique bounded regular metadata members required')
            require(not m.name.endswith(('.npy','.safetensors')),'array member prohibited in publication metadata')
            total+=m.size;require(total<=192*1024**2 and len(self.members)<4096,'finite metadata archive bound exceeded')
            member_raw=self.package.extractfile(m).read(m.size+1);require(len(member_raw)==m.size,'metadata member byte count differs')
            self.members[m.name]=m;self.data[m.name]=member_raw;self.hashes[m.name]=sha(member_raw)
        require(all(not any(str(p) in self.members for p in PurePosixPath(n).parents if str(p)!='.') for n in self.members),'ancestor member collision')
    def raw(self,name,digest=None,size=None):
        relative(name);require(name in self.members,'original metadata member missing')
        require(digest is None or self.hashes[name]==digest,'original member SHA differs')
        require(size is None or self.members[name].size==size,'original member size differs')
        raw=self.data[name];require(sha(raw)==self.hashes[name],'cached original metadata byte proof differs');return raw
    def json(self,name,digest=None):return parse(self.raw(name,digest))


class MainBundle:
    def __init__(self,ref):
        envelope=parse(frozen(ref));require(envelope.get('kind')=='i04-actual-small-archives' and len(envelope['archives'])==2,'actual main small transport required')
        self.envelope_sha=ref['sha256'];self.archive=Archive(envelope['archives'][0]);self.proof_archive=Archive(envelope['archives'][1])
        self.mapping=self.archive.json('metadata-source-map.json');self.map_sha=self.archive.hashes['metadata-source-map.json'];m=self.mapping
        require(m.get('kind')=='i04-actual-numeric-small-export' and m.get('arrays_statted_opened_or_copied')==m.get('fresh_array_hashes_by_exporter')==0 and
            m.get('numeric_replay_performed_by_exporter') is False and m.get('native_executions_started')==0,'array-free actual main metadata required')
        self.files=m['files'];seen=set()
        for original,entry in self.files.items():
            origin(original);self.archive.raw(entry['path'],entry['sha256'],entry['size']);seen.add(entry['path'])
        for name,entry in m['generated_files'].items():self.archive.raw(name,entry['sha256'],entry['size']);seen.add(name)
        require(seen|{'metadata-source-map.json'}==set(self.archive.members),'unmapped main metadata archive member')
        require(any(PurePosixPath(name).name=='export_i04_actual_small_v1.py' and entry['sha256']=='4153db0b6b8bcdd2f240ef70f5c57249d21bee569e920754b136b1a2ff63dbd5'
            and entry.get('role')=='small_exporter_source' for name,entry in self.files.items()),'actual4153 metadata producer source byte proof missing')
        self.omitted=m['omitted'];require(len(self.omitted)==572 and Counter(x['backend'] for x in self.omitted.values())=={'GPU':286,'NPU':286} and
            sum(n.endswith('.npy') for n in self.omitted)==564 and sum(n.endswith('.safetensors') for n in self.omitted)==8,'all572 original large descriptors required')
        for original,entry in self.omitted.items():origin(original);require(HEX.fullmatch(entry['sha256']) and type(entry['size']) is int and entry['size']>0,'omitted descriptor differs')
        self.controller=self.json(m['controller']['path'],m['controller']['sha256']);completed(self.controller);c=self.controller
        require(c['task']=='I04' and c['returncode']==c['child_returncode']==0 and c['timed_out'] is False and c['native_executions_started']==0 and
            c['tool_manifest_sha256']==TOOL_SHA and (c['whole_cpu_seconds'],c['child_work_seconds'],c['analysis_seconds'],c['cleanup_reserve_seconds'])==(960,920,900,20),'actual main completed source identity differs')
        self.report=self.json(c['report']['path'],c['report']['sha256']);self.spec=self.json(c['comparison_spec']['path'],c['comparison_spec']['sha256'])
        r,s=self.report,self.spec
        require(r['status']=='i04_raw_bf16_batch_padding_and_request_pairs_checked' and r['task']==s['task']==TASK and r['comparison_spec_sha256']==c['comparison_spec']['sha256'] and
            r['stage_spec_sha256']==s['stage_spec_sha256']==STAGE_SHA and s['expected_inventory_sha256']==EXPECTED_SHA and
            r['cpu_prerequisite_sha256']==s['cpu_prerequisite_sha256']==CPU_SHA and s['i03_prerequisite_sha256']==I03_SHA and
            r['native_executions_started_by_admission']==0 and r['source_map_sha256']=={b:x['source_map']['sha256'] for b,x in s['endpoints'].items()} and
            r['thresholds'] is r['acceptance'] is None and r['full_core_complete'] is False,'original actual main report/spec differ')
        require([(p['sides'],p['request'],p['kind']) for p in r['target_distribution_pairs']]==pairs(),'exact18 cross-first request-preserving comparisons required')
        expected_scope={'independent_parent_inputs':1,'derived_prefix_shape_stress_requests':1,'native_calls_per_backend':4,'logical_observations_per_backend':6,
            'target_scores_rederived':1524,'full_vocabulary_rows_rederived':564,'raw_physical_rows_retained':1792,'valid_raw_rows_finite_checked':1536,
            'pad_only_rows_separately_counted':256,'target_distribution_pairs':18,'matched_cross_backend_pairs':6,'within_backend_pairs':12,
            'original_large_sources_final_bytehash_checked':572,'comparison_documents':144}
        require(all(r['scope'].get(k)==v for k,v in expected_scope.items()),'actual I04 measured scope differs')
        original_large=set()
        for backend,info in s['endpoints'].items():
            mapping=self.json(info['source_map']['path'],info['source_map']['sha256']);outer=self.json(info['receipt']['source_path'],info['receipt']['sha256'])
            require(mapping['request']=={'task':'I04','backend':backend,'outer_receipt':info['receipt']['source_path']} and
                mapping['full_array_hashes_checked']==286 and mapping['retained_array_count']==(0 if backend=='GPU' else 286),'original286-object endpoint identity differs')
            wanted={'modes/'+mode+'/raw-native-logits.safetensors' for mode in ('alone-A','alone-B','batch-left','batch-right')}
            wanted|={'modes/'+mode+'/request-'+request+'/dist-p%03d.npy'%p for request,ms in CONDITIONS.items() for mode in ms for p in positions(request)}
            native={name:entry for name,entry in mapping['files'].items() if name.endswith(('.npy','.safetensors'))}
            prefix=outer['output_dir']+'/'
            require(len(native)==286 and all(name.startswith(prefix) for name in native) and {name[len(prefix):] for name in native}==wanted,
                'original endpoint exact4raw/282row identities differ')
            for name,entry in native.items():
                omitted=self.omitted[name];require(omitted['backend']==backend and omitted['sha256']==entry['sha256'] and omitted['size']==entry['size'],
                    'omission descriptor does not match original frozen source map')
            original_large.update(native)
        require(original_large==set(self.omitted),'omitted native pool differs from original two source maps')
        tools=c['tools_root'];manifest=self.json(child(tools,'tool-bundle-manifest.json'),TOOL_SHA)
        require(len(manifest['files'])==27,'actual27-source main closure required')
        for name,entry in manifest['files'].items():self.raw(child(tools,name),entry['sha256'],entry['size_bytes'])
        for name,digest in SOURCES.values():require(manifest['files'][CASE+'/'+name]['sha256']==digest,'fixed actual scientific source differs')
        require(c['argv'][2]==child(tools,CASE+'/'+SOURCES['main'][0]),'actual direct main source differs')
        frozen_count=0
        for p in r['target_distribution_pairs']:
            folder=str(PurePosixPath(p['targets']['sources']['contract']).parent);require(len(p['frozen_document_sha256'])==8,'eight frozen documents per pair required')
            for name,digest in p['frozen_document_sha256'].items():self.raw(child(folder,name),digest);frozen_count+=1
        require(frozen_count==144,'complete144 frozen comparison sources required')
        self.generic=self.json(c['generic_receipt']['path'],c['generic_receipt']['sha256']);completed(self.generic)
        require(self.generic['argv']==c['argv'] and self.generic['child_returncode']==0 and self.generic['timeout']==920,'original main generic execution differs')
        # Exact8 portable original docs are also present in the separate proof.
        proof=self.proof_archive.json('prerequisite.json');refs=[proof[k] for k in ('controller','report','comparison_spec','analysis_source','artifact_helper_source','tool_manifest')]+list(proof['source_maps'].values())
        require(proof['kind']=='observer-i04-numeric-prerequisite' and len(refs)==8 and len(self.proof_archive.members)==9,'original8-document observer proof required')
        for item in refs:require(self.proof_archive.raw(item['path'],item['sha256'])==self.raw(item['source_path'],item['sha256']),'portable original source bytes differ')
    def raw(self,original,digest=None,size=None):
        entry=self.files[origin(original)];require(digest is None or digest==entry['sha256'],'original metadata reference SHA conflicts')
        return self.archive.raw(entry['path'],entry['sha256'],entry['size'] if size is None else size)
    def json(self,original,digest=None):return parse(self.raw(original,digest))


class E02Bundle:
    def __init__(self,ref,main):
        env=parse(frozen(ref));require(env.get('kind')=='i04-selected-e02-small-transport','actual E02 transport required')
        raw=base64.b64decode(env['controller_raw_base64'],validate=True);require(sha(raw)==env['controller_sha256'],'raw E02 controller SHA differs')
        self.controller=parse(raw);completed(self.controller);c=self.controller;self.controller_sha=sha(raw);self.envelope_sha=ref['sha256']
        require(c['task']=='I04-selected-E02' and c['child_returncode']==0 and c['timed_out'] is False and c['native_executions_started']==0 and
            c['native_array_files_copied']==0 and (c['child_cpu_seconds'],c['generic_envelope_seconds'],c['whole_cpu_seconds'],c['cleanup_reserve_seconds'])==(900,920,960,20) and
            c['original_controller_sha256']==main.mapping['controller']['sha256'],'actual E02 terminal source/controller scope differs')
        require(all(c[k]==v for k,v in E02_SOURCES.items()),'reviewed E02 source closure differs')
        self.archive=Archive(env['archive']);require({k:env['archive'][k] for k in ('path','bytes','sha256')}==c['archive'],'E02 controller/archive reference differs')
        self.original_root=str(PurePosixPath(env['controller_path']).parent);require(PurePosixPath(c['generic_receipt']['path']).parent.parent==PurePosixPath(self.original_root),'original E02 relative layout differs')
        membermap=self.archive.json('archive-members.json');require(set(membermap['files'])|{'archive-members.json'}==set(self.archive.members),'all E02 archive members must be covered')
        for name,entry in membermap['files'].items():self.archive.raw(name,entry['sha256'],entry['size_bytes'])
        require(membermap['native_array_files']==0 and c['archive_regular_members']==len(self.archive.members),'array-free full member inventory differs')
        self.report=self.json(c['report']['path'],c['report']['sha256']);r=self.report
        require(r['status']=='independent_i04_selected_e02_checks_matched' and r['source_controller']['sha256']==main.mapping['controller']['sha256'] and
            r['source_report']==main.controller['report'] and r['comparison_spec']==main.controller['comparison_spec'] and r['native_executions_started']==0 and
            r['thresholds'] is r['acceptance'] is None and r['full_core_complete'] is False,'actual E02 report does not bind original main')
        scope=r['scope'];require(scope['target_pairs']==18 and scope['request_target_counts']=={'A':159,'B':95} and
            scope['matched_cross_backend_distribution_pair_rows']==282 and 282<=scope['independent_distribution_pair_rows']<=285 and
            scope['admitted_large_sources_final_bytehash_checked']==572 and scope['native_KV_checks']==0 and r['native_KV_checks']==[],
            'actual independent18-target/selected-row/572 hash scope differs')
        self.generic=self.json(c['generic_receipt']['path'],c['generic_receipt']['sha256']);completed(self.generic)
        require(self.generic['child_returncode']==0 and self.generic['timeout']==920 and self.generic['argv'][1:3]==['-S','-B'],'actual E02 generic execution differs')
        result_root=str(PurePosixPath(c['report']['path']).parent);self.selection=self.json(child(result_root,'selection.json'),r['selection_sha256'])
        source_proof=self.json(child(result_root,'source-proof.json'));pool=self.json(child(result_root,'admitted-large-source-hashes.json'))
        require(len(pool)==572 and len({x['original_path'] for x in pool})==572 and len({x['resolved_path'] for x in pool})==572 and
            source_proof['all_admitted_large_final_hashes']==572,'fresh572-object byte proof required')
        for item in pool:
            reference=main.omitted[item['original_path']];require(all(item[k]==reference[k] for k in ('backend','sha256','size')),'E02 large hash differs from original admission')
            checked=source_proof['checked_sources'][item['resolved_path']];require(checked['sha256']==item['sha256'] and checked['size']==item['size'],'E02 final large byte proof differs')
        metadata=self.archive.json('payload/metadata-source-map.json');require(metadata['kind']=='i04-selected-e02-metadata' and metadata['native_array_files_copied']==0 and metadata['numeric_scope']==scope,'original E02 metadata map differs')
        for original,entry in metadata['files'].items():origin(original);self.archive.raw('payload/'+entry['path'],entry['sha256'],entry['size'])
        for filename,digest in [('run_i04_selected_e02_v1.py',E02_SOURCES['runner_sha256']),('verify_i04_selected_e02_v1.py',E02_SOURCES['verifier_sha256']),
                ('verify_i03_selected_e02_v1.py',E02_SOURCES['independent_scalar_source_sha256']),('record_run.py',E02_SOURCES['generic_sha256'])]:
            require(any(PurePosixPath(name).name==filename and entry['sha256']==digest for name,entry in metadata['files'].items()),'E02 raw scientific source byte proof missing')
        require(len(r['target_pair_checks'])==18 and [p['sides'] for p in r['target_pair_checks']]==[p[0] for p in pairs()] and
            len(r['distribution_checks'])==scope['independent_distribution_pair_rows'],'all18 real E02 target pair checks required')
        for a,b in zip(r['target_pair_checks'],main.report['target_distribution_pairs']):
            for k,v in a['metrics'].items():
                if k=='max_coordinate':require(v==b['targets']['metrics'][k],'E02 target coordinate differs')
                else:require(math.isclose(metric_number(v),metric_number(b['targets']['metrics'][k]),rel_tol=5e-12,abs_tol=1e-12),'E02 target metric differs')
        expected={(i,p) for i,pair in enumerate(main.report['target_distribution_pairs'][:6]) for p in positions(pair['request'])}
        for field in ('tail_merged_js','probability_rmse','max_probability_error'):
            i=max(range(18),key=lambda i:metric_number(main.report['target_distribution_pairs'][i]['distributions']['aggregate'][field]['max']))
            expected.add((i,main.report['target_distribution_pairs'][i]['distributions']['aggregate'][field]['max_coordinate']['position']))
        require([(x['pair_index'],x['position']) for x in self.selection['distribution_rows']]==sorted(expected) and
            [(x['pair_index'],x['position']) for x in r['distribution_checks']]==sorted(expected),'actual selected282-plus-global-extrema inventory differs')
        for checked in r['distribution_checks']:
            p=main.report['target_distribution_pairs'][checked['pair_index']];require(checked['sides']==p['sides'] and checked['request']==p['request'],'E02 selected logical pair differs')
            old=[x for x in p['distributions']['positions'] if x['position']==checked['position']];require(len(old)==1,'original selected distribution row missing')
            for key in ('tail_merged_js','probability_rmse','max_probability_error','top100_overlap'):
                require(math.isclose(metric_number(checked['metrics'][key]),metric_number(old[0][key]),rel_tol=5e-12,abs_tol=1e-12),'E02 selected scalar differs from main')
            require(len(checked['raw_native_to_NPY_max_abs_delta'])==2 and all(0<=metric_number(x)<=1e-12 for x in checked['raw_native_to_NPY_max_abs_delta']),
                'actual selected raw-to-FP64 derivation bound differs')
    def raw(self,original,digest=None):
        name=PurePosixPath(origin(original));root=PurePosixPath(self.original_root);require(name.is_relative_to(root),'original E02 product escapes invocation')
        return self.archive.raw(name.relative_to(root).as_posix(),digest)
    def json(self,original,digest=None):return parse(self.raw(original,digest))


def target_metrics(raw,independent=False):
    allowed={'target_count','side_a_nll_nat_per_token','side_b_nll_nat_per_token','nll_abs_diff_nat_per_token','mae_nat','p99_nat','p99_method','max_abs_nat','max_coordinate'}
    require(set(raw)==allowed-({'p99_method'} if independent else set()),'complete target metric schema required')
    out={k:copy.deepcopy(v) for k,v in raw.items() if k!='max_coordinate'}
    if independent:out['p99_method']='global linear h=0.99*(N-1)'
    out['max_target_index_zero_based']=raw['max_coordinate']['position']-1
    return out


def mismatch(raw):
    ids=sorted({raw['side_a_token'],raw['side_b_token']});require(len(ids)==2 and [x['token'] for x in raw['probabilities']]==ids,'exact two top1 diagnostic candidates required')
    return {'side_a_top1_candidate_index':ids.index(raw['side_a_token']),'side_b_top1_candidate_index':ids.index(raw['side_b_token']),
        'probabilities':[{'anonymous_candidate_index':i,'side_a':x['side_a'],'side_b':x['side_b']} for i,x in enumerate(raw['probabilities'])],
        'side_a_margin':raw['side_a_margin'],'side_b_margin':raw['side_b_margin']}


def distribution_row(raw,index=None):
    required={'union_count','tail_merged_js','top1_agreement','top100_overlap','probability_rmse','max_probability_error','coverage','normalization_mass'}
    allowed=required|{'sample','position','max_error_token','top1_mismatch','direct_complement_mass'}
    require(required<=set(raw) and set(raw)<=allowed,'complete known distribution row schema required')
    out={k:copy.deepcopy(raw[k]) for k in required}
    if 'direct_complement_mass' in raw:out['direct_complement_mass']=copy.deepcopy(raw['direct_complement_mass'])
    if 'top1_mismatch' in raw:out['top1_mismatch']=mismatch(raw['top1_mismatch'])
    if 'position' in raw:out['prediction_index_zero_based']=raw['position']
    if index is not None:out['sampled_position_index_zero_based']=index
    return out


def aggregate(raw):
    require(set(raw)<={'probability_rmse','max_probability_error','tail_merged_js','top1_agreement','top100_overlap','coverage','normalization_mass'},'unknown aggregate metric field')
    out=copy.deepcopy(raw)
    for key in ('probability_rmse','max_probability_error','tail_merged_js'):
        coordinate=out[key]['max_coordinate'];require(set(coordinate)<={'sample','position','token'} and 'position' in coordinate,'known global distribution coordinate required')
        out[key]['max_coordinate']={'prediction_index_zero_based':coordinate['position']}
    return out


def conditions(contract,side):
    raw=contract['side_conditions'][side];mode=raw['execution_mode'];hardware=raw['hardware'];software=raw['software']
    software_keys={'framework','torch','torch_npu','transformers','cuda_runtime','cann','driver','numpy'}
    policy_keys={'deterministic_algorithms','deterministic_warn_only','cudnn_deterministic','cudnn_benchmark','cuda_matmul_allow_tf32',
        'cudnn_allow_tf32','float32_matmul_precision','cublas_workspace_config','pythonhashseed','matmul_allow_hf32','conv_allow_hf32','jit_compile_false','cube_math_type'}
    require(set(raw['backend_policy'])<=policy_keys,'new backend policy field requires explicit public review')
    mode_keys={'mode','request','slot','physical_offset','native_batch_size','physical_width','logical_sequence_length','use_cache','native_forward_calls',
        'same_process_model_loads','loaded_model_state_sha256','implementation_sha256'}
    require(set(mode)==mode_keys and mode['use_cache'] is False and mode['native_forward_calls']==mode['same_process_model_loads']==1,'cache-off one-call native condition required')
    return {'hardware':{k:hardware[k] for k in ('category','model')},'software':{k:v for k,v in software.items() if k in software_keys},
        'numerics':copy.deepcopy(contract['common']['numerics']),'backend_policy':copy.deepcopy(raw['backend_policy']),'execution_mode':copy.deepcopy(mode)}


def calculate(a,b):
    n=len(a);require(n in (159,95) and len(b)==n and all(type(x) in (int,float) and math.isfinite(x) and x<=0 for x in a+b),'complete159/95 anonymous vectors required')
    errors=[abs(x-y) for x,y in zip(a,b)];order=sorted(errors);h=.99*(n-1);lo=math.floor(h);hi=math.ceil(h)
    na,nb=[math.fsum(-x for x in seq)/n for seq in (a,b)]
    return {'target_count':n,'side_a_nll_nat_per_token':na,'side_b_nll_nat_per_token':nb,'nll_abs_diff_nat_per_token':abs(na-nb),'mae_nat':math.fsum(errors)/n,
        'p99_nat':order[lo]+(h-lo)*(order[hi]-order[lo]),'p99_method':'global linear h=0.99*(N-1)','max_abs_nat':max(errors),'max_target_index_zero_based':errors.index(max(errors))}


def close_metrics(actual,recorded):
    require(set(actual)==set(recorded),'target scalar inventory differs')
    for key,value in actual.items():
        if type(value) in (int,str):require(type(value) is type(recorded[key]) and value==recorded[key],'target discrete scalar differs')
        else:require(math.isclose(value,metric_number(recorded[key]),rel_tol=0,abs_tol=1e-12),'target scalar differs')


def collect_targets(main):
    runs={};target_pairs=[];distributions=[]
    for pair in main.report['target_distribution_pairs']:
        request=pair['request'];count=LENGTHS[request]-1;contract=main.json(pair['targets']['sources']['contract']);source=pair['targets']['sources']
        require(len(contract['targets'])==count and [x['position'] for x in contract['targets']]==list(range(1,count+1)), 'frozen full logical target contract required')
        for label,side in zip(('side_a','side_b'),pair['sides']):
            ref=source[label];document=main.json(ref);scores=document['scores'];require(len(scores)==count,'frozen target vector length differs')
            require([{k:x[k] for k in ('sample','position','token')} for x in scores]==contract['targets'],'frozen target identities differ')
            values=[x['logprob'] for x in scores];backend=side.split('-')[0].upper();mode=contract['side_conditions'][side]['execution_mode']['mode']
            row={'id':public_side(side),'backend':backend,'mode':mode,'request':request,'target_start_index_zero_based':0,'target_count':count,
                'target_vector_sha256':sha(canonical(values).encode()),'raw_native_logits_sha256':main.report['raw_derivation'][backend][mode]['raw_sha256'],
                'largest_abs_raw_logprob_derivation_delta':main.report['raw_derivation'][backend][mode]['observations'][request]['largest_abs_logprob_derivation_delta'],
                'conditions':conditions(contract,side),'target_logprobs_nat':values}
            if side in runs:require(runs[side]['target_logprobs_nat']==values and runs[side]['conditions']==row['conditions'],'same observation differs across frozen peers')
            else:runs[side]=row
            runs[side].setdefault('frozen_target_document_sha256',[])
            digest=main.files[ref]['sha256']
            if digest not in runs[side]['frozen_target_document_sha256']:runs[side]['frozen_target_document_sha256'].append(digest)
        sides=[public_side(x) for x in pair['sides']];metrics=target_metrics(pair['targets']['metrics'])
        close_metrics(calculate(*[runs[s]['target_logprobs_nat'] for s in pair['sides']]),metrics)
        require(pair['targets']['coverage']=={'expected':count,'paired':count},'full per-request target coverage required')
        target_pairs.append({'id':'-vs-'.join(sides),'sides':sides,'request':request,'kind':pair['kind'],'coverage':pair['targets']['coverage'],
            'target_start_index_zero_based':0,'metrics':metrics,'thresholds':None,'acceptance':None})
        d=pair['distributions'];require(d['status']=='no_thresholds' and d['position_count']==len(d['positions'])==47 and
            [x['position'] for x in d['positions']]==positions(request),'47 complete per-request rows required')
        distributions.append({'id':'-vs-'.join(sides),'sides':sides,'request':request,'kind':pair['kind'],'status':d['status'],'position_count':47,
            'positions':[distribution_row(x,i) for i,x in enumerate(d['positions'])],'aggregate':aggregate(d['aggregate']),
            'normalization_tolerance':d['normalization_tolerance'],'renormalization':d['renormalization'],'thresholds':None,'acceptance':None})
    order=[f'{b}-{m}-{r.lower()}' for b in ('gpu','npu') for m in ('alone-A','alone-B','batch-left','batch-right')
        for r in ([m[-1]] if m.startswith('alone-') else ['A','B'])]
    require(set(runs)==set(order) and len(runs)==12,'exact12 distinct logical observations required')
    return [runs[x] for x in order],target_pairs,distributions


def independent_summary(e02,main):
    r=e02.report
    return {'schema_version':1,'kind':'selected_I04_independent_E02_summary','status':r['status'],'source_controller_sha256':e02.controller_sha,
        'source_report_sha256':e02.controller['report']['sha256'],'original_I04_report_sha256':main.controller['report']['sha256'],
        'verifier_sha256':E02_SOURCES['verifier_sha256'],'source_selection_sha256':r['selection_sha256'],'scope':copy.deepcopy(r['scope']),
        'verification':copy.deepcopy(r['verification']),
        'target_pair_checks':[{'sides':[public_side(s) for s in x['sides']],'request':x['request'],'metrics':target_metrics(x['metrics'],True)} for x in r['target_pair_checks']],
        'distribution_checks':[{'sides':[public_side(s) for s in x['sides']],'request':x['request'],'prediction_index_zero_based':x['position'],
            'metrics':distribution_row(x['metrics']),'raw_native_to_NPY_max_abs_delta':x['raw_native_to_NPY_max_abs_delta']} for x in r['distribution_checks']],
        'native_KV_checks':[],'all_native_array_hashes_checked':572,'native_executions_started':0,'thresholds':None,'acceptance':None,'full_core_complete':False,
        'limitations':['All18 target reductions and282 matched cross-backend row contrasts plus at most3 reported extrema are independently checked.',
            'All572 native files receive a fresh source-side SHA pass. The local public replay reads0 arrays and recomputes targets only.',
            'This is selected distribution scalar replay, not a second global search across all846 contrasts or a repeat of all1536 valid native row derivations.',
            'B is a96-token prefix shape stress of the same discovery parent. No fresh-process or batch-condition repeatability was measured.']}


def accounting(main,e02):
    model={}
    for backend,info in main.spec['endpoints'].items():
        outer=main.json(info['receipt']['source_path'],info['receipt']['sha256']);ref=outer['generic_receipt'];generic=main.json(ref['path'],ref['sha256']);completed(generic)
        require(generic['child_returncode']==0 and type(generic['wall_seconds']) in (int,float) and math.isfinite(generic['wall_seconds']) and generic['wall_seconds']>=0,
            'actual source-host instrumented child duration required')
        model[backend]={'recorder_receipt_sha256':ref['sha256'],'status':'completed','returncode':0,'recorded_wall_seconds':generic['wall_seconds'],
            'recorded_start_utc_on_source_host':generic['start'],'recorded_end_utc_on_source_host':generic['end'],'native_model_processes':1,'loaded_models':1,
            'native_forward_calls':4,'scope':'Instrumented model child: imports, loading, capture and validation; parent preparation/transfer excluded.',
            'uninstrumented_latency_seconds':None,'active_device_seconds':None,'allocated_instance_seconds':None,'currency_cost':None}
    return {'schema_version':1,'kind':'selected_I04_execution_accounting','source_metadata_map_sha256':main.map_sha,
        'scope':'Two instrumented native model children and distinct offline controllers; a measured subset of evaluation work.',
        'model_children':model,'cpu_numerical_admission':{'controller_sha256':main.mapping['controller']['sha256'],'status':'completed','returncode':0,
            'recorded_wall_seconds':main.controller['elapsed_seconds'],'native_executions_started':0,'scope':'Whole offline controller including child; never add nested child time again.'},
        'cpu_selected_E02':{'controller_sha256':e02.controller_sha,'status':'completed','returncode':0,'recorded_wall_seconds':e02.controller['elapsed_seconds'],
            'native_executions_started':0,'scope':'Selected CPU verification plus metadata packaging; includes its numeric child.'},
        'total_evaluation_cost_complete':False,'P01_complete':False,'headline_speed_comparison_supported':False,
        'total_allocated_device_seconds':None,'total_currency_cost':None,
        'unknown_or_excluded':['Queue and allocated-instance lifetime/rates/billing.','Complete preparation, retries, transfers, CPU validation and cleanup cost.',
            'Uninstrumented synchronized latency, throughput, warmup and peak memory.','Source-host clocks differ; no cross-host interval is subtracted.'], 'acceptance':None}


def privacy(value):
    forbidden={'sample','token','token_id','prompt','history','input_ids','source_path','device_uuid','gpu_uuid','allocation_id','app_id','password','credential'}
    def check(item):
        if isinstance(item,dict):
            require(not(set(item)&forbidden),'private field escaped public allowlist')
            for x in item.values():check(x)
        elif isinstance(item,list):
            for x in item:check(x)
        elif isinstance(item,str):
            require(not re.search(r'(?:/home/|/tmp/|/mnt/|[A-Za-z]:\\|(?:\d{1,3}\.){3}\d{1,3}|[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}|REDACTED_ACCOUNT|user-job-dir|app-[a-z0-9]{8})',item),'private source identity escaped public allowlist')
    check(value);canonical(value)


def replay_source(target_sha,metric_sha,pair_list):
    """Public standalone stdlib target replay; exactly two JSON reads."""
    source='''#!/usr/bin/env python3
"""Replay18 anonymous I04 target pairs,159/95 separately; open0 native arrays.
Usage: python -S -B replay-targets.py selected-targets.json [selected-metrics.json]
Distribution scalars and E02/cost summaries are archived, not recomputed here.
"""
import hashlib,json,math
from pathlib import Path
import sys
TARGET_SHA=__TARGET_SHA__
METRIC_SHA=__METRIC_SHA__
PAIRS=__PAIRS__
def require(ok,message):
 if not ok:raise ValueError(message)
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)
def load(path,digest):
 p=Path(path);require(p.is_file() and not p.is_symlink() and p.stat().st_size<=16*1024**2,'bounded public JSON required')
 raw=p.read_bytes();require(hashlib.sha256(raw).hexdigest()==digest,'frozen public artifact SHA differs')
 def pairs(items):
  out={}
  for k,v in items:require(k not in out,'duplicate JSON key');out[k]=v
  return out
 def reject(v):raise ValueError('nonfinite JSON token '+v)
 return json.loads(raw,object_pairs_hook=pairs,parse_constant=reject)
def calculate(a,b):
 n=len(a);require(n in (159,95) and len(b)==n and all(type(x) in (int,float) and math.isfinite(x) and x<=0 for x in a+b),'complete159/95 vectors required')
 e=[abs(x-y) for x,y in zip(a,b)];s=sorted(e);h=.99*(n-1);lo=math.floor(h);hi=math.ceil(h);na,nb=[math.fsum(-v for v in x)/n for x in (a,b)]
 return {'target_count':n,'side_a_nll_nat_per_token':na,'side_b_nll_nat_per_token':nb,'nll_abs_diff_nat_per_token':abs(na-nb),'mae_nat':math.fsum(e)/n,'p99_nat':s[lo]+(h-lo)*(s[hi]-s[lo]),'p99_method':'global linear h=0.99*(N-1)','max_abs_nat':max(e),'max_target_index_zero_based':e.index(max(e))}
def replay(target_path,metric_path=None):
 p=Path(target_path);t=load(p,TARGET_SHA);m=load(Path(metric_path) if metric_path else p.with_name('selected-metrics.json'),METRIC_SHA)
 require(t['kind']=='anonymous_i04_target_replay' and m['kind']=='anonymous_i04_comparison_metrics','I04 public artifact kinds required')
 for d in (t,m):require(d['thresholds'] is None and d['acceptance'] is None and d['full_core_complete'] is False and d['workload']['independent_parent_inputs']==1 and d['workload']['target_distribution_pairs']==18 and d['array_evidence']['public_target_replay_arrays_read']==0,'measured partial scope differs')
 for k in ('model','source_pins','workload','pair_scope','array_evidence','target_pairs'):require(t[k]==m[k],'public artifacts disagree: '+k)
 require(m['target_replay_artifact']=={'file':'selected-targets.json','sha256':TARGET_SHA},'target artifact binding differs')
 require([(p['sides'],p['request'],p['kind']) for p in t['target_pairs']]==PAIRS,'exact18 cross-first pair inventory required')
 vectors={}
 for i,r in enumerate(t['runs']):
  values=r['target_logprobs_nat'];n=159 if r['request']=='A' else 95
  require(r['target_count']==len(values)==n and hashlib.sha256(canonical(values).encode()).hexdigest()==r['target_vector_sha256'],'anonymous vector identity differs')
  require({k:v for k,v in r.items() if k!='target_logprobs_nat'}==m['runs'][i],'run metadata differs');vectors[r['id']]=values
 require(len(vectors)==12 and len(m['runs'])==12,'12 distinct logical observations required')
 for i,p in enumerate(t['target_pairs']):
  a,b=p['sides'];n=159 if p['request']=='A' else 95;require(p['coverage']=={'expected':n,'paired':n},'per-request coverage differs')
  actual=calculate(vectors[a],vectors[b]);require(set(actual)==set(p['metrics']),'complete target scalar inventory required')
  for k,v in actual.items():
   old=p['metrics'][k]
   if type(v) in (int,str):require(type(old) is type(v) and old==v,'target discrete scalar differs')
   else:require(type(old) in (int,float) and math.isfinite(old) and math.isclose(v,old,rel_tol=0,abs_tol=1e-12),'target scalar differs')
  dist=m['distribution_pairs'][i];require(dist['sides']==[a,b] and dist['request']==p['request'] and dist['position_count']==len(dist['positions'])==47,'archived distribution scope differs')
 return {'status':'recorded_i04_target_metrics_replayed','target_pairs_checked':18,'request_target_counts':{'A':159,'B':95},'independent_parent_inputs':1,'derived_prefix_shape_stress_requests':1,'target_metric_verification_tolerance':1e-12,'verification_tolerance_is_model_acceptance_threshold':False,'native_executions_started':0,'arrays_read':0,'archived_distribution_metrics_replayed':False,'thresholds':None,'acceptance':None,'full_core_complete':False}
if __name__=='__main__':
 if len(sys.argv) not in (2,3):raise SystemExit('usage: python -S -B replay-targets.py selected-targets.json [selected-metrics.json]')
 try:result=replay(sys.argv[1],sys.argv[2] if len(sys.argv)==3 else None)
 except (OSError,ValueError,KeyError,TypeError,IndexError) as exc:print(json.dumps({'status':'rejected','reason':str(exc),'acceptance':None}));raise SystemExit(2)
 print(json.dumps(result,indent=2,allow_nan=False))
'''
    return source.replace('__TARGET_SHA__',repr(target_sha)).replace('__METRIC_SHA__',repr(metric_sha)).replace('__PAIRS__',repr(pair_list)).encode()


def validated_coverage(ref):
    raw=frozen(ref);doc=parse(raw)
    baseline_path=Path(__file__).resolve().parents[5]/'site/evidence/gemma4-h100-ascend-partitions-20261107/coverage.json'
    baseline_raw=baseline_path.read_bytes();require(sha(baseline_raw)==BASELINE_COVERAGE_SHA,'original49-task public plan baseline changed')
    baseline=parse(baseline_raw)
    require(doc.get('schema_version')==1 and doc.get('task_count')==49 and doc.get('core_task_count')==28 and doc.get('full_core_complete') is False and
        doc.get('original_49_task_scope_complete') is False and doc.get('thresholds',False) is None and doc.get('acceptance',False) is None and
        len(doc.get('tasks',[]))==49 and len({x['task_id'] for x in doc['tasks']})==49,'reviewed complete49-task partial-coverage allowlist required')
    require(doc.get('source_plan_sha256')==baseline['source_plan_sha256'] and doc.get('model')==baseline['model'] and
        [{k:x[k] for k in ('task_id','profile','expected_coverage')} for x in doc['tasks']]==
        [{k:x[k] for k in ('task_id','profile','expected_coverage')} for x in baseline['tasks']],
        'original49 task IDs/profiles/procedure/plan identities must remain unchanged')
    require(all(x.get('full_plan_task_complete') is False for x in doc['tasks']),'pilot evidence must not complete a full plan task')
    require(doc['counts']==dict(Counter(x['status'] for x in doc['tasks'])),'coverage counts disagree with task statuses');privacy(doc)
    return doc


def public_documents(main,e02,coverage):
    runs,target_pairs,dist=collect_targets(main);independent=independent_summary(e02,main);cost=accounting(main,e02)
    independent_sha=sha(encoded(independent));pins={'input_sha256s':INPUTS,'metadata_source_map_sha256':main.map_sha,'main_metadata_envelope_sha256':main.envelope_sha,
        'main_metadata_archive_sha256':main.archive.ref['sha256'],'controller_sha256':main.mapping['controller']['sha256'],
        'comparison_report_sha256':main.controller['report']['sha256'],'comparison_spec_sha256':main.controller['comparison_spec']['sha256'],
        'stage_spec_sha256':STAGE_SHA,'expected_inventory_sha256':EXPECTED_SHA,'cpu_prerequisite_sha256':CPU_SHA,'i03_prerequisite_sha256':I03_SHA,
        'analysis_sha256':SOURCES['main'][1],'artifact_admission_sha256':SOURCES['helper'][1],
        'controller_source_sha256':SOURCES['controller'][1],'tool_manifest_sha256':TOOL_SHA,'source_maps_sha256':main.report['source_map_sha256'],
        'E02_envelope_sha256':e02.envelope_sha,'E02_controller_sha256':e02.controller_sha,'E02_report_sha256':e02.controller['report']['sha256']}
    workload={'independent_parent_inputs':1,'parent_input_scope':'one frozen English discovery article','derived_prefix_shape_stress_requests':1,
        'requests':{r:{'sequence_length':LENGTHS[r],'prompt_length':PROMPTS[r],'continuation_length':32,'target_count':LENGTHS[r]-1,
            'distribution_predictor_positions':positions(r),'distribution_rows_per_observation':47} for r in LENGTHS},
        'new_model_processes_per_backend':1,'model_loads_per_backend':1,'native_calls_per_backend':4,'logical_observations_per_backend':6,
        'native_modes_per_backend':4,'use_cache':False,'vocabulary_size':262144,'target_scores_rederived':1524,'full_vocabulary_rows_rederived':564,
        'raw_physical_rows_retained':1792,'valid_raw_rows_finite_checked':1536,'pad_only_rows_separately_counted':256,
        'target_distribution_pairs':18,'fresh_process_repeatability_measured':False,'batch_padding_repeatability_measured':False,'cache_eviction_tested':False,
        'validity_from_lengths_only':True,'valid_token_ID0_preserved':True,'pad_only_payload_retained_losslessly':True}
    array={'native_admission_full_array_files_checked':572,'native_admission_raw_logits_files':8,'native_admission_full_vocabulary_rows_rederived':564,
        'downloaded_main_and_E02_metadata_array_files':0,'metadata_export_array_stat_open_copy_count':0,'separate_full_GPU_transport_contains_arrays':286,
        'NPU_native_arrays_acquired_by_these_metadata_exports':0,'public_target_replay_arrays_read':0,'public_target_replay_recomputes_distribution_metrics':False,
        'independent_e02_scalar_math_recheck_completed':True,'independent_e02_summary_ref':{'file':'independent-checks.json','sha256':independent_sha}}
    common={'schema_version':1,'status':'scoped_measured_batch_padding_comparison','model':MODEL,'source_pins':pins,'workload':workload,
        'pair_scope':{'matched_cross_backend_pairs':6,'within_backend_request_condition_pairs':12,'total_target_distribution_pairs':18,'native_final_KV_pairs':0},
        'coordinate_convention':{'target_index_zero_based':'Original logical scored label position minus1,0..158 for A or0..94 for B; token IDs/input text are omitted.',
            'prediction_index_zero_based':'Logical predictor position, independent of native batch slot and padding offset.',
            'sampled_position_index_zero_based':'Ordinal0..46 among the request-specific47 selected predictor rows.'},
        'array_evidence':array,'target_pairs':target_pairs,'thresholds':None,'acceptance':None,'full_core_complete':False}
    targets={**common,'kind':'anonymous_i04_target_replay','runs':runs}
    metrics={**common,'kind':'anonymous_i04_comparison_metrics','target_replay_artifact':{'file':'selected-targets.json','sha256':sha(encoded(targets))},
        'runs':[{k:v for k,v in r.items() if k!='target_logprobs_nat'} for r in runs],
        'distribution_metric_policy':{'probability_rmse':'RMSE over exact union of each side top100 token IDs; complement excluded.',
            'max_probability_error':'Maximum absolute probability error over that union.',
            'tail_merged_js':'JS over the union categories plus one exact full-vocabulary-complement mass category.',
            'normalization':'No renormalization; original complete FP64 row probability masses and top100/union coverage retained.'},
        'distribution_pairs':dist,'native_final_KV_pairs':[],
        'raw_derivation':copy.deepcopy(main.report['raw_derivation']),
        'limitations':['One discovery parent plus its derived96-token prefix; not two independent representative quality examples.',
            'Six logical conditions per backend share one loaded process/model. No batch-condition or fresh-process repeats, cache, scheduler or eviction measurement.',
            'Pad-only BF16 values are retained/count separately; finite checks apply to valid rows only. The final valid unscored predictors159/95 are retained.',
            'All18 contrasts stay per request and pair. NLL and percentiles are not pooled across159/95 unequal target counts.',
            'Backend hardware/software/math policies differ. Operator cause remains unresolved; no speed, billing, P01 or model-acceptance conclusion.',
            'Public replay recomputes target scalars only, with0 native-array reads. Distribution scalars and source-side E02 checks are archived.']}
    # raw_derivation contains only fixed mode/request IDs, digests and numeric counts/deltas.
    for document in (targets,metrics,independent,cost,coverage):privacy(document)
    replay=replay_source(sha(encoded(targets)),sha(encoded(metrics)),[(p['sides'],p['request'],p['kind']) for p in target_pairs])
    lines=['# Gemma-4-12B H100–Ascend batch and padding comparison','',
        'This measured I04 stage uses one frozen English discovery parent and its96-token prefix as shape stress. A has160 tokens/159 targets; B has96 tokens/95 targets. Each backend loads one model and performs four cache-off native calls, producing six logical observations. Parameters and retained native logits are BF16; exported log probabilities are FP64.','',
        'The independent admission checked all572 native files,1536 valid predictor rows and564 complete vocabulary rows. All1792 physical predictor rows are retained;256 pad-only rows are counted separately and never normalized or paired. Finite-value assertions apply to valid rows.','',
        'The18 request-preserving contrasts contain six matched GPU/NPU pairs and twelve within-backend controls. Their full scalar results and846 distribution-row contrasts are archived without pooling unequal target counts. Top100-union probability errors and exact-complement-merged JS retain their coarsened definitions.','']
    for p in target_pairs[:6]:
        v=p['metrics'];lines.append(f"- {p['id']}: {v['target_count']} targets; MAE {v['mae_nat']!r} nat, P99 {v['p99_nat']!r} nat, maximum {v['max_abs_nat']!r} nat at anonymous target index {v['max_target_index_zero_based']}.")
    lines+=['','Actual independent E02 replay matched all18 target reductions and'+str(e02.report['scope']['independent_distribution_pair_rows'])+' selected distribution contrasts, including all282 matched cross-backend rows and the deduplicated reported extrema. It freshly hashed all572 native files. This does not independently repeat all846 distribution contrasts or all valid native rows.','',
        'The public standalone replay opens only the two frozen JSON files and recomputes all18 target comparisons with the Python standard library:','',
        '```sh','python -S -B replay-targets.py selected-targets.json selected-metrics.json','```','',
        'Recorded model-child wall times include imports, model loading, instrumentation, capture and validation. They are a subset of execution accounting, with no speed ratio, synchronized latency/throughput, allocated-device lifetime or billing conclusion. P01 and the full core remain incomplete.','',
        'Thresholds and acceptance remain null. Backend/operator causes remain unresolved. Coverage refers to the exact measured stage; one discovery parent does not establish representative quality or multilingual coverage.','',
        'Artifacts: [targets](selected-targets.json), [metrics](selected-metrics.json), [independent checks](independent-checks.json), [execution accounting](execution-cost.json), [plan coverage](coverage.json), [replay](replay-targets.py).','']
    result={'selected-targets.json':encoded(targets),'selected-metrics.json':encoded(metrics),'replay-targets.py':replay,
        'independent-checks.json':encoded(independent),'execution-cost.json':encoded(cost),'coverage.json':encoded(coverage),'report.md':'\n'.join(lines).encode()}
    return result


def render(spec_path,spec_sha,output):
    raw=frozen({'path':str(spec_path),'sha256':spec_sha});spec=parse(raw)
    require(spec.get('schema_version')==1 and spec.get('kind')=='i04-public-render-inputs' and spec.get('actual_main_and_E02_verified') is True,
        'actual frozen main+E02 byte-proof specification required')
    main=MainBundle(spec['main_envelope']);e02=E02Bundle(spec['E02_envelope'],main);coverage=validated_coverage(spec['coverage'])
    documents=public_documents(main,e02,coverage)
    output=Path(output);private=Path(__file__).resolve().parent
    require(output.resolve().is_relative_to(private) and output.parent.is_dir() and not output.exists() and not output.is_symlink(),
        'exclusive private transfer output required; public/site/history writes prohibited')
    output.mkdir(mode=0o700)
    for name,body in documents.items():
        with (output/name).open('xb') as stream:stream.write(body)
    require(frozen({'path':str(spec_path),'sha256':spec_sha})==raw,'frozen publication input changed')
    receipt={'status':'actual_I04_private_publication_candidates_rendered','source_spec_sha256':spec_sha,'files':{n:{'sha256':sha(v),'size_bytes':len(v)} for n,v in documents.items()},
        'native_arrays_read':0,'native_executions_started':0,'public_files_written':0,'history_files_written':0,'acceptance':None}
    with output.with_name(output.name+'-render-receipt.json').open('x',encoding='utf-8') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
    return receipt


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--spec',type=Path,required=True);p.add_argument('--spec-sha256',required=True)
    p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args();print(json.dumps(render(a.spec,a.spec_sha256,a.output_dir),indent=2))


if __name__=='__main__':main()

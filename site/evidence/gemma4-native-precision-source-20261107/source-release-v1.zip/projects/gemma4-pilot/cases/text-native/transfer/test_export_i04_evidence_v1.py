"""Synthetic CPU protocol fixtures, never native-model evidence or admission."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i04_export_under_test', HERE / 'export_i04_evidence_v1.py')
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@unittest.skipUnless(os.name == 'posix', 'Original POSIX source-map keys')
class Evidence(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.root = self.base / 'new-i04-task'
        self.root.mkdir()
        self.claim = self.root / 'claims' / 'synthetic-CPU-fixture'
        self.claim.mkdir(parents=True)
        self.run = self.root / 'runs' / 'h100-i04-cacheoff-synthetic'
        self.artifacts = self.run / 'artifacts'
        self.artifacts.mkdir(parents=True)
        (self.root / 'exports').mkdir()
        self.entry = self.root / 'source' / 'entry.py'
        self.entry.parent.mkdir()
        self.entry.write_bytes(b'# Synthetic protocol fixture, not a model collector\n')
        self.input = self.root / 'source/input.json'
        self.input.write_text('{"synthetic_cpu_fixture":true}\n')
        self.input_b=self.root/'source/input-b.json';self.input_b.write_bytes(b'{"synthetic_prefix_stress_fixture":true}\n')
        for key,path in [('INPUT_SHA',self.input),('INPUT_B_SHA',self.input_b)]:
            patched=patch.object(tool,key,sha(path));patched.start();self.addCleanup(patched.stop)
        self.stage = self.root / 'source/stage.json'
        self.stage.write_text('{"status":"synthetic_cpu_fixture"}\n')
        self.expected = self.claim / 'expected-inventory.json'
        self.expected.write_text('{"scope":"synthetic transport protocol only"}\n')
        self.allocation = self.claim / 'allocation.json'
        self.allocation.write_text('{"synthetic":true,"no_real_allocation":true}\n')
        self.stage_patch = patch.object(tool, 'STAGE_SHA', sha(self.stage))
        self.expected_patch = patch.object(tool, 'EXPECTED_SHA', sha(self.expected))
        self.stage_patch.start(); self.expected_patch.start()
        self.proof = self.claim / 'prerequisite.json'
        self.proof.write_bytes(b'CPU synthetic prior proof bytes; no numerical admission')
        self.proof_patch = patch.object(tool, 'PROOF_SHA', sha(self.proof))
        self.proof_patch.start(); self.addCleanup(self.proof_patch.stop)
        self.cpu_proof=self.claim/'cpu-prerequisite.json';self.cpu_proof.write_bytes(b'CPU synthetic21doc proof; no actual test execution')
        cpu_patch=patch.object(tool,'CPU_PROOF_SHA',sha(self.cpu_proof));cpu_patch.start();self.addCleanup(cpu_patch.stop)
        self.addCleanup(self.stage_patch.stop); self.addCleanup(self.expected_patch.stop)
        # Simulate an original GPU /tmp package source which is gone after UI
        # stop. Export must use the already-hashed AFS copy under its old key.
        self.original_module = self.base / 'old-gpu-tmp/package/__init__.py'
        self.original_module.parent.mkdir(parents=True)
        self.original_module.write_bytes(b'# Original GPU temporary module, synthetic\n')
        self.frozen_module = self.claim / 'frozen-runtime/0000/__init__.py'
        self.frozen_module.parent.mkdir(parents=True)
        self.frozen_module.write_bytes(self.original_module.read_bytes())
        self.module_ref = {'path': str(self.original_module), 'sha256': sha(self.original_module),
                           'size_bytes': self.original_module.stat().st_size}
        self.runtime_map = self.claim / 'frozen-runtime-source-map.json'
        tool.put(self.runtime_map, {str(self.original_module): {'path': str(self.frozen_module),
            'sha256': sha(self.original_module), 'size_bytes': self.original_module.stat().st_size}})
        runtime = {'model_identity': {'modeling_source': self.module_ref},
                   'package_sources': {'synthetic_module': self.module_ref},
                   'sources': {'synthetic_entry': {'path': str(self.entry), 'sha256': sha(self.entry),
                                                  'size_bytes': self.entry.stat().st_size}},
                   'scope': 'Synthetic CPU transport fixture, no native values'}
        tool.put(self.artifacts / 'runtime.json', runtime)
        # Small placeholder bytes intentionally cannot pass independent raw
        # BF16/numeric admission. This test exercises provenance/transport only.
        for name in sorted(tool.LARGE_NAMES):
            (self.artifacts / name).parent.mkdir(parents=True, exist_ok=True)
            (self.artifacts / name).write_bytes(('synthetic fixture ' + name).encode())
        (self.artifacts/'modes/batch-left/events.json').write_bytes(b'{"synthetic":true}\n')
        for index in range(621-len([p for p in self.artifacts.rglob('*') if p.is_file()])):
            (self.artifacts/('synthetic-metadata-%03d.json'%index)).write_bytes(b'{"synthetic":true}\n')
        self.manifest = {'backend': 'gpu', 'stage_spec_sha256': tool.STAGE_SHA,
            'expected_inventory_sha256': tool.EXPECTED_SHA, 'i03_prerequisite_sha256': tool.PROOF_SHA, 'synthetic': True,
            'kind':'i04-capture-artifacts','input_sha256s':{'A':tool.INPUT_SHA,'B':tool.INPUT_B_SHA},
            'files': {p.relative_to(self.artifacts).as_posix(): {'sha256': sha(p), 'size_bytes': p.stat().st_size}
                      for p in self.artifacts.rglob('*') if p.is_file()}}
        tool.put(self.artifacts / 'artifacts-manifest.json', self.manifest)
        tool.put(self.artifacts / 'status.json', {'status': 'completed', 'synthetic': True,
            'artifacts_manifest_sha256': sha(self.artifacts / 'artifacts-manifest.json')})
        argv = ['synthetic-never-executed', '--input', str(self.input),'--input-b',str(self.input_b), '--allocation-receipt', str(self.allocation),
            '--stage-spec', str(self.stage), '--stage-spec-sha256', tool.STAGE_SHA,
            '--expected-inventory', str(self.expected), '--expected-inventory-sha256', tool.EXPECTED_SHA,
            '--i03-prerequisite', str(self.proof), '--i03-prerequisite-sha256', tool.PROOF_SHA,
            '--output', str(self.artifacts)]
        tool.put(self.run / 'command.json', {'status': 'completed', 'returncode': 0, 'argv': argv,
                                             'start': 'synthetic', 'timeout': 900})
        for name in ('stdout.bin', 'stderr.bin', 'execution.json'):
            (self.run / name).write_bytes(b'original generic fixture bytes\n')
        sources = {str(p): sha(p) for p in (self.entry, self.input,self.input_b, self.stage, self.expected,
                                            self.allocation, self.original_module, self.proof,self.cpu_proof)}
        self.outer = {'schema_version': 1, 'task': 'I04', 'backend': 'GPU', 'status': 'completed',
            'returncode': 0, 'timed_out': False, 'native_capture_count': 1, 'native_forward_calls_total': 4, 'model_loads': 1,
            'started_utc': 'synthetic', 'argv': argv, 'output_dir': str(self.artifacts),
            'collector_path': str(self.entry), 'collector_sha256': sha(self.entry),
            'input_path': str(self.input), 'input_sha256': sha(self.input),
            'input_b_path':str(self.input_b),'input_b_sha256':sha(self.input_b),
            'allocation_path': str(self.allocation), 'allocation_sha256': sha(self.allocation),
            'expected_inventory_source_path': str(self.expected), 'expected_inventory_source_sha256': tool.EXPECTED_SHA,
            'stage_spec_source_path': str(self.stage), 'stage_spec_source_sha256': tool.STAGE_SHA,
            'i03_prerequisite_source_path': str(self.proof), 'i03_prerequisite_source_sha256': tool.PROOF_SHA,
            'cpu_prerequisite_source_path':str(self.cpu_proof),'cpu_prerequisite_source_sha256':tool.CPU_PROOF_SHA,
            'generic_receipt': {'path': str(self.run / 'command.json'), 'sha256': sha(self.run / 'command.json')},
            'runtime_source_map_path': str(self.runtime_map), 'runtime_source_map_sha256': sha(self.runtime_map),
            'source_sha256': sources, 'dependency_paths': list(sources),
            'artifacts_manifest_sha256': sha(self.artifacts / 'artifacts-manifest.json'), 'synthetic': True}
        self.outer_path = self.claim / 'capture-receipt.json'
        self.original_module.unlink()
        tool.put(self.claim / 'claim.json',{'whole_attempt_seconds':3000,'entry_started_utc':'2026-11-07T00:00:00+00:00'})
        tool.put(self.claim / 'controller-receipt.json', {'task':'I04','status':'completed','returncode':0,'timed_out':False,'remaining_descendants':[],
            'wall_seconds':10.0,'finished_utc':'2026-11-07T00:00:10+00:00','metadata_export_reserved_seconds':960,'controller_work_seconds':2020})

    def invoke(self, name='export', retain=False):
        tool.put(self.outer_path, self.outer)
        output = self.root / 'exports' / name
        result = tool.export(self.outer_path, self.root, output, retain)
        return output, result

    def test_gpu_complete_copy_original_keys_and_raw_receipts(self):
        output, result = self.invoke()
        mapping = tool.read(output / 'source-map.json')
        self.assertEqual(mapping['full_array_hashes_checked'], 286)
        self.assertEqual(mapping['retained_array_count'], 0)
        self.assertTrue(all('path' in entry for entry in mapping['files'].values()))
        for original in (self.outer_path, self.run / 'command.json', self.runtime_map):
            entry = mapping['files'][str(original)]
            self.assertEqual((output / entry['path']).read_bytes(), original.read_bytes())
        entry = mapping['files'][str(self.original_module)]
        self.assertEqual((output / entry['path']).read_bytes(), self.frozen_module.read_bytes())
        self.assertEqual(result['archive_sha256'], sha(result['archive']))
        self.assertLessEqual(result['archive_bytes'], tool.MAX_TRANSPORT)
        self.assertEqual(result['logical_payload_bytes'],tool.tree_size(output))
        self.assertLessEqual(result['logical_payload_bytes'],tool.MAX_LOGICAL)
        with tarfile.open(result['archive']) as archive:
            members = archive.getmembers()
            self.assertTrue(all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members))
            self.assertEqual(len({m.name for m in members}), len(members))

    def test_npu_retains_exact286_but_rehashes_every_source(self):
        self.outer['backend'] = 'NPU'
        self.manifest['backend'] = 'npu'
        extra=self.artifacts/'driver-version-provenance.json';extra.write_bytes(b'{"synthetic_driver":true}\n')
        self.manifest['files'][extra.name]={'sha256':sha(extra),'size_bytes':extra.stat().st_size}
        (self.artifacts / 'artifacts-manifest.json').unlink()
        tool.put(self.artifacts / 'artifacts-manifest.json', self.manifest)
        status = tool.read(self.artifacts / 'status.json')
        status['artifacts_manifest_sha256'] = sha(self.artifacts / 'artifacts-manifest.json')
        (self.artifacts / 'status.json').unlink(); tool.put(self.artifacts / 'status.json', status)
        self.outer['artifacts_manifest_sha256'] = status['artifacts_manifest_sha256']
        command = tool.read(self.run / 'command.json'); command['timeout'] = 1200
        (self.run / 'command.json').unlink(); tool.put(self.run / 'command.json', command)
        self.outer['generic_receipt']['sha256'] = sha(self.run / 'command.json')
        output, result = self.invoke(retain=True)
        mapping = tool.read(output / 'source-map.json')
        retained = {path: ref for path, ref in mapping['files'].items() if ref.get('retained_at_source')}
        self.assertEqual(len(retained), 286)
        self.assertTrue(all('path' not in ref and ref['sha256'] == sha(path) for path, ref in retained.items()))
        self.assertEqual(result['retained_array_count'], 286)

    def test_gpu_cannot_retain_arrays(self):
        with self.assertRaisesRegex(ValueError, 'GPU arrays'):
            self.invoke(retain=True)

    def test_frozen_runtime_copy_tamper_rejected(self):
        self.frozen_module.write_bytes(b'changed')
        with self.assertRaises(ValueError):
            self.invoke()
        self.assertFalse(any(self.root.rglob('*.tar.gz')))

    def test_raw_artifact_and_generic_receipt_mutation_rejected(self):
        (self.artifacts / 'modes/alone-A/raw-native-logits.safetensors').write_bytes(b'changed')
        with self.assertRaises(ValueError):
            self.invoke()

    def test_declared_sha_cannot_be_forged(self):
        self.outer['source_sha256'][str(self.entry)] = 'a' * 64
        with self.assertRaises(ValueError):
            self.invoke()

    def test_python_source_keeps_one_mib_cap_separate_from_metadata(self):
        self.entry.write_bytes(b'#'+b'x'*(1024**2))
        with self.assertRaisesRegex(ValueError,'Python code/source evidence exceeds1MiB'):self.invoke()
        self.assertFalse(any(self.root.rglob('*.tar.gz')))

    def test_old_array_inventory_cannot_be_mixed_in(self):
        (self.artifacts / 'old-32-targets.npy').write_bytes(b'old unrelated fixture')
        with self.assertRaisesRegex(ValueError, 'inventory'):
            self.invoke()

    def test_literal_argv_binding_cannot_be_changed(self):
        self.outer['argv'] = list(self.outer['argv'])
        self.outer['argv'][self.outer['argv'].index('--output') + 1] = '/unrelated'
        with self.assertRaisesRegex(ValueError, 'argv'):
            self.invoke()

    def test_second_input_and_cpu_proof_identity_cannot_be_changed(self):
        for name in ('input_b_sha256','cpu_prerequisite_source_sha256'):
            with self.subTest(name=name):
                old=self.outer[name];self.outer[name]='a'*64
                with self.assertRaisesRegex(ValueError,'two-input/two-prerequisite'):self.invoke('bad-'+name)
                self.outer_path.unlink();self.outer[name]=old

    def test_raw_padding_bit_patterns_are_copied_opaquely(self):
        path=self.artifacts/'modes/batch-left/raw-native-logits.safetensors'
        # These transport-only bytes intentionally are not an admissible tensor.
        raw=b'opaque fixture\0'+bytes.fromhex('0000807fff7f008000000100')
        path.write_bytes(raw);self.manifest['files'][path.relative_to(self.artifacts).as_posix()]={'sha256':sha(path),'size_bytes':len(raw)}
        (self.artifacts/'artifacts-manifest.json').unlink();tool.put(self.artifacts/'artifacts-manifest.json',self.manifest)
        self.outer['artifacts_manifest_sha256']=sha(self.artifacts/'artifacts-manifest.json')
        status=tool.read(self.artifacts/'status.json');status['artifacts_manifest_sha256']=self.outer['artifacts_manifest_sha256']
        (self.artifacts/'status.json').unlink();tool.put(self.artifacts/'status.json',status)
        output,_=self.invoke();ref=tool.read(output/'source-map.json')['files'][str(path)]
        self.assertEqual((output/ref['path']).read_bytes(),raw)

    def test_output_symlink_to_new_in_task_location_is_rejected(self):
        link=self.root/'exports/link';link.symlink_to(self.root/'exports/target',target_is_directory=True)
        tool.put(self.outer_path,self.outer)
        with self.assertRaisesRegex(ValueError,'cannot be a symlink'):tool.export(self.outer_path,self.root,link)
        self.assertFalse((self.root/'exports/target').exists())

    def test_actual_compressed_size_gate_keeps_failure_without_transport(self):
        with patch.object(tool, 'MAX_TRANSPORT', 10), self.assertRaisesRegex(ValueError, 'transport cap'):
            self.invoke()
        failure = tool.read(self.root / 'exports/export-failure.json')
        self.assertFalse(failure['transport_allowed'])
        self.assertTrue((self.root / 'exports/export.tar.gz').is_file())
        self.assertTrue((self.artifacts / 'modes/alone-A/raw-native-logits.safetensors').is_file())

    def test_output_escape_and_symlink_are_rejected(self):
        tool.put(self.outer_path, self.outer)
        with self.assertRaises(ValueError):
            tool.export(self.outer_path, self.root, self.root / '..' / 'outside')
        link = self.root / 'source/linked.py'
        link.symlink_to(self.entry)
        with self.assertRaisesRegex(ValueError, 'symlink'):
            tool.export(self.outer_path, self.root, self.root / 'exports/export')


    def test_actual_logical_size_gate_before_archive(self):
        with patch.object(tool,'MAX_LOGICAL',1), self.assertRaisesRegex(ValueError,'logical transport cap'):
            self.invoke()
        self.assertFalse((self.root/'exports/export.tar.gz').exists())
        self.assertFalse(tool.read(self.root/'exports/export-failure.json')['transport_allowed'])

    def test_masking_utils_nested_ref_survives_original_removal(self):
        runtime=tool.read(self.artifacts/'runtime.json')
        runtime['implementation_sources']={'masking_utils':self.module_ref}
        (self.artifacts/'runtime.json').unlink();tool.put(self.artifacts/'runtime.json',runtime)
        self.manifest['files']['runtime.json']={'sha256':sha(self.artifacts/'runtime.json'),'size_bytes':(self.artifacts/'runtime.json').stat().st_size}
        (self.artifacts/'artifacts-manifest.json').unlink();tool.put(self.artifacts/'artifacts-manifest.json',self.manifest)
        self.outer['artifacts_manifest_sha256']=sha(self.artifacts/'artifacts-manifest.json')
        status=tool.read(self.artifacts/'status.json');status['artifacts_manifest_sha256']=self.outer['artifacts_manifest_sha256']
        (self.artifacts/'status.json').unlink();tool.put(self.artifacts/'status.json',status)
        output,_=self.invoke()
        entry=tool.read(output/'source-map.json')['files'][str(self.original_module)]
        self.assertEqual((output/entry['path']).read_bytes(),self.frozen_module.read_bytes())

    def test_terminal_controller_required(self):
        (self.claim/'controller-receipt.json').unlink()
        tool.put(self.claim/'controller-receipt.json',{'task':'I04','status':'completed','returncode':0,'timed_out':False,'remaining_descendants':[123]})
        with self.assertRaisesRegex(ValueError,'completed and cleaned'):self.invoke()

    def test_metadata_event_larger_than_old4mib_preserved(self):
        path=self.artifacts/'modes/batch-left/events.json';path.write_bytes(b'x'*(5*1024**2+1))
        self.manifest['files'][path.relative_to(self.artifacts).as_posix()]={'sha256':sha(path),'size_bytes':path.stat().st_size}
        (self.artifacts/'artifacts-manifest.json').unlink();tool.put(self.artifacts/'artifacts-manifest.json',self.manifest)
        self.outer['artifacts_manifest_sha256']=sha(self.artifacts/'artifacts-manifest.json')
        status=tool.read(self.artifacts/'status.json');status['artifacts_manifest_sha256']=self.outer['artifacts_manifest_sha256']
        (self.artifacts/'status.json').unlink();tool.put(self.artifacts/'status.json',status)
        output,_=self.invoke();entry=tool.read(output/'source-map.json')['files'][str(path)]
        self.assertEqual(entry['size'],5*1024**2+1)
        self.assertEqual(sha(output/entry['path']),sha(path))

    def test_duplicate_json_and_traversal_are_rejected(self):
        (self.claim/'controller-receipt.json').write_text('{"task":"I04","task":"I04"}')
        with self.assertRaisesRegex(ValueError,'duplicate'):self.invoke()
        for name in ('../escape','modes//full-r1/a','modes/full-r1/./a','/absolute'):
            with self.assertRaises(ValueError):tool.safe_relative(name)

class PureGuards(unittest.TestCase):
    def test_actual_duration_must_leave_full_export_envelope(self):
        claim={'whole_attempt_seconds':3000,'entry_started_utc':'2026-11-07T00:00:00+00:00'}
        controller={'metadata_export_reserved_seconds':960,'controller_work_seconds':2020,'wall_seconds':2040.0,
            'finished_utc':'2026-11-07T00:34:00+00:00'}
        self.assertEqual(tool.native_attempt_seconds('NPU',controller,claim),2040.0)
        self.assertEqual(tool.native_attempt_seconds('GPU',controller,claim),2040.0)
        for value in (2040.1,float('nan'),False):
            controller['wall_seconds']=value
            with self.subTest(value=value),self.assertRaisesRegex(ValueError,'insufficient960s'):tool.native_attempt_seconds('NPU',controller,claim)
        controller['finished_utc']='2026-11-07T00:34:01+00:00'
        with self.assertRaisesRegex(ValueError,'insufficient960s'):tool.native_attempt_seconds('GPU',controller,claim)
    def test_prescribed_unique_inventory_and_limits(self):
        self.assertEqual({key:len(value) for key,value in tool.POSITIONS.items()},{'A':47,'B':47})
        self.assertEqual(len(tool.LARGE_NAMES),286)
        self.assertEqual(sum(n.endswith('.safetensors') for n in tool.LARGE_NAMES),4)
        self.assertEqual((tool.MAX_LOGICAL,tool.MAX_TRANSPORT),(1207959552,1610612736))

    def test_canonical_relative_guard(self):
        self.assertEqual(tool.safe_relative('modes/batch-left/request-A/dist-p127.npy'),'modes/batch-left/request-A/dist-p127.npy')
        for name in ('../escape','/absolute','a//b','a/./b','a/../b','a\\b'):
            with self.assertRaises(ValueError):tool.safe_relative(name)

if __name__ == '__main__':
    unittest.main()

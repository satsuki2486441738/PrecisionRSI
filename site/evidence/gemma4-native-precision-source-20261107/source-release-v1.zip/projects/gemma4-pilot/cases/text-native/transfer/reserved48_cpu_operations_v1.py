"""Source-pinned, once-only reserved48 actual CPU prerequisite protocol.

Only the unchanged reviewed I04 CPUv3 child/subreaper/owned-process-group cleanup
functions are reused. This is not a scheduler allocation/native-model claim.
Production gates remain None. Probe90s, owned child120s, whole180s including a
20s cleanup reserve; no source UI, SSH, device query or model load occurs here.
"""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import signal
import sys
import tarfile
import time
import traceback

CASE = 'projects/gemma4-pilot/cases/text-native'
SELF = CASE + '/transfer/reserved48_cpu_operations_v1.py'
PROBE = CASE + '/transfer/reserved48_cpu_probe_v1.py'
HELPER = CASE + '/transfer/i04_cpu_stage_operations_v3.py'
COMMON = CASE + '/adapters/reserved48_common_v1.py'
EXPECTED = CASE + '/adapters/reserved48_expected_v1.py'
MANIFEST = CASE + '/inputs/reserved-articles-v1/reserved.json'
CONFIG = CASE + '/transfer/local-snapshot-20261106T054650Z/config.json'
FROZEN = {
 COMMON: 'bf1bd4176fd209fd6fabfbda22bd9fb246cfdf12e72d89d7ca77417ad8546e58',
 CASE + '/adapters/reserved48_native_v1.py': 'd7bc0e8115769d4fcbe2aecec6e6ee550517fa7a27e7afef6b8b3844e20fe3e2',
 EXPECTED: 'ad229e986bab26fb697ab58120d63b948123c3ad52a1a51383a09495e719c05e',
 CASE + '/adapters/test_reserved48_common_v1.py': 'd829d846e412cb5eccc1980fe3458d860ce7cae2bbe8f0212938239eea34cf68',
 CASE + '/adapters/test_reserved48_expected_v1.py': 'ede777ad404b068110771826c7ac81bbd9f4ce7a0db415366b2635bf076f24df',
 CASE + '/adapters/test_reserved48_native_v1.py': '4599130cd52557966f47afc5002de4d3a8844c1a2976f39ea85e7d2e7ffc485f',
 PROBE: '0fb33d04d85d492d7cf8863e598be082ac1743a6987eaac2a6dd2d4972cc541c',
 HELPER: '36973a846475161e3ab05ff65c75bd56a535bcaad2056f3e42e6fa498d4002a2',
 MANIFEST: '10f6b1a6976507e1af65706ddd4bb61d9276c43ae443b2a6852935e2967dca37',
 CONFIG: '14f38c5492ffc9cbcdf808647ca0c025bb5b9b4eb737526347134d500ace6098'}
SUBDIR = 'reserved48-english-20261107/cpu-prerequisite-v1'
ARCHIVE = 'reserved48-cpu-prerequisite-v1.tar.gz'
TOTAL, WORK, CLEANUP, CHILD, PROBE_SECONDS = 180, 160, 20, 120, 90
MAX_CODE, MAX_METADATA, MAX_SOURCE, MAX_ARCHIVE = 1024**2, 16 * 1024**2, 8 * 1024**2, 2 * 1024**2
MAX_PRODUCTS = 32 * 1024**2


def require(ok, message):
    if not ok: raise ValueError(message)


def utc(): return datetime.now(timezone.utc).isoformat()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate JSON key'); result[key] = value
        return result
    def bad(value): raise ValueError('nonfinite JSON token ' + value)
    return json.loads(Path(path).read_bytes(), object_pairs_hook=pairs, parse_constant=bad)


def put(path, doc):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(doc, stream, indent=2, allow_nan=False); stream.write('\n')


def ref(path):
    path = Path(path); require(path.is_file() and not path.is_symlink(), 'regular original file required')
    return {'path': str(path.resolve()), 'sha256': sha(path), 'size_bytes': path.stat().st_size}


def safe(name):
    require(isinstance(name, str) and name and str(PurePosixPath(name)) == name and not PurePosixPath(name).is_absolute() and
            '\\' not in name and all(part not in ('', '.', '..') for part in name.split('/')), 'canonical relative source member required')
    return PurePosixPath(name)


def guard(root, path):
    path = Path(path)
    require(path.is_absolute() and path.is_relative_to(root) and path.resolve().is_relative_to(root), 'owned CPU path escapes root')
    current = path
    while current != root:
        require(not current.is_symlink(), 'symlink in owned CPU path'); current = current.parent
    return path


def frozen_files(repo):
    """Derive exact70-file closure from already authenticated literals/data."""
    repo = Path(repo); files = dict(FROZEN)
    require(sha(repo / COMMON) == FROZEN[COMMON] and sha(repo / MANIFEST) == FROZEN[MANIFEST], 'common/48-input manifest bytes changed')
    tree = ast.parse((repo / COMMON).read_bytes())
    pins = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign) and
                any(isinstance(target, ast.Name) and target.id == 'OLD_PINS' for target in node.targets))
    require(type(pins) is dict and len(pins) == 12 and all(type(k) is str and type(v) is str for k, v in pins.items()),
            'reviewed unchanged helper closure differs')
    for name, digest in pins.items(): safe(name); require(name not in files, 'duplicate static source key'); files[name] = digest
    manifest = read(repo / MANIFEST); require(len(manifest['samples']) == 48, 'exact48-input manifest required')
    for item in manifest['samples']:
        name = item['file']; require(PurePosixPath(name).name == name and '\\' not in name and name.endswith('.json'), 'flat original input filename required')
        key = CASE + '/inputs/reserved-articles-v1/' + name; require(key not in files, 'duplicate input source'); files[key] = item['sha256']
    files[SELF] = sha(repo / SELF)
    require(len(files) == 71, 'exact reserved48 CPU source closure count differs')
    return files


def verify_tree(source, manifest, digest, check_executed=False, allow_cpu_runtime=False):
    source, manifest = Path(source), Path(manifest)
    require(source.is_dir() and not source.is_symlink() and ref(manifest)['sha256'] == digest, 'exact external CPU source manifest required')
    document = read(manifest); expected = frozen_files(source)
    require(document['kind'] == 'reserved48-actual-tiny-cpu-source-v1' and document['production_model_loads'] == 0 and
            document['native_executions_started'] == 0 and document['tests'] == 23 and set(document['files']) == set(expected),
            'exact source-only CPU bundle contract differs')
    actual = set()
    for path in source.rglob('*'):
        require(not path.is_symlink(), 'CPU source tree contains symlink')
        if path.is_file(): actual.add(path.relative_to(source).as_posix()); require(len(actual) <= len(expected), 'extra source files')
    require(actual == set(expected), 'CPU source tree complete inventory differs')
    for name, digest in expected.items():
        safe(name); path = source / name; item = ref(path)
        require(path.stat().st_nlink == 1 and item['sha256'] == digest and item['size_bytes'] <= (MAX_CODE if name.endswith('.py') else MAX_METADATA) and
                document['files'][name] == {'sha256': digest, 'size_bytes': item['size_bytes']}, 'frozen CPU source bytes differ: ' + name)
    if check_executed: require(Path(__file__).resolve() == (source / SELF).resolve(), 'CPU operations executed outside its staged closure')
    require(sha(__file__) == document['files'][SELF]['sha256'], 'executed operations bytes differ from bundle')
    if not allow_cpu_runtime:
        require(not any(name in sys.modules for name in ('torch', 'torch_npu', 'numpy', 'transformers')), 'source gate imported framework')
    return document


def independent_inventory(source):
    adapters = Path(source) / (CASE + '/adapters'); sys.path.insert(0, str(adapters))
    import reserved48_common_v1 as common
    import reserved48_expected_v1 as expected
    require(Path(common.__file__).resolve() == (Path(source) / COMMON).resolve() and
            Path(expected.__file__).resolve() == (Path(source) / EXPECTED).resolve(), 'inventory module resolved outside CPU source closure')
    require(all(value is None for value in common.GATES.values()) and expected.STAGE_SHA256 is None, 'CPU proof cannot activate native gates')
    input_dir = Path(source) / (CASE + '/inputs/reserved-articles-v1')
    document = expected.derive(input_dir / 'reserved.json', input_dir)
    common.check_expected(document, common.inventory(input_dir / 'reserved.json', input_dir), None)
    raw = (json.dumps(document, indent=2, allow_nan=False) + '\n').encode()
    require(len(raw) <= MAX_METADATA and document['native_executions_started'] == 0 and document['stage_spec_sha256'] is None,
            'pre-native independent inventory or metadata cap differs')
    return document, raw


def build(repo, output):
    repo = Path(repo).resolve(strict=True); output = Path(output)
    require(output.parent.is_dir() and not output.exists(), 'exclusive new CPU packet directory required')
    files, contents = frozen_files(repo), {}
    for name, digest in files.items():
        safe(name); path = repo / name; item = ref(path)
        require(item['sha256'] == digest and item['size_bytes'] <= (MAX_CODE if name.endswith('.py') else MAX_METADATA), 'CPU source size/hash differs')
        body = path.read_bytes()
        if name.endswith('.py'): ast.parse(body)
        contents[name] = body
    document = {'schema_version': 1, 'kind': 'reserved48-actual-tiny-cpu-source-v1', 'tests': 23,
        'production_model_loads': 0, 'native_executions_started': 0, 'whole_cpu_seconds': TOTAL,
        'work_seconds': WORK, 'cleanup_reserve_seconds': CLEANUP, 'probe_seconds': PROBE_SECONDS, 'child_seconds': CHILD,
        'files': {name: {'sha256': hashlib.sha256(body).hexdigest(), 'size_bytes': len(body)} for name, body in sorted(contents.items())}}
    raw = (json.dumps(document, indent=2, allow_nan=False) + '\n').encode()
    require(sum(map(len, contents.values())) + len(raw) <= MAX_SOURCE, 'finite CPU expanded source cap exceeded')
    output.mkdir(mode=0o700); archive = output / ARCHIVE
    with archive.open('xb') as stream, tarfile.open(fileobj=stream, mode='w:gz', format=tarfile.USTAR_FORMAT) as package:
        for name, body in [('source-manifest.json', raw), *[('source/' + name, body) for name, body in sorted(contents.items())]]:
            item = tarfile.TarInfo(name); item.size = len(body); item.mode = 0o600; package.addfile(item, io.BytesIO(body))
    require(archive.stat().st_size <= MAX_ARCHIVE, 'CPU archive exceeds2MiB')
    result = {'status': 'reserved48_cpu_source_packet_created', 'archive': ref(archive),
        'manifest_sha256': hashlib.sha256(raw).hexdigest(), 'source_files': len(files), 'regular_members': len(files) + 1,
        'production_model_loads': 0, 'native_executions_started': 0}
    put(output / 'packet-receipt.json', result); return result


def stage(root, archive, archive_sha, manifest_sha):
    root = Path(root); require(root.is_dir() and not root.is_symlink(), 'explicit original CPU root required'); root = root.resolve(strict=True)
    archive = guard(root, Path(archive)); target = guard(root, root / SUBDIR)
    require(archive.parent == root and archive.is_file() and archive.stat().st_size <= MAX_ARCHIVE and sha(archive) == archive_sha and
            not target.exists(), 'new exclusive uploaded CPU packet required')
    require(shutil.disk_usage(root).free >= 128 * 1024**2, 'CPU source stage free-space guard failed')
    contents = {}; size = 0
    with tarfile.open(archive, 'r:gz') as package:
        for item in package:
            safe(item.name); require(item.name not in contents and len(contents) < 128 and item.type == tarfile.REGTYPE and
                item.isfile() and not item.sparse and not item.pax_headers and 0 < item.size <= MAX_METADATA, 'bounded regular source member required')
            size += item.size; require(size <= MAX_SOURCE, 'CPU expanded source cap exceeded')
            contents[item.name] = package.extractfile(item).read()
    require('source-manifest.json' in contents and hashlib.sha256(contents['source-manifest.json']).hexdigest() == manifest_sha,
            'external CPU manifest SHA differs')
    document = json.loads(contents['source-manifest.json']); files = document['files']
    require(set(contents) == {'source-manifest.json'} | {'source/' + name for name in files}, 'CPU source archive member inventory differs')
    names = set(contents)
    for name, body in contents.items():
        require(all(str(parent) not in names for parent in PurePosixPath(name).parents if str(parent) != '.'), 'source file/ancestor collision')
        if name.startswith('source/'):
            key = name[len('source/'):]; require(files[key] == {'sha256': hashlib.sha256(body).hexdigest(), 'size_bytes': len(body)}, 'source member SHA differs')
            require(len(body) <= (MAX_CODE if key.endswith('.py') else MAX_METADATA), 'typed source size cap differs')
            if key.endswith('.py'): ast.parse(body)
    # Validate all static pins before any new stage-directory write.
    for name, digest in FROZEN.items(): require(files[name]['sha256'] == digest, 'reviewed source pin differs')
    require(files[SELF]['sha256'] == sha(__file__), 'stage operations bytes differ')
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True); target.mkdir(mode=0o700)
    for name, body in contents.items():
        path = target.joinpath(*safe(name).parts); path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with path.open('xb') as stream: stream.write(body)
    verify_tree(target / 'source', target / 'source-manifest.json', manifest_sha)
    result = {'status': 'reserved48_cpu_sources_staged_not_native', 'source_files': len(files), 'manifest_sha256': manifest_sha,
        'archive_sha256': archive_sha, 'source_root': str(target / 'source'), 'finished_utc': utc(),
        'production_model_loads': 0, 'native_executions_started': 0, 'native_claim_created': False}
    put(target / 'stage-receipt.json', result); return result


def load_cleanup(source):
    path = Path(source) / HELPER; require(sha(path) == FROZEN[HELPER], 'reviewed CPU cleanup source changed')
    spec = importlib.util.spec_from_file_location('_reserved48_scoped_cpu_child_only', path)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    return helper


def validate_probe(path, check_runtime_bytes=True):
    document = read(path)
    require(document.get('status') == 'completed' and document.get('returncode') == 0 and document.get('timeout_seconds') == 90 and
        document.get('source', {}).get('sha256') == FROZEN[PROBE] and document.get('operations_source', {}).get('sha256') == sha(__file__) and
        document.get('versions', {}).get('torch') == '2.9.0+cpu' and document.get('versions', {}).get('numpy') == '1.26.4', 'actual pinned CPU probe/version result differs')
    tests = document.get('tests', {}); require(tests.get('run') == 23 and tests.get('skipped') == tests.get('failures') == tests.get('errors') == 0 and
        tests.get('real_torch_BF16_fixture_enabled') is True, 'all23 actual tests including Torch must pass without skip')
    phases = document.get('phase_observations', [])
    require([item.get('phase') for item in phases] == ['after_torch', 'after_runtime_imports', 'before_tests', 'after_tests', 'after_tiny_roundtrip'] and
        all(type(item.get('torch_npu_imported')) is bool and type(item.get('npu_namespace_registered')) is bool and
            item.get('npu_initialized') is (False if item['npu_namespace_registered'] else None) and item.get('cuda_initialized') is False for item in phases),
        'observed CPU import/context phases differ or accelerator initialized')
    require(all(type(document.get(name)) is int and document[name] == 0 for name in ('production_model_loads', 'native_model_forward_calls',
        'agent_accelerator_initialization_requests', 'agent_hardware_or_availability_queries')) and
        document.get('library_internal_availability_queries') == 'not instrumented' and document.get('device_initialization_checks') == 'getter_only' and
        document.get('production_activation_gates') == 'all None', 'CPU-only query/model/production gate scope differs')
    result = document.get('actual_tiny_roundtrip', {})
    require(result.get('checks_passed') == 8 and len(set(result.get('checks', []))) == 8 and result.get('native_rows') == 65 and
        result.get('target_scores') == 64 and result.get('selected_rows') == 4 and result.get('vocabulary') == 7 and
        result.get('native_model_loads') == result.get('native_model_forward_calls') == 0, 'actual tiny65-row/32-slab/BF16 checks differ')
    require(set(document.get('runtime_sources', {})) == {'torch', 'numpy', 'safetensors', 'safetensors_torch', 'torch_tensor',
        'inference_capture', 'artifact_io', 'conditions'}, 'CPU runtime source inventory differs')
    if check_runtime_bytes:
        for item in document['runtime_sources'].values(): require(ref(item['path']) == item and item['size_bytes'] <= 4 * 1024**2, 'actual CPU runtime source bytes changed')
        for item in (result['artifact'], tests['transcript']):
            require(Path(item['path']).resolve().is_relative_to(Path(path).parent.resolve()) and ref(item['path']) == item and
                item['size_bytes'] <= 128 * 1024, 'tiny original CPU artifact/test transcript changed')
    return document


def run_attempt(root, manifest_sha, started):
    root = Path(root)
    require(os.name == 'posix' and root.is_dir() and not root.is_symlink(), 'POSIX original CPU root required'); root = root.resolve(strict=True)
    target = guard(root, root / SUBDIR); source = target / 'source'; manifest = target / 'source-manifest.json'
    verify_tree(source, manifest, manifest_sha, True); _, inventory_bytes = independent_inventory(source)
    require(shutil.disk_usage(target).free >= 128 * 1024**2 and time.monotonic() - started + CHILD < WORK,
            'insufficient finite CPU preparation envelope/free-space')
    put(target / 'cpu-attempt-once.json', {'claimed_utc': utc(), 'kind': 'CPU-only marker, not allocation/model/native claim',
        'manifest_sha256': manifest_sha, 'independent_inventory_sha256': hashlib.sha256(inventory_bytes).hexdigest(),
        'automatic_retry': False, 'native_claim_created': False, 'production_model_loads': 0})
    runs = target / 'runs'; runs.mkdir(mode=0o700)
    folder = runs / ('compare-reserved48-actual-cpu-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')); folder.mkdir(mode=0o700)
    state = {'schema_version': 1, 'task': 'reserved48-cpu-validation-v1', 'status': 'running', 'started_utc': utc(),
        'source_manifest_sha256': manifest_sha, 'source_root': str(source), 'whole_cpu_seconds': TOTAL, 'cleanup_reserve_seconds': CLEANUP,
        'child_seconds': CHILD, 'probe_seconds': PROBE_SECONDS, 'automatic_retry': False, 'production_model_loads': 0,
        'native_claim_created': False, 'native_executions_started': 0, 'steps': [], 'acceptance': None}
    put(folder / 'controller-start.json', state)
    inventory_path = folder / 'independent-inventory.json'
    with inventory_path.open('xb') as stream: stream.write(inventory_bytes)
    helper = load_cleanup(source)
    try:
        step = helper.child([sys.executable, '-B', str(source / PROBE), '--source-root', str(source),
            '--operations-sha256', sha(__file__), '--manifest-sha256', manifest_sha,
            '--expected-inventory', str(inventory_path), '--expected-inventory-sha256', sha(inventory_path),
            '--output', str(folder / 'probe')], source / (CASE + '/transfer'), CHILD, folder / 'probe.stdout', folder / 'probe.stderr')
        state['steps'].append(step)
        require(step['returncode'] == 0 and step['timed_out'] is False and step['cleanup']['remaining_owned_process_group'] is False,
                'actual CPU probe failed/timed out or left owned process group')
        document = validate_probe(folder / 'probe/receipt.json'); summary = read(folder / 'probe.stdout')
        require(summary['status'] == 'completed' and summary['returncode'] == 0 and summary['receipt'] == ref(folder / 'probe/receipt.json') and
                summary['tests_run'] == 23 and summary['skips'] == 0, 'actual CPU probe stdout/receipt differs')
        require(document['independent_inventory'] == ref(inventory_path) and document['source_manifest_sha256'] == manifest_sha and
            document['source']['path'] == str((source / PROBE).resolve()) and document['operations_source']['path'] == str((source / SELF).resolve()),
            'actual CPU probe source/inventory/controller binding differs')
        frozen = folder / 'runtime-sources'; frozen.mkdir(); catalog = {}; total = 0
        for name, item in document['runtime_sources'].items():
            body = Path(item['path']).read_bytes(); total += len(body); require(total <= 16 * 1024**2, 'CPU runtime source copy cap exceeded')
            copy = frozen / (name + '.py')
            with copy.open('xb') as stream: stream.write(body)
            require(sha(copy) == item['sha256'] and ref(item['path']) == item, 'actual CPU runtime copied bytes differ')
            catalog[name] = {'source': item, 'copy': ref(copy)}
        put(folder / 'runtime-source-map.json', catalog); verify_tree(source, manifest, manifest_sha, True)
        product_bytes = sum(path.stat().st_size for path in folder.rglob('*') if path.is_file())
        require(product_bytes <= MAX_PRODUCTS and time.monotonic() - started < WORK, 'CPU products/work exhausted cleanup reserve')
        state.update(status='completed', returncode=0, actual_tests=23, test_skips=0, actual_tiny_checks=8,
            independent_inventory=ref(inventory_path), probe=ref(folder / 'probe/receipt.json'), runtime_source_map=ref(folder / 'runtime-source-map.json'),
            remaining_owned_process_groups=[], product_bytes_before_terminal_receipt=product_bytes,
            scope='Actual tiny CPU Torch API and full23 regressions only; no production model/native backend/quality/performance execution')
    except BaseException as exc:
        state.update(status='failed', returncode=2, error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc(), partial_files_preserved=True)
    finally:
        state.update(finished_utc=utc(), elapsed_seconds=time.monotonic() - started); put(folder / 'controller-receipt.json', state)
    print(json.dumps({'status': state['status'], 'returncode': state['returncode'], 'receipt': ref(folder / 'controller-receipt.json'),
        'actual_tests': state.get('actual_tests'), 'actual_tiny_checks': state.get('actual_tiny_checks'), 'error': state.get('error')}, indent=2), flush=True)
    return state['returncode']


def run(root, manifest_sha):
    require(os.name == 'posix' and hasattr(signal, 'SIGALRM'), 'bounded POSIX CPU protocol required')
    started = time.monotonic()
    def expired(*_): raise KeyboardInterrupt('reserved48 CPU work160s deadline/signal;20s cleanup reserve')
    previous = {sig: signal.signal(sig, expired) for sig in (signal.SIGALRM, signal.SIGTERM, signal.SIGINT, signal.SIGHUP)}
    signal.setitimer(signal.ITIMER_REAL, WORK)
    try: return run_attempt(root, manifest_sha, started)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        for sig, handler in previous.items(): signal.signal(sig, handler)


def main():
    p = argparse.ArgumentParser(description=__doc__); subs = p.add_subparsers(dest='mode', required=True)
    b = subs.add_parser('build'); b.add_argument('--repo', type=Path, required=True); b.add_argument('--output', type=Path, required=True)
    s = subs.add_parser('stage')
    for name in ('root', 'archive'): s.add_argument('--' + name, type=Path, required=True)
    for name in ('archive-sha256', 'manifest-sha256'): s.add_argument('--' + name, required=True)
    r = subs.add_parser('run'); r.add_argument('--root', type=Path, required=True); r.add_argument('--manifest-sha256', required=True)
    args = p.parse_args()
    if args.mode == 'build': print(json.dumps(build(args.repo, args.output), indent=2))
    elif args.mode == 'stage': print(json.dumps(stage(args.root, args.archive, args.archive_sha256, args.manifest_sha256), indent=2))
    else: return run(args.root, args.manifest_sha256)
    return 0


if __name__ == '__main__': raise SystemExit(main())

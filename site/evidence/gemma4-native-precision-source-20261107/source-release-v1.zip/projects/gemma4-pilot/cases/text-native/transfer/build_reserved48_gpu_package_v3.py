"""Render reviewed four-bin GPU candidates and rehearse pure preconditions.

This tool never allocates, probes a device, restores an environment or starts
a native model. Derived v3 sources are isolated artifacts; historical v1/v2
bytes and actual111-ref prerequisite bytes are preserved. Root owns deployment
and later publication of authenticated fresh allocation metadata.
"""
import argparse
import ast
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import time
from types import SimpleNamespace
sys.dont_write_bytecode=True

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]
CASE = 'projects/gemma4-pilot/cases/text-native'
AFS = '/srv/precision-task'
GPU_BASE = AFS+'/reserved48-i05-q01-20261107/gpu'
PROOF_SHA = '7acedd06be98e639efb308fbaca4caafb27cc17ad6cb14022e3932c6283020e8'
PROOF_REL = CASE+'/runs/compare-reserved48-native-prerequisite-prepared-20261106T231753Z/prerequisite/prerequisite.json'
TEMPLATES = {
    CASE+'/transfer/reserved48_stage_contract_v2.py': '924fc9dda795fe66c0ffc047a3b158289b2baac50a91c220f9991d899390ddc5',
    CASE+'/transfer/reserved48_gpu_lifecycle_v2.py': '7b273d985428dcc809e4569b9e6b42a752ef6458b7a91c05291db91bfc684291',
    CASE+'/transfer/reserved48_npu_lifecycle_v2.py': '4fdf7d0d767c3d38520a6eec1abce87d4ce97496514190ec89687dee4c2976b5',
    CASE+'/adapters/reserved48_common_v2.py': '410e21fd02d4e3defe95d96afd330e2184f4db498250e04bece55922e1739af4',
    CASE+'/adapters/reserved48_native_v2.py': '221000a07f79affec2486e558f4d2ce0e6ef72eb2f3398acd8f4e93f6bf06527',
    CASE+'/adapters/reserved48_expected_v2.py': 'ed3b47c61785a4f31869950ebea74e553072a170fd32f824468c76700107babb'}
IO = CASE+'/transfer/h100_i01_lifecycle_v1.py'
RESTORE = CASE+'/transfer/launch_h100_torch290_repeat_v1.py'
IO_SHA = '34b00c57a2fb08e3ded9332a1e4dae760791d9a9b261983dd3809909d58caafc'
RESTORE_SHA = '5b8aecafd569999aebe5c369edacd9f054980bee3f75748a85189cae7690a06e'
OLD_EXPECTED_SHA = 'ad229e986bab26fb697ab58120d63b948123c3ad52a1a51383a09495e719c05e'
MODELS = AFS+'/model-download/snapshot'
ENVIRONMENT = {'path': AFS+'/environment-py31213-torch290cu128-20261106.tar',
    'sha256': 'e29d65534fb7d5ef38e5a71a08dc149f4cb7f3252e44835520c6ce357100d574'}
BINS = (128,512,2048,8192)
FSYNC_WORK_SECONDS,FSYNC_WHOLE_SECONDS=35,45
HEX = re.compile(r'^[a-f0-9]{64}$')
RENAMES = {name: name.replace('_v2', '_v3') for name in
    ('reserved48_stage_contract_v2','reserved48_gpu_lifecycle_v2','reserved48_npu_lifecycle_v2',
     'reserved48_common_v2','reserved48_native_v2','reserved48_expected_v2')}


def require(ok, message):
    if not ok: raise ValueError(message)


def digest(raw): return hashlib.sha256(raw).hexdigest()
def sha(path): return digest(Path(path).read_bytes())
def encoded(doc): return (json.dumps(doc,indent=2,allow_nan=False)+'\n').encode()
def read(path):
    def pairs(items):
        d={}
        for key,value in items: require(key not in d,'duplicate JSON key');d[key]=value
        return d
    return json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,
        parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def write(path,raw):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(raw)
def put(path,doc):write(path,encoded(doc))
def relative(name):
    p=PurePosixPath(name)
    require(isinstance(name,str) and name and str(p)==name and not p.is_absolute() and '\\' not in name and ':' not in name
        and all(x not in ('','.','..') for x in name.split('/')),'canonical package relative path required')
    return p
def ref(path):
    path=Path(path);require(path.is_file() and not path.is_symlink() and path.stat().st_size<=16*1024**2,'bounded metadata/code source required')
    return {'path':str(path.resolve()),'sha256':sha(path),'size_bytes':path.stat().st_size}
def remote_ref(root,name,raw):return {'path':str(PurePosixPath(root)/relative(name)),'sha256':digest(raw),'size_bytes':len(raw)}
def local_absolute(path):
    path=Path(path).absolute()
    # Only local filesystem access gets the Windows extended-length prefix.
    # Remote deployment identities always use PurePosixPath separately.
    if os.name=='nt' and not str(path).startswith('\\\\?\\'):path=Path('\\\\?\\'+str(path))
    return path
def pure(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    require(not any(x in sys.modules for x in ('torch','torch_npu','numpy','transformers')),'preparation imported framework')
    return m


def replace_assignment(raw,name,value):
    tree=ast.parse(raw);nodes=[n.value for n in tree.body if isinstance(n,ast.Assign) and
        any(isinstance(t,ast.Name) and t.id==name for t in n.targets)]
    require(len(nodes)==1,'unique reviewed literal assignment required: '+name);node=nodes[0]
    lines=raw.splitlines(keepends=True);start=sum(map(len,lines[:node.lineno-1]))+node.col_offset
    end=sum(map(len,lines[:node.end_lineno-1]))+node.end_col_offset
    return raw[:start]+repr(value).encode()+raw[end:]


def parallelism_literal(raw,value):
    tree=ast.parse(raw);fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='proposed_stage')
    returned=next(n.value for n in fn.body if isinstance(n,ast.Return));require(isinstance(returned,ast.Dict),'literal stage dictionary required')
    nodes=[v for k,v in zip(returned.keys,returned.values) if isinstance(k,ast.Constant) and k.value=='H100_parallelism_selected']
    require(len(nodes)==1,'one selected GPU parallelism metadata literal required');node=nodes[0];lines=raw.splitlines(keepends=True)
    start=sum(map(len,lines[:node.lineno-1]))+node.col_offset;end=sum(map(len,lines[:node.end_lineno-1]))+node.end_col_offset
    return raw[:start]+repr(value).encode()+raw[end:]


def path_bridge(raw):
    for old,new in RENAMES.items():raw=raw.replace(old.encode(),new.encode())
    return raw


def lineage(original,derived,assignments=(),parallel=False):
    restored=derived
    for old,new in RENAMES.items():restored=restored.replace(new.encode(),old.encode())
    old_tree=ast.parse(original)
    for name in assignments:
        node=next(n for n in old_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
        # Restore original AST expression, including dict.fromkeys(None) gates.
        try:value=ast.literal_eval(node.value);restored=replace_assignment(restored,name,value)
        except (ValueError,TypeError):
            current=ast.parse(restored);target=next(n for n in current.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
            lines=restored.splitlines(keepends=True);a=target.value;b=node.value
            start=sum(map(len,lines[:a.lineno-1]))+a.col_offset;end=sum(map(len,lines[:a.end_lineno-1]))+a.end_col_offset
            source_lines=original.splitlines(keepends=True);x=sum(map(len,source_lines[:b.lineno-1]))+b.col_offset;y=sum(map(len,source_lines[:b.end_lineno-1]))+b.end_col_offset
            restored=restored[:start]+original[x:y]+restored[end:]
    if parallel:restored=parallelism_literal(restored,None)
    require(ast.dump(ast.parse(restored))==ast.dump(old_tree),'unreviewed functional AST change in derived v3 source')
    return {'original_sha256':digest(original),'derived_sha256':digest(derived),'allowed_assignments':list(assignments),
        'owned_v2_to_v3_path_bridges_only':True,'selected_GPU_parallelism_literal_changed':parallel,'functional_AST_unchanged_after_normalization':True}


def static_assets(repo,common,io_module):
    pins={**common.OLD_PINS,**io_module.BASE_PINS,IO:IO_SHA,RESTORE:RESTORE_SHA,
        CASE+'/adapters/reserved48_expected_v1.py':OLD_EXPECTED_SHA,
        'skills/precision-compare/scripts/record_run.py':'2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'}
    # This old helper imports artifact_io/NumPy at module load. Read its frozen
    # literal source map with AST instead of executing any numerical imports.
    parent=repo/(CASE+'/adapters/i01_common_v1.py')
    require(sha(parent)==common.OLD_PINS[CASE+'/adapters/i01_common_v1.py'],'old parent source differs')
    maps=[ast.literal_eval(n.value) for n in ast.parse(parent.read_bytes()).body if isinstance(n,ast.Assign)
        and any(isinstance(t,ast.Name) and t.id=='PINNED' for t in n.targets)]
    require(len(maps)==1 and len(maps[0])==9,'one frozen9-source loader map required');pins.update(maps[0]);assets={}
    for name,pin in pins.items():
        relative(name);path=repo/name;value=ref(path);require(value['sha256']==pin,'immutable helper/source changed: '+name);assets[name]=path.read_bytes()
    return assets


def source_manifest(assets):
    require(len(assets)<=512 and sum(map(len,assets.values()))<=512*1024**2,'bounded512-file/source512MiB closure required')
    inventory={name:{'sha256':digest(raw),'size_bytes':len(raw),'kind':'code' if name.endswith('.py') else 'metadata'} for name,raw in sorted(assets.items())}
    return {'schema_version':1,'task':'gemma4-reserved48-i05-q01-v1','files':{k:v['sha256'] for k,v in inventory.items()},'inventory':inventory}


def shell(root,config_sha,lifecycle_sha):
    path=str(PurePosixPath(root)/'source'/CASE/'transfer/reserved48_gpu_lifecycle_v3.py')
    code='import hashlib,os,pathlib,sys;p=pathlib.Path(sys.argv[1]);assert p.is_absolute() and p.is_file() and not p.is_symlink();assert hashlib.sha256(p.read_bytes()).hexdigest()==sys.argv[2];os.execv(sys.executable,[sys.executable,"-S","-B",str(p),"--config",sys.argv[3],"--config-sha256",sys.argv[4],"--prompt-bin",sys.argv[5]])'
    require("'" not in code and '\\' not in root and root.startswith(AFS+'/'),'literal POSIX startup only')
    P=PurePosixPath(root).name[1:5]
    return ('#!/bin/bash\nset -eu\nunset PYTHONHOME PYTHONPATH\nexport PYTHONHASHSEED=0 PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 TORCH_DEVICE_BACKEND_AUTOLOAD=0\n'
        "exec python3 -I -S -B -c '"+code+"' '"+path+"' '"+lifecycle_sha+"' '"+root+"/prepared-config.json' '"+config_sha+"' '"+str(int(P))+"'\n").encode()


def build(output,repo=REPO,rehearse=True):
    started=time.monotonic();repo=Path(repo).resolve();output=local_absolute(output)
    require(output.parent.is_dir() and not output.exists() and not output.is_symlink(),'exclusive new package output required')
    templates={name:(repo/name).read_bytes() for name in TEMPLATES}
    require(all(digest(templates[k])==v for k,v in TEMPLATES.items()),'reviewed v2 template bytes differ')
    template=pure(repo/(CASE+'/transfer/reserved48_stage_contract_v2.py'),'_reserved48_package_contract_v2')
    common=pure(repo/(CASE+'/adapters/reserved48_common_v2.py'),'_reserved48_package_common_v2')
    io_module=pure(repo/IO,'_reserved48_package_GPU_IO')
    require(all(v is None for v in template.GATES.values()) and all(v is None for v in common.GATES.values()),'historical v2 activation values changed')
    proof_path=repo/PROOF_REL;require(sha(proof_path)==PROOF_SHA,'actual111-ref native prerequisite differs')
    checked=template.prerequisite(proof_path,PROOF_SHA);require(len(checked['refs'])==111,'all111 original prerequisite refs required')
    assets=static_assets(repo,common,io_module)
    corpus=repo/CASE/'inputs/reserved-articles-v1';manifest=read(corpus/'reserved.json')
    for item in [{'file':'reserved.json','sha256':template.MANIFEST_SHA},*manifest['samples']]:
        path=corpus/item['file'];require(sha(path)==item['sha256'],'original48 input bytes differ');assets[CASE+'/inputs/reserved-articles-v1/'+item['file']]=path.read_bytes()
    proof_prefix=CASE+'/prerequisites/reserved48-native'
    for item in checked['refs'].values():
        path=Path(item['path']);rel=path.relative_to(proof_path.parent).as_posix();relative(rel)
        require(ref(path)==item,'original prerequisite changed during packaging');assets[proof_prefix+'/'+rel]=path.read_bytes()
    output.mkdir(mode=0o700);generated=output/'generated';generated.mkdir()
    stage=template.proposed_stage();stage['H100_parallelism_selected']=4
    stage_bytes=encoded(stage);S=digest(stage_bytes)
    expected_raw=replace_assignment(path_bridge(templates[CASE+'/adapters/reserved48_expected_v2.py']),'STAGE_SHA256',S)
    expected_path=generated/'reserved48_expected_v3.py';write(expected_path,expected_raw);expected=pure(expected_path,'_reserved48_package_expected_v3')
    inventory=expected.derive(corpus/'reserved.json',corpus,S);expected_bytes=encoded(inventory);E=digest(expected_bytes)
    budget=encoded(template.proposed_budget(S));B=digest(budget)
    gates={'cpu_portable_sha256':template.ACTUAL_CPU_PORTABLE_SHA,'native_prerequisite_sha256':PROOF_SHA,'stage_sha256':S,
        'budget_sha256':B,'expected_inventory_sha256':E,'expected_builder_sha256':digest(expected_raw),'native_endpoint_schema_reviewed':True}
    contract_raw=parallelism_literal(replace_assignment(path_bridge(templates[CASE+'/transfer/reserved48_stage_contract_v2.py']),'GATES',gates),4);C=digest(contract_raw)
    common_gates={'stage_sha256':S,'expected_inventory_sha256':E,'prerequisite_helper_sha256':C,'prerequisite_sha256':PROOF_SHA,
        'budget_sha256':B,'allocation_schema_ready':True,'outer_lifecycle_ready':True}
    common_raw=replace_assignment(path_bridge(templates[CASE+'/adapters/reserved48_common_v2.py']),'GATES',common_gates)
    native_raw=path_bridge(templates[CASE+'/adapters/reserved48_native_v2.py'])
    lifecycle_raw=replace_assignment(path_bridge(templates[CASE+'/transfer/reserved48_gpu_lifecycle_v2.py']),'CONTRACT_SHA',C)
    npu_raw=path_bridge(templates[CASE+'/transfer/reserved48_npu_lifecycle_v2.py'])  # Remains None; no NPU activation in this GPU package.
    rendered={CASE+'/adapters/reserved48_expected_v3.py':expected_raw,CASE+'/adapters/reserved48_common_v3.py':common_raw,
        CASE+'/adapters/reserved48_native_v3.py':native_raw,CASE+'/transfer/reserved48_stage_contract_v3.py':contract_raw,
        CASE+'/transfer/reserved48_gpu_lifecycle_v3.py':lifecycle_raw,CASE+'/transfer/reserved48_npu_lifecycle_v3.py':npu_raw}
    lineage_docs={}
    for target,raw in rendered.items():
        original=templates[target.replace('_v3.py','_v2.py')]
        assignment=['GATES'] if target.endswith(('common_v3.py','contract_v3.py')) else ['STAGE_SHA256'] if target.endswith('expected_v3.py') else ['CONTRACT_SHA'] if target.endswith('gpu_lifecycle_v3.py') else []
        lineage_docs[target]=lineage(original,raw,assignment,target.endswith('contract_v3.py'));assets[target]=raw
        if target!=CASE+'/adapters/reserved48_expected_v3.py':write(generated/PurePosixPath(target).name,raw)
    resource_policy={'schema_version':1,'state':'root_selected_offline_policy_not_actual_allocation','GPU_prompt_bins':list(BINS),
        'maximum_concurrent_H100_bin_jobs':4,'requested_compute_devices_per_job':1,'model_loads_per_job':1,
        'actual_allocation_ids':None,'resources_created_by_this_builder':0,'Q02_or_P01_coupled':False,'NPU_native_activated_by_this_GPU_package':False}
    assets.update({CASE+'/reserved48-stage-v3.json':stage_bytes,CASE+'/reserved48-budget-v3.json':budget,
        CASE+'/reserved48-expected-v3.json':expected_bytes,CASE+'/reserved48-resource-policy-v3.json':encoded(resource_policy)})
    for name,raw in templates.items():assets['lineage/'+name]=raw
    assets[CASE+'/transfer/build_reserved48_gpu_package_v3.py']=Path(__file__).read_bytes()
    packages=output/'packages';packages.mkdir();bins=[]
    source_doc=source_manifest(assets);source_raw=encoded(source_doc)
    for P in BINS:
        name='p%04d-v1'%P;local=packages/name;local.mkdir();root=GPU_BASE+'/'+name;source=root+'/source'
        for path,raw in assets.items():write(local/'source'/path,raw)
        write(local/'source-manifest.json',source_raw)
        def sr(name):return remote_ref(source,name,assets[name])
        d={'schema_version':1,'task':template.TASK,'backend':'GPU','prompt_bin':P,'native_capture_schema_version':2,'progress_schema_version':1,
            'model_loads':1,'native_launches':1,'automatic_retry':False,'task_root':root,'source_root':source,
            'source_manifest':remote_ref(root,'source-manifest.json',source_raw),'collector_relative_path':CASE+'/adapters/reserved48_native_v3.py',
            'common_relative_path':CASE+'/adapters/reserved48_common_v3.py','lifecycle_relative_path':CASE+'/transfer/reserved48_gpu_lifecycle_v3.py',
            'recorder_relative_path':'skills/precision-compare/scripts/record_run.py','cleanup_relative_path':CASE+'/transfer/npu_three_repeat_launcher_v4.py',
            'gpu_io_relative_path':IO,'gpu_restore_relative_path':RESTORE,
            'reviewed_source_sha256':{'collector':digest(native_raw),'common':digest(common_raw),'lifecycle':digest(lifecycle_raw)},
            'stage_spec':sr(CASE+'/reserved48-stage-v3.json'),'budget':sr(CASE+'/reserved48-budget-v3.json'),
            'expected_inventory':sr(CASE+'/reserved48-expected-v3.json'),'expected_builder':sr(CASE+'/adapters/reserved48_expected_v3.py'),
            'prerequisite':sr(proof_prefix+'/prerequisite.json'),'manifest':sr(CASE+'/inputs/reserved-articles-v1/reserved.json'),
            'input_dir':source+'/'+CASE+'/inputs/reserved-articles-v1','allocation_source_path':root+'/platform-allocation-source.json',
            'model':MODELS,'numerics_policy':sr(CASE+'/inputs/peer-math-policy-cu128-v1.json'),'resource_policy':sr(CASE+'/reserved48-resource-policy-v3.json')}
        config=encoded(d);write(local/'prepared-config.json',config)
        entry=shell(root,digest(config),digest(lifecycle_raw));write(local/'launch-reserved48-gpu-v3.sh',entry)
        bins.append({'prompt_bin':P,'root':root,'prepared_config_sha256':digest(config),'source_manifest_sha256':digest(source_raw),
            'entry_sha256':digest(entry),'actual_allocation_id':None,'native_executions_started':0})
    put(output/'source-lineage.json',lineage_docs)
    result={'schema_version':1,'status':'four_GPU_bin_candidates_prepared_not_executed','stage_sha256':S,'budget_sha256':B,
        'expected_inventory_sha256':E,'original_prerequisite_sha256':PROOF_SHA,'source_sha256':{k:digest(v) for k,v in rendered.items()},
        'template_sha256':TEMPLATES,'bins':bins,'source_files_per_bin':len(assets),'source_bytes_per_bin':sum(map(len,assets.values())),
        'resource_policy':resource_policy,'reused_environment':ENVIRONMENT,'native_executions_started':0,'hardware_queries':0,
        'original_proof_producer_identity_rewritten':False,'NPU_v3_contract_pin':None,'full_core_complete':False,'acceptance':None}
    if rehearse:result['pure_common_prepare_rehearsal']=rehearsal(output)
    package_files={p.relative_to(packages).as_posix():p.read_bytes() for p in packages.rglob('*') if p.is_file()}
    index={'schema_version':1,'kind':'reserved48-four-GPU-bin-v3-package','GPU_base':GPU_BASE,'files':{k:{'sha256':digest(v),'size_bytes':len(v)} for k,v in package_files.items()},'build':result}
    index_raw=encoded(index);write(output/'package-index.json',index_raw);package_files['package-index.json']=index_raw
    archive=output/'reserved48-four-GPU-bin-v3.tar.gz'
    with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz',format=tarfile.USTAR_FORMAT) as tf:
        for name,raw in sorted(package_files.items()):
            relative(name);info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o700 if name.endswith('.sh') else 0o600;tf.addfile(info,io.BytesIO(raw))
    result.update(archive={'path':str(archive),'sha256':sha(archive),'size_bytes':archive.stat().st_size},package_index_sha256=digest(index_raw),
        regular_members=len(package_files),elapsed_seconds=time.monotonic()-started)
    require(archive.stat().st_size<=128*1024**2 and sum(map(len,package_files.values()))<=512*1024**2,'bounded GPU metadata source package exceeds budget')
    require(all(sha(repo/k)==v for k,v in TEMPLATES.items()),'historical v2 templates changed during build')
    put(output/'build-receipt.json',result);return result


def rehearsal(output,rehearsal_dir=None):
    """Actual source/proof/corpus checks; synthetic allocation only, no model."""
    output=Path(output);results=[]
    for P in BINS:
        local=output/'packages'/('p%04d-v1'%P);source=local/'source';d=read(local/'prepared-config.json')
        common=pure(source/CASE/'adapters/reserved48_common_v3.py','_reserved48_v3_dry_common_%d'%P)
        folder=Path(rehearsal_dir or output/'rehearsal')/str(P);folder.mkdir(parents=True);model=folder/'configuration-only';model.mkdir()
        config=(REPO/CASE/'transfer/local-snapshot-20261106T054650Z/config.json').read_bytes();write(model/'config.json',config)
        allocation=folder/'allocation.json';platform=folder/'platform.json';launch=folder/'launch.json'
        put(allocation,{'allocation_id':'app-synthetic-precondition-only','synthetic_CPU_rehearsal':True,'visible_count':0})
        put(platform,{'allocation_id':'app-synthetic-precondition-only','synthetic_CPU_rehearsal':True,'actual_allocation':False})
        def local_ref(item):return ref(local/PurePosixPath(item['path']).relative_to(PurePosixPath(d['task_root'])))
        values={k:local_ref(d[k]) for k in ('stage_spec','budget','expected_inventory','prerequisite')}
        values.update(prerequisite_helper=ref(source/CASE/'transfer/reserved48_stage_contract_v3.py'))
        frozen={k:values[k] for k in ('stage_spec','budget','expected_inventory','prerequisite')}
        frozen.update(allocation_source=ref(platform),source_manifest=ref(local/'source-manifest.json'))
        put(launch,{'allocation_id':'app-synthetic-precondition-only','task':common.TASK,'backend':'gpu','prompt_bin':P,'status':'claimed',
            'permanent_claim':True,'native_launches':1,'model_loads':1,'automatic_retry':False,
            'external_hard_watchdog_seconds':10830,'frozen_refs':frozen,'synthetic_CPU_rehearsal':True})
        args=SimpleNamespace(backend='gpu',device='cuda:0',prompt_bin=P,model=model,input_dir=source/CASE/'inputs/reserved-articles-v1',
            manifest=source/CASE/'inputs/reserved-articles-v1/reserved.json',allocation_receipt=allocation,allocation_source=platform,
            allocation_source_sha256=sha(platform),launch_receipt=launch,launch_receipt_sha256=sha(launch),
            source_manifest=local/'source-manifest.json',source_manifest_sha256=sha(local/'source-manifest.json'),
            numerics_policy=source/CASE/'inputs/peer-math-policy-cu128-v1.json',driver_source=None,native_mapping=None,native_source=None,
            output=folder/'NO_NATIVE_OUTPUT',progress_path=folder/'NO_NATIVE_PROGRESS')
        for k,v in values.items():setattr(args,k,Path(v['path']));setattr(args,k+'_sha256',v['sha256'])
        context=common.prepare(args,source/CASE/'adapters/reserved48_native_v3.py')
        require(len(context['all_rows'])==48 and len(context['rows'])==12 and len(context['proof']['refs'])==111,'complete pure48/12/111 source checks failed')
        require(not args.output.exists() and not args.progress_path.exists() and not (local/'claims').exists(),'dry rehearsal created native output/claims')
        results.append({'prompt_bin':P,'inputs_verified':48,'selected_inputs':12,'proof_refs':111,'frameworks_imported':False,
            'native_outputs_created':False,'claims_created':False,'synthetic_allocation_is_not_actual_evidence':True})
    return results


def inspect_archive(archive,archive_sha,index_sha):
    """Validate the complete metadata-only package before any AFS write."""
    archive=Path(archive);require(archive.is_file() and not archive.is_symlink() and archive.stat().st_size<=128*1024**2
        and sha(archive)==archive_sha,'external source package size/SHA differs')
    bodies={};total=0
    with tarfile.open(archive,'r:gz') as package:
        for member in package:
            relative(member.name);require(member.isfile() and not member.sparse and not member.pax_headers and
                not member.issym() and not member.islnk() and member.name not in bodies,'distinct ordinary USTAR source members required')
            cap=1024**2 if member.name.endswith('.py') else 16*1024**2
            require(0<=member.size<=cap,'bounded source/meta member required');total+=member.size
            require(total<=512*1024**2 and len(bodies)<4096,'source metadata512MiB/4096-member cap')
            body=package.extractfile(member).read(cap+1);require(len(body)==member.size,'truncated source package member');bodies[member.name]=body
    require('package-index.json' in bodies and digest(bodies['package-index.json'])==index_sha,'external source index SHA differs')
    index=json.loads(bodies['package-index.json']);require(index['kind']=='reserved48-four-GPU-bin-v3-package' and index['GPU_base']==GPU_BASE,
        'exact root-owned GPU deployment namespace required')
    require(set(bodies)==set(index['files'])|{'package-index.json'},'source package index coverage differs')
    names=set(bodies)
    require(all(all(str(p) not in names for p in PurePosixPath(n).parents if str(p)!='.') for n in names),'file/ancestor collision in source package')
    for name,item in index['files'].items():require(item=={'sha256':digest(bodies[name]),'size_bytes':len(bodies[name])},'source package member changed')
    require([b['prompt_bin'] for b in index['build']['bins']]==list(BINS) and all(b['actual_allocation_id'] is None for b in index['build']['bins'])
        and index['build']['native_executions_started']==0,'source package must not invent allocations or native results')
    for P in BINS:
        prefix='p%04d-v1/'%P;cfg=json.loads(bodies[prefix+'prepared-config.json'])
        require(cfg['task_root']==GPU_BASE+'/'+prefix[:-1] and cfg['source_root']==cfg['task_root']+'/source' and cfg['prompt_bin']==P,
            'prepared-config/root/bin identity differs')
        manifest=json.loads(bodies[prefix+'source-manifest.json'])
        source={n[len(prefix+'source/'):]:raw for n,raw in bodies.items() if n.startswith(prefix+'source/')}
        require(manifest==source_manifest(source) and len(source)==index['build']['source_files_per_bin'],'typed exact source manifest differs')
        require(cfg['source_manifest']==remote_ref(cfg['task_root'],'source-manifest.json',bodies[prefix+'source-manifest.json']),
            'prepared config/source-manifest ref differs')
        for field in ('stage_spec','budget','expected_inventory','expected_builder','prerequisite','manifest','numerics_policy','resource_policy'):
            item=cfg[field];rel=str(PurePosixPath(item['path']).relative_to(PurePosixPath(cfg['source_root'])))
            require(item==remote_ref(cfg['source_root'],rel,source[rel]),'prepared original source/ref differs: '+field)
        require(cfg['allocation_source_path']==cfg['task_root']+'/platform-allocation-source.json'
            and cfg['model']==MODELS and '\\' not in bodies[prefix+'launch-reserved48-gpu-v3.sh'].decode(),
            'unknown allocation must remain separate; startup must be POSIX')
    require(sha(archive)==archive_sha,'source package changed during inspection')
    return index,bodies


def stage(archive,archive_sha,index_sha):
    require(os.name=='posix','AFS staging requires explicit Linux filesystem; no platform action')
    index,bodies=inspect_archive(archive,archive_sha,index_sha)
    base=Path(AFS);target=Path(GPU_BASE)
    require(base.is_dir() and not base.is_symlink() and not target.exists() and not target.is_symlink(),
        'existing nonsymlink AFS base and exclusive new GPU namespace required')
    current=target
    while current!=base:
        require(not current.is_symlink(),'symlink in proposed AFS namespace');current=current.parent
    require(shutil.disk_usage(base).free>=64*1024**3,'AFS source free64GiB guard')
    target.parent.mkdir(exist_ok=True);target.mkdir(mode=0o700)
    put(target/'stage-once.json',{'archive_sha256':archive_sha,'package_index_sha256':index_sha,'automatic_retry':False,'native_executions_started':0})
    for name,raw in bodies.items():
        path=target.joinpath(*relative(name).parts);require(path.resolve().is_relative_to(target.resolve()),'source write escapes AFS namespace')
        write(path,raw);path.chmod(0o700 if name.endswith('.sh') else 0o600)
        require(sha(path)==digest(raw),'staged source bytes differ')
    result={'schema_version':1,'status':'four_GPU_source_bins_staged_not_allocated','GPU_base':GPU_BASE,'archive_sha256':archive_sha,
        'package_index_sha256':index_sha,'regular_members':len(bodies),'bins':index['build']['bins'],'actual_allocations':None,
        'native_executions_started':0,'hardware_queries':0,'acceptance':None}
    put(target/'stage-receipt.json',result);return result


def fsync_source(source,manifest_sha):
    source=Path(source).resolve(strict=True);manifest=source.parent/'source-manifest.json'
    require(isinstance(manifest_sha,str) and HEX.fullmatch(manifest_sha) and sha(manifest)==manifest_sha,'external staged-source manifest SHA differs')
    doc=read(manifest);path=source/CASE/'adapters/reserved48_common_v3.py';original=source/'lineage'/CASE/'adapters/reserved48_common_v2.py'
    require(sha(original)==TEMPLATES[CASE+'/adapters/reserved48_common_v2.py'] and
        sha(path)==doc['files'][CASE+'/adapters/reserved48_common_v3.py'],'frozen common source differs before CPU fsync probe')
    lineage(original.read_bytes(),path.read_bytes(),['GATES'])
    return source,path


def _fsync_probe_body(source,folder,manifest_sha):
    """Synthetic declared protocol only; terminal intentionally cannot admit native evidence."""
    source,path=fsync_source(source,manifest_sha);folder=Path(folder).resolve();common=pure(path,'_reserved48_fsync_proxy_common')
    expected=read(source/CASE/'reserved48-expected-v3.json')
    rows=[{'sample':r['sample'],'P':r['prompt_length'],'L':r['sequence_length'],
        'plans':{m['mode']:m['input_spans_zero_based_half_open'] for m in r['modes']}} for r in expected['samples'] if r['prompt_length']==128]
    start=time.monotonic();progress=common.Progress(folder/'synthetic-progress.jsonl',rows,'gpu');latencies=[]
    def call(fn,*args,**kwargs):
        before=time.monotonic();fn(*args,**kwargs);latencies.append(time.monotonic()-before)
    for phase in ('environment_preflight','model_load','after_model_load'):call(progress.phase,phase)
    for row in rows:
        for mode in common.MODES:
            call(progress.enter_cell,row['sample'],mode)
            for i,(a,b) in enumerate(row['plans'][mode]):
                call(progress.phase,'input_or_cache_preparation');call(progress.forward_started,i,a,b)
                call(progress.forward_returned,i);call(progress.phase,'source_CPU_derivation_and_evidence')
            path=folder/(row['sample']+'-'+mode+'.json')
            put(path,{'sample':row['sample'],'mode':mode,'native_calls':len(row['plans'][mode]),'valid_rows':row['L'],
                'targets':row['L']-1,'selected_rows':47,'synthetic_protocol_only':True,'native_execution_observed':False})
            call(progress.complete_cell,path)
    call(progress.phase,'final_artifact_validation')
    # Same final durable write cost, but not a forged source_capture_completed
    # terminal or a false observed-model-load counter from Progress.complete().
    call(progress.emit,'synthetic_CPU_fsync_probe_terminal',native_executions_started=0,model_loads_observed=0)
    progress.terminal=True
    require(progress.count==3342,'actual source logger event count changed')
    try:common.validate_progress(progress.path,rows)
    except ValueError:pass
    else:raise ValueError('synthetic fsync probe must never qualify as native progress evidence')
    ordered=sorted(latencies)
    result={'status':'synthetic_CPU_progress_fsync_probe_completed','scope':'AFS metadata-write proxy only; no model/GPU/P01 latency claim',
        'events_fsynced':progress.count,'declared_cells':36,'declared_forward_spans':816,'native_forward_calls':0,'model_loads':0,
        'elapsed_seconds':time.monotonic()-start,'event_latency_max_seconds':max(ordered),'event_latency_median_seconds':ordered[len(ordered)//2],
        'original_common_sha256':sha(source/CASE/'adapters/reserved48_common_v3.py'),'native_progress_admissible':False,'native_executions_started':0}
    put(folder/'probe-result.json',result);return result


def fsync_probe_worker(source,folder,manifest_sha):
    """A direct worker invocation keeps the same CPU-only deadline/path guard."""
    require(os.name=='posix','bounded CPU-only fsync worker requires Linux')
    source,_=fsync_source(source,manifest_sha);folder=Path(folder).absolute()
    require(folder.is_dir() and not folder.is_symlink() and not folder.resolve().is_relative_to(source),
        'fsync worker output must be an existing nonsymlink directory outside immutable source')
    def expired(*_):raise TimeoutError('direct synthetic CPU fsync work35s')
    previous={sig:signal.signal(sig,expired) for sig in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
    signal.setitimer(signal.ITIMER_REAL,FSYNC_WORK_SECONDS)
    try:return _fsync_probe_body(source,folder,manifest_sha)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        for sig,handler in previous.items():signal.signal(sig,handler)


def fsync_probe(source,output,manifest_sha):
    require(os.name=='posix','bounded CPU-only fsync proxy requires Linux')
    source,_=fsync_source(source,manifest_sha);output=Path(output).absolute()
    require(output.parent.is_dir() and not output.exists() and not output.is_symlink() and not output.resolve().is_relative_to(source),
        'exclusive fsync run must be outside immutable source tree')
    output.mkdir(mode=0o700);started=time.monotonic();proc=None
    state={'schema_version':1,'task':'reserved48-synthetic-CPU-fsync-probe','status':'running','started_utc':datetime.now(timezone.utc).isoformat(),
        'whole_seconds':FSYNC_WHOLE_SECONDS,'work_seconds':FSYNC_WORK_SECONDS,'cleanup_reserve_seconds':5,'native_executions_started':0,'model_loads':0,
        'no_automatic_cap_or_durability_adjustment':True,'not_a_native_permission_gate':True}
    def expired(*_):raise TimeoutError('synthetic CPU fsync work35s')
    previous={sig:signal.signal(sig,expired) for sig in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
    signal.setitimer(signal.ITIMER_REAL,FSYNC_WORK_SECONDS)
    try:
        with (output/'stdout.bin').open('xb') as stdout,(output/'stderr.bin').open('xb') as stderr:
            proc=subprocess.Popen(
                [sys.executable,'-S','-B',str(Path(__file__).resolve()),'fsync-worker','--source',str(source),'--output',str(output),
                 '--source-manifest-sha256',manifest_sha],stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
            proc.wait(timeout=FSYNC_WORK_SECONDS)
        require(proc.returncode==0,'fsync child did not complete; retain incomplete protocol as CPU diagnostic')
        result=read(output/'probe-result.json');require(result['native_executions_started']==0 and result['events_fsynced']==3342,
            'synthetic-only fsync result differs');state.update(status='completed_CPU_proxy_only',result=result)
    except BaseException as exc:state.update(status='incomplete_CPU_proxy_only',error_type=type(exc).__name__,error=str(exc))
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        if proc is not None:
            try:os.killpg(proc.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            try:proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                pass
            try:os.killpg(proc.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            try:proc.wait(timeout=3)
            except subprocess.TimeoutExpired:state.update(status='incomplete_CPU_proxy_only',cleanup_error='owned single-process worker did not exit after KILL')
            state['child_returncode']=proc.returncode
        state['elapsed_seconds']=time.monotonic()-started
        if state['elapsed_seconds']>FSYNC_WHOLE_SECONDS:state.update(status='incomplete_CPU_proxy_only',whole_deadline_exceeded=True)
        state['partial_files_retained']=True;state['native_progress_admissible']=False;put(output/'controller-receipt.json',state)
        for sig,handler in previous.items():signal.signal(sig,handler)
    return state


def publish(P,app_id,observed_utc,evidence,index_sha):
    """Root-invoked publication only; does not create/start a platform app."""
    require(os.name=='posix' and P in BINS and re.fullmatch(r'app-[a-z0-9-]{1,64}',app_id),'explicit actual GPU app/bin required')
    observed=datetime.fromisoformat(observed_utc);require(observed.tzinfo is not None and isinstance(evidence,str) and evidence.strip(),
        'actual timezone-qualified UI observation and source reference required')
    base=Path(GPU_BASE);index_path=base/'package-index.json';require(not base.is_symlink() and sha(index_path)==index_sha,'staged source index SHA differs')
    index=read(index_path);item=next(b for b in index['build']['bins'] if b['prompt_bin']==P);root=base/('p%04d-v1'%P)
    require(not root.is_symlink() and not (root/'bin-launch-once.json').exists() and not (root/'claims').exists(),'fresh bin must not have an earlier launch/claim')
    config=root/'prepared-config.json';require(sha(config)==item['prepared_config_sha256'],'immutable prepared config differs');d=read(config)
    require(sha(root/'source-manifest.json')==item['source_manifest_sha256'] and d['task_root']==str(root),'actual staged bin source differs')
    source=root/'platform-allocation-source.json';temporary=root/'.platform-allocation-source.prepared'
    require(not source.exists() and not source.is_symlink(),'allocation source already published; no overwrite/retry')
    value={'schema_version':1,'task':d['task'],'backend':'GPU','prompt_bin':P,'allocation_id':app_id,'observed_utc':observed_utc,
        'evidence_source':evidence,'prepared_config_sha256':sha(config),'stage_sha256':d['stage_spec']['sha256'],
        'budget_sha256':d['budget']['sha256'],'expected_inventory_sha256':d['expected_inventory']['sha256'],
        'native_prerequisite_sha256':d['prerequisite']['sha256'],'lifecycle_sha256':d['reviewed_source_sha256']['lifecycle'],
        'source_manifest_sha256':item['source_manifest_sha256'],'platform_resource_created_by_this_tool':False}
    put(temporary,value);os.link(temporary,source);require(sha(source)==sha(temporary),'atomic allocation source bytes differ');temporary.unlink()
    result={'status':'actual_UI_allocation_source_published_not_started_by_tool','allocation_id':app_id,'prompt_bin':P,
        'source':ref(source),'prepared_config_sha256':sha(config),'native_executions_started':0}
    put(root/'allocation-source-publish-receipt.json',result);return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['build','inspect','stage','fsync','fsync-worker','publish'])
    p.add_argument('--output',type=Path);p.add_argument('--source',type=Path);p.add_argument('--archive',type=Path)
    p.add_argument('--archive-sha256');p.add_argument('--index-sha256');p.add_argument('--source-manifest-sha256')
    p.add_argument('--prompt-bin',type=int,choices=BINS);p.add_argument('--app-id');p.add_argument('--observed-utc');p.add_argument('--evidence');args=p.parse_args()
    if args.mode=='build':result=build(args.output)
    elif args.mode=='inspect':
        index,bodies=inspect_archive(args.archive,args.archive_sha256,args.index_sha256)
        result={'status':'metadata_source_package_verified','regular_members':len(bodies),'bins':index['build']['bins'],'native_executions_started':0}
    elif args.mode=='stage':result=stage(args.archive,args.archive_sha256,args.index_sha256)
    elif args.mode=='fsync':result=fsync_probe(args.source,args.output,args.source_manifest_sha256)
    elif args.mode=='fsync-worker':result=fsync_probe_worker(args.source,args.output,args.source_manifest_sha256)
    else:result=publish(args.prompt_bin,args.app_id,args.observed_utc,args.evidence,args.index_sha256)
    print(json.dumps(result,indent=2))

"""CPU artifact regressions; all tensors are synthetic, never native evidence."""
import copy
import hashlib
import json
import math
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import reserved48_cpu_artifacts_v1 as artifacts
import derive_compare_reserved48_cpu_v1 as workflow


def word(value): return struct.unpack('<I', struct.pack('<f', float(value)))[0] >> 16


def fixture(vocabulary=128, P=128, mode='full'):
    length = P + 32; sequence = [i % vocabulary for i in range(length)]; sequence[0] = 2
    positions = sorted(set(i * (P - 1) // 15 for i in range(16)) | set(range(P - 1, P + 31)))
    row = {'sample': 'synthetic-CPU-only', 'input_ids': sequence, 'input_sha256': '1' * 64,
        'prompt_length': P, 'sequence_length': length, 'distribution_positions': positions}
    rows = {i: struct.pack('<H', word(i - 3)) * vocabulary for i in range(7)}
    digests = [{'prediction_position': p, 'sha256': hashlib.sha256(rows[p % 7]).hexdigest(),
                'native_data_bytes': vocabulary * 2} for p in range(length)]
    stream = hashlib.sha256()
    for p in range(length): stream.update(rows[p % 7])
    scores = [{'sample': row['sample'], 'position': p + 1, 'prediction_position': p, 'token': sequence[p + 1],
        'raw_target_bf16_u16': word(p % 7 - 3), 'raw_target_value': float(p % 7 - 3), 'logprob': -math.log(vocabulary),
        'source_logsumexp': float(p % 7 - 3) + math.log(vocabulary), 'source_logsumexp_origin': artifacts.SOURCE_LSE_ORIGIN,
        'raw_argmax_token_lowest_id': 0, 'raw_argmax_bf16_u16': word(p % 7 - 3), 'raw_row_sha256': digests[p]['sha256']}
        for p in range(length - 1)]
    target = {'task': artifacts.TASK, 'mode': mode, 'sample': row['sample'], 'input_sha256': row['input_sha256'], 'scores': scores}
    digest_doc = {'rows': digests, 'raw_stream_sha256': stream.hexdigest(), 'full_raw_rows_retained': False,
        'all_valid_rows_checked_finite': length, 'unscored_finite_last_position': length - 1}
    selection = {'sample': row['sample'], 'mode': mode, 'shape': [47, vocabulary], 'original_sequence_native_shape': [1, length, vocabulary],
        'positions': [{'row': i, 'prediction_position': p, 'target_position': p + 1, 'token': sequence[p + 1],
                       'raw_row_sha256': digests[p]['sha256']} for i, p in enumerate(positions)]}
    summary = {'mode': mode, 'valid_rows': length, 'targets': length - 1, 'selected_rows': 47, 'raw_stream_sha256': stream.hexdigest()}
    return row, target, digest_doc, selection, summary, rows


def save_bf16(path, row, native_rows, vocabulary, shape=None, dtype='BF16', trailing=b''):
    shape = [47, vocabulary] if shape is None else shape
    data = b''.join(native_rows[p % 7] for p in row['distribution_positions'])
    header = {'logits': {'dtype': dtype, 'shape': shape, 'data_offsets': [0, len(data)]},
              '__metadata__': {'scope': 'synthetic CPU fixture, no model', 'sample': row['sample']}}
    raw = json.dumps(header, separators=(',', ':')).encode(); raw += b' ' * ((-len(raw)) % 8)
    with Path(path).open('xb') as stream: stream.write(struct.pack('<Q', len(raw)) + raw + data + trailing)


class ScalarAdmissionTests(unittest.TestCase):
    def test_all8223_targets_and_valid_zero_survive_without_claiming_all_raw_replay(self):
        row, target, digests, selection, summary, _ = fixture(P=8192)
        result = artifacts.admit_source_scalars(row, target, digests, selection, summary, 128)
        self.assertEqual(result['source_target_scores'], 8223)
        self.assertEqual(result['source_raw_rows_claimed_finite'], 8224)
        self.assertFalse(result['independent_all_target_normalizers']); self.assertFalse(result['full_unselected_raw_audit'])
        self.assertEqual(target['scores'][127]['token'], 0)
        wrong = copy.deepcopy(target); wrong['scores'][127]['token'] = False
        with self.assertRaises(ValueError): artifacts.admit_source_scalars(row, wrong, digests, selection, summary, 128)

    def test_missing_last_target_wrong_shift_or_scalar_formula_is_rejected(self):
        row, target, digests, selection, summary, _ = fixture()
        wrong = copy.deepcopy(target); wrong['scores'].pop()
        with self.assertRaises(ValueError): artifacts.admit_source_scalars(row, wrong, digests, selection, summary, 128)
        for key, value in (('position', 158), ('raw_target_value', 4), ('source_logsumexp', 20), ('raw_row_sha256', '0' * 64)):
            wrong = copy.deepcopy(target); wrong['scores'][-1][key] = value
            with self.assertRaises(ValueError, msg=key): artifacts.admit_source_scalars(row, wrong, digests, selection, summary, 128)

    def test_omitted_reordered_selected_position_and_unscored_digest_are_rejected(self):
        row, target, digests, selection, summary, _ = fixture()
        wrong = copy.deepcopy(selection); wrong['positions'][0], wrong['positions'][1] = wrong['positions'][1], wrong['positions'][0]
        with self.assertRaises(ValueError): artifacts.admit_source_scalars(row, target, digests, wrong, summary, 128)
        wrong = copy.deepcopy(digests); wrong['rows'].pop()
        with self.assertRaises(ValueError): artifacts.admit_source_scalars(row, target, wrong, selection, summary, 128)
        wrong = copy.deepcopy(digests); wrong['full_raw_rows_retained'] = True
        with self.assertRaises(ValueError): artifacts.admit_source_scalars(row, target, wrong, selection, summary, 128)


class ArrayDerivationTests(unittest.TestCase):
    def test_actual_numpy_fullV47_matrix_and_documented_multirow_selector(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); row, targets, digests, selection, summary, native_rows = fixture(262144)
            source = root / 'selected-native-logits.safetensors'; save_bf16(source, row, native_rows, 262144)
            original = artifacts.ref(source)
            derived = artifacts.derive_selected(source, original, row, selection, targets['scores'], root / 'new-logprobs.npy', artifacts.Audit(60))
            self.assertEqual(derived['new_derived_FP64_rows'], 47); self.assertFalse(derived['original_GPU_or_NPU_FP64_array'])
            self.assertFalse(derived['independent_all_target_normalizers']); self.assertEqual(artifacts.ref(source), original)
            values = np.load(root / 'new-logprobs.npy', mmap_mode='r', allow_pickle=False)
            try:
                self.assertEqual(values.shape, (47, 262144)); self.assertEqual(values.dtype, np.dtype('<f8'))
                self.assertLess(float(np.max(np.abs(values + math.log(262144)))), 1e-12)
            finally: values._mmap.close()
            _, shared = artifacts.libraries()
            selector = derived['positions'][-1]
            self.assertEqual(selector['scores']['row'], 46); self.assertNotIn('row', selector)
            selected, mass = shared['compare_distributions'].scores(root, selector, 262144, 1e-10, 'none')
            self.assertEqual(selected.shape, (262144,)); self.assertAlmostEqual(mass, 1.0, places=12)
            wrong = copy.deepcopy(selector); wrong['row'] = wrong['scores'].pop('row')
            with self.assertRaises(ValueError): shared['compare_distributions'].scores(root, wrong, 262144, 1e-10, 'none')
            with self.assertRaises(ValueError):
                artifacts.derive_selected(source, original, row, selection, targets['scores'], root / 'new-logprobs.npy', artifacts.Audit(60))

    def test_old_full_raw_shape_trailing_payload_and_nonBF16_are_rejected(self):
        row, _, _, _, _, native_rows = fixture()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for index, kwargs in enumerate(({'shape': [1, 160, 128]}, {'dtype': 'F16'}, {'trailing': b'x'})):
                path = root / ('invalid-%d.safetensors' % index); save_bf16(path, row, native_rows, 128, **kwargs)
                with self.assertRaises(ValueError): artifacts.selected_array(path, 128)

    def test_permuted_native_rows_nonfinite_and_forged_argmax_are_rejected(self):
        row, target, _, selection, _, native_rows = fixture()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); source = root / 'original.safetensors'; save_bf16(source, row, native_rows, 128)
            array = artifacts.selected_array(source, 128)
            with source.open('r+b') as stream:
                stream.seek(array.offset); first = stream.read(256); second = stream.read(256)
                stream.seek(array.offset); stream.write(second + first)
            with self.assertRaisesRegex(ValueError, 'digest differs'):
                artifacts.derive_selected(source, ref(source), row, selection, target['scores'], root / 'bad-order.npy', artifacts.Audit(10), 128)
            source2 = root / 'nonfinite.safetensors'; save_bf16(source2, row, native_rows, 128)
            array = artifacts.selected_array(source2, 128)
            with source2.open('r+b') as stream: stream.seek(array.offset); stream.write(struct.pack('<H', 0x7f80))
            with self.assertRaisesRegex(ValueError, 'nonfinite'):
                artifacts.derive_selected(source2, ref(source2), row, selection, target['scores'], root / 'nonfinite.npy', artifacts.Audit(10), 128)
            source3 = root / 'valid.safetensors'; save_bf16(source3, row, native_rows, 128)
            wrong = copy.deepcopy(target); wrong['scores'][row['distribution_positions'][0]]['raw_argmax_token_lowest_id'] = 1
            with self.assertRaisesRegex(ValueError, 'argmax/tie'):
                artifacts.derive_selected(source3, ref(source3), row, selection, wrong['scores'], root / 'wrong-tie.npy', artifacts.Audit(10), 128)


def ref(path): return artifacts.ref(path)


class SharedComparisonTests(unittest.TestCase):
    def test_cache_geometry_accepts_observed_trim_and_rejects_invented_trim_or_full_clip(self):
        def cache(consumed, trimmed=False):
            layers = []
            for i in range(48):
                full = i % 6 == 5; n = 1023 if trimmed and not full else consumed
                tensor = {'shape': [1, 1 if full else 8, n, 512 if full else 256], 'dtype': 'torch.bfloat16', 'device': 'npu:0'}
                layers.append({'index': i, 'configured_attention': 'full_attention' if full else 'sliding_attention',
                    'reported_sequence_length': consumed, 'is_sliding': trimmed and not full, 'sliding_window': 1024 if not full else None,
                    'keys': copy.deepcopy(tensor), 'values': copy.deepcopy(tensor)})
            return {'present': True, 'logical_tokens_consumed': consumed, 'reported_sequence_length': consumed,
                    'class': 'synthetic.not-a-native-cache', 'layers': layers}
        artifacts.admit_cache_metadata({'present': False}, 8224, False, 'npu:0')
        artifacts.admit_cache_metadata({'present': False, 'logical_tokens': 0}, 0, True, 'npu:0')
        # Either observed implementation is legal; L160 does not prove future clipping.
        artifacts.admit_cache_metadata(cache(2048), 2048, True, 'npu:0')
        artifacts.admit_cache_metadata(cache(2048, True), 2048, True, 'npu:0')
        wrong = cache(2048, True); wrong['layers'][0]['is_sliding'] = False
        with self.assertRaisesRegex(ValueError, 'sliding provenance'): artifacts.admit_cache_metadata(wrong, 2048, True, 'npu:0')
        wrong = cache(2048); wrong['layers'][5]['keys']['shape'][-2] = 1024
        with self.assertRaisesRegex(ValueError, 'full-attention'): artifacts.admit_cache_metadata(wrong, 2048, True, 'npu:0')
        wrong = cache(2048); wrong['layers'][0]['values']['dtype'] = 'torch.float32'
        with self.assertRaisesRegex(ValueError, 'dtype/device'): artifacts.admit_cache_metadata(wrong, 2048, True, 'npu:0')

    def test_full_shared_comparator_accepts_new_matrix_row_descriptors(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); row, target, _, selection, _, native_rows = fixture()
            observations = {}
            for backend in ('GPU', 'NPU'):
                source = root / (backend + '.safetensors'); save_bf16(source, row, native_rows, 128)
                derived = artifacts.derive_selected(source, ref(source), row, selection, target['scores'], root / (backend + '.npy'), artifacts.Audit(30), 128)
                path = root / (backend + '-derivation.json'); artifacts.put(path, derived)
                scores = root / (backend + '-source-view.json')
                artifacts.put(scores, {'sample': row['sample'], 'scores': [{key: item[key] for key in ('sample', 'position', 'token', 'logprob')} for item in target['scores']]})
                observations[(backend, 'full')] = {'derivation': ref(path), 'source_scalar_view': ref(scores), 'profile': {
                    'backend': backend, 'partition': 'full', 'source_software': {'numpy': np.__version__, 'scope': 'synthetic, no model'},
                    'source_backend_policy': {'synthetic_cpu_fixture': True}, 'normalization_location': 'new_common_CPU_artifact',
                    'source_native_receipt': {'source_path': '/synthetic/not-an-actual-native-receipt', 'sha256': '2' * 64}}}
            pair = {'a_backend': 'GPU', 'a_mode': 'full', 'b_backend': 'NPU', 'b_mode': 'full', 'kind': 'cross_backend_matched'}
            output = workflow.compare_pair(root / 'comparison', row, pair, observations, 128)
            report = artifacts.load(output['path'])
            self.assertEqual(report['target_metrics']['target_count'], 159)
            self.assertEqual(report['continuation_target_metrics']['target_count'], 32)
            self.assertEqual(report['target_metrics']['max_abs_nat'], 0)
            self.assertEqual(report['distribution']['position_count'], 47)
            self.assertEqual(report['distribution']['aggregate']['top1_agreement']['count'], 47)
            self.assertIsNone(report['thresholds']); self.assertFalse(report['independent_all_target_normalizers'])

    def test_source_map_no_GPU_retained_fallback_and_byte_mutation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); payload = root / 'payload'; payload.mkdir(); original = '/source/samples/f/full/selected-native-logits.safetensors'
            data = payload / 'small'; data.write_bytes(b'fixture bytes, not native')
            mapping = {'schema_version': 1, 'request': {'task': 'RESERVED48', 'backend': 'GPU', 'prompt_bin': 128,
                'outer_receipt': '/source/capture-receipt.json'}, 'files': {original: {'path': 'payload/small',
                'sha256': artifacts.sha(data), 'size': data.stat().st_size}}}
            path = root / 'source-map.json'; artifacts.put(path, mapping)
            info = {'source_map': {'path': str(path), 'sha256': artifacts.sha(path)}, 'receipt': {'source_path': '/source/capture-receipt.json'}}
            endpoint = artifacts.Endpoint(artifacts.Audit(10), info, 'GPU', 128)
            self.assertEqual(endpoint.get(original, large=True), data.resolve()); data.write_bytes(b'changed bytes')
            with self.assertRaises(ValueError): endpoint.audit.finish()
            mapping['files'][original] = {'retained_at_source': True, 'sha256': '0' * 64, 'size': 24}
            path.write_text(json.dumps(mapping), encoding='utf-8'); info['source_map']['sha256'] = artifacts.sha(path)
            endpoint = artifacts.Endpoint(artifacts.Audit(10), info, 'GPU', 128)
            with self.assertRaisesRegex(ValueError, 'only explicit original NPU'): endpoint.get(original, large=True)

    def test_unready_analysis_refuses_before_files_or_output_and_missing_bin_refused(self):
        self.assertTrue(all(value is None for value in artifacts.GATES.values()))
        with self.assertRaisesRegex(ValueError, 'unready'): artifacts.request('/must-not-open', '0' * 64)
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / 'not-created'
            result = subprocess.run([sys.executable, '-S', '-B', str(Path(workflow.__file__)), 'bin', '--request', 'missing',
                '--request-sha256', '0' * 64, '--output-dir', str(output), '--prompt-bin', '8192'],
                capture_output=True, text=True, timeout=20)
            self.assertNotEqual(result.returncode, 0); self.assertIn('unready', result.stderr); self.assertFalse(output.exists())
            with self.assertRaisesRegex(ValueError, 'four completed bins'): workflow.aggregate({}, {}, [], output)
            self.assertFalse(output.exists())

    def test_all_four_bin_catalog_validation_rejects_missing_pair_alias_and_policy_drift(self):
        """Metadata-only fixture: never creates or opens any raw/derived arrays."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); registry = {}; bin_refs = []; rows = []; pair_specs = []
            for mode in artifacts.MODES:
                pair_specs.append({'a_backend': 'GPU', 'a_mode': mode, 'b_backend': 'NPU', 'b_mode': mode})
            for backend in ('GPU', 'NPU'):
                for a, b in (('full', 'token'), ('full', 'chunk'), ('token', 'chunk')):
                    pair_specs.append({'a_backend': backend, 'a_mode': a, 'b_backend': backend, 'b_mode': b})
            request = {key: {'sha256': str(i) * 64} for i, key in enumerate(('stage_spec', 'expected_inventory', 'budget', 'cpu_prerequisite', 'manifest'), 1)}
            budget_path = root / 'synthetic-budget.json'; artifacts.put(budget_path, {})
            request['budget'] = ref(budget_path); request['cpu_workspace_root'] = str(root)
            request['source_maps'] = {backend: {str(P): {'synthetic': backend + str(P)} for P in artifacts.BINS} for backend in ('GPU', 'NPU')}
            def sealed(path, document):
                value = {'path': str(path), 'sha256': 'a' * 64, 'size_bytes': 1}; registry[str(path)] = document; return value
            for P in artifacts.BINS:
                folder = root / str(P); observations = {}; comparisons = []
                for i in range(12):
                    sample = '%s-%02d' % (P, i); rows.append({'sample': sample, 'prompt_length': P})
                    for backend in ('GPU', 'NPU'):
                        for mode in artifacts.MODES:
                            profile = {'backend': backend, 'partition': mode, 'source_software': {'torch': 'synthetic'},
                                'source_backend_policy': {'frozen': True}, 'derivation': artifacts.DERIVATION,
                                'normalization_location': 'new_common_CPU_artifact'}
                            stem = folder / (backend + sample + mode)
                            observations['/'.join((backend, sample, mode))] = {'sample': sample, 'backend': backend, 'mode': mode,
                                'profile': profile, 'source_scalar_view': sealed(str(stem) + '-scores', {}), 'derivation': sealed(str(stem) + '-derive', {})}
                    for j, pair in enumerate(pair_specs):
                        comparisons.append(sealed(folder / ('%s-pair%d' % (sample, j)), {'sample': sample, 'pair': pair,
                            'distribution': {'status': 'no_thresholds', 'position_count': 47}}))
                report = {'kind': 'reserved48_cpu_bin_report', 'task': artifacts.TASK, 'status': 'completed', 'prompt_bin': P,
                    'bindings': workflow.common_bindings(request), 'input_count': 12, 'native_observations': 72, 'input_pairs': 108,
                    'distribution_pair_positions': 5076, 'native_executions_started': 0, 'independent_all_target_normalizers': False,
                    'full_unselected_raw_audit': False, 'source_maps': {backend: request['source_maps'][backend][str(P)] for backend in ('GPU', 'NPU')},
                    'observations': observations, 'input_pair_reports': comparisons}
                bin_refs.append(sealed(folder / 'bin-report.json', report))
            inventory = {'samples': rows, 'pairs_per_input': pair_specs}
            def read(value, root=None, audit=None): return registry[value['path']]
            with patch.object(workflow, 'pinned_json', side_effect=read), patch.object(artifacts, 'libraries', return_value=(None, {})), \
                    patch.object(workflow, 'Budget', side_effect=RuntimeError('complete metadata admitted before output')):
                with self.assertRaisesRegex(RuntimeError, 'complete metadata admitted'): workflow.aggregate(request, inventory, bin_refs, root / 'never-written')
                selected = registry[bin_refs[-1]['path']]; key = next(iter(selected['observations']))
                item = selected['observations'].pop(key)
                with self.assertRaisesRegex(ValueError, 'complete48'): workflow.aggregate(request, inventory, bin_refs, root / 'never-written')
                selected['observations'][key] = item
                item['profile']['source_software']['torch'] = 'different-bin'
                with self.assertRaisesRegex(ValueError, 'policy drift'): workflow.aggregate(request, inventory, bin_refs, root / 'never-written')
                item['profile']['source_software']['torch'] = 'synthetic'
                selected['input_pair_reports'][-1] = selected['input_pair_reports'][0]
                with self.assertRaisesRegex(ValueError, 'comparison inventory'): workflow.aggregate(request, inventory, bin_refs, root / 'never-written')
            self.assertFalse((root / 'never-written').exists())


if __name__ == '__main__': unittest.main()

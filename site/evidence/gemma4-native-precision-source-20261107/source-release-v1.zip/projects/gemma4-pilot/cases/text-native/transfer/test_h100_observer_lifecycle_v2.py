"""Finite CPU protocol tests using actual metadata; no model/resource operations."""
from concurrent.futures import ThreadPoolExecutor
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PureWindowsPath
import subprocess
import sys
import tarfile
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
CASE = HERE.parent


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


JOB = load('observer_lifecycle_under_test', 'h100_observer_lifecycle_v2.py')
OPS = load('observer_package_under_test', 'build_h100_observer_source_package_v2.py')
GEOMETRY = {
    'gpu-loaded-inventory.json': HERE / 'i01-numeric-small-local-20261106T145700Z/payload/payload/0190/loaded-model-inventory.json',
    'npu-loaded-inventory.json': HERE / 'i01-numeric-small-local-20261106T145700Z/payload/payload/0337/loaded-model-inventory.json',
    'modeling_gemma4_unified.py': HERE / 'i01-numeric-small-local-20261106T145700Z/payload/payload/0101/modeling_gemma4_unified.py',
    'config.json': HERE / 'hf-smallfiles-20261105T112300Z/snapshot/config.json'}


def actual_build(output):
    return OPS.build(HERE.parents[4], output,
        HERE / 'i04-main-local-20261107T212400Z/observer-proof/prerequisite.json', JOB.I04_PROOF_SHA,
        HERE / 'observer-cpu-proof-local-20261106T213255Z/payload/prerequisite.json', JOB.CPU_PROOF_SHA,
        HERE / 'observer-independent-expected-v2-20261107.json', GEOMETRY)


class ActualSourceProtocol(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='observer-source-CPU-')
        cls.build = actual_build(Path(cls.temp.name) / 'package')
        with tarfile.open(cls.build['archive'], 'r:gz') as archive:
            cls.members = {}
            for item in archive:
                OPS.safe(item.name)
                if not item.isfile() or item.issym() or item.islnk(): raise AssertionError('nonregular local package')
                cls.members[item.name] = archive.extractfile(item).read()

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='observer-protocol-CPU-'); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve() / OPS.NAME; self.root.mkdir()
        for name, raw in self.members.items():
            path = self.root / name.removeprefix(OPS.NAME + '/')
            self.assertTrue(path.resolve().is_relative_to(self.root))
            path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(raw)
        self.source = {'schema_version': 1, 'task_id': JOB.TASK_ID, 'allocation_id': 'app-observer-synthetic-CPU-fixture'.lower(),
            'vendor': 'NVIDIA', 'visible_count': 1, 'observed_utc': '2026-11-07T00:00:00+00:00',
            'evidence_source': 'Synthetic CPU protocol fixture; not an actual platform allocation',
            'source_pins': JOB.source_pins(), 'source_manifest_sha256': self.build['source_manifest_sha256'],
            'expected_inventory_sha256': JOB.EXPECTED_JSON_SHA,
            'i04_prerequisite_path': str(self.root / 'prerequisite-i04/prerequisite.json'), 'i04_prerequisite_sha256': JOB.I04_PROOF_SHA,
            'cpu_prerequisite_path': str(self.root / 'prerequisite-cpu/prerequisite.json'), 'cpu_prerequisite_sha256': JOB.CPU_PROOF_SHA}
        for label, name in [('entry', JOB.ENTRY), ('lifecycle', JOB.LIFECYCLE), ('operations', JOB.OPERATIONS)]:
            self.source[label + '_path'] = str(self.root / name); self.source[label + '_sha256'] = JOB.sha(self.root / name)

    def source_file(self):
        JOB.put(self.root / JOB.SOURCE, self.source)

    def test_actual_stage_inventory_bounds_and_future_pin_failure(self):
        stage = JOB.read(CASE / 'observer-stage-v2.json'); self.assertEqual(JOB.sha(CASE / 'observer-stage-v2.json'), JOB.SPEC_SHA)
        for value, key in [(JOB.MAX_SECONDS, 'whole_attempt_timeout_seconds_per_backend'), (JOB.CAPTURE_SECONDS, 'gpu_capture_timeout_seconds'),
                           (JOB.MAX_CAPTURE_BYTES, 'maximum_capture_product_bytes_per_backend'), (JOB.MAX_TASK_BYTES, 'maximum_new_task_storage_bytes_per_backend')]:
            self.assertEqual(value, stage['limits'][key])
        self.assertEqual(JOB.WORK_SECONDS + JOB.METADATA_EXPORT_SECONDS + JOB.CLEANUP_SECONDS, 3600)
        self.assertEqual((JOB.WORK_SECONDS, JOB.CAPTURE_SECONDS), (2620, 1200))
        for name in ('SPEC_SHA', 'EXPECTED_JSON_SHA', 'I04_PROOF_SHA', 'CPU_PROOF_SHA'):
            with patch.object(JOB, name, None), self.assertRaisesRegex(ValueError, 'unready'): JOB.launch(self.root, self.fail, self.fail)
        with patch.dict(JOB.NEW_PINS, {JOB.COMMON: None}), self.assertRaisesRegex(ValueError, 'unready'): JOB.ready()
        self.assertFalse((self.root / 'claims').exists())

    def test_exact_actual35_ref_dual_proof_and32_original_aliases(self):
        checked, files, aliases = JOB.dual_prerequisite(self.source, self.root)
        self.assertEqual((len(checked['refs']), len(files), len(aliases)), (35, 35, 32))
        self.assertEqual(checked['native_executions_started'], 0)
        self.assertTrue(all(name.startswith('/home/') for name in aliases))
        self.assertFalse(any(name in sys.modules for name in ('torch', 'torch_npu', 'numpy', 'transformers')))

    def test_independent_expected_verifies_actual_four_geometry_docs(self):
        result = JOB.independent_expected(self.source, self.root)
        self.assertEqual(result['sha256'], JOB.EXPECTED_JSON_SHA)
        p = self.root / 'geometry/npu-loaded-inventory.json'; p.write_bytes(p.read_bytes() + b' ')
        with self.assertRaises(ValueError): JOB.independent_expected(self.source, self.root)

    def test_corrupt_original_CPU_or_I04_proof_never_claims_queries_or_restores(self):
        for prefix in ('i04', 'cpu'):
            with self.subTest(prefix=prefix):
                target = next((self.root / ('prerequisite-' + prefix) / 'proof').iterdir())
                original = target.read_bytes(); target.write_bytes(original + b' '); self.source_file()
                try:
                    with patch.object(JOB.sys, 'platform', 'linux'), self.assertRaises(ValueError):
                        JOB.launch(self.root, lambda *_a, **_k: self.fail('driver queried'), lambda *_a: self.fail('worker launched'))
                    self.assertFalse((self.root / 'claims').exists())
                finally:
                    target.write_bytes(original); (self.root / JOB.SOURCE).unlink()

    def test_frozen_source_geometry_and_generated_entry_all_in_manifest(self):
        JOB.validate_source(self.source, self.root); files = JOB.source_files(self.source, self.root)
        for name, digest in JOB.GEOMETRY.items(): self.assertEqual(files[str(self.root / 'geometry' / name)], digest)
        for old in ('REDACTED_APP_ID', 'REDACTED_APP_ID', 'REDACTED_APP_ID', 'REDACTED_APP_ID', 'REDACTED_APP_ID'):
            with self.assertRaises(ValueError): JOB.validate_source({**self.source, 'allocation_id': old}, self.root)
        manifest = OPS.read(self.root / JOB.MANIFEST)
        override = manifest['deployment_namespace_override']
        self.assertTrue(override['frozen_stage_declared_GPU_root'].endswith('-gpu-v1'))
        self.assertTrue(override['approved_GPU_root'].endswith('-gpu-v2'))
        self.assertFalse(override['literal_stage_root_agreement_claimed'])
        self.assertFalse(override['numeric_geometry_changed'])

    def test_concurrent_permanent_claim_has_one_winner(self):
        (self.root / 'claims').mkdir()
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda _: JOB.claim_once(self.root, 'app-synthetic', {'CPU_fixture': True}), range(16)))
        self.assertEqual(sum(x is not None for x in results), 1)

    def test_failed_driver_spends_claim_and_refuses_second_query(self):
        self.source_file()
        def bad(*_a, **_kw): return subprocess.CompletedProcess([], 7, b'', b'synthetic CPU fixture driver refusal')
        with patch.object(JOB.sys, 'platform', 'linux'):
            self.assertEqual(JOB.launch(self.root, bad, lambda *_a: self.fail('worker after query failure')), 1)
            self.assertEqual(JOB.launch(self.root, lambda *_a, **_k: self.fail('second driver'), lambda *_a: self.fail('second worker')), 0)
        self.assertTrue((self.root / 'claims' / self.source['allocation_id'] / 'launch-failure.json').is_file())

    def test_valid_metadata_query_uses_only_new_worker_and_work_deadline(self):
        self.source_file(); calls = []
        def query(*_a, **_k):
            return subprocess.CompletedProcess([], 0,
                b'GPU-REDACTED_DEVICE_UUID, NVIDIA H100 80GB HBM3, 580.95.05\n', b'')
        def worker(argv, directory, root, deadline, helper):
            calls.append(argv); self.assertEqual(root, self.root)
            self.assertLessEqual(deadline - time.monotonic(), JOB.WORK_SECONDS + JOB.CLEANUP_SECONDS)
            self.assertEqual(Path(argv[-3]).name, JOB.LIFECYCLE); self.assertEqual(argv[-2], '--worker')
            return 0, {'status': 'completed'}
        with patch.object(JOB.sys, 'platform', 'linux'):
            self.assertEqual(JOB.launch(self.root, query, worker), 0)
        self.assertEqual(len(calls), 1)
        claim = JOB.read(self.root / 'claims' / self.source['allocation_id'] / 'claim.json')
        self.assertEqual(claim['capture_seconds'], 1200); self.assertEqual(claim['whole_attempt_seconds'], 3600)

    def recorded_claim(self):
        self.source_file()
        state = {'schema_version': 1, 'task': 'OBSERVER', 'task_id': JOB.TASK_ID,
            'allocation_id': self.source['allocation_id'], 'source_sha256': JOB.sha(self.root / JOB.SOURCE),
            'entry_started_utc': '2026-11-07T00:00:00+00:00', 'claimed_utc': '2026-11-07T00:00:01+00:00',
            'entry_elapsed_before_claim_seconds': 1.0,
            'entry_sha256': self.source['entry_sha256'], 'lifecycle_sha256': self.source['lifecycle_sha256'],
            'i04_prerequisite_sha256': JOB.I04_PROOF_SHA, 'cpu_prerequisite_sha256': JOB.CPU_PROOF_SHA,
            'stage_spec_sha256': JOB.SPEC_SHA, 'collector_sha256': JOB.NEW_PINS[JOB.GPU],
            'independent_expected_sha256': JOB.EXPECTED_JSON_SHA, 'independent_expected_bytes': JOB.EXPECTED_JSON_BYTES,
            'whole_attempt_seconds': JOB.MAX_SECONDS, 'metadata_export_reserved_seconds': JOB.METADATA_EXPORT_SECONDS,
            'controller_work_seconds': JOB.WORK_SECONDS, 'capture_seconds': JOB.CAPTURE_SECONDS,
            'max_capture_bytes': JOB.MAX_CAPTURE_BYTES, 'max_new_task_bytes_sampled': JOB.MAX_TASK_BYTES,
            'logical_transport_cap': JOB.LOGICAL_TRANSPORT, 'encoded_transport_cap': JOB.ENCODED_TRANSPORT}
        directory = JOB.claim_once(self.root, self.source['allocation_id'], state)
        (directory / JOB.SOURCE).write_bytes((self.root / JOB.SOURCE).read_bytes())
        return directory

    def test_direct_worker_without_recorded_claim_refused_before_any_import_or_native(self):
        self.source_file(); directory = self.root / 'claims' / self.source['allocation_id']; directory.mkdir(parents=True)
        (directory / JOB.SOURCE).write_bytes((self.root / JOB.SOURCE).read_bytes())
        with patch.object(JOB, 'ROOT', self.root), patch.object(JOB, 'load_pinned', side_effect=AssertionError('import/restore/native before permanent claim')):
            with self.assertRaises(ValueError): JOB.worker(directory)
        self.assertFalse((directory / 'claim.json').exists()); self.assertFalse((directory / 'worker-once.json').exists())

    def test_claimed_worker_is_exclusive_and_never_creates_fresh_claim(self):
        directory = self.recorded_claim()
        refs = JOB.claim_bound_worker_once(directory, self.root, self.source)
        self.assertEqual(set(refs), {str(directory / 'claim.json'), str(directory / 'worker-once.json')})
        self.assertEqual(JOB.read(directory / 'worker-once.json')['native_executions_started_at_marker'], 0)
        with self.assertRaisesRegex(ValueError, 'marker already exists'):
            JOB.claim_bound_worker_once(directory, self.root, self.source)

    def test_worker_claim_allocation_proofs_and_source_cannot_be_substituted(self):
        directory = self.recorded_claim(); path = directory / 'claim.json'; original = JOB.read(path)
        for key in ('allocation_id', 'lifecycle_sha256', 'source_sha256', 'stage_spec_sha256', 'collector_sha256',
                    'i04_prerequisite_sha256', 'cpu_prerequisite_sha256', 'independent_expected_sha256'):
            bad = copy.deepcopy(original); bad[key] = 'b' * 64
            path.write_text(json.dumps(bad))
            with self.subTest(field=key), self.assertRaisesRegex(ValueError, 'permanent claim does not bind'):
                JOB.claim_bound_worker_once(directory, self.root, self.source)
            self.assertFalse((directory / 'worker-once.json').exists())
        path.write_text(json.dumps(original))
        (directory / JOB.SOURCE).write_bytes((directory / JOB.SOURCE).read_bytes() + b' ')
        with self.assertRaisesRegex(ValueError, 'platform source bytes differ'):
            JOB.claim_bound_worker_once(directory, self.root, self.source)

    def test_native_argv_binds_backend_and_both_actual_proofs(self):
        argv = JOB.capture_argv('/synthetic/python', '/synthetic/source', '/synthetic/claim', '/synthetic/run', self.source)
        self.assertEqual(argv[argv.index('--backend') + 1], 'gpu')
        self.assertEqual(argv[argv.index('--cpu-prerequisite-sha256') + 1], JOB.CPU_PROOF_SHA)
        self.assertEqual(argv[argv.index('--i04-prerequisite-sha256') + 1], JOB.I04_PROOF_SHA)
        self.assertNotIn('--input-b', argv); self.assertEqual(len([x for x in argv if x.startswith('--')]), len(set(x for x in argv if x.startswith('--'))))

    def test_windows_package_actual_original_bytes_pass_Linux_production_guards(self):
        program = '''from pathlib import Path
import tempfile,tarfile,importlib.util,json,sys
archive=Path(sys.argv[1])
with tempfile.TemporaryDirectory(prefix='observer-win-to-linux-') as temp:
 base=Path(temp);root=base/'observer-transparency-20261107-gpu-v2'
 with tarfile.open(archive,'r:gz') as package:
  for member in package:
   assert member.isfile() and not member.issym() and not member.islnk()
   path=base/member.name;assert path.resolve().is_relative_to(base)
   path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(package.extractfile(member).read())
 spec=importlib.util.spec_from_file_location('observer_actual_linux_ops',root/'build_h100_observer_source_package_v2.py');ops=importlib.util.module_from_spec(spec);spec.loader.exec_module(ops)
 job=ops.module(root/'h100_observer_lifecycle_v2.py')
 manifest=ops.read(root/'source-manifest.json')
 for relative,ref in manifest['files'].items():assert ops.sha(root/relative)==ref['sha256']
 ops.check_shell_and_operations(root,job)
 source={'expected_inventory_sha256':job.EXPECTED_JSON_SHA,'i04_prerequisite_path':str(root/'prerequisite-i04/prerequisite.json'),'i04_prerequisite_sha256':job.I04_PROOF_SHA,'cpu_prerequisite_path':str(root/'prerequisite-cpu/prerequisite.json'),'cpu_prerequisite_sha256':job.CPU_PROOF_SHA}
 assert len(job.dual_prerequisite(source,root)[1])==35
 job.independent_expected(source,root)
 entry=root/ops.ENTRY;raw=entry.read_bytes();assert b"'/data/afs-2026/" in raw and b'\\\\data' not in raw
 entry.write_bytes(raw.replace(b'/data/afs-2026/',b'\\\\data\\\\afs-2026\\\\'))
 try:ops.check_shell_and_operations(root,job)
 except ValueError:pass
 else:raise AssertionError('backslash startup accepted')
 assert not any(name in sys.modules for name in ('torch','torch_npu','numpy','transformers'))
 print('actual35 proofs and POSIX source guard passed; backslash mutation rejected; no native')
'''
        archive = self.build['archive']
        if os.name == 'nt':
            converted = subprocess.run(['wsl.exe', '-d', 'Ubuntu-24.04', '--exec', 'wslpath', '-a', archive], capture_output=True, text=True, timeout=20, check=True).stdout.strip()
            argv = ['wsl.exe', '-d', 'Ubuntu-24.04', '--exec', 'python3', '-S', '-B', '-c', program, converted]
        else: argv = [sys.executable, '-S', '-B', '-c', program, archive]
        result = subprocess.run(argv, capture_output=True, timeout=50)
        self.assertEqual(result.returncode, 0, result.stderr.decode(errors='replace'))
        self.assertIn(b'actual35 proofs and POSIX source guard passed', result.stdout)

    def test_capture_inventory_rejects_missing_row_or_unplanned_tensor(self):
        modes = ['off-before', 'hooks-only', 'off-after', 'hooks-plus-dispatch-metadata']; positions = sorted({i * 127 // 15 for i in range(16)} | set(range(127, 159)))
        names = {f'modes/{mode}/raw-native-logits.safetensors' for mode in modes}
        names |= {f'modes/{mode}/dist-p{p:03d}.npy' for mode in modes for p in positions}
        names |= {f'modes/{mode}/boundary-samples.safetensors' for mode in modes[1::2]}
        files = {name: {'synthetic_descriptor': True} for name in names}
        files.update({f'synthetic-small-{i}.json': {} for i in range(452 - len(names))})
        folder = self.root / 'structural-only'; folder.mkdir(); p = folder / 'artifacts-manifest.json'
        p.write_text(json.dumps({'capture_schema_version': 2, 'files': files})); self.assertEqual(JOB.validate_large_inventory(folder)['large_files'], 194)
        missing = next(name for name in files if name.endswith('.npy')); files['unplanned.npy'] = files.pop(missing)
        p.write_text(json.dumps({'capture_schema_version': 2, 'files': files}))
        with self.assertRaises(ValueError): JOB.validate_large_inventory(folder)


class SafePackage(unittest.TestCase):
    def test_paths_JSON_and_POSIX_startup(self):
        for name in ('/root', '../old', './x', 'x//y', 'x/../y', 'x\\y'):
            with self.assertRaises(ValueError): OPS.safe(name)
        windows = SimpleNamespace(ROOT=PureWindowsPath(JOB.ROOT.as_posix()), HEX=JOB.HEX)
        self.assertEqual(OPS.shell_bytes(windows, 'a' * 64), OPS.shell_bytes(JOB, 'a' * 64))
        self.assertNotIn(b'\\data', OPS.shell_bytes(windows, 'a' * 64))

    def test_bad_archive_topology_refused_before_new_root(self):
        for corruption in ('duplicate', 'traversal', 'symlink', 'hardlink', 'ancestor'):
            with self.subTest(corruption=corruption), tempfile.TemporaryDirectory() as temp:
                base = Path(temp).resolve(); fake = SimpleNamespace(TASK=base, TASK_ID=JOB.TASK_ID, MANIFEST=JOB.MANIFEST, CPU_PROOF_SHA=JOB.CPU_PROOF_SHA, MIN_FREE=1)
                raw_sources = {JOB.LIFECYCLE: (HERE / JOB.LIFECYCLE).read_bytes(), JOB.OPERATIONS: (HERE / JOB.OPERATIONS).read_bytes()}
                if corruption == 'ancestor': raw_sources.update({'collision': b'x', 'collision/file': b'y'})
                manifest = {'task_id': JOB.TASK_ID, 'cpu_prerequisite_sha256': JOB.CPU_PROOF_SHA, 'files': {name: {'kind': 'code', 'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw)} for name, raw in raw_sources.items()}}
                raw = json.dumps(manifest).encode(); raw_sources[JOB.MANIFEST] = raw; archive = base / 'synthetic.tar'
                with tarfile.open(archive, 'w') as tar:
                    for name, body in raw_sources.items():
                        item = tarfile.TarInfo(OPS.NAME + '/' + name); item.size = len(body); tar.addfile(item, io.BytesIO(body))
                    item = tarfile.TarInfo(OPS.NAME + '/../escape' if corruption == 'traversal' else OPS.NAME + '/link')
                    if corruption == 'duplicate': item.name = OPS.NAME + '/' + JOB.MANIFEST; item.size = len(raw); tar.addfile(item, io.BytesIO(raw))
                    elif corruption in ('symlink', 'hardlink'):
                        item.type = tarfile.SYMTYPE if corruption == 'symlink' else tarfile.LNKTYPE; item.linkname = JOB.LIFECYCLE; tar.addfile(item)
                    elif corruption == 'traversal': tar.addfile(item)
                with patch.object(OPS, 'module', return_value=fake), patch.object(OPS, 'ready'), patch.object(OPS, 'validate', side_effect=AssertionError('must refuse before writing')):
                    with self.assertRaises(ValueError): OPS.stage(base, archive, OPS.sha(archive), hashlib.sha256(raw).hexdigest())
                self.assertFalse((base / OPS.NAME).exists())


@unittest.skipUnless(sys.platform.startswith('linux'), 'Actual Linux CPU process ownership checks')
class OwnedCPUProcesses(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.helper = JOB.load_pinned(HERE / 'npu_three_repeat_launcher_v4.py', JOB.CLEANUP_SHA, 'observer_CPU_cleanup_under_test')

    def execute(self, script, seconds=.7):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); folder = root / 'receipt'; folder.mkdir(); start = time.monotonic()
            code, state = JOB.supervise([sys.executable, '-c', script], folder, root, start + JOB.CLEANUP_SECONDS + seconds, self.helper)
            self.assertLess(time.monotonic() - start, seconds + 12); self.assertEqual(state['remaining_descendants'], [])
            self.assertEqual(JOB.read(folder / 'controller-receipt.json')['returncode'], code)
            return code

    def test_successful_CPU_worker(self):
        self.assertEqual(self.execute("print('CPU protocol only; no model')"), 0)

    def test_timeout_reaps_escaped_TERM_resistant_grandchild(self):
        child = 'import os,signal,time;os.setsid();signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(60)'
        parent = "import subprocess,sys,signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);subprocess.Popen([sys.executable,'-c',%r]);time.sleep(60)" % child
        self.assertEqual(self.execute(parent), 124)

    def test_orphan_is_failed_and_reaped(self):
        child = 'import os,time;os.setsid();time.sleep(60)'
        self.assertEqual(self.execute("import subprocess,sys,time;subprocess.Popen([sys.executable,'-c',%r]);time.sleep(.2)" % child), 1)

    def test_parent_TERM_preserves_failure_receipt_and_cleans_owned_worker(self):
        program = '''import importlib.util,pathlib,signal,sys,time
p=pathlib.Path(sys.argv[1]);root=pathlib.Path(sys.argv[2]);folder=root/'receipt';folder.mkdir()
s=importlib.util.spec_from_file_location('observer_external_parent_test',p);j=importlib.util.module_from_spec(s);s.loader.exec_module(j)
h=j.load_pinned(p.parent/'npu_three_repeat_launcher_v4.py',j.CLEANUP_SHA,'external_parent_cleanup')
def interrupted(*args):raise KeyboardInterrupt()
signal.signal(signal.SIGTERM,interrupted)
child="import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);print('worker-ready',flush=True);time.sleep(60)"
code,state=j.supervise([sys.executable,'-c',child],folder,root,time.monotonic()+60,h)
sys.exit(code)
'''
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            with (root / 'parent.stdout').open('wb') as out, (root / 'parent.stderr').open('wb') as err:
                process = subprocess.Popen([sys.executable, '-S', '-B', '-c', program, str(HERE / JOB.LIFECYCLE), str(root)], stdout=out, stderr=err)
                try:
                    deadline = time.monotonic() + 10; ready = root / 'receipt/worker.stdout'
                    while time.monotonic() < deadline and (not ready.exists() or b'worker-ready' not in ready.read_bytes()):
                        self.assertIsNone(process.poll()); time.sleep(.02)
                    self.assertTrue(ready.exists() and b'worker-ready' in ready.read_bytes())
                    process.terminate(); self.assertEqual(process.wait(timeout=12), 1)
                finally:
                    if process.poll() is None: process.kill(); process.wait(timeout=5)
            receipt = JOB.read(root / 'receipt/controller-receipt.json')
            self.assertEqual(receipt['remaining_descendants'], [])
            self.assertEqual(receipt['error_type'], 'KeyboardInterrupt')
            self.assertEqual(receipt['returncode'], 1)


if __name__ == '__main__': unittest.main()

"""Independent stdlib arithmetic and native payload identity for GPU observer.

The pinned I03 independent verifier supplies binary/scalar primitives only.
Original comparator functions and native framework/model APIs are never used.
NumPy is imported solely to bind the original common-CPU implementation version;
its numerical functions are not used for these independent reductions.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import itertools
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import signal
import struct
import sys
import time
import traceback
import zipfile

HERE = Path(__file__).resolve().parent
CASE = HERE.parent
BASE_SHA = '863019a1bd9875d418630c4c5e547576232e225fd66a98d63d51f3023701a44e'
MODES = ['off-before', 'hooks-only', 'off-after', 'hooks-plus-dispatch-metadata']
POSITIONS = sorted(set(j * 127 // 15 for j in range(16)) | set(range(127, 159)))
VOCAB = 262144


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024**2), b''): h.update(block)
    return h.hexdigest()


path = HERE / 'verify_i03_selected_e02_v1.py'
require(sha(path) == BASE_SHA, 'independent stdlib primitive bytes differ')
_spec = importlib.util.spec_from_file_location('_observer_e02_independent_primitives', path)
base = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(base)
parse, canonical, put = base.parse, base.canonical, base.put


def equal(actual, expected, label):
    """Exact structure/identities; scalar diagnostics use the pinned tolerance."""
    if isinstance(actual, dict):
        require(isinstance(expected, dict) and set(actual) == set(expected), 'independent object inventory differs: ' + label)
        for key, value in actual.items(): equal(value, expected[key], label + '/' + key)
    elif isinstance(actual, (list, tuple)):
        require(isinstance(expected, (list, tuple)) and len(actual) == len(expected), 'independent coordinate inventory differs: ' + label)
        for index, value in enumerate(actual): equal(value, expected[index], label + '/' + str(index))
    elif type(actual) in (str, bool, int):
        require(type(expected) is type(actual) and actual == expected, 'independent discrete value differs: ' + label)
    elif actual is None and expected is None: return
    else: base.equal(actual, expected, label)


def ref(path):
    path = Path(path); require(path.is_file() and not path.is_symlink(), 'regular original file required')
    return {'path': str(path.resolve()), 'sha256': sha(path), 'size_bytes': path.stat().st_size}


def case_path(name):
    p = PurePosixPath(name)
    require(type(name) is str and not p.is_absolute() and str(p) == name and '\\' not in name and
            ':' not in name and all(x not in ('', '.', '..') for x in name.split('/')), 'canonical case-relative path required')
    result = CASE.joinpath(*p.parts)
    require(result.resolve(strict=True).is_relative_to(CASE.resolve()), 'proof path escapes private case')
    return result


class Audit(base.Audit):
    def tick(self):
        if time.monotonic() >= self.deadline: raise TimeoutError('observer GPU independent E02 deadline')


class Endpoint(base.Endpoint):
    def __init__(self, audit, path, digest, request):
        self.audit, self.backend, self.root = audit, 'GPU', None
        self.path = audit.file(path, digest); self.document = audit.json(self.path, digest); self.files = self.document['files']
        require(self.document['schema_version'] == 1 and self.document['request'] == request and request['task'] == 'OBSERVER' and
                request['backend'] == 'GPU' and len(self.files) == 672, 'exact admitted GPU observer source map required')

    def locate(self, name, expected=None):
        result, value = super().locate(name, expected)
        current = result
        while current != self.path.parent:
            require(not current.is_symlink(), 'copied original ancestor link'); current = current.parent
        require('path' in value and not value.get('retained_at_source'), 'GPU evidence must be fully copied')
        return result, value


def source_chain(spec, audit):
    objects = {}
    for role, value in spec['objects'].items():
        p = case_path(value['case_path']); objects[role] = audit.file(p, value['sha256'])
        require(p.stat().st_size == value['size_bytes'], 'frozen actual dependency size differs')
    controller, report, profile = [audit.json(objects[key]) for key in ('controller', 'report', 'profile')]
    require(controller['task'] == 'OBSERVER-GPU-only-CPU' and controller['status'] == 'completed' and
            controller['returncode'] == controller['child_returncode'] == 0 and controller['timed_out'] is False and
            controller['source_timed_out'] is False and controller['remaining_owned_process_group'] is False and
            controller['native_executions_started'] == 0 and controller['automatic_retry'] is False and
            controller['report']['sha256'] == spec['objects']['report']['sha256'] and
            controller['report']['path'] == spec['actual_report_source_path'] and
            controller['profile_sha256'] == spec['objects']['profile']['sha256'] and
            controller['driver_sha256'] == spec['objects']['driver']['sha256'], 'actual completed CPU controller/report/source chain differs')
    argv = controller['argv']; require(len(argv) > 4 and argv[1:3] == ['-S', '-B'] and '--internal-worker' in argv and
        argv[3].endswith('/transfer/run_observer_gpu_only_admission_v3.py'), 'actual direct frozen CPU driver argv required')
    for name, key in (('--profile', 'profile'), ('--source-map', 'original_input_source_map')):
        require(argv.count(name) == 1 and argv[argv.index(name) + 1].endswith('/' + spec['objects'][key]['case_path']),
                'actual CPU argv dependency detached')
    require(audit.json(objects['worker'])['report'] == controller['report'] and
            controller['worker_receipt']['sha256'] == spec['objects']['worker']['sha256'] and
            report['status'] == 'actual_GPU_only_observer_raw_BF16_and_sampled_comparisons_checked' and
            report['profile_sha256'] == controller['profile_sha256'] and report['driver_sha256'] == controller['driver_sha256'] and
            report['native_executions_started_by_this_admission'] == 0 and report['acceptance'] is report['thresholds'] is None,
            'original completed worker/report identity or scope differs')
    for filename, digest in report['offline_tool_source_sha256'].items():
        role = 'transfer' if filename.startswith(('split_', 'reassemble_')) else 'adapters'
        p = case_path(role + '/' + filename); audit.file(p, digest)
        require(profile['original_sources'][filename] == digest, 'frozen original analysis source/profile differs')
    require(profile['source_map_sha256'] == report['original_source_map_sha256'] == spec['objects']['source_map']['sha256'] and
            spec['objects']['original_input_source_map']['sha256'] == spec['objects']['source_map']['sha256'] and
            profile['outer_receipt']['sha256'] == report['original_outer_receipt_sha256'] == spec['native_outer_sha256'] and
            profile['native_controller_sha256'] == report['source_native_controller_sha256'] == spec['native_controller_sha256'] and
            profile['artifacts_manifest_sha256'] == spec['artifacts_manifest_sha256'] and
            report['input_reuse'] == audit.json(objects['import_receipt']) and
            report['scope']['within_GPU_target_distribution_pairs'] == 6 and report['scope']['distribution_pair_rows'] == 282 and
            report['scope']['boundary_tensor_pairs'] == 98 and report['scope']['NPU_activated'] is False,
            'actual source-map/native authority or GPU-only scope differs')
    require(profile['prior_import']['source_root'].endswith('/' + spec['objects']['source_map']['case_path'].removesuffix('/source-map.json')),
            'explicit reused import location differs from admitted original map')
    endpoint = Endpoint(audit, objects['source_map'], spec['objects']['source_map']['sha256'], spec['original_map_request'])
    outer = endpoint.json(spec['original_map_request']['outer_receipt'], spec['native_outer_sha256']); output = outer['output_dir']
    claim = str(PurePosixPath(spec['original_map_request']['outer_receipt']).parent)
    require(outer['status'] == 'completed' and outer['returncode'] == 0 and outer['timed_out'] is False and
            outer['backend'] == 'GPU' and outer['input_sha256'] == spec['input_sha256'] and outer['native_capture_count'] == 1 and
            outer['model_loads'] == 1 and outer['native_forward_calls_total'] == 4, 'original single-load four-forward native authority differs')
    native_controller = endpoint.json(base.child(claim, 'controller-receipt.json'), spec['native_controller_sha256'])
    require(native_controller['status'] == 'completed' and native_controller['returncode'] == 0 and
            native_controller['remaining_descendants'] == [] and native_controller['timed_out'] is False, 'original native controller is incomplete')
    require(endpoint.json(base.child(claim, 'sources-before.json')) == endpoint.json(base.child(claim, 'sources-after.json')) ==
            outer['source_sha256'] and set(outer['dependency_paths']) == set(outer['source_sha256']), 'original source freeze differs')
    for name, digest in outer['source_sha256'].items(): endpoint.get(name, digest)
    manifest = endpoint.json(base.child(output, 'artifacts-manifest.json'), spec['artifacts_manifest_sha256'])['files']
    expected = endpoint.json(base.child(output, 'expected-inventory.json'), spec['expected_inventory_sha256'])
    require(expected['modes'] == MODES == spec['modes'] and expected['distribution_positions'] == POSITIONS == spec['distribution_positions'] and
            [x['id'] for x in expected['boundaries']] == spec['sample_boundaries'] and len(spec['sample_boundaries']) == 98 and
            expected['input_sha256'] == spec['input_sha256'] and expected['stage_spec_sha256'] == spec['stage_spec_sha256'], 'predeclared independent coordinate inventory differs')
    large = {base.child(output, 'modes/' + mode + '/raw-native-logits.safetensors') for mode in MODES}
    large |= {base.child(output, 'modes/' + mode + '/dist-p%03d.npy' % p) for mode in MODES for p in POSITIONS}
    large |= {base.child(output, 'modes/' + mode + '/boundary-samples.safetensors') for mode in spec['sample_pair_modes']}
    require(len(large) == 194 and {name for name in endpoint.files if name.endswith(('.npy', '.safetensors'))} == large and
            {base.child(output, name) for name in manifest if name.endswith(('.npy', '.safetensors'))} == large,
            'exact194 native/derived large files required')
    # First full pool pass precedes scalar decoding; raw-byte membership is
    # frozen before values, and the second pass occurs after all reductions.
    for name, item in endpoint.files.items(): endpoint.get(name, item['sha256'])
    require(len({str(endpoint.get(name)) for name in large}) == 194, 'distinct original large observations may not alias')
    for relative, item in manifest.items():
        name = base.child(output, relative); require(endpoint.files[name]['sha256'] == item['sha256'] and
            endpoint.files[name]['size'] == item['size_bytes'], 'original product manifest/source-map differs')
    return objects, report, endpoint, output, expected, sorted(large)


def validate_spec(spec):
    require(spec['kind'] == 'observer-GPU-only-independent-E02-spec-v3' and
        spec['status'] == 'selection_frozen_before_tensor_reads' and spec['cpu_seconds'] == 900 and
        spec['modes'] == MODES and spec['pair_modes'] == [list(x) for x in itertools.combinations(MODES, 2)] and
        spec['sample_pair_modes'] == ['hooks-only', 'hooks-plus-dispatch-metadata'] and
        spec['distribution_positions'] == POSITIONS and len(spec['sample_boundaries']) == len(set(spec['sample_boundaries'])) == 98 and
        spec['arithmetic_diagnostic_tolerance'] == {'absolute': base.ATOL, 'relative': base.RTOL,
            'source_sha256': BASE_SHA, 'model_acceptance_threshold': None} and
        spec['scope'] == {'target_pairs': 6, 'targets_per_pair': 159, 'distribution_pair_rows': 282,
            'distribution_rows_per_pair': 47, 'boundary_tensor_pairs': 98, 'global_sample_elements': 294784,
            'large_sources': 194, 'large_hash_passes': 2, 'raw_logits_files': 4, 'BF16_values_per_raw_file': 41943040,
            'sample_pack_files': 2} and spec['native_executions_started'] == 0 and spec['acceptance'] is None,
        'predeclared complete6/282/98/194 E02 scope differs')


def tensor_payload(path, expected_shapes, audit=None):
    """Hash only BF16 data bytes, with canonical named geometry framing too."""
    start, header = base.native_header(path)
    require(set(header) == set(expected_shapes) and all(header[key]['shape'] == shape for key, shape in expected_shapes.items()),
            'BF16 payload named geometry differs')
    framed = hashlib.sha256(b'BF16-canonical-tensor-payload-v1\0'); values = 0; per_tensor = {}
    with Path(path).open('rb') as stream:
        stream.seek(start); physical = hashlib.sha256()
        for block in iter(lambda: stream.read(4 * 1024**2), b''):
            if audit: audit.tick()
            physical.update(block)
        for key in sorted(header):
            record = header[key]; lo, hi = record['data_offsets']; count = base.shape_size(record['shape']); values += count
            frame = canonical({'tensor': key, 'dtype': 'BF16', 'shape': record['shape'], 'data_bytes': hi - lo}).encode()
            framed.update(struct.pack('<Q', len(frame))); framed.update(frame); own = hashlib.sha256()
            stream.seek(start + lo); remaining = hi - lo
            while remaining:
                if audit: audit.tick()
                block = stream.read(min(4 * 1024**2, remaining)); require(block, 'truncated BF16 data payload')
                framed.update(block); own.update(block); remaining -= len(block)
            per_tensor[key] = {'shape': record['shape'], 'values': count, 'data_sha256': own.hexdigest()}
    return {'source': ref(path), 'tensor_count': len(header), 'BF16_values': values,
        'physical_data_payload_sha256': physical.hexdigest(), 'canonical_framed_sha256': framed.hexdigest(),
        'header_bytes_excluded': start, 'per_tensor': per_tensor}


def same_payloads(items):
    require(len(items) >= 2, 'paired payload records required')
    return {'all_equal': len({x['canonical_framed_sha256'] for x in items.values()}) == 1,
        'physical_data_payloads_equal': len({x['physical_data_payload_sha256'] for x in items.values()}) == 1,
        'files': items, 'file_headers_excluded': True, 'numeric_zero_was_not_used_as_bit_equality_evidence': True}


def compare_distribution(actual, shared):
    for key in ('union_count', 'top1_agreement', 'top100_overlap', 'probability_rmse', 'max_probability_error', 'max_error_token'):
        equal(actual[key], shared[key], key)
    equal(actual['tail_merged_js'], shared['tail_merged_js']['value'], 'tail JS')
    for key in ('coverage', 'normalization_mass'):
        for role, value in actual[key].items(): equal(value, shared[key][role], key + '/' + role)


def summarize_distribution(rows, shared):
    diagnostics = {}
    for field in ('probability_rmse', 'max_probability_error', 'tail_merged_js'):
        values = [row[field] for row in rows]
        for metric, value in (('mean', math.fsum(values) / len(values)), ('p99', base.quantile(values, .99)), ('max', max(values))):
            equal(value, shared[field][metric], 'distribution summary/' + field + '/' + metric)
        worst = values.index(max(values)); coordinate = {'sample': rows[worst]['sample'], 'position': rows[worst]['position']}
        if field == 'max_probability_error': coordinate['token'] = rows[worst]['max_error_token']
        reported = shared[field]['max_coordinate']
        require(set(reported) == set(coordinate), 'reported maximum coordinate fields differ')
        selected = [row for row in rows if row['sample'] == reported['sample'] and row['position'] == reported['position']]
        require(len(selected) == 1, 'reported maximum must be one actually replayed row')
        if field == 'max_probability_error': equal(reported['token'], selected[0]['max_error_token'], 'maximum token coordinate')
        # Independent exp/log/FSUM arithmetic may leave sub-ULP residuals at
        # identical distributions. Verify the reported location reaches the
        # independently replayed maximum under the SAME scalar diagnostic
        # tolerance; retain the exact unrounded independent argmax separately.
        base.equal(selected[0][field], max(values), 'reported maximum value at replayed coordinate/' + field)
        diagnostics[field] = {'reported_max_coordinate': reported, 'independent_exact_max_coordinate': coordinate,
            'independent_unrounded_max_value': max(values), 'independent_value_at_reported_coordinate': selected[0][field],
            'coordinate_checked_with_same_scalar_diagnostic_tolerance': True,
            'diagnostic_absolute_tolerance': base.ATOL, 'diagnostic_relative_tolerance': base.RTOL,
            'model_acceptance_threshold': None}
    equal(sum(x['top1_agreement'] for x in rows), shared['top1_agreement']['count'], 'top1 count')
    equal(len(rows), shared['top1_agreement']['total'], 'top1 inventory')
    equal(sum(x['top1_agreement'] for x in rows) / len(rows), shared['top1_agreement']['fraction'], 'top1 fraction')
    equal(math.fsum(x['top100_overlap'] for x in rows) / len(rows), shared['top100_overlap']['mean'], 'overlap mean')
    for role in rows[0]['coverage']:
        values = [row['coverage'][role] for row in rows]
        for metric, value in (('mean', math.fsum(values) / len(values)), ('p1', base.quantile(values, .01)), ('min', min(values))):
            equal(value, shared['coverage'][role][metric], 'coverage summary/' + role + '/' + metric)
    return diagnostics


def input_sequence(expected):
    sequence = expected['sequence']
    require(isinstance(sequence, list) and len(sequence) == 160 and
            all(type(token) is int and 0 <= token < VOCAB for token in sequence) and
            expected['input_ids'] == [sequence] and expected['attention_mask'] == [[1] * 160] and
            expected['position_ids'] == [list(range(160))],
            'exact flat sequence plus batched1x160 IDs/mask/absolute positions required')
    return sequence


def replay(spec, audit, report, endpoint, output, expected):
    sequence, sample = input_sequence(expected), expected['sample']; targets = {}; payloads = {}
    for mode in MODES:
        prefix = base.child(output, 'modes/' + mode); doc = endpoint.json(base.child(prefix, 'target-scores.json'))
        require(doc['mode'] == mode and doc['input_sha256'] == spec['input_sha256'] and len(doc['scores']) == 159, 'exact causal target vector required')
        for p, item in enumerate(doc['scores']):
            require(item['sample'] == sample and item['position'] == p + 1 and item['prediction_position'] == p and
                    type(item['token']) is int and item['token'] == sequence[p + 1], 'causal target shift/token differs')
        targets[mode] = [item['logprob'] for item in doc['scores']]
        payloads[mode] = tensor_payload(endpoint.get(base.child(prefix, 'raw-native-logits.safetensors')), {'logits': [1, 160, VOCAB]}, audit)
        require(payloads[mode]['BF16_values'] == 41943040, 'full160xV BF16 raw payload required')
    require(spec['pair_modes'] == [list(x) for x in itertools.combinations(MODES, 2)] and len(report['target_distribution_pairs']) == 6,
            'predeclared six within-GPU pairs required')
    coords = [{'sample': sample, 'position': p, 'token': sequence[p]} for p in range(1, 160)]; checks = []
    for index, modes in enumerate(spec['pair_modes']):
        original = report['target_distribution_pairs'][index]
        require(original['sides'] == ['gpu-' + m for m in modes] and original['targets']['status'] ==
                original['distributions']['status'] == 'no_thresholds' and original['distributions']['position_count'] == 47 and
                original['distributions']['renormalization'] == 'none', 'original pair scope/order differs')
        target = base.target_metrics(targets[modes[0]], targets[modes[1]], coords)
        for key, value in target.items(): equal(value, original['targets']['metrics'][key], 'target/' + key)
        distribution = []
        for position, shared in zip(POSITIONS, original['distributions']['positions']):
            audit.tick(); require(shared['sample'] == sample and shared['position'] == position, 'exact all47 predictor positions required')
            rows = [base.read_npy(endpoint.get(base.child(output, 'modes/' + mode + '/dist-p%03d.npy' % position))) for mode in modes]
            actual = base.distribution_metrics(*rows); compare_distribution(actual, shared)
            distribution.append({'sample': sample, 'position': position, **actual}); del rows
        diagnostics = summarize_distribution(distribution, original['distributions']['aggregate'])
        checks.append({'pair_index': index, 'modes': modes, 'targets': target, 'distribution_rows': distribution,
            'distribution_maximum_coordinate_diagnostics': diagnostics})
    sample_modes = spec['sample_pair_modes']; sample_payloads = {}; sample_paths = {}
    shapes = {key: [1, 47, 64] for key in spec['sample_boundaries']}
    for mode in sample_modes:
        sample_paths[mode] = endpoint.get(base.child(output, 'modes/' + mode + '/boundary-samples.safetensors'))
        sample_payloads[mode] = tensor_payload(sample_paths[mode], shapes, audit)
        require(sample_payloads[mode]['BF16_values'] == 294784, 'all98x47x64 sampled values required')
    original = report['boundary_sample_comparisons']; require(len(original) == 1 and original[0]['sides'] == ['gpu-' + m for m in sample_modes],
                                                            'one declared within-GPU boundary pair required')
    shared = original[0]['metrics']; require(set(shared['per_tensor']) == set(shapes), 'exact98 named tensor reductions required')
    tensors = {}; global_a, global_b = [], []
    for key in sorted(shapes):
        audit.tick(); values = [base.native_values(sample_paths[mode], key, 0, 3008, [1, 47, 64]) for mode in sample_modes]
        metrics = base.tensor_metrics(*values); target = shared['per_tensor'][key]
        for field, value in metrics.items(): equal(value, target[field], key + '/' + field)
        boundary = next(x for x in expected['boundaries'] if x['id'] == key)
        coordinates = {'sample': sample, 'boundary': key, 'module': boundary['module'], 'when': boundary['when'],
            'token_indices': POSITIONS, 'channel_indices': expected['channels']}
        equal(target['coordinates'], coordinates, key + '/sample coordinate inventory')
        equal(target['max_coordinate'], base.unravel(metrics['max_flat_index'], [1, 47, 64]), key + '/max coordinate')
        global_a.extend(values[0]); global_b.extend(values[1]); tensors[key] = metrics
    global_metrics = base.tensor_metrics(global_a, global_b)
    for key, value in global_metrics.items():
        equal(value, shared['global'][key], 'global samples/' + key)
    tensor_index, index = divmod(global_metrics['max_flat_index'], 3008); tensor = sorted(shapes)[tensor_index]
    equal(shared['global']['max_coordinate'], {'tensor': tensor, 'index': index, 'coordinate': base.unravel(index, [1, 47, 64]),
        'observation': shared['per_tensor'][tensor]['coordinates']}, 'global samples max coordinate')
    return {'target_distribution_checks': checks, 'boundary_samples': {'per_tensor': tensors, 'global': global_metrics},
        'payload_identity': {'raw_logits': same_payloads(payloads), 'boundary_samples': same_payloads(sample_payloads)}}


def verify(spec_path, spec_sha, output):
    output = Path(output).absolute(); require(re.fullmatch(r'compare-observer-gpu-e02-[0-9]{8}T[0-9]{6}Z', output.name) and
        output.parent.is_dir() and not output.exists() and not output.is_symlink(), 'exclusive canonical new E02 run required')
    require(os.name == 'posix', 'bounded actual E02 requires Linux CPU process')
    started = time.monotonic(); output.mkdir(mode=0o700); audit = Audit(880); controller = {'schema_version': 1,
        'task': 'OBSERVER-GPU-E02', 'status': 'running', 'started_utc': datetime.now(timezone.utc).isoformat(), 'whole_seconds': 900,
        'native_executions_started': 0, 'subprocesses_started': 0, 'acceptance': None, 'automatic_retry': False}
    prior = signal.getsignal(signal.SIGALRM)
    def timeout(*_): raise TimeoutError('observer independent E02 whole900s deadline')
    signal.signal(signal.SIGALRM, timeout); signal.setitimer(signal.ITIMER_REAL, 890)
    try:
        verifier_sha = sha(__file__); audit.file(__file__, verifier_sha)
        spec = audit.json(spec_path, spec_sha); validate_spec(spec)
        put(output / 'frozen-selection.json', spec); controller['selection'] = ref(output / 'frozen-selection.json')
        objects, report, endpoint, native_output, expected, large = source_chain(spec, audit)
        wheel = objects['numpy_wheel']; numpy_site = output / 'numpy-site'; numpy_site.mkdir()
        with zipfile.ZipFile(wheel) as archive: archive.extractall(numpy_site)
        require(sha(numpy_site / 'numpy/__init__.py') == spec['numpy_init_sha256'], 'actual common-CPU NumPy source differs')
        sys.path.insert(0, str(numpy_site)); import numpy as np
        require(np.__version__ == '1.26.4' and Path(np.__file__).resolve() == numpy_site / 'numpy/__init__.py', 'actual CPU NumPy import differs')
        result = replay(spec, audit, report, endpoint, native_output, expected)
        for name in large: endpoint.get(name, force=True)
        audit.recheck_small(); require(not any(x in sys.modules for x in ('torch', 'torch_npu', 'transformers')), 'independent replay imported a framework')
        document = {'schema_version': 1, 'status': 'independent_observer_GPU_E02_matched', 'selection': controller['selection'],
            'scope': spec['scope'], 'all_metrics_matched': True, **result, 'source_controller': spec['objects']['controller'],
            'source_report': spec['objects']['report'], 'source_map': spec['objects']['source_map'],
            'original_large_sources': {name: audit.originals[name] for name in large}, 'large_hash_passes': 2,
            'independent_arithmetic': 'I03 pinned stdlib scalar/BF16/FP64 helpers, no original comparator functions',
            'source_sha256': {'verifier': verifier_sha, 'spec': spec_sha, 'independent_primitives': BASE_SHA},
            'numpy': {'version': np.__version__, 'source_sha256': sha(np.__file__), 'arithmetic_used': False},
            'native_executions_started': 0, 'thresholds': None, 'acceptance': None, 'full_core_complete': False,
            'limitations': spec['limitations']}
        put(output / 'e02-report.json', document); controller.update(status='completed', returncode=0, timed_out=False, report=ref(output / 'e02-report.json'))
    except BaseException as exc:
        controller.update(status='failed', returncode=124 if isinstance(exc, TimeoutError) else 1, timed_out=isinstance(exc, TimeoutError),
            error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0); signal.signal(signal.SIGALRM, prior)
        controller.update(finished_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.monotonic() - started,
            verifier_sha256=sha(__file__), spec_sha256=spec_sha, modified_original_sources=False)
        put(output / 'controller-receipt.json', controller)
    return controller


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('--spec', type=Path, required=True)
    p.add_argument('--spec-sha256', required=True); p.add_argument('--output', type=Path, required=True); args = p.parse_args()
    result = verify(args.spec, args.spec_sha256, args.output); print(json.dumps(result, indent=2), flush=True)
    raise SystemExit(result['returncode'])

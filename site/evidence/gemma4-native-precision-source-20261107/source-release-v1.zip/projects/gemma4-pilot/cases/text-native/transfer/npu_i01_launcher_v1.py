"""One new-claim Ascend I01 capture, bounded to 1200 native / 2400 total seconds.

Only main/probe execute native observations. The shared instance and unrelated
processes are never stopped. The conservative process gate requires an explicit
empty npu-smi process section; an occupied or unrecognized table spends the new
claim and stops before loading. Generic record_run bytes are never rewritten.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import subprocess
import sys
import time

CASE = 'projects/gemma4-pilot/cases/text-native'
ENTRY = CASE + '/adapters/i01_npu_v1.py'
COMMON = CASE + '/adapters/i01_common_v1.py'
LAUNCHER = CASE + '/transfer/npu_i01_launcher_v1.py'
HELPER = CASE + '/transfer/npu_three_repeat_launcher_v4.py'
EXPECTED = CASE + '/adapters/i01_expected_inventory_v1.py'
SPEC = CASE + '/i01-stage-v1.json'
INPUT = CASE + '/inputs/discovery-v1/wikitext2-discovery-001.json'
RECORDER = 'skills/precision-compare/scripts/record_run.py'
TASK_ID = 'gemma4-gpu-npu-i01-cacheoff-v1-20261106'
STAGE_SHA = '5aa7d50bb472aab82108ad6711fdd6c5bdd4780bbecb27cdf78c734d13093c05'
EXPECTED_SHA = '416b4f7384c5676c7b1fc9c6d41a7e5c53e654d95554ceebe71dceb94049d5ee'
ORIGINAL_UUID = 'REDACTED_DEVICE_UUID'
MAX_SECONDS, CAPTURE_SECONDS, CLEANUP_SECONDS = 2400, 1200, 20
MAX_BYTES = 1024 ** 3
PINS = {
 COMMON: 'fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c',
 ENTRY: '6e41565fde0103cc532c75de78553bc8b941b7aae9f604d3aebb01a46bc70ceb',
 EXPECTED: '834de8fef3d6147b908450116e39a48ea75a026bfc13a290db7db25492fbb40b',
 SPEC: STAGE_SHA,
 INPUT: '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0',
 RECORDER: '2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b',
 HELPER: 'c1719e831a557cd9707374138d9219a8ae887854dd029a1ec165631d9259f485',
 CASE + '/adapters/pilot_gpu_torch290_candidate.py': '5a73efe31962788baa04fa21abb1079be8a47e43393c23f3fa483e71c64b4f53',
 CASE + '/adapters/pilot_ascend_candidate_v3.py': '95b7b9302543d8a14995e293c790d5de9e23abc6041a53bb1d627ae3b5cd7ee8',
 CASE + '/adapters/pilot_gpu_peer_v2.py': 'fbf0b1dc4b03576852d166bc56d3bca14d6544be8aebd120ef0b92f146429eae',
 CASE + '/adapters/verify_snapshot.py': 'cd64a5f3f380d9cc04578848ba508ace3f1df0752ca952b8d575dd2904196f26',
 CASE + '/adapters/upstream-identity.json': '80dc0e0e59e5c526426b566d36a21f762a79d498986d5d6cd01098c8cb5decc3',
 'skills/precision-compare/scripts/inference_capture.py': '5d388e846249d7fd74df1b15036f8a371e3267ada1b2fb0408bc51345ffad19c',
 'skills/precision-compare/scripts/artifact_io.py': '0260cd5ee1fd4e9d37e39bfd79efa9e663a1d48cb75b5adb31b84af9e1edbf39',
 'skills/precision-compare/scripts/conditions.py': 'e012c025395f2f0474f0b35074d8417ec5a217f3659f82218de0f5d05068036d',
}


def require(ok, message):
    if not ok: raise ValueError(message)


def utc(): return datetime.now(timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 ** 2), b''): h.update(block)
    return h.hexdigest()


def read(path):
    def pairs(values):
        result = {}
        for key, value in values:
            require(key not in result, 'duplicate JSON key'); result[key] = value
        return result
    def reject(value): raise ValueError('nonfinite JSON token ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs, parse_constant=reject)


def raw_put(path, raw):
    with Path(path).open('xb') as stream: stream.write(raw)


def put(path, value):
    raw_put(path, (json.dumps(value, indent=2, allow_nan=False) + '\n').encode('utf-8'))


def regular(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'regular original file required: ' + str(path))
    return path


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def claim_once(task, metadata):
    parent = Path(task) / 'claims'; parent.mkdir(exist_ok=True)
    claim = parent / ('npu-i01-' + ORIGINAL_UUID)
    try: claim.mkdir(mode=0o700)
    except FileExistsError: return None
    put(claim / 'claim.json', metadata)
    return claim


def process_gate(raw):
    """Conservative all-instance-idle check, not a guessed chip/ordinal mapping."""
    text = raw.decode('utf-8')
    process_column, seen, empty_boards, boards = None, False, set(), set()
    for line in text.splitlines():
        cells = [cell.strip() for cell in line.strip().strip('|').split('|')]
        header = [i for i, cell in enumerate(cells) if re.fullmatch(r'process\s+id', cell, re.I)]
        if header:
            require(len(header) == 1, 'ambiguous process ID header')
            process_column, seen = header[0], True
            continue
        if not seen:
            match = re.match(r'^\|\s*(\d+)\s+Ascend[^|]*\|', line)
            if match: boards.add(int(match.group(1)))
            continue
        empty = re.search(r'no\s+running\s+processes\s+found\s+in\s+NPU\s+(\d+)', line, re.I)
        if empty:
            board = int(empty.group(1))
            require(board not in empty_boards, 'duplicate empty-board process observation')
            empty_boards.add(board)
            continue
        if cells and re.match(r'^\d+(?:\s|$)', cells[0]):
            require(process_column < len(cells) and not cells[process_column].isdigit(),
                    'a shared-instance NPU process is present; no model launch or unrelated stop')
            raise ValueError('unrecognized nonempty process row; no model launch')
    require(seen, 'npu-smi process header unavailable')
    require(boards and empty_boards == boards, 'process inventory does not explicitly cover every observed board as empty')
    return {'status': 'explicitly_empty', 'policy': 'conservative all-instance process table must be empty',
            'raw_sha256': hashlib.sha256(raw).hexdigest(), 'known_process_rows': 0,
            'observed_board_ids': sorted(boards), 'explicitly_empty_board_ids': sorted(empty_boards),
            'scope': 'point-in-time observation; no exclusive scheduler reservation or hidden-process attestation'}


def smi_identity(path, expected_sha):
    path = Path(path)
    require(path.is_absolute() and path.is_file(), 'explicit absolute process-inventory CLI required')
    resolved = regular(path.resolve(strict=True))
    require(resolved.stat().st_size <= 32 * 1024 ** 2 and sha(resolved) == expected_sha,
            'process inventory CLI real bytes differ from frozen source')
    with resolved.open('rb') as stream: magic = stream.read(4)
    vendors = []
    for name in ('/usr/local/Ascend/driver/tools/npu-smi', '/usr/local/Ascend/driver/tools/npu-smi/npu-smi', '/usr/local/sbin/npu-smi'):
        candidate = Path(name)
        if candidate.is_file():
            real = candidate.resolve()
            vendors.append({'path': name, 'resolved_path': str(real), 'size_bytes': real.stat().st_size,
                            'sha256': sha(real), 'same_bytes_as_selected': sha(real) == expected_sha})
    return {'requested_path': str(path), 'resolved_path': str(resolved), 'sha256': expected_sha,
        'size_bytes': resolved.stat().st_size, 'first_four_bytes_hex': magic.hex(), 'is_symlink': path.is_symlink(),
        'available_vendor_path_comparisons': vendors,
        'scope': 'Observed CLI/wrapper source identity; process output is not independent scheduler or hidden-process attestation'}


def source_check(args):
    root, source = args.task_root.resolve(), args.source_root.resolve()
    require(root.name == 'i01-cacheoff-20261106' and source == root / 'source', 'new I01 task/source roots required')
    require(not args.task_root.is_symlink() and root.is_dir() and source.is_dir(), 'existing nonsymlink new task/source required')
    require(args.source_manifest.resolve().is_relative_to(root) and sha(regular(args.source_manifest)) == args.source_manifest_sha256,
            'source manifest path/hash differs')
    manifest = read(args.source_manifest)
    require(set(manifest) == {'schema_version', 'task_id', 'files'} and manifest['schema_version'] == 1 and manifest['task_id'] == TASK_ID,
            'exact source manifest schema required')
    require(set(manifest['files']) == set(PINS) | {LAUNCHER}, 'source dependency closure differs')
    require(all(manifest['files'][name] == digest for name, digest in PINS.items()), 'reviewed source pins differ')
    frozen = {}
    for name, expected in manifest['files'].items():
        parts = PurePosixPath(name)
        require(not parts.is_absolute() and '..' not in parts.parts and '\\' not in name, 'unsafe source path')
        path = source / name
        require(path.resolve().is_relative_to(source), 'source escape')
        current = path
        while current != source:
            require(not current.is_symlink(), 'source path contains symlink'); current = current.parent
        require(regular(path).stat().st_size <= 1024 ** 2 and sha(path) == expected, 'source file SHA/size differs: ' + name)
        frozen[str(path)] = expected
    require(Path(__file__).resolve() == source / LAUNCHER, 'execute the frozen staged launcher itself')
    helper = load_module(source / HELPER, 'i01_reviewed_npu_helpers')
    allocation, physical = helper.binding(args.allocation, args.native_mapping, args.native_source)
    require(physical == ORIGINAL_UUID, 'new binding must retain original cached NPU UUID')
    for path in (args.source_manifest, args.allocation, args.native_mapping, args.native_source, args.driver_source):
        frozen[str(regular(path).resolve())] = sha(path)
    identity = smi_identity(args.npu_smi, args.npu_smi_sha256)
    frozen[identity['resolved_path']] = identity['sha256']
    require(sha(args.driver_source) == '1bc07a765a4b4c765510ec7979113ea03b0217f1dcc0c2eb4646d011d7f88902', 'native driver source differs')
    return helper, allocation, frozen


def assert_frozen(frozen):
    require(all(sha(regular(path)) == digest for path, digest in frozen.items()), 'frozen source/input/binding changed')


def tree_bytes(root):
    total = 0
    for path in Path(root).rglob('*'):
        require(not path.is_symlink(), 'symlink in new task output')
        if path.is_file(): total += path.stat().st_size
    return total


def bounded(helper, argv, stdout, stderr, deadline, task):
    process = None
    try:
        with stdout.open('xb') as out, stderr.open('xb') as err:
            process = subprocess.Popen(argv, stdout=out, stderr=err, stdin=subprocess.DEVNULL,
                start_new_session=True, cwd=args_source_root(task))
            next_sample = 0
            while process.poll() is None:
                now = time.monotonic()
                if now >= deadline: raise TimeoutError('I01 whole-attempt deadline reached')
                if now >= next_sample:
                    require(tree_bytes(task) <= MAX_BYTES, 'new task sampled storage limit exceeded')
                    next_sample = now + 2
                try: process.wait(timeout=min(.2, deadline-now))
                except subprocess.TimeoutExpired: pass
            code = process.returncode
            require(not any(row['state'] != 'Z' for row in helper.descendants().values()), 'unexpected owned descendant after child exit')
            return code
    finally:
        helper.cleanup(process)


def args_source_root(task):
    return Path(task) / 'source'


def subreaper():
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0: raise OSError(ctypes.get_errno(), 'Linux subreaper unavailable')


def probe(args):
    helper, allocation, frozen = source_check(args)
    require(allocation['physical_device_id'] == ORIGINAL_UUID, 'NPU identity differs')
    helper.native_probe(args, args.probe_output)
    packages = {}
    for name in ('torch', 'torch_npu', 'transformers', 'numpy'):
        module = sys.modules[name]
        path = regular(module.__file__)
        packages[name] = {'path': str(path.resolve()), 'sha256': sha(path), 'size_bytes': path.stat().st_size}
    put(args.probe_output.with_name('native-runtime-sources.json'), packages)
    assert_frozen(frozen)
    return 0


def worker(args):
    helper, allocation, frozen = source_check(args)
    claim = args.worker.resolve()
    require(claim.parent == args.task_root.resolve() / 'claims' and claim.is_dir(), 'worker requires the spent new claim')
    expected_path = claim / 'expected-inventory.json'
    require(sha(expected_path) == EXPECTED_SHA and expected_path.stat().st_size == 102138, 'independent expected bytes differ')
    before = read(claim / 'sources-before.json')
    assert_frozen(before)
    sys.path.insert(0, str(args.source_root / 'skills/precision-compare/scripts'))
    recorder = load_module(args.source_root / RECORDER, 'i01_generic_record_run')
    def interrupted(signum, frame): raise KeyboardInterrupt()
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP): signal.signal(sig, interrupted)
    run, command = recorder.record_run(args.task_root / 'runs', 'ascend', 'i01-cacheoff', CAPTURE_SECONDS,
        lambda folder: [sys.executable, '-B', str(args.source_root / ENTRY), '--model', str(args.model),
            '--input', str(args.source_root / INPUT), '--allocation-receipt', str(args.allocation),
            '--native-mapping', str(args.native_mapping), '--native-source', str(args.native_source),
            '--driver-source', str(args.driver_source), '--device', 'npu:0',
            '--stage-spec', str(args.source_root / SPEC), '--stage-spec-sha256', STAGE_SHA,
            '--expected-inventory', str(expected_path), '--expected-inventory-sha256', EXPECTED_SHA,
            '--output', str(folder / 'artifacts')], cwd=args.source_root, execution=claim / 'execution-profile.json')
    generic = {'path': str(run / 'command.json'), 'sha256': sha(run / 'command.json')}
    put(claim / 'generic-receipt-reference.json', generic)
    require(command['status'] == 'completed' and command['returncode'] == 0, 'I01 native collector failed')
    sys.path.insert(0, str(args.source_root / CASE / 'adapters'))
    from i01_common_v1 import validate_output
    output = run / 'artifacts'
    validation = validate_output(output, args.source_root / INPUT)
    runtime = read(output / 'runtime.json')
    require(runtime['package_sources'] == read(claim / 'native-runtime-sources.json'),
            'collector package source identity differs from fresh native preflight')
    runtime_sources = [runtime['model_identity']['modeling_source'], *runtime['package_sources'].values()]
    runtime_map = {}
    for index, ref in enumerate(runtime_sources):
        original = regular(ref['path'])
        require(sha(original) == ref['sha256'] and original.stat().st_size == ref['size_bytes'], 'runtime implementation bytes differ')
        target = claim / 'frozen-runtime' / ('%02d' % index) / original.name
        target.parent.mkdir(parents=True, exist_ok=False)
        raw_put(target, original.read_bytes())
        runtime_map[str(original)] = {'path': str(target), 'sha256': sha(target), 'size_bytes': target.stat().st_size}
        before[str(original)] = ref['sha256']
    put(claim / 'frozen-runtime-map.json', runtime_map)
    assert_frozen(before)
    put(claim / 'sources-after.json', before)
    put(claim / 'capture-receipt.json', {'schema_version': 1, 'task': 'I01', 'task_id': TASK_ID,
        'backend': 'NPU', 'status': 'completed', 'returncode': 0, 'timed_out': False,
        'started_utc': command['start'], 'finished_utc': utc(), 'argv': command['argv'],
        'collector_path': str(args.source_root / ENTRY), 'collector_sha256': PINS[ENTRY],
        'input_path': str(args.source_root / INPUT), 'input_sha256': PINS[INPUT],
        'dependency_paths': list(before), 'source_sha256': before, 'output_dir': str(output),
        'artifacts_manifest_sha256': sha(output / 'artifacts-manifest.json'),
        'expected_inventory_source_path': str(expected_path), 'expected_inventory_source_sha256': EXPECTED_SHA,
        'stage_spec_source_path': str(args.source_root / SPEC), 'stage_spec_source_sha256': STAGE_SHA,
        'generic_receipt': generic, 'allocation_path': str(args.allocation), 'allocation_sha256': sha(args.allocation),
        'runtime_source_map_path': str(claim / 'frozen-runtime-map.json'),
        'runtime_source_map_sha256': sha(claim / 'frozen-runtime-map.json'),
        'validation': validation, 'native_capture_count': 1, 'acceptance': None})
    return 0


def argv_copy(args):
    argv = [sys.executable, '-B', str(Path(__file__).resolve())]
    for name in ('task_root', 'source_root', 'model', 'allocation', 'native_mapping', 'native_source', 'driver_source', 'source_manifest', 'source_manifest_sha256', 'npu_smi', 'npu_smi_sha256'):
        argv += ['--' + name.replace('_', '-'), str(getattr(args, name))]
    return argv


def run(args):
    started = time.monotonic()
    require(sys.platform.startswith('linux') and os.environ.get('PYTHONHASHSEED') == '0', 'Linux/PYTHONHASHSEED=0 required')
    helper, allocation, frozen = source_check(args)
    require(shutil.disk_usage(args.task_root).free >= 2*1024**3 and tree_bytes(args.task_root) <= MAX_BYTES, 'source free/storage bound failed')
    subreaper()
    claim = claim_once(args.task_root, {'schema_version': 1, 'task_id': TASK_ID, 'claimed_utc': utc(),
        'allocation_id': allocation['allocation_id'], 'runtime_uuid': ORIGINAL_UUID, 'whole_attempt_seconds': MAX_SECONDS,
        'capture_seconds': CAPTURE_SECONDS, 'max_new_bytes_sampled': MAX_BYTES, 'native_launches': 1,
        'automatic_retries': 0, 'pid': os.getpid(), 'source_manifest_sha256': args.source_manifest_sha256})
    if claim is None:
        print(json.dumps({'status': 'refused', 'reason': 'permanent_I01_claim_exists', 'native_capture_started': False}), flush=True)
        return 0
    state = {'schema_version': 1, 'task': 'I01', 'task_id': TASK_ID, 'backend': 'NPU', 'status': 'running',
        'started_utc': utc(), 'claim': str(claim), 'source_sha256': frozen,
        'storage_limit_is_sampled_not_hard_quota': True, 'acceptance': None}
    handlers = {}
    def interrupt(signum, frame): raise TimeoutError('signal/deadline ' + str(signum))
    code = 1
    try:
        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGALRM): handlers[sig] = signal.signal(sig, interrupt)
        signal.setitimer(signal.ITIMER_REAL, MAX_SECONDS)
        source_map = {}
        for index, (original, digest) in enumerate(frozen.items()):
            target = claim / 'frozen-source' / ('%03d' % index) / Path(original).name
            target.parent.mkdir(parents=True)
            raw_put(target, Path(original).read_bytes()); require(sha(target) == digest, 'source changed while freezing')
            source_map[original] = {'path': str(target), 'sha256': digest, 'size_bytes': target.stat().st_size}
        put(claim / 'frozen-source-map.json', source_map)
        inventory_cli = smi_identity(args.npu_smi, args.npu_smi_sha256)
        put(claim / 'npu-smi-identity.json', inventory_cli)
        expected = load_module(args.source_root / EXPECTED, 'i01_expected_independent')
        expected_path = claim / 'expected-inventory.json'
        expected.build(args.source_root / INPUT, expected_path, args.source_root / SPEC, STAGE_SHA)
        require(sha(expected_path) == EXPECTED_SHA and expected_path.stat().st_size == 102138, 'independent pre-model inventory differs')
        execution = claim / 'execution-profile.json'
        put(execution, {'env': {'PYTHONHASHSEED': '0', 'PYTHONNOUSERSITE': '1', 'PYTHONDONTWRITEBYTECODE': '1',
            'PYTHONHOME': None, 'PYTHONPATH': None, 'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1'}})
        for number in (1, 2):
            require(smi_identity(args.npu_smi, args.npu_smi_sha256) == inventory_cli, 'CLI identity changed before process inventory')
            result = subprocess.run([str(args.npu_smi), 'info'], capture_output=True, timeout=20, check=False)
            require(smi_identity(args.npu_smi, args.npu_smi_sha256) == inventory_cli, 'CLI identity changed after process inventory')
            raw_put(claim / ('process-%d.stdout' % number), result.stdout)
            raw_put(claim / ('process-%d.stderr' % number), result.stderr)
            require(result.returncode == 0, 'npu-smi inventory failed')
            observed = process_gate(result.stdout)
            put(claim / ('process-%d.json' % number), dict(observed, observed_utc=utc(), returncode=result.returncode))
            if number == 1:
                probe_path = claim / 'native-preflight.json'
                status = bounded(helper, argv_copy(args) + ['--probe-output', str(probe_path)],
                    claim / 'preflight.stdout', claim / 'preflight.stderr', min(started+MAX_SECONDS-CLEANUP_SECONDS, time.monotonic()+120), args.task_root)
                require(status == 0 and read(probe_path).get('status') == 'preflight_passed', 'fresh native preflight failed')
                packages = read(claim / 'native-runtime-sources.json')
                package_map = {}
                for index, ref in enumerate(packages.values()):
                    original = regular(ref['path'])
                    require(sha(original) == ref['sha256'] and original.stat().st_size == ref['size_bytes'], 'native package source changed')
                    target = claim / 'frozen-native-packages' / ('%02d' % index) / original.name
                    target.parent.mkdir(parents=True)
                    raw_put(target, original.read_bytes())
                    package_map[str(original)] = {'path': str(target), 'sha256': sha(target), 'size_bytes': target.stat().st_size}
                    frozen[str(original)] = ref['sha256']
                put(claim / 'frozen-native-packages-map.json', package_map)
        dynamic = [expected_path, execution, claim / 'native-preflight.json', claim / 'native-runtime-sources.json', claim / 'npu-smi-identity.json']
        dynamic += [claim / ('process-%d%s' % (n, suffix)) for n in (1,2) for suffix in ('.stdout','.stderr','.json')]
        frozen.update({str(path): sha(path) for path in dynamic})
        assert_frozen(frozen); put(claim / 'sources-before.json', frozen)
        code = bounded(helper, argv_copy(args) + ['--worker', str(claim)], claim / 'worker.stdout', claim / 'worker.stderr',
            started+MAX_SECONDS-CLEANUP_SECONDS, args.task_root)
        require(code == 0 and read(claim / 'capture-receipt.json').get('status') == 'completed', 'I01 capture worker failed')
        assert_frozen(frozen); require(tree_bytes(args.task_root) <= MAX_BYTES, 'new task storage exceeded bound')
        if started + MAX_SECONDS - CLEANUP_SECONDS - time.monotonic() >= 20:
            try:
                post = subprocess.run([str(args.npu_smi), 'info'], capture_output=True, timeout=20, check=False)
                raw_put(claim / 'process-after.stdout', post.stdout); raw_put(claim / 'process-after.stderr', post.stderr)
                state['post_capture_process_observation'] = {'observed_utc': utc(), 'returncode': post.returncode,
                    'stdout_sha256': sha(claim / 'process-after.stdout'), 'stderr_sha256': sha(claim / 'process-after.stderr'),
                    'scope': 'Metadata after owned capture exited; unrelated newly started processes are not stopped or attributed'}
            except (OSError, subprocess.TimeoutExpired) as exc:
                state['post_capture_process_observation'] = {'status': 'unavailable', 'error_type': type(exc).__name__, 'error': str(exc)}
        else:
            state['post_capture_process_observation'] = {'status': 'not_queried', 'reason': 'preserve finite cleanup reserve'}
        state['status'] = 'completed'
    except BaseException as exc:
        code = 124 if isinstance(exc, TimeoutError) else 1
        state.update(status='failed', error_type=type(exc).__name__, error=str(exc))
    finally:
        try: helper.cleanup(None)
        except BaseException as exc:
            code = 1; state.update(status='cleanup_failed', cleanup_error=str(exc))
        signal.setitimer(signal.ITIMER_REAL, 0)
        for sig, handler in handlers.items(): signal.signal(sig, handler)
        state.update(finished_utc=utc(), wall_seconds=time.monotonic()-started, returncode=code,
            timed_out=code == 124, remaining_descendants=sorted(helper.descendants()), claim_remains_spent=True)
        put(claim / 'controller-receipt.json', state)
    print(json.dumps({'status': state['status'], 'returncode': code, 'claim': str(claim)}, allow_nan=False), flush=True)
    return code


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('task-root', 'source-root', 'model', 'allocation', 'native-mapping', 'native-source', 'driver-source', 'source-manifest', 'npu-smi'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--source-manifest-sha256', required=True)
    parser.add_argument('--npu-smi-sha256', required=True)
    parser.add_argument('--probe-output', type=Path)
    parser.add_argument('--worker', type=Path)
    args = parser.parse_args()
    require(not (args.worker and args.probe_output), 'one internal mode only')
    if args.probe_output: return probe(args)
    if args.worker: return worker(args)
    return run(args)


if __name__ == '__main__': raise SystemExit(main())

"""Private GPU-only observer publication candidates; no arrays/public/Git I/O.

Actual E02 report/controller pins remain closed until their successful bytes
exist. Original source JSON is never rewritten. Only explicit public fields
leave the private evidence graph; each output phase creates at most3 files.
"""
import argparse
from collections import Counter
import copy
import hashlib
import itertools
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import signal
import time
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
CASE = HERE.parent
RECORD = 'gemma4-h100-observer-transparency-20261107'
REPORT_SHA = '7953d80271966156792c0e956aaec25d6cee27b4e3d22cbcc6cb5ed64245f7b8'
CONTROLLER_SHA = '37ecba17be9b03d306c21c3ba3de40efd926dde1e63f822420989c4a0f6d5fad'
MATRIX_SHA = 'efcf8064a6713ea854a2383328e28a818015e5c58af49c3f96f730d67f6ce8d1'
WORKLOAD_SHA = '933e541a4ea62b8092666203186d02ccfa16e1990087ed6297550c99bbc82996'
E02_REPORT_SHA = '2ac29b72ef6bee066b5d0bb692e6f0558b21ea44b900f2bd870381428a2a97db'
E02_CONTROLLER_SHA = '4e6ce1506dcbc51a8678376d5f75ff2927e2583376b39b1fbd26daa20401f9af'
E02_VERIFIER_SHA = '72a72fe7b24c11c3e3069a22f58eba949c2816595bfd403ac2620f5efad41d37'
E02_SPEC_SHA = '8858a9874bdb5adc2aac43e9957e722cb266435de7f1384e87bfda20c6069fcc'
PRIMITIVE_SHA = '863019a1bd9875d418630c4c5e547576232e225fd66a98d63d51f3023701a44e'
SOURCE_MAP_SHA = '11f6107b3f86f55f9d5f4a213f0233a1b9f2a8b8a9af0169cbd036abdcb59b1b'
INPUT_SHA = '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
MODES = ['off-before', 'hooks-only', 'off-after', 'hooks-plus-dispatch-metadata']
POSITIONS = sorted({i*127//15 for i in range(16)} | set(range(127, 159)))
CHANNELS = [i*3839//63 for i in range(64)]
BOUNDARIES = ['embedding.scaled.output'] + [f'block.{i:02d}.{when}' for i in range(48) for when in ('input', 'output')] + ['norm.final.output']
HEX = re.compile(r'^[a-f0-9]{64}$')
MODEL = {'repository': 'google/gemma-4-12B', 'variant': 'base', 'revision': '1a2c7729392586f5ecddae8807ee2ef741eabb9a',
    'parameter_dtype': 'BF16', 'native_logits_dtype': 'BF16', 'attention': 'eager', 'seed': 0, 'tensor_parallel_size': 1}


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+'\n').encode()
def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def parse(raw):
    def pairs(items):
        result = {}
        for key, value in items: require(key not in result, 'duplicate JSON key'); result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def metadata(path, expected):
    path = Path(path)
    require(path.suffix in ('.json', '.py', '.txt') and path.is_file() and not path.is_symlink() and path.stat().st_size <= 16*1024**2,
            'bounded metadata only; native arrays may not be opened')
    raw = path.read_bytes(); require(HEX.fullmatch(expected) and sha(raw) == expected, 'original metadata byte SHA differs')
    return raw


def finite(value):
    require(type(value) in (int, float) and math.isfinite(value), 'finite scalar metric required')
    return value


def number(value):
    if isinstance(value, dict):
        require(set(value) == {'value', 'status'} and value['status'] == 'no_thresholds', 'source scalar status differs')
        value = value['value']
    return None if value is None else finite(value)


def privacy(value):
    banned_keys = {'token', 'tokens', 'token_ids', 'history', 'prompt', 'source_path', 'path', 'pid', 'pids', 'allocation_id',
        'physical_device_id', 'runtime_uuid', 'device_uuid', 'password', 'username', 'account'}
    if isinstance(value, dict):
        require(not (set(value) & banned_keys), 'private field leaked into public candidate')
        for item in value.values(): privacy(item)
    elif isinstance(value, list):
        for item in value: privacy(item)
    elif isinstance(value, str):
        require(not any(x in value for x in ('/mnt/', '/home/', '/data/afs', 'C:\\', 'C:/', 'REDACTED_ACCOUNT', 'REDACTED_ACCOUNT', 'REDACTED_APP_ID',
            'wikitext2-discovery-001', 'wxid_')), 'private source/account/sample leaked')
        require(not re.search(r'\b(?:\d{1,3}\.){3}\d{1,3}\b|\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b', value),
            'IP/device identifier leaked')
    elif type(value) in (int, float): finite(value)
    else: require(value is None or type(value) is bool, 'unsupported public scalar')


def quantile(values, p):
    values = sorted(values); index = p*(len(values)-1); lo = int(index)
    return values[lo] + (index-lo)*(values[min(lo+1, len(values)-1)]-values[lo])


def target_reduce(a, b):
    require(len(a) == len(b) == 159 and all(type(x) in (int, float) and math.isfinite(x) and x <= 0 for x in a+b), '159 finite logprobs required')
    errors = [abs(x-y) for x, y in zip(a, b)]; index = errors.index(max(errors))
    na, nb = [math.fsum(-x for x in side)/159 for side in (a, b)]
    return {'target_count': 159, 'side_a_nll_nat_per_token': na, 'side_b_nll_nat_per_token': nb,
        'nll_abs_diff_nat_per_token': abs(na-nb), 'mae_nat': math.fsum(errors)/159, 'p99_nat': quantile(errors, .99),
        'max_abs_nat': errors[index], 'max_target_index': index}


def target_metrics(value):
    keys = ('target_count', 'side_a_nll_nat_per_token', 'side_b_nll_nat_per_token', 'nll_abs_diff_nat_per_token', 'mae_nat', 'p99_nat', 'max_abs_nat')
    result = {key: finite(value[key]) for key in keys}
    require(result['target_count'] == 159 and value['p99_method'] == 'global linear h=0.99*(N-1)', 'exact target reduction semantics differ')
    result['p99_method'] = value['p99_method']
    result['max_target_index'] = value['max_coordinate']['position']-1
    require(type(result['max_target_index']) is int and 0 <= result['max_target_index'] < 159, 'target-coordinate shift differs')
    return result


def distribution_row(value, ordinal):
    require(value['position'] == POSITIONS[ordinal] and type(value['union_count']) is int and 100 <= value['union_count'] <= 200 and
        type(value['top1_agreement']) is bool, 'exact sampled distribution coordinate/count differs')
    result = {'selected_row_index': ordinal, 'prediction_index': value['position'], 'union_count': value['union_count'],
        'top1_agreement': value['top1_agreement'], 'top100_overlap': finite(value['top100_overlap']),
        'probability_rmse': finite(value['probability_rmse']), 'max_probability_error': finite(value['max_probability_error']),
        'tail_merged_js': number(value['tail_merged_js']),
        'coverage': {key: finite(value['coverage'][key]) for key in ('side_a_top100', 'side_b_top100', 'side_a_union', 'side_b_union')},
        'normalization_mass': {key: finite(value['normalization_mass'][key]) for key in ('side_a', 'side_b')}}
    return result


def distribution_aggregate(value):
    result = {}
    for key in ('probability_rmse', 'max_probability_error', 'tail_merged_js'):
        result[key] = {name: finite(value[key][name]) for name in ('mean', 'p99', 'max')}
        result[key]['max_prediction_index'] = value[key]['max_coordinate']['position']
        require(result[key]['max_prediction_index'] in POSITIONS, 'aggregate maximum outside selected coordinates')
    result['top1_agreement'] = {key: value['top1_agreement'][key] for key in ('count', 'total', 'fraction')}
    require(result['top1_agreement']['total'] == 47, 'all47 top1 observations required')
    result['top100_overlap_mean'] = finite(value['top100_overlap']['mean'])
    result['coverage'] = {role: {key: finite(value['coverage'][role][key]) for key in ('mean', 'p1', 'min')}
        for role in ('side_a_top100', 'side_b_top100', 'side_a_union', 'side_b_union')}
    return result


def tensor_metric(value):
    require(value['count'] == 3008 or value['count'] == 294784, 'native sample coordinate population differs')
    result = {'count': value['count'], **{key: number(value[key]) for key in
        ('side_a_norm', 'side_b_norm', 'error_norm', 'rmse', 'cosine', 'max_abs')}, 'max_flat_index': value['max_flat_index']}
    require(type(result['max_flat_index']) is int and 0 <= result['max_flat_index'] < result['count'], 'sample maximum outside flattened coordinates')
    return result


def safe_main(report, score_documents):
    require(report['status'] == 'actual_GPU_only_observer_raw_BF16_and_sampled_comparisons_checked' and
        report['scope']['NPU_activated'] is False and report['scope']['native_forward_calls_original'] == 4 and
        report['scope']['original_large_sources_final_bytehash_checked'] == 194 and report['acceptance'] is report['thresholds'] is None and
        report['full_core_complete'] is False, 'actual GPU-only non-acceptance report required')
    vectors = {}; pairs = []; coordinates = None
    for index, (left, right) in enumerate(itertools.combinations(MODES, 2)):
        original = report['target_distribution_pairs'][index]
        require(original['sides'] == ['gpu-'+left, 'gpu-'+right] and original['targets']['coverage'] == {'expected': 159, 'paired': 159} and
            original['targets']['status'] == original['distributions']['status'] == 'no_thresholds' and
            original['distributions']['position_count'] == 47, 'exact six159/47 pairs required')
        for mode in (left, right):
            doc = score_documents[(index, mode)]; scores = doc['scores']
            require(doc['side'] == 'gpu-'+mode and doc['common']['inputs']['sha256'] == INPUT_SHA and
                doc['common']['model']['revision'] == MODEL['revision'] and len(scores) == 159,
                'original source-bound target document identity differs')
            coords = [{key: item[key] for key in ('sample', 'position', 'token')} for item in scores]
            require([item['position'] for item in scores] == list(range(1, 160)) and
                all(type(item['token']) is int and 0 <= item['token'] < 262144 for item in scores), 'causal target inventory differs')
            if coordinates is None: coordinates = coords
            require(coords == coordinates, 'target input/token identities differ between modes')
            values = [finite(item['logprob']) for item in scores]; require(all(x <= 0 for x in values), 'positive logprob')
            if mode in vectors: require(vectors[mode] == values, 'same mode differs between comparison documents')
            vectors[mode] = values
        target = target_metrics(original['targets']['metrics']); replay = target_reduce(vectors[left], vectors[right])
        for key, value in replay.items(): require(abs(value-target[key]) <= 1e-12, 'independent target replay mismatch: '+key)
        maximum = original['targets']['metrics']['max_coordinate']; require(maximum == coordinates[target['max_target_index']], 'original maximum target coordinate differs')
        distribution = original['distributions']; rows = distribution['positions']; require(len(rows) == 47, 'all47 scalar rows retained')
        pairs.append({'id': 'gpu/'+left+'/'+right, 'sides': ['gpu-'+left, 'gpu-'+right], 'targets': target,
            'distributions': {'position_count': 47, 'positions': [distribution_row(row, i) for i, row in enumerate(rows)],
                'aggregate': distribution_aggregate(distribution['aggregate']), 'probability_error_scope': 'top100 union members',
                'JS_scope': 'top100 union plus exact complementary tail bin', 'renormalization': 'none'}})
    require(len(vectors) == 4 and len(pairs) == 6, 'four vectors/six contrasts required')
    samples = report['boundary_sample_comparisons']; require(len(samples) == 1 and samples[0]['sides'] ==
        ['gpu-hooks-only', 'gpu-hooks-plus-dispatch-metadata'], 'one enabled boundary contrast required')
    tensor = samples[0]['metrics']; require(set(tensor['per_tensor']) == set(BOUNDARIES), 'exact98 public boundary names required')
    per_boundary = {}
    for name in BOUNDARIES:
        item = tensor['per_tensor'][name]
        require(item['coordinates']['token_indices'] == POSITIONS and item['coordinates']['channel_indices'] == CHANNELS and
            item['coordinates']['boundary'] == name and len(item['max_coordinate']) == 3, 'exact1x47x64 boundary coordinate inventory differs')
        per_boundary[name] = dict(tensor_metric(item), max_selected_coordinate=item['max_coordinate'])
    census = {}
    for mode in MODES:
        value = report['execution_census'][mode]
        if mode in ('off-before', 'off-after'):
            require(value == {'execution_census_measured': False}, 'disabled modes must not invent fired counts')
            census[mode] = value
        else:
            require(value['static_modules'] == 875 and value['fired_modules'] == 863 and value['total_module_invocations'] == 864 and
                len(value['zero_fired_modules']) == 12 and value['native_kernel_identity_attested'] is False and value['full_operand_values_attested'] is False,
                'actual scoped invocation census differs')
            census[mode] = {key: value[key] for key in ('execution_census_measured', 'static_modules', 'fired_modules', 'zero_fired_modules',
                'total_module_invocations', 'frontend_dispatcher_enabled', 'frontend_invocations', 'frontend_unique_signatures',
                'native_kernel_identity_attested', 'full_operand_values_attested')}
    targets = {'schema_version': 1, 'kind': 'anonymous-observer-GPU-only-target-vectors', 'record_id': RECORD, 'model': MODEL,
        'input_sha256': INPUT_SHA, 'input_count': 1, 'sequence_length': 160, 'target_count_per_mode': 159,
        'coordinate_rule': 'target_index0..158 corresponds to original target position1..159 and prediction index0..158',
        'vectors': [{'id': 'gpu-'+mode, 'mode': mode, 'logprobs': vectors[mode]} for mode in MODES],
        'acceptance': None, 'full_core_complete': False}
    metrics = {'schema_version': 1, 'kind': 'observer-GPU-only-sanitized-metrics', 'record_id': RECORD, 'model': MODEL,
        'input_sha256': INPUT_SHA, 'source_formal_report_sha256': REPORT_SHA, 'source_formal_controller_sha256': CONTROLLER_SHA,
        'selected_targets_sha256': sha(encoded(targets)), 'scope': {'independent_inputs': 1, 'same_loaded_model_processes': 1,
            'native_cacheoff_forwards': 4, 'scored_targets_per_mode': 159, 'unique_source_target_scores': 636,
            'unique_source_full_vocabulary_rows': 188, 'target_distribution_pairs': 6, 'distribution_pair_rows': 282,
            'sampled_boundary_pairs': 98, 'sampled_global_elements': 294784, 'source_large_objects': 194,
            'GPU_NPU_observer_comparison_complete': False, 'fresh_process_repeatability_measured': False, 'P01_measured': False},
        'target_distribution_pairs': pairs,
        'boundary_samples': {'sides': samples[0]['sides'], 'sample_shape': [1, 47, 64], 'selected_positions': POSITIONS,
            'selected_channels': CHANNELS, 'per_boundary': per_boundary, 'global': tensor_metric(tensor['global']),
            'cosine_min': min(x['cosine'] for x in per_boundary.values() if x['cosine'] is not None),
            'cosine_max': max(x['cosine'] for x in per_boundary.values() if x['cosine'] is not None)},
        'execution_census': census, 'state_control': {'same_loaded_eval_model': True, 'complete_RNG_equal': True,
            'available_observed_model_state_equal': True, 'scalar_BF16_buffer_content_gap_count': len(report['scalar_buffer_content_gaps']),
            'complete_parameter_buffer_byte_attestation': False},
        'NPU_observer': {'status': 'failed_pre_model_shared_instance_busy_guard', 'owned_model_loads': 0,
            'owned_observer_forwards': 0, 'workload_ownership_of_busy_processes_established': False, 'other_processes_stopped': False},
        'thresholds': None, 'acceptance': None, 'full_core_complete': False}
    privacy(targets); privacy(metrics)
    return targets, metrics


def coverage_v6(matrix):
    require(len(matrix['tasks']) == 49 and matrix['task_count'] == 49 and matrix['core_task_count'] == 28 and
        matrix['counts'] == {'partial': 6, 'complete': 9, 'pending': 11, 'deferred': 21, 'not_applicable': 2}, 'exact v5 ledger required')
    result = copy.deepcopy(matrix['public_summary_allowlist']); original = copy.deepcopy(result['tasks'])
    notes = {
        'M01': ' Add the actual GPU observer static875 module/630 named parameter/629 unique object inventory; static records remain separate from863 fired modules.',
        'M03': ' Add four actual GPU native cache-off observer modes and the full source-bound identity/runtime/census admission. NPU observer model launch did not occur.',
        'D03': 'One H100 process, one160-token input, four same-loaded-model off/hooks controls. Six numeric target/distribution contrasts and98 sampled boundary pairs independently checked; NPU observer contrast remains absent.',
        'O01': 'Actual GPU frontend dispatch and module census:5604 invocations/4922 scoped signatures;863 fired modules. Shapes/dtypes/frontend overloads do not identify executed kernels or local causes.',
        'O02': 'Actual GPU native BF16 [1,47,64] snapshots at scaled embedding output,48 block input/output pairs and finalnorm output;98 within-GPU boundary comparisons. No full hidden-state/operand or NPU trajectory claim.'}
    for task in result['tasks']:
        key = task['task_id']
        if key in ('D03', 'O01', 'O02'):
            require(task['status'] == 'pending', 'only three expected pending tasks may change')
            task.update(status='partial', observed_scope=notes[key], pilot_complete=False, full_plan_task_complete=False,
                gap='One-input GPU-only scope; NPU observer, broader workloads and complete original task evidence remain incomplete.',
                next_action='Extend only under a separately bounded native task and actual cross-backend/operand/kernel evidence as applicable.')
        elif key in notes: task['observed_scope'] += notes[key]
    for a, b in zip(original, result['tasks']):
        require(all(a[key] == b[key] for key in ('task_id', 'profile', 'expected_coverage')), 'original49 task identities changed')
        require(a['status'] == b['status'] or a['task_id'] in ('D03', 'O01', 'O02'), 'unrelated status changed')
    counts = dict(Counter(row['status'] for row in result['tasks']))
    require(counts == {'partial': 9, 'complete': 9, 'pending': 8, 'deferred': 21, 'not_applicable': 2}, 'v6 counts must remain49')
    result.update(counts=counts, scope='Historical GPU/NPU pilots plus GPU-only observer transparency; original49 tasks incomplete',
        full_core_complete=False, original_49_task_scope_complete=False, record_id=RECORD, acceptance=None)
    privacy(result); return result


def replay_source():
    return r'''"""Replay six anonymous GPU observer target pairs using stdlib only."""
import hashlib,json,math,pathlib,sys
def require(ok,message):
 if not ok:raise ValueError(message)
def read(path):
 p=pathlib.Path(path);require(p.suffix=='.json' and p.stat().st_size<4*1024**2,'bounded JSON only')
 raw=p.read_bytes();return raw,json.loads(raw,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def reduce(a,b):
 require(len(a)==len(b)==159 and all(type(x) in (int,float) and math.isfinite(x) and x<=0 for x in a+b),'159 finite logprobs')
 e=[abs(x-y) for x,y in zip(a,b)];s=sorted(e);h=.99*158;lo=int(h);na,nb=[math.fsum(-x for x in v)/159 for v in (a,b)]
 return {'target_count':159,'side_a_nll_nat_per_token':na,'side_b_nll_nat_per_token':nb,'nll_abs_diff_nat_per_token':abs(na-nb),'mae_nat':math.fsum(e)/159,'p99_nat':s[lo]+(h-lo)*(s[lo+1]-s[lo]),'max_abs_nat':max(e),'max_target_index':e.index(max(e))}
raw,targets=read(sys.argv[1]);_,metrics=read(sys.argv[2] if len(sys.argv)>2 else pathlib.Path(sys.argv[1]).with_name('selected-metrics.json'))
require(hashlib.sha256(raw).hexdigest()==metrics['selected_targets_sha256'],'target byte SHA differs')
require(targets['record_id']==metrics['record_id']=='gemma4-h100-observer-transparency-20261107' and targets['acceptance'] is metrics['acceptance'] is None and metrics['full_core_complete'] is False,'record/scope differs')
vectors={row['id']:row['logprobs'] for row in targets['vectors']};require(len(vectors)==4 and len(metrics['target_distribution_pairs'])==6,'four vectors/six pairs required')
for pair in metrics['target_distribution_pairs']:
 a,b=pair['sides'];actual=reduce(vectors[a],vectors[b])
 for key,value in actual.items():require(abs(value-pair['targets'][key])<=1e-12,'target reduction mismatch '+key)
print(json.dumps({'status':'six_target_pairs_replayed','pairs':6,'arrays_opened':0,'verification_atol':1e-12,'acceptance':None,'distribution_or_tensor_values_replayed':False},indent=2))
'''


def near(a, b):
    require(abs(finite(a)-finite(b)) <= 1e-12+5e-12*abs(b), 'independent arithmetic diagnostic differs')


def safe_e02(source, formal):
    expected_scope = {'target_pairs': 6, 'targets_per_pair': 159, 'distribution_pair_rows': 282,
        'distribution_rows_per_pair': 47, 'boundary_tensor_pairs': 98, 'global_sample_elements': 294784,
        'large_sources': 194, 'large_hash_passes': 2, 'raw_logits_files': 4,
        'BF16_values_per_raw_file': 41943040, 'sample_pack_files': 2}
    require(source['status'] == 'independent_observer_GPU_E02_matched' and source['all_metrics_matched'] is True and
        source['scope'] == expected_scope and len(source['original_large_sources']) == 194 and source['large_hash_passes'] == 2 and
        source['native_executions_started'] == 0 and source['acceptance'] is source['thresholds'] is None and source['full_core_complete'] is False and
        source['source_sha256'] == {'verifier': E02_VERIFIER_SHA, 'spec': E02_SPEC_SHA, 'independent_primitives': PRIMITIVE_SHA} and
        source['source_report']['sha256'] == REPORT_SHA and source['source_controller']['sha256'] == CONTROLLER_SHA and
        source['source_map']['sha256'] == SOURCE_MAP_SHA and source['selection']['sha256'] == E02_SPEC_SHA,
        'successful source-bound exact-scope E02 required')
    checks = []
    require(len(source['target_distribution_checks']) == 6, 'all six independent target/distribution contrasts required')
    for index, ((left, right), item, original) in enumerate(zip(itertools.combinations(MODES, 2),
            source['target_distribution_checks'], formal['target_distribution_pairs'])):
        require(item['pair_index'] == index and item['modes'] == [left, right] and len(item['distribution_rows']) == 47,
            'independent mode/row order differs')
        targets = {key: value for key, value in item['targets'].items() if key != 'max_coordinate'}
        targets['max_target_index'] = item['targets']['max_coordinate']['position']-1
        expected = target_metrics(original['targets']['metrics'])
        for key, value in targets.items(): near(value, expected[key])
        require(item['targets']['max_coordinate'] == original['targets']['metrics']['max_coordinate'], 'independent target coordinate differs')
        rows = []
        for ordinal, (row, shared) in enumerate(zip(item['distribution_rows'], original['distributions']['positions'])):
            require(row['position'] == POSITIONS[ordinal] and row['sample'] == shared['sample'] and row['union_count'] == shared['union_count'] and
                row['top1_agreement'] == shared['top1_agreement'] and row['max_error_token'] == shared['max_error_token'],
                'independent distribution discrete coordinate/identity differs')
            for key in ('tail_merged_js', 'probability_rmse', 'max_probability_error', 'top100_overlap'): near(row[key], number(shared[key]))
            for family in ('coverage', 'normalization_mass'):
                for key, value in row[family].items(): near(value, shared[family][key])
            sanitized = distribution_row(dict(row, tail_merged_js={'value': row['tail_merged_js'], 'status': 'no_thresholds'}), ordinal)
            sanitized['direct_complement_mass'] = {key: finite(row['direct_complement_mass'][key]) for key in ('side_a', 'side_b')}
            rows.append(sanitized)
        diagnostics = {}
        for key in ('probability_rmse', 'max_probability_error', 'tail_merged_js'):
            d = item['distribution_maximum_coordinate_diagnostics'][key]
            require(d['diagnostic_absolute_tolerance'] == 1e-12 and d['diagnostic_relative_tolerance'] == 5e-12 and
                d['model_acceptance_threshold'] is None and d['coordinate_checked_with_same_scalar_diagnostic_tolerance'] is True and
                d['reported_max_coordinate'] == original['distributions']['aggregate'][key]['max_coordinate'] and
                d['independent_exact_max_coordinate']['position'] in POSITIONS, 'frozen independent diagnostic semantics differ')
            diagnostics[key] = {'reported_max_prediction_index': d['reported_max_coordinate']['position'],
                'independent_exact_max_prediction_index': d['independent_exact_max_coordinate']['position'],
                **{name: finite(d[name]) for name in ('independent_unrounded_max_value', 'independent_value_at_reported_coordinate')},
                'diagnostic_absolute_tolerance': 1e-12, 'diagnostic_relative_tolerance': 5e-12, 'model_acceptance_threshold': None}
        checks.append({'pair_index': index, 'modes': [left, right], 'targets': targets, 'distribution_rows': rows,
            'distribution_maximum_coordinate_diagnostics': diagnostics})
    payload = {}
    for family, modes, count, values in (('raw_logits', MODES, 1, 41943040),
            ('boundary_samples', ['hooks-only', 'hooks-plus-dispatch-metadata'], 98, 294784)):
        group = source['payload_identity'][family]
        require(set(group['files']) == set(modes) and group['all_equal'] is True and group['physical_data_payloads_equal'] is True and
            group['file_headers_excluded'] is True and group['numeric_zero_was_not_used_as_bit_equality_evidence'] is True,
            'actual payload bit identity must come from source-bound hashes')
        files = {}
        for mode in modes:
            item = group['files'][mode]
            require(item['tensor_count'] == count and item['BF16_values'] == values and
                item['source']['size_bytes'] == item['header_bytes_excluded']+values*2 and item['header_bytes_excluded'] >= 8 and
                HEX.fullmatch(item['physical_data_payload_sha256']) and HEX.fullmatch(item['canonical_framed_sha256']),
                'BF16 payload framing differs')
            expected_names = {'logits'} if family == 'raw_logits' else set(BOUNDARIES)
            require(set(item['per_tensor']) == expected_names, 'exact tensor key inventory differs')
            for tensor in item['per_tensor'].values():
                require(tensor['shape'] == ([1, 160, 262144] if family == 'raw_logits' else [1, 47, 64]) and
                    tensor['values'] == (41943040 if family == 'raw_logits' else 3008) and HEX.fullmatch(tensor['data_sha256']),
                    'native BF16 tensor shape/count/data digest differs')
            files[mode] = {key: copy.deepcopy(item[key]) for key in ('tensor_count', 'BF16_values', 'physical_data_payload_sha256',
                'canonical_framed_sha256', 'header_bytes_excluded', 'per_tensor')}
            files[mode]['original_file_sha256'] = item['source']['sha256']
        require(len({v['physical_data_payload_sha256'] for v in files.values()}) ==
            len({v['canonical_framed_sha256'] for v in files.values()}) == 1, 'claimed equality contradicts actual digests')
        payload[family] = {'all_equal': True, 'physical_data_payloads_equal': True, 'files': files,
            'file_headers_excluded': True, 'numeric_zero_was_not_used_as_bit_equality_evidence': True}
    tensor = source['boundary_samples']; original_tensor = formal['boundary_sample_comparisons'][0]['metrics']
    require(set(tensor['per_tensor']) == set(BOUNDARIES), 'all98 independent boundary reductions required')
    def independent_tensor(a, b):
        require(a['count'] == b['count'] and a['max_flat_index'] == b['max_flat_index'], 'independent sample coordinate/count differs')
        for key in ('side_a_norm', 'side_b_norm', 'error_norm', 'rmse', 'cosine', 'max_abs'):
            if a[key] is None: require(number(b[key]) is None, 'independent undefined scalar differs')
            else: near(a[key], number(b[key]))
        return {key: a[key] for key in ('count', 'side_a_norm', 'side_b_norm', 'error_norm', 'rmse', 'cosine', 'max_abs', 'max_flat_index')}
    result = {'schema_version': 1, 'kind': 'sanitized-independent-observer-GPU-E02', 'record_id': RECORD,
        'source_report_sha256': E02_REPORT_SHA, 'source_controller_sha256': E02_CONTROLLER_SHA,
        'formal_report_sha256': REPORT_SHA, 'scope': expected_scope, 'all_metrics_matched': True,
        'target_distribution_checks': checks, 'boundary_samples': {
            'per_boundary': {name: independent_tensor(tensor['per_tensor'][name], original_tensor['per_tensor'][name]) for name in BOUNDARIES},
            'global': independent_tensor(tensor['global'], original_tensor['global'])}, 'payload_identity': payload,
        'source_sha256': source['source_sha256'], 'arithmetic': source['independent_arithmetic'],
        'diagnostic_verification': {'absolute_tolerance': 1e-12, 'relative_tolerance': 5e-12,
            'meaning': 'independent arithmetic/serialization verification; no model acceptance threshold'},
        'formal_metrics_rewritten': False, 'native_executions_started': 0, 'arrays_read_by_public_renderer': 0,
        'thresholds': None, 'acceptance': None, 'full_core_complete': False}
    privacy(result); return result


def relative(value):
    require(isinstance(value, str) and '\\' not in value, 'canonical relative POSIX metadata path required')
    p = PurePosixPath(value)
    require(not p.is_absolute() and p.as_posix() == value and value and all(x not in ('', '.', '..') for x in p.parts),
        'metadata path may not escape the private case')
    return p


class Inputs:
    def __init__(self): self.files = {}; self.total = 0
    def read(self, value, digest):
        path = CASE/relative(value)
        require(path.resolve().is_relative_to(CASE.resolve()) and not any(p.is_symlink() for p in (path, *path.parents) if p.is_relative_to(CASE)),
            'metadata ancestor symlink/path escape')
        raw = metadata(path, digest)
        if path not in self.files:
            self.total += len(raw); require(self.total <= 64*1024**2, 'metadata source budget exceeded')
            self.files[path] = (digest, len(raw))
        else: require(self.files[path] == (digest, len(raw)), 'same original has inconsistent SHA/size')
        return parse(raw) if path.suffix != '.py' else raw
    def recheck(self):
        for path, (digest, size) in self.files.items():
            require(len(metadata(path, digest)) == size, 'original metadata changed during rendering')


def source_bundle(spec_path, spec_sha):
    require(os.name == 'posix', 'production rendering binds original POSIX source paths; run in Linux')
    spec_raw = metadata(spec_path, spec_sha); spec = parse(spec_raw)
    require(spec['kind'] == 'private-observer-GPU-only-publication-plan' and spec['record_id'] == RECORD and
        spec['public_or_git_writes_authorized_for_this_tool'] is False and spec['acceptance'] is None and
        spec['full_core_complete'] is False, 'private exact-scope publication plan required')
    inputs = Inputs(); docs = {}
    refs = spec['source_documents']
    for key, ref in refs.items():
        require(set(ref) == {'case_path', 'sha256'}, 'explicit original metadata ref required')
        docs[key] = inputs.read(ref['case_path'], ref['sha256'])
    pinned = {'formal_report': REPORT_SHA, 'formal_controller': CONTROLLER_SHA, 'E02_report': E02_REPORT_SHA,
        'E02_controller': E02_CONTROLLER_SHA, 'E02_verifier': E02_VERIFIER_SHA, 'E02_spec': E02_SPEC_SHA,
        'matrix_v5': MATRIX_SHA, 'workload_v5': WORKLOAD_SHA, 'source_map': SOURCE_MAP_SHA}
    require(all(refs[key]['sha256'] == value for key, value in pinned.items()), 'frozen actual dependency pin differs')
    formal, controller, e02, ec = [docs[k] for k in ('formal_report', 'formal_controller', 'E02_report', 'E02_controller')]
    require(controller['task'] == 'OBSERVER-GPU-only-CPU' and controller['status'] == 'completed' and
        controller['returncode'] == controller['child_returncode'] == 0 and controller['timed_out'] is False and
        controller['remaining_owned_process_group'] is False and controller['report']['sha256'] == REPORT_SHA and
        controller['native_executions_started'] == 0 and ec['task'] == 'OBSERVER-GPU-E02' and ec['status'] == 'completed' and
        ec['returncode'] == 0 and ec['timed_out'] is False and ec['native_executions_started'] == ec['subprocesses_started'] == 0 and
        ec['report']['sha256'] == E02_REPORT_SHA and ec['verifier_sha256'] == E02_VERIFIER_SHA and ec['spec_sha256'] == E02_SPEC_SHA and
        ec['modified_original_sources'] is False, 'actual completed numeric and independent controllers required')
    for control, key in ((controller, 'formal_report'), (ec, 'E02_report')):
        require(control['report']['path'] == (CASE/relative(refs[key]['case_path'])).resolve().as_posix(),
            'original report identity/path differs; no path rewriting')
    for name, key in (('source_report', 'formal_report'), ('source_controller', 'formal_controller'), ('source_map', 'source_map')):
        require(e02[name]['case_path'] == refs[key]['case_path'] and e02[name]['sha256'] == refs[key]['sha256'], 'E02 original source role differs')
    require(ec['selection']['path'] == (CASE/relative(refs['E02_spec']['case_path'])).resolve().as_posix(), 'original selection path differs')
    root = PurePosixPath(refs['formal_report']['case_path']).parent
    scores = {}; adapter_paths = set()
    for index, pair in enumerate(formal['target_distribution_pairs']):
        for name, digest in pair['frozen_document_sha256'].items():
            require(relative(name).name == name, 'adapter basename only')
            p = (root/'analysis'/('scores-%02d' % index)/name).as_posix()
            value = inputs.read(p, digest); adapter_paths.add(p)
            if index == 0 and name == 'gpu-off-before-environment.json': docs['public_environment'] = value
            if name.endswith('-targets.json') and name.startswith('gpu-'):
                scores[(index, name[len('gpu-'):-len('-targets.json')])] = value
    for name, digest in formal['boundary_sample_comparisons'][0]['frozen_document_sha256'].items():
        require(relative(name).name == name, 'sample adapter basename only')
        p = (root/'analysis/samples-00'/name).as_posix(); inputs.read(p, digest); adapter_paths.add(p)
    require(len(adapter_paths) == 67, 'all67 original adapter documents must be byte-bound')
    env = docs['public_environment']
    require(env['rank'] == 0 and env['versions'] == env['actual']['software'] and env['actual']['hardware'] ==
        {'category': 'GPU', 'model': 'NVIDIA H100 80GB HBM3'} and env['actual']['execution_mode']['use_cache'] is False,
        'actual public environment identity differs')
    native, outer = docs['GPU_native_controller'], docs['GPU_outer']
    require(refs['GPU_native_controller']['sha256'] == formal['source_native_controller_sha256'] and
        refs['GPU_outer']['sha256'] == formal['original_outer_receipt_sha256'] and native['status'] == outer['status'] == 'completed' and
        native['returncode'] == outer['returncode'] == 0 and native['timed_out'] is outer['timed_out'] is False and
        native['remaining_descendants'] == [] and outer['native_forward_calls_total'] == 4 and outer['model_loads'] == 1,
        'actual original GPU model/capture terminal differs')
    map_root = (CASE/relative(refs['source_map']['case_path'])).parent
    array_catalog = { (map_root/relative(v['path'])).as_posix(): v for v in docs['source_map']['files'].values()
        if 'path' in v and PurePosixPath(v['path']).suffix in ('.npy', '.safetensors') }
    require(len(array_catalog) == 194, 'exact original194 large descriptors required without array I/O')
    expected_originals = {key: value for key, value in docs['source_map']['files'].items()
        if 'path' in value and PurePosixPath(value['path']).suffix in ('.npy', '.safetensors')}
    require(set(e02['original_large_sources']) == set(expected_originals), 'E02 original194-object identities differ')
    for key, value in e02['original_large_sources'].items():
        original = expected_originals[key]
        require(value['actual_path'] == (map_root/relative(original['path'])).as_posix() and value['sha256'] == original['sha256'] and
            value['size'] == original['size'] and value['backend'] == 'GPU' and value['large'] is True,
            'E02 full194 source/size/hash binding differs')
    for group in e02['payload_identity'].values():
        for item in group['files'].values():
            value = array_catalog.get(item['source']['path'])
            require(value and value['sha256'] == item['source']['sha256'] and value['size'] == item['source']['size_bytes'],
                'E02 raw/sample byte descriptor differs from original source map')
    nq = docs['NPU_failed_query']; failed = [x for x in nq['receipts'] if x.get('status') == 'failed']
    require(len(failed) == 1 and failed[0]['sha256'] == '605385b0baecc5c0864fa2302809a08bdb69bc15e2e5d58d3442ac93198d4d75' and
        failed[0]['returncode'] == 1 and failed[0]['remaining_descendants'] == [] and failed[0]['timed_out'] is False and
        failed[0]['output_dir'] is None and all(x.get('present') is False for x in nq['receipts'] if x is not failed[0]),
        'original pre-model failed NPU scope differs')
    diagnostic = docs['NPU_idle_diagnostic']
    require(refs['NPU_idle_diagnostic']['sha256'] == '7d4e5cf4e4ea5e30021af56bc7432935209d6460b8c83b871e2ad74d8150723a' and
        diagnostic['original_controller_sha256'] == failed[0]['sha256'] and diagnostic['failed_idle_gate_number'] == 1 and
        diagnostic['model_loads_started_by_failed_attempt'] == diagnostic['native_model_forward_calls_by_failed_attempt'] == 0 and
        diagnostic['native_model_work_retried'] is False and diagnostic['original_start_and_claim_remain_spent'] is True and
        diagnostic['signals_sent'] == 0 and diagnostic['native_activation_allowed'] is False,
        'source-bound first busy guard, no model/retry/stop diagnostic differs')
    for key in ('E02_failed_v1_controller', 'E02_failed_v2_controller'):
        d = docs[key]; require(d['status'] == 'failed' and d['returncode'] == 1 and d['native_executions_started'] == 0 and
            d['modified_original_sources'] is False, 'prior failed CPU E02 receipts must remain explicit')
    inputs.recheck(); return spec, docs, scores, inputs


def ledgers(matrix, workload, coverage, evidence):
    m, w = copy.deepcopy(matrix), copy.deepcopy(workload)
    m.update(created_utc='2026-11-07T01:25:38.375811+00:00', counts=coverage['counts'], public_summary_allowlist=coverage,
        current_GPU_only_observer_stage_complete=True, current_GPU_NPU_observer_stage_complete=False,
        next_execution='Preserve the scoped GPU observer proof. NPU observer needs a new bounded namespace and fresh idle/UUID guards; no old spent claim may rerun. Reserved-data, quality and performance remain separately gated.')
    by_id = {x['task_id']: x for x in coverage['tasks']}
    keys = ('status', 'observed_scope', 'gap', 'next_action', 'pilot_complete', 'full_plan_task_complete')
    for task in m['tasks']:
        if task['task_id'] in ('M01', 'M03', 'D03', 'O01', 'O02'):
            task.update({key: by_id[task['task_id']][key] for key in keys})
            task['evidence_keys'] = list(dict.fromkeys(task.get('evidence_keys', [])+list(evidence)))
    m['evidence'].update(evidence)
    m['previous_matrix'] = {'path': 'matrix-gpu-npu-v5.json', 'sha256': MATRIX_SHA}
    # Keep the old v5 bytes and stale internal workload pointer as historical
    # evidence, while v6 points to the actually hashed new workload below.
    m['retained_v5_declared_workload_reference'] = matrix['workload']
    w.update(created_utc=m['created_utc'], state='GPU_only_observer_numeric_and_independent_E02_verified_NPU_pre_model_busy',
        title='Gemma4 base H100 TP1 observer transparency; historical GPU/NPU pilots retained',
        previous_workload={'path': 'workload-gpu-npu-v5.json', 'sha256': WORKLOAD_SHA},
        next_execution=m['next_execution'])
    w.setdefault('retained_prior_stage_scopes', {})['I04'] = copy.deepcopy(workload['measured_scope'])
    w['measured_scope'] = {'backend': 'GPU', 'independent_inputs': 1, 'same_loaded_model_processes': 1, 'native_calls': 4,
        'unique_target_scores': 636, 'unique_full_vocabulary_rows': 188, 'target_distribution_pairs': 6,
        'distribution_pair_rows': 282, 'sampled_boundary_pairs': 98, 'sampled_global_elements': 294784,
        'independent_E02_all_rows_and_samples': True, 'raw_logits_payload_bit_identity': True,
        'boundary_sample_payload_bit_identity': True, 'NPU_observer_model_loads': 0, 'NPU_observer_complete': False,
        'P01_measured': False, 'thresholds': None, 'acceptance': None, 'full_core_complete': False}
    w['evidence'].update(evidence)
    w['resources']['this_file_starts_or_authorizes_jobs'] = False
    w['resources']['observer'] = {'GPU_capture': 'completed; platform subsequently observed stopped by root',
        'NPU_capture': 'first shared-instance idle guard failed before model; permanent launch spent; no process stopped',
        'complete_platform_lifetime_and_billing_known': False}
    m['workload'] = {'path': 'workload-gpu-npu-v6.json', 'sha256': sha(encoded(w))}
    require(all(a['task_id'] == b['task_id'] and a['profile'] == b['profile'] and a['expected_coverage'] == b['expected_coverage']
        for a, b in zip(matrix['tasks'], m['tasks'])), 'v6 changed original task identities')
    return m, w


def documents(targets, metrics, e02, docs, coverage):
    formal = docs['formal_controller']; independent = docs['E02_controller']
    intervals = [{'phase': 'formal_GPU_only_CPU_admission', 'status': 'completed', 'seconds': finite(formal['elapsed_seconds']),
        'source_controller_sha256': CONTROLLER_SHA}]
    for key, name in (('E02_failed_v1_controller', 'independent_E02_v1_failed'), ('E02_failed_v2_controller', 'independent_E02_v2_failed'),
            ('E02_controller', 'independent_E02_v3_completed')):
        c = docs[key]; intervals.append({'phase': name, 'status': c['status'], 'seconds': finite(c['elapsed_seconds']),
            'source_controller_sha256': None})
    # Exact source hashes come from the publication plan, never from re-encoding
    # an original controller document.
    cost = {'schema_version': 1, 'record_id': RECORD, 'monetary_cost': None, 'currency': None, 'rate': None,
        'invoice_or_billed_GPU_hours_known': False, 'recorded_CPU_intervals': intervals,
        'complete_executed_CPU_setup_failure_and_transfer_time_known': False,
        'recorded_intervals_are_not_a_total_and_may_overlap': True,
        'CPU_intervals_are_not_GPU_billing_or_P01': True, 'native_capture_repeated_after_CPU_failures': False,
        'original_data_bytes': 730988032, 'large_file_bytes_including_headers': 731029648,
        'logical_export_bytes': 752633169, 'original_archive_bytes': 355832914,
        'NPU_failed_pre_model_wall_seconds': finite(next(x for x in docs['NPU_failed_query']['receipts'] if x.get('status') == 'failed')['wall_seconds']),
        'NPU_shared_instance_occupant_workload_or_owner_known': False, 'acceptance': None, 'P01_measured': False}
    cost['instrumented_native_source_intervals'] = []
    for key, label in (('GPU_native_controller', 'original GPU source controller including preconditions and instrumented capture'),
            ('GPU_outer', 'original four-forward instrumented capture outer interval')):
        value = docs[key]
        start, finish = [datetime.fromisoformat(value[name].replace('Z', '+00:00')) for name in ('started_utc', 'finished_utc')]
        seconds = (finish-start).total_seconds(); require(0 <= seconds <= 3600, 'source instrumented interval outside declared bound')
        cost['instrumented_native_source_intervals'].append({'phase': label, 'seconds_from_source_UTC': seconds,
            'P01_latency': False, 'GPU_billing_interval': False})
    nll = metrics['target_distribution_pairs'][0]['targets']['side_a_nll_nat_per_token']
    raw = e02['payload_identity']['raw_logits']['files']['off-before']; sample = e02['payload_identity']['boundary_samples']['files']['hooks-only']
    report = f'''# Gemma4 H100 observer transparency

Four cache-off forwards of one loaded Gemma4-12B base model on one H100 produced bit-identical native BF16 logits payloads for this fixed input. The two enabled modes also produced bit-identical retained boundary sample payloads. The modes were off-before, hooks-only, off-after, and hooks plus frontend dispatch metadata. This is a GPU-only observer check. The NPU attempt failed at the first shared-instance busy-process guard before model load; its launch claim remains spent, and no other process was stopped. Busy-process workload ownership was not established.

The model revision is `{MODEL['revision']}`, input digest `{INPUT_SHA}`, with BF16 parameters/native logits, eager attention, seed0 and TP1. Each mode consumed the same128+32 known tokens in one160-token forward with `use_cache=False` and `logits_to_keep=0`. The159 scores include127 prompt and32 continuation targets; the final raw prediction159 has no known next target.

All six within-GPU target contrasts have NLL `{nll}` nat/token and zero NLL difference, MAE, linear P99 and maximum target error. The formal282 sampled distribution contrasts have zero top100-union probability errors and tail-merged JS, with top1 agreement and top100 overlap1. These probability metrics use the top100 union and an exact complementary tail bin; they are not full-vocabulary error or KL. The98 sampled boundary comparisons cover scaled embedding output,48 block inputs/outputs and final norm output. Each BF16 sample is `[1,47,64]` (3008 elements), giving294784 paired elements, zero RMSE/max error and global cosine1. Per-boundary cosine roundoff is retained unchanged in the JSON.

Independent CPU E02 recomputed all6x159 target reductions, all282 distribution rows, all98 boundary reductions and the global sample reduction; all194 original large objects were fully byte-hashed before and after. It also verified actual BF16 payload identity for the four `[1,160,262144]` logits files (41943040 values each) and the two98-tensor sample packs. Whole safetensors headers contain mode metadata and are excluded from this payload comparison. Raw payload SHA256 is `{raw['physical_data_payload_sha256']}`; sample payload SHA256 is `{sample['physical_data_payload_sha256']}`. Identity comes from these actual bytes, not from zero metrics alone.

The formal JS remains zero with its tied maximum at prediction0. Independent scalar arithmetic retained a maximum JS residual `4.7021875179805497e-17` at prediction144; its value at the formal maximum is zero. The verifier predeclared absolute1e-12/relative5e-12 arithmetic diagnostic tolerances. These are verification tolerances; acceptance thresholds remain null. Formal metrics and independent residuals are both preserved.

The loaded static inventory has875 module-name records,630 named parameter entries and629 observed unique parameter objects. Each enabled mode recorded863 fired modules and864 invocations, including an explicit12-record zero-fired census. Dispatch metadata recorded5604 frontend invocations/4922 scoped signatures. Static inventory and frontend overload/shape/dtype records do not identify executed kernels, fusion, accumulation precision or local numerical causes. Same loaded eval model, complete RNG and available observed state equality were checked. The original scalar BF16 buffer fingerprint gap remains explicit; complete parameter/buffer byte attestation is false.

This adds scoped partial evidence to D03/O01/O02 and extends existing M01/M03 evidence. The49-task ledger remains9 scoped complete,9 partial,8 pending,21 deferred and2 not applicable. Full core completion, fresh-process repeatability, quality preservation, P01 performance and the GPU/NPU observer comparison remain incomplete. Monetary cost and billed GPU hours are unknown; recorded CPU intervals include both failed E02 attempts and the successful version. Historical evidence remains preserved.

Run `python -S -B replay-targets.py selected-targets.json selected-metrics.json` to replay the six anonymous target contrasts using stdlib. This opens zero arrays and does not independently recompute distributions or boundary samples. See [metrics](selected-metrics.json), [independent E02](e02-summary.json), [coverage](coverage.json), and [recorded cost scope](cost.json).
'''
    privacy(cost); privacy(report); return report.encode(), cost


def render(spec_path, spec_sha, output, phase):
    # Do not create even a candidate directory from guessed future E02 evidence.
    require(all(isinstance(value, str) and HEX.fullmatch(value) for value in (E02_REPORT_SHA, E02_CONTROLLER_SHA)),
            'actual observer E02 report/controller are not yet frozen; publication stays closed')
    started = time.monotonic(); previous = signal.getsignal(signal.SIGALRM) if hasattr(signal, 'SIGALRM') else None
    def expired(*_): raise TimeoutError('private metadata rendering exceeded120 seconds')
    if previous is not None: signal.signal(signal.SIGALRM, expired); signal.alarm(120)
    try:
        output = Path(output).absolute(); case = CASE.resolve()
        require(output.resolve().is_relative_to(case/'transfer') or output.resolve().is_relative_to(case/'runs'), 'private candidate destination only')
        require(not output.exists() and not any(p.is_symlink() for p in output.parents if p.is_relative_to(case)), 'fresh nonsymlink candidate directory required')
        spec, docs, scores, inputs = source_bundle(spec_path, spec_sha)
        targets, metrics = safe_main(docs['formal_report'], scores); e02 = safe_e02(docs['E02_report'], docs['formal_report'])
        env = docs['public_environment']['actual']
        metrics['environment'] = {key: copy.deepcopy(env[key]) for key in ('hardware', 'software', 'backend_policy')}
        metrics['implementation_sha256'] = env['execution_mode']['implementation_sha256']
        metrics['independent_E02'] = {'report_sha256': E02_REPORT_SHA, 'controller_sha256': E02_CONTROLLER_SHA,
            'all_metrics_matched': True, 'large_hash_passes': 2, 'payload_identity': e02['payload_identity']}
        coverage = coverage_v6(docs['matrix_v5'])
        report, cost = documents(targets, metrics, e02, docs, coverage)
        for item, key in zip(cost['recorded_CPU_intervals'], ('formal_controller', 'E02_failed_v1_controller', 'E02_failed_v2_controller', 'E02_controller')):
            item['source_controller_sha256'] = spec['source_documents'][key]['sha256']
        evidence = {'observer_'+key: {'path': ref['case_path'], 'sha256': ref['sha256']} for key, ref in spec['source_documents'].items()
            if key not in ('matrix_v5', 'workload_v5')}
        matrix, workload = ledgers(docs['matrix_v5'], docs['workload_v5'], coverage, evidence)
        batches = {'numeric': {'selected-targets.json': encoded(targets), 'selected-metrics.json': encoded(metrics), 'replay-targets.py': replay_source().encode()},
            'documents': {'report.md': report, 'coverage.json': encoded(coverage), 'cost.json': encoded(cost)},
            'ledger': {'matrix-gpu-npu-v6.json': encoded(matrix), 'workload-gpu-npu-v6.json': encoded(workload), 'e02-summary.json': encoded(e02)}}
        require(phase in batches and len(batches[phase]) == 3, 'exact private three-artifact phase required')
        for name, raw in batches[phase].items():
            require(len(raw) <= 16*1024**2, 'output member cap exceeded')
            if not name.startswith(('matrix-', 'workload-')): privacy(parse(raw) if name.endswith('.json') else raw.decode())
        inputs.recheck(); require(metadata(spec_path, spec_sha) == encoded(spec), 'original plan bytes changed/noncanonical')
        output.mkdir(parents=False)
        for name, raw in batches[phase].items():
            with (output/name).open('xb') as handle: handle.write(raw); handle.flush(); os.fsync(handle.fileno())
        inputs.recheck()
        result = {'status': 'private_observer_publication_candidates_created', 'phase': phase, 'files': {
            name: {'sha256': sha(raw), 'size_bytes': len(raw)} for name, raw in batches[phase].items()},
            'source_metadata_files_rehashed': len(inputs.files), 'arrays_statted_opened_or_copied': 0,
            'public_or_git_writes': 0, 'elapsed_seconds': time.monotonic()-started, 'acceptance': None}
        print(json.dumps(result, indent=2)); return result
    finally:
        if previous is not None: signal.alarm(0); signal.signal(signal.SIGALRM, previous)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for key in ('spec', 'output'): p.add_argument('--'+key, type=Path, required=True)
    p.add_argument('--spec-sha256', required=True); p.add_argument('--phase', choices=('numeric', 'documents', 'ledger'), required=True)
    args = p.parse_args(); render(args.spec, args.spec_sha256, args.output, args.phase)

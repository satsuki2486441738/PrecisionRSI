"""Unactivated v2 reserved48 progress-aligned stage/budget, portable preconditions and finite jobs.

Only preparation is authorized by this source. Every production activation pin
is None. Original CPU/I04 wrappers keep their kinds and bytes. A new native
prerequisite asserts verified preconditions, never observed native execution.
"""
import argparse
import ctypes
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import subprocess
import sys
import time

CASE = 'projects/gemma4-pilot/cases/text-native'
TASK = 'gemma4-reserved48-i05-q01-v1'
STAGE_ID = 'gemma4-gpu-npu-reserved48-i05-q01-v1'
NAMESPACE = 'reserved48-i05-q01-20261107'
BACKEND_ROOTS = {'GPU':'/srv/precision-task/'+NAMESPACE+'/gpu',
    'NPU':'/srv/npu-precision-task/'+NAMESPACE+'/npu'}
BINS = (128, 512, 2048, 8192)
NATIVE = dict(zip(BINS, (1800, 2700, 4500, 10800)))
PER_INPUT = dict(zip(BINS, (90, 150, 300, 720)))
WHOLE = {P: NATIVE[P] + 2700 for P in BINS}
EXPORT, CLEANUP = 960, 60
GIB = 1024**3
MANIFEST_SHA = '10f6b1a6976507e1af65706ddd4bb61d9276c43ae443b2a6852935e2967dca37'
EXPECTED_SOURCE = 'ad229e986bab26fb697ab58120d63b948123c3ad52a1a51383a09495e719c05e'
CPU_CHECKER_SHA = '5b6d11ce989e84c3d777f0136fd3e74c5ac410f66bb78f35ea3fb6c317e9bdcd'
I04_CHECKER_SHA = '610e349ae0ba0be42fc683ccb7fd573255c080d835c09f07f4dee73edf98aa4c'
I04_SHA = '59830ffb67bafb2c0497ef954392fb4fc830dc388afc16a7750195cd09986e54'
ACTUAL_CPU_PORTABLE_SHA = '5f798c29e0cbe28d0f17869e49774631c51b2f4d01ad8cbd6195ef3844cc4f07'
RECORD_SHA = '2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'
CLEANUP_SHA = 'c1719e831a557cd9707374138d9219a8ae887854dd029a1ec165631d9259f485'
# The observed source-side CPU query is not local byte admission.
GATES = {'cpu_portable_sha256': None, 'native_prerequisite_sha256': None, 'stage_sha256': None, 'budget_sha256': None, 'expected_inventory_sha256': None, 'expected_builder_sha256': None, 'native_endpoint_schema_reviewed': None}
HEX = re.compile(r'^[a-f0-9]{64}$')


def require(ok, message):
    if not ok: raise ValueError(message)


def utc(): return datetime.now(timezone.utc).isoformat()
def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(4*1024**2), b''): h.update(block)
    return h.hexdigest()


def read(path):
    def pairs(items):
        result = {}
        for key, value in items: require(key not in result, 'duplicate JSON key'); result[key] = value
        return result
    return json.loads(Path(path).read_bytes(), object_pairs_hook=pairs,
        parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))


def put(path, document):
    raw = (json.dumps(document, indent=2, allow_nan=False)+'\n').encode()
    require(len(raw) <= 16*1024**2, 'metadata exceeds16MiB')
    with Path(path).open('xb') as f: f.write(raw)


def relative(name):
    require(isinstance(name, str) and name and '\\' not in name and not PurePosixPath(name).is_absolute() and
        str(PurePosixPath(name)) == name and all(x not in ('', '.', '..') for x in name.split('/')), 'canonical relative POSIX path required')
    return PurePosixPath(name)


def absolute(name):
    require(isinstance(name, str) and name.startswith('/') and '\\' not in name and
        str(PurePosixPath(name)) == name and '..' not in PurePosixPath(name).parts, 'canonical absolute POSIX identity required')
    return PurePosixPath(name)


def file_ref(path, root=None, limit=16*1024**2):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= limit, 'bounded regular source required')
    if root is not None:
        root = Path(root); require(path.resolve().is_relative_to(root.resolve()), 'source escapes declared root')
        cursor = path
        while cursor != root: require(not cursor.is_symlink(), 'source ancestor symlink'); cursor = cursor.parent
    return {'path': str(path.resolve()), 'sha256': sha(path), 'size_bytes': path.stat().st_size}


def load_module(path, digest, name):
    require(isinstance(digest, str) and HEX.fullmatch(digest) and file_ref(path)['sha256'] == digest, 'pinned pure source remains unready or changed')
    spec = importlib.util.spec_from_file_location(name, path); module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    require(not any(x in sys.modules for x in ('torch', 'torch_npu', 'numpy', 'transformers')), 'pre-native helper imported a framework')
    return module


def ready():
    require(all(isinstance(v, str) and HEX.fullmatch(v) for k, v in GATES.items() if k != 'native_endpoint_schema_reviewed') and
        GATES['native_endpoint_schema_reviewed'] is True and GATES['cpu_portable_sha256']==ACTUAL_CPU_PORTABLE_SHA,
        'reserved48 lifecycle/stage/budget/proof remains unready')


def proposed_stage():
    """Candidate values only: no writer, allocation or activation side effect."""
    return {'schema_version': 1, 'task': TASK, 'stage_id': STAGE_ID, 'status': 'prepared_not_executed',
        'manifest_sha256': MANIFEST_SHA, 'native_tasks': ['I05', 'Q01'], 'input_prompt_bins': list(BINS),
        'native_capture_schema_version': 2, 'expected_inventory_schema_version': 2, 'progress_schema_version': 1,
        'progress_scope': 'Durable claim-side plan/entry/synchronized-return/source-summary/terminal; absence or truncation means unknown',
        'inputs_per_bin': 12, 'modes': ['full', 'token', 'chunk'], 'calls_per_input': 68,
        'calls_per_bin': 816, 'calls_per_backend': 3264, 'observations_per_backend': 144,
        'model_loads_per_backend_if_all_bins_run': 4, 'pairs_per_input': 9, 'input_pair_contrasts': 432,
        'correlated_distribution_pair_positions': 20304, 'selected_original_BF16_rows_per_backend': 6768,
        'all_target_scalars_per_backend': 396144, 'valid_raw_finite_source_claims_per_backend': 396288,
        'maximum_parallel_H100_bin_jobs_possible': 4, 'H100_parallelism_selected': 4,
        'native_task_roots': {side:{str(P):root+'/p%04d-v1'%P for P in BINS} for side,root in BACKEND_ROOTS.items()},
        'required_actual_proof_sha256': {'reserved48_CPU':ACTUAL_CPU_PORTABLE_SHA,'I04_numeric':I04_SHA},
        'NPU_concurrent_model_jobs': 1, 'no_automatic_retry': True, 'thresholds': None, 'acceptance': None,
        'independent_all_target_normalizers': False, 'full_unselected_raw_retained': False,
        'Q02_executed': False, 'P01_executed': False, 'resources_allocated_by_spec': 0,
        'proof_activation': 'Actual CPU98-doc and I04 eight-doc bytes plus source/lifecycle review required; None pins refuse.'}


def proposed_budget(stage_sha):
    require(isinstance(stage_sha, str) and HEX.fullmatch(stage_sha), 'explicit stage SHA required; budget never back-binds into stage')
    return {'schema_version': 1, 'task': TASK, 'stage_sha256': stage_sha, 'state': 'proposed_not_activated', 'limits': {
        'native_seconds_by_prompt_bin': {str(P): NATIVE[P] for P in BINS},
        'per_input_seconds_by_prompt_bin': {str(P): PER_INPUT[P] for P in BINS},
        'whole_seconds_by_prompt_bin': {str(P): WHOLE[P] for P in BINS},
        'controller_work_seconds_by_prompt_bin': {str(P): WHOLE[P]-EXPORT-CLEANUP for P in BINS},
        'source_wait_seconds': 120, 'bootstrap_proposed_seconds': 600, 'postcapture_validation_proposed_seconds': 300,
        'generic_timeout_extra_seconds': 30, 'source_export_whole_seconds': EXPORT, 'cleanup_seconds': CLEANUP,
        'unassigned_explicit_controller_slack_seconds': 630, 'external_hard_watchdog_required': True,
        'mode_product_bytes': 48*1024**2, 'input_product_bytes': 160*1024**2, 'bin_product_bytes': 2*GIB,
        'cohort_product_bytes': 8*GIB, 'new_task_product_bytes': 12*GIB,
        'initial_source_free_bytes': 64*GIB, 'minimum_source_free_bytes': 8*GIB,
        'cpu_row_chunk': 32, 'source_cpu_slab_working_memory_bytes': 512*1024**2,
        'minimum_free_device_bytes': 35*GIB, 'minimum_gpu_host_effective_available_bytes': 40*GIB,
        'minimum_npu_host_effective_available_bytes': 80*GIB,
        'logical_wire_bytes_per_direction': 4*GIB, 'encoded_wire_bytes_per_direction': 4*GIB,
        'wire_chunk_data_bytes': 256*1024**2, 'metadata_member_bytes': 16*1024**2, 'metadata_total_bytes': 512*1024**2,
        'CPU_per_bin_seconds': 3600, 'CPU_cleanup_seconds': 20, 'CPU_cohort_product_bytes': 64*GIB,
        'CPU_initial_free_bytes': 96*GIB, 'CPU_max_working_memory_bytes': 512*1024**2},
        'known_selected_BF16_payload_bytes_per_bin_backend': 887095296,
        'known_selected_BF16_payload_bytes_per_backend': 3548381184,
        'known_new_CPU_FP64_bytes_per_bin_both_backends': 7096762368,
        'known_new_CPU_FP64_bytes_cohort_both_backends': 28387049472,
        'largest_temporary_device_raw_logits_bytes': 4311547904,
        'runtime_restore_free_guard': 'Actual verified expanded environment +512MiB scratch +2GiB headroom on the actual restore volume',
        'caps_are_not_runtime_estimates_or_storage_reservations': True,
        'failure': 'OOM/nonfinite/timeout spends this bin claim; preserve partials and explicit unexecuted cells, no truncation/fallback/retry',
        'wire': 'Original47 BF16 fullV rows only; NEW CPU FP64 rows are not source GPU/NPU arrays. Actual wrappers/headers/metadata count toward caps.'}


def proposed_cpu_budget(stage_sha):
    """Separate flat CPU budget matching the reviewed00be/bee6 helper API.

    Native cleanup60 and CPU cleanup20 are different envelopes. They are never
    smuggled into the same cleanup_seconds field or presented as executed caps.
    """
    require(isinstance(stage_sha,str) and HEX.fullmatch(stage_sha),'explicit frozen stage SHA required')
    return {'schema_version':1,'task':TASK,'stage_sha256':stage_sha,'state':'proposed_not_activated','limits':{
        'per_bin_cpu_seconds':3600,'cleanup_seconds':20,'cpu_row_chunk':32,'maximum_working_memory_bytes':512*1024**2,
        'maximum_bin_product_bytes':12*GIB,'maximum_cohort_product_bytes':64*GIB,'minimum_free_before_start_bytes':96*GIB},
        'source_rows':'Original BF16 safetensors logits[47,262144], exact vocabulary/47 prediction coordinates and raw row byte hashes',
        'new_arrays':'NEW little-endian FP64 NumPy [47,262144]; descriptor scores={path:absolute_NEW_npy,row:0..46}',
        'owning_tools':{'derive_logprobs':'skills/precision-compare/scripts/inference_capture.py',
            'array_decoder':'skills/precision-compare/scripts/artifact_io.py','matrix_row_facade':'skills/precision-compare/scripts/compare_distributions.py:11-21',
            'weighted_global_score_reduction':'skills/precision-compare/scripts/score_metrics.py'},
        'independent_all_target_normalizers':False,'unselected_raw_not_retained':True,'Q02_executed':False,'P01_executed':False,
        'limits_are_proposals_not_activated_or_reserved':True}


def prerequisite(path, digest):
    """New transparent native-precondition wrapper around unchanged two proofs."""
    require(isinstance(digest,str) and HEX.fullmatch(digest), 'explicit external native prerequisite SHA required')
    path = Path(path);require(not path.is_symlink(),'native prerequisite wrapper symlink');path=path.resolve(strict=True)
    require(file_ref(path)['sha256'] == digest, 'native prerequisite byte SHA differs'); doc = read(path)
    require(set(doc) == {'schema_version', 'kind', 'cpu', 'i04', 'checker_sources', 'preconditions_only', 'native_executions_started', 'native_execution_allowed_by_prerequisite'} and
        doc['schema_version'] == 1 and doc['kind'] == 'reserved48-native-prerequisite' and doc['preconditions_only'] is True and
        doc['native_executions_started'] == 0 and doc['native_execution_allowed_by_prerequisite'] is False, 'transparent precondition-only wrapper required')
    refs = {}
    def get(item, checker=False):
        require(set(item) == ({'path','sha256'} if checker else {'path','source_path','sha256'}), 'exact portable proof/checker reference required')
        if not checker:absolute(item['source_path'])
        p = path.parent.joinpath(*relative(item['path']).parts)
        value = file_ref(p, path.parent); require(value['sha256'] == item['sha256'], 'portable proof/checker byte SHA differs'); return p, value
    cpu, cpu_ref = get(doc['cpu']); scientific, scientific_ref = get(doc['i04'])
    require(cpu_ref['sha256'] == ACTUAL_CPU_PORTABLE_SHA and scientific_ref['sha256'] == I04_SHA, 'two original proof wrapper identities differ')
    require(set(doc['checker_sources']) == {'cpu', 'i04'}, 'both reviewed pure checker sources required')
    checked = {}
    for label, pinned in (('cpu', CPU_CHECKER_SHA), ('i04', I04_CHECKER_SHA)):
        p, value = get(doc['checker_sources'][label],True); require(value['sha256'] == pinned, 'pure checker source changed')
        checked[label] = load_module(p, pinned, '_reserved48_'+label+'_preconditions'); refs['checker/'+label] = value
    a = checked['cpu'].prerequisite(cpu, cpu_ref['sha256']); b = checked['i04'].i04_prerequisite(scientific, I04_SHA)
    require(a['document']['kind'] == 'reserved48-cpu-validation-prerequisite-v1' and len(a['refs']) == 98 and len(b['refs']) == 8 and
        a['native_executions_started'] == b['native_executions_started'] == 0, 'actual98 CPU and8 numeric raw documents required')
    refs.update({'cpu/'+k: v for k, v in a['refs'].items()}); refs.update({'i04/'+k: v for k, v in b['refs'].items()})
    refs.update({'cpu-wrapper': cpu_ref, 'i04-wrapper': scientific_ref, 'native-wrapper': file_ref(path)})
    for value in refs.values(): require(file_ref(value['path']) == value, 'original copied prerequisite changed')
    return {'document': doc, 'refs': refs, 'prerequisite_sha256': digest, 'native_executions_started': 0,
        'scope': 'Metadata preconditions only; original CPU/I04 proof kinds unchanged, no new native evidence or acceptance.'}


def build_prerequisite(cpu_path, i04_path, cpu_checker, i04_checker, output, original_wrapper_sources):
    """Copy only the actual110 prerequisite refs into a NEW portable wrapper.

    This metadata operation does not fill GATES or permit model execution.
    The original source-side CPU export controller JSON is absent from its
    portable proof and is not fabricated here.
    """
    require(set(original_wrapper_sources)=={'cpu','i04'},'two externally observed original POSIX wrapper identities required')
    for name in ('cpu','i04'):absolute(original_wrapper_sources[name])
    normalized=[]
    for p in (cpu_path,i04_path,cpu_checker,i04_checker):
        p=Path(p);require(not p.is_symlink(),'original proof/checker symlink');normalized.append(p.resolve(strict=True))
    cpu_path,i04_path,cpu_checker,i04_checker=normalized
    cpu = load_module(cpu_checker,CPU_CHECKER_SHA,'_reserved48_build_cpu_preconditions').prerequisite(cpu_path,ACTUAL_CPU_PORTABLE_SHA)
    numerical = load_module(i04_checker,I04_CHECKER_SHA,'_reserved48_build_i04_preconditions').i04_prerequisite(i04_path,I04_SHA)
    require(len(cpu['refs'])==98 and len(numerical['refs'])==8 and cpu['native_executions_started']==numerical['native_executions_started']==0,'exact actual98+8 raw proof documents required')
    output=Path(output);require(not output.exists() and not output.is_symlink() and output.parent.is_dir(),'exclusive new proof directory required');output=output.resolve();output.mkdir(mode=0o700)
    def copy(original, target):
        original=Path(original);before=file_ref(original);target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:f.write(original.read_bytes())
        require(file_ref(original)==before and sha(target)==before['sha256'],'original proof changed while copying')
    wrappers={}
    for label,path,checked in (('cpu',Path(cpu_path),cpu),('i04',Path(i04_path),numerical)):
        target=output/label/'prerequisite.json';copy(path,target)
        for value in checked['refs'].values():
            original=Path(value['path']);rel=original.relative_to(path.parent);relative(rel.as_posix());copy(original,output/label/rel)
        wrappers[label]={'path':label+'/prerequisite.json','source_path':original_wrapper_sources[label],'sha256':sha(path)}
    checkers={}
    for label,path,digest in (('cpu',Path(cpu_checker),CPU_CHECKER_SHA),('i04',Path(i04_checker),I04_CHECKER_SHA)):
        copy(path,output/'checkers'/path.name);checkers[label]={'path':'checkers/'+path.name,'sha256':digest}
    doc={'schema_version':1,'kind':'reserved48-native-prerequisite',**wrappers,'checker_sources':checkers,'preconditions_only':True,
        'native_executions_started':0,'native_execution_allowed_by_prerequisite':False}
    path=output/'prerequisite.json';put(path,doc);checked=prerequisite(path,sha(path))
    require(len(checked['refs'])==111,'new wrapper plus110 unchanged prerequisite refs required')
    return {'prerequisite':file_ref(path),'refs':len(checked['refs']),'native_executions_started':0,'production_gates_changed':False,
        'original_CPU_export_controller_bytes_locally_attested':False}


def process_start(pid): return int((Path('/proc')/str(pid)/'stat').read_text().rpartition(')')[2].split()[19])


@contextmanager
def entry_deadline(prompt_bin):
    require(os.name=='posix' and prompt_bin in BINS,'explicit finite POSIX bin required')
    def stop(*_):raise TimeoutError('reserved48 complete bin entry deadline/signal; no retry')
    previous={sig:signal.signal(sig,stop) for sig in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
    signal.setitimer(signal.ITIMER_REAL,WHOLE[prompt_bin]-EXPORT-CLEANUP)
    try:yield
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        for sig,handler in previous.items():signal.signal(sig,handler)


def source_context(path, digest, backend):
    ready(); started = time.monotonic(); config_digest=digest
    require(sha(path) == config_digest, 'external bin launch config SHA differs'); doc = read(path); P = doc['prompt_bin']
    require(doc['schema_version'] == 1 and doc['task'] == TASK and doc['backend'] == backend and P in BINS and
        doc['model_loads'] == doc['native_launches'] == 1 and doc['automatic_retry'] is False and
        doc['native_capture_schema_version']==2 and doc['progress_schema_version']==1, 'one new independent12-input bin launch required')
    root = Path(str(absolute(doc['task_root']))); source = Path(str(absolute(doc['source_root'])))
    require(str(root) == BACKEND_ROOTS[backend]+'/p%04d-v1'%P and root.name == 'p%04d-v1'%P and root.parent.name == backend.lower() and root.parent.parent.name == NAMESPACE and
        root.is_dir() and not root.is_symlink() and source.is_dir() and not source.is_symlink() and source.resolve().is_relative_to(root.resolve()), 'exact new bin namespace required')
    manifest = read(doc['source_manifest']['path']); require(file_ref(doc['source_manifest']['path'], root) == doc['source_manifest'] and
        manifest['task'] == TASK and isinstance(manifest['files'], dict) and set(manifest['files']) == set(manifest['inventory']), 'typed new source manifest required')
    require({p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()} == set(manifest['files']) and
        all(not p.is_symlink() for p in source.rglob('*')) and len(manifest['files'])<=512, 'exact bounded non-symlink source inventory required')
    frozen = {str(Path(path).resolve()): config_digest}
    total=0
    for name, file_digest in manifest['files'].items():
        require(not name.lower().endswith(('.npy','.safetensors','.pt','.whl','.tar','.gz','.part')),'unplanned native/model/archive source file refused before IO')
        item = manifest['inventory'][name]
        p = source.joinpath(*relative(name).parts); value = file_ref(p, source, 1024**2 if name.endswith('.py') else 16*1024**2)
        require(set(item) == {'sha256','size_bytes','kind'} and type(item['size_bytes']) is int and item['kind'] == ('code' if name.endswith('.py') else 'metadata') and
            value['sha256'] == item['sha256'] == file_digest and value['size_bytes'] == item['size_bytes'], 'typed source size/SHA differs'); frozen[value['path']] = value['sha256']
        total+=value['size_bytes'];require(total<=512*1024**2,'source metadata closure exceeds512MiB')
    reviewed=doc['reviewed_source_sha256'];require(set(reviewed)=={'collector','common','lifecycle'} and
        all(isinstance(x,str) and HEX.fullmatch(x) for x in reviewed.values()),'externally frozen prepared-config source pins required')
    # Lifecycles pin this contract; new capture source may also pin its proof
    # helper. Reverse source pins here would form an impossible hash cycle.
    # Their reviewed bytes are instead bound by the externally pinned prepared
    # config and its exact typed deployment manifest.
    for name, reviewed_digest in ((doc['collector_relative_path'], reviewed['collector']),
                        (doc['common_relative_path'], reviewed['common']),
                        (doc['lifecycle_relative_path'], reviewed['lifecycle']),
                        (doc['recorder_relative_path'], RECORD_SHA), (doc['cleanup_relative_path'], CLEANUP_SHA)):
        require(manifest['files'][relative(name).as_posix()] == reviewed_digest, 'actual reviewed collector/lifecycle/helper source differs')
    for label, gate in (('stage_spec', 'stage_sha256'), ('budget', 'budget_sha256'), ('expected_inventory', 'expected_inventory_sha256'), ('prerequisite', 'native_prerequisite_sha256')):
        value = doc[label]; require(file_ref(value['path'], root) == value and value['sha256'] == GATES[gate], 'actual stage/budget/expected/proof bytes differ'); frozen[value['path']] = value['sha256']
    stage = read(doc['stage_spec']['path']); budget = read(doc['budget']['path'])
    require(canonical(stage) == canonical(proposed_stage()) and canonical(budget) == canonical(proposed_budget(GATES['stage_sha256'])), 'reviewed finite semantic stage/budget differs')
    expected_path=Path(doc['expected_builder']['path']);require(file_ref(expected_path,source)==doc['expected_builder'] and
        doc['expected_builder']['sha256']==GATES['expected_builder_sha256'],'reviewed independent v2 expected source required')
    expected = load_module(expected_path, GATES['expected_builder_sha256'], '_reserved48_independent_v2_preclaim')
    inventory = expected.derive(doc['manifest']['path'], doc['input_dir'], GATES['stage_sha256'])
    declared_expected=read(doc['expected_inventory']['path'])
    require(sha(doc['manifest']['path']) == MANIFEST_SHA and declared_expected.get('schema_version')==2 and
        declared_expected.get('native_capture_schema_version')==2 and declared_expected.get('native_progress',{}).get('schema_version')==1 and
        canonical(declared_expected) == canonical(inventory), 'all48 independent v2 expected coordinates/progress schema differ')
    checked = prerequisite(doc['prerequisite']['path'], GATES['native_prerequisite_sha256'])
    for value in checked['refs'].values(): require(Path(value['path']).resolve().is_relative_to(root.resolve()), 'proof byte closure escapes owned bin'); frozen[value['path']] = value['sha256']
    # A prepared config is frozen before a fresh GPU app ID exists. Only the
    # separate authenticated platform source arrives after UI creation. It
    # explicitly cites this prepared config SHA; no invented app ID is needed.
    platform_path=Path(str(absolute(doc['allocation_source_path'])));require(platform_path.parent==root,'allocation source must belong to the exact new bin root')
    stop=started+120
    while not platform_path.is_file() and time.monotonic()<stop:time.sleep(min(1,max(0,stop-time.monotonic())))
    require(platform_path.is_file() and not platform_path.is_symlink(),'actual allocation source absent after120s; no claim or model')
    doc['allocation_source']=file_ref(platform_path,root,131072)
    for value in (doc['manifest'], doc['source_manifest'], doc['expected_builder'], doc['allocation_source']):
        require(file_ref(value['path']) == value, 'explicit bin source reference changed'); frozen[value['path']] = value['sha256']
    platform = read(doc['allocation_source']['path']); require(platform['backend'] == backend and platform['prompt_bin'] == P and
        platform['task'] == TASK and isinstance(platform['allocation_id'], str) and platform['allocation_id'] and
        platform['prepared_config_sha256']==config_digest and platform['stage_sha256']==GATES['stage_sha256'] and
        platform['expected_inventory_sha256']==GATES['expected_inventory_sha256'] and platform['budget_sha256']==GATES['budget_sha256'] and
        platform['native_prerequisite_sha256']==GATES['native_prerequisite_sha256'] and
        platform['lifecycle_sha256']==reviewed['lifecycle'], 'actual allocation source is detached from prepared config/bin')
    if backend == 'GPU': require(re.fullmatch('app-[a-z0-9-]{1,64}', platform['allocation_id']), 'actual authenticated GPU app ID required')
    require(shutil.disk_usage(root).free >= 64*GIB, 'initial source free64GiB guard failed')
    return {'document': doc, 'root': root, 'source': source, 'frozen': frozen, 'inventory': inventory, 'platform': platform, 'bin': P,
        'config_ref': file_ref(path, root), 'started_monotonic': started}


def check_frozen(mapping):
    for path, digest in mapping.items(): require(sha(path) == digest, 'frozen source changed: '+path)


def tree_bytes(root):
    total = 0
    for p in Path(root).rglob('*'):
        require(not p.is_symlink(), 'new task tree symlink')
        if p.is_file(): total += p.stat().st_size
    return total


def new_run_directory(root,backend,prompt_bin,stamp=None):
    require(backend in ('GPU','NPU') and prompt_bin in BINS,'explicit task side/bin required')
    if stamp is None:stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    require(isinstance(stamp,str) and re.fullmatch('[0-9]{8}T[0-9]{6}Z',stamp),'canonical UTC run timestamp required')
    parent=Path(root)/'runs';require(not parent.is_symlink(),'owned run parent cannot be a symlink');parent.mkdir(exist_ok=True)
    folder=parent/(backend.lower()+'-reserved48-p%04d-'%prompt_bin+stamp);folder.mkdir(mode=0o700)
    return folder


def claim_once(context):
    ready()
    root, doc = context['root'], context['document']; parent = root/'claims'; require(not parent.is_symlink(), 'claim parent symlink'); parent.mkdir(exist_ok=True)
    intent=root/'bin-launch-once.json'
    try:
        put(intent,{'task':TASK,'backend':doc['backend'],'prompt_bin':context['bin'],'allocation_id':context['platform']['allocation_id'],
            'prepared_config':context['config_ref'],'permanent_bin_attempt_spent':True,'automatic_retry':False,'claimed_utc':utc()})
    except FileExistsError:return None
    claim = parent/context['platform']['allocation_id']
    try: claim.mkdir(mode=0o700)
    except FileExistsError: return None
    put(claim/'claim.json', {'schema_version': 1, 'task': TASK, 'backend': doc['backend'], 'prompt_bin': context['bin'],
        'allocation_id': context['platform']['allocation_id'], 'claimed_utc': utc(), 'controller_pid': os.getpid(),
        'controller_starttime': process_start(os.getpid()), 'config': context['config_ref'],
        'bin_launch_intent_sha256':sha(intent),
        'stage_sha256': GATES['stage_sha256'], 'budget_sha256': GATES['budget_sha256'], 'expected_inventory_sha256': GATES['expected_inventory_sha256'],
        'prerequisite_sha256': GATES['native_prerequisite_sha256'], 'source_manifest': doc['source_manifest'], 'allocation_source': doc['allocation_source'],
        'lifecycle_sha256': doc['reviewed_source_sha256']['lifecycle'], 'native_launches': 1, 'model_loads': 1,
        'native_forward_calls': 816, 'permanent_claim': True, 'automatic_retry': False,
        'whole_seconds': WHOLE[context['bin']], 'native_seconds': NATIVE[context['bin']], 'cleanup_seconds': CLEANUP, 'reserved_export_seconds': EXPORT})
    return claim


def worker_guard(context, claim, probe=False):
    ready()
    claim = Path(claim); doc = context['document']; require(claim == context['root']/'claims'/context['platform']['allocation_id'] and not claim.is_symlink(), 'exact spent bin claim required')
    value = read(claim/'claim.json'); require(value['task'] == TASK and value['backend'] == doc['backend'] and value['prompt_bin'] == context['bin'] and
        value['allocation_source'] == doc['allocation_source'] and value['source_manifest'] == doc['source_manifest'] and value['stage_sha256'] == GATES['stage_sha256'] and
        value['budget_sha256'] == GATES['budget_sha256'] and value['prerequisite_sha256'] == GATES['native_prerequisite_sha256'] and
        value['expected_inventory_sha256'] == GATES['expected_inventory_sha256'] and value['lifecycle_sha256'] == doc['reviewed_source_sha256']['lifecycle'] and
        value['config'] == context['config_ref'] and value['native_launches'] == value['model_loads'] == 1 and value['automatic_retry'] is False and
        value['whole_seconds'] == WHOLE[context['bin']] and value['native_seconds'] == NATIVE[context['bin']], 'claim source/proof/bin binding differs')
    intent=read(context['root']/'bin-launch-once.json');require(value['bin_launch_intent_sha256']==sha(context['root']/'bin-launch-once.json') and
        intent['task']==TASK and intent['backend']==doc['backend'] and intent['prompt_bin']==context['bin'] and
        intent['allocation_id']==context['platform']['allocation_id'] and intent['prepared_config']==context['config_ref'] and
        intent['permanent_bin_attempt_spent'] is True,'permanent bin attempt cannot be transferred to another allocation')
    parent = read(claim/'worker-once.json') if probe else {'pid': value['controller_pid'], 'starttime': value['controller_starttime']}
    require(os.getppid() == parent['pid'] and process_start(parent['pid']) == parent['starttime'], 'internal entry requires the real live owning parent')
    marker = claim/('probe-once.json' if probe else 'worker-once.json')
    put(marker, {'task': TASK, 'status': 'attempt_spent_before_native_work', 'pid': os.getpid(), 'starttime': process_start(os.getpid()),
        'parent_pid': os.getppid(), 'claim_sha256': sha(claim/'claim.json'), 'automatic_retry': False})
    return marker


def native_argv(context, claim, python, allocation, output):
    d = context['document']; P = context['bin']; entry = context['source']/d['collector_relative_path']
    argv = [str(python), '-B', str(entry), '--backend', d['backend'].lower(), '--prompt-bin', str(P), '--device', 'cuda:0' if d['backend']=='GPU' else 'npu:0']
    for name in ('model', 'input_dir'): argv += ['--'+name.replace('_','-'), str(d[name])]
    values = {'manifest': d['manifest'], 'allocation-receipt': file_ref(allocation), 'allocation-source': d['allocation_source'],
        'source-manifest': d['source_manifest'], 'stage-spec': d['stage_spec'], 'expected-inventory': d['expected_inventory'],
        'prerequisite-helper': file_ref(__file__), 'prerequisite': d['prerequisite'], 'budget': d['budget'], 'launch-receipt': file_ref(claim/'launch-receipt.json')}
    for name, item in values.items():
        argv += ['--'+name, item['path']]
        if name not in ('manifest', 'allocation-receipt'): argv += ['--'+name+'-sha256', item['sha256']]
    for name in ('numerics_policy', 'driver_source', 'native_mapping', 'native_source'):
        if name in d: argv += ['--'+name.replace('_','-'), d[name]['path']]
    return argv+['--progress-path',str(claim/'native-progress.jsonl'),'--output', str(output)]


def validate_products(context, output):
    manifest = read(output/'artifacts-manifest.json'); status = read(output/'status.json'); P = context['bin']; files = manifest['files']
    require(manifest['task'] == TASK and status['task'] == TASK and status['status'] == 'completed' and status['backend'] == context['document']['backend'].lower() and
        status['prompt_bin'] == P and status['inputs'] == 12 and status['observations'] == 36 and status['native_calls'] == 816 and status['model_loads'] == 1 and
        status['selected_rows'] == 1692 and status['all_target_scores'] == 36*(P+31) and status['all_valid_native_rows'] == 36*(P+32) and
        status['manifest_sha256'] == sha(output/'artifacts-manifest.json') and status['full_raw_retained'] is status['full_KV_retained'] is False, 'complete bounded12-input native product inventory required')
    wanted = {'samples/'+row['sample']+'/'+mode+'/selected-native-logits.safetensors' for row in context['inventory']['samples'] if row['prompt_length'] == P for mode in ('full','token','chunk')}
    require({p.relative_to(output).as_posix() for p in output.rglob('*') if p.is_file()} == set(files)|{'artifacts-manifest.json','status.json'} and
        {x for x in files if x.endswith(('.npy','.safetensors'))} == wanted and len(wanted) == 36 and tree_bytes(output) <= 2*GIB, 'exact36 selected BF16 products; no old arrays/full raw/KV')
    for name, value in files.items():
        actual = file_ref(output.joinpath(*relative(name).parts), output, 48*1024**2)
        require(actual['sha256'] == value['sha256'] and actual['size_bytes'] == value['size_bytes'], 'original artifact bytes changed')
    return status


def run_worker(context, claim, prepare):
    ready()
    marker = worker_guard(context, claim); d = context['document']; root = context['root']; source = context['source']
    python, allocation, dynamic = prepare(context, claim)
    before = dict(context['frozen']); before.update({str(p): sha(p) for p in [context['root']/'bin-launch-once.json',claim/'claim.json', marker, *dynamic]})
    values = {k: d[k] for k in ('allocation_source','source_manifest','stage_spec','expected_inventory','prerequisite','budget')}
    launch = {'task': TASK, 'backend': d['backend'].lower(), 'prompt_bin': context['bin'], 'allocation_id': context['platform']['allocation_id'],
        'status': 'claimed', 'permanent_claim': True, 'native_launches': 1, 'model_loads': 1, 'automatic_retry': False,
        'external_hard_watchdog_seconds': NATIVE[context['bin']]+30, 'frozen_refs': values}
    put(claim/'launch-receipt.json', launch); before[str(claim/'launch-receipt.json')] = sha(claim/'launch-receipt.json')
    check_frozen(before); put(claim/'sources-before.json', before)
    recorder = load_module(source/d['recorder_relative_path'], RECORD_SHA, '_reserved48_original_record_run')
    folder = new_run_directory(root,d['backend'],context['bin'])
    output = folder/'artifacts'; argv = native_argv(context, claim, python, allocation, output)
    put(claim/'native-process-launch-intent.json',{'task':TASK,'prompt_bin':context['bin'],'argv':argv,'claimed_utc':utc(),
        'scope':'Process launch intent only; it does not prove model loading or a completed forward','automatic_retry':False})
    generic, command = recorder.record_run(folder, d['backend'].lower(), 'reserved48-bin', NATIVE[context['bin']]+30, lambda _: argv, cwd=source)
    put(claim/'generic-receipt-reference.json',{'source':file_ref(generic/'command.json'),
        'status':command['status'],'returncode':command['returncode'],'child_returncode':command['child_returncode'],
        'timeout_scope':'original_generic_native_process_only'})
    require(command['status'] == 'completed' and command['returncode'] == command['child_returncode'] == 0, 'native bin failed; claim stays spent, no retry')
    validation = validate_products(context, output)
    emitted,stdout_evidence=parse_native_stdout(generic/'stdout.bin',d['backend'],output)
    require(emitted['progress']==file_ref(claim/'native-progress.jsonl',claim,4*1024**2),'original native stdout/progress byte binding differs')
    progress=capture_progress_evidence(context,claim,output,require_success=True)
    check_frozen(before); put(claim/'sources-after.json', before)
    put(claim/'capture-receipt.json', {'schema_version': 1, 'task': 'RESERVED48', 'task_id': TASK, 'backend': d['backend'], 'prompt_bin': context['bin'],
        'status': 'completed', 'returncode': 0, 'timed_out': False, 'native_capture_count': 1, 'model_loads': 1, 'native_forward_calls_total': 816,
        'started_utc': command['start'], 'finished_utc': utc(), 'argv': argv, 'collector_path': str(source/d['collector_relative_path']),
        'collector_sha256': d['reviewed_source_sha256']['collector'], 'input_manifest_sha256': MANIFEST_SHA, 'output_dir': str(output),
        'stage_spec_source_path': d['stage_spec']['path'], 'stage_spec_source_sha256': GATES['stage_sha256'],
        'expected_inventory_source_path': d['expected_inventory']['path'], 'expected_inventory_source_sha256': GATES['expected_inventory_sha256'],
        'cpu_prerequisite_source_sha256': GATES['cpu_portable_sha256'], 'native_prerequisite_source_sha256': GATES['native_prerequisite_sha256'],
        'allocation_path': str(allocation), 'allocation_sha256': sha(allocation), 'dependency_paths': list(before), 'source_sha256': before,
        'artifacts_manifest_sha256': sha(output/'artifacts-manifest.json'), 'generic_receipt': file_ref(generic/'command.json'),
        'validation': validation, 'native_capture_schema_version':2,'progress_schema_version':1,'native_progress':progress,'native_stdout':stdout_evidence,
        'thresholds': None, 'acceptance': None, 'full_core_complete': False})


def supervise(context, config, config_sha, lifecycle):
    """Own-process hard deadline and reviewed descendant cleanup, no other jobs."""
    ready();claim = claim_once(context)
    if claim is None: return {'status': 'refused', 'reason': 'permanent_bin_claim_exists', 'model_started': False}
    d = context['document']; helper = load_module(context['source']/d['cleanup_relative_path'], CLEANUP_SHA, '_reserved48_owned_cleanup')
    require(ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0, 'owned Linux subreaper unavailable')
    started = context['started_monotonic']; deadline = started+WHOLE[context['bin']]-EXPORT-CLEANUP; proc = None; code = 1
    state = {'schema_version': 1, 'task': 'RESERVED48', 'backend': d['backend'], 'prompt_bin': context['bin'], 'status': 'running', 'started_utc': utc(),
        'whole_seconds': WHOLE[context['bin']], 'reserved_export_seconds': EXPORT, 'owned_cleanup_seconds': CLEANUP, 'automatic_retry': False}
    def interrupt(*_): raise TimeoutError('owned bin controller deadline/signal; claim remains spent')
    previous = {sig: signal.signal(sig, interrupt) for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP,signal.SIGALRM)}
    signal.setitimer(signal.ITIMER_REAL, max(.01, deadline-time.monotonic()))
    try:
        with (claim/'worker.stdout').open('xb') as out, (claim/'worker.stderr').open('xb') as err:
            env=dict(os.environ)
            for key in ('PYTHONPATH','PYTHONHOME'):env.pop(key,None)
            env.update(PYTHONHASHSEED='0',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',TORCH_DEVICE_BACKEND_AUTOLOAD='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
            proc = subprocess.Popen([sys.executable,'-S','-B',str(lifecycle),'--config',str(config),'--config-sha256',config_sha,'--prompt-bin',str(context['bin']),'--internal-worker','--claim',str(claim)],
                stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True,env=env)
            while proc.poll() is None:
                require(time.monotonic() < deadline, 'bin controller work deadline reached; export/cleanup reserve retained')
                require(tree_bytes(context['root']) <= 12*GIB and shutil.disk_usage(context['root']).free >= 8*GIB, 'task12GiB or source free8GiB low-watermark guard')
                try: proc.wait(timeout=.5)
                except subprocess.TimeoutExpired: pass
            code = proc.returncode; require(code != 0 or not any(x['state'] != 'Z' for x in helper.descendants().values()), 'unexpected live owned descendant')
            if code==0:
                outer=read(claim/'capture-receipt.json');require(outer['status']=='completed' and outer['returncode']==0 and
                    outer['native_capture_schema_version']==2 and outer['native_progress']['status']=='source_capture_completed' and
                    outer['native_progress']['summary_hashes_checked']==36,'zero-exit worker lacks complete original capture/progress receipt')
                state['capture_receipt']=file_ref(claim/'capture-receipt.json')
            state['status'] = 'completed' if code == 0 else 'failed'
    except BaseException as exc:
        code = 124 if isinstance(exc, TimeoutError) else 1; state.update(status='failed', error_type=type(exc).__name__, error=str(exc))
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        try: helper.cleanup(proc)
        except BaseException as exc: code = 1; state.update(status='cleanup_failed', cleanup_error=str(exc))
        remaining=sorted(helper.descendants())
        if remaining:code=1;state.update(status='cleanup_failed')
        state['native_process_launch_intent_present']=(claim/'native-process-launch-intent.json').is_file()
        try:state['progress_diagnostic']=capture_progress_evidence(context,claim,require_success=False)
        except BaseException as exc:state['progress_diagnostic']={'status':'unknown_diagnostic','unexecuted_cells_inferred':False,'error_type':type(exc).__name__,'error':str(exc)}
        try:state['native_generic']=generic_receipt_evidence(context,claim)
        except BaseException as exc:
            code=1;state.update(status='evidence_verification_failed')
            state['native_generic']={'status':'unverified_original_generic_receipt','generic_deadline_reached':None,
                'evidence_error_type':type(exc).__name__,'evidence_error':str(exc)}
        state['timeout_observations']={'outer_controller_deadline':code==124,
            'original_generic_native_deadline':state['native_generic'].get('generic_deadline_reached'),
            'source_reported_timeout':True if state['progress_diagnostic'].get('source_failure',{}).get('classification')=='bounded_timeout' else None}
        state.update(returncode=code, timed_out=code == 124,timed_out_scope='outer_controller_only', remaining_descendants=remaining, finished_utc=utc(), wall_seconds=time.monotonic()-started)
        put(claim/'controller-receipt.json', state)
        for sig, handler in previous.items(): signal.signal(sig, handler)
    return state



def capture_progress_evidence(context,claim,output=None,require_success=False):
    """Hash/retain protocol and36 original summaries; not numerical admission."""
    claim=Path(claim);path=claim/'native-progress.jsonl'
    if not path.is_file():
        require(not require_success,'terminal progress is absent; no complete capture admission')
        return {'status':'unavailable_or_not_started_unknown','unexecuted_cells_inferred':False,'native_numeric_admission':False}
    before=file_ref(path,claim,4*1024**2);d=context['document'];common=load_module(context['source']/d['common_relative_path'],
        d['reviewed_source_sha256']['common'],'_reserved48_frozen_v2_progress_protocol')
    rows=[{'sample':r['sample'],'P':r['prompt_length'],'L':r['sequence_length'],
        'plans':{m['mode']:m['input_spans_zero_based_half_open'] for m in r['modes']}} for r in context['inventory']['samples'] if r['prompt_length']==context['bin']]
    try:checked=common.validate_progress(path,rows)
    except (ValueError,KeyError,TypeError,IndexError) as exc:
        require(not require_success,'missing/truncated/invalid terminal progress; numeric cells remain unadmitted')
        return {'status':'partial_or_invalid_terminal_unknown','source':before,'unexecuted_cells_inferred':False,
            'diagnostic_error':str(exc),'native_numeric_admission':False}
    require(checked['progress_sha256']==before['sha256'] and file_ref(path,claim,4*1024**2)==before,'native progress bytes changed during protocol validation')
    result={'status':checked['status'],'source':before,'transition_protocol':checked,'summary_hashes_checked':0,
        'native_numeric_admission':False,'unexecuted_cells_inferred':False}
    records=[json.loads(line) for line in path.read_bytes().splitlines()]
    if checked['status']=='source_capture_failed':result['source_failure']=records[-1]['error']
    if require_success:
        require(checked['status']=='source_capture_completed' and checked['forward_attempts']==checked['forward_returns']==816 and checked['not_entered_cells']==0,
            'all36 source cells/816 synchronized returns required')
        output=Path(output);manifest=read(output/'artifacts-manifest.json')['files']
        summary_events=[event for event in records if event['event']=='mode_capture_completed']
        expected=[('samples/'+r['sample']+'/'+mode+'/capture-summary.json',r['sample'],mode) for r in rows for mode in ('full','token','chunk')]
        require(len(summary_events)==len(expected)==36,'one original summary per planned cell required')
        for event,(relative_name,sample,mode) in zip(summary_events,expected):
            actual=file_ref(output.joinpath(*relative(relative_name).parts),output)
            require(event['sample']==sample and event['mode']==mode and event['summary']==actual and
                manifest[relative_name]=={'sha256':actual['sha256'],'size_bytes':actual['size_bytes']},'progress summary reference is detached from original artifact bytes')
        require(file_ref(path,claim,4*1024**2)==before,'progress bytes changed after summary hash validation')
        result['summary_hashes_checked']=36
    require(file_ref(path,claim,4*1024**2)==before,'progress bytes changed after final diagnostic extraction')
    return result


def parse_native_stdout(path,backend,output):
    """Known NPU driver event plus one exact final status, never last-JSON guessing.

    Raw stdout is retained unchanged. A conflicting/unknown/duplicate prefix is
    not accepted merely because a later line resembles a completed status.
    """
    raw=file_ref(path,limit=16*1024**2);lines=Path(path).read_bytes().splitlines()
    require(backend in ('GPU','NPU') and len(lines)==(1 if backend=='GPU' else 2),'strict native stdout record inventory differs')
    def decode(line):
        def pairs(items):
            result={}
            for key,value in items:require(key not in result,'duplicate native stdout JSON key');result[key]=value
            return result
        doc=json.loads(line,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)));canonical(doc);return doc
    records=[decode(line) for line in lines];final=records[-1];status=read(Path(output)/'status.json')
    require(isinstance(final,dict) and set(final)==set(status)|{'progress'} and
        canonical({k:v for k,v in final.items() if k!='progress'})==canonical(status) and final['status']=='completed',
        'native final stdout must equal the original status plus progress ref')
    event=None
    if backend=='NPU':
        event=records[0];require(isinstance(event,dict) and set(event)=={'event','observation'} and
            event['event']=='driver_version_api_observation','only the frozen driver API observation prefix is allowed')
        api=event['observation'];require(isinstance(api,dict) and api.get('call')=="torch_npu.utils.get_cann_version('DRIVER')" and
            api.get('status') in ('returned','error'),'explicit original driver API observation required')
        if api['status']=='returned':
            require(set(api)=={'call','status','value','parsed_version'} and isinstance(api['value'],str) and
                api['value'].strip()==api['parsed_version']=='25.5.2','driver API return conflicts with frozen native driver version')
        else:
            require(set(api) in ({'call','status','error_type','error','traceback'},{'call','status','value','error_type','error','traceback'}) and
                all(isinstance(api[k],str) for k in ('error_type','error','traceback')) and api['error_type'] and api['traceback'],
                'original driver API error must be retained explicitly')
        runtime=read(Path(output)/'runtime.json')
        require(canonical(api)==canonical(runtime['driver_version_provenance']['api']),'stdout driver event differs from original runtime provenance')
    require(file_ref(path,limit=16*1024**2)==raw,'native stdout changed during strict parsing')
    return final,{'raw_source':raw,'record_count':len(records),'driver_api_event':event,'raw_bytes_rewritten':False}


def generic_receipt_evidence(context,claim):
    """Separate observed generic timeout from outer and cooperative failures."""
    path=Path(claim)/'generic-receipt-reference.json'
    if not path.is_file():return {'status':'not_returned_or_unavailable','generic_deadline_reached':None,
        'scope':'No returned original generic receipt; no global no-timeout conclusion'}
    pointer=read(path);value=pointer['source'];require(file_ref(value['path'],context['root'])==value,'original failed/successful generic receipt bytes differ')
    record=read(value['path']);require(record['status']==pointer['status'] and record['returncode']==pointer['returncode'] and
        record['child_returncode']==pointer['child_returncode'],'original generic failure pointer differs')
    return {'source':value,'status':record['status'],'returncode':record['returncode'],'child_returncode':record['child_returncode'],
        'timeout_seconds':record['timeout'],'wall_seconds':record['wall_seconds'],'generic_deadline_reached':record['status']=='timed_out',
        'scope':'Original generic native-process deadline only; a source cooperative timeout may instead appear as nonzero child exit'}

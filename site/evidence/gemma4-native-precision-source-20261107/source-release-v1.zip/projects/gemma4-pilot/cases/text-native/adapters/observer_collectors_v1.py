"""Read-only module boundaries and dispatcher-visible frontend metadata.

Import is standard-library only. Torch is supplied by the caller after native
prerequisites; the dispatch class imports the pinned Torch interface lazily.
No kernel names, fused implementation or accumulator precision are inferred.
"""
from collections import Counter
from contextlib import contextmanager
import hashlib
import json
import threading

TOKENS=sorted(set(i*127//15 for i in range(16))|set(range(127,159)))
CHANNELS=[j*3839//63 for j in range(64)]
BLOCK_PREFIX='model.language_model.layers.'
MAX_CALLS,MAX_SIGNATURES,MAX_BYTES=200000,10000,16777216


def require(ok,message):
    if not ok:raise ValueError(message)


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
def signature(value):return hashlib.sha256(canonical(value).encode()).hexdigest()


def boundary_specs(block_count=48,prefix=BLOCK_PREFIX,embedding='model.language_model.embed_tokens',norm='model.language_model.norm'):
    values=[{'id':'embedding.scaled.output','module':embedding,'when':'output'}]
    for index in range(block_count):
        values.extend({'id':'block.%02d.%s'%(index,side),'module':prefix+str(index),'when':side} for side in ('input','output'))
    values.append({'id':'norm.final.output','module':norm,'when':'output'})
    return values


def tensor_metadata(tensor):
    result={'shape':[int(x) for x in tensor.shape],'dtype':str(tensor.dtype),
        'device':str(tensor.device),'layout':str(tensor.layout)}
    try:result['stride']=[int(x) for x in tensor.stride()]
    except Exception as exc:result.update(stride=None,stride_gap={'error_type':type(exc).__name__,'error':str(exc)})
    return result


def tensor_tree(value,torch,path='value',depth=0,budget=None):
    """Bounded metadata, never scalar tensor values or materialized operands."""
    if budget is None:budget=[0]
    budget[0]+=1
    require(depth<=12 and budget[0]<=4096,'dispatcher metadata tree exceeds nesting/node limits')
    if isinstance(value,torch.Tensor):return {'path':path,**tensor_metadata(value)}
    if isinstance(value,(tuple,list)):
        require(len(value)<=128,'dispatcher container exceeds128 items')
        return {'container':type(value).__name__,'items':[tensor_tree(x,torch,path+'/'+str(i),depth+1,budget) for i,x in enumerate(value)]}
    if isinstance(value,dict):
        require(len(value)<=128 and all(isinstance(k,(str,int)) for k in value),'unsupported dispatcher mapping')
        return {'container':'dict','items':{str(k):tensor_tree(x,torch,path+'/'+str(k),depth+1,budget) for k,x in value.items()}}
    return {'python_type':type(value).__module__+'.'+type(value).__qualname__}


def selected_tensor(value,torch):
    if isinstance(value,torch.Tensor):return value,'tensor'
    if isinstance(value,(tuple,list)) and value and isinstance(value[0],torch.Tensor):return value[0],'sequence/0'
    if isinstance(value,dict):
        names=[name for name in ('hidden_states','last_hidden_state') if isinstance(value.get(name),torch.Tensor)]
        require(len(names)==1,'boundary mapping must expose one explicit hidden-state tensor')
        return value[names[0]],'mapping/'+names[0]
    raise ValueError('unsupported boundary output container; no guessed tensor selection')


def hook_registry(modules):
    names=('_forward_pre_hooks','_forward_pre_hooks_with_kwargs','_forward_hooks','_forward_hooks_with_kwargs','_forward_hooks_always_called')
    return {name:{field:[(int(key),id(value)) for key,value in getattr(module,field,{}).items()] for field in names}
        for name,module in modules}


class Observer:
    def __init__(self,model,torch,device,*,specs=None,tokens=None,channels=None,hidden_shape=(1,160,3840),
                 max_calls=MAX_CALLS,max_signatures=MAX_SIGNATURES,max_bytes=MAX_BYTES):
        self.model,self.torch,self.device=model,torch,str(device)
        self.specs=boundary_specs() if specs is None else list(specs)
        self.tokens=list(TOKENS if tokens is None else tokens);self.channels=list(CHANNELS if channels is None else channels)
        self.hidden_shape=list(hidden_shape);self.sample_shape=[self.hidden_shape[0],len(self.tokens),len(self.channels)]
        require(len(self.hidden_shape)==3 and self.hidden_shape[0]==1 and self.tokens==sorted(set(self.tokens)) and
            self.channels==sorted(set(self.channels)) and self.tokens and self.channels and min(self.tokens)>=0 and
            max(self.tokens)<self.hidden_shape[1] and min(self.channels)>=0 and max(self.channels)<self.hidden_shape[2],
            'explicit unique in-range token/channel selection required')
        self.modules=list(model.named_modules(remove_duplicate=False));self.by_name=dict(self.modules)
        require(len(self.by_name)==len(self.modules),'duplicate module names')
        aliases={}
        for name,module in self.modules:aliases.setdefault(id(module),[]).append(name)
        require(all(len(names)==1 for names in aliases.values()),'module object aliases make individual invocation attribution ambiguous')
        require(len({x['id'] for x in self.specs})==len(self.specs) and all(set(x)=={'id','module','when'} and
            x['module'] in self.by_name and x['when'] in ('input','output') for x in self.specs),'boundary module/specification inventory differs')
        self.by_boundary={(x['module'],x['when']):x for x in self.specs}
        require(len(self.by_boundary)==len(self.specs),'duplicate boundary module/side')
        self.calls=Counter();self.completed=Counter();self.hook_counts=Counter();self.events=[];self.samples={};self.handles=[]
        self.scope=[];self.owner=None;self.guard_depth=0;self.dispatch_calls=0;self.excluded_calls=Counter();self.signatures={}
        self.max_calls,self.max_signatures,self.max_bytes=max_calls,max_signatures,max_bytes
        self.serialized_bytes=0;self.status='prepared';self.error=None;self.before_registry=None;self.after_registry=None

    @contextmanager
    def collector_guard(self):
        self.guard_depth+=1
        try:yield
        finally:self.guard_depth-=1

    def snapshot(self,name,side,tensor,path):
        spec=self.by_boundary.get((name,side))
        if spec is None:return
        require(self.hook_counts[spec['id']]==0,'boundary fired more than once: '+spec['id'])
        observed=tensor_metadata(tensor)
        require(observed['shape']==self.hidden_shape and observed['dtype']=='torch.bfloat16' and observed['device']==self.device,
            'actual boundary shape/dtype/device differs: '+spec['id'])
        with self.collector_guard():
            # Selection/clone happens at this exact boundary. Later in-place
            # changes cannot alter these independent selected native values.
            ti=self.torch.tensor(self.tokens,dtype=self.torch.long,device=tensor.device)
            ci=self.torch.tensor(self.channels,dtype=self.torch.long,device=tensor.device)
            sample=tensor.detach().index_select(1,ti).index_select(2,ci).contiguous().clone()
        require(list(sample.shape)==self.sample_shape and str(sample.dtype)=='torch.bfloat16','selected native sample shape/dtype differs')
        self.samples[spec['id']]=sample;self.hook_counts[spec['id']]+=1
        self.events.append({**spec,'ordinal':len(self.events),'tensor_path':path,'observed':observed,
            'token_indices':self.tokens,'channel_indices':self.channels,'sample_shape':self.sample_shape,
            'sample_dtype':str(sample.dtype),'snapshot':'detached selected native clone at boundary; CPU copy after forward'})

    def pre(self,name,module,args,kwargs):
        require(threading.get_ident()==self.owner,'concurrent Python module calls are outside this bounded pilot')
        self.scope.append(name);self.calls[name]+=1
        if (name,'input') in self.by_boundary:
            if 'hidden_states' in kwargs:tensor,path=selected_tensor(kwargs['hidden_states'],self.torch);path='kwargs/hidden_states/'+path
            else:
                require(bool(args),'selected boundary has no hidden-state input')
                tensor,path=selected_tensor(args[0],self.torch);path='args/0/'+path
            self.snapshot(name,'input',tensor,path)
        return None

    def post(self,name,module,args,kwargs,result):
        require(threading.get_ident()==self.owner and self.scope and self.scope[-1]==name,'module scope stack/order differs')
        try:
            if (name,'output') in self.by_boundary and result is not None:
                tensor,path=selected_tensor(result,self.torch);self.snapshot(name,'output',tensor,'output/'+path)
            self.completed[name]+=1
        finally:self.scope.pop()
        return None

    def __enter__(self):
        require(self.status=='prepared','observer context is single use')
        self.owner=threading.get_ident();self.before_registry=hook_registry(self.modules);self.status='recording'
        try:
            for name,module in self.modules:
                self.handles.append(module.register_forward_pre_hook(lambda m,a,k,n=name:self.pre(n,m,a,k),with_kwargs=True))
                self.handles.append(module.register_forward_hook(lambda m,a,k,r,n=name:self.post(n,m,a,k,r),with_kwargs=True,always_call=True))
        except BaseException:
            self.remove_handles();raise
        return self

    def remove_handles(self):
        errors=[]
        for handle in reversed(self.handles):
            try:handle.remove()
            except Exception as exc:errors.append({'error_type':type(exc).__name__,'error':str(exc)})
        self.handles=[];self.after_registry=hook_registry(self.modules)
        require(not errors and self.before_registry==self.after_registry,'owned hooks failed to restore the original module registries')

    def __exit__(self,kind,value,traceback):
        self.remove_handles()
        if kind is not None:
            self.status='incomplete';self.error={'error_type':kind.__name__,'error':str(value)};return False
        try:
            require(not self.scope and self.calls==self.completed,'module invocation pre/post closure differs')
            require([x['id'] for x in self.events]==[x['id'] for x in self.specs] and
                all(self.hook_counts[x['id']]==1 for x in self.specs),'missing, duplicate or reordered boundary event')
            self.status='completed'
        except BaseException as exc:
            self.status='incomplete';self.error={'error_type':type(exc).__name__,'error':str(exc)};raise
        return False

    def dispatch(self,func,args,kwargs):
        if self.guard_depth:
            self.excluded_calls[str(func)]+=1
            return func(*args,**kwargs)
        self.dispatch_calls+=1
        require(self.dispatch_calls<=self.max_calls,'dispatcher invocation cap exceeded; observation incomplete')
        record={'operator':str(func),'schema':str(func._schema),'module_scope':list(self.scope),
            'inputs':tensor_tree(args,self.torch,'args'),'kwargs':tensor_tree(kwargs,self.torch,'kwargs')}
        # Forward the original operation exactly once, without replacing any
        # operand, scalar argument, output, backend or precision policy.
        result=func(*args,**kwargs)
        record['outputs']=tensor_tree(result,self.torch,'outputs')
        key=signature(record)
        if key not in self.signatures:
            require(len(self.signatures)<self.max_signatures,'dispatcher signature cap exceeded; observation incomplete')
            self.serialized_bytes+=len(canonical(record).encode())+128
            require(self.serialized_bytes<=self.max_bytes,'dispatcher metadata byte cap exceeded; observation incomplete')
            self.signatures[key]={'signature_sha256':key,'count':0,'first_invocation':self.dispatch_calls,**record}
        self.signatures[key]['count']+=1
        return result

    def dispatch_mode(self):
        from torch.utils._python_dispatch import TorchDispatchMode
        observer=self
        class MetadataMode(TorchDispatchMode):
            def __torch_dispatch__(self,func,types,args=(),kwargs=None):
                return observer.dispatch(func,args,{} if kwargs is None else kwargs)
        return MetadataMode()

    def report(self,dispatch_enabled):
        modules=[{'name':name,'class':type(module).__module__+'.'+type(module).__qualname__,
            'invocations':self.calls[name],'completed_invocations':self.completed[name]} for name,module in self.modules]
        result={'schema_version':1,'status':self.status,'error':self.error,'enabled':True,
            'actual_module_count':len(modules),'module_invocations':modules,
            'zero_fired_modules':[x['name'] for x in modules if x['invocations']==0],
            'fired_module_count':sum(x['invocations']>0 for x in modules),'total_module_invocations':sum(self.calls.values()),
            'boundary_specs':self.specs,'boundary_counts':{x['id']:self.hook_counts[x['id']] for x in self.specs},
            'boundary_events':self.events,'hook_registry_restored':self.before_registry==self.after_registry,
            'dispatcher':{'enabled':dispatch_enabled,'observed_invocations':self.dispatch_calls,
                'unique_signatures':len(self.signatures),'signatures':list(self.signatures.values()),
                'collector_generated_excluded_operations':dict(self.excluded_calls),
                'metadata_byte_budget_accounting':self.serialized_bytes,
                'limits':{'invocations':self.max_calls,'unique_signatures':self.max_signatures,'serialized_bytes':self.max_bytes},
                'scope':'Dispatcher-visible frontend overloads and tensor metadata only; not native kernels/fusion/accumulator precision/instructions.'},
            'scope':'Read-only effective nn.Module hook boundaries; module listing is static and zero-fired entries are explicit.'}
        require(len(canonical(result['dispatcher']).encode())<=self.max_bytes,'actual serialized dispatcher census exceeds byte cap')
        return result

"""GPU lifecycle CPU fixtures only; no GPU/device/model/app is invoked."""
from concurrent.futures import ThreadPoolExecutor
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import reserved48_stage_contract_v1 as c
import reserved48_gpu_lifecycle_v1 as g

HERE=Path(__file__).resolve().parent


def context(root):
    return {'root':root,'source':root/'source','bin':128,'platform':{'allocation_id':'app-syntheticCPU'},
        'config_ref':{'path':str(root/'prepared.json'),'sha256':'1'*64,'size_bytes':1},'started_monotonic':time.monotonic(),
        'document':{'backend':'GPU','source_manifest':{'path':'/synthetic/source-manifest.json','sha256':'2'*64},
            'allocation_source':{'path':'/synthetic/actual-allocation.json','sha256':'3'*64},'cleanup_relative_path':'cleanup.py',
            'reviewed_source_sha256':{'collector':'4'*64,'common':'5'*64,'lifecycle':'6'*64}}}


class GatesAndClaims(unittest.TestCase):
    def test_unready_contract_precedes_file_reads_and_all_normal_internal_CLI_routes(self):
        with patch.object(Path,'read_bytes',side_effect=AssertionError('unready source read')):
            with self.assertRaisesRegex(ValueError,'unready'):g.contract()
        with tempfile.TemporaryDirectory() as td:
            output=Path(td)/'absent'
            for extra in ([],['--internal-worker','--claim',str(output)]):
                result=subprocess.run([sys.executable,'-S','-B',g.__file__,'--config',str(output),'--config-sha256','0'*64,'--prompt-bin','8192',*extra],capture_output=True,timeout=15)
                self.assertNotEqual(result.returncode,0);self.assertIn(b'unready',result.stderr);self.assertFalse(output.exists())

    def test_clean_environment_preserves_visible_binding_but_removes_injected_python(self):
        with patch.dict(os.environ,{'PYTHONPATH':'injected','PYTHONHOME':'injected','CUDA_VISIBLE_DEVICES':'fixture-visible'}):env=g.clean_environment()
        self.assertNotIn('PYTHONHOME',env);self.assertNotIn('PYTHONPATH',env)
        self.assertEqual(env['CUDA_VISIBLE_DEVICES'],'fixture-visible');self.assertEqual(env['TORCH_DEVICE_BACKEND_AUTOLOAD'],'0')

    def test_one_permanent_claim_under_concurrency_and_worker_failure_does_not_release_it(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);ctx=context(root)
            with patch.object(c,'ready'),patch.object(c,'process_start',return_value=123):
                with ThreadPoolExecutor(max_workers=8) as pool:claims=list(pool.map(lambda _:c.claim_once(ctx),range(8)))
                self.assertEqual(sum(x is not None for x in claims),1);claim=next(x for x in claims if x is not None)
                with patch.object(c.os,'getppid',return_value=os.getpid()):marker=c.worker_guard(ctx,claim)
                self.assertTrue(marker.exists())
                with patch.object(c.os,'getppid',return_value=os.getpid()),self.assertRaises(FileExistsError):c.worker_guard(ctx,claim)
                self.assertIsNone(c.claim_once(ctx));self.assertTrue((claim/'claim.json').exists())
                ctx['platform']['allocation_id']='app-another-syntheticCPU'
                self.assertIsNone(c.claim_once(ctx));self.assertFalse((root/'claims/app-another-syntheticCPU').exists())

    def test_wrong_config_or_reused_parent_identity_refuses_before_worker_marker(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);ctx=context(root)
            with patch.object(c,'ready'),patch.object(c,'process_start',return_value=123):claim=c.claim_once(ctx)
            with patch.object(c,'ready'),patch.object(c.os,'getppid',return_value=os.getpid()),patch.object(c,'process_start',return_value=124):
                with self.assertRaisesRegex(ValueError,'live owning parent'):c.worker_guard(ctx,claim)
            self.assertFalse((claim/'worker-once.json').exists())


@unittest.skipUnless(sys.platform.startswith('linux'),'owned Linux child/subreaper fixtures')
class Supervisor(unittest.TestCase):
    def run_child(self,body,timeout=False):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);ctx=context(root);ctx['source'].mkdir();(ctx['source']/'cleanup.py').write_bytes((HERE/'npu_three_repeat_launcher_v4.py').read_bytes())
            child=root/'synthetic-child.py';child.write_text(body,encoding='utf8')
            with patch.object(c,'ready'),patch.dict(c.WHOLE,{128:c.EXPORT+c.CLEANUP+(.1 if timeout else 5)}):result=c.supervise(ctx,root/'not-read-config','0'*64,child)
            claim=root/'claims/app-syntheticCPU';self.assertTrue((claim/'claim.json').exists());self.assertEqual(result['remaining_descendants'],[])
            return result
    def test_actual_child_returncode7_remains_failed_not_completed(self):
        result=self.run_child('raise SystemExit(7)\n');self.assertEqual(result['status'],'failed');self.assertEqual(result['returncode'],7);self.assertFalse(result['timed_out'])
    def test_actual_timeout_reaps_owned_child_and_records_failure(self):
        result=self.run_child('import time\ntime.sleep(60)\n',True);self.assertEqual(result['status'],'failed');self.assertEqual(result['returncode'],124);self.assertTrue(result['timed_out'])


if __name__=='__main__':unittest.main()

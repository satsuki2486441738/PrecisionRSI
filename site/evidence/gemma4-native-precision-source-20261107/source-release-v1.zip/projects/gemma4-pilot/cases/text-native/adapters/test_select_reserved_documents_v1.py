import unittest
import select_reserved_documents_v1 as tool


class ReservationTests(unittest.TestCase):
    def test_nested_heading_stays_with_article_and_exclusion_removes_whole_article(self):
        rows=['\n',' = First = \n','old paragraph\n',' = = Inner = = \n','late paragraph\n',' = Second = \n','new paragraph\n']
        self.assertEqual(tool.articles(rows),[(1,5),(5,7)])
        chosen,meta=tool.select(rows,lambda _:list(range(10,30)),{2},bins=(4,),per_bin=1,continuation=2)
        self.assertEqual(chosen[0]['source_rows_zero_based_half_open'],[5,7])
        self.assertEqual(meta['excluded_discovery_or_duplicate_paragraph_documents'],1)

    def test_duplicate_discovery_paragraph_in_another_article_is_excluded(self):
        rows=[' = A = \n','Seen paragraph\n',' = B = \n',' seen   PARAGRAPH \n',' = C = \n','fresh\n']
        chosen,_=tool.select(rows,lambda _:list(range(10,30)),{1},bins=(4,),per_bin=1,continuation=2)
        self.assertEqual(chosen[0]['source_rows_zero_based_half_open'],[4,6])

    def test_largest_bins_first_one_article_once_and_deterministic(self):
        rows=[' = Old = \n','excluded\n']+sum(([f' = Article {i} = \n',f'body {i}\n'] for i in range(8)),[])
        encode=lambda _:list(range(10,110))
        a,meta=tool.select(rows,encode,{1},bins=(4,8),per_bin=2,continuation=2)
        b,_=tool.select(rows,encode,{1},bins=(4,8),per_bin=2,continuation=2)
        self.assertEqual(a,b);self.assertEqual(meta['observed_per_bin'],{4:2,8:2})
        self.assertEqual(len({tuple(x['source_rows_zero_based_half_open']) for x in a}),4)
        self.assertEqual([x['bin'] for x in a],[4,4,8,8])

    def test_ineligible_short_or_special_content_never_fills_a_claimed_bin(self):
        rows=[' = Old = \n','excluded\n',' = Other = \n','fresh\n']
        for encode in (lambda _:[10],lambda _:[0]+list(range(10,30))):
            with self.assertRaisesRegex(ValueError,'not filled'):
                tool.select(rows,encode,{1},bins=(8,),per_bin=1,continuation=2)

    def test_records_add_bos_once_and_preserve_known_continuation_span(self):
        item={'bin':128,'ids':list(range(10,220)), 'source_rows_zero_based_half_open':[2,7],
              'source_text_sha256':'a'*64,'normalized_article_sha256':'b'*64,'source_token_count_without_BOS':210}
        doc=next(iter(tool.records([item]).values()))
        self.assertEqual(doc['prompt'],[2]+list(range(10,137)))
        self.assertEqual(doc['continuation'],list(range(137,169)))
        self.assertEqual(doc['source_token_span_without_BOS_half_open'],[0,159])


if __name__=='__main__':unittest.main()

"""Synthetic CPU protocol/arithmetic fixtures; never model or native evidence."""
import copy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import struct
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('independent_i04_selected_e02',HERE/'verify_i04_selected_e02_v1.py')
tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path,document):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(document,allow_nan=False,indent=2)+'\n',encoding='utf-8');return path


def npy(path,values):
    header=repr({'descr':'<f8','fortran_order':False,'shape':(1,len(values))}).encode()
    header+=b' '*((64-(10+len(header)+1)%64)%64)+b'\n'
    Path(path).write_bytes(b'\x93NUMPY\x01\x00'+struct.pack('<H',len(header))+header+struct.pack('<'+str(len(values))+'d',*values))


def native(path,shape,valid):
    # Padding NaN payloads are deliberately retained; selected valid rows are0.
    width,vocabulary=shape[1:];payload=bytearray()
    for slot in range(shape[0]):
        for p in range(width):payload.extend(struct.pack('<H',0 if (slot,p) in valid else 0x7fc1)*vocabulary)
    doc={'logits':{'dtype':'BF16','shape':shape,'data_offsets':[0,len(payload)]}}
    header=json.dumps(doc,separators=(',',':')).encode();header+=b' '*((-len(header))%8)
    Path(path).write_bytes(struct.pack('<Q',len(header))+header+payload)


def fixture_report():
    pairs=[]
    for sides,request,kind in tool.pair_inventory():
        sample='CPU-'+request;coords=[{'sample':sample,'position':p,'token':p%128} for p in range(1,tool.LENGTHS[request])]
        logp=-math.log(128);count=len(coords)
        metrics={'target_count':count,'side_a_nll_nat_per_token':logp*-1,'side_b_nll_nat_per_token':logp*-1,
            'nll_abs_diff_nat_per_token':0.,'mae_nat':0.,'p99_nat':0.,'max_abs_nat':0.,'max_coordinate':coords[0]}
        rows=[{'sample':sample,'position':p,'union_count':100,'tail_merged_js':{'value':0.,'status':'ok'},
            'top1_agreement':True,'top100_overlap':1.,'probability_rmse':0.,'max_probability_error':0.,'max_error_token':0,
            'coverage':{'side_a_top100':100/128,'side_b_top100':100/128,'side_a_union':100/128,'side_b_union':100/128},
            'normalization_mass':{'side_a':1.,'side_b':1.}} for p in tool.positions(request)]
        aggregate={field:{'max':0.,'max_coordinate':{'sample':sample,'position':rows[0]['position'],**({'token':0} if field=='max_probability_error' else {})}} for field in tool.FIELDS}
        pairs.append({'sides':sides,'request':request,'kind':kind,'targets':{'status':'no_thresholds','coverage':{'expected':count,'paired':count},'metrics':metrics},
            'distributions':{'positions':rows,'aggregate':aggregate}})
    return {'target_distribution_pairs':pairs}


class FakeEndpoint:
    """Actual tiny files, only the external native receipt layer is synthetic."""
    def __init__(self,audit,backend):self.audit,self.backend,self.files=audit,backend,{}
    def register(self,path):
        path=Path(path);self.files[str(path)]={'sha256':digest(path),'size':path.stat().st_size};return str(path)
    def get(self,name,expected=None,force=False):
        ref=self.files[name];return self.audit.file(name,expected or ref['sha256'],name.endswith(('.npy','.safetensors')),force)
    def json(self,name,expected=None):return tool.parse(self.get(name,expected).read_bytes())


def geometry_fixture(root):
    audit=tool.Audit(900);runs={};large=[]
    for backend in ('GPU','NPU'):
        endpoint=FakeEndpoint(audit,backend);raws={}
        for mode in tool.MODES:
            folder=root/backend/mode;folder.mkdir(parents=True)
            members=[(r,g) for (m,r),g in tool.plans().items() if m==mode];shape=members[0][1]['shape']
            valid={(g['slot'],g['physical_offset']+p) for r,g in members for p in range(tool.LENGTHS[r])}
            path=folder/'raw-native-logits.safetensors';native(path,shape,valid);raws[mode]=endpoint.register(path)
            large.append((endpoint,str(path),digest(path)))
        for (mode,request),g in tool.plans().items():
            folder=root/backend/mode/('request-'+request);folder.mkdir();sequence=[p%128 for p in range(tool.LENGTHS[request])]
            coords=[{'sample':'CPU-'+request,'position':p,'token':sequence[p]} for p in range(1,len(sequence))]
            rows=[{**c,'prediction_position':c['position']-1,'physical_prediction_position':g['physical_offset']+c['position']-1,
                'physical_target_position':g['physical_offset']+c['position'],'request':request,'slot':g['slot'],'logprob':-math.log(128)} for c in coords]
            score=write(folder/'target-scores.json',{'scores':rows,'raw_logits_sha256':endpoint.files[raws[mode]]['sha256'],
                'slot':g['slot'],'physical_offset':g['physical_offset']});endpoint.register(score)
            for p in tool.positions(request):
                stem='dist-p%03d'%p;array=folder/(stem+'.npy');npy(array,[-math.log(128)]*128);endpoint.register(array)
                large.append((endpoint,str(array),digest(array)))
                record={'sample':'CPU-'+request,'position':p,'history':sequence[:p+1],'request':request,'slot':g['slot'],
                    'physical_offset':g['physical_offset'],'physical_prediction_position':g['physical_offset']+p,'target_position':p+1,
                    'token':sequence[p+1],'raw_logits_sha256':endpoint.files[raws[mode]]['sha256'],'scores':{'path':stem+'.npy','row':0},'logprob':-math.log(128)}
                endpoint.register(write(folder/(stem+'.json'),record))
            runs[f'{backend.lower()}-{mode}-{request.lower()}']={'endpoint':endpoint,'output':str(folder),'mode':mode,'request':request,
                'geometry':g,'coordinates':coords,'sequence':sequence,'raw_logits':raws[mode],'score_source':str(score)}
    return audit,runs,large


class IndependentChecks(unittest.TestCase):
    def test_159_and95_target_reductions_are_separate(self):
        for count,p99 in ((159,1.42),(95,2.06)):
            a=[-2.]*count;b=a[:];b[:3]=[-3.,-4.,-5.];coords=[{'position':p+1} for p in range(count)]
            out=tool.target_metrics(a,b,coords)
            self.assertEqual(out['target_count'],count);self.assertAlmostEqual(out['mae_nat'],6/count)
            self.assertAlmostEqual(out['p99_nat'],p99);self.assertEqual(out['max_coordinate'],coords[2])
        with self.assertRaises(ValueError):tool.target_metrics([-2.]*95,[-2.]*159,[{}]*95)

    def test_analytic_complement_JS_union_errors_and_top1(self):
        # Top100 union101;27 untouched categories form one exact complement.
        pa=[1/128]*128;pb=pa[:];pb[0]*=1.5;pb[1]*=.5
        result=tool.distribution_metrics([math.log(x) for x in pa],[math.log(x) for x in pb])
        direct=math.fsum(.5*p*math.log(2*p/(p+q))+.5*q*math.log(2*q/(p+q)) for p,q in zip(pa,pb))
        self.assertAlmostEqual(result['tail_merged_js'],direct,places=15)
        self.assertAlmostEqual(result['max_probability_error'],.5/128)
        self.assertAlmostEqual(result['probability_rmse'],math.sqrt(2*(.5/128)**2/result['union_count']))
        self.assertAlmostEqual(result['direct_complement_mass']['side_a'],(128-result['union_count'])/128)
        pb=pa[:];pb[0]*=.5;pb[1]*=1.5
        result=tool.distribution_metrics([math.log(x) for x in pa],[math.log(x) for x in pb])
        self.assertFalse(result['top1_agreement']);self.assertEqual(result['top1_mismatch']['side_b_token'],1)
        self.assertAlmostEqual(result['top1_mismatch']['side_b_margin'],.5/128)

    def test_selection_all6_cross_pairs_and_global_ties_bounds(self):
        report=fixture_report();selection=tool.select(report)
        self.assertEqual(len(selection['distribution_rows']),282);self.assertEqual(len(selection['distribution_extrema_claims']),3)
        self.assertTrue(all(x['pair_index']==0 and x['reported_tie_pair_count']==18 for x in selection['distribution_extrema_claims']))
        for i,field in enumerate(tool.FIELDS,6):
            pair=report['target_distribution_pairs'][i];row=pair['distributions']['positions'][2]
            row[field]=1.;pair['distributions']['aggregate'][field]={'max':1.,'max_coordinate':{'sample':row['sample'],'position':row['position'],**({'token':0} if field=='max_probability_error' else {})}}
        self.assertEqual(tool.select(report)['distribution_rows_selected'],285)
        report['target_distribution_pairs'][0]['sides']=['gpu-alone-A-a','npu-alone-B-b']
        with self.assertRaises(ValueError):tool.select(report)

    def test_all18_and282_actual_small_files_left_offset64_padNaNs_and_572_hashes(self):
        with tempfile.TemporaryDirectory() as temporary,patch.object(tool,'VOCAB',128),patch.object(tool,'child',lambda p,n:str(Path(p)/n)):
            audit,runs,large=geometry_fixture(Path(temporary));report=fixture_report();selection=tool.select(report)
            targets,distributions=tool.replay(audit,report,runs,selection)
            self.assertEqual((len(targets),len(distributions),len(large)),(18,282,572))
            self.assertEqual(sum(x['metrics']['target_count'] for x in targets),9*159+9*95)
            self.assertTrue(all(x['raw_native_to_NPY_max_abs_delta']==[0.,0.] for x in distributions))
            self.assertEqual(len(tool.final_hashes(audit,large)),572)
            # A nonselected within-side contrast cannot hide modified native data.
            endpoint,name,_=large[-1];Path(name).write_bytes(b'changed')
            with self.assertRaises(ValueError):tool.final_hashes(audit,large)

    def test_wrong_B_offset_unscored95_and_selected_raw_value_rejected(self):
        with tempfile.TemporaryDirectory() as temporary,patch.object(tool,'VOCAB',128),patch.object(tool,'child',lambda p,n:str(Path(p)/n)):
            audit,runs,_=geometry_fixture(Path(temporary));tool.load_targets(runs)
            run=runs['gpu-batch-left-b'];self.assertEqual(run['geometry']['physical_offset'],64)
            with self.assertRaises(ValueError):tool.selected_values(run,95)
            broken=copy.copy(run);broken['geometry']={**run['geometry'],'physical_offset':0}
            with self.assertRaises(ValueError):tool.selected_values(broken,0)
            path=Path(run['output'])/'dist-p000.npy';npy(path,[-math.log(128)-.01]*128)
            with self.assertRaises(ValueError):tool.selected_values(run,0)

    def test_changed_target_or_report_metric_refuses_success(self):
        with tempfile.TemporaryDirectory() as temporary,patch.object(tool,'VOCAB',128),patch.object(tool,'child',lambda p,n:str(Path(p)/n)):
            audit,runs,_=geometry_fixture(Path(temporary));report=fixture_report();report['target_distribution_pairs'][0]['targets']['metrics']['mae_nat']=.1
            with self.assertRaises(ValueError):tool.replay(audit,report,runs,tool.select(report))
            report=fixture_report();report['target_distribution_pairs'][0]['distributions']['positions'][0]['probability_rmse']=.1
            with self.assertRaises(ValueError):tool.replay(audit,report,runs,tool.select(report))

    @unittest.skipUnless(os.name=='posix','Original POSIX endpoint roots')
    def test_endpoint_copied_and_retained_boundaries_and_mutation(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);array=root/'row.npy';array.write_bytes(b'CPU byte fixture')
            map_path=root/'source-map.json';name='/synthetic-cpu-only/row.npy';outer='/synthetic-cpu-only/outer.json'
            mapping={'schema_version':1,'request':{'task':'I04','backend':'GPU','outer_receipt':outer},
                'files':{name:{'path':array.name,'size':array.stat().st_size,'sha256':digest(array)}}}
            write(map_path,mapping);info={'source_map':{'path':str(map_path),'sha256':digest(map_path)},'receipt':{'source_path':outer}}
            endpoint=tool.Endpoint(tool.Audit(900),info,'GPU');self.assertEqual(endpoint.get(name),array)
            array.write_bytes(b'mutated')
            with self.assertRaises(ValueError):endpoint.get(name,force=True)
            mapping['request']['backend']='NPU';mapping['files']={str(array):{'retained_at_source':True,'size':array.stat().st_size,'sha256':digest(array)}}
            write(map_path,mapping);info['source_map']['sha256']=digest(map_path);info['retained_root']=str(root/'missing')
            with self.assertRaises((ValueError,FileNotFoundError)):tool.Endpoint(tool.Audit(900),info,'NPU')
            info['retained_root']=str(root);endpoint=tool.Endpoint(tool.Audit(900),info,'NPU');self.assertEqual(endpoint.get(str(array)),array)
            info['retained_root']=str(root/'sub');(root/'sub').mkdir()
            endpoint=tool.Endpoint(tool.Audit(900),info,'NPU')
            with self.assertRaises(ValueError):endpoint.get(str(array))

    def test_controller_external_hash_and_null_acceptance_are_mandatory(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);controller=write(root/'controller.json',{'status':'completed','returncode':0})
            with self.assertRaises(ValueError):tool.controller_chain(tool.Audit(900),controller,'0'*64)
            with self.assertRaises((ValueError,KeyError)):tool.controller_chain(tool.Audit(900),controller,digest(controller))

    def test_original_generic2a_controller_schema_positive_and_binding_mutations(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary).resolve();run=root/'compare-i04-synthetic';run.mkdir();tools=root/'tools';tools.mkdir()
            refs={}
            for name in (tool.MAIN,tool.HELPER,tool.CONTROLLER):
                source=HERE.parents[4]/name;destination=tools/name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,destination)
                refs[name]={'sha256':digest(destination),'size_bytes':destination.stat().st_size}
            manifest=write(tools/'tool-bundle-manifest.json',{'files':refs})
            spec_path=write(run/'comparison-spec.json',{'task':tool.TASK,'stage_spec_sha256':tool.STAGE_SHA,'expected_inventory_sha256':tool.EXPECTED_SHA,
                'cpu_prerequisite_sha256':tool.CPU_SHA,'i03_prerequisite_sha256':tool.I03_SHA,'endpoints':{},'acceptance':None,'thresholds':None})
            report=write(run/'bundle/i04-comparison-report.json',{'task':tool.TASK,'stage_spec_sha256':tool.STAGE_SHA,'cpu_prerequisite_sha256':tool.CPU_SHA,
                'comparison_spec_sha256':digest(spec_path),'status':'i04_raw_bf16_batch_padding_and_request_pairs_checked','native_executions_started_by_admission':0,
                'acceptance':None,'thresholds':None,'full_core_complete':False,'scope':{'target_distribution_pairs':18,'original_large_sources_final_bytehash_checked':572},
                'source_map_sha256':{},'offline_tool_source_sha256':{'admit_i04_batch_padding_v1.py':tool.MAIN_SHA,'i04_artifact_admission_v1.py':tool.HELPER_SHA}})
            argv=[str(root/'python'),'-B',str(tools/tool.MAIN),'--spec',str(spec_path),'--spec-sha256',digest(spec_path),
                '--output-dir',str(run/'bundle'),'--timeout-seconds','900']
            generic_dir=run/'cpu-i04-admission-20261107T000001Z';generic_dir.mkdir()
            profile=write(run/'profile.json',{'env':{'TORCH_DEVICE_BACKEND_AUTOLOAD':'0'}});snapshot=generic_dir/'execution.json';shutil.copyfile(profile,snapshot)
            logs={}
            for key in ('stdout','stderr'):
                path=generic_dir/(key+'.bin');path.write_bytes(b'synthetic CPU protocol only\n');logs[key]={'path':str(path),'sha256':digest(path),'bytes':path.stat().st_size}
            generic=write(generic_dir/'command.json',{'status':'completed','returncode':0,'child_returncode':0,'argv':argv,'cwd':str(tools),'timeout':920.,
                'start':'2026-11-07T00:00:01+00:00','end':'2026-11-07T00:00:02+00:00',
                'execution':{'path':str(profile),'snapshot':str(snapshot),'sha256':digest(snapshot)}})
            state={'status':'completed','returncode':0,'task':'I04','run':str(run),'tools_root':str(tools),'tool_manifest_sha256':digest(manifest),
                'whole_cpu_seconds':960,'child_work_seconds':920,'analysis_seconds':900,'cleanup_reserve_seconds':20,'native_executions_started':0,
                'child_returncode':0,'timed_out':False,'argv':argv,'comparison_spec':{'path':str(spec_path),'sha256':digest(spec_path)},
                'report':{'path':str(report),'sha256':digest(report)},'generic_receipt':{'path':str(generic),'sha256':digest(generic)},
                'started_utc':'2026-11-07T00:00:00+00:00','finished_utc':'2026-11-07T00:00:03+00:00',**logs}
            controller=write(run/'controller-receipt.json',state)
            self.assertEqual(tool.controller_chain(tool.Audit(900),controller,digest(controller))[2]['source_map_sha256'],{})
            for field,value in [('timed_out',True),('child_returncode',7),('analysis_seconds',901)]:
                bad={**state,field:value};write(controller,bad)
                with self.assertRaises(ValueError):tool.controller_chain(tool.Audit(900),controller,digest(controller))
            altered=tool.parse(report.read_bytes());altered['acceptance']=True;write(report,altered)
            write(controller,{**state,'report':{'path':str(report),'sha256':digest(report)}})
            with self.assertRaises(ValueError):tool.controller_chain(tool.Audit(900),controller,digest(controller))


if __name__=='__main__':unittest.main()

"""Ascend candidate v2: retain DRIVER API failure with pinned native version.info provenance.

Run under a scheduler-owned, bounded recorder after verifying allocation and
device ownership. This program cannot authenticate the supplied allocation
receipt or prove ordinal-to-physical identity where the runtime exposes no UUID.
It verifies the snapshot bytes and freezes the prior H100 pilot's input and
model semantics. It does not implement the cross-platform admission adapter.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import argparse
import hashlib
import json
import os
import random
import re
import subprocess
import uuid
from pathlib import Path

from pilot_gpu_peer_v2 import capture, parse_input, write_json
from verify_snapshot import verify

REVISION = '1a2c7729392586f5ecddae8807ee2ef741eabb9a'
INPUT_SHA256 = '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
METADATA_SHA256 = '80dc0e0e59e5c526426b566d36a21f762a79d498986d5d6cd01098c8cb5decc3'
HERE = Path(__file__).resolve().parent


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def check_input(path):
    if sha256(Path(path).read_bytes()) != INPUT_SHA256:
        raise ValueError('input bytes differ from frozen H100 discovery example')
    sample, prompt, continuation = parse_input(path)
    if len(prompt) != 128 or len(continuation) != 32:
        raise ValueError('input length differs from frozen H100 workload')
    return sample, prompt, continuation


def check_allocation(receipt, ordinal):
    # This is schema/consistency validation, not independent ownership proof.
    if not isinstance(receipt, dict) or receipt.get('vendor') != 'Ascend':
        raise ValueError('allocation must name Ascend explicitly')
    if type(receipt.get('visible_count')) is not int or receipt['visible_count'] < 1:
        raise ValueError('allocation receipt needs visible_count')
    if receipt.get('logical_ordinal') != ordinal or type(receipt.get('logical_ordinal')) is not int:
        raise ValueError('allocation logical ordinal does not match requested device')
    if ordinal >= receipt['visible_count']:
        raise ValueError('logical ordinal outside supplied visible count')
    for name in ('allocation_id', 'physical_device_id', 'evidence_source'):
        if not isinstance(receipt.get(name), str) or not receipt[name].strip():
            raise ValueError('allocation receipt missing ' + name)


def check_version(name, value):
    if not isinstance(value, str) or not value.strip() or value.lower() in {'unknown', 'none'}:
        raise RuntimeError('missing native version: ' + name)
    return value


DRIVER_SOURCE_PATH = Path('/usr/local/Ascend/driver/version.info')
DRIVER_SOURCE_SHA256 = '1bc07a765a4b4c765510ec7979113ea03b0217f1dcc62ebe4646d011d7f88902'
DRIVER_VERSION = '25.5.2'


def parse_driver_version_info(path):
    """Read the actual installed native driver metadata; never infer another key."""
    path = Path(path)
    if not path.is_absolute() or not path.is_file() or path.resolve() != DRIVER_SOURCE_PATH.resolve():
        raise RuntimeError('explicit installed driver/version.info source required')
    raw = path.read_bytes()
    observed_sha = sha256(raw)
    if observed_sha != DRIVER_SOURCE_SHA256:
        raise RuntimeError('native driver version.info differs from the frozen diagnostic SHA256')
    text = raw.decode('utf-8')
    values = {}
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        key, separator, value = line.partition('=')
        if not separator:
            continue
        # Deliberately case-sensitive. ascendhal_version and other component
        # versions are not the installed driver package Version field.
        key = key.strip()
        if key not in ('Version', 'package_version'):
            continue
        if key in values:
            raise RuntimeError('duplicate native driver metadata key: ' + key)
        values[key] = value.strip()
    version = values.get('Version')
    if version != DRIVER_VERSION:
        raise RuntimeError('native driver Version is missing or differs from the observed 25.5.2')
    if 'package_version' in values and values['package_version'] != version:
        raise RuntimeError('native driver Version and package_version conflict')
    return version, {'path': str(path), 'resolved_path': str(path.resolve()), 'sha256': observed_sha,
        'size_bytes': len(raw), 'selected_key': 'Version', 'parsed_version': version,
        'package_version': values.get('package_version'),
        'scope': 'Installed native package metadata; loaded driver binary identity is not independently proven'}


def observe_driver_version(getter, source_path):
    """Record the metadata API observation and require the pinned native source."""
    import traceback
    api = {'call': "torch_npu.utils.get_cann_version('DRIVER')"}
    try:
        value = getter('DRIVER')
        api['value'] = value if isinstance(value, (str, int, float, bool, type(None))) else repr(value)
        parsed = check_version('driver API', value).strip()
        api.update(status='returned', parsed_version=parsed)
    except Exception as exc:
        api.update(status='error', error_type=type(exc).__name__, error=str(exc), traceback=traceback.format_exc())
    # Preserve the original API result/error even if the required source fails.
    print(json.dumps({'event': 'driver_version_api_observation', 'observation': api}), flush=True)
    version, native = parse_driver_version_info(source_path)
    provenance = {'api': api, 'native_source': native,
        'selected_version': version, 'selected_source': 'native_driver_version_info',
        'fallback_used': api['status'] == 'error',
        'limitations': ['The metadata API failure is recorded, not repaired or attributed to an operator.',
                       'The native version.info file describes installed package metadata.']}
    if api['status'] == 'returned' and api['parsed_version'] != version:
        print(json.dumps({'event': 'driver_version_conflict', 'observation': provenance}), flush=True)
        raise RuntimeError('driver API and pinned native Version disagree')
    return version, provenance


def normalize_runtime_uuid(value):
    """Treat the native all-zero placeholder as unavailable device identity."""
    if value is None or not str(value).strip():
        return None
    try:
        parsed = uuid.UUID(str(value).strip())
    except (ValueError, AttributeError) as exc:
        raise RuntimeError('malformed native NPU UUID') from exc
    return str(parsed) if parsed.int else None


def check_stack(versions):
    """Reject obviously incompatible binaries; this does not prove CANN support."""
    torch_version = re.match(r'^(\d+\.\d+\.\d+)(?:$|[+.])', versions['torch'])
    npu_version = re.match(r'^(\d+\.\d+\.\d+)(?:$|[+.])', versions['torch_npu'])
    if not torch_version or not npu_version or torch_version.group(1) != npu_version.group(1):
        raise RuntimeError('Torch and TorchNPU binary versions do not match')
    if versions['transformers'] != '5.10.1':
        raise RuntimeError('Transformers does not match frozen H100 version 5.10.1')


def get_policy(torch, npu):
    matmul = npu.matmul.allow_hf32
    conv = npu.conv.allow_hf32
    if type(matmul) is not bool or type(conv) is not bool:
        raise RuntimeError('HF32 policy unavailable as explicit boolean')
    return {
        'float32_matmul_precision': torch.get_float32_matmul_precision(),
        'matmul_allow_hf32': matmul,
        'conv_allow_hf32': conv,
        'deterministic_algorithms': bool(torch.are_deterministic_algorithms_enabled()),
        'deterministic_warn_only': bool(torch.is_deterministic_algorithms_warn_only_enabled()),
        'pythonhashseed': os.environ.get('PYTHONHASHSEED'),
        # Record optional backend properties without inventing unavailable values.
        'jit_compile_false': npu.is_jit_compile_false() if hasattr(npu, 'is_jit_compile_false') else None,
        'cube_math_type': str(npu.matmul.cube_math_type) if getattr(npu.matmul, 'cube_math_type', None) is not None else None,
    }


def set_policy(torch, npu, numpy):
    before = get_policy(torch, npu)
    torch.set_float32_matmul_precision('highest')
    npu.matmul.allow_hf32 = False
    npu.conv.allow_hf32 = True
    random.seed(0)
    numpy.random.seed(0)
    torch.manual_seed(0)
    npu.manual_seed_all(0)
    after = get_policy(torch, npu)
    expected = {'float32_matmul_precision': 'highest', 'matmul_allow_hf32': False,
                'conv_allow_hf32': True, 'deterministic_algorithms': False,
                'deterministic_warn_only': False, 'pythonhashseed': '0'}
    if any(type(after[k]) is not type(v) or after[k] != v for k, v in expected.items()):
        raise RuntimeError('actual NPU numerical policy differs from declared candidate policy')
    return before, after


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', type=Path, required=True, help='Local model snapshot directory')
    parser.add_argument('--input', type=Path, required=True, help='Frozen H100 input bytes')
    parser.add_argument('--allocation-receipt', type=Path, required=True, help='Private scheduler ownership evidence')
    parser.add_argument('--driver-source', type=Path, required=True, help='Actual installed native driver/version.info')
    parser.add_argument('--device', required=True, help='Explicit runtime ordinal npu:N')
    parser.add_argument('--output', type=Path, required=True, help='New output directory')
    args = parser.parse_args()
    match = re.fullmatch(r'npu:(0|[1-9][0-9]*)', args.device)
    if not match:
        parser.error('--device must be an explicit npu:N ordinal')
    ordinal = int(match.group(1))
    sample, prompt, continuation = check_input(args.input)
    allocation_bytes = args.allocation_receipt.read_bytes()
    allocation = json.loads(allocation_bytes)
    check_allocation(allocation, ordinal)
    metadata_bytes = (HERE / 'upstream-identity.json').read_bytes()
    if sha256(metadata_bytes) != METADATA_SHA256:
        raise ValueError('pinned upstream metadata hash mismatch')
    # No silent creation or use of a shared Python environment.
    import torch
    import torch_npu
    import numpy
    import transformers
    from transformers import AutoModelForMultimodalLM
    npu = torch_npu.npu
    cann_version = check_version('CANN', torch_npu.utils.get_cann_version('CANN'))
    driver_version, driver_provenance = observe_driver_version(torch_npu.utils.get_cann_version, args.driver_source)
    versions = {'torch': check_version('torch', torch.__version__),
                'torch_npu': check_version('torch_npu', torch_npu.__version__),
                'transformers': check_version('transformers', transformers.__version__),
                'cann': cann_version, 'driver': driver_version}
    check_stack(versions)
    if not npu.is_available() or npu.device_count() != allocation['visible_count']:
        raise RuntimeError('NPU availability or visible device count differs from supplied allocation')
    if ordinal >= npu.device_count():
        raise RuntimeError('NPU ordinal is not visible')
    npu.set_device(ordinal)
    if not npu.is_bf16_supported():
        raise RuntimeError('native BF16 not supported on selected NPU')
    props = npu.get_device_properties(ordinal)
    name = npu.get_device_name(ordinal)
    if not isinstance(name, str) or not name.strip():
        raise RuntimeError('native NPU device name unavailable')
    physical_uuid = normalize_runtime_uuid(getattr(props, 'uuid', None))
    if physical_uuid is not None and physical_uuid != normalize_runtime_uuid(allocation['physical_device_id']):
        raise RuntimeError('runtime UUID does not match supplied physical device')
    memory = npu.mem_get_info(ordinal)
    if not isinstance(memory, (tuple, list)) or len(memory) != 2 or min(memory) <= 0:
        raise RuntimeError('native device memory information unavailable')
    smi = subprocess.run(['npu-smi', 'info'], capture_output=True, text=True, timeout=30, check=True)
    if not smi.stdout.strip():
        raise RuntimeError('npu-smi info returned no evidence')
    before, policy = set_policy(torch, npu, numpy)
    args.output.mkdir(parents=True, exist_ok=False)
    write_json(args.output / 'driver-version-provenance.json', driver_provenance)
    (args.output / 'npu-smi.txt').write_text(smi.stdout, encoding='utf-8')
    receipt = verify(args.model, json.loads(metadata_bytes))
    receipt['upstream_metadata_sha256'] = METADATA_SHA256
    write_json(args.output / 'snapshot-verification.json', receipt)
    if receipt['status'] != 'verified':
        raise RuntimeError('local snapshot failed byte verification')
    write_json(args.output / 'policy-before-load.json', {'before': before, 'configured': policy})
    model = AutoModelForMultimodalLM.from_pretrained(str(args.model), revision=REVISION,
        local_files_only=True, dtype=torch.bfloat16, attn_implementation='eager')
    if getattr(model.config, 'model_type', None) != 'gemma4_unified':
        raise RuntimeError('loaded model is not the pinned Gemma 4 Unified class')
    commit = getattr(model.config, '_commit_hash', None)
    if commit and commit.lower() != REVISION:
        raise RuntimeError('loaded config revision differs from pinned revision')
    model = model.to(args.device).eval()
    if getattr(model.config, '_attn_implementation', None) != 'eager':
        raise RuntimeError('effective attention implementation differs from eager')
    parameter_dtypes = sorted({str(p.dtype) for p in model.parameters()})
    if parameter_dtypes != ['torch.bfloat16']:
        raise RuntimeError('model parameter dtype differs from BF16')
    after_load = get_policy(torch, npu)
    write_json(args.output / 'policy-after-load.json', after_load)
    if after_load != policy:
        raise RuntimeError('NPU numerical policy changed during model loading')
    runtime = {'model_repository': 'google/gemma-4-12B', 'requested_revision': REVISION,
        'observed_config_commit': commit, 'model_class': type(model).__name__,
        'model_type': model.config.model_type, 'input_sha256': INPUT_SHA256,
        'allocation_receipt_sha256': sha256(allocation_bytes), 'device': args.device,
        'device_name': name, 'runtime_uuid': physical_uuid,
        'free_bytes_before_load': int(memory[0]), 'total_bytes': int(memory[1]),
        'versions': versions, 'driver_version_provenance': driver_provenance,
        'driver_version_provenance_sha256': sha256((args.output / 'driver-version-provenance.json').read_bytes()),
        'torch_file': str(torch.__file__),
        'torch_npu_file': str(torch_npu.__file__), 'transformers_file': str(transformers.__file__),
        'parameter_dtypes': parameter_dtypes, 'actual_attention': 'eager',
        'logprob_dtype': 'float64', 'seed': 0, 'math_policy': policy,
        'visible_device_env': {key: os.environ.get(key) for key in ('ASCEND_RT_VISIBLE_DEVICES', 'ASCEND_VISIBLE_DEVICES')},
        'limitations': ['Candidate only; actual platform compatibility requires native execution',
                        'matching package version numbers do not establish CANN/driver support',
                        'allocation receipt is supplied and not independently authenticated',
                        'runtime-loaded bytes not independently proven by snapshot verification',
                        'text-only single-device fixed-history pilot; no acceptance threshold']}
    write_json(args.output / 'runtime.json', runtime)
    capture(model, torch, args.device, sample, prompt, continuation, args.output, 'float64')
    npu.synchronize(ordinal)
    after = get_policy(torch, npu)
    write_json(args.output / 'policy-after-capture.json', after)
    if after != policy:
        raise RuntimeError('NPU numerical policy changed during capture')
    write_json(args.output / 'status.json', {'status': 'completed', 'rank': 0,
        'scope': 'Ascend single-device integration pilot; allocation provenance still needs independent validation'})


if __name__ == '__main__':
    main()

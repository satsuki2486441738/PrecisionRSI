"""Build a scoped I01 history entry from frozen public evidence; never append it."""
import copy
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[5]
ID = 'gemma4-h100-ascend-cacheoff-20261106'
REVISION = 'cc6c84f250f2b001d3de30f63c6a5bb7d4b6d2cf'
HISTORY_SHA = '3bf81df041381cce17e055e691d33d45e0afc32482d93ada48b9389bcf9d3e6f'
REPAIRS_SHA = '0c186a832c07aa42bb9c74b0e98fd2ad036de52eb5ea694f28ec8353daf2d1fc'
PINS = {'report.md': '04c5975cd4f6713424d50e53a1286bb5529e9b21c1fbf692030c3fd0abe90929',
        'coverage.json': '7d23bab715de582792e5aafc3d46f1caad0b4dc6fe2e4b0cf2ef65b9940d4c1c',
        'selected-metrics.json': 'b9646885fdebc1693a31738dd41389265a13e8145e18f8cd61c8ff5ec9ef2970',
        'selected-targets.json': '7e52fb4b812924ea08a9ff10e9708a16f4a9503f4c965a35bd0f01658361de63',
        'replay-targets.py': 'd3c925c7661c4cbc0193c0c0f6d82ca77a3d4d02c918e8853fab721649791575'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    site = ROOT / 'site'
    history, repairs = site/'data/evaluations.json', site/'data/repairs.json'
    assert sha(history) == HISTORY_SHA and sha(repairs) == REPAIRS_SHA
    document = json.loads(history.read_text(encoding='utf-8'))
    assert len(document['evaluations']) == 106 and len(json.loads(repairs.read_text())['repairs']) == 20
    old = document['evaluations'][-1]
    assert old['id'] == 'gemma4-h100-ascend-fixed-20261106'
    evidence = site / 'evidence' / ID
    for name, pin in PINS.items():
        assert sha(evidence/name) == pin
        raw = subprocess.run(['git', 'show', REVISION+':site/evidence/'+ID+'/'+name], cwd=ROOT,
                             check=True, capture_output=True).stdout
        assert hashlib.sha256(raw).hexdigest() == pin
    metrics = json.loads((evidence/'selected-metrics.json').read_text())
    targets = json.loads((evidence/'selected-targets.json').read_text())
    assert metrics['thresholds'] is None and metrics['acceptance'] is None
    assert metrics['full_core_complete'] is False and metrics['pair_scope']['total_pairs'] == 7
    old_sides = {x['id']: x for x in old['sides']}
    sides = []
    for run in targets['runs']:
        identity = run['id']; gpu = identity.startswith('gpu-'); full = identity.endswith('-full')
        original = ('h100' if gpu else 'npu') + ('-r1' if full else '-r'+identity.rsplit('r',1)[1])
        side = copy.deepcopy(old_sides[original]); side['id'] = identity
        side['label'] = ('H100' if gpu else 'Ascend') + (' / cache-off full' if full else ' / historical cached '+identity.rsplit('-',1)[1])
        side['settings'].update(use_cache=not full, native_forward_calls=1 if full else 32,
                                prefill_tokens=160 if full else 128, cached_decode_calls=0 if full else 31,
                                capture_scope='one new full capture' if full else 'reused historical cached capture',
                                new_repeatability_measured=False, native_logits_retained=full)
        if full and not gpu and not any(x['name']=='NumPy' for x in side['libraries']):
            side['libraries'].append({'name':'NumPy','version':'1.26.4'})
        sides.append(side)
    comparisons = []
    for index, (target, distribution) in enumerate(zip(metrics['target_pairs'], metrics['distribution_pairs'])):
        assert target['sides'] == distribution['sides'] and target['id'] == distribution['id']
        a,b = target['sides']; t,d = target['metrics'], distribution['aggregate']
        values = {'target-nll-abs-diff':t['nll_abs_diff_nat_per_token'], 'target-mae':t['mae_nat'],
                  'target-p99':t['p99_nat'], 'target-max':t['max_abs_nat'],
                  'top1-agreements':d['top1_agreement']['count'], 'top1-agreement-fraction':d['top1_agreement']['fraction'],
                  'top100-overlap-mean':d['top100_overlap']['mean']}
        for field,prefix in [('tail_merged_js','tail-merged-js'),('probability_rmse','union-probability-rmse'),
                             ('max_probability_error','union-max-probability-error')]:
            for stat in ('mean','p99','max'): values[prefix+'-'+stat] = d[field][stat]
        for field in ('side_a_top100','side_b_top100','side_a_union','side_b_union'):
            for stat in ('mean','p1','min'): values[field.replace('_','-')+'-'+stat] = d['coverage'][field][stat]
        rendered = []
        for prototype in old['comparisons'][0]['metrics']:
            item = copy.deepcopy(prototype); key = item['id']; item['value'] = values[key]
            item['label'] = item['label'].replace('h100-r1',a).replace('npu-r1',b)
            item.pop('coordinate',None); item.pop('side_values',None)
            if key == 'target-nll-abs-diff':item['side_values'] = {a:t['side_a_nll_nat_per_token'],b:t['side_b_nll_nat_per_token']}
            if key == 'target-max':item['coordinate'] = {'anonymous_target_index_zero_based':t['max_target_index_zero_based'],
                'within_pair_target_index_zero_based':t['max_target_index_within_pair_zero_based']}
            for field,prefix in [('tail_merged_js','tail-merged-js'),('probability_rmse','union-probability-rmse'),
                                 ('max_probability_error','union-max-probability-error')]:
                if key == prefix+'-max':item['coordinate'] = d[field]['max_coordinate']
            rendered.append(item)
        assert len(rendered) == len(values) == 28
        count = 159 if index == 0 else 32
        positions = 47 if index == 0 else 32
        comparisons.append({'id':target['id'], 'title':('GPU/NPU cache-off: ' if index==0 else 'Historical peer contrast: ')+a+' vs '+b,
            'side_ids':[a,b], 'scope':('One input; matched cache-off full forwards on GPU and NPU.' if index==0 else
            'One input; historical full/cached continuation intersection. Multiple uncontrolled variables; no cache-only causal claim.'),
            'metrics':rendered, 'coverage':[{'label':'Paired targets','observed':count,'expected':count,'unit':'targets'},
                {'label':'Paired selected distributions','observed':positions,'expected':positions,'unit':'positions'},
                {'label':'Vocabulary per retained row','observed':262144,'expected':262144,'unit':'entries/row'},
                {'label':'Independent fixed inputs','observed':1,'expected':1,'unit':'inputs'}]})
    entry = {'id':ID,'date':'2026-11-06','title':'Gemma 4 12B: H100 vs Ascend cache-off anchor (159 targets)',
        'task':'inference','status':'partial','acceptance':None,'thresholds':None,'full_core_complete':False,'model':copy.deepcopy(old['model']),
        'summary':'One new cache-off full forward per backend; independently retained/reconstructed BF16 raw outputs,159 paired targets and47 selected distributions. Six historical cached peer contrasts share the same input. Full-core completion and numerical acceptance remain open.',
        'common':['Same pinned base checkpoint,160 known tokens including128 prompt tokens and32 fixed continuation tokens, seed0, TP1, BF16 parameters/native logits and eager attention.',
            'New capture: use_cache=False,past_key_values=None,logits_to_keep=0,all-one mask,positions0..159,no labels. Retained raw BF16 logits are normalized offline in FP64.',
            'Independent raw reconstruction checks159 targets and47 full rows per backend, including all160 raw predictor rows for finiteness. Final predictor159 has no fabricated unknown target.'],
        'differences':copy.deepcopy(old['differences']) + ['Historical controls use cache-on prefill128 plus31 decodes. New GPU physical identifier differs from historical peers; NPU matches. Cache/partition/process/collector/allocation state differ, so these controls do not isolate cache use.'],
        'sides':sides,'comparisons':comparisons,'scope':copy.deepcopy(metrics['pair_scope']) | {'independent_inputs':1,'new_captures_per_backend':1,'new_repeatability_measured':False,'raw_predictor_rows_checked_per_backend':160,'new_full_rows_checked_per_backend':47,'target_only_replay_pairs':7,'public_replay_arrays_read':0},
        'notes':['The primary comparison is GPU versus NPU. Every pair shares one input; seven comparisons do not imply seven independent examples.',
            'Numerical thresholds and acceptance remain null. Arithmetic reconstruction tolerance1e-12 and normalization tolerance1e-5 verify evidence, not accuracy acceptance.',
            'Target indices span0..158 globally; the historical intersection spans127..158. Distribution positions are predictor indices, and sampled ordinals are recorded separately.',
            'Probability errors cover the top100 token union. Tail-merged JS uses the union plus one exact complement category and is coarsened.',
            'Public replay reproduces target reductions only and reads zero arrays. Full-row metrics were computed source-side; local metadata exports721 files while omitting286 NPY and2 raw BF16 objects.',
            'Loaded module/tie inventories are static metadata. Operator attribution, representative/reserved inputs,context bins,batch/padding,generation,performance and total lifetime cost remain incomplete. The49-task/28-core ledger retains all gaps.'],
        'evidence':[{'label':label,'url':'evidence/'+ID+'/'+name} for name,label in [('report.md','Scoped cache-off GPU/NPU report'),('selected-metrics.json','All seven comparison summaries and anonymous position metrics'),('selected-targets.json','Eight anonymous score vectors'),('replay-targets.py','Seven-pair standard-library target replay'),('coverage.json','Original49-task coverage ledger')]],
        'archive':{'revision':REVISION,'prefix':'site/evidence/'+ID+'/','replay_cases':7,'file_sha256':PINS}}
    raw = json.dumps(entry,allow_nan=False)
    assert not re.search(r'/(?:home|data|tmp|mnt)/|[A-Z]:\\|app-[a-z0-9]{8}|[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}',raw,re.I)
    output = Path(__file__).with_name('i01-history-entry-ready-20261106.json')
    with output.open('x',encoding='utf-8',newline='\n') as stream:json.dump(entry,stream,indent=2,allow_nan=False);stream.write('\n')
    assert sha(history) == HISTORY_SHA and sha(repairs) == REPAIRS_SHA
    print(json.dumps({'path':str(output),'sha256':sha(output),'comparisons':7,'metrics_per_comparison':28,'archive_revision':REVISION,'history_written':False}))


if __name__ == '__main__':
    main()

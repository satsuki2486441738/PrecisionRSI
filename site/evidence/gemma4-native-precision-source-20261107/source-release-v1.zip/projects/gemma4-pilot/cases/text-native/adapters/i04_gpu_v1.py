"""One new H100 process/model; four cache-off I04 batch/padding calls."""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import json
import os
import sys

import i04_common_v1 as common
from pilot_gpu_torch290_candidate import check_allocation, check_device, check_stack, POLICY_SHA256
from pilot_gpu_peer_v2 import seed_and_check, math_policy, check_policy


def main():
    args = common.arguments('gpu')
    stage, inventory, refs, proof = common.prepare(args,'gpu',__file__)
    allocation = common.read(args.allocation_receipt); check_allocation(allocation)
    common.require(common.sha(args.numerics_policy) == POLICY_SHA256, 'frozen GPU numerical policy differs')
    policy = common.read(args.numerics_policy)
    sys.path.insert(0,str(common.HERE.parent/'transfer'))
    from npu_three_repeat_launcher_v4 import memory_observation
    memory = memory_observation()
    common.require(memory['effective_available_bytes'] >= stage['limits']['minimum_gpu_host_effective_available_bytes'], 'effective host/cgroup memory is below40GiB')
    with common.bounded_native(stage,'gpu'):
        import torch
        import numpy
        import transformers
        import transformers.masking_utils as masking_utils
        from transformers import AutoModelForMultimodalLM
        versions = {'torch':str(torch.__version__),'transformers':str(transformers.__version__),'cuda_runtime':str(torch.version.cuda),'numpy':str(numpy.__version__)}
        check_stack(versions); props, physical, free, total = check_device(torch,allocation)
        rng = seed_and_check(torch,numpy,policy); common.check_refs(refs)
        common.initialize_output(args,proof); common.put(args.output/'policy-before-load.json',rng)
        model, identity = common.prior.load_verified_model(args,torch,AutoModelForMultimodalLM,common.read(common.HERE/'upstream-identity.json'))
        after_load = math_policy(torch); check_policy(after_load,policy); common.put(args.output/'policy-after-load.json',after_load)
        implementations = {'modeling':identity['modeling_source'],'masking_utils':common.file_ref(masking_utils.__file__)}
        common.check_refs(implementations)
        summaries = common.capture_all(model,torch,args.device,inventory,args.output,'gpu',lambda:seed_and_check(torch,numpy,policy),
            lambda:math_policy(torch),lambda:torch.cuda.synchronize(0))
        after_capture = math_policy(torch); check_policy(after_capture,policy); common.put(args.output/'policy-after-capture.json',after_capture)
        runtime = {'backend':'gpu','model_identity':identity,'implementation_sources':implementations,'versions':versions,
            'device_argument':args.device,'device_name':props.name,'runtime_uuid':physical,'visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),
            'free_bytes_before_load':free,'total_bytes':total,'host_memory':memory,'allocation_receipt_sha256':common.sha(args.allocation_receipt),
            'numerics_policy_sha256':POLICY_SHA256,'math_policy':after_capture,'seed':0,'initial_rng_observations':rng,
            'native_capture_modes':summaries,'python':sys.version,'python_executable':sys.executable,
            'package_sources':{'torch':common.file_ref(torch.__file__),'transformers':common.file_ref(transformers.__file__),'numpy':common.file_ref(numpy.__file__)}}
        print(json.dumps(common.finalize(args,'gpu',inventory,refs,runtime),allow_nan=False),flush=True)


if __name__ == '__main__': main()

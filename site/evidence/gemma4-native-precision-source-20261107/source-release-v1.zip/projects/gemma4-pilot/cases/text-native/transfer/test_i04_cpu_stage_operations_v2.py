"""CPU archive/process guards only; never invoke native probe or model paths."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i04_cpu_ops_under_test',HERE/'i04_cpu_stage_operations_v2.py')
tool = importlib.util.module_from_spec(spec); spec.loader.exec_module(tool)


class GuardTests(unittest.TestCase):
    def test_canonical_paths(self):
        for name in ('../escape','/absolute','a//b','a/../b','a/./b','a\\b',''):
            with self.assertRaises(ValueError): tool.safe(name)
        self.assertEqual(str(tool.safe('source/a.py')),'source/a.py')

    def archive(self,root,members):
        path = root/'packet.tar.gz'
        with tarfile.open(path,'w:gz') as package:
            for name,kind in members:
                info = tarfile.TarInfo(name); info.size = 1
                if kind == 'link': info.type = tarfile.SYMTYPE; info.linkname = '/outside'; info.size = 0
                package.addfile(info,io.BytesIO(b'x'))
        return path

    def test_reject_archive_links_duplicates_and_ancestor_collisions_before_write(self):
        for members in ([('source/x.py','link')],[('source/x','file'),('source/x','file')],[('source/x','file'),('source/x/y','file')]):
            with tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary); archive = self.archive(root,members); target = root/'new'
                with self.assertRaises(ValueError): tool.extract(archive,target,tool.sha(archive),'a'*64)
                self.assertFalse(target.exists())

    def test_exact_archive_manifest_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); raw = b'# CPU synthetic regular source\n'; name = 'synthetic.py'
            manifest = {'files':{name:{'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}}}
            encoded = json.dumps(manifest).encode(); archive = root/'packet.tar.gz'
            with tarfile.open(archive,'w:gz') as package:
                for member,data in [('source-manifest.json',encoded),('source/'+name,raw)]:
                    info = tarfile.TarInfo(member); info.size = len(data); package.addfile(info,io.BytesIO(data))
            target = root/'new'; source,metadata = tool.extract(archive,target,tool.sha(archive),hashlib.sha256(encoded).hexdigest())
            self.assertEqual((source/name).read_bytes(),raw)
            with self.assertRaisesRegex(ValueError,'exclusive'): tool.extract(archive,target,tool.sha(archive),hashlib.sha256(encoded).hexdigest())
            self.assertEqual((source/name).read_bytes(),raw)

    def test_framework_free_pure_helper_and_actual_proof(self):
        repo = HERE.parents[4]; source = repo/tool.PROOF_HELPER
        helper = tool.pure_module(source,'i04_cpu_guard_pure_proof')
        proof = repo/(tool.CASE+'/transfer/i03-numeric-small-local-20261106T170703Z/payload/i04-prerequisite/prerequisite.json')
        actual = helper.prerequisite(proof,tool.PROOF_SHA)
        self.assertEqual(len(actual['refs']),8); self.assertEqual(actual['native_executions_started'],0)

    @unittest.skipUnless(os.name == 'posix','POSIX owned CPU group cleanup')
    def test_owned_cpu_timeout_has_raw_logs_and_stops_group(self):
        import sys
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            result = tool.child([sys.executable,'-c','import time;print("CPU",flush=True);time.sleep(30)'],root,.1,root/'stdout',root/'stderr')
            self.assertTrue(result['timed_out']); self.assertNotEqual(result['returncode'],0)
            self.assertEqual((root/'stdout').read_bytes(),b'CPU\n')

    def test_changed_source_is_rejected_before_any_helper_import(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); source = root/'source'; source.mkdir()
            path = source/'synthetic.py'; path.write_bytes(b'original CPU source')
            doc = {'kind':'i04-cpu-only-stage-bundle-v2','stage_spec_sha256':tool.STAGE_SHA,
                'i03_prerequisite_sha256':tool.PROOF_SHA,'expected_inventory_sha256':tool.EXPECTED_SHA,
                'native_executions_started':0,'model_loads':0,'expected_CPU_tests':21,
                'files':{'synthetic.py':{'sha256':tool.sha(path),'size_bytes':path.stat().st_size}}}
            manifest = root/'source-manifest.json'; tool.put(manifest,doc); digest = tool.sha(manifest)
            path.write_bytes(b'changed CPU source')
            with patch.object(tool,'pure_module') as importer,self.assertRaisesRegex(ValueError,'source size/SHA'):
                tool.verify_tree(source,manifest,digest)
            importer.assert_not_called()

    def test_expected_framework_guard_requires_fresh_process(self):
        import subprocess
        import sys
        adapters = HERE.parent/'adapters'
        poison = "import sys,types,unittest;sys.path.insert(0,sys.argv[1]);sys.modules['numpy']=types.ModuleType('numpy');sys.modules['i04_common_v1']=types.ModuleType('i04_common_v1');suite=unittest.defaultTestLoader.loadTestsFromName('test_i04_expected_inventory_v1.Coordinates.test_no_collector_framework_imports');raise SystemExit(not unittest.TextTestRunner().run(suite).wasSuccessful())"
        bad = subprocess.run([sys.executable,'-S','-B','-c',poison,str(adapters)],capture_output=True,timeout=20)
        self.assertNotEqual(bad.returncode,0)
        good = subprocess.run([sys.executable,'-S','-B','-m','unittest','-v','test_i04_expected_inventory_v1'],cwd=adapters,capture_output=True,timeout=20)
        self.assertEqual(good.returncode,0,good.stderr.decode(errors='replace'))
        self.assertIn(b'Ran 8 tests',good.stderr); self.assertNotIn(b'skipped',good.stderr)

    @unittest.skipUnless(os.name == 'posix','POSIX bounded CPU orchestration fixture')
    def test_orchestrator_uses_two_fresh_test_children_and_rejects_combination(self):
        calls = []
        def fake_child(argv,cwd,timeout,stdout,stderr):
            calls.append(argv)
            if '-m' in argv:
                modules = argv[5:]
                if modules == ['test_i04_expected_inventory_v1']: log,code = 'Ran 8 tests\n\nOK\n',0
                elif modules == ['test_i04_capture_v1']:
                    log,code = 'test_pinned_factory_masks_valid_queries_for_both_padding_sides ... ok\nRan 13 tests\n\nOK\n',0
                else: log,code = 'Combined namespace poisoned the independent expected guard\nFAILED\n',1
                stdout.write_bytes(b''); stderr.write_text(log)
            else:
                stdout.write_text(json.dumps({'status':'i04_cpu_only_actual_mask_factories_checked','valid_query_key_cells_checked':192,
                    'model_loads':0,'native_model_forward_calls':0,'accelerator_initializations':0,'torch_npu_imported':False,'cuda_initialized':False}))
                stderr.write_bytes(b''); code = 0
            return {'argv':argv,'returncode':code,'timed_out':False}
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary); (base/tool.SUBDIR/'source').mkdir(parents=True)
            with patch.object(tool,'verify_tree',return_value=({}, {'synthetic_fixture':True})),patch.object(tool,'child',side_effect=fake_child):
                result = tool.run(base,'a'*64)
            self.assertEqual(result['status'],'completed')
            self.assertEqual(result['CPU_test_groups_passed'],{'expected':8,'capture':13})
            self.assertEqual([argv[5:] for argv in calls if '-m' in argv],[['test_i04_expected_inventory_v1'],['test_i04_capture_v1']])
            self.assertEqual(len(calls),3)

    @unittest.skipUnless(os.name == 'posix','POSIX adopted CPU descendant cleanup')
    def test_leader_exit_still_reaps_TERM_resistant_grandchild(self):
        import sys
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            code = "import subprocess,sys; p=subprocess.Popen([sys.executable,'-c','import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);print(\"READY\",flush=True);time.sleep(30)'],stdout=subprocess.PIPE);assert p.stdout.readline()==b'READY\\n';print(p.pid,flush=True)"
            result = tool.child([sys.executable,'-c',code],root,5,root/'stdout',root/'stderr')
            self.assertEqual(result['returncode'],0); self.assertFalse(result['cleanup']['remaining_owned_process_group'])
            pid = int((root/'stdout').read_text().splitlines()[0])
            self.assertFalse((Path('/proc')/str(pid)).exists())

    @unittest.skipUnless(os.name == 'posix','POSIX CPU descendant timeout cleanup')
    def test_timeout_reaps_TERM_resistant_descendant_after_leader_TERM(self):
        import sys
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            code = "import subprocess,sys,time; p=subprocess.Popen([sys.executable,'-c','import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);print(\"READY\",flush=True);time.sleep(30)'],stdout=subprocess.PIPE);assert p.stdout.readline()==b'READY\\n';print(p.pid,flush=True);time.sleep(30)"
            result = tool.child([sys.executable,'-c',code],root,.2,root/'stdout',root/'stderr')
            self.assertTrue(result['timed_out']); self.assertFalse(result['cleanup']['remaining_owned_process_group'])
            pid = int((root/'stdout').read_text().splitlines()[0]); self.assertFalse((Path('/proc')/str(pid)).exists())


if __name__ == '__main__': unittest.main()

"""Independent small CPU arithmetic/format fixtures; never native evidence."""
import ast
import copy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
from pathlib import PurePosixPath
import shutil
import struct
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('i03_selected_independent_e02',HERE/'verify_i03_selected_e02_v1.py')
tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def safetensors(path,records,payload):
    raw=json.dumps(records,separators=(',',':')).encode();raw+=b' '*((-len(raw))%8)
    path.write_bytes(struct.pack('<Q',len(raw))+raw+payload)


def npy(path,values,shape=None,descr='<f8'):
    shape=(1,len(values)) if shape is None else shape
    raw=repr({'descr':descr,'fortran_order':False,'shape':shape}).encode();raw+=b' '*((64-(10+len(raw)+1)%64)%64)+b'\n'
    path.write_bytes(b'\x93NUMPY\x01\x00'+struct.pack('<H',len(raw))+raw+struct.pack('<'+str(len(values))+'d',*values))


def fixture_report():
    pairs=[]
    for index in range(23):
        aggregate={field:{'max':float(index),'max_coordinate':{'sample':'CPU-fixture','position':127}} for field in tool.FIELDS}
        pairs.append({'sides':['CPU-a-%d'%index,'CPU-b-%d'%index],'distributions':{'aggregate':aggregate}})
    pairs[12]['sides']=['gpu-full-r1','npu-full-r1']
    kv=[]
    for index in range(4):
        tensor='layer-000.key' if index==0 else 'layer-001.value'
        kv.append({'sides':['CPU-kv-a','CPU-kv-b'],'metrics':{'global':{'max_coordinate':{'tensor':tensor,'index':0,'coordinate':[0]}},
            'per_tensor':{'layer-000.key':{},'layer-001.value':{}}}})
    return {'target_distribution_pairs':pairs,'native_final_kv_pairs':kv}


class Arithmetic(unittest.TestCase):
    def test_all159_scalar_target_reductions_and_first_maximum(self):
        a=[-2.0]*159;b=a[:];b[0]-=1;b[1]-=2;b[2]-=3
        coordinates=[{'sample':'CPU-fixture','position':i+1,'token':i} for i in range(159)]
        result=tool.target_metrics(a,b,coordinates)
        self.assertEqual(result['target_count'],159);self.assertAlmostEqual(result['mae_nat'],6/159)
        self.assertAlmostEqual(result['p99_nat'],1.42);self.assertEqual(result['max_coordinate'],coordinates[2])
        self.assertAlmostEqual(result['side_b_nll_nat_per_token']-result['side_a_nll_nat_per_token'],6/159)
        with self.assertRaises(ValueError):tool.target_metrics(a[:-1],b[:-1],coordinates[:-1])

    def test_uniform_distribution_ties_and_direct_complement(self):
        a=[-math.log(128)]*128;result=tool.distribution_metrics(a,a)
        self.assertEqual((result['union_count'],result['max_error_token'],result['top1_agreement']),(100,0,True))
        self.assertEqual((result['probability_rmse'],result['max_probability_error'],result['tail_merged_js']),(0,0,0))
        self.assertAlmostEqual(result['direct_complement_mass']['side_a'],28/128)

    def test_zero_probability_JS_and_symmetry(self):
        a=[-math.inf]*128;b=a[:];a[0]=0;b[1]=0
        left=tool.distribution_metrics(a,b);right=tool.distribution_metrics(b,a)
        self.assertAlmostEqual(left['tail_merged_js'],math.log(2));self.assertEqual(left['tail_merged_js'],right['tail_merged_js'])
        self.assertAlmostEqual(left['probability_rmse'],math.sqrt(2/100));self.assertFalse(left['top1_agreement'])
        self.assertEqual(left['max_error_token'],0)

    def test_full_tensor_reductions_zero_norm_and_first_tie(self):
        result=tool.tensor_metrics([1.,2.,3.],[1.,3.,1.])
        self.assertEqual((result['count'],result['max_abs'],result['max_flat_index']),(3,2,2))
        self.assertAlmostEqual(result['side_a_norm'],math.sqrt(14));self.assertAlmostEqual(result['error_norm'],math.sqrt(5))
        self.assertAlmostEqual(result['rmse'],math.sqrt(5/3));self.assertAlmostEqual(result['cosine'],10/math.sqrt(154))
        zero=tool.tensor_metrics([0.,0.],[0.,0.]);self.assertIsNone(zero['cosine']);self.assertEqual(zero['max_flat_index'],0)
        with self.assertRaises(ValueError):tool.tensor_metrics([math.nan],[0.])

    def test_global_subset_is_deterministic_deduplicated_and_bounded(self):
        report=fixture_report();selected=tool.select(report)
        self.assertEqual((selected['fixed_cross_full_positions'],selected['distribution_rows_selected']),(47,48))
        self.assertEqual(selected['representative_KV_tensors_selected'],7)
        self.assertFalse(selected['original_model_values_decoded_before_selection'])
        self.assertEqual(selected,tool.select(copy.deepcopy(report)))
        for pair in report['target_distribution_pairs']:
            for field in tool.FIELDS:pair['distributions']['aggregate'][field]['max']=0
        tied=tool.select(report)
        self.assertTrue(all(x['pair_index']==0 and x['reported_tie_pair_count']==23 for x in tied['distribution_extrema_claims']))
        report['target_distribution_pairs'][0]['distributions']['aggregate']['tail_merged_js']['max_coordinate']['position']=96
        with self.assertRaises(ValueError):tool.select(report)


class Formats(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup);self.root=Path(self.temporary.name)

    def test_lossless_BF16_decode_sign_bits_and_scalar_coordinates(self):
        path=self.root/'tiny.safetensors';bits=[0x0000,0x8000,0x3f80,0xbf80,0x3f00,0x4000,0xc000,0x0080]
        safetensors(path,{'tiny':{'dtype':'BF16','shape':[1,2,4],'data_offsets':[0,16]}},struct.pack('<8H',*bits))
        values=tool.native_values(path,'tiny',0,8,[1,2,4])
        self.assertEqual(values[:7],[0.,-0.,1.,-1.,.5,2.,-2.]);self.assertEqual(math.copysign(1,values[1]),-1)
        self.assertEqual(tool.native_values(path,'tiny',5,1)[0],2.)
        self.assertEqual(tool.unravel(5,[1,2,4]),[0,1,1])
        with self.assertRaises(ValueError):tool.native_values(path,'tiny',8,1)
        with self.assertRaises(ValueError):tool.bf16_values(struct.pack('<H',0x7f80))
        with self.assertRaises(ValueError):tool.bf16_values(struct.pack('<H',0x7fc1))

    def test_native_gap_overlap_wrong_dtype_or_truncation_rejected(self):
        path=self.root/'bad.safetensors'
        for records,payload in [
            ({'a':{'dtype':'BF16','shape':[2],'data_offsets':[0,4]},'b':{'dtype':'BF16','shape':[2],'data_offsets':[2,6]}},b'\0'*6),
            ({'a':{'dtype':'BF16','shape':[2],'data_offsets':[2,6]}},b'\0'*6),
            ({'a':{'dtype':'F16','shape':[2],'data_offsets':[0,4]}},b'\0'*4),
            ({'a':{'dtype':'BF16','shape':[2],'data_offsets':[0,4]}},b'\0'*2)]:
            safetensors(path,records,payload)
            with self.assertRaises(ValueError):tool.native_header(path)

    def test_NPY_shape_dtype_finiteness_and_bytes(self):
        path=self.root/'row.npy';values=[-math.log(128)]*128;npy(path,values)
        self.assertEqual(tool.read_npy(path,128),tuple(values))
        for shape,descr in [((128,),'<f8'),((1,128),'<f4')]:
            npy(path,values,shape,descr)
            with self.assertRaises(ValueError):tool.read_npy(path,128)
        npy(path,[math.nan]*128)
        with self.assertRaises(ValueError):tool.read_npy(path,128)
        path.write_bytes(b'\x93NUMPY\x01\x00\xff')
        with self.assertRaises(ValueError):tool.read_npy(path,128)

    def test_scalar_native_logprob_rederivation(self):
        result=tool.independent_logprobs([0.,0.,0.,0.]);self.assertEqual(result,[-math.log(4)]*4)
        self.assertAlmostEqual(math.fsum(math.exp(x) for x in result),1)

    @unittest.skipUnless(os.name=='posix','Original POSIX source-map paths')
    def test_endpoint_actual_copied_and_retained_hashes_and_source_mutation(self):
        mapped=self.root/'source-map.json';array=self.root/'tiny.npy';array.write_bytes(b'CPU hash fixture, no numeric content')
        original='/CPU-fixture/output/tiny.npy'
        info={'source_map':{'path':str(mapped),'sha256':None},'receipt':{'source_path':'/CPU-fixture/capture.json'}}
        mapping={'schema_version':1,'request':{'task':'I03','backend':'GPU','outer_receipt':info['receipt']['source_path']},
            'files':{original:{'path':array.name,'size':array.stat().st_size,'sha256':digest(array)}}}
        tool.put(mapped,mapping);info['source_map']['sha256']=digest(mapped)
        endpoint=tool.Endpoint(tool.Audit(600),info,'GPU');self.assertEqual(endpoint.get(original),array)
        array.write_bytes(b'changed')
        with self.assertRaises(ValueError):endpoint.get(original,force=True)
        mapped.unlink();array.write_bytes(b'new CPU retained fixture');name=str(array)
        info['retained_root']=str(self.root);mapping['request']['backend']='NPU';mapping['files']={name:{'retained_at_source':True,'size':array.stat().st_size,'sha256':digest(array)}}
        tool.put(mapped,mapping);info['source_map']['sha256']=digest(mapped)
        endpoint=tool.Endpoint(tool.Audit(600),info,'NPU');self.assertEqual(endpoint.get(name),array)
        mapping['files'][name]['path']='forbidden';mapped.unlink();tool.put(mapped,mapping);info['source_map']['sha256']=digest(mapped)
        with self.assertRaises(ValueError):tool.Endpoint(tool.Audit(600),info,'NPU').get(name)

    def test_strict_JSON_and_no_shared_numeric_imports(self):
        for raw in ('{"a":1,"a":2}','{"a":NaN}'):
            with self.assertRaises(ValueError):tool.parse(raw)
        tree=ast.parse((HERE/'verify_i03_selected_e02_v1.py').read_text())
        imports=[node.module for node in ast.walk(tree) if isinstance(node,ast.ImportFrom)]+[alias.name for node in ast.walk(tree) if isinstance(node,ast.Import) for alias in node.names]
        self.assertFalse(any(name and any(word in name for word in ('numpy','torch','compare','admit','i03_artifact')) for name in imports))
        self.assertFalse(any(name in sys.modules for name in ('torch','torch_npu','numpy')))


class ActualMetadata(unittest.TestCase):
    def test_actual_predeclared_selection_and23_target_reductions_after_freeze(self):
        # Raw original metadata only. The source484 native arrays are not opened.
        base=HERE.parent/'transfer/i03-numeric-small-local-20261106T170703Z/payload'
        if not (base/'metadata-source-map.json').is_file():self.skipTest('retained actual small metadata unavailable')
        metadata=json.loads((base/'metadata-source-map.json').read_text())
        self.assertEqual(digest(base/'metadata-source-map.json'),'f37e4c5e40160de007e4f156f3dcaa4f53d49b4563e9a1d8b17a7af9c0618e7f')
        proof=base/'i04-prerequisite';prior=json.loads((proof/'prerequisite.json').read_text())
        controller=json.loads((proof/'proof/i03-controller.json').read_text());report=json.loads((proof/'proof/i03-report.json').read_text())
        comparison=json.loads((proof/'proof/i03-comparison-spec.json').read_text())
        self.assertEqual(digest(proof/'proof/i03-report.json'),tool.ACTUAL_REPORT_SHA)
        selection=tool.select(report);selection.update(source_controller={'path':prior['controller']['source_path'],'sha256':tool.ACTUAL_CONTROLLER_SHA},source_report=controller['report'])
        self.assertEqual(hashlib.sha256((json.dumps(selection,indent=2,allow_nan=False)+'\n').encode()).hexdigest(),tool.SELECTION_SHA)
        self.assertEqual((selection['distribution_rows_selected'],selection['representative_KV_tensors_selected']),(49,8))
        self.assertTrue((HERE.parent/'transfer/i03-e02-selected-inventory-20261107.json').is_file())
        runs={}
        def local_document(original):
            ref=metadata['files'][original];path=base/ref['path'];self.assertEqual(digest(path),ref['sha256']);return json.loads(path.read_text())
        for backend,info in comparison['endpoints'].items():
            mapping_path=info['source_map']['path'];mapping=local_document(mapping_path)
            def native_document(original):
                ref=mapping['files'][original];actual=str(PurePosixPath(mapping_path).parent/ref['path'])
                result=local_document(actual);self.assertEqual(metadata['files'][actual]['sha256'],ref['sha256']);return result
            outer=native_document(info['receipt']['source_path']);input_doc=native_document(outer['input_path']);seq=input_doc['prompt']+input_doc['continuation']
            coordinates=[{'sample':input_doc['sample'],'position':i,'token':seq[i]} for i in range(1,160)]
            for mode in tool.MODES:
                doc=native_document(outer['output_dir']+'/modes/'+mode+'/target-scores.json')
                runs[backend.lower()+'-'+mode]=([x['logprob'] for x in doc['scores']],coordinates)
        for pair in report['target_distribution_pairs']:
            a,b=[runs[side] for side in pair['sides']];self.assertEqual(a[1],b[1]);actual=tool.target_metrics(a[0],b[0],a[1])
            for field,value in actual.items():
                if field=='max_coordinate':self.assertEqual(value,pair['targets']['metrics'][field])
                else:tool.equal(value,pair['targets']['metrics'][field],field)


@unittest.skipUnless(os.name=='posix','POSIX signal/process envelope protocol fixture')
class RunnerProtocol(unittest.TestCase):
    def test_bound_runner_preserves_controller_archive_and_transfer_envelope_bytes(self):
        # Substitute a labelled CPU-only protocol stub via test-only hash patch.
        # Production pins require the actual reviewed verifier, never this stub.
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);(root/'runs').mkdir();here=root/'tools';here.mkdir()
            runner_path=HERE.parent/'transfer/run_i03_selected_e02_v1.py'
            spec=importlib.util.spec_from_file_location('i03_e02_runner_protocol',runner_path);runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
            own=here/runner_path.name;shutil.copyfile(runner_path,own)
            repo=next(path for path in HERE.parents if (path/'skills/precision-compare/scripts/record_run.py').is_file())
            shutil.copyfile(repo/'skills/precision-compare/scripts/record_run.py',here/'record_run.py')
            verifier=here/'verify_i03_selected_e02_v1.py'
            verifier.write_text("""# Synthetic CPU protocol fixture; no model or independent numerical claim.
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--controller');p.add_argument('--controller-sha256');p.add_argument('--output');a=p.parse_args()
o=Path(a.output);o.mkdir()
d={'status':'independent_i03_selected_e02_checks_matched','scope':{'target_pairs':23,'global_KV_coordinates':4,'admitted_large_sources_final_bytehash_checked':484},'source_report':{'synthetic_CPU_protocol_fixture':True},'native_executions_started':0,'acceptance':None}
for name,value in [('e02-report.json',d),('source-proof.json',{'checked_sources':{},'original_source_files':{}}),('admitted-large-source-hashes.json',[])]:
 (o/name).write_text(json.dumps(value))
print('synthetic CPU stub completed; not native evidence')
""")
            controller=root/'original-controller.json';controller.write_text('{"synthetic_CPU_protocol_fixture":true}')
            old_umask=os.umask(0o077)
            try:
                with patch.object(runner,'VERIFY_SHA',digest(verifier)),patch.object(runner,'__file__',str(own)):
                    self.assertEqual(runner.run(root,controller,digest(controller)),0)
            finally:os.umask(old_umask)
            envelope_path=next((root/'runs').glob('*-json-base64.txt'));envelope=json.loads(envelope_path.read_text())
            import base64
            raw_controller=base64.b64decode(envelope['controller_raw_base64']);raw_archive=base64.b64decode(envelope['archive']['base64'])
            self.assertEqual(hashlib.sha256(raw_controller).hexdigest(),envelope['controller_sha256'])
            self.assertEqual(raw_controller,Path(envelope['controller_path']).read_bytes())
            self.assertEqual(hashlib.sha256(raw_archive).hexdigest(),envelope['archive']['sha256'])
            self.assertEqual(len(raw_archive),envelope['archive']['bytes'])
            with tarfile.open(envelope['archive']['path']) as package:
                self.assertTrue(all(item.isfile() and not item.name.startswith('/') and '..' not in item.name.split('/') for item in package.getmembers()))
            self.assertEqual(controller.read_text(),'{"synthetic_CPU_protocol_fixture":true}')


if __name__=='__main__':unittest.main()

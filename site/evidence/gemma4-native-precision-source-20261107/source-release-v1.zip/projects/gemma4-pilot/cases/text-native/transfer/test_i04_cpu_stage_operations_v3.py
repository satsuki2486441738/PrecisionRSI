"""CPU archive/process/import-state guards; no framework/model/device calls."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i04_cpu_ops_under_test',HERE/'i04_cpu_stage_operations_v3.py')
tool = importlib.util.module_from_spec(spec); spec.loader.exec_module(tool)
tool.validate_probe_unpatched = tool.validate_probe


def synthetic_probe(root=None):
    """Synthetic protocol data; this never executes a factory or imports Torch."""
    write_sources = root is not None
    root = Path(root) if write_sources else Path(tempfile.gettempdir())/'synthetic-runtime-unwritten'
    paths = {'torch':'torch/__init__.py','numpy':'numpy/__init__.py','transformers':'transformers/__init__.py',
        'masking_utils':'transformers/masking_utils.py','configuration':'transformers/models/gemma4_unified/configuration_gemma4_unified.py',
        'import_utils':'transformers/utils/import_utils.py','torch_npu_npu':'torch_npu/npu/__init__.py'}
    sources = {}
    for key, relative in paths.items():
        path = root / relative; raw = ('# Synthetic CPU protocol source: ' + key + '\n').encode()
        if write_sources:
            path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(raw)
        sources[key] = {'path':path.as_posix(),'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}
    return {'status':'i04_cpu_only_actual_mask_factories_checked','valid_query_key_cells_checked':192,
        'versions':{'torch':'2.9.0+cpu','transformers':'5.10.1','numpy':'1.26.4'},'sources':sources,
        'model_loads':0,'native_model_forward_calls':0,'agent_accelerator_initialization_requests':0,
        'agent_hardware_or_availability_queries':0,'torch_npu_imported':True,'npu_initialized':False,'cuda_initialized':False,
        'device_backend_autoload':'0','device_initialization_checks':'getter_only',
        'library_internal_availability_queries':'not_counted_and_not_prohibited',
        'phase_observations':[{'phase':name,'torch_npu_imported':index >= 2,'npu_namespace_registered':index >= 2,
            'npu_initialized':None if index < 2 else False,'cuda_initialized':False} for index,name in enumerate(tool.PROBE_PHASES)],
        'observations':[{'side':side,'factory':factory,'shape':[2,1,4,4],'dtype':'torch.bfloat16','device':'cpu'}
            for side in ('left','right') for factory in ('sliding_attention','full_attention','direct_full','direct_sliding')]}


class GuardTests(unittest.TestCase):
    def test_canonical_paths(self):
        for name in ('../escape','/absolute','a//b','a/../b','a/./b','a\\b',''):
            with self.assertRaises(ValueError): tool.safe(name)
        self.assertEqual(str(tool.safe('source/a.py')),'source/a.py')

    def archive(self,root,members):
        path = root/'packet.tar.gz'
        with tarfile.open(path,'w:gz') as package:
            for name,kind in members:
                info = tarfile.TarInfo(name); info.size = 1
                if kind == 'link': info.type = tarfile.SYMTYPE; info.linkname = '/outside'; info.size = 0
                package.addfile(info,io.BytesIO(b'x'))
        return path

    def test_reject_archive_links_duplicates_and_ancestor_collisions_before_write(self):
        for members in ([('source/x.py','link')],[('source/x','file'),('source/x','file')],[('source/x','file'),('source/x/y','file')]):
            with tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary); archive = self.archive(root,members); target = root/'new'
                with self.assertRaises(ValueError): tool.extract(archive,target,tool.sha(archive),'a'*64)
                self.assertFalse(target.exists())

    def test_exact_archive_manifest_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); raw = b'# CPU synthetic regular source\n'; name = 'synthetic.py'
            manifest = {'files':{name:{'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}}}
            encoded = json.dumps(manifest).encode(); archive = root/'packet.tar.gz'
            with tarfile.open(archive,'w:gz') as package:
                for member,data in [('source-manifest.json',encoded),('source/'+name,raw)]:
                    info = tarfile.TarInfo(member); info.size = len(data); package.addfile(info,io.BytesIO(data))
            target = root/'new'; source,metadata = tool.extract(archive,target,tool.sha(archive),hashlib.sha256(encoded).hexdigest())
            self.assertEqual((source/name).read_bytes(),raw)
            with self.assertRaisesRegex(ValueError,'exclusive'): tool.extract(archive,target,tool.sha(archive),hashlib.sha256(encoded).hexdigest())
            self.assertEqual((source/name).read_bytes(),raw)

    def test_framework_free_pure_helper_and_actual_proof(self):
        repo = HERE.parents[4]; source = repo/tool.PROOF_HELPER
        helper = tool.pure_module(source,'i04_cpu_guard_pure_proof')
        proof = repo/(tool.CASE+'/transfer/i03-numeric-small-local-20261106T170703Z/payload/i04-prerequisite/prerequisite.json')
        actual = helper.prerequisite(proof,tool.PROOF_SHA)
        self.assertEqual(len(actual['refs']),8); self.assertEqual(actual['native_executions_started'],0)

    @unittest.skipUnless(os.name == 'posix','POSIX owned CPU group cleanup')
    def test_owned_cpu_timeout_has_raw_logs_and_stops_group(self):
        import sys
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            result = tool.child([sys.executable,'-c','import time;print("CPU",flush=True);time.sleep(30)'],root,.1,root/'stdout',root/'stderr')
            self.assertTrue(result['timed_out']); self.assertNotEqual(result['returncode'],0)
            self.assertEqual((root/'stdout').read_bytes(),b'CPU\n')

    def test_changed_source_is_rejected_before_any_helper_import(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); source = root/'source'; source.mkdir()
            path = source/'synthetic.py'; path.write_bytes(b'original CPU source')
            doc = {'kind':'i04-cpu-only-stage-bundle-v3','stage_spec_sha256':tool.STAGE_SHA,
                'i03_prerequisite_sha256':tool.PROOF_SHA,'expected_inventory_sha256':tool.EXPECTED_SHA,
                'native_executions_started':0,'model_loads':0,'expected_CPU_tests':21,
                'files':{'synthetic.py':{'sha256':tool.sha(path),'size_bytes':path.stat().st_size}}}
            manifest = root/'source-manifest.json'; tool.put(manifest,doc); digest = tool.sha(manifest)
            path.write_bytes(b'changed CPU source')
            with patch.object(tool,'pure_module') as importer,self.assertRaisesRegex(ValueError,'source size/SHA'):
                tool.verify_tree(source,manifest,digest)
            importer.assert_not_called()

    def test_expected_framework_guard_requires_fresh_process(self):
        import subprocess
        import sys
        adapters = HERE.parent/'adapters'
        poison = "import sys,types,unittest;sys.path.insert(0,sys.argv[1]);sys.modules['numpy']=types.ModuleType('numpy');sys.modules['i04_common_v1']=types.ModuleType('i04_common_v1');suite=unittest.defaultTestLoader.loadTestsFromName('test_i04_expected_inventory_v1.Coordinates.test_no_collector_framework_imports');raise SystemExit(not unittest.TextTestRunner().run(suite).wasSuccessful())"
        bad = subprocess.run([sys.executable,'-S','-B','-c',poison,str(adapters)],capture_output=True,timeout=20)
        self.assertNotEqual(bad.returncode,0)
        good = subprocess.run([sys.executable,'-S','-B','-m','unittest','-v','test_i04_expected_inventory_v1'],cwd=adapters,capture_output=True,timeout=20)
        self.assertEqual(good.returncode,0,good.stderr.decode(errors='replace'))
        self.assertIn(b'Ran 8 tests',good.stderr); self.assertNotIn(b'skipped',good.stderr)

    @unittest.skipUnless(os.name == 'posix','POSIX bounded CPU orchestration fixture')
    def test_orchestrator_uses_two_fresh_test_children_and_rejects_combination(self):
        calls = []
        def fake_child(argv,cwd,timeout,stdout,stderr):
            calls.append(argv)
            if '-m' in argv:
                modules = argv[5:]
                if modules == ['test_i04_expected_inventory_v1']: log,code = 'Ran 8 tests\n\nOK\n',0
                elif modules == ['test_i04_capture_v2']:
                    log,code = 'test_pinned_factory_masks_valid_queries_for_both_padding_sides ... ok\nRan 13 tests\n\nOK\n',0
                else: log,code = 'Combined namespace poisoned the independent expected guard\nFAILED\n',1
                stdout.write_bytes(b''); stderr.write_text(log)
            else:
                stdout.write_text(json.dumps(synthetic_probe()))
                stderr.write_bytes(b''); code = 0
            return {'argv':argv,'returncode':code,'timed_out':False}
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary); (base/tool.SUBDIR/'source').mkdir(parents=True)
            with patch.object(tool,'verify_tree',return_value=({}, {'synthetic_fixture':True})),patch.object(tool,'child',side_effect=fake_child),patch.object(tool,'validate_probe',side_effect=lambda p: tool.validate_probe_unpatched(p,False)):
                result = tool.run(base,'a'*64)
            self.assertEqual(result['status'],'completed')
            self.assertEqual(result['CPU_test_groups_passed'],{'expected':8,'capture':13})
            self.assertEqual([argv[5:] for argv in calls if '-m' in argv],[['test_i04_expected_inventory_v1'],['test_i04_capture_v2']])
            self.assertEqual(len(calls),3)

    @unittest.skipUnless(os.name == 'posix','POSIX adopted CPU descendant cleanup')
    def test_leader_exit_still_reaps_TERM_resistant_grandchild(self):
        import sys
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            code = "import subprocess,sys; p=subprocess.Popen([sys.executable,'-c','import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);print(\"READY\",flush=True);time.sleep(30)'],stdout=subprocess.PIPE);assert p.stdout.readline()==b'READY\\n';print(p.pid,flush=True)"
            result = tool.child([sys.executable,'-c',code],root,5,root/'stdout',root/'stderr')
            self.assertEqual(result['returncode'],0); self.assertFalse(result['cleanup']['remaining_owned_process_group'])
            pid = int((root/'stdout').read_text().splitlines()[0])
            self.assertFalse((Path('/proc')/str(pid)).exists())

    @unittest.skipUnless(os.name == 'posix','POSIX CPU descendant timeout cleanup')
    def test_timeout_reaps_TERM_resistant_descendant_after_leader_TERM(self):
        import sys
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            code = "import subprocess,sys,time; p=subprocess.Popen([sys.executable,'-c','import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);print(\"READY\",flush=True);time.sleep(30)'],stdout=subprocess.PIPE);assert p.stdout.readline()==b'READY\\n';print(p.pid,flush=True);time.sleep(30)"
            result = tool.child([sys.executable,'-c',code],root,.2,root/'stdout',root/'stderr')
            self.assertTrue(result['timed_out']); self.assertFalse(result['cleanup']['remaining_owned_process_group'])
            pid = int((root/'stdout').read_text().splitlines()[0]); self.assertFalse((Path('/proc')/str(pid)).exists())


class ProbeSemantics(unittest.TestCase):
    def test_registered_import_is_allowed_while_all_initialization_getters_stay_false(self):
        with tempfile.TemporaryDirectory() as temporary:
            probe = synthetic_probe(Path(temporary))
            self.assertIs(tool.validate_probe(probe),probe)
            self.assertIs(probe['torch_npu_imported'],True)
            self.assertEqual(len(probe['sources']),7)
            self.assertNotIn('accelerator_initializations',probe)

    def test_any_initialized_phase_is_rejected(self):
        for index in range(6):
            for field in ('npu_initialized','cuda_initialized'):
                with self.subTest(index=index,field=field):
                    probe = synthetic_probe(); probe['phase_observations'][index][field] = True
                    with self.assertRaises(ValueError): tool.validate_probe(probe,False)

    def test_unregistered_phase_is_unknown_not_falsely_recorded_as_getter_false(self):
        probe = synthetic_probe(); probe['phase_observations'][0]['npu_initialized'] = False
        with self.assertRaisesRegex(ValueError,'phase'): tool.validate_probe(probe,False)
        probe = synthetic_probe(); probe['phase_observations'].reverse()
        with self.assertRaisesRegex(ValueError,'ordered'): tool.validate_probe(probe,False)

    def test_import_ban_or_library_internal_zero_claim_is_not_accepted(self):
        for field,value in [('torch_npu_imported',False),('library_internal_availability_queries',0),
                ('device_initialization_checks','availability_probe'),('agent_hardware_or_availability_queries',1)]:
            with self.subTest(field=field):
                probe = synthetic_probe(); probe[field] = value
                with self.assertRaises(ValueError): tool.validate_probe(probe,False)

    def test_runtime_sources_are_rehashed_and_cannot_drop_getter_or_import_utils(self):
        with tempfile.TemporaryDirectory() as temporary:
            probe = synthetic_probe(Path(temporary)); Path(probe['sources']['torch_npu_npu']['path']).write_bytes(b'mutated')
            with self.assertRaisesRegex(ValueError,'source bytes'): tool.validate_probe(probe)
        probe = synthetic_probe(); del probe['sources']['import_utils']
        with self.assertRaisesRegex(ValueError,'seven'): tool.validate_probe(probe,False)

    def test_exact_192_cells_eight_masks_and_integer_zero_claims(self):
        for field,value in [('valid_query_key_cells_checked',True),('model_loads',False),('native_model_forward_calls',1),
                ('agent_accelerator_initialization_requests',1)]:
            with self.subTest(field=field):
                probe = synthetic_probe(); probe[field] = value
                with self.assertRaises(ValueError): tool.validate_probe(probe,False)
        probe = synthetic_probe(); probe['observations'].pop()
        with self.assertRaisesRegex(ValueError,'inventory'): tool.validate_probe(probe,False)

    def test_v2_history_and_v3_final_probe_test_pins(self):
        self.assertEqual(tool.sha(HERE/'i04_cpu_stage_operations_v2.py'),
            'bffba407af697b0891e11d0309612d43b5b507b6297e095726c22c795e2a8c2a')
        self.assertEqual(tool.FIXED[tool.PROBE], '036788fadb665d766bed7c6ea4832ae0d80732eb588f06df5abee96f955429f1')
        self.assertEqual(tool.FIXED[tool.CASE+'/adapters/test_i04_capture_v2.py'],
            '5b07f6f30e87b4005876d0fa26dbcb8896136430681b9b3ed77aef0181cf962f')
        self.assertTrue(tool.SUBDIR.endswith('cpu-stage-v3'))


if __name__ == '__main__': unittest.main()

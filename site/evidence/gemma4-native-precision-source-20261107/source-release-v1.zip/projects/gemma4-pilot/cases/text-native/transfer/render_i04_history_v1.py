"""Render the private109th history candidate from a real seven-file I04 archive.

Read-only Git commands verify immutable blobs; site/, repair history and Git are
never written. The actual archive commit is mandatory, after root publication.
"""
import argparse
from collections import Counter
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
CASE = 'projects/gemma4-pilot/cases/text-native'
ID = 'gemma4-h100-ascend-batch-padding-20261107'
PREFIX = 'site/evidence/' + ID + '/'
HISTORY_SHA = 'a9ea2987d1a12ed3772b14a82fb043b6da13fdb6b109008e4bb2f855d215303d'
REPAIRS_SHA = '0c186a832c07aa42bb9c74b0e98fd2ad036de52eb5ea694f28ec8353daf2d1fc'
REPAIRS_ARCHIVE_SHA = '0edb5cce61a39322eea02f521d8bb4632ab6780fd31a2c8dabd9b15c5cf1bca2'
REPORT_SHA = 'b65819037bacac5d9098834a364c3512defb0f77435160f53a0a340a5a8d0c48'
CONTROLLER_SHA = '5d18a78e14433e5b1e812ca4335704182cbeac1f18ce5fd5ceee30d0ad1cd3f0'
E02_CONTROLLER_SHA = '0129c269f8732d93303cb026468735144cc9b97f29aa0e2170958b5b48a837a9'
E02_REPORT_SHA = 'fc664f2fd6e78905edd2e8ee1a9a47d59ce7d723f4107527bb32a5cc094d4b15'
VERIFIER_SHA = '2cdb98c37f2e3690ed9b7918ff0b223f4f662d90014c0bbd649c2dc76ecc639c'
SELECTION_SHA = '77ae35aa07f2b70b3db1206f456ce107eac831018003f061bcd54061c66377a3'
FILES = ('report.md', 'coverage.json', 'selected-targets.json', 'selected-metrics.json',
         'replay-targets.py', 'execution-cost.json', 'independent-checks.json')
# Root may revise report prose spacing before the archive; its real Git blob is
# pinned in the produced entry. All six measured JSON/script bytes stay fixed.
FIXED = {'selected-targets.json': '39d15fa7c8312c6783ce02dfda039352dd36f58e8c790fb21ace5f9c9b14bf61',
         'selected-metrics.json': '7f9b478c857d0e7002d1893338d2e37b15fc6b9a3bfb770ea88b060cc5e4e61b',
         'replay-targets.py': '9bbf83cf96d1d2d231a8f43b3de155cf9aac2bfc423172532bc40e98cec76b69',
         'execution-cost.json': '468b2d85ea44389ef12a107d6d9432675e3451f6730a4137a4345157e054853c',
         'coverage.json': '0c76093988ed7a5b63bb53b0d69db39307780dd99574288c2f53ee1ee2949492',
         'independent-checks.json': '79d7987715b3c5aa718499cec6bc99dd1579d7d0fcc2302f6f72b26ac971cbd4'}
IDS = ('alone-a-a', 'alone-b-b', 'batch-left-a', 'batch-left-b', 'batch-right-a', 'batch-right-b')
SIDES = [b + '-' + mode for b in ('gpu', 'npu') for mode in IDS]
PAIRS = [[f'gpu-{mode}', f'npu-{mode}'] for mode in
         ('alone-a-a', 'batch-left-a', 'batch-right-a', 'alone-b-b', 'batch-left-b', 'batch-right-b')]
for _backend in ('gpu', 'npu'):
    for _request in ('a', 'b'):
        _alone = f'{_backend}-alone-{_request}-{_request}'
        _left, _right = f'{_backend}-batch-left-{_request}', f'{_backend}-batch-right-{_request}'
        PAIRS.extend([[_alone, _left], [_alone, _right], [_left, _right]])


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            require(key not in out, 'duplicate JSON key')
            out[key] = value
        return out
    def reject(value):
        raise ValueError('nonfinite JSON token ' + value)
    doc = json.loads(raw, object_pairs_hook=pairs, parse_constant=reject)
    json.dumps(doc, allow_nan=False)
    return doc


def put(path, doc):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(doc, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def git(repo, *args):
    result = subprocess.run(['git', *args], cwd=repo, check=True, capture_output=True, timeout=30)
    require(len(result.stdout) <= 16 * 1024**2, 'bounded archive blob required')
    return result.stdout


def archive_files(repo, revision, history_raw, repairs_raw):
    require(re.fullmatch(r'[a-f0-9]{40}', revision), 'actual full40hex archive commit required')
    require(git(repo, 'rev-parse', '--verify', revision + '^{commit}').decode().strip() == revision,
            'actual commit object required')
    listed = git(repo, 'ls-tree', '-r', '--name-only', revision, '--', PREFIX).decode().splitlines()
    require(set(listed) == {PREFIX + name for name in FILES} and len(listed) == 7,
            'archive must contain exactly seven evidence files')
    require(git(repo, 'show', revision + ':site/data/evaluations.json') == history_raw,
            'archive must precede this109th history append')
    archived_repairs = git(repo, 'show', revision + ':site/data/repairs.json')
    require(digest(archived_repairs) == REPAIRS_ARCHIVE_SHA and
            archived_repairs == repairs_raw.replace(b'\r\n', b'\n'),
            'known20repair archive/working newline provenance changed')
    documents, pins = {}, {}
    for name in FILES:
        raw = git(repo, 'show', revision + ':' + PREFIX + name)
        path = repo / PREFIX / name
        require(path.is_file() and not path.is_symlink() and path.read_bytes() == raw,
                'published bytes differ from archived blob: ' + name)
        pins[name] = digest(raw)
        require(name not in FIXED or pins[name] == FIXED[name], 'reviewed evidence pin changed: ' + name)
        documents[name] = read(raw) if name.endswith('.json') else raw.decode('utf-8')
    require(documents['report.md'].startswith('# Gemma-4-12B'), 'reviewed I04 report title required')
    return documents, pins


def validate_evidence(documents, previous_coverage):
    m, t, coverage, e02, cost = (documents[k] for k in
        ('selected-metrics.json', 'selected-targets.json', 'coverage.json', 'independent-checks.json', 'execution-cost.json'))
    for doc in (m, t):
        require(doc['thresholds'] is None and doc['acceptance'] is None and doc['full_core_complete'] is False,
                'acceptance or full-core claim changed')
        w = doc['workload']
        require(w['independent_parent_inputs'] == w['derived_prefix_shape_stress_requests'] == 1 and
                w['new_model_processes_per_backend'] == w['model_loads_per_backend'] == 1 and
                w['native_calls_per_backend'] == w['native_modes_per_backend'] == 4 and
                w['logical_observations_per_backend'] == 6 and w['use_cache'] is False and
                w['target_scores_rederived'] == 1524 and w['full_vocabulary_rows_rederived'] == 564 and
                w['raw_physical_rows_retained'] == 1792 and w['valid_raw_rows_finite_checked'] == 1536 and
                w['pad_only_rows_separately_counted'] == 256 and w['target_distribution_pairs'] == 18 and
                all(w[k] is False for k in ('fresh_process_repeatability_measured', 'batch_padding_repeatability_measured', 'cache_eviction_tested')),
                'actual one-parent I04 coverage differs')
        for request, length in (('A', 160), ('B', 96)):
            r = w['requests'][request]
            require(r['sequence_length'] == length and r['target_count'] == length - 1 and
                    r['distribution_rows_per_observation'] == len(r['distribution_predictor_positions']) == 47,
                    'unequal request coverage changed')
        require([run['id'] for run in doc['runs']] == SIDES and
                [pair['sides'] for pair in doc['target_pairs']] == PAIRS, '12sides/18cross-first pairs differ')
        a = doc['array_evidence']
        require(a['independent_e02_scalar_math_recheck_completed'] is True and
                a['independent_e02_summary_ref'] == {'file': 'independent-checks.json', 'sha256': FIXED['independent-checks.json']} and
                a['native_admission_full_array_files_checked'] == 572 and
                a['downloaded_main_and_E02_metadata_array_files'] == a['public_target_replay_arrays_read'] == 0,
                'actual E02 binding or metadata zero-array scope changed')
    require(m['source_pins'] == t['source_pins'] and m['target_pairs'] == t['target_pairs'] and
            m['source_pins']['comparison_report_sha256'] == REPORT_SHA and
            m['source_pins']['controller_sha256'] == CONTROLLER_SHA and
            m['source_pins']['E02_report_sha256'] == E02_REPORT_SHA and m['native_final_KV_pairs'] == [],
            'main/E02 source pins, targets or no-KV scope differ')
    require([p['sides'] for p in m['distribution_pairs']] == PAIRS and
            sum(p['position_count'] for p in m['distribution_pairs']) == 846, 'complete846 row contrasts required')
    for target, dist in zip(m['target_pairs'], m['distribution_pairs']):
        n = 159 if target['request'] == 'A' else 95
        require(target['coverage'] == {'expected': n, 'paired': n} and target['metrics']['target_count'] == n and
                target['thresholds'] is None and target['acceptance'] is None and
                dist['request'] == target['request'] and dist['position_count'] == len(dist['positions']) == 47,
                'per-request target/distribution coverage differs')
    require(coverage['task_count'] == 49 and coverage['core_task_count'] == 28 and
            coverage['full_core_complete'] is False and coverage['original_49_task_scope_complete'] is False and
            coverage['thresholds'] is None and coverage['acceptance'] is None and
            len(coverage['tasks']) == 49 and coverage['counts'] == dict(Counter(x['status'] for x in coverage['tasks'])) and
            all(x['full_plan_task_complete'] is False for x in coverage['tasks']), 'full-plan incomplete49task ledger required')
    keys = ('task_id', 'profile', 'expected_coverage')
    require([{k: x[k] for k in keys} for x in coverage['tasks']] ==
            [{k: x[k] for k in keys} for x in previous_coverage['tasks']], 'original49 plan identities changed')
    old_status = {x['task_id']: x['status'] for x in previous_coverage['tasks']}
    require(all(x['status'] == ('complete' if x['task_id'] == 'I04' else old_status[x['task_id']]) for x in coverage['tasks']) and
            coverage['counts'] == {'partial': 6, 'complete': 9, 'pending': 11, 'deferred': 21, 'not_applicable': 2},
            'only scoped I04 status transition is supported')
    require(e02['kind'] == 'selected_I04_independent_E02_summary' and
            e02['status'] == 'independent_i04_selected_e02_checks_matched' and
            e02['source_controller_sha256'] == E02_CONTROLLER_SHA and e02['source_report_sha256'] == E02_REPORT_SHA and
            e02['original_I04_report_sha256'] == REPORT_SHA and e02['verifier_sha256'] == VERIFIER_SHA and
            e02['source_selection_sha256'] == SELECTION_SHA and e02['all_native_array_hashes_checked'] == 572 and
            e02['native_executions_started'] == 0 and e02['thresholds'] is None and e02['acceptance'] is None and
            e02['full_core_complete'] is False, 'actual selected E02 source proof differs')
    s = e02['scope']
    require(s['target_pairs'] == 18 and s['request_target_counts'] == {'A': 159, 'B': 95} and
            s['independent_distribution_pair_rows'] == 283 and s['matched_cross_backend_distribution_pair_rows'] == 282 and
            s['all_distribution_pair_rows_in_original_report'] == 846 and s['native_KV_checks'] == 0 and
            s['admitted_large_sources_final_bytehash_checked'] == 572 and s['independent_parent_inputs'] == 1 and
            s['all_raw_valid_rows_independently_replayed'] is False and
            len(e02['target_pair_checks']) == 18 and len(e02['distribution_checks']) == 283 and e02['native_KV_checks'] == [] and
            e02['verification']['model_acceptance_thresholds'] is False, 'selected283row scope differs')
    require(cost['kind'] == 'selected_I04_execution_accounting' and cost['acceptance'] is None and
            all(cost[k] is False for k in ('P01_complete', 'total_evaluation_cost_complete', 'headline_speed_comparison_supported')) and
            cost['total_allocated_device_seconds'] is None and cost['total_currency_cost'] is None, 'speed/billing claim differs')
    for backend, seconds in (('GPU', 298.557943277061), ('NPU', 85.6662234030664)):
        c = cost['model_children'][backend]
        require(c['recorded_wall_seconds'] == seconds and c['status'] == 'completed' and type(c['returncode']) is int and
                c['returncode'] == 0 and c['native_forward_calls'] == 4 and c['loaded_models'] == c['native_model_processes'] == 1 and
                all(c[k] is None for k in ('uninstrumented_latency_seconds', 'active_device_seconds', 'allocated_instance_seconds', 'currency_cost')),
                'instrumented native-child accounting differs')
    for key, pin, seconds in (('cpu_numerical_admission', CONTROLLER_SHA, 240.48395719006658),
                              ('cpu_selected_E02', E02_CONTROLLER_SHA, 197.6121320873499)):
        require(cost[key]['controller_sha256'] == pin and cost[key]['recorded_wall_seconds'] == seconds and
                cost[key]['native_executions_started'] == 0, 'distinct CPU controller accounting differs')


def score_comparison(target, distribution, prototypes):
    a, b = target['sides']; t, d = target['metrics'], distribution['aggregate']; n = t['target_count']
    values = {'target-nll-abs-diff': t['nll_abs_diff_nat_per_token'], 'target-mae': t['mae_nat'],
              'target-p99': t['p99_nat'], 'target-max': t['max_abs_nat'], 'top1-agreements': d['top1_agreement']['count'],
              'top1-agreement-fraction': d['top1_agreement']['fraction'], 'top100-overlap-mean': d['top100_overlap']['mean']}
    families = (('tail_merged_js', 'tail-merged-js'), ('probability_rmse', 'union-probability-rmse'),
                ('max_probability_error', 'union-max-probability-error'))
    for field, prefix in families:
        for stat in ('mean', 'p99', 'max'):
            values[prefix + '-' + stat] = d[field][stat]
    for field in ('side_a_top100', 'side_b_top100', 'side_a_union', 'side_b_union'):
        for stat in ('mean', 'p1', 'min'):
            values[field.replace('_', '-') + '-' + stat] = d['coverage'][field][stat]
    rendered = []
    for prototype in prototypes:
        item = copy.deepcopy(prototype); key = item['id']; item['value'] = values[key]
        item.pop('coordinate', None); item.pop('side_values', None)
        if key.startswith(('side-a-', 'side-b-')):
            side = a if key.startswith('side-a-') else b
            item['label'] = side + ' ' + ('Top-100' if 'top100' in key else 'union') + ' probability mass ' + key.rsplit('-', 1)[1].upper()
        if key == 'target-nll-abs-diff':
            item['side_values'] = {a: t['side_a_nll_nat_per_token'], b: t['side_b_nll_nat_per_token']}
        if key == 'target-max':
            item['coordinate'] = {'anonymous_target_index_zero_based': t['max_target_index_zero_based']}
        for field, prefix in families:
            if key == prefix + '-max':
                item['coordinate'] = copy.deepcopy(d[field]['max_coordinate'])
        rendered.append(item)
    require(len(rendered) == len(values) == 28, 'all28 aggregate metrics required')
    return {'id': target['id'], 'title': ('GPU/NPU matched condition: ' if target['kind'] == 'cross_backend_matched' else 'Within-backend control: ') + a + ' vs ' + b,
            'side_ids': [a, b], 'kind': target['kind'],
            'scope': f"Request {target['request']}: {n} targets and47 selected distributions; one parent article and a derived prefix shape stress request.",
            'metrics': rendered, 'coverage': [{'label': label, 'observed': count, 'expected': count, 'unit': unit}
                for label, count, unit in (('Paired targets', n, 'targets'), ('Paired selected distributions', 47, 'positions'),
                                          ('Vocabulary per retained row', 262144, 'entries/row'), ('Independent parent inputs', 1, 'inputs'))]}


def build_entry(documents, pins, revision, previous):
    m, t = documents['selected-metrics.json'], documents['selected-targets.json']; sides = []
    libraries = (('torch', 'PyTorch'), ('transformers', 'Transformers'), ('numpy', 'NumPy'),
                 ('cuda_runtime', 'CUDA runtime'), ('torch_npu', 'TorchNPU'), ('cann', 'CANN'), ('driver', 'Driver package metadata'))
    for run in t['runs']:
        c = run['conditions']; mode = copy.deepcopy(c['execution_mode'])
        sides.append({'id': run['id'], 'label': ('H100' if run['backend'] == 'GPU' else 'Ascend') + ' / ' + run['mode'] + ' / request ' + run['request'],
            'hardware': c['hardware']['model'],
            'libraries': [{'name': label, 'version': c['software'][field]} for field, label in libraries if field in c['software']],
            'settings': {'dtype': 'BF16', 'native_logits_dtype': 'BF16', 'offline_logprob_dtype': 'FP64',
                'attention': c['numerics']['attention'], 'mode': 'eval/inference', 'seed': c['numerics']['seed'],
                'device_count': 1, 'visible_device_alias_count': 1 if run['backend'] == 'GPU' else 8,
                'parallelism': c['numerics']['parallelism'], **copy.deepcopy(c['backend_policy']),
                'execution': mode, 'batch_padding_repeatability_measured': False, 'fresh_process_repeatability_measured': False}})
    comparisons = [score_comparison(a, b, previous['comparisons'][0]['metrics'])
                   for a, b in zip(m['target_pairs'], m['distribution_pairs'])]
    require(len(sides) == 12 and len(comparisons) == 18, '12sides/18 comparisons required')
    coverage, e02 = documents['coverage.json'], documents['independent-checks.json']
    return {'id': ID, 'date': '2026-11-07', 'title': 'Gemma 4 12B: H100 vs Ascend batch and padding',
        'task': 'inference', 'status': 'partial', 'acceptance': None, 'thresholds': None, 'full_core_complete': False,
        'model': copy.deepcopy(previous['model']),
        'summary': 'One discovery article plus its96-token prefix shape stress: two unequal160/96-token requests, six logical observations per backend and18 request-preserving contrasts. Cache-off BF16 capture and selected independent E02 checks are complete at this scope; acceptance and the full plan remain open.',
        'common': ['Same pinned base checkpoint; BF16 parameters/native logits, FP64 exported log probabilities, eager attention, seed0 andTP1.',
            'One loaded model per backend performs four native calls: alone A, alone B, left-padded batch and right-padded batch. Six logical observations per backend remain separate.',
            'All1792 physical raw predictor rows are retained;1536 valid rows are finite-checked and256 pad-only rows are separately counted. Offline reconstruction checks1524 target scores and564 full-vocabulary rows.'],
        'differences': ['Hardware and backend software/math policies differ and are recorded separately from actual I04 conditions; no operator cause is established.',
            'A has160 tokens/159 targets; its derived prefix B has96 tokens/95 targets. Left padding offsets B by64; right padding uses offset0. Validity comes from lengths and offsets, preserving valid token ID0.',
            'Alone and batched execution share one loaded process. Batch/padding and fresh-process repeatability, scheduler behavior and cache modes are unmeasured.'],
        'sides': sides, 'comparisons': comparisons,
        'scope': copy.deepcopy(m['workload']) | {'target_only_replay_pairs': 18, 'public_replay_arrays_read': 0,
            'selected_E02_distribution_pair_rows': 283, 'selected_E02_matched_cross_backend_rows': 282,
            'native_KV_comparisons': 0, 'operator_cause_established': False},
        'plan_coverage': {k: copy.deepcopy(coverage[k]) for k in ('task_count', 'core_task_count', 'counts', 'full_core_complete', 'original_49_task_scope_complete')},
        'instrumented_execution_accounting': copy.deepcopy(documents['execution-cost.json']),
        'independent_checks': {k: copy.deepcopy(e02[k]) for k in ('status', 'source_controller_sha256', 'source_report_sha256',
            'original_I04_report_sha256', 'verifier_sha256', 'source_selection_sha256', 'scope', 'verification', 'all_native_array_hashes_checked')},
        'notes': ['The first six comparisons are matched GPU/NPU contrasts. Twelve within-backend controls follow. These18 pairs do not add independent quality examples.',
            'All metrics remain per request and pair; NLL and percentiles are never pooled across159/95 unequal target counts.',
            'Top100-union probability errors and exact-complement-merged JS retain their coarsened definitions, rather than full-vocabulary probability error or divergence.',
            'Public standard-library replay checks18 target reductions with0 array reads. Actual source-side E02 checks18 target pairs and283 selected distribution contrasts, including282 matched cross-backend rows and one additional reported extreme; it does not independently repeat all846 contrasts.',
            'All572 native files are freshly hashed in the source-side checks. These metadata exports contain0 native arrays; the separate complete GPU transfer contains286 array files. No native KV comparison is made.',
            'Instrumented child wall durations are accounting observations, without a speed ratio, synchronized latency/throughput, allocated lifetime or billed-cost conclusion. Nested intervals are not summed and cross-host clocks are not subtracted.',
            'Thresholds and acceptance are null. Evidence-reconstruction tolerances are not model-accuracy acceptance thresholds. Operator cause and the full49-task/28core plan remain unresolved.'],
        'evidence': [{'label': label, 'url': 'evidence/' + ID + '/' + name} for name, label in zip(FILES,
            ('Scoped batch/padding report', 'Original49task scoped coverage ledger', 'Twelve anonymous target vectors',
             'All18 target and sampled-distribution summaries', '18pair standard-library target replay',
             'Selected instrumented execution accounting', 'Selected independent scalar E02 checks'))],
        'archive': {'revision': revision, 'prefix': PREFIX, 'replay_cases': 18, 'file_sha256': pins}}


def append_history(history_raw, entry):
    previous = read(history_raw)
    require(len(previous['evaluations']) == 108 and all(v['id'] != ID for v in previous['evaluations']), 'exact108 prior records required')
    require((json.dumps(previous, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode() == history_raw,
            'current Unicode/indent2 history format differs')
    marker = b'\n  ]\n}\n'; require(history_raw.endswith(marker), 'history array trailer differs')
    prefix = history_raw[:-len(marker)]
    old = ('"updated_at": "' + previous['updated_at'] + '"').encode(); new = b'"updated_at": "2026-11-07"'
    require(prefix.count(old) == 1, 'unique top-level history date required'); updated = prefix.replace(old, new, 1)
    tail = '\n'.join('    ' + line for line in json.dumps(entry, ensure_ascii=False, indent=2, allow_nan=False).splitlines()).encode()
    raw = updated + b',\n' + tail + marker; current = read(raw)
    require(current['evaluations'][:-1] == previous['evaluations'] and len(current['evaluations']) == 109,
            'prior108 object preservation failed')
    require(raw.startswith(updated + b',\n') and
            (json.dumps(current, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode() == raw,
            'prior evaluation UTF8 prefix/current format changed')
    return raw, digest(prefix[prefix.index(b'  "evaluations": ['):])


def validate_candidate(repo, folder):
    """Run owning schema validator against a read-only overlay; copy no site tree."""
    source = repo / '.github/validate_history.py'
    module_spec = importlib.util.spec_from_file_location('owning_history_validator', source)
    module = importlib.util.module_from_spec(module_spec); module_spec.loader.exec_module(module)
    class Overlay:
        def __init__(self, relative=Path()): self.relative = relative
        def __truediv__(self, other): return Overlay(self.relative / other)
        def read_text(self, *args, **kwargs):
            path = folder / 'new-history.json' if self.relative.as_posix() == 'data/evaluations.json' else repo / 'site' / self.relative
            return path.read_text(*args, **kwargs)
        def resolve(self): return (repo / 'site' / self.relative).resolve()
    require(module.validate_evaluations(Overlay()) == 109 and module.validate(Overlay()) == 20,
            'owning history schema validation failed')


def render(repo, revision, output_root):
    repo = Path(repo).resolve(strict=True); output_root = Path(output_root)
    require(not output_root.is_symlink() and output_root.resolve(strict=True).is_relative_to(repo / CASE / 'transfer'),
            'private transfer output root required')
    history = repo / 'site/data/evaluations.json'; repairs = repo / 'site/data/repairs.json'
    history_raw, repairs_raw = history.read_bytes(), repairs.read_bytes()
    require(digest(history_raw) == HISTORY_SHA and digest(repairs_raw) == REPAIRS_SHA and len(read(repairs_raw)['repairs']) == 20,
            'published108/20 history pins changed')
    document = read(history_raw)
    require(len(document['evaluations']) == 108 and document['evaluations'][-1]['id'] == 'gemma4-h100-ascend-partitions-20261107',
            'known108th I03 stage missing')
    old = document['evaluations'][-1]; prior = repo / 'site/evidence' / old['id'] / 'coverage.json'
    require(digest(prior.read_bytes()) == old['archive']['file_sha256']['coverage.json'], 'prior49task inventory bytes changed')
    documents, pins = archive_files(repo, revision, history_raw, repairs_raw)
    validate_evidence(documents, read(prior.read_bytes())); entry = build_entry(documents, pins, revision, old)
    raw = json.dumps(entry, ensure_ascii=False, allow_nan=False)
    require(not re.search(r'/(?:home|data|tmp|mnt)/|[A-Z]:\\|app-[a-z0-9]{8}|[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', raw, re.I),
            'private identity/path in history candidate')
    candidate, prefix_sha = append_history(history_raw, entry)
    folder = output_root / ('compare-i04-history-render-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    folder.mkdir(mode=0o700); put(folder / 'candidate-entry.json', entry)
    with (folder / 'new-history.json').open('xb') as stream: stream.write(candidate)
    validate_candidate(repo, folder)
    require(history.read_bytes() == history_raw and repairs.read_bytes() == repairs_raw, 'published histories changed during rendering')
    for name, pin in pins.items():
        require(digest((repo / PREFIX / name).read_bytes()) == pin, 'published evidence changed during rendering')
    receipt = {'schema_version': 1, 'status': 'private_history_candidate_rendered', 'archive_revision': revision,
        'entry_id': ID, 'prior_evaluations': 108, 'candidate_evaluations': 109, 'repair_records_unchanged': 20,
        'prior_history_sha256': HISTORY_SHA, 'repairs_sha256': REPAIRS_SHA, 'preserved_prior_evaluation_prefix_sha256': prefix_sha,
        'comparisons': 18, 'target_distribution_comparisons': 18, 'native_final_KV_comparisons': 0,
        'primary_pair': entry['comparisons'][0]['side_ids'], 'candidate_entry_path': str(folder / 'candidate-entry.json'),
        'candidate_entry_sha256': digest((folder / 'candidate-entry.json').read_bytes()),
        'new_history_path': str(folder / 'new-history.json'), 'new_history_sha256': digest(candidate),
        'owning_validator_evaluations': 109, 'owning_validator_repairs': 20,
        'public_history_written': False, 'git_modified': False, 'acceptance': None, 'full_core_complete': False}
    put(folder / 'render-receipt.json', receipt)
    return receipt


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--archive-commit', required=True)
    parser.add_argument('--repo', type=Path, default=HERE.parents[4]); parser.add_argument('--output-root', type=Path)
    args = parser.parse_args()
    print(json.dumps(render(args.repo, args.archive_commit, args.output_root or args.repo / CASE / 'transfer'), indent=2))

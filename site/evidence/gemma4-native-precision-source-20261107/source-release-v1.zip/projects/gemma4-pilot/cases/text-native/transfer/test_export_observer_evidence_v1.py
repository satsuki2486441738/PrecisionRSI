"""Synthetic stdlib transport protocol fixtures, not native values/admission."""
import copy
import hashlib
import importlib.util
import json
import os
import subprocess
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent


def load(name,file):
    spec=importlib.util.spec_from_file_location(name,HERE/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


M=load('observer_transport_fixture','export_observer_evidence_v1.py')
RUNNER=load('observer_transport_runner_fixture','run_observer_metadata_export_v1.py')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


class Unready(unittest.TestCase):
    def test_unknown_profile_and_runner_remain_closed_without_actual_input(self):
        self.assertIsNone(M.ACTUAL_CAPTURE_PINS['NPU']);self.assertEqual(RUNNER.EXPORT_SHA,sha(HERE/'export_observer_evidence_v1.py'))
        for backend in ('GPU','NPU'):
            with patch.dict(M.ACTUAL_CAPTURE_PINS,{backend:None}),self.assertRaisesRegex(ValueError,'unready'):M.ready_profile(backend)

    def test_GPU_actual_terminal_pin_profile_matches_original_local_receipt_bytes(self):
        folder=HERE/'observer-gpu-terminal-local-20261106T223548Z'
        receipt=M.read(folder/'local-validation-receipt.json');self.assertEqual(sha(folder/'local-validation-receipt.json'),'4450753848c83ebf49c7cfc3f2fe352fa441147f2333a5fcfa449e0eefcb5c3e')
        for name,ref in receipt['refs'].items():self.assertEqual(sha(folder/name),ref['sha256'])
        p=M.ready_profile('GPU');outer=M.read(folder/'capture-receipt.json');controller=M.read(folder/'controller-receipt.json')
        self.assertEqual(p['outer_sha256'],sha(folder/'capture-receipt.json'));self.assertEqual(p['controller_sha256'],sha(folder/'controller-receipt.json'))
        self.assertEqual(p['artifacts_manifest_sha256'],outer['artifacts_manifest_sha256']);self.assertEqual(p['launcher_sha256'],outer['source_sha256'][p['launcher_path']])
        self.assertEqual(controller['remaining_descendants'],[]);self.assertEqual(controller['returncode'],0)


@unittest.skipUnless(os.name=='posix','Actual original POSIX source-map identities')
class Evidence(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='observer-transport-CPU-fixture-');self.addCleanup(self.temp.cleanup)
        self.base=Path(self.temp.name).resolve();self.root=self.base/'synthetic-observer-task';self.root.mkdir()
        self.claim=self.root/'claims/synthetic-CPU-protocol';self.claim.mkdir(parents=True)
        self.run=self.root/'runs/h100-observer-synthetic';self.artifacts=self.run/'artifacts';self.artifacts.mkdir(parents=True)
        (self.root/'exports').mkdir();source=self.root/'source';source.mkdir()
        self.entry=source/'observer_native_v2.py';self.entry.write_bytes(b'# Synthetic CPU protocol source, never executed\n')
        self.launcher=source/'synthetic-lifecycle.py';self.launcher.write_bytes(b'# Synthetic lifecycle metadata source only\n')
        self.input=source/'input.json';self.input.write_bytes(b'{"synthetic_CPU_protocol_only":true}\n')
        self.stage=source/'stage.json';M.put(self.stage,{'native_task_roots':{'GPU':str(self.root),'NPU':str(self.root)},'status':'synthetic protocol fixture'})
        self.expected=self.claim/'expected-inventory.json';self.expected.write_bytes(b'{"synthetic_transport_only":true}\n')
        self.proof=self.claim/'i04-prerequisite.json';self.proof.write_bytes(b'Synthetic proof bytes, not scientific admission\n')
        self.cpu=self.claim/'cpu-prerequisite.json';self.cpu.write_bytes(b'Synthetic CPU protocol proof, not actual test execution\n')
        self.allocation=self.claim/'allocation.json';M.put(self.allocation,{'synthetic_CPU_fixture':True,'actual_allocation':False})
        self.deployment=self.root/'source-manifest.json';M.put(self.deployment,{'synthetic':True})
        for key,p in [('STAGE_SHA',self.stage),('EXPECTED_SHA',self.expected),('INPUT_SHA',self.input),('PROOF_SHA',self.proof),('CPU_PROOF_SHA',self.cpu)]:
            q=patch.object(M,key,sha(p));q.start();self.addCleanup(q.stop)
        self.original=self.base/'retired-GPU-tmp/module.py';self.original.parent.mkdir();self.original.write_bytes(b'# Original GPU temporary source bytes\n')
        self.frozen=self.claim/'frozen-runtime/000/module.py';self.frozen.parent.mkdir(parents=True);self.frozen.write_bytes(self.original.read_bytes())
        self.module_ref={'path':str(self.original),'sha256':sha(self.original),'size_bytes':self.original.stat().st_size}
        self.runtime_map=self.claim/'frozen-runtime-source-map.json';M.put(self.runtime_map,{str(self.original):{'path':str(self.frozen),**{k:self.module_ref[k] for k in ('sha256','size_bytes')}}})
        self.runtime={'package_sources':{'synthetic_module':self.module_ref},'implementation_sources':{'synthetic_module':self.module_ref},
            'scope':'Synthetic transport fixture. No native values, model, math, framework or numerical admission.'}
        M.put(self.artifacts/'runtime.json',self.runtime);(self.artifacts/'input.json').write_bytes(self.input.read_bytes())
        for name in M.LARGE_NAMES:
            p=self.artifacts/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(('opaque synthetic byte fixture '+name).encode())
        for i in range(452-len([p for p in self.artifacts.rglob('*') if p.is_file()])):
            (self.artifacts/('synthetic-small-%03d.json'%i)).write_bytes(b'{"synthetic":true}\n')
        self.manifest={'schema_version':1,'kind':'observer-capture-artifacts','task':'gemma4-observer-transparency-v1','backend':'gpu',
            'capture_schema_version':2,'stage_spec_sha256':M.STAGE_SHA,'expected_inventory_sha256':M.EXPECTED_SHA,
            'i04_prerequisite_sha256':M.PROOF_SHA,'cpu_prerequisite_sha256':M.CPU_PROOF_SHA,
            'files':{p.relative_to(self.artifacts).as_posix():{'sha256':sha(p),'size_bytes':p.stat().st_size} for p in self.artifacts.rglob('*') if p.is_file()}}
        M.put(self.artifacts/'artifacts-manifest.json',self.manifest)
        M.put(self.artifacts/'status.json',{'status':'completed','artifacts_manifest_sha256':sha(self.artifacts/'artifacts-manifest.json'),'synthetic':True})
        argv=['synthetic-never-executed','--backend','gpu','--input',str(self.input),'--allocation-receipt',str(self.allocation),
            '--stage-spec',str(self.stage),'--stage-spec-sha256',M.STAGE_SHA,'--expected-inventory',str(self.expected),'--expected-inventory-sha256',M.EXPECTED_SHA,
            '--i04-prerequisite',str(self.proof),'--i04-prerequisite-sha256',M.PROOF_SHA,'--cpu-prerequisite',str(self.cpu),'--cpu-prerequisite-sha256',M.CPU_PROOF_SHA,'--output',str(self.artifacts)]
        M.put(self.run/'command.json',{'status':'completed','returncode':0,'argv':argv,'start':'synthetic','timeout':1200})
        for name in ('stdout.bin','stderr.bin','execution.json'):(self.run/name).write_bytes(b'Original synthetic generic protocol bytes\n')
        sources={str(p):sha(p) for p in (self.entry,self.launcher,self.input,self.stage,self.expected,self.proof,self.cpu,self.allocation,self.original,self.deployment)}
        self.outer={'schema_version':1,'task':'OBSERVER','task_id':M.TASK_ID,'backend':'GPU','status':'completed','returncode':0,'timed_out':False,
            'capture_schema_version':2,'native_capture_count':1,'native_forward_calls_total':4,'model_loads':1,'started_utc':'synthetic','argv':argv,'output_dir':str(self.artifacts),
            'collector_path':str(self.entry),'collector_sha256':sha(self.entry),'input_path':str(self.input),'input_sha256':M.INPUT_SHA,
            'allocation_path':str(self.allocation),'allocation_sha256':sha(self.allocation),'stage_spec_source_path':str(self.stage),'stage_spec_source_sha256':M.STAGE_SHA,
            'expected_inventory_source_path':str(self.expected),'expected_inventory_source_sha256':M.EXPECTED_SHA,
            'i04_prerequisite_source_path':str(self.proof),'i04_prerequisite_source_sha256':M.PROOF_SHA,'cpu_prerequisite_source_path':str(self.cpu),'cpu_prerequisite_source_sha256':M.CPU_PROOF_SHA,
            'generic_receipt':{'path':str(self.run/'command.json'),'sha256':sha(self.run/'command.json')},
            'runtime_source_map_path':str(self.runtime_map),'runtime_source_map_sha256':sha(self.runtime_map),'source_sha256':sources,'dependency_paths':list(sources),
            'artifacts_manifest_sha256':sha(self.artifacts/'artifacts-manifest.json'),'synthetic':True}
        self.outer_path=self.claim/'capture-receipt.json';self.original.unlink()
        M.put(self.claim/'claim.json',{'whole_attempt_seconds':3600,'entry_started_utc':'2026-11-07T00:00:00+00:00'})
        M.put(self.claim/'controller-receipt.json',{'task':'OBSERVER','status':'completed','returncode':0,'timed_out':False,'remaining_descendants':[],
            'wall_seconds':10.0,'finished_utc':'2026-11-07T00:00:10+00:00','metadata_export_reserved_seconds':960,'controller_work_seconds':2620})

    def replace(self,p,d):
        if p.exists():p.unlink()
        M.put(p,d)

    def seal(self):
        self.replace(self.outer_path,self.outer)
        return {'outer_sha256':sha(self.outer_path),'controller_sha256':sha(self.claim/'controller-receipt.json'),
            'artifacts_manifest_sha256':sha(self.artifacts/'artifacts-manifest.json'),'source_manifest_path':str(self.deployment),'source_manifest_sha256':sha(self.deployment),
            'launcher_path':str(self.launcher),'launcher_sha256':sha(self.launcher),'collector_sha256':sha(self.entry)}

    def invoke(self,name='export',retain=False):
        profile=self.seal();output=self.root/'exports'/name
        with patch.dict(M.ACTUAL_CAPTURE_PINS,{self.outer['backend']:profile}):r=M.export(self.outer_path,self.root,output,retain)
        return output,r

    def test_unready_actual_profile_precedes_any_native_array_stat_or_read(self):
        self.seal();real_stat=Path.stat;real_open=Path.open
        def stat(p,*a,**kw):
            if str(p).endswith(('.npy','.safetensors')):raise AssertionError('native array stat while actual pins unready')
            return real_stat(p,*a,**kw)
        def opening(p,*a,**kw):
            if str(p).endswith(('.npy','.safetensors')):raise AssertionError('native array open while actual pins unready')
            return real_open(p,*a,**kw)
        with patch.dict(M.ACTUAL_CAPTURE_PINS,{'GPU':None}),patch.object(Path,'stat',stat),patch.object(Path,'open',opening),self.assertRaisesRegex(ValueError,'unready'):
            M.export(self.outer_path,self.root,self.root/'exports/unready')
        self.assertFalse((self.root/'exports/unready').exists())

    def test_GPU_full194_files_and_original_TMP_alias_survive_losslessly(self):
        out,r=self.invoke();mapping=M.read(out/'source-map.json');self.assertEqual(mapping['full_array_hashes_checked'],194);self.assertEqual(mapping['retained_array_count'],0)
        self.assertTrue(all('path' in v for v in mapping['files'].values()))
        for p in (self.outer_path,self.run/'command.json',self.runtime_map):self.assertEqual((out/mapping['files'][str(p)]['path']).read_bytes(),p.read_bytes())
        self.assertEqual((out/mapping['files'][str(self.original)]['path']).read_bytes(),self.frozen.read_bytes());self.assertEqual(sha(r['archive']),r['archive_sha256'])
        with tarfile.open(r['archive']) as package:self.assertTrue(all(p.isfile() and not p.name.startswith('/') and '..' not in Path(p.name).parts for p in package))

    def test_NPU_retains194_sources_with_hashes_without_payload_arrays(self):
        self.outer['backend']='NPU';self.outer['argv'][self.outer['argv'].index('--backend')+1]='npu';self.manifest['backend']='npu'
        p=self.artifacts/'driver-provenance.json';p.write_bytes(b'{"synthetic_driver":true}\n');self.manifest['files'][p.name]={'sha256':sha(p),'size_bytes':p.stat().st_size}
        self.replace(self.artifacts/'artifacts-manifest.json',self.manifest);self.outer['artifacts_manifest_sha256']=sha(self.artifacts/'artifacts-manifest.json')
        self.replace(self.artifacts/'status.json',{'status':'completed','artifacts_manifest_sha256':self.outer['artifacts_manifest_sha256']})
        command=M.read(self.run/'command.json');command['argv']=self.outer['argv'];command['timeout']=1500;self.replace(self.run/'command.json',command)
        self.outer['generic_receipt']['sha256']=sha(self.run/'command.json');out,r=self.invoke(retain=True)
        mapping=M.read(out/'source-map.json');retained={k:v for k,v in mapping['files'].items() if v.get('retained_at_source')}
        self.assertEqual(len(retained),194);self.assertTrue(all('path' not in v and v['sha256']==sha(k) for k,v in retained.items()))
        self.assertEqual(len(list(out.rglob('*.npy')))+len(list(out.rglob('*.safetensors'))),0)

    def test_GPU_retain_and_unrelated_old_array_are_rejected(self):
        with self.assertRaisesRegex(ValueError,'GPU copies'):self.invoke(retain=True)
        (self.artifacts/'old-unrelated.npy').write_bytes(b'old')
        with self.assertRaisesRegex(ValueError,'inventory'):self.invoke('bad-array')

    def test_native_metadata_or_frozen_runtime_byte_tamper_is_rejected(self):
        self.frozen.write_bytes(b'mutated source')
        with self.assertRaises(ValueError):self.invoke()
        self.assertFalse(any((self.root/'exports').glob('*.tar.gz')))

    def test_approved_namespace_override_is_retained_without_rewriting_stage(self):
        stage=M.read(self.stage);stage['native_task_roots']['GPU']=str(self.root)+'-declared-v1';self.replace(self.stage,stage)
        with patch.object(M,'STAGE_SHA',sha(self.stage)):
            self.outer['stage_spec_source_sha256']=M.STAGE_SHA;self.outer['argv'][self.outer['argv'].index('--stage-spec-sha256')+1]=M.STAGE_SHA
            command=M.read(self.run/'command.json');command['argv']=self.outer['argv'];self.replace(self.run/'command.json',command);self.outer['generic_receipt']['sha256']=sha(self.run/'command.json')
            self.manifest['stage_spec_sha256']=M.STAGE_SHA;self.replace(self.artifacts/'artifacts-manifest.json',self.manifest)
            self.outer['artifacts_manifest_sha256']=sha(self.artifacts/'artifacts-manifest.json');self.replace(self.artifacts/'status.json',{'status':'completed','artifacts_manifest_sha256':self.outer['artifacts_manifest_sha256']})
            override={'frozen_stage_spec_sha256':M.STAGE_SHA,'independent_expected_inventory_sha256':M.EXPECTED_SHA,'frozen_stage_declared_GPU_root':stage['native_task_roots']['GPU'],
                'approved_GPU_root':str(self.root),'lifecycle_sha256':sha(self.launcher),'literal_stage_root_agreement_claimed':False,'numeric_geometry_changed':False}
            self.replace(self.deployment,{'deployment_namespace_override':override});self.outer['deployment_namespace_override']=override
            self.outer['source_sha256'][str(self.stage)]=sha(self.stage);self.outer['source_sha256'][str(self.deployment)]=sha(self.deployment)
            out,r=self.invoke();self.assertEqual(M.read(out/'source-map.json')['deployment_namespace_override'],override)
            copied=M.read(out/'source-map.json')['files'][str(self.stage)]['path'];self.assertEqual((out/copied).read_bytes(),self.stage.read_bytes())

    def test_unplanned_runtime_array_ref_is_rejected_before_its_stat(self):
        unknown=self.base/'unplanned-tiny.safetensors';self.runtime['bad']={'path':str(unknown),'sha256':'a'*64,'size_bytes':224}
        self.replace(self.artifacts/'runtime.json',self.runtime);self.manifest['files']['runtime.json']={'sha256':sha(self.artifacts/'runtime.json'),'size_bytes':(self.artifacts/'runtime.json').stat().st_size}
        self.replace(self.artifacts/'artifacts-manifest.json',self.manifest);self.outer['artifacts_manifest_sha256']=sha(self.artifacts/'artifacts-manifest.json');self.replace(self.artifacts/'status.json',{'status':'completed','artifacts_manifest_sha256':self.outer['artifacts_manifest_sha256']})
        original=Path.stat
        def stat(p,*a,**kw):
            if p==unknown:raise AssertionError('unplanned tiny ref was statted')
            return original(p,*a,**kw)
        with patch.object(Path,'stat',stat),self.assertRaisesRegex(ValueError,'before filesystem IO'):self.invoke()

    def test_native_duration_must_reserve_full960_seconds(self):
        controller=M.read(self.claim/'controller-receipt.json');controller['finished_utc']='2026-11-07T00:45:00+00:00';self.replace(self.claim/'controller-receipt.json',controller)
        with self.assertRaisesRegex(ValueError,'insufficient960s'):self.invoke()

    def test_raw_native_byte_corruption_does_not_become_transport_success(self):
        next(self.artifacts.glob('modes/*/raw-native-logits.safetensors')).write_bytes(b'corrupt synthetic raw bytes')
        with self.assertRaisesRegex(ValueError,'SHA differs'):self.invoke()

    def test_original_array_changed_after_archive_is_not_hidden_by_good_copy(self):
        target=next(self.artifacts.glob('modes/*/raw-native-logits.safetensors'));real_close=tarfile.TarFile.close;changed=[]
        def close(package):
            result=real_close(package)
            if package.mode=='w' and not changed:
                target.write_bytes(b'late source mutation after a good copied payload');changed.append(True)
            return result
        with patch.object(tarfile.TarFile,'close',close),self.assertRaisesRegex(ValueError,'source changed after payload/archive'):
            self.invoke()
        self.assertTrue(changed);self.assertTrue((self.root/'exports/export-failure.json').is_file())


@unittest.skipUnless(os.name=='posix','Real CPU generic child ownership protocol')
class RunnerProtocol(unittest.TestCase):
    def prepare(self,mode):
        temp=tempfile.TemporaryDirectory(prefix='observer-transport-runner-CPU-');self.addCleanup(temp.cleanup);root=Path(temp.name).resolve()
        tools=root/'tools';tools.mkdir();claim=root/'claims/synthetic';claim.mkdir(parents=True)
        controller={'task':'OBSERVER','status':'completed','returncode':0,'timed_out':False,'remaining_descendants':[]}
        M.put(claim/'controller-receipt.json',controller);M.put(claim/'claim.json',{'synthetic_CPU_protocol_only':True})
        outer={'task':'OBSERVER','backend':'GPU','status':'completed','returncode':0,'timed_out':False,'capture_schema_version':2,
            'native_capture_count':1,'native_forward_calls_total':4,'model_loads':1,'artifacts_manifest_sha256':'a'*64,'collector_sha256':'b'*64}
        p=claim/'capture-receipt.json';M.put(p,outer)
        profile={'outer_sha256':sha(p),'controller_sha256':sha(claim/'controller-receipt.json'),'artifacts_manifest_sha256':'a'*64,'collector_sha256':'b'*64}
        text="""from pathlib import Path
import argparse,hashlib,json,time,sys
MAX_TRANSPORT=1610612736
MAX_LOGICAL=1073741824
WHOLE_SECONDS=3600
PROFILE=__PROFILE__
def ready_profile(backend):return PROFILE
def native_attempt_seconds(*args):return 10
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--outer-receipt');p.add_argument('--task-root');p.add_argument('--output');p.add_argument('--retain-arrays',action='store_true');a=p.parse_args()
 if __MODE__=='failure':print('synthetic CPU protocol child7');sys.exit(7)
 if __MODE__=='timeout':time.sleep(60)
 output=Path(a.output);output.mkdir();archive=output.with_name(output.name+'.tar.gz');archive.write_bytes(b'synthetic transport protocol bytes, not native evidence')
 result={'status':'observer_transport_export_completed','native_executions_started':0,'retained_array_count':0,'model_acceptance':None,'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'logical_payload_bytes':53,'transport_allowed_by_actual_size':True,'source_map_sha256':'c'*64}
 output.with_name(output.name+'-receipt.json').write_text(json.dumps(result));print(json.dumps(result))
""".replace('__PROFILE__',repr(profile)).replace('__MODE__',repr(mode))
        producer=tools/'export_observer_evidence_v1.py';producer.write_text(text)
        script=tools/'run_observer_metadata_export_v1.py';script.write_bytes((HERE/script.name).read_bytes())
        (tools/'record_run.py').write_bytes((HERE.parents[4]/'skills/precision-compare/scripts/record_run.py').read_bytes())
        spec=importlib.util.spec_from_file_location('observer_synthetic_runner_'+root.name,script);runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
        runner.EXPORT_SHA=sha(producer);return root,p,runner

    def test_recorded_success_permanent_export_marker_and_source_refs(self):
        root,outer,r=self.prepare('success');self.assertEqual(r.run(root,outer,'GPU'),0)
        path=next((root/'runs').glob('*/controller-receipt.json'));doc=M.read(path)
        self.assertEqual(doc['status'],'completed');self.assertEqual(doc['cumulative_native_and_reserved_export_seconds'],970)
        self.assertTrue(Path(doc['generic_receipt']['path']).is_file());self.assertFalse(doc['source_arrays_retained'])
        with self.assertRaises(FileExistsError):r.run(root,outer,'GPU')

    def test_child7_retains_failed_controller_and_raw_generic_logs(self):
        root,outer,r=self.prepare('failure');self.assertEqual(r.run(root,outer,'GPU'),2)
        doc=M.read(next((root/'runs').glob('*/controller-receipt.json')));self.assertEqual(doc['child_returncode'],7);self.assertEqual(doc['status'],'failed')
        self.assertIn(b'synthetic CPU protocol child7',(Path(doc['generic_receipt']['path']).parent/'stdout.bin').read_bytes())

    def test_timeout_preserves_failure_and_reaps_actual_CPU_child(self):
        root,outer,r=self.prepare('timeout');r.TOTAL=10;r.GENERIC=1;r.CLEANUP=2
        self.assertEqual(r.run(root,outer,'GPU'),2);doc=M.read(next((root/'runs').glob('*/controller-receipt.json')))
        self.assertEqual(doc['status'],'failed');self.assertTrue(doc['timed_out'])
        command=M.read(doc['generic_receipt']['path'])
        with self.assertRaises(ProcessLookupError):os.kill(command['child_pid'],0)


if __name__=='__main__':unittest.main()

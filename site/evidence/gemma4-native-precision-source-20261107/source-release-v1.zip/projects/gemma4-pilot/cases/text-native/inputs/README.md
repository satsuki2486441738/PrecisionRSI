# WikiText discovery pilot: frozen inputs

These inputs are CPU-prepared discovery examples, not GPU measurements or a
representative validation set. The 2026-11-05 preparation produced four
128-token and four 512-token prompts (lengths include BOS), each with 32 fixed
continuation IDs. No eligible 2048-token single row was found: that bin is
**0/4 and uncovered**. The input selection is restricted to English encyclopedia
prose; multilingual, code, mathematics and long-context coverage remain open.
Synthetic stress inputs are distinct and do not count toward representative
corpus coverage.

- Data: `Salesforce/wikitext`, revision
  `b08601e04326c79dfdd32d625aee71d232d685c3`, `wikitext-2-raw-v1` train
  parquet, SHA-256 `e83889baabc497075506f91975be5fac0d45c5290b6b20582c8cd1e853d0c9f7`.
  The [dataset card](https://huggingface.co/datasets/Salesforce/wikitext) describes
  Wikipedia Good/Featured-article content and CC BY-SA 4.0 licensing. Preserve
  source attribution and assess license obligations before redistribution.
- Tokenizer: `google/gemma-4-12B` revision
  `1a2c7729392586f5ecddae8807ee2ef741eabb9a`, `tokenizer.json`, SHA-256
  `42cacba08980fc39bfe2c73cb8c4486b9d00f2f2671072c6cb9c45ee2c5cfaae`.
  The `tokenizers` library loads this JSON directly, with automatic special tokens
  disabled; BOS ID 2 is manually prefixed and no EOS or padding is added. This
  explicit tokenization policy is not a claim that it matches every Transformers
  default preprocessing path.
- Data and tokenizer hashes were checked against the respective fixed upstream
  revision's blob metadata. The exact source files remain private in `source/`.
  `discovery-v1/discovery.json` retains source row numbers, normalized-content and
  source-text hashes, original token count, selected span, policies and per-file
  hashes. Its SHA-256 is
  `589d0f677be94597903cb8e7bb5a3b78b6d61a66ad1f76ef443f204f63319525`.
- Selection collapses whitespace and case-folds for deduplication, retains the
  earliest duplicate row, ranks by a fixed seed and content hash, and assigns the
  largest unmet eligible length bin first. It uses deterministic prefixes and does
  not substitute shorter samples for a claimed bin. Exact source text is retained
  in the pinned train parquet; selected token span is recorded separately.
- Use the **same frozen JSON bytes** for both GPU peers. The training split is
  discovery only. Before validation, freeze an independent source/partition and
  exclude discovery source IDs and normalized-content hashes; source partitioning
  alone does not prove document-level disjointness. Never tune selection or a
  candidate on validation data and then claim the same data are held out.

## Reproduce

Use Python 3.12, `tokenizers==0.22.1` and `pyarrow==22.0.0` in a private CPU
maintenance environment; the complete installed package versions are recorded in
`cpu-requirements-lock.txt`. From the repository root, with verified source files:

```sh
python projects/gemma4-pilot/cases/text-native/adapters/select_discovery.py \
  --source projects/gemma4-pilot/cases/text-native/inputs/source/wikitext2-train.parquet \
  --tokenizer projects/gemma4-pilot/cases/text-native/inputs/source/gemma4-tokenizer.json \
  --output NEW_EMPTY_PARENT/new-discovery-directory
```

The output directory must not exist. Selection refuses nonmatching source hashes.
Regeneration in a temporary directory produced nine byte-identical files (eight
inputs plus the manifest). Three unit tests check deterministic deduplication,
length assignment, special-token handling and invalid IDs. No model or GPU was run.

"""Independently freeze I01 coordinates before any cache-off native capture.

The 160 existing fixed tokens give 159 causal targets. The last native logit row
has no supplied next token. Sixteen prespecified conditioning predictors and 32
continuation predictors overlap once, yielding 47 distinct full-vocabulary rows.
No framework, model, device, weights, scores or measured result is accessed.
"""
import argparse
import hashlib
import json
from pathlib import Path

INPUT_SHA256='643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
VOCABULARY=262144
TASK='gemma4-i01-cache-off-anchor-v1'
NORMALIZATION='Offline NumPy float64 log_softmax of copied native values'
STAGE_SHA256='5aa7d50bb472aab82108ad6711fdd6c5bdd4780bbecb27cdf78c734d13093c05'
STAGE_ID='gemma4-gpu-npu-i01-cacheoff-v1-20261106'


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)


def load(path):
    def pairs(items):
        result={}
        for key,value in items:
            require(key not in result,'duplicate JSON key');result[key]=value
        return result
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    result=json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)
    canonical(result);return result


def derive(document,input_sha256,stage_spec_sha256):
    require(input_sha256==INPUT_SHA256,'I01 must use the original frozen discovery input bytes')
    require(stage_spec_sha256==STAGE_SHA256,'I01 must bind the original finite prepared stage specification')
    require(isinstance(document,dict) and isinstance(document.get('sample'),str) and document['sample'],'input sample ID required')
    conditioning,continuation=(document.get(key) for key in ('prompt','continuation'))
    require(isinstance(conditioning,list) and len(conditioning)==128 and isinstance(continuation,list) and len(continuation)==32,
        'exact 128 conditioning plus 32 continuation tokens required; no truncation')
    sequence=conditioning+continuation
    require(all(type(token) is int and 0<=token<VOCABULARY for token in sequence),'nonnegative in-vocabulary integer token IDs required')
    grid=[i*127//15 for i in range(16)]
    continuation_predictors=list(range(127,159))
    selected=sorted(set(grid)|set(continuation_predictors))
    require(len(grid)==16 and len(continuation_predictors)==32 and set(grid)&set(continuation_predictors)=={127} and len(selected)==47,
        'independent fixed coordinate derivation failed')
    targets=[{'sample':document['sample'],'position':position,'token':sequence[position]} for position in range(1,160)]
    distributions=[{'sample':document['sample'],'position':position,'history':sequence[:position+1]} for position in selected]
    return {'schema_version':1,'task':TASK,'stage_id':STAGE_ID,'stage_spec_sha256':stage_spec_sha256,
        'input_sha256':input_sha256,'sequence_length':160,
        'conditioning_length':128,'continuation_length':32,'vocabulary_size':VOCABULARY,
        'native_forward':{'invocations':1,'batch_size':1,'use_cache':False,'attention':'eager','parameter_dtype':'bfloat16'},
        'raw_logits':{'tensor_name':'logits','dtype':'BF16','shape':[1,160,VOCABULARY],'data_bytes':160*VOCABULARY*2,
            'unscored_prediction_indices':[159]},
        'all_targets':targets,'distribution_positions':distributions,
        'cached_overlap_targets':[row for row in targets if row['position']>=128],
        'sampling':{'conditioning_predictors':grid,'continuation_predictors':continuation_predictors,
            'deduplicated_predictors':selected,'intersection_predictors':[127],
            'rule':'conditioning floor(i*127/15), i=0..15; continuation 127..158; sorted set union'},
        'normalization':NORMALIZATION,'thresholds':None,'acceptance':None,
        'scope':'one fixed 160-token cache-off anchor; 159 targets and 47 prespecified distribution positions'}


def check_stage(stage_spec,expected_sha256):
    require(expected_sha256==STAGE_SHA256 and sha(stage_spec)==expected_sha256,'stage specification source SHA differs')
    stage=load(stage_spec)
    require(stage.get('stage_id')==STAGE_ID and stage.get('status')=='prepared_not_executed' and
        stage.get('thresholds') is None and stage.get('acceptance') is None and stage.get('full_core_complete') is False,
        'stage source is not the unchanged prepared finite-bound specification')
    return stage


def verify(expected,input_path,stage_spec):
    check_stage(stage_spec,STAGE_SHA256)
    result=derive(load(input_path),sha(input_path),STAGE_SHA256)
    require(canonical(load(expected))==canonical(result),'frozen expected inventory differs from independent input-derived inventory')
    return result


def build(input_path,output,stage_spec,stage_spec_sha256):
    stage=check_stage(stage_spec,stage_spec_sha256)
    document=derive(load(input_path),sha(input_path),stage_spec_sha256);output=Path(output)
    require(stage['selected_prediction_positions']==document['sampling']['deduplicated_predictors'] and
        stage['semantics']['valid_targets']==len(document['all_targets']) and
        stage['semantics']['expected_logits_shape']==document['raw_logits']['shape'],
        'stage semantics differ from independently derived coordinates')
    require(not output.exists() and output.parent.is_dir(),'new expected-inventory output required')
    with output.open('x',encoding='utf-8',newline='\n') as stream:json.dump(document,stream,indent=2,allow_nan=False);stream.write('\n')
    return {'status':'expected_inventory_frozen','task':TASK,'output':str(output.resolve()),'sha256':sha(output),
        'causal_targets':159,'distinct_distribution_positions':47,'raw_logit_data_bytes':160*VOCABULARY*2,
        'native_executions_started':0,'acceptance':None}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--stage-spec',required=True,type=Path)
    parser.add_argument('--stage-spec-sha256',required=True)
    args=parser.parse_args()
    try:result=build(args.input,args.output,args.stage_spec,args.stage_spec_sha256)
    except (OSError,ValueError,KeyError,TypeError) as exc:parser.exit(2,type(exc).__name__+': '+str(exc)+'\n')
    print(json.dumps(result,allow_nan=False))


if __name__=='__main__':main()

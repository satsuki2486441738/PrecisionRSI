"""Actual metadata and synthetic control regressions; no Torch/native work."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from contextlib import ExitStack
from unittest.mock import patch

import observer_common_v2 as common
import observer_prerequisite_v1 as proof

CASE=Path(__file__).resolve().parents[1]
I04=CASE/'transfer/i04-main-local-20261107T212400Z/observer-proof/prerequisite.json'
CPU=CASE/'transfer/observer-cpu-proof-local-20261106T213255Z/payload/prerequisite.json'


def copy_proof(source,target,cpu=False):
    target=Path(target);target.mkdir();doc=common.read(source)
    refs=list(doc['files'].values()) if cpu else [doc[k] for k in ('controller','report','comparison_spec','analysis_source','artifact_helper_source','tool_manifest')]+list(doc['source_maps'].values())
    (target/'prerequisite.json').write_bytes(Path(source).read_bytes())
    for item in refs:
        path=target/item['path'];path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((Path(source).parent/item['path']).read_bytes())
    return target/'prerequisite.json'


def synthetic_rng():
    return {'python':{'sha256':'a'*64},'numpy':{'sha256':'b'*64,'header':{'algorithm':'MT19937','word_count':624,'word_encoding':'uint32-little-endian',
        'position':624,'has_gauss':0,'cached_gaussian_binary64_le_hex':'0000000000000000'}},'torch_cpu':{'sha256':'c'*64},'device0':{'sha256':'d'*64}}


class ActualProof(unittest.TestCase):
    def test_actual_I04_eight_and_CPU24_originals_dual_closure_without_arrays(self):
        old_open=Path.open;old_stat=Path.stat
        def guard(method):
            def checked(path,*a,**k):
                if str(path).lower().endswith(('.npy','.safetensors')):raise AssertionError('native/tiny tensor payload must not be accessed by proof checker')
                return method(path,*a,**k)
            return checked
        with patch.object(Path,'open',guard(old_open)),patch.object(Path,'stat',guard(old_stat)):
            checked=proof.prerequisite(I04,proof.I04_PROOF_SHA256,CPU,proof.CPU_PROOF_SHA256)
        self.assertEqual(len(checked['proofs']['i04']['refs']),8);self.assertEqual(len(checked['proofs']['cpu']['refs']),24)
        self.assertEqual(len(checked['refs']),35);self.assertEqual(checked['native_executions_started'],0)

    def test_preparation_missing_pin_unready_before_file_or_framework(self):
        for name in ('STAGE_SHA256','EXPECTED_SHA256','PREREQUISITE_SOURCE_SHA256','I04_PREREQUISITE_SHA256','CPU_PREREQUISITE_SHA256'):
            self.assertTrue(common.HEX.fullmatch(getattr(common,name)))
            with patch.object(common,name,None),patch.object(common,'sha',side_effect=AssertionError('unready must fail before source/model access')):
                with self.assertRaisesRegex(ValueError,'unready'):common.prepare(SimpleNamespace(),__file__)
        self.assertNotIn('torch',sys.modules);self.assertNotIn('torch_npu',sys.modules)

    def test_explicit_cpu_cli_and_mutual_native_common_collector_pairing(self):
        with patch.object(sys,'argv',['native','--backend','npu','--model','m','--input','i','--allocation-receipt','a','--stage-spec','s',
            '--expected-inventory','e','--i04-prerequisite','p','--cpu-prerequisite','c','--output','o','--stage-spec-sha256','x',
            '--expected-inventory-sha256','x','--i04-prerequisite-sha256','x','--cpu-prerequisite-sha256','x','--device','npu:0']):args=common.arguments()
        self.assertEqual(args.cpu_prerequisite,Path('c'));self.assertEqual(args.cpu_prerequisite_sha256,'x')
        native=ast.parse((CASE/'adapters/observer_native_v2.py').read_text('utf8'))
        self.assertTrue(any(isinstance(n,ast.Import) and any(a.name=='observer_common_v2' and a.asname=='common' for a in n.names) for n in native.body))
        self.assertEqual(common.PINNED['projects/gemma4-pilot/cases/text-native/adapters/observer_collectors_v1.py'],'774b5cb210f294a23d6865f863d5facdf537c3ed3064ae39027425797b83101c')

    def test_original_v1_bytes_and_native_math_functions_preserved(self):
        first=CASE/'adapters/observer_common_v1.py';native=CASE/'adapters/observer_native_v1.py'
        self.assertEqual(common.sha(first),'d58aae77138a9076b426193d45011cee375b04bc3d6528c985d884c8f40de507')
        self.assertEqual(common.sha(native),'b6dc494b30e62e351a2de0f05d63250cda7e5131cf5fc479178396ab10f56ccf')
        def functions(path):return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(path.read_text('utf8')).body if isinstance(x,ast.FunctionDef)}
        a,b=functions(first),functions(Path(common.__file__))
        for name in ('capture_mode','derive_rows','actual_static_model','save_tensors','complete_rng','expected_core','validate_rows','validate_observer'):self.assertEqual(a[name],b[name])
        old,new=functions(native),functions(CASE/'adapters/observer_native_v2.py')
        for name in old:
            if name!='main':self.assertEqual(old[name],new[name])

    def test_actual_frozen_stage_expected_and_pairing_metadata_without_native(self):
        import observer_native_v2 as native
        self.assertEqual(native.verify_pairing()['common_sha256'],common.sha(common.__file__))
        self.assertEqual(common.sha(CASE/'observer-stage-v2.json'),common.STAGE_SHA256)
        self.assertEqual(common.sha(CASE/'transfer/observer-independent-expected-v2-20261107.json'),common.EXPECTED_SHA256)
        doc=common.read(CASE/'transfer/observer-independent-expected-v2-20261107.json')
        core=common.expected_core(common.coordinates(common.read(CASE/'inputs/discovery-v1/wikitext2-discovery-001.json')))
        self.assertTrue(all(common.canonical(doc[k])==common.canonical(v) for k,v in core.items()))
        with patch.object(native,'COMMON_SOURCE_SHA256','0'*64),self.assertRaisesRegex(ValueError,'frozen'):native.verify_pairing()

    def test_retained_dual_proof_copy_exact_and_relative_CPU_wrapper_supported(self):
        checked=proof.prerequisite(I04,proof.I04_PROOF_SHA256,Path(os.path.relpath(CPU,Path.cwd())),proof.CPU_PROOF_SHA256)
        with tempfile.TemporaryDirectory() as temporary:
            output=Path(temporary)/'artifacts';args=SimpleNamespace(output=output,input=CASE/'inputs/discovery-v1/wikitext2-discovery-001.json',
                stage_spec=CASE/'observer-stage-v1.json',expected_inventory=CASE/'transfer/observer-independent-expected-20261107.json',i04_prerequisite=I04,cpu_prerequisite=CPU)
            common.initialize_output(args,checked)
            self.assertEqual(common.sha(output/'prerequisites/i04/prerequisite.json'),proof.I04_PROOF_SHA256)
            self.assertEqual(common.sha(output/'prerequisites/cpu/prerequisite.json'),proof.CPU_PROOF_SHA256)
            copied=proof.prerequisite(output/'prerequisites/i04/prerequisite.json',proof.I04_PROOF_SHA256,
                output/'prerequisites/cpu/prerequisite.json',proof.CPU_PROOF_SHA256)
            self.assertEqual(len(copied['refs']),35)

    def test_copied_I04_report_byte_tamper_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            wrapper=copy_proof(I04,Path(temporary)/'i04');doc=common.read(wrapper);path=wrapper.parent/doc['report']['path'];path.write_bytes(path.read_bytes()+b'\n')
            with self.assertRaisesRegex(ValueError,'SHA differs'):proof.i04_prerequisite(wrapper,proof.I04_PROOF_SHA256)

    def test_resigned_wrong_scope_or_direct_argv_cannot_pass_semantic_gate(self):
        for altered in ('scope','argv'):
            with tempfile.TemporaryDirectory() as temporary:
                wrapper=copy_proof(I04,Path(temporary)/'i04');doc=common.read(wrapper);cp=wrapper.parent/doc['controller']['path'];rp=wrapper.parent/doc['report']['path']
                controller,report=common.read(cp),common.read(rp)
                if altered=='scope':
                    controller['scope']['target_distribution_pairs']=17;report['scope']['target_distribution_pairs']=17
                else:controller['argv'][controller['argv'].index('--timeout-seconds')+1]='901'
                rp.write_text(json.dumps(report),'utf8');new_report=common.sha(rp);controller['report']['sha256']=new_report
                cp.write_text(json.dumps(controller),'utf8');new_controller=common.sha(cp)
                doc['report']['sha256']=new_report;doc['controller']['sha256']=new_controller;wrapper.write_text(json.dumps(doc),'utf8')
                with patch.object(proof,'I04_PROOF_SHA256',common.sha(wrapper)),patch.object(proof,'REPORT',new_report),patch.object(proof,'CONTROLLER',new_controller),self.assertRaises(ValueError):
                    proof.i04_prerequisite(wrapper,common.sha(wrapper))

    def test_diagnostic_CPU_wrapper_even_resigned_cannot_be_native_proof(self):
        with tempfile.TemporaryDirectory() as temporary:
            wrapper=copy_proof(CPU,Path(temporary)/'cpu',True);doc=common.read(wrapper);doc['kind']='observer-cpu-failed-diagnostic-v1';doc['native_prerequisite_valid']=False
            wrapper.write_text(json.dumps(doc),'utf8');digest=common.sha(wrapper)
            with patch.object(proof,'CPU_PROOF_SHA256',digest),self.assertRaisesRegex(ValueError,'not a native prerequisite'):
                proof.prerequisite(I04,proof.I04_PROOF_SHA256,wrapper,digest)

    def test_pure_checker_fresh_process_import_and_both_actual_proofs(self):
        source=Path(proof.__file__)
        code="import importlib.util,sys; s=importlib.util.spec_from_file_location('gate',sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);r=m.prerequisite(sys.argv[2],m.I04_PROOF_SHA256,sys.argv[3],m.CPU_PROOF_SHA256);assert len(r['refs'])==35;assert not any(n in sys.modules for n in ('torch','torch_npu','numpy','transformers'))"
        result=subprocess.run([sys.executable,'-S','-B','-c',code,str(source),str(I04),str(CPU)],capture_output=True,text=True,timeout=15)
        self.assertEqual(result.returncode,0,result.stderr)


class StateControl(unittest.TestCase):
    def run_capture(self,folder,state_fn=None,rng_fn=None):
        baseline={'model_object_id':123,'buffers':[{'name':'model.language_model.embed_tokens.embed_scale','shape':[],
            'dtype':'torch.bfloat16','version':0,'content_probe_gap':{'error_type':'RuntimeError','error':'self.dim() cannot be0 to view BFloat16 as Byte'}}],
            'config':{'fixture':True},'parameters':[{'name':'fixture','version':0}]}
        def mode(model,torch,device,inventory,directory,name):directory.mkdir();return {'mode':name,'synthetic_no_native':True}
        with (patch.object(common,'actual_static_model',return_value={'synthetic_no_native':True}),patch.object(common,'model_state',side_effect=state_fn or (lambda *_:copy.deepcopy(baseline))),
                patch.object(common,'rng_observation',side_effect=rng_fn or (lambda *_:synthetic_rng())),patch.object(common,'capture_mode',side_effect=mode)):
            return common.capture_all(object(),object(),'npu:0',{},folder,'npu',lambda:{'seed':0},lambda:{'policy':'fixture'},lambda:None)

    def test_unchanged_scalar_BF16_gap_retained_explicitly_no_complete_content_claim(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder=Path(temporary);self.run_capture(folder);summary=common.read(folder/'capture-summary.json')
            self.assertEqual(len(summary['buffer_content_fingerprint_gaps']),1);self.assertFalse(summary['loaded_parameter_byte_attestation'])
            baseline=common.read(folder/'loaded-model-state.json')
            for mode in common.MODES:self.assertEqual(common.read(folder/'modes'/mode/'model-state-after.json'),baseline)
        self.assertIs(common.model_state,common.controlled.model_state)

    def test_RNG_advance_or_observed_parameter_version_change_fail_closed(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder=Path(temporary);values=[synthetic_rng(),synthetic_rng()];values[1]['device0']['sha256']='e'*64
            with self.assertRaisesRegex(ValueError,'consumed RNG'):self.run_capture(folder,rng_fn=lambda *_:values.pop(0))
        with tempfile.TemporaryDirectory() as temporary:
            folder=Path(temporary);count=[0]
            def state(*_):
                count[0]+=1;return {'buffers':[],'parameters':[{'version':int(count[0]>=3)}],'model_object_id':123}
            with self.assertRaisesRegex(ValueError,'persistent model state'):self.run_capture(folder,state_fn=state)


if __name__=='__main__':unittest.main()

"""Independent, bounded stdlib E02 replay of the admitted I03 selected subset.

No framework/shared numerical imports. All23 target reductions, a predeclared
distribution subset, four reported KV extrema and <=8 full KV tensors. This
does not independently repeat every1081 row pair or every110100480 KV coordinate.
"""
import argparse
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import heapq
import itertools
import json
import math
from pathlib import Path, PurePosixPath
import re
import signal
import struct
import time

CASE='projects/gemma4-pilot/cases/text-native'
MAIN=CASE+'/adapters/admit_i03_partition_repeat_v1.py'
MAIN_SHA='2468a5f2a1aafe9f9437edae2bd90b3bdca15f9c1abcc6fa3b927ddb8167691c'
HELPER=CASE+'/adapters/i03_artifact_admission_v1.py'
HELPER_SHA='b734babc65be6ec361acbc10905b6c3e02e8c5c57650efb11e3a195134a1b6eb'
CONTROLLER=CASE+'/transfer/run_i03_actual_compare_v1.py'
CONTROLLER_SHA='5cc22ed237239f7a090f53525353f27db6e06b6c3c68fa2210bff4925e480431'
TOOL_SHA='d4db95a5ae22091417698109d0dd9836ff5665d66667c530aaf85a4f597ccf87'
STAGE_SHA='6e53e3cdf3e7fad8f56b43cb99a42bdb999ac074a5a40a3c1e7df72eeb504005'
INPUT_SHA='643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
EXPECTED_SHA='5c8cdcc3c5b88732ccd589d95fa5ce86bd9eac71f83620e3bc48bcfc3b3b9a25'
COLLECTORS={'GPU':'6bd1616289966d561ff2254ba5896b1784e570de3d211a313b9e6f44c24ffe9a',
            'NPU':'3b21aabb480c230812b3b4be4a62191bc393ead34bc3bba1ae3af86c00a0ecc0'}
MODES=['full-r1','full-r2','full-r3','token','chunk63-65']
POSITIONS=sorted(set(i*127//15 for i in range(16))|set(range(127,159)))
VOCAB=262144
FIELDS=('tail_merged_js','probability_rmse','max_probability_error')
ATOL,RTOL=1e-12,5e-12
HEX=re.compile(r'^[a-f0-9]{64}$')
ACTUAL_CONTROLLER_SHA='03552c47162cb92195785b4ae63b9567ef331e6187f84754e3b8bbb4e409d24c'
ACTUAL_REPORT_SHA='c1cefa946eef3530384f2c43c538c2d59a6433e16f993dc157850e915f21ac87'
ACTUAL_SPEC_SHA='c825ce48f502beb2ce4104dddff1274aec4c6099fbc6fc18d63b04df06f70c07'
SELECTION_SHA='64be91b643771a26dceb13dec8d69f5c1d0ffc8eb901821cc645d9a26b1a95e9'


def require(ok,message):
    if not ok:raise ValueError(message)


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)


def parse(raw):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=reject)


def put(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def number(value):
    if isinstance(value,dict):value=value['value']
    require(type(value) in (int,float) and math.isfinite(value),'finite metric required');return value


def equal(actual,expected,label):
    if actual is None:
        require(isinstance(expected,dict) and expected.get('value') is None and expected.get('reason')=='zero signal norm','zero-norm result differs: '+label)
    else:require(math.isclose(number(actual),number(expected),rel_tol=RTOL,abs_tol=ATOL),'independent metric differs: '+label)


def original(path):
    p=PurePosixPath(path)
    require(isinstance(path,str) and p.is_absolute() and str(p)==path and '\\' not in path and '..' not in p.parts,'canonical original POSIX path required')
    return path


def child(path,name):return str(PurePosixPath(original(path))/name)


def flag(argv,name):
    require(isinstance(argv,list) and argv.count(name)==1 and not any(item.startswith(name+'=') for item in argv),'unique literal argv flag required')
    index=argv.index(name);require(index+1<len(argv),'missing argv value');return argv[index+1]


def shape_size(shape):
    require(isinstance(shape,list) and shape and all(type(x) is int and x>0 for x in shape),'positive tensor shape required')
    return math.prod(shape)


def unravel(index,shape):
    require(type(index) is int and 0<=index<shape_size(shape),'tensor coordinate outside shape')
    coordinates=[]
    for dimension in reversed(shape):coordinates.append(index%dimension);index//=dimension
    return list(reversed(coordinates))


class Audit:
    def __init__(self,seconds):
        self.deadline=time.monotonic()+seconds;self.checked={};self.large=set();self.originals={};self.hash_calls=0
    def tick(self):
        if time.monotonic()>=self.deadline:raise TimeoutError('I03 E02 CPU600s deadline reached')
    def file(self,path,expected=None,large=False,force=False):
        self.tick();path=Path(path)
        require(path.is_file() and not path.is_symlink(),'original regular source required: '+str(path))
        name=str(path.resolve(strict=True))
        if force or name not in self.checked:
            h=hashlib.sha256()
            with path.open('rb') as stream:
                for block in iter(lambda:stream.read(4*1024**2),b''):self.tick();h.update(block)
            digest=h.hexdigest();self.hash_calls+=1
            require(expected is None or HEX.fullmatch(expected) and digest==expected,'frozen source byte SHA differs: '+name)
            require(name not in self.checked or self.checked[name]['sha256']==digest,'source changed during E02')
            self.checked[name]={'sha256':digest,'size':path.stat().st_size}
        require(expected is None or self.checked[name]['sha256']==expected,'source reference SHA conflicts')
        if large:self.large.add(name)
        return Path(name)
    def json(self,path,expected=None):return parse(self.file(path,expected).read_bytes())
    def recheck_small(self):
        for path,ref in list(self.checked.items()):
            if path not in self.large:self.file(path,ref['sha256'],force=True)


class Endpoint:
    """Only path/hash resolution is shared in semantics; no numeric admission calls."""
    def __init__(self,audit,info,backend):
        self.audit,self.backend=audit,backend;ref=info['source_map']
        self.path=audit.file(ref['path'],ref['sha256']);self.document=audit.json(self.path,ref['sha256']);self.files=self.document['files']
        require(self.document.get('schema_version')==1 and self.document.get('request',{}).get('task')=='I03' and
            self.document['request'].get('backend')==backend and self.document['request'].get('outer_receipt')==info['receipt']['source_path'],'original endpoint request differs')
        self.root=Path(info['retained_root']).resolve(strict=True) if backend=='NPU' and info.get('retained_root') else None
        require(backend=='GPU' or self.root is not None and self.root.is_dir(),'explicit NPU retained root required')
    def locate(self,name,expected=None):
        name=original(name);ref=self.files[name]
        require(type(ref.get('size')) is int and ref['size']>=0 and isinstance(ref.get('sha256'),str) and HEX.fullmatch(ref['sha256']) and
            (expected is None or expected==ref['sha256']),'mapped source size/SHA differs')
        if ref.get('retained_at_source') is True:
            require(self.backend=='NPU' and self.root is not None and 'path' not in ref and name.endswith(('.npy','.safetensors')),'only native NPU arrays may be source-retained')
            path=Path(name);require(path.is_relative_to(self.root) and path.resolve(strict=True).is_relative_to(self.root),'retained source escapes root')
        else:
            p=PurePosixPath(ref['path']);require(not p.is_absolute() and '..' not in p.parts and '\\' not in ref['path'],'copied metadata escapes source map')
            path=self.path.parent/str(p);require(path.resolve(strict=True).is_relative_to(self.path.parent),'copied source escapes bundle')
        require(path.is_file() and not path.is_symlink() and path.stat().st_size==ref['size'],'actual mapped file size/type differs')
        self.audit.originals[name]={'actual_path':str(path.resolve()),'sha256':ref['sha256'],'size':ref['size'],'backend':self.backend,
            'large':name.endswith(('.npy','.safetensors'))}
        return path,ref
    def get(self,name,expected=None,force=False):
        path,ref=self.locate(name,expected);return self.audit.file(path,ref['sha256'],name.endswith(('.npy','.safetensors')),force)
    def json(self,name,expected=None):return parse(self.get(name,expected).read_bytes())


def quantile(values,fraction):
    values=sorted(values);require(values and 0<=fraction<=1,'nonempty quantile input required')
    index=fraction*(len(values)-1);lower=int(index)
    return values[lower]+(index-lower)*(values[min(lower+1,len(values)-1)]-values[lower])


def target_metrics(a,b,coordinates):
    require(len(a)==len(b)==len(coordinates)==159,'all159 target scores required')
    require(all(math.isfinite(x) and x<=0 for x in a+b),'finite target scores required')
    errors=[abs(x-y) for x,y in zip(a,b)];worst=errors.index(max(errors));na,nb=[math.fsum(-x for x in side)/159 for side in (a,b)]
    return {'target_count':159,'side_a_nll_nat_per_token':na,'side_b_nll_nat_per_token':nb,'nll_abs_diff_nat_per_token':abs(na-nb),
        'mae_nat':math.fsum(errors)/159,'p99_nat':quantile(errors,.99),'max_abs_nat':errors[worst],'max_coordinate':coordinates[worst]}


def read_npy(path,vocabulary=VOCAB):
    with Path(path).open('rb') as stream:
        require(stream.read(6)==b'\x93NUMPY','NPY magic differs');version=stream.read(2)
        require(version in (b'\x01\x00',b'\x02\x00',b'\x03\x00'),'unsupported NPY format')
        size=2 if version[0]==1 else 4;prefix=stream.read(size);require(len(prefix)==size,'truncated NPY header length')
        length=int.from_bytes(prefix,'little');require(0<length<=65536,'bounded NPY header required')
        header=ast.literal_eval(stream.read(length).decode('utf-8' if version[0]==3 else 'latin1').strip())
        require(set(header)=={'shape','fortran_order','descr'} and header['shape']==(1,vocabulary) and header['fortran_order'] is False and
            header['descr'] in ('<f8','>f8','=f8'),'exact complete1xV FP64 row required')
        raw=stream.read(vocabulary*8+1);require(len(raw)==vocabulary*8,'NPY payload byte count differs')
    values=struct.unpack(header['descr'][0]+str(vocabulary)+'d',raw)
    require(all(math.isfinite(x) and x<=0 for x in values),'finite nonpositive full logprobs required');return values


def native_header(path):
    with Path(path).open('rb') as stream:
        prefix=stream.read(8);require(len(prefix)==8,'truncated safetensors prefix');length=struct.unpack('<Q',prefix)[0]
        require(0<length<=262144,'bounded safetensors header required');raw=stream.read(length);require(len(raw)==length,'truncated safetensors header')
    header=parse(raw);records={};spans=[]
    for name,ref in header.items():
        if name=='__metadata__':
            require(isinstance(ref,dict) and all(isinstance(v,str) for v in ref.values()),'string safetensors metadata required');continue
        require(set(ref)=={'dtype','shape','data_offsets'} and ref['dtype']=='BF16','lossless native BF16 tensor required')
        count=shape_size(ref['shape']);start,end=ref['data_offsets']
        require(type(start) is int and type(end) is int and start>=0 and end-start==count*2,'native tensor shape/offset byte size differs')
        records[name]=ref;spans.append((start,end))
    offset=0
    for start,end in sorted(spans):require(start==offset,'native payload gap/overlap');offset=end
    require(Path(path).stat().st_size==8+length+offset,'native complete file size differs')
    return 8+length,records


def bf16_values(raw):
    require(len(raw)%2==0,'BF16 byte length differs')
    values=[struct.unpack('<f',struct.pack('<I',bits[0]<<16))[0] for bits in struct.iter_unpack('<H',raw)]
    require(all(math.isfinite(x) for x in values),'nonfinite native BF16 value');return values


def native_values(path,key,start,count,shape=None):
    base,header=native_header(path);require(key in header,'native tensor key missing');record=header[key]
    require(shape is None or record['shape']==shape,'native tensor shape differs')
    require(type(start) is int and type(count) is int and start>=0 and count>0 and start+count<=shape_size(record['shape']),'native scalar range outside tensor')
    with Path(path).open('rb') as stream:stream.seek(base+record['data_offsets'][0]+start*2);raw=stream.read(count*2)
    require(len(raw)==count*2,'native values truncated');return bf16_values(raw)


def independent_logprobs(values):
    maximum=max(values);normalizer=maximum+math.log(math.fsum(math.exp(x-maximum) for x in values))
    return [x-normalizer for x in values]


def distribution_metrics(a,b):
    require(len(a)==len(b) and len(a)>=100,'complete vocabulary rows required')
    topa=heapq.nsmallest(100,range(len(a)),key=lambda i:(-a[i],i));topb=heapq.nsmallest(100,range(len(b)),key=lambda i:(-b[i],i))
    union=sorted(set(topa)|set(topb));members=set(union);pa=[math.exp(x) for x in a];pb=[math.exp(x) for x in b]
    ma,mb=math.fsum(pa),math.fsum(pb);require(abs(ma-1)<=1e-5 and abs(mb-1)<=1e-5,'full probability normalization differs')
    ca=math.fsum(x for i,x in enumerate(pa) if i not in members);cb=math.fsum(x for i,x in enumerate(pb) if i not in members)
    categories=[(pa[i],pb[i],a[i],b[i]) for i in union]+[(ca,cb,math.log(ca) if ca else -math.inf,math.log(cb) if cb else -math.inf)]
    terms=[]
    for p,q,lp,lq in categories:
        maximum=max(lp,lq)
        if maximum==-math.inf:continue
        lm=maximum+math.log(math.exp(lp-maximum)+math.exp(lq-maximum))-math.log(2)
        if p:terms.append(.5*p*(lp-lm))
        if q:terms.append(.5*q*(lq-lm))
    errors=[abs(pa[i]-pb[i]) for i in union];worst=errors.index(max(errors))
    return {'union_count':len(union),'tail_merged_js':max(0.0,math.fsum(terms)),
        'probability_rmse':math.sqrt(math.fsum(x*x for x in errors)/len(union)),'max_probability_error':errors[worst],
        'max_error_token':union[worst],'top1_agreement':topa[0]==topb[0],'top100_overlap':len(set(topa)&set(topb))/100,
        'coverage':{'side_a_top100':math.fsum(pa[i] for i in topa),'side_b_top100':math.fsum(pb[i] for i in topb),
            'side_a_union':math.fsum(pa[i] for i in union),'side_b_union':math.fsum(pb[i] for i in union)},
        'normalization_mass':{'side_a':ma,'side_b':mb},'direct_complement_mass':{'side_a':ca,'side_b':cb}}


def tensor_metrics(a,b):
    require(len(a)==len(b)>0 and all(math.isfinite(x) for x in a+b),'finite paired tensor values required')
    differences=[y-x for x,y in zip(a,b)];errors=[abs(x) for x in differences]
    # BF16 finite magnitudes squared times <=327680 remain safely inside FP64.
    aa=math.fsum(x*x for x in a);bb=math.fsum(x*x for x in b);ee=math.fsum(x*x for x in differences)
    cosine=math.fsum(x*y for x,y in zip(a,b))/math.sqrt(aa*bb) if aa and bb else None
    if cosine is not None:require(abs(cosine)<=1+1e-12,'scalar cosine outside rounding bound');cosine=max(-1.,min(1.,cosine))
    maximum=max(errors)
    return {'count':len(a),'side_a_norm':math.sqrt(aa),'side_b_norm':math.sqrt(bb),'error_norm':math.sqrt(ee),
        'rmse':math.sqrt(ee/len(a)),'cosine':cosine,'max_abs':maximum,'max_flat_index':errors.index(maximum)}


def select(report):
    pairs=report['target_distribution_pairs'];require(len(pairs)==23,'all23 source target/distribution pairs required')
    fixed=[i for i,pair in enumerate(pairs) if pair['sides']==['gpu-full-r1','npu-full-r1']]
    require(len(fixed)==1,'prespecified first cross-full pair missing')
    chosen={(fixed[0],p) for p in POSITIONS};extrema=[]
    for field in FIELDS:
        index=max(range(len(pairs)),key=lambda i:number(pairs[i]['distributions']['aggregate'][field]['max']))
        claim=pairs[index]['distributions']['aggregate'][field];position=claim['max_coordinate']['position']
        require(position in POSITIONS,'reported maximum outside frozen47 positions');chosen.add((index,position))
        extrema.append({'metric':field,'pair_index':index,'sides':pairs[index]['sides'],'position':position,'claim':claim,
            'reported_tie_pair_count':sum(number(p['distributions']['aggregate'][field]['max'])==number(claim['max']) for p in pairs)})
    require(len(chosen)<=50,'selected distribution scope exceeds fixed bound')
    kv=[];require(len(report['native_final_kv_pairs'])==4,'four native KV pairs required')
    for index,pair in enumerate(report['native_final_kv_pairs']):
        coordinate=pair['metrics']['global']['max_coordinate']
        require(coordinate['tensor'] in pair['metrics']['per_tensor'],'reported global KV tensor missing')
        tensors=sorted({coordinate['tensor'],'layer-000.key'})
        kv.append({'pair_index':index,'sides':pair['sides'],'reported_global_max_coordinate':coordinate,'representative_tensors':tensors})
    return {'schema_version':1,'status':'subset_frozen_before_scalar_values','distribution_rows':[{'pair_index':i,'sides':pairs[i]['sides'],'position':p} for i,p in sorted(chosen)],
        'distribution_extrema_claims':extrema,'kv':kv,'target_pairs':23,'target_scores_per_side_per_pair':159,
        'fixed_cross_full_positions':47,'distribution_rows_selected':len(chosen),'global_KV_coordinates_selected':4,
        'representative_KV_tensors_selected':sum(len(x['representative_tensors']) for x in kv),
        'tie_policy':'first pair in immutable report order; row coordinate is its reported first maximum; deduplicate pair/position',
        'selection_uses_frozen_report_metrics':True,'original_model_values_decoded_before_selection':False,'thresholds':None,'acceptance':None}


def completed(document):
    require(document.get('status')=='completed' and type(document.get('returncode')) is int and document['returncode']==0,'actual completed0 producer receipt required')


def source_chain(audit,controller_path,controller_sha):
    require(controller_sha==ACTUAL_CONTROLLER_SHA,'actual original I03 controller SHA differs from predeclared proof')
    state=audit.json(controller_path,controller_sha);completed(state);run=Path(controller_path).parent;tools=Path(state['tools_root'])
    require(state.get('task')=='I03' and state.get('run')==str(run) and state.get('child_returncode')==0 and
        state.get('native_executions_started')==0 and state.get('tool_manifest_sha256')==TOOL_SHA and state.get('whole_cpu_seconds')==900 and
        state.get('child_work_seconds')==870 and state.get('analysis_seconds')==850 and not state.get('timed_out',False) and not state.get('cleanup_incomplete',False),
        'actual bounded original I03 admission controller differs')
    tool_doc=audit.json(tools/'tool-bundle-manifest.json',TOOL_SHA)
    require(len(tool_doc['files'])==20 and tool_doc['files'][MAIN]['sha256']==MAIN_SHA and tool_doc['files'][HELPER]['sha256']==HELPER_SHA and
        tool_doc['files'][CONTROLLER]['sha256']==CONTROLLER_SHA,'pinned independent20source admission closure differs')
    for name,ref in tool_doc['files'].items():
        p=PurePosixPath(name);require(not p.is_absolute() and '..' not in p.parts and '\\' not in name,'unsafe tool source member')
        actual=audit.file(tools/name,ref['sha256']);require(actual.stat().st_size==ref['size_bytes'],'tool source size differs')
    argv=state['argv'];require(argv[1]=='-B' and Path(argv[2])==tools/MAIN,'actual direct numerical analysis source differs')
    spec_ref,report_ref=state['comparison_spec'],state['report']
    require(spec_ref['sha256']==ACTUAL_SPEC_SHA and report_ref['sha256']==ACTUAL_REPORT_SHA,'actual report/spec SHA differs from retained original proof')
    require(Path(spec_ref['path'])==run/'comparison-spec.json' and Path(report_ref['path'])==run/'bundle/i03-comparison-report.json' and
        flag(argv,'--spec')==spec_ref['path'] and flag(argv,'--spec-sha256')==spec_ref['sha256'] and flag(argv,'--output-dir')==str(run/'bundle') and
        flag(argv,'--timeout-seconds')=='850','original comparison input/output direct argv differs')
    spec=audit.json(spec_ref['path'],spec_ref['sha256']);report=audit.json(report_ref['path'],report_ref['sha256'])
    require(spec['stage_spec_sha256']==report['stage_spec_sha256']==STAGE_SHA and report['comparison_spec_sha256']==spec_ref['sha256'] and
        report['status']=='i03_raw_bf16_partition_repeat_and_final_kv_checked' and report['native_executions_started_by_admission']==0 and
        report['thresholds'] is None and report['acceptance'] is None and report['full_core_complete'] is False and
        report['scope']['target_distribution_pairs']==23 and report['scope']['native_final_kv_pairs']==4 and
        report['source_map_sha256']=={k:v['source_map']['sha256'] for k,v in spec['endpoints'].items()},'frozen actual23/4 I03 result chain differs')
    for label in ('stdout','stderr'):
        ref=state[label];path=audit.file(ref['path'],ref['sha256']);require(path.stat().st_size==ref['bytes'],'original numerical log size differs')
    endpoints={};runs={};large=[]
    for backend,info in spec['endpoints'].items():
        endpoint=Endpoint(audit,info,backend);endpoints[backend]=endpoint;outer=endpoint.json(info['receipt']['source_path'],info['receipt']['sha256']);completed(outer)
        require(outer['task']=='I03' and outer['backend']==backend and outer['collector_sha256']==COLLECTORS[backend] and outer['input_sha256']==INPUT_SHA and
            outer['stage_spec_source_sha256']==STAGE_SHA and outer['expected_inventory_source_sha256']==EXPECTED_SHA and
            outer['native_capture_count']==1 and outer['native_forward_calls_total']==70 and outer['model_loads']==1 and outer['timed_out'] is False,
            'actual one-process70-forward native outer differs')
        generic=endpoint.json(outer['generic_receipt']['path'],outer['generic_receipt']['sha256']);completed(generic)
        require(generic['argv']==outer['argv'] and generic['child_returncode']==0 and generic['timeout']==(1500 if backend=='GPU' else 1800),'original native generic receipt differs')
        native_controller=endpoint.json(child(str(PurePosixPath(info['receipt']['source_path']).parent),'controller-receipt.json'));completed(native_controller)
        require(native_controller['remaining_descendants']==[],'native producer descendants remain')
        inp=endpoint.json(outer['input_path'],INPUT_SHA);sequence=inp['prompt']+inp['continuation']
        require(len(inp['prompt'])==128 and len(inp['continuation'])==32 and all(type(x) is int and 0<=x<VOCAB for x in sequence),'original causal input differs')
        manifest=endpoint.json(child(outer['output_dir'],'artifacts-manifest.json'),outer['artifacts_manifest_sha256'])
        status=endpoint.json(child(outer['output_dir'],'status.json'));require(status['status']=='completed' and status['artifacts_manifest_sha256']==outer['artifacts_manifest_sha256'],'native terminal manifest differs')
        expected_large={'modes/'+mode+'/'+name for mode in MODES for name in ({'raw-native-logits.safetensors'}|{'dist-p%03d.npy'%p for p in POSITIONS})}
        expected_large|={'modes/'+mode+'/final-native-kv.safetensors' for mode in MODES[3:]}
        actual_large={name for name in manifest['files'] if name.endswith(('.npy','.safetensors'))}
        require(actual_large==expected_large and len(manifest['files'])==(530 if backend=='GPU' else 531),'exact admitted native product inventory differs')
        require({key[len(outer['output_dir'])+1:] for key in endpoint.files if key.startswith(outer['output_dir']+'/')}==set(manifest['files'])|{'artifacts-manifest.json','status.json'},'endpoint native output inventory differs')
        for name,ref in manifest['files'].items():
            original_path=child(outer['output_dir'],name);path,mapped=endpoint.locate(original_path,ref['sha256'])
            require(mapped['size']==ref['size_bytes'],'native product size binding differs')
            if name in actual_large:large.append((endpoint,original_path,ref['sha256']))
        for name,ref in endpoint.files.items():
            if not name.endswith(('.npy','.safetensors')):endpoint.get(name,ref['sha256'])
        for name,digest in outer['source_sha256'].items():endpoint.get(name,digest)
        for mode in MODES:
            output=child(outer['output_dir'],'modes/'+mode)
            coordinates=[{'sample':inp['sample'],'position':i,'token':sequence[i]} for i in range(1,160)]
            raw=child(output,'raw-native-logits.safetensors')
            runs[backend.lower()+'-'+mode]={'endpoint':endpoint,'output':output,'score_source':child(output,'target-scores.json'),
                'coordinates':coordinates,'sequence':sequence,'raw_logits':raw}
    require(set(endpoints)=={'GPU','NPU'} and len(large)==484 and len({str(endpoint.locate(name)[0].resolve()) for endpoint,name,_ in large})==484,
        'actual484 distinct admitted large source objects required')
    frozen=0
    for pair in report['target_distribution_pairs']+report['native_final_kv_pairs']:
        metric=pair['targets'] if 'targets' in pair else pair['metrics'];directory=Path(metric['sources']['contract']).parent
        require(directory.resolve().is_relative_to((run/'bundle').resolve()),'frozen comparison document directory escapes original run')
        for name,digest in pair['frozen_document_sha256'].items():
            require(PurePosixPath(name).name==name,'unsafe flat frozen comparison document');audit.file(directory/name,digest);frozen+=1
    require(frozen==204,'exact204 frozen target/distribution/KV documents required')
    expected=[]
    for backend in ('gpu','npu'):
        expected += [(backend+'-'+a,backend+'-'+b) for a,b in itertools.combinations(MODES[:3],2)]
        expected += [(backend+'-'+a,backend+'-'+b) for a,b in [('full-r1','token'),('full-r1','chunk63-65'),('token','chunk63-65')]]
    expected += [('gpu-'+a,'npu-'+b) for a in MODES[:3] for b in MODES[:3]]
    expected += [('gpu-'+m,'npu-'+m) for m in MODES[3:]]
    require(len(report['target_distribution_pairs'])==23 and {tuple(p['sides']) for p in report['target_distribution_pairs']}==set(expected),'exact23 pair membership differs')
    require([p['sides'] for p in report['native_final_kv_pairs']]==[['gpu-token','gpu-chunk63-65'],['npu-token','npu-chunk63-65'],['gpu-token','npu-token'],['gpu-chunk63-65','npu-chunk63-65']], 'fixed four native KV pair inventory differs')
    return state,spec,report,runs,large


def verify(controller_path,controller_sha,output,timeout=600):
    require(type(timeout) is int and timeout==600,'fixed600s stdlib CPU replay required');audit=Audit(timeout)
    audit.file(Path(__file__).resolve())
    output=Path(output);require(output.parent.is_dir() and not output.exists(),'exclusive new E02 output required')
    state,spec,report,runs,large=source_chain(audit,controller_path,controller_sha)
    selection=select(report)
    selection.update(source_controller={'path':str(controller_path),'sha256':controller_sha},source_report=state['report'])
    require(hashlib.sha256((json.dumps(selection,indent=2,allow_nan=False)+'\n').encode()).hexdigest()==SELECTION_SHA,
        'actual report-derived subset differs from predeclared immutable selection')
    output.mkdir(mode=0o700);put(output/'selection.json',selection)
    selection_sha=hashlib.sha256((output/'selection.json').read_bytes()).hexdigest()
    # The subset above is durable before decoding original scores or tensors.
    for run in runs.values():
        scores=run['endpoint'].json(run['score_source'])
        require(len(scores['scores'])==159 and all(all(row[k]==coordinate[k] for k in coordinate)
            for row,coordinate in zip(scores['scores'],run['coordinates'])),'native all159 causal target identities differ')
        require(scores['raw_logits_sha256']==run['endpoint'].files[run['raw_logits']]['sha256'],'target/native source binding differs')
        run['scores']=[row['logprob'] for row in scores['scores']]
    targets=[]
    for index,pair in enumerate(report['target_distribution_pairs']):
        audit.tick();a,b=[runs[side] for side in pair['sides']];require(a['coordinates']==b['coordinates'],'target coordinates differ across original sides')
        actual=target_metrics(a['scores'],b['scores'],a['coordinates']);shared=pair['targets']
        require(shared['status']=='no_thresholds' and shared['coverage']=={'expected':159,'paired':159},'original target coverage/status differs')
        for field,value in actual.items():
            if field=='max_coordinate':require(value==shared['metrics'][field],'target max causal coordinate differs')
            else:equal(value,shared['metrics'][field],'target.'+field)
        targets.append({'pair_index':index,'sides':pair['sides'],'metrics':actual})
    distributions=[]
    for chosen in selection['distribution_rows']:
        audit.tick();pair=report['target_distribution_pairs'][chosen['pair_index']];position=chosen['position'];values=[];raw_deltas=[]
        for side in chosen['sides']:
            run=runs[side];endpoint=run['endpoint'];row=child(run['output'],'dist-p%03d.npy'%position);lp=read_npy(endpoint.get(row))
            native=native_values(endpoint.get(run['raw_logits']),'logits',position*VOCAB,VOCAB,[1,160,VOCAB]);derived=independent_logprobs(native)
            delta=max(abs(x-y) for x,y in zip(lp,derived));require(delta<=1e-12,'selected raw BF16/FP64 row derivation differs')
            require(lp[run['sequence'][position+1]]==run['scores'][position],'selected target/NPY identity differs')
            values.append(lp);raw_deltas.append(delta)
        actual=distribution_metrics(*values);shared=[r for r in pair['distributions']['positions'] if r['sample']==runs[chosen['sides'][0]]['coordinates'][0]['sample'] and r['position']==position]
        require(len(shared)==1,'unique selected source distribution row required');shared=shared[0]
        for field in FIELDS:equal(actual[field],shared[field],'selected distribution.'+field)
        for field in ('union_count','max_error_token','top1_agreement'):require(type(actual[field]) is type(shared[field]) and actual[field]==shared[field],'selected top100 ranking differs')
        equal(actual['top100_overlap'],shared['top100_overlap'],'top100 overlap')
        for group in ('coverage','normalization_mass'):
            for field,value in actual[group].items():equal(value,shared[group][field],group+'.'+field)
        for claim in selection['distribution_extrema_claims']:
            if claim['pair_index']==chosen['pair_index'] and claim['position']==position:
                equal(actual[claim['metric']],claim['claim']['max'],'selected reported global '+claim['metric'])
                if claim['metric']=='max_probability_error':require(actual['max_error_token']==claim['claim']['max_coordinate']['token'],'selected global max token differs')
        distributions.append({**chosen,'metrics':actual,'raw_native_to_NPY_max_abs_delta':raw_deltas})
    kv=[]
    for chosen in selection['kv']:
        audit.tick();pair=report['native_final_kv_pairs'][chosen['pair_index']];paths=[];headers=[]
        for side in pair['sides']:
            run=runs[side];path=run['endpoint'].get(child(run['output'],'final-native-kv.safetensors'));_,header=native_header(path)
            expected_keys={'layer-%03d.%s'%(i,k) for i in range(48) for k in ('key','value')};require(set(header)==expected_keys,'all96 native KV tensor keys required')
            for name,ref in header.items():
                layer=int(name.split('.')[0].split('-')[1]);shape=[1,1,160,512] if layer in (5,11,17,23,29,35,41,47) else [1,8,160,256]
                require(ref['shape']==shape,'native configured KV layout differs')
            paths.append(path);headers.append(header)
        require(headers[0]==headers[1],'paired native KV layouts/offsets differ')
        coordinate=chosen['reported_global_max_coordinate'];name=coordinate['tensor'];index=coordinate['index'];shape=headers[0][name]['shape']
        require(unravel(index,shape)==coordinate['coordinate'],'reported global KV multidimensional coordinate differs')
        av,bv=[native_values(path,name,index,1,shape)[0] for path in paths];error=abs(av-bv)
        equal(error,pair['metrics']['global']['max_abs'],'global KV coordinate absolute error')
        ordered=sorted(headers[0]);global_index=sum(shape_size(headers[0][key]['shape']) for key in ordered[:ordered.index(name)])+index
        require(global_index==pair['metrics']['global']['max_flat_index'],'global KV flat coordinate differs')
        reductions=[]
        for tensor in chosen['representative_tensors']:
            shape=headers[0][tensor]['shape'];count=shape_size(shape);a,b=[native_values(path,tensor,0,count,shape) for path in paths]
            actual=tensor_metrics(a,b);shared=pair['metrics']['per_tensor'][tensor]
            for field,value in actual.items():
                if field in ('count','max_flat_index'):require(value==shared[field],'representative KV exact count/index differs')
                else:equal(value,shared[field],'representative KV '+field)
            require(unravel(actual['max_flat_index'],shape)==shared['max_coordinate'],'representative KV maximum coordinate differs')
            reductions.append({'tensor':tensor,'shape':shape,'metrics':actual})
        kv.append({**chosen,'global_coordinate_values':{'side_a':av,'side_b':bv,'absolute_error':error},'full_tensor_reductions':reductions})
    # One fresh full484-object hash pass AFTER selected numeric reads. Unselected
    # arrays are not reread twice; selected arrays are hash-checked when read and
    # again in this final admitted-pool pass. No full1081/110M scalar replay claim.
    pool=[]
    for endpoint,name,digest in large:
        path=endpoint.get(name,digest,force=True);pool.append({'original_path':name,'backend':endpoint.backend,'sha256':digest,'size':path.stat().st_size,'resolved_path':str(path)})
    audit.recheck_small();require(hashlib.sha256((output/'selection.json').read_bytes()).hexdigest()==selection_sha,'frozen subset changed during replay')
    result={'schema_version':1,'status':'independent_i03_selected_e02_checks_matched','checked_utc':datetime.now(timezone.utc).isoformat(),
        'source_controller':{'path':str(controller_path),'sha256':controller_sha},'source_report':state['report'],'comparison_spec':state['comparison_spec'],
        'selection_sha256':selection_sha,'scope':{'target_pairs':23,'targets_per_pair':159,'independent_distribution_pair_rows':len(distributions),
            'all_distribution_pair_rows_in_original_report':1081,'global_KV_coordinates':4,'full_representative_KV_tensors':sum(len(x['full_tensor_reductions']) for x in kv),
            'admitted_large_sources_final_bytehash_checked':484,'full_KV_global_reductions_repeated':False,'independent_inputs':1},
        'target_pair_checks':targets,'distribution_checks':distributions,'native_KV_checks':kv,
        'verification':{'absolute_metric_tolerance':ATOL,'relative_metric_tolerance':RTOL,'raw_logprob_derivation_absolute_tolerance':1e-12,
            'model_acceptance_thresholds':False,'CPU_seconds':600,'full_pool_bytehash_passes':1},
        'native_executions_started':0,'thresholds':None,'acceptance':None,'full_core_complete':False,
        'limitations':['Selected E02 subset, not independent replay of all1081 distribution pairs or all110100480 KV paired coordinates',
            'Union-top100 probability errors and complement-merged JS are not full-vocabulary probability errors/divergence',
            'The reported global extrema choose the subset; selected values are independently checked, not a new independent global search',
            'Same-process full repeats are not fresh-process repeatability; no native-file bytewise equality or operator cause is asserted']}
    put(output/'e02-report.json',result);put(output/'admitted-large-source-hashes.json',pool)
    put(output/'source-proof.json',{'schema_version':1,'checked_sources':audit.checked,'original_source_files':audit.originals,
        'source_map_sha256':report['source_map_sha256'],'all_admitted_large_final_hashes':484,'hash_calls':audit.hash_calls,'native_executions_started':0})
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--controller',type=Path,required=True);parser.add_argument('--controller-sha256',required=True)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    def expire(*_):raise TimeoutError('independent I03 E02 CPU600s bound exceeded')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,600)
    try:
        require(HEX.fullmatch(args.controller_sha256),'actual controller SHA required')
        result=verify(args.controller,args.controller_sha256,args.output)
        print(json.dumps({'status':result['status'],'scope':result['scope'],'native_executions_started':0,'acceptance':None}));return 0
    finally:signal.setitimer(signal.ITIMER_REAL,0)


if __name__=='__main__':raise SystemExit(main())

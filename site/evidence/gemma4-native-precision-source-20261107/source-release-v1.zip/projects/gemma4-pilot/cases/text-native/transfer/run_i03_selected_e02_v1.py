"""One CPU600/whole660 I03 selected E02 replay and small transfer envelope."""
import argparse
import base64
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import tarfile
import time

VERIFY_SHA='863019a1bd9875d418630c4c5e547576232e225fd66a98d63d51f3023701a44e'
RECORDER_SHA='2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'
MAX_SMALL,MAX_TOTAL,MAX_GZIP=16*1024**2,192*1024**2,32*1024**2


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def read(path):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)


def put(path,document):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(document,stream,indent=2,allow_nan=False);stream.write('\n')


def run(root,controller,controller_sha):
    os.umask(0o077)
    started=time.monotonic();root=Path(root).resolve(strict=True);here=Path(__file__).resolve().parent
    verifier=here/'verify_i03_selected_e02_v1.py';recorder=here/'record_run.py'
    require(here.is_relative_to(root) and not here.is_symlink() and len(VERIFY_SHA)==64 and sha(verifier)==VERIFY_SHA and sha(recorder)==RECORDER_SHA,'reviewed CPU source closure unavailable')
    controller=Path(controller);require(controller.resolve().is_relative_to(root) and controller.is_file() and not controller.is_symlink() and sha(controller)==controller_sha,'actual admitted I03 controller path/SHA required')
    require(not any(name in sys.modules for name in ('torch','torch_npu','numpy')),'CPU replay runner imported a framework')
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');reservation=root/'runs'/('compare-i03-selected-e02-invocation-'+stamp)
    reservation.mkdir(mode=0o700,exist_ok=False)
    put(reservation/'claim.json',{'task':'I03-selected-E02','controller_sha256':controller_sha,'claimed_utc':datetime.now(timezone.utc).isoformat(),
        'native_executions_started':0,'automatic_retry':False,'whole_seconds':660,'numeric_child_seconds':600})
    spec=importlib.util.spec_from_file_location('i03_selected_e02_generic',recorder);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    def interrupted(signum,frame):raise KeyboardInterrupt('bounded E02 signal '+str(signum))
    handlers={sig:signal.signal(sig,interrupted) for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP,signal.SIGALRM)}
    signal.setitimer(signal.ITIMER_REAL,max(.01,660-(time.monotonic()-started)))
    state={'schema_version':1,'task':'I03-selected-E02','status':'running','started_utc':datetime.now(timezone.utc).isoformat(),
        'original_controller':str(controller),'original_controller_sha256':controller_sha,'verifier_sha256':VERIFY_SHA,
        'runner_sha256':sha(__file__),'generic_sha256':RECORDER_SHA,'child_cpu_seconds':600,'generic_envelope_seconds':620,
        'whole_cpu_seconds':660,'cleanup_reserve_seconds':20,'native_executions_started':0,'thresholds':None,'acceptance':None}
    code=1
    try:
        require(660-(time.monotonic()-started)-20>=620,'insufficient finite CPU envelope')
        native,command=module.record_run(reservation,'cpu','e02-scalar-selected',620,
            lambda folder:[sys.executable,'-B',str(verifier),'--controller',str(controller),'--controller-sha256',controller_sha,'--output',str(folder/'e02')],cwd=here)
        state['generic_receipt']={'path':str(native/'command.json'),'sha256':sha(native/'command.json')}
        require(command['status']=='completed' and command['returncode']==0,'CPU E02 child failed; partial/log evidence preserved')
        result_path=native/'e02/e02-report.json';result=read(result_path)
        require(result['status']=='independent_i03_selected_e02_checks_matched' and result['scope']['target_pairs']==23 and
            result['scope']['global_KV_coordinates']==4 and result['scope']['admitted_large_sources_final_bytehash_checked']==484 and
            result['native_executions_started']==0 and result['acceptance'] is None,'independent selected E02 scope/result differs')
        proof=read(native/'e02/source-proof.json');payload=reservation/'payload';payload.mkdir()
        catalog={};total=0
        sources={str(verifier):VERIFY_SHA,str(recorder):RECORDER_SHA,str(Path(__file__).resolve()):sha(__file__)}
        sources.update({path:ref['sha256'] for path,ref in proof['checked_sources'].items() if not path.endswith(('.npy','.safetensors'))})
        for original,ref in proof['original_source_files'].items():
            if not ref['large']:sources.setdefault(original,ref['sha256'])
        # Preserve original keys even when a GPU /tmp source has only its admitted
        # copied AFS payload available. The source proof supplies that resolution.
        resolved={original:ref['actual_path'] for original,ref in proof['original_source_files'].items()}
        for index,(original,digest) in enumerate(sorted(sources.items())):
            require(time.monotonic()-started<640,'preserve finite CPU cleanup reserve')
            actual=Path(resolved.get(original,original));require(actual.is_file() and not actual.is_symlink() and actual.stat().st_size<=MAX_SMALL and sha(actual)==digest,'E02 small source/copy differs')
            total+=actual.stat().st_size;require(total<=MAX_TOTAL,'E02 metadata closure exceeds192MiB')
            relative='payload/%04d/%s'%(index,actual.name);target=payload/relative;target.parent.mkdir(parents=True)
            raw=actual.read_bytes();require(hashlib.sha256(raw).hexdigest()==digest,'small source changed before copy')
            with target.open('xb') as stream:stream.write(raw)
            catalog[original]={'path':relative,'sha256':digest,'size':len(raw)}
        put(payload/'metadata-source-map.json',{'schema_version':1,'kind':'i03-selected-e02-metadata','files':catalog,
            'source_report':result['source_report'],'omitted_large_sources':read(native/'e02/admitted-large-source-hashes.json'),
            'native_executions_started':0,'numeric_scope':result['scope'],'acceptance':None})
        state.update(status='numeric_and_small_proof_completed_pending_export',report={'path':str(result_path),'sha256':sha(result_path)},scope=result['scope'])
        put(reservation/'preexport-controller.json',state)
        archive=reservation.with_name(reservation.name+'-small.tar.gz')
        with archive.open('xb') as stream,tarfile.open(fileobj=stream,mode='w:gz') as package:
            for path in sorted(reservation.rglob('*')):
                require(time.monotonic()-started<640,'E02 packaging finite reserve exhausted');require(not path.is_symlink(),'symlink in E02 output')
                if path.is_file():package.add(path,arcname=path.relative_to(reservation).as_posix(),recursive=False)
        require(archive.stat().st_size<=MAX_GZIP,'E02 gzip exceeds32MiB')
        require(sha(verifier)==VERIFY_SHA and sha(recorder)==RECORDER_SHA and sha(controller)==controller_sha,'E02 immutable input/source changed')
        state.update(status='completed',archive={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive)},copied_small_sources=len(catalog))
        code=0
    except BaseException as exc:state.update(status='failed',error_type=type(exc).__name__,error=str(exc),partial_files_preserved=True,automatic_retry=False)
    finally:
        receipt=reservation/'controller-receipt.json';envelope=None
        try:
            if code==0:
                # Encode while the whole660s timer is still active. The final
                # controller has no self-referential envelope SHA; prepare its
                # exact bytes, write envelope, then commit those controller bytes.
                encoded=base64.b64encode(archive.read_bytes()).decode('ascii')
                state.update(returncode=0,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started)
                controller_raw=(json.dumps(state,indent=2,allow_nan=False)+'\n').encode()
                envelope=reservation.with_name(reservation.name+'-json-base64.txt')
                put(envelope,{'schema_version':1,'kind':'i03-selected-e02-small-transport','controller_path':str(receipt),
                    'controller_sha256':hashlib.sha256(controller_raw).hexdigest(),
                    'controller_raw_base64':base64.b64encode(controller_raw).decode('ascii'),
                    'archive':{**state['archive'],'base64':encoded}})
                require(envelope.stat().st_size<=64*1024**2,'E02 transfer envelope exceeds64MiB')
                with receipt.open('xb') as stream:stream.write(controller_raw)
                receipt_digest=sha(receipt);envelope_digest=sha(envelope);envelope_bytes=envelope.stat().st_size
            else:
                state.update(returncode=code,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started);put(receipt,state)
        except BaseException as exc:
            code=1;state.update(status='export_failed',returncode=1,error_type=type(exc).__name__,error=str(exc),partial_files_preserved=True,
                automatic_retry=False,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started)
            if not receipt.exists():put(receipt,state)
        finally:
            signal.setitimer(signal.ITIMER_REAL,0)
            for sig,handler in handlers.items():signal.signal(sig,handler)
    if code==0:print(json.dumps({'status':'completed','receipt':str(receipt),'receipt_sha256':receipt_digest,'archive':state['archive'],'envelope':str(envelope),
        'envelope_bytes':envelope_bytes,'envelope_sha256':envelope_digest,'native_executions_started':0}),flush=True)
    else:print(json.dumps(state),flush=True)
    return code


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True);parser.add_argument('--controller',type=Path,required=True)
    parser.add_argument('--controller-sha256',required=True);args=parser.parse_args();return run(args.root,args.controller,args.controller_sha256)


if __name__=='__main__':raise SystemExit(main())

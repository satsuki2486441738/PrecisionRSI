"""Actual pinned native mask factories on tiny CPU tensors; no model/device init."""
import os
os.environ['TORCH_DEVICE_BACKEND_AUTOLOAD'] = '0'
import hashlib
import json
from pathlib import Path
import signal
import sys


def main():
    def expire(*_): raise TimeoutError('I04 CPU mask probe60s timeout')
    signal.signal(signal.SIGALRM,expire); signal.setitimer(signal.ITIMER_REAL,60)
    try:
        import torch
        import numpy
        import transformers
        import transformers.masking_utils as masks
        import transformers.models.gemma4_unified.configuration_gemma4_unified as configuration
        from transformers import Gemma4UnifiedTextConfig
        assert str(torch.__version__).split('+')[0] == '2.9.0' and transformers.__version__ == '5.10.1' and numpy.__version__ == '1.26.4'
        assert 'torch_npu' not in sys.modules and not torch.cuda.is_initialized()
        torch.set_num_threads(2)
        config = Gemma4UnifiedTextConfig(num_hidden_layers=2,layer_types=['sliding_attention','full_attention'])
        config._attn_implementation = 'eager'; config.sliding_window = 1024
        cells = 0; observations = []
        for side,valid in [('left',[0,0,1,1]),('right',[1,1,0,0])]:
            mask = torch.tensor([[1,1,1,1],valid],dtype=torch.int64,device='cpu')
            position = (mask.cumsum(-1)-1).masked_fill(mask==0,0)
            embedded = torch.zeros((2,4,8),dtype=torch.bfloat16,device='cpu')
            prepared = masks.create_masks_for_generate(config,embedded,mask,None,position_ids=position,block_sequence_ids=torch.full_like(mask,-1))
            assert set(prepared) == {'sliding_attention','full_attention'}
            prepared.update({'direct_full':masks.create_causal_mask(config,embedded,mask,None,position_ids=position),
                'direct_sliding':masks.create_sliding_window_causal_mask(config,embedded,mask,None,position_ids=position)})
            for name,value in prepared.items():
                assert list(value.shape) == [2,1,4,4] and value.device.type == 'cpu'
                for batch in range(2):
                    for query in range(4):
                        if mask[batch,query]:
                            for key in range(4):
                                assert bool(value[batch,0,query,key] == 0) == bool(key <= query and mask[batch,key])
                                cells += 1
                observations.append({'side':side,'factory':name,'shape':list(value.shape),'dtype':str(value.dtype),'device':str(value.device)})
        assert cells == 192 and 'torch_npu' not in sys.modules and not torch.cuda.is_initialized()
        def ref(module):
            path = Path(module.__file__).resolve()
            return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size_bytes':path.stat().st_size}
        print(json.dumps({'status':'i04_cpu_only_actual_mask_factories_checked','versions':{'torch':str(torch.__version__),
            'transformers':transformers.__version__,'numpy':numpy.__version__},'sources':{name:ref(module) for name,module in
            [('torch',torch),('numpy',numpy),('transformers',transformers),('masking_utils',masks),('configuration',configuration)]},
            'observations':observations,'valid_query_key_cells_checked':cells,'torch_npu_imported':False,'cuda_initialized':False,
            'device_backend_autoload':'0','model_loads':0,'native_model_forward_calls':0,'accelerator_initializations':0,'acceptance':None}),flush=True)
        return 0
    finally: signal.setitimer(signal.ITIMER_REAL,0)


if __name__ == '__main__': raise SystemExit(main())

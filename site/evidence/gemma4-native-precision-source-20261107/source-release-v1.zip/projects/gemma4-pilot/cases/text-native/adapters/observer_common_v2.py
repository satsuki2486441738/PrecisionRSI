"""Four-call dual-proof observer capture v2; native remains initially gated.

The new stage, independent expected inventory and actual I04 numeric prerequisite
must be frozen before Torch import. Reused modules supply loading/state/RNG and
shared row derivation only; their old capture paths are never called.
"""
import argparse
from contextlib import contextmanager,nullcontext
import gc
import hashlib
import math
from pathlib import Path
import re
import shutil
import signal
import sys

import numpy as np
import i03_common_v1 as controlled
import observer_collectors_v1 as collectors

prior=controlled.prior
HERE,REPO=prior.HERE,prior.REPO
require,sha,read,put=prior.require,prior.sha,prior.read,prior.put
file_ref,check_refs=prior.file_ref,prior.check_refs
canonical,safe_relative=controlled.canonical,controlled.safe_relative
model_state,rng_observation=controlled.model_state,controlled.rng_observation
TASK='gemma4-observer-transparency-v1'
STAGE_ID='gemma4-gpu-npu-observer-v1-20261107'
STAGE_SHA256='54683b3e1697b8358e7371d516596c42db347ff04de7253231236498ad15e22d'
EXPECTED_SHA256='2f9821d74578735f2d8f1c82ec86c5f28dedc077ae7e293dce474e701cd7181a'
PREREQUISITE_SOURCE_SHA256='610e349ae0ba0be42fc683ccb7fd573255c080d835c09f07f4dee73edf98aa4c'
I04_PREREQUISITE_SHA256='59830ffb67bafb2c0497ef954392fb4fc830dc388afc16a7750195cd09986e54'
CPU_PREREQUISITE_SHA256='1c5bbfc0089a78cf5d8564a666feb11bf24144cbbb6814a7003da12cce2ebd63'
INPUT_SHA256=prior.INPUT_SHA256
REVISION,NORMALIZATION=prior.REVISION,prior.NORMALIZATION
VOCABULARY,WIDTH,NUM_LAYERS=262144,3840,48
MODES=['off-before','hooks-only','off-after','hooks-plus-dispatch-metadata']
CAPTURE_CAP=1073741824
CASE='projects/gemma4-pilot/cases/text-native'
HEX=re.compile(r'^[a-f0-9]{64}$')
MODULE_SIGNATURE='54d24190ade712b1f3a8e81e9569997fa2548a2ee41e2bc8ddc457d943da8103'
PARAMETER_SIGNATURE='35bd6ff42846d93a92980279f9194dcddd94ddd7530c20a0b171ddb87f76f768'
PINNED={**prior.PINNED,
    CASE+'/adapters/i01_common_v1.py':'fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c',
    CASE+'/adapters/i03_common_v1.py':'5cf67f53b5392e4425c4534ec6f97961066c190d24dc1280f31e66781a0fe03a',
    CASE+'/adapters/i03_prerequisite_v1.py':'e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36',
    CASE+'/adapters/observer_collectors_v1.py':'774b5cb210f294a23d6865f863d5facdf537c3ed3064ae39027425797b83101c',
    CASE+'/adapters/observer_expected_inventory_v1.py':'50a5f870d60733a842379107887365641b4f21afe43682407f6f0e94d79c5ec0',
    CASE+'/transfer/export_observer_cpu_proof_v1.py':'cbad23821a46454426a0e61a017a3adb618b8f7a319aea9c92f383d248fe2bf5'}


def arguments():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--backend',choices=['gpu','npu'],required=True)
    for name in ('model','input','allocation-receipt','stage-spec','expected-inventory','i04-prerequisite','cpu-prerequisite','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    for name in ('stage-spec-sha256','expected-inventory-sha256','i04-prerequisite-sha256','cpu-prerequisite-sha256','device'):
        parser.add_argument('--'+name,required=True)
    for name in ('numerics-policy','driver-source','native-mapping','native-source'):
        parser.add_argument('--'+name,type=Path)
    return parser.parse_args()


def coordinates(document):
    inventory=controlled.coordinates(document)
    require(len(inventory['sequence'])==160 and inventory['positions']==collectors.TOKENS,'fixed observer coordinates differ')
    return inventory


def expected_core(inventory):
    return {'schema_version':1,'task':TASK,'stage_id':STAGE_ID,'stage_spec_sha256':STAGE_SHA256,
        'input_sha256':INPUT_SHA256,'modes':MODES,'sequence':inventory['sequence'],'sample':inventory['sample'],
        'raw_logits':{'dtype':'BF16','shape':[1,160,VOCABULARY],'tensor_name':'logits','files':4},
        'targets_per_mode':159,'distribution_positions':collectors.TOKENS,'channels':collectors.CHANNELS,
        'boundaries':collectors.boundary_specs(),'sample_shape':[1,47,64],'enabled_modes':MODES[1::2],
        'module_name_class_signature_sha256':MODULE_SIGNATURE,'parameter_signature_sha256':PARAMETER_SIGNATURE,
        'numeric_data_bytes_excluding_headers':730988032,'target_distribution_pair_count':16,'primary_cross_boundary_pairs':98}


def complete_rng(observation):
    """Unknown generator bytes cannot establish the advertised RNG control."""
    require(set(observation)=={'python','numpy','torch_cpu','device0'},'complete RNG inventory differs')
    for name in ('python','numpy','torch_cpu','device0'):
        item=observation[name]
        require(isinstance(item,dict) and not item.get('unavailable') and HEX.fullmatch(item.get('sha256','')),
            'complete same-host RNG bytes unavailable: '+name)
    header=observation['numpy'].get('header',{})
    require(header.get('algorithm')=='MT19937' and header.get('word_count')==624 and
        header.get('word_encoding')=='uint32-little-endian' and type(header.get('position')) is int and
        0<=header['position']<=624 and header.get('has_gauss') in (0,1) and
        re.fullmatch('[a-f0-9]{16}',header.get('cached_gaussian_binary64_le_hex','')),
        'full NumPy RNG canonical payload descriptor differs')
    return observation


def prepare(args,entry):
    require(all(isinstance(value,str) and HEX.fullmatch(value) for value in
        (STAGE_SHA256,EXPECTED_SHA256,PREREQUISITE_SOURCE_SHA256,I04_PREREQUISITE_SHA256,CPU_PREREQUISITE_SHA256)),
        'observer stage/expected/actual I04 prerequisite source pins remain unready')
    require(not any(name in sys.modules for name in ('torch','torch_npu')),'actual I04 numeric admission must precede Torch import')
    require(args.device==('cuda:0' if args.backend=='gpu' else 'npu:0'),'one explicit selected native device required')
    require(args.stage_spec_sha256==STAGE_SHA256 and sha(args.stage_spec)==STAGE_SHA256,'observer finite stage SHA differs')
    stage=read(args.stage_spec)
    require(stage.get('stage_id')==STAGE_ID and stage.get('status')=='prepared_not_executed' and stage.get('modes')==MODES and
        stage.get('total_forward_calls_per_backend')==4 and stage.get('acceptance') is None,'frozen observer stage semantics differ')
    limits={'gpu_capture_timeout_seconds':1200,'npu_capture_timeout_seconds':1500,'whole_attempt_timeout_seconds_per_backend':3600,
        'cpu_metadata_export_whole_timeout_seconds':960,'owned_cleanup_reserve_seconds':20,'maximum_capture_product_bytes_per_backend':CAPTURE_CAP,
        'maximum_new_task_storage_bytes_per_backend':4294967296,'minimum_free_source_storage_bytes':5368709120,
        'maximum_logical_artifact_transport_bytes_per_direction':1073741824,'maximum_encoded_transport_bytes_per_direction':1610612736,
        'max_native_model_processes_per_backend':1,'automatic_native_retries':0}
    require(all(type(stage.get('limits',{}).get(k)) is int and stage['limits'][k]==v for k,v in limits.items()),'observer resource bounds differ')
    require(sha(args.input)==INPUT_SHA256,'fixed original160-token input differs')
    inventory=coordinates(read(args.input))
    require(args.expected_inventory_sha256==EXPECTED_SHA256 and sha(args.expected_inventory)==EXPECTED_SHA256,'independent observer inventory differs')
    expected=read(args.expected_inventory)
    require(all(k in expected and canonical(expected[k])==canonical(v) for k,v in expected_core(inventory).items()),'observer independent input/boundary inventory differs')
    source=HERE/'observer_prerequisite_v1.py'
    require(sha(source)==PREREQUISITE_SOURCE_SHA256 and args.i04_prerequisite_sha256==I04_PREREQUISITE_SHA256 and
        args.cpu_prerequisite_sha256==CPU_PREREQUISITE_SHA256,'actual I04/CPU prerequisite bindings differ')
    import importlib.util
    spec=importlib.util.spec_from_file_location('observer_actual_pure_i04_prerequisite',source)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    checked=helper.prerequisite(args.i04_prerequisite,args.i04_prerequisite_sha256,args.cpu_prerequisite,args.cpu_prerequisite_sha256)
    require(checked.get('native_executions_started')==0,'prerequisite checker must be pure metadata')
    require(args.output.parent.is_dir() and not args.output.exists() and not args.output.is_symlink(),'exclusive observer output required')
    require(shutil.disk_usage(args.output.parent).free>=5368709120,'observer source storage below5GiB')
    prior.check_import_paths();require(Path(controlled.__file__).resolve()==HERE/'i03_common_v1.py' and
        Path(collectors.__file__).resolve()==HERE/'observer_collectors_v1.py','actual reused/observer module paths differ')
    refs={}
    for name,digest in PINNED.items():
        refs[name]=file_ref(REPO/name);require(refs[name]['sha256']==digest,'immutable observer dependency differs')
    for name in ('observer_collectors_v1.py','observer_common_v2.py',Path(entry).name,'observer_prerequisite_v1.py'):
        refs['observer/'+name]=file_ref(HERE/name)
    for name in ('input','allocation_receipt','stage_spec','expected_inventory','i04_prerequisite','cpu_prerequisite',
            *(['numerics_policy'] if args.backend=='gpu' else ['driver_source','native_mapping','native_source'])):
        require(getattr(args,name) is not None,'required backend binding missing: '+name);refs['input/'+name]=file_ref(getattr(args,name))
    refs.update({'prerequisite/'+name:ref for name,ref in checked['refs'].items()})
    return stage,inventory,refs,checked


def initialize_output(args,proof):
    args.output.mkdir()
    for path,name in ((args.input,'input.json'),(args.stage_spec,'stage-spec.json'),(args.expected_inventory,'expected-inventory.json')):
        with (args.output/name).open('xb') as stream:stream.write(path.read_bytes())
    folder=args.output/'prerequisites';folder.mkdir()
    for side,wrapper in (('i04',args.i04_prerequisite),('cpu',args.cpu_prerequisite)):
        destination=folder/side;destination.mkdir()
        with (destination/'prerequisite.json').open('xb') as stream:stream.write(wrapper.read_bytes())
        for item in proof['proofs'][side]['refs'].values():
            original=Path(item['path']);relative=original.resolve().relative_to(wrapper.parent.resolve())
            target=destination.joinpath(*safe_relative(relative.as_posix()).parts);target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as stream:stream.write(original.read_bytes())
            require(sha(target)==item['sha256'],'original '+side+' prerequisite copy differs')


@contextmanager
def bounded_native(stage,backend):
    require(sys.platform.startswith('linux'),'bounded native observer requires POSIX timers')
    def expire(*_):raise TimeoutError('observer bounded model hash/load/capture timeout')
    previous=signal.signal(signal.SIGALRM,expire)
    signal.setitimer(signal.ITIMER_REAL,stage['limits'][backend+'_capture_timeout_seconds'])
    try:yield
    finally:signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)


def check_storage(output):
    total=0
    for path in Path(output).rglob('*'):
        require(not path.is_symlink(),'observer artifact tree contains symlink')
        if path.is_file():total+=path.stat().st_size
    require(total<=CAPTURE_CAP,'observer capture exceeds1GiB')
    return total


def actual_static_model(model):
    modules=[{'name':name,'class':type(module).__module__+'.'+type(module).__qualname__} for name,module in model.named_modules(remove_duplicate=False)]
    parameters=[{'name':name,'shape':list(p.shape),'dtype':str(p.dtype),'numel':int(p.numel())} for name,p in model.named_parameters(remove_duplicate=False)]
    objects={id(p) for _,p in model.named_parameters(remove_duplicate=False)}
    require(len(modules)==875 and collectors.signature(modules)==MODULE_SIGNATURE,'actual loaded module graph differs from frozen static reference')
    require(len(parameters)==630 and len(objects)==629 and collectors.signature(parameters)==PARAMETER_SIGNATURE,'actual loaded parameter geometry/dtype/alias signature differs')
    require(all(not module.training for _,module in model.named_modules(remove_duplicate=False)),'observer requires eval/dropout-disabled model')
    require(model.lm_head.weight is model.model.language_model.embed_tokens.weight,'actual tied parameter object differs')
    config=model.config.get_text_config();types=list(config.layer_types)
    require(len(types)==48 and [i for i,x in enumerate(types) if x=='full_attention']==[5,11,17,23,29,35,41,47],'actual attention layout differs')
    profiles=[]
    for index,kind in enumerate(types):
        attention=model.get_submodule(collectors.BLOCK_PREFIX+str(index)+'.self_attn')
        profile={'layer':index,'configured_type':kind,'q_projection_shape':list(attention.q_proj.weight.shape),
            'k_projection_shape':list(attention.k_proj.weight.shape),'v_projection_shape':None if attention.v_proj is None else list(attention.v_proj.weight.shape),
            'output_projection_shape':list(attention.o_proj.weight.shape)}
        require((profile['q_projection_shape'],profile['k_projection_shape'],profile['v_projection_shape'],profile['output_projection_shape'])==
            (([4096,3840],[2048,3840],[2048,3840],[3840,4096]) if kind=='sliding_attention' else ([8192,3840],[512,3840],None,[3840,8192])),
            'actual projection profile differs; no full-attention v_proj is invented')
        profiles.append(profile)
    return {'kind':'actual-loaded-static-model-observation','modules':modules,'parameters':parameters,
        'actual_module_count':len(modules),'actual_named_parameter_entries':len(parameters),'actual_unique_parameter_objects':len(objects),
        'module_name_class_signature_sha256':collectors.signature(modules),'parameter_signature_sha256':collectors.signature(parameters),
        'attention_profiles':profiles,'tied_embedding_head_parameter_object':True,
        'scope':'Static loaded metadata; execution is established separately only by actual hook/dispatcher observations.'}


def save_tensors(tensors,path,mode,kind):
    from safetensors.torch import save_file
    require(not path.exists(),'new observer native tensor file required')
    save_file(tensors,str(path),metadata={'task':TASK,'mode':mode,'boundary':kind})
    controlled.safetensors_header(path,{name:list(tensor.shape) for name,tensor in tensors.items()})


def derive_rows(native_cpu,inventory,directory,mode):
    raw_path=directory/'raw-native-logits.safetensors';save_tensors({'logits':native_cpu},raw_path,mode,'full native output before score processing')
    raw=file_ref(raw_path);base={'schema_version':1,'task':TASK,'mode':mode,'stage_spec_sha256':STAGE_SHA256,
        'input_sha256':INPUT_SHA256,'raw_logits_sha256':raw['sha256'],'native_logits_dtype':'torch.bfloat16',
        'logprob_dtype':'float64','normalization':NORMALIZATION};scores=[];positions=[]
    for p in range(160):
        values=native_cpu[0,p,:].double().numpy();require(np.isfinite(values).all(),'observer native valid row is nonfinite')
        if p==159:continue
        row=prior.derive_logprobs(values,dtype='float64');token=inventory['sequence'][p+1];value=float(row[token])
        require(math.isfinite(value) and value<=0,'invalid observer raw-derived target logprob')
        scores.append({'sample':inventory['sample'],'position':p+1,'prediction_position':p,'token':token,'logprob':value})
        if p in inventory['positions']:
            prefix='dist-p%03d'%p;descriptor={'path':prefix+'.npy','row':0}
            with (directory/descriptor['path']).open('xb') as stream:np.save(stream,row.reshape(1,VOCABULARY),allow_pickle=False)
            roles=(['prompt_sample'] if p in [i*127//15 for i in range(16)] else [])+(['continuation'] if p>=127 else [])
            record={**base,'sample':inventory['sample'],'position':p,'history':inventory['sequence'][:p+1],'roles':roles,
                'target_position':p+1,'token':token,'logprob':value,'scores':descriptor}
            put(directory/(prefix+'.json'),record);positions.append({**{key:record[key] for key in ('sample','position','history','roles','scores')},'record':prefix+'.json'})
        check_storage(directory.parent.parent)
    put(directory/'target-scores.json',{**base,'kind':'observer-native-target-scores','scores':scores})
    put(directory/'distributions.json',{**base,'kind':'observer-native-distribution-rows','positions':positions})
    return raw


def capture_mode(model,torch,device,inventory,directory,mode):
    directory.mkdir();enabled=mode in (MODES[1],MODES[3]);dispatch_enabled=mode==MODES[3]
    observer=collectors.Observer(model,torch,device) if enabled else None
    observation=None
    try:
        with torch.inference_mode():
            context=observer if enabled else nullcontext()
            with context:
                dispatch=observer.dispatch_mode() if dispatch_enabled else nullcontext()
                # Input construction and post-forward serialization are outside
                # the census; its scope is exactly the native model call.
                ids=torch.tensor([inventory['sequence']],dtype=torch.long,device=device)
                mask=torch.ones((1,160),dtype=torch.long,device=device)
                positions=torch.arange(160,dtype=torch.long,device=device).reshape(1,160)
                with dispatch:
                    result=model(input_ids=ids,attention_mask=mask,position_ids=positions,past_key_values=None,
                        use_cache=False,logits_to_keep=0,return_dict=True)
                require(getattr(result,'past_key_values',None) is None and getattr(result,'shared_kv_states',None) is None,'observer returned unexpected cache/shared state')
                require(list(result.logits.shape)==[1,160,VOCABULARY] and str(result.logits.dtype)=='torch.bfloat16','observer native full logits shape/dtype differs')
                native_cpu=result.logits.detach().cpu().contiguous().clone()
            if enabled:
                observation=observer.report(dispatch_enabled)
                tensors={key:value.detach().cpu().contiguous().clone() for key,value in observer.samples.items()}
                require(len(tensors)==98 and all(list(value.shape)==[1,47,64] and str(value.dtype)=='torch.bfloat16' for value in tensors.values()),'all98 native boundary snapshots required')
                save_tensors(tensors,directory/'boundary-samples.safetensors',mode,'selected detached native clones from98 boundaries')
                observation['native_samples']=file_ref(directory/'boundary-samples.safetensors')
            else:observation={'schema_version':1,'enabled':False,'status':'disabled_control','boundary_specs':collectors.boundary_specs(),
                'boundary_counts':None,'module_invocations':None,'zero_fired_modules':None,'dispatcher':{'enabled':False},
                'scope':'No module hooks or dispatcher collector installed; execution census was not measured in this control.'}
        encoded=canonical(observation).encode();require(len(encoded)<=collectors.MAX_BYTES,'actual serialized observer metadata exceeds16MiB')
        with (directory/'observer.json').open('xb') as stream:stream.write(encoded+b'\n')
    except BaseException as exc:
        failure={'status':'incomplete','mode':mode,'error_type':type(exc).__name__,'error':str(exc),
            'boundary_counts':None if observer is None else dict(observer.hook_counts),
            'observed_dispatch_calls':0 if observer is None else observer.dispatch_calls,
            'unique_dispatch_signatures':0 if observer is None else len(observer.signatures),'automatic_retry':False}
        put(directory/'observer-failure.json',failure);raise
    raw=derive_rows(native_cpu,inventory,directory,mode)
    summary={'schema_version':1,'task':TASK,'mode':mode,'native_forward_calls':1,'model_loads':0,'use_cache':False,
        'past_key_values_is_none':True,'returned_cache':None,'returned_shared_kv_states':None,'logits_to_keep':0,
        'native_logits_shape':[1,160,VOCABULARY],'native_logits_dtype':'torch.bfloat16','targets':159,'distribution_positions':47,
        'unscored_native_prediction_indices':[159],'observer_enabled':enabled,'dispatcher_enabled':dispatch_enabled,
        'boundary_snapshots':98 if enabled else 0,'raw_logits':raw,'observer':file_ref(directory/'observer.json')}
    put(directory/'capture-summary.json',summary);return summary


def capture_all(model,torch,device,inventory,output,backend,seed_callback,policy_callback,synchronize):
    (output/'modes').mkdir();static=actual_static_model(model);put(output/'observed-static-model.json',static)
    baseline=model_state(model,torch);put(output/'loaded-model-state.json',baseline);policy=policy_callback();anchor=None;summaries=[]
    for mode in MODES:
        gc.collect();synchronize();require(canonical(model_state(model,torch))==canonical(baseline),'persistent observer model state changed before mode')
        reset=seed_callback();require(canonical(policy_callback())==canonical(policy),'observer backend policy changed before mode')
        before=complete_rng(rng_observation(torch,backend))
        if anchor is None:anchor=before
        require(canonical(before)==canonical(anchor),'full same-host RNG reset state differs')
        directory=output/'modes'/mode;summary=capture_mode(model,torch,device,inventory,directory,mode);synchronize()
        after_rng=complete_rng(rng_observation(torch,backend))
        require(canonical(before)==canonical(after_rng),'observer/model consumed RNG in eval; transparency stage incomplete')
        after=model_state(model,torch);put(directory/'model-state-after.json',after)
        require(canonical(after)==canonical(baseline) and canonical(policy_callback())==canonical(policy),'observer changed persistent model state/policy')
        put(directory/'state-control.json',{'mode':mode,'seed_reset':reset,'rng_before':before,'rng_after':after_rng,
            'math_policy':policy,'baseline_model_state_sha256':sha(output/'loaded-model-state.json'),
            'model_state_after_sha256':sha(directory/'model-state-after.json'),'scope':'same loaded eval model; same-host complete RNG state; kernel/allocator warmup not reset'})
        summaries.append(summary);check_storage(output)
    gaps=[{'name':item['name'],'content_probe_gap':item['content_probe_gap']} for item in baseline['buffers'] if 'content_probe_gap' in item]
    put(output/'capture-summary.json',{'task':TASK,'modes':summaries,'native_forward_calls_total':4,'model_loads':1,
        'target_scores':636,'distribution_rows':188,'native_boundary_snapshots':196,'buffer_content_fingerprint_gaps':gaps,
        'loaded_parameter_byte_attestation':False,'acceptance':None})
    return summaries


def finalize(args,inventory,refs,runtime):
    check_refs(refs);check_refs(runtime['implementation_sources'])
    baseline=read(args.output/'loaded-model-state.json');buffers=baseline['buffers']
    runtime['buffer_content_fingerprint_coverage']={'observed_buffer_entries':len(buffers),
        'entries_with_content_sha256':sum('content_sha256' in item for item in buffers),
        'unavailable_entries':[{'name':item['name'],'content_probe_gap':item['content_probe_gap']} for item in buffers if 'content_probe_gap' in item],
        'method':'Unchanged reviewed I03 bounded8MiB probe, including retained scalar BF16 view(uint8) gap; no reshape fix under old CPU proof.',
        'complete_loaded_model_content_attested':False}
    runtime.update(task=TASK,stage_id=STAGE_ID,stage_spec_sha256=STAGE_SHA256,input_sha256=INPUT_SHA256,
        expected_inventory_sha256=EXPECTED_SHA256,i04_prerequisite_sha256=I04_PREREQUISITE_SHA256,cpu_prerequisite_sha256=CPU_PREREQUISITE_SHA256,sources=refs,
        capture_schema_version=2,source_pairing={'collector':'observer_collectors_v1.py','common':'observer_common_v2.py','native':'observer_native_v2.py',
            'prerequisite':'observer_prerequisite_v1.py'},
        modes=MODES,native_forward_calls_total=4,model_loads=1,target_scores=636,distribution_rows=188,
        boundary_snapshots=196,model_repository='google/gemma-4-12B',requested_revision=REVISION,
        native_logits_dtype='torch.bfloat16',logprob_dtype='float64',normalization=NORMALIZATION,
        thresholds=None,acceptance=None,full_core_complete=False,
        limitations=['one text input/cache-off eager','47/160 tokens and64/3840 channels sampled','frontend dispatcher metadata is not native kernel attribution',
            'upstream-propagated differences do not establish local operator cause','no training/modality/quality/eviction/multi-device coverage',
            'unchanged bounded buffer probe retains unsupported scalar BF16 content-fingerprint gap; object/storage/version/config and available fingerprints are compared, not all buffer bytes'])
    put(args.output/'runtime.json',runtime)
    files={p.relative_to(args.output).as_posix():{'sha256':sha(p),'size_bytes':p.stat().st_size} for p in sorted(args.output.rglob('*')) if p.is_file()}
    put(args.output/'artifacts-manifest.json',{'schema_version':1,'kind':'observer-capture-artifacts','task':TASK,'backend':args.backend,
        'stage_spec_sha256':STAGE_SHA256,'expected_inventory_sha256':EXPECTED_SHA256,'i04_prerequisite_sha256':I04_PREREQUISITE_SHA256,
        'cpu_prerequisite_sha256':CPU_PREREQUISITE_SHA256,'capture_schema_version':2,'files':files,'acceptance':None})
    validate_output(args.output,args.input,False);check_refs(refs)
    put(args.output/'status.json',{'status':'completed','task':TASK,'backend':args.backend,'modes':MODES,'native_forward_calls_total':4,
        'model_loads':1,'artifacts_manifest_sha256':sha(args.output/'artifacts-manifest.json'),'acceptance':None,'full_core_complete':False})
    return validate_output(args.output,args.input)


def validate_observer(observed,modules,enabled,dispatch_enabled):
    """Structural observation closure; static modules do not imply execution."""
    require(observed.get('enabled') is enabled and observed.get('dispatcher',{}).get('enabled') is dispatch_enabled,
        'observer/dispatcher enabled mode differs')
    specs=collectors.boundary_specs()
    require(observed.get('boundary_specs')==specs,'observer boundary specification differs')
    if not enabled:
        require(observed.get('status')=='disabled_control' and observed.get('boundary_counts') is None and
            observed.get('module_invocations') is None and observed.get('zero_fired_modules') is None,
            'disabled control installed or claimed an execution observer')
        return
    census=observed.get('module_invocations',[])
    require(observed.get('status')=='completed' and observed.get('error') is None and observed.get('actual_module_count')==len(modules) and
        observed.get('hook_registry_restored') is True and [{k:x[k] for k in ('name','class')} for x in census]==modules,
        'actual module census/static graph closure differs')
    require(all(type(x.get('invocations')) is int and x['invocations']>=0 and x.get('completed_invocations')==x['invocations'] for x in census),
        'actual module invocation counts are not complete nonnegative integers')
    require(census[0]['name']=='' and census[0]['invocations']==1 and
        observed.get('zero_fired_modules')==[x['name'] for x in census if x['invocations']==0] and
        observed.get('fired_module_count')==sum(x['invocations']>0 for x in census) and
        observed.get('total_module_invocations')==sum(x['invocations'] for x in census),'zero-fired/actual invocation census differs')
    require(observed.get('boundary_counts')=={x['id']:1 for x in specs},'actual boundary count differs')
    events=observed.get('boundary_events',[])
    require(len(events)==len(specs),'actual boundary event inventory differs')
    for index,(event,spec) in enumerate(zip(events,specs)):
        require(all(event.get(k)==v for k,v in spec.items()) and event.get('ordinal')==index and
            event.get('token_indices')==collectors.TOKENS and event.get('channel_indices')==collectors.CHANNELS and
            event.get('sample_shape')==[1,47,64] and event.get('sample_dtype')=='torch.bfloat16' and
            event.get('observed',{}).get('shape')==[1,160,3840] and event['observed'].get('dtype')=='torch.bfloat16',
            'actual selected boundary metadata/coordinate order differs')
    dispatcher=observed['dispatcher'];signatures=dispatcher.get('signatures',[]);count=dispatcher.get('observed_invocations')
    require(dispatcher.get('limits')=={'invocations':collectors.MAX_CALLS,'unique_signatures':collectors.MAX_SIGNATURES,'serialized_bytes':collectors.MAX_BYTES},
        'dispatcher finite metadata limits differ')
    require(type(count) is int and 0<=count<=collectors.MAX_CALLS and len(signatures)==dispatcher.get('unique_signatures') and
        len(signatures)<=collectors.MAX_SIGNATURES and type(dispatcher.get('metadata_byte_budget_accounting')) is int and
        0<=dispatcher['metadata_byte_budget_accounting']<=collectors.MAX_BYTES,'dispatcher actual count/byte cap differs')
    if dispatch_enabled:require(count>0 and len(signatures)>0,'enabled dispatcher recorded no frontend operations')
    else:require(count==0 and signatures==[] and dispatcher.get('collector_generated_excluded_operations')=={},'hooks-only mode installed dispatcher')
    names={x['name'] for x in modules};keys=set();total=0
    for item in signatures:
        key=item.get('signature_sha256');record={k:v for k,v in item.items() if k not in ('signature_sha256','count','first_invocation')}
        require(set(record)=={'operator','schema','module_scope','inputs','kwargs','outputs'} and key not in keys and
            key==collectors.signature(record) and type(item.get('count')) is int and item['count']>0 and
            type(item.get('first_invocation')) is int and 1<=item['first_invocation']<=count and
            isinstance(record['operator'],str) and isinstance(record['schema'],str) and
            isinstance(record['module_scope'],list) and record['module_scope'] and record['module_scope'][0]=='' and
            all(name in names for name in record['module_scope']),'dispatcher signature/content/scope differs')
        keys.add(key);total+=item['count']
    require(total==count and all(isinstance(k,str) and type(v) is int and v>0 for k,v in dispatcher.get('collector_generated_excluded_operations',{}).items()),
        'dispatcher aggregate/excluded-count closure differs')
    require(len(canonical(observed).encode())<=collectors.MAX_BYTES,'actual full observer metadata exceeds16MiB')


def validate_rows(folder,inventory,mode,raw_sha):
    base={'task':TASK,'mode':mode,'stage_spec_sha256':STAGE_SHA256,'input_sha256':INPUT_SHA256,
        'raw_logits_sha256':raw_sha,'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':NORMALIZATION}
    targets=read(folder/'target-scores.json');index=read(folder/'distributions.json')
    for document in (targets,index):require(all(document.get(k)==v for k,v in base.items()),'observer raw-derived score provenance differs')
    scores=targets.get('scores',[]);rows=index.get('positions',[])
    require(len(scores)==159 and len(rows)==47,'observer exact target/row inventory differs')
    for p,item in enumerate(scores):
        require({k:item.get(k) for k in ('sample','position','prediction_position','token')}==
            {'sample':inventory['sample'],'position':p+1,'prediction_position':p,'token':inventory['sequence'][p+1]} and
            type(item.get('logprob')) in (int,float) and math.isfinite(item['logprob']) and item['logprob']<=0,
            'observer exact target coordinates/value differs')
    for item,p in zip(rows,inventory['positions']):
        prefix='dist-p%03d'%p;roles=(['prompt_sample'] if p in [i*127//15 for i in range(16)] else [])+(['continuation'] if p>=127 else [])
        expected={'sample':inventory['sample'],'position':p,'history':inventory['sequence'][:p+1],'roles':roles,
            'scores':{'path':prefix+'.npy','row':0},'record':prefix+'.json'}
        require(item==expected,'observer exact distribution coordinates/history differs')
        record=read(folder/item['record'])
        require(all(record.get(k)==v for k,v in base.items()) and all(record.get(k)==v for k,v in expected.items() if k!='record') and
            record.get('target_position')==p+1 and record.get('token')==inventory['sequence'][p+1] and record.get('logprob')==scores[p]['logprob'],
            'observer row JSON provenance/selected target differs')
        values=np.load(folder/(prefix+'.npy'),allow_pickle=False,mmap_mode='r')
        try:
            require(values.shape==(1,VOCABULARY) and values.dtype==np.dtype('float64') and np.isfinite(values).all() and
                (values<=0).all() and float(values[0,record['token']])==record['logprob'],'observer full FP64 row shape/finite/selected value differs')
        finally:
            mapping=getattr(values,'_mmap',None)
            if mapping is not None:mapping.close()


def validate_output(output,input_path,require_completed=True):
    """Offline schema/hash check; independent admission must redo all math."""
    output=Path(output);require(output.is_dir() and not output.is_symlink() and sha(input_path)==INPUT_SHA256,'observer retained input differs')
    inventory=coordinates(read(input_path))
    require(sha(output/'input.json')==INPUT_SHA256 and sha(output/'stage-spec.json')==STAGE_SHA256 and
        sha(output/'expected-inventory.json')==EXPECTED_SHA256,'observer retained input/stage/expected bytes differ')
    require(sha(output/'prerequisites/i04/prerequisite.json')==I04_PREREQUISITE_SHA256 and
        sha(output/'prerequisites/cpu/prerequisite.json')==CPU_PREREQUISITE_SHA256,'retained actual dual prerequisites differ')
    source=HERE/'observer_prerequisite_v1.py';require(sha(source)==PREREQUISITE_SOURCE_SHA256,'reviewed dual-proof checker source differs')
    import importlib.util
    spec=importlib.util.spec_from_file_location('observer_retained_dual_proof_checker',source);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    helper.prerequisite(output/'prerequisites/i04/prerequisite.json',I04_PREREQUISITE_SHA256,
        output/'prerequisites/cpu/prerequisite.json',CPU_PREREQUISITE_SHA256)
    manifest=read(output/'artifacts-manifest.json');files=manifest['files']
    require(manifest.get('kind')=='observer-capture-artifacts' and manifest.get('task')==TASK and manifest.get('stage_spec_sha256')==STAGE_SHA256 and
        manifest.get('capture_schema_version')==2 and manifest.get('i04_prerequisite_sha256')==I04_PREREQUISITE_SHA256 and
        manifest.get('cpu_prerequisite_sha256')==CPU_PREREQUISITE_SHA256,
        'observer artifact manifest identity differs')
    expected=set(files)|{'artifacts-manifest.json'}|({'status.json'} if require_completed else set())
    require({p.relative_to(output).as_posix() for p in output.rglob('*') if p.is_file()}==expected,'observer artifact inventory is not exact')
    for name,ref in files.items():
        safe_relative(name);path=output/name;require(not path.is_symlink() and ref=={'sha256':sha(path),'size_bytes':path.stat().st_size},'observer original artifact bytes differ')
    static=read(output/'observed-static-model.json');modules=static['modules']
    require(len(modules)==875 and collectors.signature(modules)==MODULE_SIGNATURE and
        collectors.signature(static['parameters'])==PARAMETER_SIGNATURE and static.get('actual_unique_parameter_objects')==629,
        'actual loaded static module/parameter observation differs')
    baseline=read(output/'loaded-model-state.json');baseline_sha=sha(output/'loaded-model-state.json');anchor=None;policy=None
    for mode in MODES:
        folder=output/'modes'/mode;summary=read(folder/'capture-summary.json');observed=read(folder/'observer.json')
        enabled=mode in MODES[1::2];dispatch=mode==MODES[3]
        require(summary.get('task')==TASK and summary.get('mode')==mode and summary.get('native_forward_calls')==1 and
            summary.get('targets')==159 and summary.get('distribution_positions')==47 and summary.get('use_cache') is False and
            summary.get('past_key_values_is_none') is True and summary.get('returned_cache') is None and summary.get('returned_shared_kv_states') is None and
            summary.get('logits_to_keep')==0 and summary.get('native_logits_shape')==[1,160,VOCABULARY] and
            summary.get('native_logits_dtype')=='torch.bfloat16' and summary.get('unscored_native_prediction_indices')==[159] and
            summary.get('observer_enabled') is enabled and summary.get('dispatcher_enabled') is dispatch and
            summary.get('boundary_snapshots')==(98 if enabled else 0),'observer per-mode product count/control differs')
        controlled.safetensors_header(folder/'raw-native-logits.safetensors',{'logits':[1,160,VOCABULARY]})
        require(summary.get('raw_logits')==file_ref(folder/'raw-native-logits.safetensors') and summary.get('observer')==file_ref(folder/'observer.json'),
            'observer original raw/metadata reference differs')
        validate_rows(folder,inventory,mode,summary['raw_logits']['sha256']);validate_observer(observed,modules,enabled,dispatch)
        require(canonical(read(folder/'model-state-after.json'))==canonical(baseline),'persistent observed model state changed')
        state=read(folder/'state-control.json');before=complete_rng(state['rng_before']);after=complete_rng(state['rng_after'])
        if anchor is None:anchor=before;policy=state['math_policy']
        require(state.get('mode')==mode and canonical(before)==canonical(after)==canonical(anchor) and
            canonical(state['math_policy'])==canonical(policy) and state.get('baseline_model_state_sha256')==baseline_sha and
            state.get('model_state_after_sha256')==sha(folder/'model-state-after.json'),'complete observed same-state/RNG/policy chain differs')
        required={'raw-native-logits.safetensors','target-scores.json','distributions.json','observer.json','capture-summary.json','model-state-after.json','state-control.json'}
        required|={f'dist-p{p:03d}.{suffix}' for p in inventory['positions'] for suffix in ('json','npy')}
        if enabled:
            controlled.safetensors_header(folder/'boundary-samples.safetensors',{x['id']:[1,47,64] for x in collectors.boundary_specs()})
            require(observed.get('native_samples')==file_ref(folder/'boundary-samples.safetensors'),'original boundary samples reference differs')
            required.add('boundary-samples.safetensors')
        require({p.name for p in folder.iterdir()}==required,'observer per-mode exact product inventory differs')
    if require_completed:require(read(output/'status.json').get('artifacts_manifest_sha256')==sha(output/'artifacts-manifest.json'),'observer terminal manifest binding differs')
    return {'status':'observer_output_artifacts_checked','modes':MODES,'native_forward_calls_total':4,'model_loads':1,
        'target_scores':636,'distribution_rows':188,'boundary_snapshots':196,'primary_cross_boundary_pairs':98,
        'artifacts_manifest_sha256':sha(output/'artifacts-manifest.json'),'output_bytes':check_storage(output),'numeric_admission':'pending','acceptance':None}

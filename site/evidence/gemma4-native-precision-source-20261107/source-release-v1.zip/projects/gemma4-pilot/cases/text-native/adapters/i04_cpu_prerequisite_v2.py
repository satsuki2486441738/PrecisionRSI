"""Pure-stdlib gate for actual I04 CPU validation before any native query.

Twenty-one copied original documents prove the two fresh CPU test processes and
actual pinned mask-factory probe. No framework, model or subprocess is started.
The externally frozen portable-wrapper SHA is mandatory and never inferred.
"""
import hashlib
import importlib.util
import math
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
OLD_HELPER_SHA = '8d42c0eb525c92c23c5324dc751149b47f3c20b8e74d65d4ba76de6c1ca068f0'
old_path = HERE/'i04_prerequisite_v1.py'
if not old_path.is_file() or old_path.is_symlink() or hashlib.sha256(old_path.read_bytes()).hexdigest() != OLD_HELPER_SHA:
    raise ValueError('frozen pure-stdlib I03 prerequisite utility source differs')
spec = importlib.util.spec_from_file_location('i04_cpu_proof_pinned_utilities',old_path)
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
require,sha,read,file_ref = old.require,old.sha,old.read,old.file_ref
canonical,absolute,relative,flag,utc = old.canonical,old.absolute,old.relative,old.flag,old.utc

CASE = 'projects/gemma4-pilot/cases/text-native'
OPS = CASE+'/transfer/i04_cpu_stage_operations_v3.py'
PROBE = CASE+'/transfer/i04_cpu_mask_probe_v2.py'
EXPECTED_TEST = CASE+'/adapters/test_i04_expected_inventory_v1.py'
CAPTURE_TEST = CASE+'/adapters/test_i04_capture_v2.py'
STAGE_SHA = '26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
I03_PROOF_SHA = '3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c'
I03_REPORT_SHA = 'c1cefa946eef3530384f2c43c538c2d59a6433e16f993dc157850e915f21ac87'
EXPECTED_SHA = '22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76'
MANIFEST_SHA = '4dd494de15898f1a43fb31c19ead9ee8c52ca46e9c23096e5f49b42aec340b3b'
OPS_SHA = '36973a846475161e3ab05ff65c75bd56a535bcaad2056f3e42e6fa498d4002a2'
PROBE_SHA = '036788fadb665d766bed7c6ea4832ae0d80732eb588f06df5abee96f955429f1'
EXPECTED_TEST_SHA = 'f567bc9397a801593e49efe081e97510c550e88eb0245aa7a5eadba7e732ce99'
CAPTURE_TEST_SHA = '5b07f6f30e87b4005876d0fa26dbcb8896136430681b9b3ed77aef0181cf962f'
HEX = re.compile(r'^[a-f0-9]{64}$')
RUNTIME_NAMES = {'torch','numpy','transformers','masking_utils','configuration','import_utils','torch_npu_npu'}
LOG_NAMES = {name+'_'+stream for name in ('expected','capture','probe') for stream in ('stdout','stderr')}
SINGLES = ('controller','startup_receipt','stage_receipt','source_manifest','operations_source','probe_source')


def exact_int(value,expected): return type(value) is int and value == expected


def prerequisite(path,digest):
    path = Path(path)
    require(isinstance(digest,str) and HEX.fullmatch(digest) and file_ref(path,65536)['sha256'] == digest,'CPU prerequisite wrapper SHA differs')
    doc = read(path)
    require(set(doc) == {'schema_version','kind','stage_spec_sha256','i03_prerequisite_sha256','expected_inventory_sha256',
        'test_sources','test_logs','runtime_sources',*SINGLES} and exact_int(doc['schema_version'],1) and
        doc['kind'] == 'i04-cpu-validation-prerequisite-v2' and doc['stage_spec_sha256'] == STAGE_SHA and
        doc['i03_prerequisite_sha256'] == I03_PROOF_SHA and doc['expected_inventory_sha256'] == EXPECTED_SHA,
        'complete actual I04 CPU prerequisite required')
    require(set(doc['test_sources']) == {'expected','capture'} and set(doc['test_logs']) == LOG_NAMES and
        set(doc['runtime_sources']) == RUNTIME_NAMES,'all fresh-test/probe/runtime proof documents required')
    refs = {name:doc[name] for name in SINGLES}
    for group in ('test_sources','test_logs','runtime_sources'): refs.update({group+'/'+name:ref for name,ref in doc[group].items()})
    require(len(refs) == 21 and len({r.get('path') for r in refs.values() if isinstance(r,dict)}) == 21 and
        len({r.get('source_path') for r in refs.values() if isinstance(r,dict)}) == 21,'twenty-one distinct original/copy paths required')
    observed = {}
    for name,ref in refs.items():
        require(isinstance(ref,dict) and set(ref) == {'path','source_path','sha256'} and isinstance(ref['sha256'],str) and HEX.fullmatch(ref['sha256']),
            'invalid original CPU proof reference')
        rel = relative(ref['path']); absolute(ref['source_path']); actual = path.parent.joinpath(*rel.parts)
        require(actual.resolve().is_relative_to(path.parent.resolve()),'CPU proof copy escapes bundle')
        current = actual
        while current != path.parent:
            require(not current.is_symlink(),'CPU proof path contains symlink'); current = current.parent
        observed[name] = file_ref(actual)
        require(observed[name]['sha256'] == ref['sha256'],'copied original CPU proof bytes differ')
    for name,expected in [('source_manifest',MANIFEST_SHA),('operations_source',OPS_SHA),('probe_source',PROBE_SHA),
            ('test_sources/expected',EXPECTED_TEST_SHA),('test_sources/capture',CAPTURE_TEST_SHA)]:
        require(refs[name]['sha256'] == expected,'frozen CPU code/source-manifest identity differs')
    load = lambda name:read(observed[name]['path'])
    controller,start,stage,manifest = (load(name) for name in ('controller','startup_receipt','stage_receipt','source_manifest'))
    require(controller.get('task') == 'I04-CPU-validation' and controller.get('status') == 'completed' and exact_int(controller.get('returncode'),0) and
        exact_int(controller.get('CPU_tests_passed'),21) and exact_int(controller.get('CPU_tests_skipped'),0) and
        canonical(controller.get('CPU_test_groups_passed')) == canonical({'expected':8,'capture':13}) and
        exact_int(controller.get('native_executions_started'),0) and exact_int(controller.get('model_loads'),0) and controller.get('native_claim_created') is False,
        'actual21-test zero-skip CPU-only success required')
    require(exact_int(controller.get('whole_timeout_seconds'),300) and exact_int(controller.get('work_timeout_seconds'),240) and
        exact_int(controller.get('owned_cleanup_reserve_seconds'),20) and type(controller.get('elapsed_seconds')) in (int,float) and
        math.isfinite(controller['elapsed_seconds']) and 0 <= controller['elapsed_seconds'] <= 240 and controller.get('manifest_sha256') == MANIFEST_SHA,
        'actual finite CPU validation boundary differs')
    require(controller.get('automatic_retry') is False and controller.get('module_import_policy') == 'observed_not_forbidden' and
        exact_int(controller.get('agent_hardware_or_availability_queries'),0) and
        controller.get('library_internal_availability_queries') == 'not_counted_and_not_prohibited',
        'CPU controller import/initialization/query scope differs')
    expected_check = {'prerequisite_sha256':I03_PROOF_SHA,'prior_report_sha256':I03_REPORT_SHA,'original_proof_documents_checked':8,
        'expected_inventory_sha256':EXPECTED_SHA,'native_executions_started':0}
    require(canonical(controller.get('before')) == canonical(expected_check) and canonical(controller.get('after')) == canonical(expected_check),
        'CPU before/after actual I03 proof and independent expected identity differ')
    source = absolute(controller['source']); target = source.parent; run = absolute(doc['controller']['source_path']).parent
    require(source.name == 'source' and target.name == 'cpu-stage-v3' and target.parent.name == 'i04-batch-padding-20261107' and
        run.parent == target/'runs' and absolute(doc['startup_receipt']['source_path']) == target/'cpu-validation-v3-start.json' and
        absolute(doc['stage_receipt']['source_path']) == target/'stage-receipt.json' and absolute(doc['source_manifest']['source_path']) == target/'source-manifest.json',
        'original CPU stage/run namespace differs')
    base = target.parent.parent
    require(absolute(doc['operations_source']['source_path']) == base/'i04_cpu_stage_operations_v3.py' and
        absolute(doc['probe_source']['source_path']) == source/PROBE and absolute(doc['test_sources']['expected']['source_path']) == source/EXPECTED_TEST and
        absolute(doc['test_sources']['capture']['source_path']) == source/CAPTURE_TEST,'original CPU source paths differ')
    argv = start.get('argv')
    require(start.get('status') == 'cpu_validation_spawned_not_result' and start.get('automatic_retry') is False and
        start.get('ops_sha256') == OPS_SHA and start.get('manifest_sha256') == MANIFEST_SHA and
        start.get('stage_receipt_sha256') == doc['stage_receipt']['sha256'] and exact_int(start.get('total_cpu_seconds'),300) and
        exact_int(start.get('native_executions_started'),0) and exact_int(start.get('model_loads'),0) and start.get('native_claim_created') is False and
        type(start.get('pid')) is int and start['pid'] > 0 and type(start.get('starttime')) is int and start['starttime'] > 0 and
        argv == [str(base/'venv/bin/python'),'-B',doc['operations_source']['source_path'],'run','--base',str(base),'--manifest-sha256',MANIFEST_SHA] and
        utc(start['started_utc']) <= utc(controller['started_utc']) < utc(controller['finished_utc']),'actual CPU startup PID/argv/source chain differs')
    require(stage.get('status') == 'i04_cpu_stage_checked_not_native' and stage.get('source') == str(source) and stage.get('manifest_sha256') == MANIFEST_SHA and
        exact_int(stage.get('files_checked'),38) and exact_int(stage.get('model_loads'),0) and stage.get('native_claim_created') is False and
        all(key in stage and canonical(stage[key]) == canonical(value) for key,value in expected_check.items()),'original static CPU stage proof differs')
    require(manifest.get('kind') == 'i04-cpu-only-stage-bundle-v3' and manifest.get('stage_spec_sha256') == STAGE_SHA and
        manifest.get('i03_prerequisite_sha256') == I03_PROOF_SHA and manifest.get('expected_inventory_sha256') == EXPECTED_SHA and
        exact_int(manifest.get('native_executions_started'),0) and exact_int(manifest.get('model_loads'),0) and
        exact_int(manifest.get('expected_CPU_tests'),21) and len(manifest.get('files',{})) == 38,'original38-file CPU source closure differs')
    for name,source_digest in [(OPS,OPS_SHA),(PROBE,PROBE_SHA),(EXPECTED_TEST,EXPECTED_TEST_SHA),(CAPTURE_TEST,CAPTURE_TEST_SHA),
            (CASE+'/i04-stage-v1.json',STAGE_SHA),(CASE+'/transfer/i04-independent-expected-20261107.json',EXPECTED_SHA),
            (CASE+'/adapters/i04_prerequisite_v1.py',OLD_HELPER_SHA)]:
        require(manifest['files'][name]['sha256'] == source_digest,'CPU manifest fixed source differs')
    steps = controller.get('steps',[]); require(len(steps) == 3,'two fresh tests and one actual CPU probe required')
    groups = [('expected','test_i04_expected_inventory_v1',8,30),('capture','test_i04_capture_v2',13,150),('probe',None,None,60)]
    pids = []
    for step,(name,module,count,timeout) in zip(steps,groups):
        expected_argv = [argv[0],'-B','-m','unittest','-v',module] if module else [argv[0],'-B',doc['probe_source']['source_path']]
        require(step.get('argv') == expected_argv and exact_int(step.get('returncode'),0) and step.get('timed_out') is False and
            exact_int(step.get('timeout_seconds'),timeout) and step.get('cleanup',{}).get('remaining_owned_process_group') is False and
            type(step['cleanup'].get('owned_process_group')) is int and step['cleanup']['owned_process_group'] > 0,
            'actual fresh CPU step argv/timeout/group-cleanup differs')
        pids.append(step['cleanup']['owned_process_group'])
        for stream in ('stdout','stderr'):
            ref = doc['test_logs'][name+'_'+stream]; raw = observed['test_logs/'+name+'_'+stream]; recorded = step[stream]
            require(recorded == {'path':ref['source_path'],'sha256':ref['sha256'],'bytes':raw['size_bytes']} and
                absolute(ref['source_path']) == run/(name+'.'+stream if name != 'probe' else 'mask-probe.'+stream), 'actual original CPU log byte/path chain differs')
        if module:
            log = Path(observed['test_logs/'+name+'_stderr']['path']).read_text(errors='replace')
            require('Ran '+str(count)+' tests' in log and 'skipped' not in log and log.rstrip().endswith('OK'),'actual fresh CPU test count/zero skips differs')
            if name == 'capture': require('test_pinned_factory_masks_valid_queries_for_both_padding_sides' in log,'actual mask factory test absent')
    require(len(set(pids)) == 3 and start['pid'] not in pids,'fresh CPU processes must have distinct owned groups')
    probe = load('test_logs/probe_stdout')
    require(canonical(probe) == canonical(controller.get('actual_mask_probe')) and probe.get('status') == 'i04_cpu_only_actual_mask_factories_checked' and
        exact_int(probe.get('valid_query_key_cells_checked'),192) and probe.get('versions') == {'torch':'2.9.0+cpu','transformers':'5.10.1','numpy':'1.26.4'} and
        probe.get('torch_npu_imported') is True and probe.get('npu_initialized') is False and probe.get('cuda_initialized') is False and
        probe.get('device_backend_autoload') == '0' and probe.get('device_initialization_checks') == 'getter_only' and
        probe.get('library_internal_availability_queries') == 'not_counted_and_not_prohibited' and
        all(exact_int(probe.get(key),0) for key in ('model_loads','native_model_forward_calls',
            'agent_accelerator_initialization_requests','agent_hardware_or_availability_queries')),
        'actual CPU factory/version/no-accelerator evidence differs')
    phases = probe.get('phase_observations',[])
    require([x.get('phase') for x in phases] == ['after_torch','after_transformers','after_configuration',
        'after_masking_utils','before_masks','after_masks'],'six ordered actual CPU import/mask phases required')
    for index,item in enumerate(phases):
        require(set(item) == {'phase','torch_npu_imported','npu_namespace_registered','npu_initialized','cuda_initialized'} and
            item['cuda_initialized'] is False and
            (item['torch_npu_imported'] is False and item['npu_namespace_registered'] is False and item['npu_initialized'] is None if index < 2 else
             item['torch_npu_imported'] is True and item['npu_namespace_registered'] is True and item['npu_initialized'] is False),
            'actual CPU import/registration/initialization phase differs')
    observations = probe.get('observations',[])
    require(len(observations) == 8 and {(x['side'],x['factory']) for x in observations} ==
        {(side,factory) for side in ('left','right') for factory in ('sliding_attention','full_attention','direct_full','direct_sliding')} and
        all(x['shape'] == [2,1,4,4] and x['dtype'] == 'torch.bfloat16' and x['device'] == 'cpu' for x in observations), 'actual CPU mask observations differ')
    require(set(probe.get('sources',{})) == RUNTIME_NAMES,'all seven actual imported CPU source observations required')
    for name,ref in doc['runtime_sources'].items():
        actual = observed['runtime_sources/'+name]
        require(probe['sources'][name] == {'path':ref['source_path'],'sha256':ref['sha256'],'size_bytes':actual['size_bytes']} and
            ref['source_path'].endswith(('.py','.pyi')),'actual imported CPU source bytes/path differ')
    require(doc['runtime_sources']['import_utils']['source_path'].endswith('/transformers/utils/import_utils.py') and
        doc['runtime_sources']['torch_npu_npu']['source_path'].endswith('/torch_npu/npu/__init__.py'),
        'actual Transformers availability/TorchNPU state-getter source roles differ')
    for ref in observed.values(): require(sha(ref['path']) == ref['sha256'],'CPU prerequisite copy changed during checks')
    require(sha(path) == digest,'CPU prerequisite wrapper changed during checks')
    return {'document':doc,'refs':observed,'prerequisite_sha256':digest,'native_executions_started':0,
        'limitations':['Copied receipts and source hashes are not scheduler attestation.',
            'CPUv3 step cwd is determined by pinned ops source; it is not a separately recorded per-step OS observation.',
            'Backend module import is observed. Library-internal availability checks are not counted or prohibited; state getters verify uninitialized NPU/CUDA at six observed phases.']}

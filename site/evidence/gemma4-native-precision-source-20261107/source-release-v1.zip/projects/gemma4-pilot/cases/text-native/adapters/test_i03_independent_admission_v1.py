"""Synthetic CPU BF16/causal/cache/KV regressions, never native model results.

No Torch/collector import. Tiny vocabulary/KV dimensions are patched in-process;
production CLI has no dimension/source-pin overrides.
"""
from contextlib import ExitStack
import copy
from collections import Counter
import json
import math
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import i03_artifact_admission_v1 as n
import admit_i03_partition_repeat_v1 as a


def write(path,doc):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(doc,indent=2,allow_nan=False)+'\n',encoding='utf-8');return path


def rng():
    return {'python':{'format':'untruncated Python random.getstate tuple repr UTF8','sha256':'1'*64},
        'numpy':{'format':'canonical-JSON-header UTF8 + NUL + complete uint32LE state words','sha256':'2'*64,
            'header':{'version':1,'algorithm':'MT19937','word_count':624,'word_encoding':'uint32-little-endian','position':624,'has_gauss':0,
                'cached_gaussian_binary64_le_hex':'0000000000000000'}},
        'torch_cpu':{'format':'complete Torch generator state ByteTensor bytes','sha256':'3'*64},
        'device0':{'format':'complete Torch generator state ByteTensor bytes','sha256':'4'*64}}


def cache(prefix,types,device='npu:0'):
    if prefix==0:return {'present':False,'sequence_length':0,'layers':[]}
    layers=[]
    for index,kind in enumerate(types):
        heads,dim=(n.SLIDING_HEADS,n.SLIDING_DIM) if kind=='sliding_attention' else (n.FULL_HEADS,n.FULL_DIM)
        shape=[1,heads,prefix,dim]
        tensor={'shape':shape,'dtype':'torch.bfloat16','device':device,'numel':math.prod(shape),'stride':[heads*prefix*dim,prefix*dim,dim,1],
            'version':0,'storage':{'data_ptr':100000+index*1000+prefix,'nbytes':math.prod(shape)*2,'offset':0}}
        layers.append({'index':index,'class':'synthetic.DynamicLayer','configured_attention':kind,'sequence_length':prefix,
            'is_sliding':False,'sliding_window':None,'is_initialized':True,'keys':copy.deepcopy(tensor),'values':copy.deepcopy(tensor)})
    return {'present':True,'class':'synthetic.DynamicCache','sequence_length':prefix,'offloading':False,'layers':layers}


def safetensors(path,tensors):
    header={};payload=bytearray()
    for key,bits in tensors.items():
        start=len(payload);payload.extend(bits.astype('<u2').tobytes());header[key]={'dtype':'BF16','shape':list(bits.shape),'data_offsets':[start,len(payload)]}
    raw=json.dumps(header,separators=(',',':')).encode();raw+=b' '*(-len(raw)%8)
    path.write_bytes(struct.pack('<Q',len(raw))+raw+payload)


class Endpoint:
    def __init__(self,root):self.root=Path(root);self.files={}
    def add(self,logical,value):
        path=self.root/('file-%04d'%len(self.files)+Path(logical).suffix)
        if isinstance(value,bytes):path.write_bytes(value)
        else:write(path,value)
        self.files[logical]=path;return path
    def get(self,name,digest=None):
        path=self.files[name]
        if digest is not None:n.require(n.sha(path)==digest,'synthetic mapped hash differs')
        return path
    def json(self,name,digest=None):return n.load(self.get(name,digest))


class Fixture:
    def __init__(self,root,mode='full-r1',device='npu:0'):
        self.root=Path(root);self.endpoint=Endpoint(root);self.output='/synthetic/non-native/artifacts';self.mode=mode;self.prefix=self.output+'/modes/'+mode
        self.doc={'sample':'synthetic-only','prompt':list(range(128)),'continuation':list(range(32))};self.endpoint.add(self.output+'/input.json',self.doc)
        self.inventory=n.expected.derive(self.doc,n.expected.INPUT_SHA256,n.expected.STAGE_SHA256);self.plan=next(m for m in self.inventory['modes'] if m['id']==mode)
        self.types=['full_attention' if i%6==5 else 'sliding_attention' for i in range(48)]
        self.baseline={'synthetic_fixture':True};self.baseline_sha='a'*64;self.policy={'synthetic_fixture':True};self.device=device
        sequence=self.doc['prompt']+self.doc['continuation'];values=((np.arange(160)[:,None]*7+np.arange(128)[None,:]*11)%47-23).astype('<f4')/4
        self.raw=self.endpoint.add(self.prefix+'/raw-native-logits.safetensors',b'');safetensors(self.raw,{'logits':(values[None].view('<u4')>>16).astype('<u2')})
        raw_sha=n.sha(self.raw);z=values.astype(np.float64);z-=z.max(axis=1)[:,None];lp=z-np.log(np.exp(z).sum(axis=1))[:,None]
        base={'schema_version':1,'task':n.expected.TASK,'mode':mode,'stage_spec_sha256':n.STAGE_SHA,'input_sha256':n.INPUT_SHA,
            'raw_logits_sha256':raw_sha,'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':n.NORMALIZATION}
        scores=[{**coord,'prediction_position':i,'logprob':float(lp[i,sequence[i+1]])} for i,coord in enumerate(self.inventory['all_targets'])]
        self.product('target-scores.json',{**base,'kind':'i03-native-target-scores','scores':scores});positions=[]
        for coord in self.inventory['distribution_positions']:
            p=coord['position'];name='dist-p%03d'%p;roles=(['prompt_sample'] if p in [i*127//15 for i in range(16)] else [])+(['continuation'] if p>=127 else [])
            descriptor={'path':name+'.npy','row':0};positions.append({**coord,'roles':roles,'scores':descriptor,'record':name+'.json'})
            self.product(name+'.json',{**base,**coord,'roles':roles,'target_position':p+1,'token':sequence[p+1],'logprob':scores[p]['logprob'],'scores':descriptor})
            path=self.endpoint.add(self.prefix+'/'+name+'.npy',b'');np.save(path,lp[p:p+1],allow_pickle=False)
        self.product('distributions.json',{**base,'kind':'i03-native-distribution-rows','positions':positions})
        events=[]
        for call in self.plan['calls']:
            events.append({**call,'mode':mode,'use_cache':self.plan['use_cache'],'past_key_values_is_none':call['call_index']==0,
                'logits_to_keep':0,'labels_supplied':False,'shared_kv_states_supplied':False,
                'native_logits_shape':[1,call['end']-call['start'],128],'native_logits_dtype':'torch.bfloat16',
                'cache_before':cache(call['start'] if self.plan['use_cache'] else 0,self.types,device),
                'cache_after':cache(call['end'] if self.plan['use_cache'] else 0,self.types,device)})
        self.product('events.json',events);self.product('model-state-after.json',self.baseline)
        reset={'seed':0,'settings':self.policy}
        if device=='cuda:0':reset.update(python_random_seed=0,numpy_seed=0,torch_initial_seed=0,cuda_initial_seed=0)
        self.product('state-control.json',{'mode':mode,'seed_reset':reset,'rng_before':rng(),'rng_after':rng(),'math_policy':self.policy,
            'baseline_model_state_sha256':self.baseline_sha,'model_state_after_sha256':n.sha(self.path('model-state-after.json'))})
        if self.plan['use_cache']:
            descriptors=n.layer_descriptors(self.types,160);path=self.endpoint.add(self.prefix+'/final-native-kv.safetensors',b'')
            safetensors(path,{key:np.full(shape,0x3f80,dtype='<u2') for key,shape in descriptors.items()})
            items=[{'key':key,'layer':int(key.split('.')[0].split('-')[1]),'kind':key.split('.')[1],'shape':shape,'dtype':'BF16','data_bytes':math.prod(shape)*2,
                'array':{'path':'final-native-kv.safetensors','key':key}} for key,shape in descriptors.items()]
            self.product('final-cache.json',{'schema_version':1,'kind':'i03-final-native-cache','task':n.expected.TASK,'mode':mode,
                'input_sha256':n.INPUT_SHA,'stage_spec_sha256':n.STAGE_SHA,'native_dtype':'torch.bfloat16','data_bytes':n.KV_BYTES,
                'cache':cache(160,self.types,device),'tensors':items,'safetensors':n.file_ref(self.endpoint,self.prefix+'/final-native-kv.safetensors')})
        else:self.product('final-cache.json',{'schema_version':1,'task':n.expected.TASK,'mode':mode,'cache':None})
        self.product('capture-summary.json',{'schema_version':1,'task':n.expected.TASK,'mode':mode,'native_forward_calls':self.plan['native_forward_calls'],
            'use_cache':self.plan['use_cache'],'cached_decode_calls':self.plan['cached_decode_calls'],'native_logits_shape':[1,160,128],
            'native_logits_dtype':'torch.bfloat16','targets':159,'sampled_distributions':47,'unscored_native_prediction_indices':[159],
            'raw_logits':n.file_ref(self.endpoint,self.prefix+'/raw-native-logits.safetensors'),
            'final_cache_sequence_length':160 if self.plan['use_cache'] else None,'final_kv_tensors':96 if self.plan['use_cache'] else 0})
    def product(self,name,doc):return self.endpoint.add(self.prefix+'/'+name,doc)
    def path(self,name):return self.endpoint.get(self.prefix+'/'+name)
    def edit(self,name,fn):
        path=self.path(name);doc=n.load(path);fn(doc);write(path,doc)
    def inspect(self):return n.inspect_mode(self.endpoint,self.output,self.mode,self.plan,self.inventory,self.types,self.baseline,self.baseline_sha,self.policy,self.device)


class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.stack=ExitStack()
        self.stack.enter_context(patch.multiple(n,VOCABULARY=128,SLIDING_HEADS=2,SLIDING_DIM=3,FULL_HEADS=1,FULL_DIM=2,KV_BYTES=163840))
        self.stack.enter_context(patch.object(n.old,'VOCABULARY',128));self.stack.enter_context(patch.object(n.expected,'VOCABULARY',128))
    def tearDown(self):self.stack.close();self.tmp.cleanup()
    def fixture(self,mode='full-r1',device='npu:0'):
        folder=Path(self.tmp.name)/('fixture-%d'%len(list(Path(self.tmp.name).iterdir())));folder.mkdir();return Fixture(folder,mode,device)
    def test_fixed23_scores4_kv_comparison_inventory(self):
        scores,kv=a.pairs();self.assertEqual(len(scores),23);self.assertEqual(len(kv),4)
        self.assertEqual(Counter(x[-1] for x in scores),{'within_process_full_repeat':6,'within_process_partition':6,'cross_backend_full':9,'cross_backend_cached':2})
    def test_full_raw15947_independent_rederivation(self):
        result=self.fixture().inspect();self.assertEqual((len(result['scores']),len(result['positions'])),(159,47));self.assertIsNone(result['final_kv'])
        self.assertLessEqual(result['raw_derivation_max_abs_delta'],1e-12)
    def test_token33_chunk34_fresh_cache_and_actual_non_sliding_class(self):
        for mode,count in [('token',33),('chunk63-65',34)]:
            fixture=self.fixture(mode);result=fixture.inspect();self.assertEqual(len(fixture.plan['calls']),count)
            self.assertEqual(result['final_kv']['tensor_count'],96);self.assertEqual(result['final_kv']['finite_coordinate_count'],81920)
            self.assertTrue(all(layer['class']=='synthetic.DynamicLayer' and layer['is_sliding'] is False for layer in result['final_kv']['observation']['layers']))
    def test_shifted_causal_label_and_changed_state_rejected(self):
        fixture=self.fixture();fixture.edit('target-scores.json',lambda d:d['scores'][0].update(prediction_position=1))
        with self.assertRaisesRegex(ValueError,'causal target'):fixture.inspect()
        fixture=self.fixture();fixture.edit('model-state-after.json',lambda d:d.update(unexpected_state=True))
        with self.assertRaisesRegex(ValueError,'persistent loaded model'):fixture.inspect()
    def test_unscored_or_missing_decode_last_row_rejected(self):
        fixture=self.fixture('token');fixture.edit('events.json',lambda d:d.pop())
        with self.assertRaisesRegex(ValueError,'call count'):fixture.inspect()
    def test_cache_growth_reuse_and_wrong_kv_shape_rejected(self):
        fixture=self.fixture('chunk63-65');fixture.edit('events.json',lambda d:d[1]['cache_before'].update(sequence_length=62))
        with self.assertRaisesRegex(ValueError,'cache observation'):fixture.inspect()
        fixture=self.fixture('token');fixture.edit('final-cache.json',lambda d:d['tensors'][0]['shape'].__setitem__(2,159))
        with self.assertRaisesRegex(ValueError,'KV tensor coordinate'):fixture.inspect()
    def test_resigned_full_row_target_unchanged_but_distribution_wrong(self):
        fixture=self.fixture();path=fixture.path('dist-p000.npy');row=np.load(path,allow_pickle=False);row[0,[2,3]]=row[0,[3,2]];np.save(path,row,allow_pickle=False)
        with self.assertRaisesRegex(ValueError,'full-row rederivation'):fixture.inspect()
    def test_rng_complete_header_not_truncated(self):
        valid=rng();n.rng_descriptor(valid,before=True);valid['numpy']['header']['word_count']=4
        with self.assertRaisesRegex(ValueError,'generator header'):n.rng_descriptor(valid,before=True)
        valid=rng();valid['python']['format']='truncated array repr'
        with self.assertRaisesRegex(ValueError,'untruncated RNG'):n.rng_descriptor(valid,before=True)
    def test_gpu_seed_reset_each_mode_rejected_if_wrong(self):
        fixture=self.fixture(device='cuda:0');fixture.edit('state-control.json',lambda d:d['seed_reset'].update(cuda_initial_seed=1))
        with self.assertRaisesRegex(ValueError,'GPU per-mode seed'):fixture.inspect()
    def test_native_kv_nonfinite_extra_key_or_overlap_rejected(self):
        fixture=self.fixture('token');path=fixture.path('final-native-kv.safetensors');descriptors=n.layer_descriptors(fixture.types,160)
        raw=path.read_bytes();offset=8+int.from_bytes(raw[:8],'little');modified=bytearray(raw);modified[offset:offset+2]=struct.pack('<H',0x7f80);path.write_bytes(modified)
        with self.assertRaisesRegex(ValueError,'nonfinite'):n.native_kv(path,descriptors)
        header=json.loads(raw[8:offset]);keys=list(descriptors);header[keys[1]]['data_offsets']=header[keys[0]]['data_offsets']
        h=json.dumps(header).encode();path.write_bytes(struct.pack('<Q',len(h))+h+raw[offset:])
        with self.assertRaisesRegex(ValueError,'gap/overlap'):n.native_kv(path,descriptors)
        header['extra']=copy.deepcopy(header[keys[0]]);h=json.dumps(header).encode();path.write_bytes(struct.pack('<Q',len(h))+h+raw[offset:])
        with self.assertRaisesRegex(ValueError,'tensor-key'):n.native_kv(path,descriptors)
    def test_shared_native_kv_all96_metrics_analytic_half_difference(self):
        first=self.fixture('token');second=self.fixture('chunk63-65');path=second.path('final-native-kv.safetensors')
        descriptors=n.layer_descriptors(second.types,160);safetensors(path,{key:np.full(shape,0x3fc0,dtype='<u2') for key,shape in descriptors.items()})
        ka=n.native_kv(first.path('final-native-kv.safetensors'),descriptors);kb=n.native_kv(path,descriptors)
        ka['descriptors']=kb['descriptors']=descriptors
        status=write(Path(self.tmp.name)/'status.json',{'status':'completed','rank':0})
        base={'model':{'synthetic_fixture':True},'hardware':{'category':'CPU-synthetic'},'software':{'framework':'fixture'},'backend_policy':{},
            'mode':{'synthetic_fixture':True},'status_path':str(status)}
        report=a.compare_kv(Path(self.tmp.name)/'kv-compare',{**base,'side':'fixture-a','final_kv':ka},{**base,'side':'fixture-b','final_kv':kb},first.inventory)
        self.assertEqual(report['metrics']['global']['count'],81920)
        self.assertAlmostEqual(report['metrics']['global']['rmse']['value'],.5);self.assertEqual(report['metrics']['global']['max_abs']['value'],.5)


if __name__=='__main__':unittest.main()

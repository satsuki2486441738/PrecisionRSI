"""Pure-stdlib portable I03 numerical prerequisite gate for new I04 work.

This checks eight original small documents and their admitted execution chain.
It imports no framework and never reads native arrays or starts a subprocess.
The new launcher freezes the externally supplied wrapper SHA before any query.
"""
from collections import Counter
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re

STAGE_SHA = '6e53e3cdf3e7fad8f56b43cb99a42bdb999ac074a5a40a3c1e7df72eeb504005'
EXPECTED_SHA = '5c8cdcc3c5b88732ccd589d95fa5ce86bd9eac71f83620e3bc48bcfc3b3b9a25'
I01_PROOF_SHA = '2d26531b83af3a3f0acf63c9b8472ce547a5bd288de6f92cd390a38a6011d840'
ANALYSIS_SHA = '2468a5f2a1aafe9f9437edae2bd90b3bdca15f9c1abcc6fa3b927ddb8167691c'
ARTIFACT_HELPER_SHA = 'b734babc65be6ec361acbc10905b6c3e02e8c5c57650efb11e3a195134a1b6eb'
TOOL_MANIFEST_SHA = 'd4db95a5ae22091417698109d0dd9836ff5665d66667c530aaf85a4f597ccf87'
CONTROLLER_SHA = '5cc22ed237239f7a090f53525353f27db6e06b6c3c68fa2210bff4925e480431'
CASE = 'projects/gemma4-pilot/cases/text-native'
MAIN = CASE+'/adapters/admit_i03_partition_repeat_v1.py'
HELPER = CASE+'/adapters/i03_artifact_admission_v1.py'
CONTROLLER = CASE+'/transfer/run_i03_actual_compare_v1.py'
MODES = ['full-r1','full-r2','full-r3','token','chunk63-65']
TASK = 'gemma4-i03-partition-repeat-v1'
HEX = re.compile(r'^[a-f0-9]{64}$')
SCOPE = {'independent_inputs':1,'new_model_processes_per_backend':1,'native_calls_per_backend':70,'modes_per_backend':5,
    'full_repeat_calls_per_backend':3,'fresh_process_repeatability_measured':False,'cached_mode_repeatability_measured':False,
    'targets_per_mode':159,'distribution_rows_per_mode':47,'raw_native_predictor_rows_finite_checked':1600,
    'full_vocabulary_rows_rederived':470,'target_scores_rederived':1590,'target_distribution_pairs':23,
    'native_final_kv_pairs':4,'native_kv_tensors_per_cached_mode':96,'cache_eviction_tested':False}


def require(ok, message):
    if not ok: raise ValueError(message)


def canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)


def read(path):
    def pairs(items):
        out = {}
        for key,value in items: require(key not in out,'duplicate JSON key'); out[key] = value
        return out
    def reject(value): raise ValueError('nonfinite JSON token '+value)
    value = json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)
    canonical(value); return value


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''): value.update(block)
    return value.hexdigest()


def file_ref(path, limit=16*1024**2):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= limit,'bounded original regular proof file required')
    return {'path':str(path.resolve()),'sha256':sha(path),'size_bytes':path.stat().st_size}


def relative(name):
    require(isinstance(name,str) and name and '\\' not in name,'POSIX proof-relative path required')
    p = PurePosixPath(name)
    require(not p.is_absolute() and str(p) == name and all(x not in ('','.','..') for x in name.split('/')) and p.parts[0] == 'proof',
        'canonical proof/ copy path required')
    return p


def absolute(name):
    require(isinstance(name,str) and '\\' not in name,'original absolute POSIX path required')
    p = PurePosixPath(name)
    require(p.is_absolute() and '..' not in p.parts and str(p) == name,'canonical original absolute POSIX path required')
    return p


def flag(argv,name):
    require(isinstance(argv,list) and all(isinstance(x,str) for x in argv) and argv.count(name) == 1 and
        not any(x.startswith(name+'=') for x in argv),'unique literal argv flag required: '+name)
    i = argv.index(name); require(i+1 < len(argv),'literal argv value missing'); return argv[i+1]


def utc(value):
    dt = datetime.fromisoformat(value.replace('Z','+00:00'))
    require(dt.tzinfo is not None and dt.utcoffset().total_seconds() == 0,'actual UTC timestamp required')
    return dt


def prerequisite(path,digest):
    path = Path(path)
    require(isinstance(digest,str) and HEX.fullmatch(digest) and file_ref(path,65536)['sha256'] == digest,'I04 prerequisite wrapper SHA differs')
    doc = read(path)
    names = ('controller','report','comparison_spec','analysis_source','artifact_helper_source','tool_manifest')
    require(set(doc) == {'schema_version','kind','prior_stage_sha256','source_maps',*names} and type(doc['schema_version']) is int and
        doc['schema_version'] == 1 and doc['kind'] == 'i04-i03-numeric-prerequisite' and doc['prior_stage_sha256'] == STAGE_SHA,
        'complete eight-document I03 prerequisite required')
    require(set(doc['source_maps']) == {'GPU','NPU'},'both actual source maps required')
    refs = {name:doc[name] for name in names}; refs.update({name+'_map':ref for name,ref in doc['source_maps'].items()})
    require(len({ref.get('path') for ref in refs.values() if isinstance(ref,dict)}) == 8,'distinct eight proof copy paths required')
    require(len({ref.get('source_path') for ref in refs.values() if isinstance(ref,dict)}) == 8,'distinct eight original proof paths required')
    observed, documents = {},{}
    for name,ref in refs.items():
        require(isinstance(ref,dict) and set(ref) == {'path','source_path','sha256'} and isinstance(ref['sha256'],str) and HEX.fullmatch(ref['sha256']),
            'invalid original copied-proof reference')
        rel = relative(ref['path']); absolute(ref['source_path']); actual = path.parent.joinpath(*rel.parts)
        require(actual.resolve().is_relative_to(path.parent.resolve()),'proof copy escapes bundle')
        current = actual
        while current != path.parent:
            require(not current.is_symlink(),'proof copy path contains symlink'); current = current.parent
        observed[name] = file_ref(actual); require(observed[name]['sha256'] == ref['sha256'],'copied original proof bytes differ')
        if name not in ('analysis_source','artifact_helper_source'): documents[name] = read(actual)
    require(doc['analysis_source']['sha256'] == ANALYSIS_SHA and doc['artifact_helper_source']['sha256'] == ARTIFACT_HELPER_SHA and
        doc['tool_manifest']['sha256'] == TOOL_MANIFEST_SHA,'frozen independent I03 analysis/helper/manifest differs')
    controller,report,spec,tools = (documents[k] for k in ('controller','report','comparison_spec','tool_manifest'))
    require(controller.get('task') == 'I03' and controller.get('status') == 'completed' and type(controller.get('returncode')) is int and
        controller['returncode'] == 0 and type(controller.get('child_returncode')) is int and controller['child_returncode'] == 0 and
        controller.get('timed_out',False) is False and controller.get('cleanup_incomplete',False) is False and
        controller.get('native_executions_started') == 0 and controller.get('whole_cpu_seconds') == 900 and
        controller.get('child_work_seconds') == 870 and controller.get('analysis_seconds') == 850 and
        controller.get('tool_manifest_sha256') == TOOL_MANIFEST_SHA and controller.get('acceptance') is None,
        'actual successful bounded I03 numerical controller required')
    run = absolute(doc['controller']['source_path']).parent
    require(controller.get('run') == str(run) and utc(controller['started_utc']) < utc(controller['finished_utc']) and
        controller.get('report') == {'path':doc['report']['source_path'],'sha256':doc['report']['sha256']} and
        controller.get('comparison_spec') == {'path':doc['comparison_spec']['source_path'],'sha256':doc['comparison_spec']['sha256']} and
        absolute(doc['report']['source_path']) == run/'bundle/i03-comparison-report.json' and
        absolute(doc['comparison_spec']['source_path']) == run/'comparison-spec.json','I03 original controller/report/spec chain differs')
    tool_root = absolute(controller['tools_root'])
    require(absolute(doc['analysis_source']['source_path']) == tool_root/MAIN and absolute(doc['artifact_helper_source']['source_path']) == tool_root/HELPER and
        absolute(doc['tool_manifest']['source_path']) == tool_root/'tool-bundle-manifest.json','actual independent source namespace differs')
    argv = controller.get('argv')
    require(isinstance(argv,list) and len(argv) > 3 and argv[1] == '-B' and argv[2] == doc['analysis_source']['source_path'] and
        flag(argv,'--spec') == doc['comparison_spec']['source_path'] and flag(argv,'--spec-sha256') == doc['comparison_spec']['sha256'] and
        flag(argv,'--output-dir') == str(run/'bundle') and flag(argv,'--timeout-seconds') == '850','I03 executed direct independent-analysis argv differs')
    require(tools.get('kind') == 'i03-offline-tool-bundle' and tools.get('native_executions_started') == 0 and tools.get('acceptance') is None and
        len(tools.get('files',{})) == 20 and tools['files'][MAIN]['sha256'] == ANALYSIS_SHA and
        tools['files'][HELPER]['sha256'] == ARTIFACT_HELPER_SHA and tools['files'][CONTROLLER]['sha256'] == CONTROLLER_SHA,
        'actual admitted20-source tool closure differs')
    require(report.get('status') == 'i03_raw_bf16_partition_repeat_and_final_kv_checked' and report.get('task') == TASK and
        report.get('stage_spec_sha256') == STAGE_SHA and report.get('comparison_spec_sha256') == doc['comparison_spec']['sha256'] and
        report.get('native_executions_started_by_admission') == 0 and report.get('thresholds',object()) is None and
        report.get('acceptance',object()) is None and report.get('full_core_complete') is False and
        canonical(report.get('scope')) == canonical(SCOPE) and canonical(controller.get('scope')) == canonical(SCOPE),
        'actual23/4/159/47 I03 raw-BF16 report scope differs')
    require(spec.get('schema_version') == 1 and spec.get('task') == TASK and spec.get('stage_spec_sha256') == STAGE_SHA and
        spec.get('expected_inventory_sha256') == EXPECTED_SHA and spec.get('i01_prerequisite_sha256') == I01_PROOF_SHA and
        spec.get('thresholds',object()) is None and spec.get('acceptance',object()) is None and set(spec.get('endpoints',{})) == {'GPU','NPU'},
        'actual I03 comparison specification differs')
    require(report.get('source_map_sha256') == {name:doc['source_maps'][name]['sha256'] for name in ('GPU','NPU')},'report actual source-map SHA chain differs')
    for name in ('GPU','NPU'):
        ref = doc['source_maps'][name]; endpoint = spec['endpoints'][name]; mapping = documents[name+'_map']
        require(endpoint['source_map'] == {'path':ref['source_path'],'sha256':ref['sha256']} and
            mapping.get('request',{}).get('task') == 'I03' and mapping['request'].get('backend') == name and
            mapping['request'].get('outer_receipt') == endpoint['receipt']['source_path'] and
            mapping.get('full_array_hashes_checked') == 242 and mapping.get('retained_array_count') == (0 if name == 'GPU' else 242) and
            mapping['files'][endpoint['receipt']['source_path']]['sha256'] == endpoint['receipt']['sha256'], 'actual endpoint-map/original-outer chain differs')
    scores,kv = report.get('target_distribution_pairs',[]),report.get('native_final_kv_pairs',[])
    require(len(scores) == 23 and len(kv) == 4 and Counter(item.get('kind') for item in scores) ==
        {'within_process_full_repeat':6,'within_process_partition':6,'cross_backend_full':9,'cross_backend_cached':2},'I03 actual pair inventory differs')
    for item in scores:
        require(item['targets']['status'] == item['distributions']['status'] == 'no_thresholds' and
            item['targets']['coverage'] == {'expected':159,'paired':159} and item['distributions']['position_count'] == 47 and
            item.get('thresholds',object()) is None and item.get('acceptance',object()) is None,'I03 paired score coverage differs')
    for item in kv:
        require(item['metrics']['status'] == 'no_thresholds' and len(item['metrics']['per_tensor']) == 96 and
            item['metrics']['global']['count'] == 27525120 and item.get('thresholds',object()) is None and item.get('acceptance',object()) is None,
            'I03 final96-key KV coverage differs')
    require(set(report.get('raw_derivation',{})) == {'GPU','NPU'},'both raw-BF16 derivation proofs required')
    for modes in report['raw_derivation'].values():
        require(set(modes) == set(MODES),'five raw modes required')
        for proof in modes.values():
            delta = proof.get('largest_abs_logprob_derivation_delta')
            require(isinstance(proof.get('raw_sha256'),str) and HEX.fullmatch(proof['raw_sha256']) and type(delta) in (int,float) and
                math.isfinite(delta) and 0 <= delta <= 1e-12,'prior raw-BF16 integrity check differs')
    for name,ref in observed.items(): require(sha(ref['path']) == ref['sha256'],'original copied prerequisite changed during checks')
    require(sha(path) == digest,'prerequisite wrapper changed during checks')
    return {'document':doc,'refs':observed,'prerequisite_sha256':digest,'native_executions_started':0}

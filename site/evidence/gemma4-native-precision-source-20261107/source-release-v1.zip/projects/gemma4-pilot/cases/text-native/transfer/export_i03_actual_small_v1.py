"""Bounded stdlib export of actual I03 numeric metadata; never open native arrays.

Preserves source paths/raw JSON bytes. This packages prior23/4 numeric results;
it does not rerun numerical inference, native tensor comparisons or array checks.
"""
import argparse
import base64
from collections import Counter
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path,PurePosixPath
import re
import signal
import tarfile

CASE='projects/gemma4-pilot/cases/text-native'
MAIN=CASE+'/adapters/admit_i03_partition_repeat_v1.py'
MAIN_SHA='2468a5f2a1aafe9f9437edae2bd90b3bdca15f9c1abcc6fa3b927ddb8167691c'
HELPER=CASE+'/adapters/i03_artifact_admission_v1.py'
HELPER_SHA='b734babc65be6ec361acbc10905b6c3e02e8c5c57650efb11e3a195134a1b6eb'
CONTROLLER=CASE+'/transfer/run_i03_actual_compare_v1.py'
CONTROLLER_SHA='5cc22ed237239f7a090f53525353f27db6e06b6c3c68fa2210bff4925e480431'
TOOL_SHA='d4db95a5ae22091417698109d0dd9836ff5665d66667c530aaf85a4f597ccf87'
STAGE_SHA='6e53e3cdf3e7fad8f56b43cb99a42bdb999ac074a5a40a3c1e7df72eeb504005'
MODES=['full-r1','full-r2','full-r3','token','chunk63-65']
MAX_SMALL,MAX_TOTAL,MAX_GZIP,MAX_ENVELOPE=16*1024**2,192*1024**2,32*1024**2,64*1024**2
HEX=re.compile(r'^[a-f0-9]{64}$')


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):value.update(block)
    return value.hexdigest()


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)


def load(path):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    result=json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject);canonical(result);return result


def put(path,doc):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(doc,stream,indent=2,allow_nan=False);stream.write('\n')


def flag(argv,name):
    require(isinstance(argv,list) and argv.count(name)==1 and not any(x.startswith(name+'=') for x in argv),'ambiguous literal argument '+name)
    index=argv.index(name);require(index+1<len(argv),'missing literal argument '+name);return argv[index+1]


def regular(path):
    path=Path(path);require(path.is_file() and not path.is_symlink(),'original regular metadata required');return path


def completed(doc):require(doc.get('status')=='completed' and type(doc.get('returncode')) is int and doc['returncode']==0,'actual completed0 controller required')


def verify_controller(controller_path,controller_sha):
    controller_path=regular(controller_path);require(HEX.fullmatch(controller_sha) and sha(controller_path)==controller_sha,'externally frozen actual controller SHA differs')
    state=load(controller_path);completed(state);run=controller_path.parent;tools=Path(state['tools_root'])
    require(state.get('task')=='I03' and state.get('run')==str(run) and state.get('child_returncode')==0 and type(state['child_returncode']) is int and
        state.get('timed_out',False) is False and state.get('cleanup_incomplete',False) is False and state.get('native_executions_started')==0 and
        state.get('tool_manifest_sha256')==TOOL_SHA and state.get('whole_cpu_seconds')==900 and state.get('child_work_seconds')==870 and
        state.get('analysis_seconds')==850 and state.get('acceptance') is None,'actual bounded23/4 controller scope differs')
    manifest=regular(tools/'tool-bundle-manifest.json');require(sha(manifest)==TOOL_SHA,'actual tool manifest differs')
    tool_doc=load(manifest);require(tool_doc['kind']=='i03-offline-tool-bundle' and len(tool_doc['files'])==20 and tool_doc['native_executions_started']==0 and
        tool_doc['files'][MAIN]['sha256']==MAIN_SHA and tool_doc['files'][HELPER]['sha256']==HELPER_SHA and
        tool_doc['files'][CONTROLLER]['sha256']==CONTROLLER_SHA,'known20source numerical tool chain differs')
    for name,ref in tool_doc['files'].items():
        path=PurePosixPath(name);require(not path.is_absolute() and '..' not in path.parts and '\\' not in name,'tool source path escapes')
        actual=regular(tools/name);require(actual.resolve().is_relative_to(tools.resolve()) and actual.stat().st_size==ref['size_bytes'] and sha(actual)==ref['sha256'],
            'actual offline source bytes differ')
    argv=state['argv'];require(len(argv)>3 and argv[1]=='-B' and Path(argv[2])==tools/MAIN and sha(argv[2])==MAIN_SHA,'actual numerical direct source differs')
    spec_ref=state['comparison_spec'];report_ref=state['report']
    require(Path(spec_ref['path'])==run/'comparison-spec.json' and Path(report_ref['path'])==run/'bundle/i03-comparison-report.json' and
        sha(regular(spec_ref['path']))==spec_ref['sha256'] and sha(regular(report_ref['path']))==report_ref['sha256'],'actual result/input path/SHA differs')
    require(flag(argv,'--spec')==spec_ref['path'] and flag(argv,'--spec-sha256')==spec_ref['sha256'] and
        flag(argv,'--output-dir')==str(run/'bundle') and flag(argv,'--timeout-seconds')=='850','actual numerical direct argv differs')
    for key,name in [('stdout','stdout.json'),('stderr','stderr.txt')]:
        ref=state[key];path=regular(ref['path']);require(path==run/name and path.stat().st_size==ref['bytes'] and sha(path)==ref['sha256'],'actual numerical log binding differs')
    spec=load(spec_ref['path']);report=load(report_ref['path'])
    require(spec['stage_spec_sha256']==STAGE_SHA and set(spec['endpoints'])=={'GPU','NPU'} and report['stage_spec_sha256']==STAGE_SHA and
        report['status']=='i03_raw_bf16_partition_repeat_and_final_kv_checked' and report['comparison_spec_sha256']==spec_ref['sha256'] and
        report['source_map_sha256']=={k:v['source_map']['sha256'] for k,v in spec['endpoints'].items()} and
        report['native_executions_started_by_admission']==0 and report['thresholds'] is None and report['acceptance'] is None and report['full_core_complete'] is False,
        'actual I03 report identity/source maps differ')
    fixed={'independent_inputs':1,'new_model_processes_per_backend':1,'native_calls_per_backend':70,'modes_per_backend':5,'full_repeat_calls_per_backend':3,
        'fresh_process_repeatability_measured':False,'cached_mode_repeatability_measured':False,'targets_per_mode':159,'distribution_rows_per_mode':47,
        'raw_native_predictor_rows_finite_checked':1600,'full_vocabulary_rows_rederived':470,'target_scores_rederived':1590,'target_distribution_pairs':23,
        'native_final_kv_pairs':4,'native_kv_tensors_per_cached_mode':96,'cache_eviction_tested':False}
    require(canonical(report['scope'])==canonical(fixed) and canonical(state['scope'])==canonical(fixed),'actual numerical scope differs')
    pairs=report['target_distribution_pairs'];kv=report['native_final_kv_pairs']
    require(len(pairs)==23 and len(kv)==4 and Counter(p['kind'] for p in pairs)=={'within_process_full_repeat':6,'within_process_partition':6,'cross_backend_full':9,'cross_backend_cached':2},
        'actual23score/4KV pair inventory differs')
    for pair in pairs:
        require(pair['targets']['status']==pair['distributions']['status']=='no_thresholds' and pair['targets']['coverage']=={'expected':159,'paired':159} and
            pair['distributions']['position_count']==47 and pair['thresholds'] is None and pair['acceptance'] is None,'actual score pair scope differs')
    for pair in kv:
        require(pair['metrics']['status']=='no_thresholds' and len(pair['metrics']['per_tensor'])==96 and pair['metrics']['global']['count']==27525120 and
            pair['thresholds'] is None and pair['acceptance'] is None,'actual full native KV pair scope differs')
    require(set(report['raw_derivation'])=={'GPU','NPU'},'both raw derivation endpoints required')
    for modes in report['raw_derivation'].values():
        require(set(modes)==set(MODES),'all five raw-native mode proofs required')
        for proof in modes.values():require(HEX.fullmatch(proof['raw_sha256']) and type(proof['largest_abs_logprob_derivation_delta']) in (int,float) and
            0<=proof['largest_abs_logprob_derivation_delta']<=1e-12,'actual raw BF16 independent derivation proof differs')
    stdout=load(state['stdout']['path']);require(stdout=={'status':report['status'],'target_distribution_pairs':23,'native_final_kv_pairs':4,
        'native_executions_started':0,'acceptance':None},'actual numerical stdout/report differs')
    return state,spec,report,tool_doc


class Catalog:
    def __init__(self,output):self.output=output;self.files={};self.omitted={};self.total=0
    def add(self,path,expected=None,role='metadata'):
        path=Path(path);original=str(path)
        require(path.is_absolute() and '\\' not in original and '..' not in PurePosixPath(original).parts,'original absolute POSIX metadata path required')
        # Classification MUST precede stat/open/hash. Native arrays may not exist
        # on a metadata-only audit host; their producer hashes remain evidence.
        if path.suffix in ('.npy','.safetensors','.tar','.gz','.whl','.bin'):
            self.omitted.setdefault(original,{'sha256':expected,'reason':'native_array_or_transport_archive_not_opened_by_metadata_export'})
            return
        regular(path);require(path.stat().st_size<=MAX_SMALL,'metadata file exceeds16MiB')
        digest=sha(path);require(expected is None or digest==expected,'metadata source SHA differs: '+original)
        if original in self.files:require(self.files[original]['sha256']==digest,'same original source path conflicts');return
        self.total+=path.stat().st_size;require(self.total<=MAX_TOTAL,'metadata source total exceeds192MiB')
        relative='payload/%04d/%s'%(len(self.files),path.name);target=self.output/relative;target.parent.mkdir(parents=True)
        raw=path.read_bytes();require(hashlib.sha256(raw).hexdigest()==digest,'metadata changed before copy')
        with target.open('xb') as stream:stream.write(raw)
        self.files[original]={'path':relative,'sha256':digest,'size':len(raw),'role':role}
    def endpoint(self,ref):
        mapping=Path(ref['path']);self.add(mapping,ref['sha256'],'original_endpoint_source_map');document=load(mapping)
        for original,item in document['files'].items():
            require(PurePosixPath(original).is_absolute() and '..' not in PurePosixPath(original).parts and '\\' not in original and
                type(item.get('size')) is int and item['size']>=0 and HEX.fullmatch(item['sha256']),'invalid original source descriptor')
            if PurePosixPath(original).suffix in ('.npy','.safetensors'):
                old=self.omitted.get(original);require(old is None or old['sha256']==item['sha256'],'array source identity conflict')
                self.omitted[original]={'sha256':item['sha256'],'size':item['size'],'reason':'native_array_not_opened_by_metadata_export'};continue
            require('path' in item and not item.get('retained_at_source'),'small endpoint source must have copied bytes')
            relative=PurePosixPath(item['path']);require(not relative.is_absolute() and '..' not in relative.parts and '\\' not in item['path'],'copied metadata escapes source map')
            actual=(mapping.parent/str(relative)).resolve(strict=True);require(actual.is_relative_to(mapping.parent.resolve()) and actual.stat().st_size==item['size'],
                'copied metadata size/path differs')
            self.add(actual,item['sha256'],'verbatim_endpoint_metadata_payload')
    def close(self):
        for original,ref in self.files.items():require(sha(original)==ref['sha256'] and sha(self.output/ref['path'])==ref['sha256'],'metadata source/copy changed')


def transport_provenance(catalog,root,transport_dir):
    transport_dir=Path(transport_dir);require(not transport_dir.is_symlink() and transport_dir.resolve().is_relative_to(root/'transports'),'explicit owned transport directory required')
    receipt_path=transport_dir/'assembly-receipt.json';receipt=load(regular(receipt_path))
    require(receipt['status']=='i03_original_gpu_gzip_reconstructed' and type(receipt['returncode']) is int and receipt['returncode']==0 and
        receipt['archive_sha256']=='406294d2a911e81b4dfbd90f05f14cf958976f7b2999a988c0714ff33979c894' and receipt['archive_bytes']==529888535 and
        receipt['original_gzip_bytes_preserved'] is True and receipt['native_executions_started']==0,'actual successful reconstruction receipt required')
    for path in sorted(transport_dir.rglob('*')):
        if path.suffix in ('.tar','.gz','.bin','.npy','.safetensors'):catalog.add(path,role='transport_archive_omitted');continue
        if path.is_file():catalog.add(path,role='actual_reassembly_and_chunk_stage_provenance')
    source=root/'tools/i03-gpu-transport-tools-20261106T160431Z/reassemble_i03_gpu_transport_v1.py'
    manifest=source.parent/'i03-gpu-transport-manifest-v1.json'
    catalog.add(source,'03175f2cef4163fb3151a76222fa6d27233cd137eecc17e3d52e0e34a7b961a5','actual_reassembly_source')
    catalog.add(manifest,'0fe4af4c53098df852b4cad41c691a324a19d06c451435f25a4adfa46ca71226','actual_chunk_manifest')


def export(controller_path,controller_sha,selection_receipt,output,transport_dir=None):
    controller_path=Path(controller_path).resolve(strict=True);output=Path(output).resolve()
    require(not output.exists() and output.parent.is_dir(),'exclusive new metadata export directory required')
    state,spec,report,tool_doc=verify_controller(controller_path,controller_sha);output.mkdir(mode=0o700);catalog=Catalog(output)
    catalog.add(Path(__file__).resolve(),role='metadata_exporter_source')
    for path in sorted(controller_path.parent.rglob('*')):
        if path.suffix in ('.npy','.safetensors','.tar','.gz','.bin'):catalog.add(path,role='unexpected_array_or_archive_omitted');continue
        if path.is_file():catalog.add(path,role='actual_numeric_controller_and_frozen_documents')
    frozen_count=0
    for pair in report['target_distribution_pairs']+report['native_final_kv_pairs']:
        metric=pair['targets'] if 'targets' in pair else pair['metrics'];folder=Path(metric['sources']['contract']).parent
        require(folder.resolve().is_relative_to((controller_path.parent/'bundle').resolve()),'frozen pair directory escapes actual comparison')
        for name,digest in pair['frozen_document_sha256'].items():
            require(PurePosixPath(name).name==name,'frozen document name escapes pair');catalog.add(folder/name,digest,'frozen_score_or_native_KV_document');frozen_count+=1
    require(frozen_count==204,'all184score+20KV frozen comparison documents required')
    tools=Path(state['tools_root']);catalog.add(tools/'tool-bundle-manifest.json',TOOL_SHA,'actual_20source_tool_manifest')
    for name,ref in tool_doc['files'].items():catalog.add(tools/name,ref['sha256'],'frozen_offline_numerical_source')
    for category in ('GPU','NPU'):catalog.endpoint(spec['endpoints'][category]['source_map'])
    selected=load(regular(selection_receipt));require(selected['status']=='ready_to_execute_frozen_cpu_controller' and type(selected['returncode']) is int and
        selected['returncode']==0 and selected['tools_root']==str(tools) and selected['native_executions_started']==0 and
        selected['gpu_source_map_sha256']==spec['endpoints']['GPU']['source_map']['sha256'] and
        selected['npu_source_map_sha256']==spec['endpoints']['NPU']['source_map']['sha256'],'actual machine endpoint selection differs')
    for path in sorted(Path(selection_receipt).parent.iterdir()):
        if path.is_file():catalog.add(path,role='actual_endpoint_selection')
    for original,digest in selected['checked_source_sha256'].items():catalog.add(original,digest,'actual_checked_tool_import_and_CPU_export_provenance')
    root=controller_path.parents[2]
    if transport_dir is not None:transport_provenance(catalog,root,transport_dir)
    proof=output/'i04-prerequisite';(proof/'proof').mkdir(parents=True)
    originals={'controller':('i03-controller.json',controller_path),'report':('i03-report.json',Path(state['report']['path'])),
        'comparison_spec':('i03-comparison-spec.json',Path(state['comparison_spec']['path'])),
        'analysis_source':('i03-analysis.py',tools/MAIN),'artifact_helper_source':('i03-artifact-helper.py',tools/HELPER),
        'tool_manifest':('i03-tool-manifest.json',tools/'tool-bundle-manifest.json'),
        'GPU':('gpu-source-map.json',Path(spec['endpoints']['GPU']['source_map']['path'])),
        'NPU':('npu-source-map.json',Path(spec['endpoints']['NPU']['source_map']['path']))}
    proof_refs={}
    for key,(name,source) in originals.items():
        target=proof/'proof'/name;raw=source.read_bytes()
        with target.open('xb') as stream:stream.write(raw)
        proof_refs[key]={'path':'proof/'+name,'source_path':str(source),'sha256':sha(source)}
        require(sha(target)==proof_refs[key]['sha256'],'portable prior-stage original bytes differ')
    prerequisite={'schema_version':1,'kind':'i04-i03-numeric-prerequisite','prior_stage_sha256':STAGE_SHA,
        **{key:proof_refs[key] for key in ('controller','report','comparison_spec','analysis_source','artifact_helper_source','tool_manifest')},
        'source_maps':{key:proof_refs[key] for key in ('GPU','NPU')}}
    put(proof/'prerequisite.json',prerequisite)
    generated={path.relative_to(output).as_posix():{'sha256':sha(path),'size':path.stat().st_size} for path in sorted(proof.rglob('*')) if path.is_file()}
    catalog.close();require(sum(name.endswith('.npy') for name in catalog.omitted)==470 and
        sum(name.endswith('.safetensors') for name in catalog.omitted)==14,'exact470NPY+10logits+4KV omitted source inventory required')
    metadata={'schema_version':1,'kind':'i03-actual-numeric-small-export','controller':{'path':str(controller_path),'sha256':controller_sha},
        'report':state['report'],'comparison_spec':state['comparison_spec'],'files':catalog.files,'omitted':catalog.omitted,'generated_files':generated,
        'arrays_statted_opened_or_copied':0,'numeric_replay_performed_by_exporter':False,'native_executions_started':0,'acceptance':None}
    put(output/'metadata-source-map.json',metadata)
    require(sum(path.stat().st_size for path in output.rglob('*') if path.is_file())<=MAX_TOTAL,'complete metadata products exceed192MiB')
    archive=output.with_name(output.name+'.tar.gz');portable=output.with_name(output.name+'-i04-prerequisite.tar.gz');archives=[]
    for folder,target_path in ((output,archive),(proof,portable)):
        with target_path.open('xb') as target,tarfile.open(fileobj=target,mode='w:gz') as package:
            for path in sorted(folder.rglob('*')):
                require(not path.is_symlink(),'export package contains symlink')
                if path.is_file():package.add(path,arcname=path.relative_to(folder).as_posix(),recursive=False)
        require(target_path.stat().st_size<=MAX_GZIP,'compressed metadata archive exceeds32MiB')
        archives.append({'basename':target_path.name,'bytes':target_path.stat().st_size,'sha256':sha(target_path)})
    catalog.close()
    for name,ref in generated.items():require(sha(output/name)==ref['sha256'],'portable proof changed during packaging')
    envelope=output.with_name(output.name+'-json-base64.txt')
    put(envelope,{'schema_version':1,'kind':'i03-actual-small-archives','archives':[{**ref,'base64':base64.b64encode(path.read_bytes()).decode('ascii')}
        for ref,path in zip(archives,(archive,portable))]})
    require(envelope.stat().st_size<=MAX_ENVELOPE,'JSONbase64 metadata envelope exceeds64MiB')
    require(sha(controller_path)==controller_sha,'actual comparison controller changed during metadata export')
    result={'status':'i03_actual_small_export_completed','controller_sha256':controller_sha,'report_sha256':state['report']['sha256'],
        'metadata_source_map_sha256':sha(output/'metadata-source-map.json'),'copied_metadata_files':len(catalog.files),'metadata_source_bytes':catalog.total,
        'frozen_comparison_documents_checked':204,'omitted_npy_files':470,'omitted_raw_native_files':14,'arrays_statted_opened_or_copied':0,
        'archives':archives,'prerequisite_path':str(proof/'prerequisite.json'),'prerequisite_sha256':sha(proof/'prerequisite.json'),
        'prerequisite_raw_documents':8,'json_base64_path':str(envelope),'json_base64_bytes':envelope.stat().st_size,'json_base64_sha256':sha(envelope),
        'native_executions_started':0,'acceptance':None}
    put(output.with_name(output.name+'-export-receipt.json'),result);return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('controller','selection-receipt','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--controller-sha256',required=True);parser.add_argument('--transport-dir',type=Path);args=parser.parse_args()
    def expire(*_):raise TimeoutError('I03 small metadata export900s deadline reached')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,900)
    try:print(json.dumps(export(args.controller,args.controller_sha256,args.selection_receipt,args.output,args.transport_dir),indent=2),flush=True)
    except BaseException as exc:
        failure=args.output.with_name(args.output.name+'-export-failure.json')
        if failure.parent.is_dir() and not failure.exists():put(failure,{'status':'failed','error_type':type(exc).__name__,'error':str(exc),
            'partial_output_preserved':True,'automatic_retry':False,'native_executions_started':0})
        raise
    finally:signal.setitimer(signal.ITIMER_REAL,0)


if __name__=='__main__':main()

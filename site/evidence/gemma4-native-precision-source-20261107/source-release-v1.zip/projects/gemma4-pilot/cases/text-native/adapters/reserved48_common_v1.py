"""Draft streaming I05/Q01 capture for the frozen English reserved48 cohort.

Import is stdlib-only. Activation/proof/budget/lifecycle pins deliberately remain
None. Selected native BF16 rows are original evidence; source-derived all-target
normalizers cannot be independently replayed once unselected raw rows are gone.
There is no Q02 generation or P01 timing implementation in this module.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import gc
import hashlib
import importlib.util
import itertools
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import struct
import sys
import time
import weakref

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]
TASK = 'gemma4-reserved48-i05-q01-v1'
STAGE_ID = 'gemma4-gpu-npu-reserved48-i05-q01-v1'
MANIFEST_SHA256 = '10f6b1a6976507e1af65706ddd4bb61d9276c43ae443b2a6852935e2967dca37'
CONFIG_SHA256 = '14f38c5492ffc9cbcdf808647ca0c025bb5b9b4eb737526347134d500ace6098'
VOCABULARY, CONTEXT_LIMIT = 262144, 262144
MODES, BINS = ('full', 'token', 'chunk'), (128, 512, 2048, 8192)
HEX = re.compile(r'^[a-f0-9]{64}$')
# None is an active refusal, never an invitation to infer a proof or budget.
GATES = {'stage_sha256': None, 'expected_inventory_sha256': None, 'prerequisite_helper_sha256': None, 'prerequisite_sha256': None, 'budget_sha256': None, 'allocation_schema_ready': None, 'outer_lifecycle_ready': None}
OLD_PINS = {
 'projects/gemma4-pilot/cases/text-native/adapters/i01_common_v1.py': 'fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c',
 'projects/gemma4-pilot/cases/text-native/adapters/i03_common_v1.py': '5cf67f53b5392e4425c4534ec6f97961066c190d24dc1280f31e66781a0fe03a',
 'projects/gemma4-pilot/cases/text-native/adapters/i03_prerequisite_v1.py': 'e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36',
 'projects/gemma4-pilot/cases/text-native/adapters/pilot_gpu_torch290_candidate.py': '5a73efe31962788baa04fa21abb1079be8a47e43393c23f3fa483e71c64b4f53',
 'projects/gemma4-pilot/cases/text-native/adapters/pilot_ascend_candidate_v3.py': '95b7b9302543d8a14995e293c790d5de9e23abc6041a53bb1d627ae3b5cd7ee8',
 'projects/gemma4-pilot/cases/text-native/adapters/pilot_gpu_peer_v2.py': 'fbf0b1dc4b03576852d166bc56d3bca14d6544be8aebd120ef0b92f146429eae',
 'projects/gemma4-pilot/cases/text-native/adapters/verify_snapshot.py': 'cd64a5f3f380d9cc04578848ba508ace3f1df0752ca952b8d575dd2904196f26',
 'projects/gemma4-pilot/cases/text-native/adapters/upstream-identity.json': '80dc0e0e59e5c526426b566d36a21f762a79d498986d5d6cd01098c8cb5decc3',
 'projects/gemma4-pilot/cases/text-native/transfer/npu_three_repeat_launcher_v4.py': 'c1719e831a557cd9707374138d9219a8ae887854dd029a1ec165631d9259f485',
 'skills/precision-compare/scripts/inference_capture.py': '5d388e846249d7fd74df1b15036f8a371e3267ada1b2fb0408bc51345ffad19c',
 'skills/precision-compare/scripts/artifact_io.py': '0260cd5ee1fd4e9d37e39bfd79efa9e663a1d48cb75b5adb31b84af9e1edbf39',
 'skills/precision-compare/scripts/conditions.py': 'e012c025395f2f0474f0b35074d8417ec5a217f3659f82218de0f5d05068036d'}


def require(ok, message):
    if not ok: raise ValueError(message)


def utc(): return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b''): digest.update(block)
    return digest.hexdigest()


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate JSON key'); result[key] = value
        return result
    def reject(value): raise ValueError('nonfinite JSON token: ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs, parse_constant=reject)


def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def ref(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'regular non-symlink file required: ' + str(path))
    return {'path': str(path.resolve(strict=True)), 'sha256': sha(path), 'size_bytes': path.stat().st_size}


def check_refs(refs):
    for value in refs.values(): require(ref(value['path']) == value, 'frozen source changed: ' + value['path'])


def pure_module(path, digest, name):
    require(ref(path)['sha256'] == digest, 'pure helper SHA differs')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    require(not any(k in sys.modules for k in ('torch', 'torch_npu', 'numpy', 'transformers')),
            'pre-native gate imported a framework')
    return module


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--backend', choices=('gpu', 'npu'), required=True)
    parser.add_argument('--prompt-bin', type=int, choices=BINS, required=True)
    for name in ('model', 'manifest', 'input-dir', 'allocation-receipt', 'allocation-source', 'source-manifest',
                 'stage-spec', 'expected-inventory', 'prerequisite-helper', 'prerequisite', 'budget', 'launch-receipt', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    for name in ('allocation-source', 'source-manifest', 'stage-spec', 'expected-inventory', 'prerequisite-helper',
                 'prerequisite', 'budget', 'launch-receipt'):
        parser.add_argument('--' + name + '-sha256', required=True)
    for name in ('numerics-policy', 'driver-source', 'native-mapping', 'native-source'):
        parser.add_argument('--' + name, type=Path)
    parser.add_argument('--device', required=True)
    return parser.parse_args()


def inventory(manifest_path, input_dir):
    """Independent collector-side derivation; never imports the expected builder."""
    manifest = read(manifest_path)
    require(sha(manifest_path) == MANIFEST_SHA256 and len(manifest['samples']) == 48 and
            manifest['requested_prompt_bins_including_BOS'] == list(BINS) and manifest['requested_per_bin'] == 12 and
            manifest['continuation_tokens'] == 32 and manifest['selection_on_model_outputs'] is False,
            'frozen unselected English cohort differs')
    result, seen, articles = [], set(), set()
    for descriptor in manifest['samples']:
        name = descriptor['file']; relative = PurePosixPath(name)
        require(relative.name == name and '\\' not in name and name.endswith('.json'), 'flat input name required')
        path = Path(input_dir) / name; actual = ref(path)
        require(path.resolve().is_relative_to(Path(input_dir).resolve()) and actual['sha256'] == descriptor['sha256'] and
                actual['size_bytes'] == descriptor['bytes'], 'input identity differs')
        doc = read(path); prompt = doc['prompt']; tail = doc['continuation']; seq = prompt + tail; P = len(prompt); L = len(seq)
        require(P in BINS and P == descriptor['prompt_length_including_BOS'] and len(tail) == 32 and L <= CONTEXT_LIMIT and
                all(type(x) is int and 0 <= x < VOCABULARY for x in seq) and seq[0] == 2, 'input token geometry differs')
        sample = doc['sample']; article = descriptor['normalized_article_sha256']
        require(sample == descriptor['sample'] and sample not in seen and article not in articles and
                doc['normalized_article_sha256'] == article and doc['source_partition'] == 'train_reserved_disjoint_articles' and
                doc['input_role'] == 'reserved_validation_not_for_policy_selection' and doc['independent_representative_example'] is True,
                'article/sample/role differs')
        seen.add(sample); articles.add(article)
        positions = sorted(set((j * (P - 1)) // 15 for j in range(16)).union(range(P - 1, P + 31)))
        split = P // 2 - 1
        plans = {mode: ([[0, L]] if mode == 'full' else
                       ([[0, P]] if mode == 'token' else [[0, split], [split, P]]) + [[j, j + 1] for j in range(P, L)])
                 for mode in MODES}
        result.append({'sample': sample, 'input_file': name, 'input_ref': actual, 'article_sha256': article,
                       'P': P, 'L': L, 'sequence': seq, 'positions': positions, 'plans': plans})
    require(all(sum(x['P'] == P for x in result) == 12 for P in BINS), 'exact twelve samples per bin required')
    return result


def check_expected(document, rows, stage_sha):
    require(document['task'] == TASK and document['stage_id'] == STAGE_ID and document['stage_spec_sha256'] == stage_sha and
            document['manifest_sha256'] == MANIFEST_SHA256 and document['config_sha256'] == CONFIG_SHA256 and
            document['vocabulary_size'] == VOCABULARY and len(document['samples']) == 48, 'independent expected identity differs')
    for expected, actual in zip(document['samples'], rows):
        require(expected['sample'] == actual['sample'] and expected['input_file'] == actual['input_file'] and
                expected['input_sha256'] == actual['input_ref']['sha256'] and expected['article_sha256'] == actual['article_sha256'] and
                expected['input_ids'] == actual['sequence'] and expected['prompt_length'] == actual['P'] and
                expected['sequence_length'] == actual['L'] and expected['all_target_positions'] == list(range(1, actual['L'])) and
                expected['all_target_tokens'] == actual['sequence'][1:] and expected['distribution_positions'] == actual['positions'] and
                expected['selected_native_BF16_shape'] == [47, VOCABULARY] and
                expected['original_full_native_shape'] == [1, actual['L'], VOCABULARY] and len(expected['modes']) == len(MODES),
                'independent expected coordinates/mode inventory differ')
        for mode, expected_plan in zip(MODES, expected['modes']):
            require(expected_plan['mode'] == mode and expected_plan['input_spans_zero_based_half_open'] == actual['plans'][mode] and
                    expected_plan['native_calls'] == len(actual['plans'][mode]) and expected_plan['use_cache'] == (mode != 'full') and
                    expected_plan['logits_to_keep'] == 0 and expected_plan['labels_supplied'] is False and
                    expected_plan['shared_kv_states_supplied'] is False, 'independent mode plan differs')
    pairs = [{'a_backend': 'GPU', 'a_mode': m, 'b_backend': 'NPU', 'b_mode': m, 'kind': 'cross_backend_matched'} for m in MODES]
    for backend in ('GPU', 'NPU'):
        pairs.extend({'a_backend': backend, 'a_mode': a, 'b_backend': backend, 'b_mode': b, 'kind': 'within_backend_partition'}
                     for a, b in itertools.combinations(MODES, 2))
    require(document['pairs_per_input'] == pairs and document['counts']['pairs_total'] == 432 and
            document['counts']['all_target_scores_per_backend'] == 396144 and document['counts']['calls_per_backend'] == 3264,
            'all-nine pair or cohort counts differ')


def prepare(args, entry):
    require(all(isinstance(GATES[key], str) and HEX.fullmatch(GATES[key]) for key in
                ('stage_sha256', 'expected_inventory_sha256', 'prerequisite_helper_sha256', 'prerequisite_sha256', 'budget_sha256')) and
            GATES['allocation_schema_ready'] is True and GATES['outer_lifecycle_ready'] is True,
            'reserved48 native stage/proof/budget/lifecycle remains unready')
    require(not any(k in sys.modules for k in ('torch', 'torch_npu', 'numpy', 'transformers')), 'framework imported before gates')
    require(args.device == ('cuda:0' if args.backend == 'gpu' else 'npu:0'), 'single compute device0 required')
    refs = {}
    for name, value in OLD_PINS.items():
        item = ref(REPO / name); require(item['sha256'] == value, 'old reviewed source changed: ' + name); refs[name] = item
    source_manifest = read(args.source_manifest)
    require(sha(args.source_manifest) == args.source_manifest_sha256 and source_manifest['task'] == TASK,
            'outer-frozen source manifest differs')
    for name, digest in source_manifest['files'].items():
        relative = PurePosixPath(name)
        require(not relative.is_absolute() and '..' not in relative.parts and '\\' not in name, 'source manifest relative path differs')
        path = REPO.joinpath(*relative.parts); item = ref(path)
        require(path.resolve().is_relative_to(REPO) and item['sha256'] == digest, 'new source manifest hash differs'); refs[name] = item
    for path in (Path(__file__), Path(entry), HERE / 'reserved48_expected_v1.py'):
        require(str(path.relative_to(REPO).as_posix()) in source_manifest['files'], 'new collector source missing from reviewed closure')
    for name in ('stage_spec', 'expected_inventory', 'prerequisite_helper', 'prerequisite', 'budget'):
        digest = getattr(args, name + '_sha256'); gate = GATES[name + '_sha256' if name != 'stage_spec' else 'stage_sha256']
        require(digest == gate and ref(getattr(args, name))['sha256'] == digest, 'frozen ' + name + ' differs')
    for name in ('allocation_receipt', 'allocation_source', 'source_manifest', 'launch_receipt', 'manifest'):
        refs[name] = ref(getattr(args, name))
    require(refs['allocation_source']['sha256'] == args.allocation_source_sha256 and
            refs['launch_receipt']['sha256'] == args.launch_receipt_sha256, 'allocation/launch source SHA differs')
    stage, budget = read(args.stage_spec), read(args.budget)
    require(stage['stage_id'] == STAGE_ID and stage['task'] == TASK and stage['status'] == 'prepared_not_executed' and
            stage['manifest_sha256'] == MANIFEST_SHA256 and stage['native_tasks'] == ['I05', 'Q01'] and
            stage['input_prompt_bins'] == list(BINS), 'frozen stage semantics differ')
    limits = budget['limits']; require(budget['task'] == TASK and budget['stage_sha256'] == args.stage_spec_sha256 and
        limits['cpu_row_chunk'] == 32 and limits['mode_product_bytes'] == 48 * 1024**2 and
        limits['input_product_bytes'] == 160 * 1024**2 and limits['bin_product_bytes'] == 2 * 1024**3 and
        limits['minimum_source_free_bytes'] >= 8 * 1024**3 and limits['external_hard_watchdog_required'] is True,
        'reviewed bounded streaming/storage contract differs')
    seconds = limits['native_seconds_by_prompt_bin'][str(args.prompt_bin)]
    require(type(seconds) is int and 0 < seconds <= 10800 and
            type(limits['per_input_seconds_by_prompt_bin'][str(args.prompt_bin)]) is int,
            'finite native/input budget missing')
    proof = pure_module(args.prerequisite_helper, args.prerequisite_helper_sha256, '_reserved48_pre_native_proof').prerequisite(
        args.prerequisite, args.prerequisite_sha256)
    require(proof['native_executions_started'] == 0 and proof['document']['kind'] == 'reserved48-native-prerequisite',
            'actual prior numeric/CPU proof required before model/device/claim')
    refs.update({'prerequisite/' + name: value for name, value in proof['refs'].items()})
    rows = inventory(args.manifest, args.input_dir); expected = read(args.expected_inventory); check_expected(expected, rows, args.stage_spec_sha256)
    for row in rows: refs['input/' + row['sample']] = row['input_ref']
    for name in ('stage_spec', 'expected_inventory', 'prerequisite_helper', 'prerequisite', 'budget'):
        refs[name] = ref(getattr(args, name))
    allocation, platform, launch = read(args.allocation_receipt), read(args.allocation_source), read(args.launch_receipt)
    require(allocation['allocation_id'] == platform['allocation_id'] == launch['allocation_id'] and
            isinstance(platform['allocation_id'], str) and platform['allocation_id'] and launch['task'] == TASK and
            launch['backend'] == args.backend and launch['prompt_bin'] == args.prompt_bin and launch['status'] == 'claimed' and
            launch['permanent_claim'] is True and launch['native_launches'] == 1 and launch['model_loads'] == 1 and
            launch['automatic_retry'] is False and launch['external_hard_watchdog_seconds'] >= seconds,
            'new actual allocation/permanent one-shot launch binding required')
    for name, item in refs.items():
        if name in ('allocation_source', 'source_manifest', 'stage_spec', 'expected_inventory', 'prerequisite', 'budget'):
            require(launch['frozen_refs'][name] == item, 'pre-native outer source binding differs: ' + name)
    require(sha(args.model / 'config.json') == CONFIG_SHA256, 'official model configuration changed')
    if args.backend == 'gpu': require(args.numerics_policy is not None, 'GPU policy required')
    else: require(all(getattr(args, k) is not None for k in ('driver_source', 'native_mapping', 'native_source')), 'NPU native/driver refs required')
    for name in ('numerics_policy', 'driver_source', 'native_mapping', 'native_source'):
        path = getattr(args, name)
        if path is not None: refs[name] = ref(path)
    require(not args.output.exists() and not args.output.is_symlink(), 'exclusive fresh output required')
    check_refs(refs)
    return {'stage': stage, 'budget': budget, 'proof': proof, 'all_rows': rows,
            'rows': [row for row in rows if row['P'] == args.prompt_bin], 'refs': refs,
            'started_utc': utc(), 'started_monotonic': time.monotonic()}


@contextmanager
def bounded_native(seconds):
    require(hasattr(signal, 'SIGALRM') and type(seconds) is int and seconds > 0, 'POSIX finite native bound required')
    def expired(signum, frame): raise TimeoutError('reserved48 cooperative native deadline; external watchdog owns hard cleanup')
    old = signal.signal(signal.SIGALRM, expired); signal.setitimer(signal.ITIMER_REAL, seconds)
    try: yield
    finally: signal.setitimer(signal.ITIMER_REAL, 0); signal.signal(signal.SIGALRM, old)


class Writer:
    """Count owned writes; this is a sampled software guard, not disk reservation."""
    def __init__(self, output, limits):
        self.output, self.limits = Path(output), limits
        self.output.mkdir(parents=False, exist_ok=False); self.files = {}; self.bytes = 0

    def target(self, name):
        relative = PurePosixPath(name)
        require(not relative.is_absolute() and relative.parts and '..' not in relative.parts and '\\' not in name,
                'contained relative product path required')
        path = self.output.joinpath(*relative.parts)
        current = self.output
        for part in relative.parts[:-1]:
            current /= part; require(not current.is_symlink(), 'product directory link refused'); current.mkdir(exist_ok=True)
        require(not path.exists() and not path.is_symlink(), 'product already exists')
        return path

    def check(self, extra=0, mode=None, sample=None):
        require(self.bytes + extra <= self.limits['bin_product_bytes'], 'bin products exceed reviewed cap')
        require(shutil.disk_usage(self.output).free >= self.limits['minimum_source_free_bytes'] + extra, 'source free-space guard failed')
        for prefix, cap in ((mode, self.limits['mode_product_bytes']), (sample, self.limits['input_product_bytes'])):
            if prefix:
                used = sum(value['size_bytes'] for key, value in self.files.items() if key.startswith(prefix + '/'))
                require(used + extra <= cap, 'mode/input product cap exceeded')

    def adopt(self, path, mode=None, sample=None):
        path = Path(path); name = path.relative_to(self.output).as_posix(); item = ref(path)
        require(name not in self.files and path.resolve().is_relative_to(self.output.resolve()), 'adopted product differs')
        self.check(item['size_bytes'], mode, sample); self.files[name] = item; self.bytes += item['size_bytes']; return item

    def put(self, name, value, mode=None, sample=None):
        raw = (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
        require(len(raw) <= 16 * 1024**2, 'metadata product exceeds16MiB')
        self.check(len(raw), mode, sample); path = self.target(name)
        with path.open('xb') as stream: stream.write(raw)
        return self.adopt(path, mode, sample)


def cache_metadata(cache, consumed, layer_types, controlled, device):
    if cache is None:
        require(consumed == 0, 'missing nonempty native cache'); return {'present': False, 'logical_tokens': 0}
    require(len(cache.layers) == 48 and len(layer_types) == 48 and not getattr(cache, 'offloading', False) and
            int(cache.get_seq_length()) == consumed, 'cache logical prefix/layers/offload differs')
    layers = []
    for index, (layer, kind) in enumerate(zip(cache.layers, layer_types)):
        heads, width = (8, 256) if kind == 'sliding_attention' else (1, 512)
        require(kind in ('sliding_attention', 'full_attention'), 'unknown configured attention')
        entry = {'index': index, 'configured_attention': kind, 'class': type(layer).__module__ + '.' + type(layer).__qualname__,
                 'reported_sequence_length': int(layer.get_seq_length()), 'is_sliding': getattr(layer, 'is_sliding', None),
                 'sliding_window': getattr(layer, 'sliding_window', None)}
        require(entry['reported_sequence_length'] == consumed, 'per-layer logical consumed prefix differs')
        for name in ('keys', 'values'):
            tensor = getattr(layer, name); shape = list(tensor.shape)
            require(len(shape) == 4 and shape[:2] == [1, heads] and shape[-1] == width and 0 < shape[-2] <= consumed and
                    str(tensor.dtype) == 'torch.bfloat16' and str(tensor.device) == device, 'native cache geometry/dtype/device differs')
            if kind == 'full_attention': require(shape[-2] == consumed, 'full-attention cache unexpectedly clipped')
            elif shape[-2] < consumed:
                window = getattr(layer, 'sliding_window', None)
                require(getattr(layer, 'is_sliding', None) is True and type(window) is int and 0 < shape[-2] <= window,
                        'reduced cache lacks observed sliding-window provenance')
            entry[name] = controlled.tensor_metadata(tensor)
        require(entry['keys']['shape'] == entry['values']['shape'], 'K/V cache shapes differ'); layers.append(entry)
    return {'present': True, 'logical_tokens_consumed': consumed, 'reported_sequence_length': int(cache.get_seq_length()),
            'class': type(cache).__module__ + '.' + type(cache).__qualname__, 'layers': layers,
            'scope': 'native metadata only; no retained K/V value comparison or unobserved clipping assumption'}


def parameter_invariant(state):
    return {key: state[key] for key in ('model_object_id', 'class', 'config', 'module_training_flags', 'parameters')}


def observed_model_state(model, torch, controlled):
    """Preserve reviewed metadata and complete bounded native buffer fingerprints.

    The historical helper cannot byte-view a scalar BF16 tensor. Flattening the
    copied observation fixes that encoding gap without modifying model state.
    Any original helper error is retained explicitly beside the new fingerprint.
    """
    state = controlled.model_state(model, torch); named = list(model.named_buffers(remove_duplicate=False))
    require(len(state['buffers']) == len(named), 'buffer metadata inventory differs')
    copied = 0
    for record, (name, value) in zip(state['buffers'], named):
        require(record['name'] == name, 'buffer observation order/name differs')
        size = int(value.numel()) * int(value.element_size()); copied += size
        require(copied <= 8 * 1024**2, 'complete buffer fingerprint observation exceeds8MiB; state is unready')
        raw = value.detach().to(device='cpu', non_blocking=False, copy=True).contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()
        require(len(raw) == size, 'buffer native fingerprint byte count differs')
        if 'content_probe_gap' in record: record['prior_helper_content_probe_gap'] = record.pop('content_probe_gap')
        record['content_sha256'] = hashlib.sha256(raw).hexdigest()
        record['fingerprint_encoding'] = 'synchronous CPU copy, contiguous.reshape(-1).view(uint8), original native bytes'
    return state


def check_model_state(baseline, actual):
    require(parameter_invariant(actual) == parameter_invariant(baseline), 'model object/parameter versions/storage/config changed')
    require(all(isinstance(item.get('content_sha256'), str) and HEX.fullmatch(item['content_sha256']) and
                'content_probe_gap' not in item for item in actual['buffers']), 'complete buffer fingerprints unavailable')
    require(actual['buffers'] == baseline['buffers'], 'buffer metadata/content differs from loaded baseline')


def check_mode_state(baseline, before, after, rng_before, rng_after):
    check_model_state(baseline, before); check_model_state(baseline, after)
    require(rng_after == rng_before, 'RNG advanced during inference mode; state carryover is outside this stage')


def stream_logits(logits, start, row, torch, np, derive_logprobs, selected, targets, digests, stream_digest):
    """Consume synchronous CPU BF16 slabs, never concatenate the full raw sequence."""
    require(sys.byteorder == 'little', 'native BF16 byte export requires reviewed little-endian host')
    require(list(logits.shape)[:1] == [1] and list(logits.shape)[-1:] == [VOCABULARY] and len(logits.shape) == 3 and
            str(logits.dtype) == 'torch.bfloat16', 'original full-vocabulary BF16 logits required')
    count = int(logits.shape[1])
    for lo in range(0, count, 32):
        hi = min(count, lo + 32)
        slab = logits[0, lo:hi, :].detach().to(device='cpu', non_blocking=False, copy=True).contiguous()
        values = slab.double().numpy()
        require(values.shape == (hi - lo, VOCABULARY) and np.isfinite(values).all(), 'all valid native rows including unscored final row must be finite')
        words = slab.view(torch.uint16).numpy(); scored = min(hi - lo, max(0, row['L'] - 1 - (start + lo)))
        normalized = derive_logprobs(values[:scored], dtype='float64') if scored else None
        if scored: require(normalized.shape == (scored, VOCABULARY) and np.isfinite(normalized).all(), 'shared FP64 log_softmax result differs')
        for index in range(hi - lo):
            position = start + lo + index
            require(position == len(digests) and position < row['L'], 'streamed native position gap/overlap')
            native_bytes = words[index].astype('<u2', copy=False).tobytes(order='C')
            digest = hashlib.sha256(native_bytes).hexdigest(); stream_digest.update(native_bytes)
            digests.append({'prediction_position': position, 'sha256': digest, 'native_data_bytes': len(native_bytes)})
            if position in row['positions']:
                require(position not in selected, 'duplicate selected native row'); selected[position] = slab[index].clone()
            if position < row['L'] - 1:
                token = row['sequence'][position + 1]; native = float(values[index, token]); lp = float(normalized[index, token])
                maximum_token = int(np.argmax(values[index])); maximum = float(values[index, maximum_token])
                # Reuse the shared normalization; this shift is not a second independent LSE algorithm.
                normalizer = maximum - float(normalized[index, maximum_token])
                require(math.isfinite(normalizer) and abs((native - normalizer) - lp) <= 1e-12, 'source scalar/normalizer formula differs')
                targets.append({'sample': row['sample'], 'position': position + 1, 'prediction_position': position, 'token': token,
                    'raw_target_bf16_u16': int(words[index, token]), 'raw_target_value': native, 'logprob': lp,
                    'source_logsumexp': normalizer, 'source_logsumexp_origin': 'raw_max - shared_FP64_logprob_at_raw_argmax',
                    'raw_argmax_token_lowest_id': maximum_token, 'raw_argmax_bf16_u16': int(words[index, maximum_token]),
                    'raw_row_sha256': digest})
        del normalized, values, words, slab


def capture_mode(model, torch, np, controlled, derive_logprobs, args, row, mode, writer, synchronize, deadline):
    prefix = 'samples/' + row['sample']; mode_prefix = prefix + '/' + mode
    selected, targets, digests, events = {}, [], [], []
    stream_digest = hashlib.sha256(); cache = None; prior_cache_id = None
    layer_types = model.config.text_config.layer_types
    started = time.monotonic(); require(time.monotonic() < deadline, 'input deadline exhausted before mode')
    with torch.inference_mode():
        for call_index, (start, end) in enumerate(row['plans'][mode]):
            require(time.monotonic() < deadline, 'per-input streaming deadline exhausted')
            before = cache_metadata(cache, start, layer_types, controlled, args.device) if mode != 'full' else {'present': False}
            kwargs = {'input_ids': torch.tensor([row['sequence'][start:end]], dtype=torch.long, device=args.device),
                'attention_mask': torch.ones((1, end), dtype=torch.long, device=args.device),
                'position_ids': torch.arange(start, end, dtype=torch.long, device=args.device).reshape(1, -1),
                'past_key_values': cache, 'use_cache': mode != 'full', 'logits_to_keep': 0, 'return_dict': True}
            result = model(**kwargs); synchronize(); logits = result.logits
            require(list(logits.shape) == [1, end - start, VOCABULARY] and str(logits.device) == args.device, 'native shape/device sliced or altered')
            returned = getattr(result, 'past_key_values', None)
            if mode == 'full': require(returned is None, 'cache-off call returned cache')
            else:
                require(returned is not None and (cache is None or returned is cache), 'native cache identity changed within mode')
                cache = returned; prior_cache_id = id(cache)
            stream_logits(logits, start, row, torch, np, derive_logprobs, selected, targets, digests, stream_digest)
            after = cache_metadata(cache, end, layer_types, controlled, args.device) if mode != 'full' else {'present': False}
            events.append({'call': call_index, 'input_span': [start, end], 'input_token_sha256': hashlib.sha256(canonical(row['sequence'][start:end]).encode()).hexdigest(),
                'attention_mask_shape': [1, end], 'attention_mask_values': 'all ones from length, including valid token0',
                'position_span': [start, end], 'use_cache': mode != 'full', 'logits_to_keep': 0,
                'native_shape': [1, end - start, VOCABULARY], 'cache_before': before, 'cache_after': after})
            writer.check(mode=mode_prefix, sample=prefix)
            del result, logits, returned, kwargs
    require(len(digests) == row['L'] and len(targets) == row['L'] - 1 and sorted(selected) == row['positions'] and
            len(events) == len(row['plans'][mode]), 'streamed complete/selected inventory differs')
    native_path = writer.target(mode_prefix + '/selected-native-logits.safetensors')
    writer.check(47 * VOCABULARY * 2 + 131080, mode_prefix, prefix)
    retained = torch.stack([selected[position] for position in row['positions']], dim=0).contiguous()
    from safetensors.torch import save_file
    save_file({'logits': retained}, str(native_path), metadata={'task': TASK, 'sample': row['sample'], 'mode': mode,
        'scope': '47 selected original native BF16 full-vocabulary prediction rows; not complete raw sequence'})
    controlled.safetensors_header(native_path, {'logits': [47, VOCABULARY]})
    native_ref = writer.adopt(native_path, mode_prefix, prefix)
    writer.put(mode_prefix + '/source-target-scores.json', {'schema_version': 1, 'task': TASK, 'sample': row['sample'], 'mode': mode,
        'input_sha256': row['input_ref']['sha256'], 'scores': targets, 'normalization': 'shared inference_capture.derive_logprobs float64 matrices of at most32 CPU rows',
        'independence_limit': 'All targets were normalized from full raw vocabularies on the source; unselected raw rows are not retained, so their normalizers are not independently posthoc rederived'}, mode_prefix, prefix)
    writer.put(mode_prefix + '/native-row-digests.json', {'rows': digests, 'raw_stream_sha256': stream_digest.hexdigest(),
        'canonical_bytes': 'ordered valid native BF16 row bytes, uint16 little endian, no safetensors header',
        'all_valid_rows_checked_finite': row['L'], 'unscored_finite_last_position': row['L'] - 1,
        'full_raw_rows_retained': False}, mode_prefix, prefix)
    writer.put(mode_prefix + '/selected-row-inventory.json', {'sample': row['sample'], 'mode': mode, 'native': native_ref,
        'shape': [47, VOCABULARY], 'original_sequence_native_shape': [1, row['L'], VOCABULARY],
        'positions': [{'row': index, 'prediction_position': p, 'target_position': p + 1, 'token': row['sequence'][p + 1],
                       'raw_row_sha256': digests[p]['sha256']} for index, p in enumerate(row['positions'])],
        'cpu_derived_FP64_artifacts': 'not generated here; future common-CPU derivation must declare new artifact provenance'}, mode_prefix, prefix)
    writer.put(mode_prefix + '/events.json', events, mode_prefix, prefix)
    final_cache = cache_metadata(cache, row['L'], layer_types, controlled, args.device) if mode != 'full' else {'present': False}
    writer.put(mode_prefix + '/final-cache-metadata.json', final_cache, mode_prefix, prefix)
    retired = weakref.ref(cache) if cache is not None else None
    summary = {'sample': row['sample'], 'mode': mode, 'native_calls': len(events), 'valid_rows': len(digests), 'targets': len(targets),
               'selected_rows': 47, 'selected_native': native_ref, 'raw_stream_sha256': stream_digest.hexdigest(),
               'cache_object_id': prior_cache_id, 'duration_instrumented_seconds': time.monotonic() - started,
               'timing_scope': 'instrumented model calls, CPU transfers/derivation and evidence writes; not P01 latency'}
    del retained, selected, cache
    return summary, retired


def capture_all(model, torch, np, controlled, args, context, writer, seed, policy, synchronize):
    baseline = observed_model_state(model, torch, controlled); baseline_parameters = parameter_invariant(baseline)
    require(bool(baseline['parameters']) and all(type(record.get('version')) is int and isinstance(record.get('storage'), dict) and
            not record['storage'].get('unavailable') and type(record['storage'].get('data_ptr')) is int and
            record['storage']['data_ptr'] > 0 for record in baseline['parameters']), 'parameter version/storage metadata unavailable')
    check_model_state(baseline, baseline)
    writer.put('model-state-before-capture.json', baseline)
    summaries, baseline_rng = [], None
    settings = policy()
    for row in context['rows']:
        deadline = time.monotonic() + context['budget']['limits']['per_input_seconds_by_prompt_bin'][str(args.prompt_bin)]
        for mode in MODES:
            gc.collect(); synchronize(); reset = seed()
            rng = controlled.rng_observation(torch, args.backend)
            require(all(not value.get('unavailable', False) for value in rng.values()), 'complete RNG observation unavailable')
            if baseline_rng is None: baseline_rng = rng
            require(rng == baseline_rng and policy() == settings, 'per-input/mode reset RNG/policy differs')
            before = observed_model_state(model, torch, controlled)
            check_model_state(baseline, before)
            summary, retired = capture_mode(model, torch, np, controlled, controlled.derive_logprobs, args, row, mode, writer, synchronize, deadline)
            gc.collect(); synchronize()
            require(retired is None or retired() is None, 'retired cache remains live after mode')
            after = observed_model_state(model, torch, controlled)
            require(parameter_invariant(after) == baseline_parameters and policy() == settings, 'parameter versions/storage/config or policy mutated during mode')
            summary['reset'] = reset; summary['rng_before'] = rng; summary['rng_after'] = controlled.rng_observation(torch, args.backend)
            require(all(not value.get('unavailable', False) for value in summary['rng_after'].values()), 'complete post-mode RNG observation unavailable')
            check_mode_state(baseline, before, after, rng, summary['rng_after'])
            summary['parameter_invariant_unchanged'] = True
            summary['parameter_state_before_sha256'] = hashlib.sha256(canonical(parameter_invariant(before)).encode()).hexdigest()
            summary['parameter_state_after_sha256'] = hashlib.sha256(canonical(parameter_invariant(after)).encode()).hexdigest()
            summary['buffer_metadata_unchanged'] = before['buffers'] == after['buffers']
            summary['buffer_metadata_before_sha256'] = hashlib.sha256(canonical(before['buffers']).encode()).hexdigest()
            summary['buffer_metadata_after_sha256'] = hashlib.sha256(canonical(after['buffers']).encode()).hexdigest()
            summaries.append(summary)
            writer.put('samples/' + row['sample'] + '/' + mode + '/capture-summary.json', summary,
                       'samples/' + row['sample'] + '/' + mode, 'samples/' + row['sample'])
    require(len(summaries) == 36 and sum(x['native_calls'] for x in summaries) == 816 and
            sum(x['selected_rows'] for x in summaries) == 1692, 'twelve-input bin capture inventory differs')
    final_state = observed_model_state(model, torch, controlled); check_model_state(baseline, final_state)
    writer.put('model-state-after-capture.json', final_state)
    return summaries


def runtime_sources(writer, values):
    """Freeze explicit implementation bytes while the native runtime still exists."""
    result = {}
    for index, (name, value) in enumerate(sorted(values.items())):
        source = Path(value['path'] if isinstance(value, dict) else value); item = ref(source)
        require(item['size_bytes'] <= 16 * 1024**2, 'runtime source exceeds metadata cap')
        target = writer.target('runtime-sources/%03d/%s' % (index, source.name)); writer.check(item['size_bytes'])
        with source.open('rb') as reader, target.open('xb') as output: shutil.copyfileobj(reader, output, 1024**2)
        copied = writer.adopt(target); require(copied['sha256'] == item['sha256'], 'runtime source copy differs')
        result[name] = {'original': item, 'frozen_copy': copied}
    writer.put('runtime-source-map.json', result); return result


def finalize(args, context, writer, runtime):
    check_refs(context['refs'])
    for value in runtime['runtime_sources'].values():
        require(ref(value['original']['path']) == value['original'] and ref(value['frozen_copy']['path']) == value['frozen_copy'],
                'runtime source changed during capture')
    writer.put('runtime.json', runtime)
    writer.put('frozen-source-refs.json', context['refs'])
    check_refs(context['refs'])
    for value in writer.files.values(): require(ref(value['path']) == value, 'owned evidence changed before completion')
    manifest = writer.put('artifacts-manifest.json', {'schema_version': 1, 'task': TASK,
        'files': {name: {'sha256': value['sha256'], 'size_bytes': value['size_bytes']} for name, value in writer.files.items()}})
    status = {'schema_version': 1, 'task': TASK, 'status': 'completed', 'backend': args.backend, 'prompt_bin': args.prompt_bin,
        'inputs': 12, 'observations': 36, 'native_calls': 816, 'model_loads': 1, 'selected_rows': 1692,
        'all_target_scores': sum(3 * (row['L'] - 1) for row in context['rows']),
        'all_valid_native_rows': sum(3 * row['L'] for row in context['rows']),
        'manifest_sha256': manifest['sha256'], 'finished_utc': utc(), 'duration_instrumented_seconds': time.monotonic() - context['started_monotonic'],
        'full_raw_retained': False, 'full_KV_retained': False, 'independent_all_target_normalizer_replay': False,
        'Q02_executed': False, 'P01_executed': False, 'thresholds': None, 'acceptance': None}
    writer.put('status.json', status); return status

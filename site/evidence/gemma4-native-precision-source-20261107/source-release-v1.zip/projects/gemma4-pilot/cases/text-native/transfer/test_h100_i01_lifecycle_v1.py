"""CPU-only lifecycle regressions; never main(), Torch, CUDA or nvidia-smi."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i01_lifecycle_under_test', HERE / 'h100_i01_lifecycle_v1.py')
job = importlib.util.module_from_spec(spec)
spec.loader.exec_module(job)


class Fixture(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.mockbase = {}
        for relative in job.BASE_PINS:
            path = self.root / 'source' / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(('CPU fixture ' + relative).encode())
            self.mockbase[relative] = job.sha(path)
        pins = dict(self.mockbase)
        for relative in (job.GPU_REL, job.COMMON_REL):
            path = self.root / 'source' / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b'CPU fixture, not a collector')
            pins[relative] = job.sha(path)
        for name in (job.ENTRY_NAME, job.LIFECYCLE_NAME):
            (self.root / name).write_bytes(b'CPU fixture, never executed')
        self.source = {'schema_version': 1, 'task_id': job.TASK_ID,
            'allocation_id': 'app-new-i01-cpu-fixture', 'vendor': 'NVIDIA', 'visible_count': 1,
            'observed_utc': '2026-11-06T12:00:00+00:00',
            'evidence_source': 'Synthetic CPU fixture, no real allocation',
            'entry_path': str(self.root / job.ENTRY_NAME),
            'entry_sha256': job.sha(self.root / job.ENTRY_NAME),
            'lifecycle_path': str(self.root / job.LIFECYCLE_NAME),
            'lifecycle_sha256': job.sha(self.root / job.LIFECYCLE_NAME), 'source_pins': pins}
        self.basepatch = patch.dict(job.BASE_PINS, self.mockbase, clear=True)
        self.basepatch.start()
        self.addCleanup(self.basepatch.stop)

    def write_source(self):
        job.put(self.root / job.SOURCE_NAME, self.source)

    def query(self, *_args, **_kwargs):
        return subprocess.CompletedProcess([], 0,
            b'GPU-REDACTED_DEVICE_UUID, NVIDIA H100 80GB HBM3, 580.95.05\n', b'')

    def test_strict_source_and_old_app_rejection(self):
        self.assertEqual(job.validate_source(self.source, self.root), self.source)
        for key, value in [('allocation_id', 'REDACTED_APP_ID'), ('visible_count', True),
                           ('task_id', 'old-task'), ('observed_utc', '2026-11-06T12:00:00+08:00')]:
            bad = {**self.source, key: value}
            with self.assertRaises(ValueError):
                job.validate_source(bad, self.root)
        with self.assertRaises(ValueError):
            job.validate_source({**self.source, 'unknown': 1}, self.root)

    def test_duplicate_nonfinite_and_unsafe_pin_rejection(self):
        for raw in (b'{"x":1,"x":2}', b'{"x":NaN}'):
            with self.assertRaises(ValueError):
                job.parse(raw)
        bad = {**self.source, 'source_pins': {**self.source['source_pins'], '../old/claim': 'a' * 64}}
        with self.assertRaises(ValueError):
            job.validate_source(bad, self.root)

    def test_source_mutation_and_frozen_raw_bytes(self):
        before = job.verify_sources(self.source, self.root)
        directory = self.root / 'freeze'
        directory.mkdir()
        copied = job.freeze_sources(directory, before, self.root)
        self.assertEqual(set(copied), set(before))
        for original, ref in copied.items():
            self.assertEqual(Path(ref['path']).read_bytes(), Path(original).read_bytes())
        path = self.root / 'source' / job.GPU_REL
        path.write_bytes(b'changed')
        with self.assertRaises(ValueError):
            job.verify_sources(self.source, self.root)

    @unittest.skipUnless(os.name == 'posix', 'POSIX symlink semantics')
    def test_parent_symlink_source_rejected(self):
        location = self.root / 'source' / job.CASE_REL / 'adapters'
        target = location.with_name('actual-adapters')
        location.rename(target)
        location.symlink_to(target, target_is_directory=True)
        with self.assertRaises(ValueError):
            job.verify_sources(self.source, self.root)

    def test_permanent_claim_concurrent_single_winner(self):
        (self.root / 'claims').mkdir()
        def claim(_):
            return job.claim_once(self.root, self.source['allocation_id'], {'synthetic': True})
        with ThreadPoolExecutor(max_workers=8) as executor:
            results = list(executor.map(claim, range(16)))
        self.assertEqual(sum(result is not None for result in results), 1)
        self.assertIsNone(claim(None))
        self.assertTrue((self.root / 'claims' / self.source['allocation_id'] / 'claim.json').is_file())

    def test_bounded_wait_never_requires_native(self):
        elapsed = [0.0]
        steps = []
        def pause(delay):
            self.assertLessEqual(delay, 1)
            steps.append(delay)
            elapsed[0] += delay
        self.assertFalse(job.wait_source(self.root / 'absent', 120, lambda: elapsed[0], pause))
        self.assertEqual(elapsed[0], 120)
        self.assertEqual(len(steps), 120)
        self.write_source()
        self.assertTrue(job.wait_source(self.root / job.SOURCE_NAME, 120, lambda: elapsed[0], pause))

    def test_launch_once_refuses_restarts_without_query_or_run(self):
        self.write_source()
        calls = []
        def run(argv, directory, deadline, root):
            calls.append(argv)
            self.assertEqual(root, self.root)
            self.assertLessEqual(deadline - time.monotonic(), job.TOTAL_SECONDS)
            self.assertIn('--worker', argv)
            return 0, {'status': 'completed'}
        with patch.object(job.sys, 'platform', 'linux'):
            self.assertEqual(job.launch(self.root, self.query, run), 0)
            self.assertEqual(job.launch(self.root,
                lambda *_a, **_k: self.fail('second native query'),
                lambda *_a: self.fail('second worker')), 0)
        self.assertEqual(len(calls), 1)

    def test_driver_failure_spends_claim_without_worker(self):
        self.write_source()
        def failed(*_a, **_k):
            return subprocess.CompletedProcess([], 1, b'', b'synthetic query failure')
        with patch.object(job.sys, 'platform', 'linux'):
            self.assertEqual(job.launch(self.root, failed, lambda *_a: self.fail('worker ran')), 1)
            self.assertEqual(job.launch(self.root, self.query, lambda *_a: self.fail('retry ran')), 0)
        directory = self.root / 'claims' / self.source['allocation_id']
        self.assertTrue((directory / 'launch-failure.json').is_file())
        self.assertTrue((directory / 'claim.json').is_file())

    def test_worker_failure_spends_claim(self):
        self.write_source()
        def failed(*_a):
            raise RuntimeError('synthetic preflight failure')
        with patch.object(job.sys, 'platform', 'linux'):
            self.assertEqual(job.launch(self.root, self.query, failed), 1)
            self.assertEqual(job.launch(self.root, self.query, lambda *_a: self.fail('retry ran')), 0)

    def test_changed_pin_rejected_before_claim_or_native(self):
        self.write_source()
        (self.root / 'source' / job.GPU_REL).write_bytes(b'changed')
        with patch.object(job.sys, 'platform', 'linux'), self.assertRaises(ValueError):
            job.launch(self.root, lambda *_a, **_k: self.fail('native ran'), lambda *_a: self.fail('worker ran'))
        self.assertFalse((self.root / 'claims').exists())

    def test_runtime_package_bytes_survive_source_removal(self):
        external = self.root / 'gpu-container-tmp' / 'module.py'
        external.parent.mkdir()
        external.write_bytes(b'GPU temporary runtime source, CPU fixture only\n')
        reference = {'path': str(external), 'sha256': job.sha(external),
                     'size_bytes': external.stat().st_size}
        directory = self.root / 'runtime-evidence'
        directory.mkdir()
        frozen = job.freeze_runtime_refs(directory, {'package': reference})
        self.assertEqual(job.freeze_runtime_refs(directory, {'package': reference}, frozen), frozen)
        external.unlink()
        self.assertEqual(job.sha(frozen[str(external)]['path']), reference['sha256'])

    def test_runtime_source_forged_hash_and_copy_mutation_rejected(self):
        original = self.root / 'module.py'
        original.write_bytes(b'CPU fixture')
        reference = {'path': str(original), 'sha256': job.sha(original),
                     'size_bytes': original.stat().st_size}
        directory = self.root / 'runtime-evidence'
        directory.mkdir()
        with self.assertRaises(ValueError):
            job.freeze_runtime_refs(directory, {'package': {**reference, 'sha256': 'a' * 64}})
        frozen = job.freeze_runtime_refs(directory, {'package': reference})
        Path(frozen[str(original)]['path']).write_bytes(b'changed')
        with self.assertRaises(ValueError):
            job.freeze_runtime_refs(directory, {'package': reference}, frozen)


@unittest.skipUnless(sys.platform.startswith('linux'), 'Real Linux process supervision')
class LinuxProcesses(unittest.TestCase):
    def run_worker(self, code, available=2, maximum=1024 ** 2):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        directory = root / 'receipt'
        directory.mkdir()
        argv = [sys.executable, '-c', code, str(root)]
        started = time.monotonic()
        result, state = job.supervise(argv, directory,
            started + job.CLEANUP_RESERVE_SECONDS + available, root, maximum)
        self.assertLess(time.monotonic() - started, available + 5)
        self.assertEqual(state['remaining_descendants'], [])
        self.assertEqual(json.loads((directory / 'controller-receipt.json').read_text())['returncode'], result)
        return result, state

    def test_completed_cpu_worker(self):
        code, state = self.run_worker("print('CPU only')")
        self.assertEqual((code, state['status']), (0, 'completed'))

    def test_timeout_kills_stubborn_descendant(self):
        child = 'import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(60)'
        parent = "import subprocess,sys,time,signal;signal.signal(signal.SIGTERM,signal.SIG_IGN);subprocess.Popen([sys.executable,'-c',%r]);time.sleep(60)" % child
        code, state = self.run_worker(parent, available=.8)
        self.assertEqual((code, state['status']), (124, 'timed_out'))

    def test_normal_leader_exit_with_live_descendant_is_failure(self):
        child = 'import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(60)'
        parent = "import subprocess,sys,time;subprocess.Popen([sys.executable,'-c',%r]);time.sleep(.4)" % child
        code, state = self.run_worker(parent)
        self.assertEqual((code, state['status']), (1, 'unexpected_descendants'))
        self.assertTrue(state['live_descendants_at_worker_exit'])

    def test_sampled_storage_gate_stops_worker(self):
        code, state = self.run_worker("import pathlib,sys,time;(pathlib.Path(sys.argv[1])/'large').write_bytes(b'x'*8192);time.sleep(60)", available=4, maximum=4096)
        self.assertEqual((code, state['status']), (1, 'interrupted_or_failed'))
        self.assertIn('storage budget', state['error'])


class RealExpectedInventory(unittest.TestCase):
    def test_actual_independent_bytes_are_frozen_before_model(self):
        case = HERE.parent
        module = job.load_pinned(case / 'adapters/i01_expected_inventory_v1.py',
            job.EXPECTED_SOURCE_SHA, 'i01_expected_cpu_test')
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / 'expected.json'
            result = module.build(case / 'inputs/discovery-v1/wikitext2-discovery-001.json',
                output, case / 'i01-stage-v1.json', job.SPEC_SHA)
            self.assertEqual(result['causal_targets'], 159)
            self.assertEqual(result['distinct_distribution_positions'], 47)
            self.assertEqual(output.stat().st_size, job.EXPECTED_JSON_BYTES)
            self.assertEqual(job.sha(output), job.EXPECTED_JSON_SHA)


if __name__ == '__main__':
    unittest.main()

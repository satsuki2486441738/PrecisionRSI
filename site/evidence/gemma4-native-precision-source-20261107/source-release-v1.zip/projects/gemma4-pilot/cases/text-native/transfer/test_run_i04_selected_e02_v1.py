"""Synthetic recorder/export fixtures, not real I04 numerical evidence."""
import base64
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import tarfile
import tempfile
import time
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent;REPO=HERE.parents[4]
spec=importlib.util.spec_from_file_location('i04_e02_small_runner',HERE/'run_i04_selected_e02_v1.py')
tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)


def fixture(root,exit_code=0,sleep=False):
    (root/'runs').mkdir();here=root/'e02tools';here.mkdir()
    for name,source in [('record_run.py',REPO/'skills/precision-compare/scripts/record_run.py'),
            ('verify_i03_selected_e02_v1.py',HERE.parent/'adapters/verify_i03_selected_e02_v1.py'),
            ('run_i04_selected_e02_v1.py',Path(tool.__file__))]:shutil.copyfile(source,here/name)
    source=here/'verify_i04_selected_e02_v1.py'
    if sleep:source.write_text('import time\ntime.sleep(60)\n',encoding='utf-8')
    elif exit_code:source.write_text('raise SystemExit(%d)\n'%exit_code,encoding='utf-8')
    else:source.write_text('''import sys,json,hashlib
from pathlib import Path
o=Path(sys.argv[sys.argv.index('--output-dir')+1]);o.mkdir()
p=Path(__file__).with_name('synthetic-source.json');p.write_text('{"synthetic_only":true}\\n')
d=hashlib.sha256(p.read_bytes()).hexdigest()
scope={'target_pairs':18,'request_target_counts':{'A':159,'B':95},'matched_cross_backend_distribution_pair_rows':282,'independent_distribution_pair_rows':282,'admitted_large_sources_final_bytehash_checked':572,'native_KV_checks':0}
result={'status':'independent_i04_selected_e02_checks_matched','scope':scope,'source_report':{},'native_KV_checks':[],'native_executions_started':0,'thresholds':None,'acceptance':None,'synthetic_not_native':True}
large=[{'original_path':'/synthetic/missing-%03d.npy'%i,'resolved_path':'/also-missing/%03d.npy'%i,'sha256':'a'*64,'size':123,'backend':'GPU' if i<286 else 'NPU'} for i in range(572)]
proof={'checked_sources':{str(p):{'sha256':d,'size':p.stat().st_size}},'original_source_files':{'/original/synthetic-source.json':{'actual_path':str(p),'sha256':d,'size':p.stat().st_size,'large':False}},'all_admitted_large_final_hashes':572}
for x in large:proof['checked_sources'][x['resolved_path']]={'sha256':x['sha256'],'size':x['size']};proof['original_source_files'][x['original_path']]={'actual_path':x['resolved_path'],'sha256':x['sha256'],'size':x['size'],'large':True}
for name,doc in [('e02-report.json',result),('source-proof.json',proof),('admitted-large-source-hashes.json',large),('selection.json',{'synthetic_not_native':True})]:
 (o/name).write_text(json.dumps(doc,indent=2)+'\\n')
''',encoding='utf-8')
    original_tools=root/'tools/original';original_tools.mkdir(parents=True);files={}
    for name in ('projects/gemma4-pilot/cases/text-native/transfer/run_i04_actual_compare_v1.py',
            'projects/gemma4-pilot/cases/text-native/adapters/admit_i04_batch_padding_v1.py'):
        dst=original_tools/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REPO/name,dst);files[name]={'sha256':tool.sha(dst)}
    tool.put(original_tools/'tool-bundle-manifest.json',{'files':files})
    run=root/'runs/original-comparison';run.mkdir();report=run/'i04-comparison-report.json'
    tool.put(report,{'status':'i04_raw_bf16_batch_padding_and_request_pairs_checked','scope':{'target_distribution_pairs':18,'original_large_sources_final_bytehash_checked':572},
        'thresholds':None,'acceptance':None,'synthetic_not_native':True})
    controller=run/'controller-receipt.json';tool.put(controller,{'task':'I04','status':'completed','returncode':0,'child_returncode':0,'timed_out':False,
        'native_executions_started':0,'whole_cpu_seconds':960,'analysis_seconds':900,'tools_root':str(original_tools),
        'tool_manifest_sha256':tool.sha(original_tools/'tool-bundle-manifest.json'),
        'argv':['python','-B',str(original_tools/'projects/gemma4-pilot/cases/text-native/adapters/admit_i04_batch_padding_v1.py')],
        'report':{'path':str(report),'sha256':tool.sha(report)}})
    spec=importlib.util.spec_from_file_location('actual_temporary_i04_runner',here/'run_i04_selected_e02_v1.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.VERIFY_SHA=tool.sha(source)
    return module,controller,here


class SmallExport(unittest.TestCase):
    def test_572_absent_array_aliases_classified_before_stat_open(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);small=root/'small.json';small.write_text('{"synthetic":true}');digest=tool.sha(small)
            proof={'checked_sources':{str(small):{'sha256':digest}},'original_source_files':{}}
            for i in range(572):
                name='/missing-native/%03d.npy'%i;proof['checked_sources'][name]={'sha256':'a'*64}
                proof['original_source_files'][name]={'actual_path':'/missing-copied/%03d.npy'%i,'sha256':'a'*64,'large':True}
            payload=root/'payload';payload.mkdir();old_stat=Path.stat;old_open=Path.open
            def stat(p,*a,**k):
                if str(p).endswith(('.npy','.safetensors')):raise AssertionError('array stat forbidden')
                return old_stat(p,*a,**k)
            def opened(p,*a,**k):
                if str(p).endswith(('.npy','.safetensors')):raise AssertionError('array open forbidden')
                return old_open(p,*a,**k)
            with patch.object(Path,'stat',stat),patch.object(Path,'open',opened):catalog=tool.small_closure(proof,{},payload,time.monotonic())
            self.assertEqual(list(catalog),[str(small)])

    def test_original_gpu_alias_and_original_stdout_bin_are_preserved(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);source=root/'stdout.bin';source.write_bytes(b'original raw CPU log\n');payload=root/'payload';payload.mkdir()
            proof={'checked_sources':{str(source):{'sha256':tool.sha(source)}},
                'original_source_files':{'/original/stdout.bin':{'actual_path':str(source),'sha256':tool.sha(source),'large':False}}}
            result=tool.small_closure(proof,{},payload,time.monotonic());self.assertEqual(len(result),2)
            self.assertTrue(all((payload/ref['path']).read_bytes()==source.read_bytes() for ref in result.values()))

    def test_small_source_tamper_and_bounded_gzip_write_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);source=root/'small.json';source.write_text('{}');payload=root/'payload';payload.mkdir()
            proof={'checked_sources':{str(source):{'sha256':'0'*64}},'original_source_files':{}}
            with self.assertRaises(ValueError):tool.small_closure(proof,{},payload,time.monotonic())
            stream=io.BytesIO();sink=tool.BoundedSink(stream,time.monotonic())
            with patch.object(tool,'MAX_GZIP',8):
                sink.write(b'12345678')
                with self.assertRaises(ValueError):sink.write(b'9')
            self.assertEqual(stream.getvalue(),b'12345678')

    @unittest.skipUnless(os.name=='posix','Original recorder owned POSIX process groups')
    def test_success_real_generic_envelope_member_manifest_and_572_omissions(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);module,controller,_=fixture(root);code=module.run(root,controller,module.sha(controller));self.assertEqual(code,0)
            envelope=next((root/'runs').glob('*-json-base64.txt'));document=module.read(envelope)
            raw=base64.b64decode(document['controller_raw_base64']);self.assertEqual(hashlib.sha256(raw).hexdigest(),document['controller_sha256'])
            self.assertEqual(Path(document['controller_path']).read_bytes(),raw)
            archive=base64.b64decode(document['archive']['base64']);self.assertEqual(hashlib.sha256(archive).hexdigest(),document['archive']['sha256'])
            with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as package:
                members=package.getmembers();self.assertTrue(all(m.isfile() and not m.name.endswith(('.npy','.safetensors')) for m in members))
                inventory=json.load(package.extractfile('archive-members.json'));self.assertEqual(set(inventory['files'])|{'archive-members.json'},{m.name for m in members})
                for name,ref in inventory['files'].items():self.assertEqual(hashlib.sha256(package.extractfile(name).read()).hexdigest(),ref['sha256'])
                source_map=json.load(package.extractfile('payload/metadata-source-map.json'));self.assertEqual(len(source_map['omitted_large_sources']),572)
            state=module.read(Path(document['controller_path']));self.assertEqual((state['child_returncode'],state['returncode'],state['native_array_files_copied']),(0,0,0))
            with self.assertRaises(FileExistsError):module.run(root,controller,module.sha(controller))

    @unittest.skipUnless(os.name=='posix','Original recorder owned POSIX process groups')
    def test_real_child7_does_not_create_success_archive_or_envelope(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);module,controller,_=fixture(root,exit_code=7);self.assertEqual(module.run(root,controller,module.sha(controller)),2)
            state=module.read(next((root/'runs').glob('compare-i04-selected-e02-*/controller-receipt.json')))
            self.assertEqual((state['status'],state['child_returncode']),('failed',7));self.assertEqual(list((root/'runs').glob('*-json-base64.txt')),[])

    @unittest.skipUnless(os.name=='posix','Original recorder owned POSIX process groups')
    def test_real_generic_timeout_keeps_failed_evidence_and_reaps_child(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);module,controller,_=fixture(root,sleep=True)
            with patch.object(module,'GENERIC',.05):self.assertEqual(module.run(root,controller,module.sha(controller)),2)
            state=module.read(next((root/'runs').glob('compare-i04-selected-e02-*/controller-receipt.json')));self.assertTrue(state['timed_out'])
            command=module.read(Path(state['generic_receipt']['path']));self.assertEqual(command['status'],'timed_out')
            with self.assertRaises(ProcessLookupError):os.kill(command['child_pid'],0)

    def test_failed_original_comparison_never_gets_new_claim(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);module,controller,_=fixture(root);state=module.read(controller);state['returncode']=2
            controller.unlink();module.put(controller,state)
            with self.assertRaises(ValueError):module.preflight(root,controller,module.sha(controller))
            self.assertFalse((root/'i04-selected-e02-claim.json').exists())


if __name__=='__main__':unittest.main()

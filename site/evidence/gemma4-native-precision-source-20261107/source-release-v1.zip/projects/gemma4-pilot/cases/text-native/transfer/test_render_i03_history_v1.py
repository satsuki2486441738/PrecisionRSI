"""History schema/preservation and signed-blob tampering tests; no native work.

Actual completed E02/coverage and immutable target/distribution/KV metrics plus107
published records are read without editing them. Git reads are stubbed with an
explicit synthetic revision; no repository is created or modified.
"""
from collections import Counter
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import render_i03_history_v1 as h

REPO=Path(__file__).resolve().parents[5]
REVISION='1'*40  # Synthetic read-only Git protocol fixture, never a real archive.


def raw(doc):return (json.dumps(doc,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()


class Fixture:
    def __init__(self):
        self.history=(REPO/'site/data/evaluations.json').read_bytes();self.repairs=(REPO/'site/data/repairs.json').read_bytes()
        self.prior=h.read(self.history)['evaluations'][-1]
        self.previous_raw=(REPO/'site/evidence'/self.prior['id']/'coverage.json').read_bytes();self.previous=h.read(self.previous_raw)
        self.blobs={name:(REPO/h.PREFIX/name).read_bytes() for name in h.FILES}
        self.documents={name:h.read(blob) if name.endswith('.json') else blob.decode() for name,blob in self.blobs.items()}
        self.pins={name:h.digest(blob) for name,blob in self.blobs.items()}
    def entry(self):return h.build_entry(self.documents,self.pins,REVISION,self.prior)
    def git(self,repo,*args):
        if args[0]=='rev-parse':return (REVISION+'\n').encode()
        if args[0]=='ls-tree':return ('\n'.join(h.PREFIX+name for name in h.FILES)+'\n').encode()
        if args[0]=='show':
            name=args[1].split(':',1)[1]
            if name=='site/data/evaluations.json':return self.history
            if name=='site/data/repairs.json':return self.repairs.replace(b'\r\n',b'\n')
            return self.blobs[name.removeprefix(h.PREFIX)]
        raise AssertionError('unexpected Git operation '+repr(args))
    def populate(self,root):
        for name,blob in self.blobs.items():
            path=root/h.PREFIX/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(blob)
        for name,blob in (('evaluations.json',self.history),('repairs.json',self.repairs)):
            path=root/'site/data'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(blob)
        previous=root/'site/evidence'/self.prior['id']/'coverage.json';previous.parent.mkdir(parents=True);previous.write_bytes(self.previous_raw)
        output=root/h.CASE/'transfer';output.mkdir(parents=True);return output


class Tests(unittest.TestCase):
    def setUp(self):self.f=Fixture()
    def test_actual_metric_shapes_new_E02_subset_and_owning_history_schema(self):
        h.validate_evidence(self.f.documents,self.f.previous);entry=self.f.entry()
        self.assertEqual([p['side_ids'] for p in entry['comparisons'][:23]],h.SCORE_PAIRS)
        self.assertEqual(len(entry['sides']),10);self.assertEqual(len(entry['comparisons']),27)
        self.assertEqual(entry['comparisons'][0]['side_ids'],['gpu-full-r1','npu-full-r1'])
        # A NPU/NPU label must not get replaced twice by the peer side name.
        npu=entry['comparisons'][17]
        self.assertEqual(next(x['label'] for x in npu['metrics'] if x['id']=='side-a-top100-mean'),'npu-full-r1 Top-100 probability mass mean')
        with tempfile.TemporaryDirectory() as temp:
            site=Path(temp);(site/'data').mkdir();(site/'data/evaluations.json').write_bytes(raw({'schema_version':1,'updated_at':'2026-11-07','evaluations':[entry]}))
            for evidence in entry['evidence']:
                target=site/evidence['url'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b'')
            spec=importlib.util.spec_from_file_location('owning_history_validator',REPO/'.github/validate_history.py');owner=importlib.util.module_from_spec(spec);spec.loader.exec_module(owner)
            self.assertEqual(owner.validate_evaluations(site),1)
    def test_preserves107_original_objects_raw_prefix_unicode_and20_repairs(self):
        data,prefix=h.append_history(self.f.history,self.f.entry());old=h.read(self.f.history);new=h.read(data)
        self.assertEqual(new['evaluations'][:-1],old['evaluations']);self.assertEqual(len(new['evaluations']),108)
        marker=b'\n  ]\n}\n';oldprefix=self.f.history[:-len(marker)];segment=oldprefix[oldprefix.index(b'  "evaluations": ['):]
        self.assertIn(segment+b',\n',data);self.assertEqual(prefix,h.digest(segment));self.assertIn('恢复'.encode(),data)
        self.assertEqual(h.digest(self.f.repairs),h.REPAIRS_SHA)
    def test_rejects_scope_acceptance_cost_and_global_replay_tampering(self):
        changes=[lambda d:d['selected-metrics.json'].__setitem__('acceptance','passed'),
            lambda d:d['selected-metrics.json']['array_evidence'].__setitem__('independent_e02_scalar_math_recheck_completed',False),
            lambda d:d['coverage.json']['tasks'].pop(),lambda d:d['coverage.json']['tasks'][0].__setitem__('full_plan_task_complete',True),
            lambda d:d['execution-cost.json'].__setitem__('headline_speed_comparison_supported',True),
            lambda d:d['execution-cost.json']['model_children']['GPU'].__setitem__('recorded_wall_seconds',1.0),
            lambda d:d['independent-checks.json']['scope'].__setitem__('independent_distribution_pair_rows',1081),
            lambda d:d['independent-checks.json']['scope'].__setitem__('full_KV_global_reductions_repeated',True)]
        for change in changes:
            docs=copy.deepcopy(self.f.documents);change(docs)
            with self.subTest(change=change),self.assertRaises(ValueError):h.validate_evidence(docs,self.f.previous)
    def test_real_commit_argument_and_archived_working_blob_integrity(self):
        with tempfile.TemporaryDirectory() as temp:
            repo=Path(temp);self.f.populate(repo)
            with patch.object(h,'git',self.f.git):
                with self.assertRaisesRegex(ValueError,'actual full40hex'):h.archive_files(repo,'HEAD',self.f.history,self.f.repairs)
                docs,pins=h.archive_files(repo,REVISION,self.f.history,self.f.repairs);self.assertEqual(pins,self.f.pins)
                (repo/h.PREFIX/'coverage.json').write_bytes(self.f.blobs['coverage.json']+b' ')
                with self.assertRaisesRegex(ValueError,'working bytes differ'):h.archive_files(repo,REVISION,self.f.history,self.f.repairs)
    def test_full_private_render_preserves_public_bytes_and_writes_only_new_candidates(self):
        with tempfile.TemporaryDirectory() as temp:
            repo=Path(temp);output=self.f.populate(repo);before={p.relative_to(repo):p.read_bytes() for p in (repo/'site').rglob('*') if p.is_file()}
            with patch.object(h,'git',self.f.git):receipt=h.render(repo,REVISION,output)
            self.assertEqual(receipt['candidate_evaluations'],108);self.assertFalse(receipt['public_history_written']);self.assertFalse(receipt['git_modified'])
            self.assertEqual({p.relative_to(repo):p.read_bytes() for p in (repo/'site').rglob('*') if p.is_file()},before)
            self.assertEqual({p.name for p in Path(receipt['new_history_path']).parent.iterdir()},{'candidate-entry.json','new-history.json','render-receipt.json'})
            self.assertEqual(h.read(Path(receipt['new_history_path']).read_bytes())['evaluations'][:-1],h.read(self.f.history)['evaluations'])
    def test_duplicate_entry_and_malformed_json_are_rejected(self):
        doc=h.read(self.f.history);doc['evaluations'][0]['id']=h.ID
        with self.assertRaisesRegex(ValueError,'exact107'):h.append_history(raw(doc),self.f.entry())
        for invalid in (b'{"a":1,"a":2}',b'{"a":NaN}'):
            with self.assertRaises(ValueError):h.read(invalid)


if __name__=='__main__':unittest.main()

"""Synthetic CPU-only I03 boundary/state/proof regressions; no Torch import.

Private unittest patches shrink vocabulary/cache dimensions, never production
CLI values. Synthetic prerequisite maps deliberately cannot match the pinned
actual GPU map outside their in-process patch scope. No native claim is made.
"""
from contextlib import ExitStack, nullcontext
import copy
import hashlib
import json
from pathlib import Path
import random
import struct
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import i03_common_v1 as c
import i03_prerequisite_v1 as proof


class ProofFixture:
    def __init__(self, root):
        self.root=Path(root);(self.root/'proof').mkdir();self.stack=ExitStack()
        self.refs={}
        def add(name,document,origin):
            path=self.root/'proof'/name
            if isinstance(document,bytes):path.write_bytes(document)
            else:c.put(path,document)
            return {'path':'proof/'+name,'source_path':origin,'sha256':c.sha(path)}
        gpu=add('gpu-map.json',{'request':{'task':'I01','backend':'GPU'},'synthetic_not_native':True},'/synthetic/i01/gpu-map.json')
        npu=add('npu-map.json',{'request':{'task':'I01','backend':'NPU'},'synthetic_not_native':True},'/synthetic/i01/npu-map.json')
        self.stack.enter_context(patch.object(proof,'ACTUAL_GPU_MAP_SHA256',gpu['sha256']))
        analysis=add('analysis.py',(c.HERE/'i01_admission_compare_v1.py').read_bytes(),'/synthetic/tools/i01_admission_compare_v1.py')
        spec=add('comparison-spec.json',{'task':'gemma4-i01-cache-off-anchor-v1','stage_spec_sha256':c.PRIOR_STAGE_SHA256,
            'endpoints':{side:{'source_map':{'path':ref['source_path'],'sha256':ref['sha256']}} for side,ref in [('GPU',gpu),('NPU',npu)]}},'/synthetic/i01/comparison-spec.json')
        report=add('report.json',{'status':'i01_raw_bf16_and_scoped_comparisons_checked','task':'gemma4-i01-cache-off-anchor-v1',
            'stage_spec_sha256':c.PRIOR_STAGE_SHA256,'comparison_spec_sha256':spec['sha256'],'native_executions_started_by_admission':0,
            'thresholds':None,'acceptance':None,'full_core_complete':False,'scope':{'independent_inputs':1,'new_repeatability_measured':False,
                'full_targets_per_backend':159,'full_distribution_positions_per_backend':47},'synthetic_not_native':True},'/synthetic/i01/report.json')
        controller=add('controller.json',{'status':'completed','returncode':0,'native_executions_started':0,
            'report':{'path':report['source_path'],'sha256':report['sha256']},
            'comparison_spec':{'path':spec['source_path'],'sha256':spec['sha256']},
            'steps':[{'returncode':0,'timed_out':False,'argv':['/synthetic/python','-B',analysis['source_path'],'--spec',spec['source_path'],'--spec-sha256',spec['sha256']]}]},'/synthetic/i01/controller.json')
        self.document={'schema_version':1,'kind':'i03-i01-numeric-prerequisite','prior_stage_sha256':c.PRIOR_STAGE_SHA256,
            'report':report,'comparison_spec':spec,'controller':controller,'analysis_source':analysis,'source_maps':{'GPU':gpu,'NPU':npu}}
        self.path=self.root/'prerequisite.json';c.put(self.path,self.document)
    def close(self):self.stack.close()
    def rehash(self,name,document):
        ref=self.document[name];path=self.root/ref['path'];path.unlink();c.put(path,document);ref['sha256']=c.sha(path)
        self.path.unlink();c.put(self.path,self.document)


class Tensor:
    dtype='torch.bfloat16';device='cpu';_version=0
    def __init__(self,values):self.values=np.asarray(values)
    @property
    def shape(self):return self.values.shape
    def numel(self):return self.values.size
    def element_size(self):return self.values.dtype.itemsize
    def stride(self):return tuple(n//self.values.itemsize for n in self.values.strides)
    def storage_offset(self):return 0
    def untyped_storage(self):return SimpleNamespace(data_ptr=lambda:id(self.values),nbytes=lambda:self.values.nbytes)
    def detach(self):return self
    def cpu(self):return self
    def contiguous(self):return self
    def clone(self):return Tensor(self.values.copy())
    def __getitem__(self,index):return Tensor(self.values[index])
    def double(self):return Tensor(self.values.astype(np.float64))
    def numpy(self):return self.values


class Torch:
    long='long';uint8='uint8';inference_mode=staticmethod(nullcontext)
    tensor=staticmethod(lambda values,**kwargs:np.asarray(values))
    ones=staticmethod(lambda shape,**kwargs:np.ones(shape,dtype=np.int64))
    cat=staticmethod(lambda values,dim:Tensor(np.concatenate([value.values for value in values],axis=dim)))
    get_rng_state=staticmethod(lambda:Tensor(np.arange(8,dtype=np.uint8)))
    cuda=SimpleNamespace(get_rng_state=lambda ordinal:Tensor(np.arange(8,dtype=np.uint8)))


class Layer:
    is_initialized=True;is_sliding=False
    def __init__(self,index,prefix):
        dim=c.SLIDING_DIM if index==0 else c.FULL_DIM
        values=np.broadcast_to(np.arange(prefix,dtype=np.float32)[None,None,:,None]/4,(1,1,prefix,dim)).copy()
        self.keys=Tensor(values+index/2);self.values=Tensor(values+index/2+1/4)
    def get_seq_length(self):return self.keys.shape[-2]


class Cache:
    offloading=False
    def update(self,prefix):self.layers=[Layer(i,prefix) for i in range(c.NUM_LAYERS)];self.prefix=prefix
    def get_seq_length(self):return self.prefix


class Model:
    training=False
    def __init__(self,sequence,fault=None):
        self.sequence=sequence;self.calls=[];self.parameter=Tensor(np.zeros((2,3),dtype=np.float32));self.fault=fault;self.last_cache=None
        text=SimpleNamespace(layer_types=['sliding_attention','full_attention'],num_key_value_heads=1,num_global_key_value_heads=1,
            head_dim=2,global_head_dim=4,num_kv_shared_layers=0)
        self.config=SimpleNamespace(get_text_config=lambda:text,to_dict=lambda:{'synthetic_not_native':True,'attention':'eager',
            'text_config':{'layer_types':text.layer_types}})
    def named_parameters(self,remove_duplicate=False):return [('fixture.weight',self.parameter)]
    def named_buffers(self,remove_duplicate=False):return []
    def named_modules(self):return [('',self)]
    def __call__(self,**kwargs):
        positions=kwargs['position_ids'][0].tolist();start,end=positions[0],positions[-1]+1
        assert positions==list(range(start,end)) and kwargs['input_ids'].tolist()==[self.sequence[start:end]]
        assert kwargs['attention_mask'].shape==(1,end) and (kwargs['attention_mask']==1).all()
        assert kwargs['logits_to_keep']==0 and kwargs['return_dict'] is True and 'shared_kv_states' not in kwargs and 'labels' not in kwargs
        incoming=kwargs['past_key_values'];assert incoming is None or incoming.get_seq_length()==start
        self.calls.append((start,end,kwargs['use_cache'],incoming is None))
        if kwargs['use_cache']:
            cache=incoming or (self.last_cache if self.fault=='leak' and self.last_cache else Cache())
            cache.update(end-1 if self.fault=='missing_final' and start==159 else end);self.last_cache=cache
        else:cache=None
        values=((np.arange(start,end)[:,None]*7+np.arange(c.VOCABULARY)[None,:]*11)%47-23).astype(np.float32)/4
        logits=Tensor(values[None,:,:])
        if self.fault=='slice':logits=Tensor(values[None,:1,:])
        if self.fault=='mutate':self.parameter._version+=1
        if self.fault=='cache_dtype' and cache is not None:cache.layers[0].keys.dtype='torch.float32'
        return SimpleNamespace(logits=logits,past_key_values=cache,shared_kv_states=None)


def save_fake(tensors,path,mode,boundary):
    descriptors={};payload=[];offset=0
    for name,tensor in sorted(tensors.items()):
        raw=(tensor.values.astype('<f4').view('<u4')>>16).astype('<u2').tobytes()
        descriptors[name]={'dtype':'BF16','shape':list(tensor.shape),'data_offsets':[offset,offset+len(raw)]};payload.append(raw);offset+=len(raw)
    header=json.dumps({**descriptors,'__metadata__':{'task':c.TASK,'mode':mode,'boundary':boundary}},separators=(',',':')).encode();header+=b' '*(-len(header)%8)
    with path.open('xb') as stream:stream.write(struct.pack('<Q',len(header)));stream.write(header);stream.write(b''.join(payload))


class CaptureTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.stack=ExitStack();self.addCleanup(self.stack.close);self.addCleanup(self.temp.cleanup)
        self.doc={'sample':'synthetic-not-native','prompt':list(range(128)),'continuation':list(range(32))}
        self.input=self.root/'input.json';c.put(self.input,self.doc)
        self.stack.enter_context(patch.multiple(c,VOCABULARY=128,INPUT_SHA256=c.sha(self.input),NUM_LAYERS=2,SLIDING_LAYERS=1,FULL_LAYERS=1,
            SLIDING_HEADS=1,FULL_HEADS=1,SLIDING_DIM=2,FULL_DIM=4,KV_DATA_BYTES=3840))
        self.stack.enter_context(patch.object(c,'save_tensors',save_fake))
        proof_dir=self.root/'prior';proof_dir.mkdir();self.proof=ProofFixture(proof_dir);self.addCleanup(self.proof.close)
        self.inventory=c.coordinates(self.doc);self.expected=self.root/'expected.json';c.put(self.expected,c.expected_core(self.inventory))
        self.args=SimpleNamespace(output=self.root/'output',input=self.input,stage_spec=c.HERE.parent/'i03-stage-v1.json',expected_inventory=self.expected,
            expected_inventory_sha256=c.sha(self.expected),i01_prerequisite=self.proof.path,i01_prerequisite_sha256=c.sha(self.proof.path))
        c.initialize_output(self.args,self.proof.document)
    def seed(self):random.seed(0);np.random.seed(0);return {'seed':0}
    def finish(self):
        for name in ('snapshot-verification','loaded-model-inventory','policy-before-load','policy-after-load','policy-after-capture'):
            c.put(self.args.output/(name+'.json'),{'synthetic_not_native':True})
        source=self.root/'synthetic-source.py';source.write_text('# CPU fixture only\n')
        ref=c.file_ref(source)
        return c.finalize(self.args,'gpu',self.inventory,{}, {'math_policy':{'fixed':True},'implementation_sources':{'modeling':ref,'cache_utils':ref}})
    def test_five_modes_70_calls_32decode_lossless_and_all_artifacts(self):
        model=Model(self.inventory['sequence'])
        summaries=c.capture_all(model,Torch,'cpu',self.inventory,self.args.output,'gpu',self.seed,lambda:{'fixed':True},lambda:None)
        self.assertEqual([s['native_forward_calls'] for s in summaries],[1,1,1,33,34]);self.assertEqual(len(model.calls),70)
        self.assertEqual(model.calls[:3],[(0,160,False,True)]*3)
        self.assertEqual(model.calls[3],(0,128,True,True));self.assertEqual(model.calls[35],(159,160,True,False))
        self.assertEqual(model.calls[36:38],[(0,63,True,True),(63,128,True,False)]);self.assertEqual(model.calls[-1],(159,160,True,False))
        payloads=[]
        for mode in c.MODES:
            directory=self.args.output/'modes'/mode;raw=(directory/'raw-native-logits.safetensors').read_bytes();offset=8+int.from_bytes(raw[:8],'little');payloads.append(raw[offset:])
            rows=c.read(directory/'target-scores.json')['scores'];self.assertEqual([r['position'] for r in rows],list(range(1,160)))
            self.assertEqual(rows[-1]['prediction_position'],158)
            if not mode.startswith('full-'):
                cache=c.read(directory/'final-cache.json');self.assertEqual(len(cache['tensors']),4);self.assertEqual(cache['data_bytes'],3840)
                self.assertEqual(cache['cache']['sequence_length'],160)
        self.assertTrue(all(raw==payloads[0] for raw in payloads))
        result=self.finish();self.assertEqual(result['native_forward_calls_total'],70);self.assertEqual(result['status'],'i03_output_artifacts_checked')
        self.assertNotIn('torch',sys.modules)
    def test_persistent_model_mutation_stops_before_second_mode(self):
        model=Model(self.inventory['sequence'],'mutate')
        with self.assertRaisesRegex(ValueError,'persistent model state changed during mode'):
            c.capture_all(model,Torch,'cpu',self.inventory,self.args.output,'gpu',self.seed,lambda:{'fixed':True},lambda:None)
        self.assertEqual(len(model.calls),1);self.assertFalse((self.args.output/'status.json').exists())
    def test_leaked_previous_mode_cache_is_rejected(self):
        (self.args.output/'modes').mkdir()
        model=Model(self.inventory['sequence'],'leak');directory=self.args.output/'modes/token'
        _,reference=c.capture_mode(model,Torch,'cpu',self.inventory,directory,'token')
        with self.assertRaisesRegex(ValueError,'previous mode cache leaked'):
            c.capture_mode(model,Torch,'cpu',self.inventory,self.args.output/'modes/chunk','chunk63-65',[reference])
    def test_sliced_logits_and_wrong_native_cache_dtype_fail(self):
        (self.args.output/'modes').mkdir()
        for fault in ('slice','cache_dtype','missing_final'):
            with self.subTest(fault=fault):
                with self.assertRaises(ValueError):c.capture_mode(Model(self.inventory['sequence'],fault),Torch,'cpu',self.inventory,self.args.output/'modes'/fault,'token')
    def test_tampered_artifact_fails_even_with_completed_status(self):
        c.capture_all(Model(self.inventory['sequence']),Torch,'cpu',self.inventory,self.args.output,'gpu',self.seed,lambda:{'fixed':True},lambda:None);self.finish()
        path=self.args.output/'modes/token/dist-p158.npy';raw=path.read_bytes();path.write_bytes(raw[:-1]+bytes([raw[-1]^1]))
        with self.assertRaisesRegex(ValueError,'byte identity differs'):c.validate_output(self.args.output,self.input)


class PrerequisiteTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.fixture=ProofFixture(Path(self.temp.name));self.addCleanup(self.fixture.close)
    def test_complete_proof_and_direct_analysis_chain(self):
        result=proof.prerequisite(self.fixture.path,c.sha(self.fixture.path))
        self.assertEqual(len(result['refs']),6);self.assertEqual(result['native_executions_started'],0)
    def test_failed_controller_is_not_native_enablement(self):
        ref=self.fixture.document['controller'];controller=c.read(self.fixture.root/ref['path']);controller['returncode']=1
        self.fixture.rehash('controller',controller)
        with self.assertRaisesRegex(ValueError,'completed controller'):proof.prerequisite(self.fixture.path,c.sha(self.fixture.path))
    def test_bad_report_scope_even_after_hash_chain_updated_rejected(self):
        report=c.read(self.fixture.root/self.fixture.document['report']['path']);report['scope']['full_targets_per_backend']=32
        self.fixture.rehash('report',report)
        controller=c.read(self.fixture.root/self.fixture.document['controller']['path']);controller['report']['sha256']=self.fixture.document['report']['sha256']
        self.fixture.rehash('controller',controller)
        with self.assertRaisesRegex(ValueError,'raw-BF16 numeric admission'):proof.prerequisite(self.fixture.path,c.sha(self.fixture.path))
    def test_proof_path_escape_and_nondirect_script_rejected(self):
        self.fixture.document['report']['path']='../report.json';self.fixture.path.unlink();c.put(self.fixture.path,self.fixture.document)
        with self.assertRaisesRegex(ValueError,'unsafe relative path'):proof.prerequisite(self.fixture.path,c.sha(self.fixture.path))
    def test_analysis_path_as_argument_does_not_prove_direct_execution(self):
        controller=c.read(self.fixture.root/self.fixture.document['controller']['path'])
        argv=controller['steps'][0]['argv'];argv.insert(2,'/synthetic/unreviewed.py')
        self.fixture.rehash('controller',controller)
        with self.assertRaisesRegex(ValueError,'executed independent analysis argv'):proof.prerequisite(self.fixture.path,c.sha(self.fixture.path))
    def test_source_file_has_only_standard_library_imports(self):
        import ast
        tree=ast.parse(Path(proof.__file__).read_text())
        names={node.module.split('.')[0] for node in ast.walk(tree) if isinstance(node,ast.ImportFrom)}
        names|={name.name.split('.')[0] for node in ast.walk(tree) if isinstance(node,ast.Import) for name in node.names}
        self.assertTrue(names<={'hashlib','json','pathlib','re'});self.assertNotIn('torch',sys.modules)
    def test_numpy_rng_digest_covers_interior_words_hidden_by_repr(self):
        original=np.random.RandomState(0).get_state()
        words=original[1].copy();words[len(words)//2]^=np.uint32(1)
        changed=(original[0],words,*original[2:])
        with np.printoptions(threshold=6,edgeitems=2):
            self.assertEqual(repr(original),repr(changed))
        a,b=c.numpy_rng_observation(original),c.numpy_rng_observation(changed)
        self.assertNotEqual(a['sha256'],b['sha256']);self.assertEqual(a['header']['word_count'],624)
        cached=(original[0],original[1],original[2],original[3],-0.0)
        self.assertNotEqual(a['sha256'],c.numpy_rng_observation(cached)['sha256'])


if __name__=='__main__':unittest.main()

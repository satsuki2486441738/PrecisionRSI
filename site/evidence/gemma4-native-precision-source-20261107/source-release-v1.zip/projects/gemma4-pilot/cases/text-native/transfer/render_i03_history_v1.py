"""Render one private I03 history candidate from a real seven-file archive.

Never writes site/, repair history or Git. The caller supplies the actual archive
commit after publishing all seven evidence files. Prior107 records remain exact.
"""
import argparse
from collections import Counter
import copy
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

CASE='projects/gemma4-pilot/cases/text-native'
ID='gemma4-h100-ascend-partitions-20261107'
PREFIX='site/evidence/'+ID+'/'
HISTORY_SHA='8e1c33dcec51f9ca503234eead01fa3d736346f24e7093326d7dbd542032210a'
REPAIRS_SHA='0c186a832c07aa42bb9c74b0e98fd2ad036de52eb5ea694f28ec8353daf2d1fc'
REPAIRS_ARCHIVE_SHA='0edb5cce61a39322eea02f521d8bb4632ab6780fd31a2c8dabd9b15c5cf1bca2'
REPORT_SHA='c1cefa946eef3530384f2c43c538c2d59a6433e16f993dc157850e915f21ac87'
CONTROLLER_SHA='03552c47162cb92195785b4ae63b9567ef331e6187f84754e3b8bbb4e409d24c'
VERIFIER_SHA='863019a1bd9875d418630c4c5e547576232e225fd66a98d63d51f3023701a44e'
SELECTION_SHA='64be91b643771a26dceb13dec8d69f5c1d0ffc8eb901821cc645d9a26b1a95e9'
FILES=('report.md','coverage.json','selected-targets.json','selected-metrics.json','replay-targets.py','execution-cost.json','independent-checks.json')
FIXED={'selected-targets.json':'2d7e6c2e872c69dc49216211bb7e72eb356b79a63744437aa4278b5fe8707289',
       'selected-metrics.json':'bc4f3cb65d071c6aede6c7e9bcfa8489303e99091397a0793886d239497ff077',
       'replay-targets.py':'4f315e96c263869d6fb5256e0a2ccbe8e422879ab842539ed525eae847350f4d',
       'execution-cost.json':'cab0f8caef11bf03f59c3c407392bcc9300f008fa23e220999a9c19e1f5e2dd7',
       'coverage.json':'18fc77f052edc307587ca57c3a183d0c52b36c9c83e56349b64d5c0352f32905',
       'independent-checks.json':'2a5c96f228594ba07ad281da153384a053ae0c71c3b37f61936e9daf10f98994'}
HEX=re.compile(r'^[a-f0-9]{64}$')
MODES=['full-r1','full-r2','full-r3','token','chunk63-65']
SIDES=[b+'-'+m for b in ('gpu','npu') for m in MODES]
SCORE_PAIRS=[['gpu-full-r%d'%i,'npu-full-r%d'%j] for i in (1,2,3) for j in (1,2,3)]+[['gpu-token','npu-token'],['gpu-chunk63-65','npu-chunk63-65']]
for _backend in ('gpu','npu'):
    SCORE_PAIRS.extend([[_backend+'-full-r%d'%i,_backend+'-full-r%d'%j] for i,j in ((1,2),(1,3),(2,3))])
    SCORE_PAIRS.extend([[_backend+'-full-r1',_backend+'-token'],[_backend+'-full-r1',_backend+'-chunk63-65'],[_backend+'-token',_backend+'-chunk63-65']])
KV_PAIRS=[['gpu-token','npu-token'],['gpu-chunk63-65','npu-chunk63-65'],['gpu-token','gpu-chunk63-65'],['npu-token','npu-chunk63-65']]


def require(ok,message):
    if not ok:raise ValueError(message)


def digest(raw):return hashlib.sha256(raw).hexdigest()


def read(raw):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    doc=json.loads(raw,object_pairs_hook=pairs,parse_constant=reject)
    json.dumps(doc,allow_nan=False);return doc


def put(path,doc):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(doc,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')


def git(repo,*args):
    result=subprocess.run(['git',*args],cwd=repo,check=True,capture_output=True,timeout=30)
    require(len(result.stdout)<=16*1024**2,'bounded archive blob required');return result.stdout


def archive_files(repo,revision,history_raw,repairs_raw):
    require(re.fullmatch(r'[a-f0-9]{40}',revision),'actual full40hex archive commit required')
    require(git(repo,'rev-parse','--verify',revision+'^{commit}').decode().strip()==revision,'actual commit object required')
    listed=git(repo,'ls-tree','-r','--name-only',revision,'--',PREFIX).decode().splitlines()
    require(set(listed)=={PREFIX+name for name in FILES} and len(listed)==7,'archive must contain exactly seven evidence files')
    require(git(repo,'show',revision+':site/data/evaluations.json')==history_raw,'archive must precede this108th history append')
    archived_repairs=git(repo,'show',revision+':site/data/repairs.json')
    # Git normalizes the one existing working CRLF; neither byte stream changes.
    require(digest(archived_repairs)==REPAIRS_ARCHIVE_SHA and archived_repairs==repairs_raw.replace(b'\r\n',b'\n'),
        'known20repair archive/working newline provenance changed')
    documents={};pins={}
    for name in FILES:
        raw=git(repo,'show',revision+':'+PREFIX+name);path=repo/PREFIX/name
        require(path.is_file() and not path.is_symlink() and path.read_bytes()==raw,'published working bytes differ from archived blob: '+name)
        pins[name]=digest(raw);require(name not in FIXED or pins[name]==FIXED[name],'reviewed evidence pin changed: '+name)
        documents[name]=read(raw) if name.endswith('.json') else raw.decode('utf-8')
    return documents,pins


def validate_evidence(documents,previous_coverage):
    m,t,cost,coverage,e02=(documents[k] for k in ('selected-metrics.json','selected-targets.json','execution-cost.json','coverage.json','independent-checks.json'))
    for doc in (m,t):
        require(doc['thresholds'] is None and doc['acceptance'] is None and doc['full_core_complete'] is False,'model acceptance/full-core claim changed')
        w=doc['workload'];require(w['independent_inputs']==1 and w['new_model_processes_per_backend']==1 and w['native_calls_per_backend']==70 and
            w['targets_per_mode']==159 and w['distribution_rows_per_mode']==47 and w['full_vocabulary_rows_rederived']==470 and
            w['fresh_process_repeatability_measured'] is False and w['cached_mode_repeatability_measured'] is False and w['cache_eviction_tested'] is False,
            'one-input five-mode coverage changed')
        require([run['id'] for run in doc['runs']]==SIDES and [pair['sides'] for pair in doc['target_pairs']]==SCORE_PAIRS,
            'ten sides/23 cross-first target pair inventory changed')
        require(doc['array_evidence']['independent_e02_scalar_math_recheck_completed'] is True and
            doc['array_evidence']['independent_e02_summary_ref']=={'file':'independent-checks.json','sha256':FIXED['independent-checks.json']},
            'final public evidence must bind completed actual E02 summary')
    require(m['target_pairs']==t['target_pairs'] and [p['sides'] for p in m['distribution_pairs']]==SCORE_PAIRS and
        [p['sides'] for p in m['native_final_KV_pairs']]==KV_PAIRS,'target/distribution/KV pair identities changed')
    require(m['source_pins']['comparison_report_sha256']==REPORT_SHA and m['source_pins']['controller_sha256']==CONTROLLER_SHA,
        'actual I03 numeric report/controller pins differ')
    for pair in m['target_pairs']:require(pair['coverage']=={'expected':159,'paired':159} and pair['thresholds'] is None and pair['acceptance'] is None,'paired target coverage changed')
    for pair in m['distribution_pairs']:require(pair['position_count']==len(pair['positions'])==47,'47 selected distributions required')
    for pair in m['native_final_KV_pairs']:require(pair['tensor_count']==len(pair['per_tensor'])==96 and pair['global']['count']==27525120,'complete96tensor native KV coverage changed')
    require(coverage['task_count']==49 and coverage['core_task_count']==28 and coverage['full_core_complete'] is False and
        coverage['original_49_task_scope_complete'] is False and coverage['thresholds'] is None and coverage['acceptance'] is None,'49task/28core incomplete ledger required')
    inventory={row['task_id']:row['profile'] for row in coverage['tasks']}
    require(len(coverage['tasks'])==len(inventory)==49 and sum(v=='core' for v in inventory.values())==28 and
        inventory=={row['task_id']:row['profile'] for row in previous_coverage['tasks']} and
        coverage['source_plan_sha256']==previous_coverage['source_plan_sha256'] and
        Counter(row['status'] for row in coverage['tasks'])==coverage['counts'] and
        all(row['full_plan_task_complete'] is False for row in coverage['tasks']),'original49 task inventory/status counts changed')
    statuses={row['task_id']:row['status'] for row in coverage['tasks']}
    require(coverage['counts']=={'partial':6,'complete':8,'pending':12,'deferred':21,'not_applicable':2} and
        all(statuses[name]=='complete' for name in ('D02','I02','I03','E01','E02')),'new scoped I03/E02 milestone ledger required')
    require(cost['kind']=='selected_I03_execution_accounting' and cost['acceptance'] is None and cost['P01_complete'] is False and
        cost['total_evaluation_cost_complete'] is False and cost['headline_speed_comparison_supported'] is False and
        cost['total_allocated_device_seconds'] is None and cost['total_currency_cost'] is None,'speed/billing completion claim changed')
    for backend,seconds in (('GPU',287.38445000350475),('NPU',94.66554082464427)):
        v=cost['model_children'][backend];require(v['recorded_wall_seconds']==seconds and v['status']=='completed' and type(v['returncode']) is int and
            v['returncode']==0 and v['native_forward_calls']==70 and v['native_model_processes']==v['loaded_models']==1 and
            all(v[k] is None for k in ('uninstrumented_latency_seconds','active_device_seconds','allocated_instance_seconds','currency_cost')),
            'actual instrumented model-child scope changed')
    require(cost['cpu_numerical_admission']['controller_sha256']==CONTROLLER_SHA and cost['cpu_numerical_admission']['recorded_wall_seconds']==299.86336386110634,
        'actual CPU numerical admission timing changed')
    require(e02['schema_version']==1 and e02['kind']=='selected_I03_independent_E02_summary' and e02['status']=='independent_i03_selected_e02_checks_matched' and
        HEX.fullmatch(e02['source_controller_sha256']) and HEX.fullmatch(e02['source_report_sha256']) and e02['original_I03_report_sha256']==REPORT_SHA and
        e02['verifier_sha256']==VERIFIER_SHA and e02['source_selection_sha256']==SELECTION_SHA and e02['all_native_array_hashes_checked']==484 and
        e02['native_executions_started']==0 and e02['thresholds'] is None and e02['acceptance'] is None and e02['full_core_complete'] is False,
        'actual independent selected E02 summary required')
    s=e02['scope'];require(s=={'target_pairs':23,'targets_per_pair':159,'independent_distribution_pair_rows':49,'all_distribution_pair_rows_in_original_report':1081,
        'global_KV_coordinates':4,'full_representative_KV_tensors':8,'admitted_large_sources_final_bytehash_checked':484,
        'full_KV_global_reductions_repeated':False,'independent_inputs':1},'selected E0249row/8tensor subset differs')
    require(len(e02['target_pair_checks'])==23 and len(e02['distribution_checks'])==49 and len(e02['native_KV_checks'])==4 and
        e02['verification']['model_acceptance_thresholds'] is False and e02['verification']['CPU_seconds']==600 and
        e02['verification']['full_pool_bytehash_passes']==1,'selected E02 arithmetic/bytehash scope differs')
    require(REPORT_SHA in documents['report.md'],'public report lacks actual numerical report pin')


def score_comparison(target,distribution,prototypes):
    a,b=target['sides'];t,d=target['metrics'],distribution['aggregate']
    values={'target-nll-abs-diff':t['nll_abs_diff_nat_per_token'],'target-mae':t['mae_nat'],'target-p99':t['p99_nat'],'target-max':t['max_abs_nat'],
        'top1-agreements':d['top1_agreement']['count'],'top1-agreement-fraction':d['top1_agreement']['fraction'],'top100-overlap-mean':d['top100_overlap']['mean']}
    for field,prefix in (('tail_merged_js','tail-merged-js'),('probability_rmse','union-probability-rmse'),('max_probability_error','union-max-probability-error')):
        for stat in ('mean','p99','max'):values[prefix+'-'+stat]=d[field][stat]
    for field in ('side_a_top100','side_b_top100','side_a_union','side_b_union'):
        for stat in ('mean','p1','min'):values[field.replace('_','-')+'-'+stat]=d['coverage'][field][stat]
    rendered=[]
    for prototype in prototypes:
        item=copy.deepcopy(prototype);key=item['id'];item['value']=values[key];item.pop('coordinate',None);item.pop('side_values',None)
        item['label']=item['label'].replace('gpu-full','{SIDE_A}').replace('npu-full','{SIDE_B}').replace('{SIDE_A}',a).replace('{SIDE_B}',b)
        if key=='target-nll-abs-diff':item['side_values']={a:t['side_a_nll_nat_per_token'],b:t['side_b_nll_nat_per_token']}
        if key=='target-max':item['coordinate']={'anonymous_target_index_zero_based':t['max_target_index_zero_based']}
        for field,prefix in (('tail_merged_js','tail-merged-js'),('probability_rmse','union-probability-rmse'),('max_probability_error','union-max-probability-error')):
            if key==prefix+'-max':item['coordinate']=copy.deepcopy(d[field]['max_coordinate'])
        rendered.append(item)
    require(len(rendered)==len(values)==28,'all28 target/distribution aggregate metrics required')
    return {'id':target['id'],'title':('GPU/NPU matched modes: ' if target['kind'].startswith('cross_backend') else 'Within-process control: ')+a+' vs '+b,
        'side_ids':[a,b],'kind':target['kind'],'scope':'One fixed input;159 targets and47 selected distributions. Same-process repeats are not independent input examples.',
        'metrics':rendered,'coverage':[{'label':label,'observed':count,'expected':count,'unit':unit} for label,count,unit in
        (('Paired targets',159,'targets'),('Paired selected distributions',47,'positions'),('Vocabulary per retained row',262144,'entries/row'),('Independent fixed inputs',1,'inputs'))]}


def build_entry(documents,pins,revision,previous):
    m,t=documents['selected-metrics.json'],documents['selected-targets.json'];sides=[]
    libraries=(('torch','PyTorch'),('transformers','Transformers'),('numpy','NumPy'),('cuda_runtime','CUDA runtime'),('torch_npu','TorchNPU'),('cann','CANN'),('driver','Driver package metadata'))
    for run in t['runs']:
        c=run['conditions'];mode=run['mode'];calls=c['execution_mode']['forward_calls']
        sides.append({'id':run['id'],'label':('H100' if run['backend']=='GPU' else 'Ascend')+' / '+mode,'hardware':c['hardware']['model'],
            'libraries':[{'name':label,'version':c['software'][field]} for field,label in libraries if field in c['software']],
            'settings':{'dtype':'BF16','native_logits_dtype':'BF16','offline_logprob_dtype':'FP64','attention':'eager','mode':'eval/inference','seed':0,
                'device_count':1,'instance_visible_devices':1 if run['backend']=='GPU' else 8,'parallelism':'TP1',**copy.deepcopy(c['backend_policy']),
                'execution_mode':mode,'use_cache':c['execution_mode']['use_cache'],'native_forward_calls':calls,'supplied_input_tokens':160,
                'prefill_partitions':[160] if calls==1 else ([128] if mode=='token' else [63,65]),'cached_decode_calls':0 if calls==1 else 32,
                'process_model_loads':1,'same_process_full_repeat_calls':3,'cached_mode_captures':0 if calls==1 else 1,
                'fresh_process_repeatability_measured':False,'cached_mode_repeatability_measured':False,'cache_eviction_tested':False}})
    comparisons=[score_comparison(a,b,previous['comparisons'][0]['metrics']) for a,b in zip(m['target_pairs'],m['distribution_pairs'])]
    for pair in m['native_final_KV_pairs']:
        rendered=[]
        for field,label in (('rmse','Native KV global RMSE'),('max_abs','Native KV global maximum absolute error'),('cosine','Native KV global cosine'),
                            ('error_norm','Native KV global error norm'),('side_a_norm','Native KV side A global norm'),('side_b_norm','Native KV side B global norm')):
            metric={'id':'kv-'+field.replace('_','-'),'label':label,'value':pair['global'][field]['value'],'unit':'cosine' if field=='cosine' else 'native value'}
            if field=='max_abs':metric['coordinate']=copy.deepcopy(pair['global']['max_coordinate'])
            rendered.append(metric)
        comparisons.append({'id':pair['id']+'-native-kv','title':'Native final KV: '+' vs '.join(pair['sides']),'side_ids':pair['sides'],'kind':'native_final_KV',
            'scope':'All96 native K/V tensors after160 supplied inputs; FP64 concatenated-coordinate reductions. Incoming operands may differ.',
            'metrics':rendered,'coverage':[{'label':label,'observed':count,'expected':count,'unit':unit} for label,count,unit in
                (('Native KV tensors',96,'tensors'),('Paired native KV elements',27525120,'elements'),('Supplied input positions',160,'positions'),('Independent fixed inputs',1,'inputs'))]})
    require(len(sides)==10 and len(comparisons)==27,'ten sides/23scores+4KV comparisons required')
    e02=documents['independent-checks.json'];coverage=documents['coverage.json']
    return {'id':ID,'date':'2026-11-07','title':'Gemma 4 12B: H100 vs Ascend partitions and same-process repeats','task':'inference','status':'partial',
        'acceptance':None,'thresholds':None,'full_core_complete':False,'model':copy.deepcopy(previous['model']),
        'summary':'One input, one loaded model per backend: three cache-off full forwards plus token and63/65-chunk cached paths;159 targets and47 distributions per mode.23 score/distribution and four complete native KV comparisons; full-plan completion and numerical acceptance remain open.',
        'common':['Same pinned base checkpoint and160 fixed inputs:128 prompt inputs including BOS plus32 predetermined continuation inputs; BF16 parameters/native logits, eager attention, seed0, batch1 andTP1.',
            'Each backend performs five modes and70 forwards in one loaded process. Seeded full generator states and model/config/parameter-version/buffer observations are checked before and after modes.',
            'All1600 raw prediction rows were finite-checked;1590 target scores and470 full-vocabulary distributions were reconstructed offline. Final predictor159 is retained without inventing an unknown target.'],
        'differences':['GPU uses Torch2.9.0+cu128/CUDA12.8; NPU uses Torch2.9.0+cpu with TorchNPU2.9.0.post2/CANN9.1.0. Actual backend math policies are listed per side.',
            'Full calls disable cache; token mode uses prefill128+32single-input decodes; chunk mode uses prefill63/65+32decodes. Cache use, shapes and execution history change.',
            'Within-backend modes share the loaded model and reset seeded RNG anchors. Allocator/kernel warmup is not reset; parameters are not byte-rehashed. No operator-defect or identical-operand arithmetic claim.'],
        'sides':sides,'comparisons':comparisons,'scope':copy.deepcopy(m['workload'])|{'target_only_replay_pairs':23,'public_replay_arrays_read':0,
            'selected_E02_distribution_pair_rows':49,'selected_E02_full_representative_KV_tensors':8,'selected_E02_global_KV_coordinates':4},
        'plan_coverage':{k:copy.deepcopy(coverage[k]) for k in ('task_count','core_task_count','counts','full_core_complete','original_49_task_scope_complete')},
        'instrumented_execution_accounting':copy.deepcopy(documents['execution-cost.json']),
        'independent_checks':{k:copy.deepcopy(e02[k]) for k in ('status','source_controller_sha256','source_report_sha256','original_I03_report_sha256','verifier_sha256','source_selection_sha256','scope','verification','all_native_array_hashes_checked')},
        'notes':['The primary comparisons are GPU versus NPU.23 pairs and repeated full forwards all share one fixed input; they do not add independent examples.',
            'All six same-process full-repeat pairs have zero target and reported sampled-distribution errors. Fresh-process repeatability and repeated cached modes remain unmeasured.',
            'Probability errors use the union of both top100 sets; JS adds one exact full-vocabulary complement category. These are not full-vocabulary probability errors/divergence.',
            'Four complete native KV comparisons cover96 tensors and27525120 elements each. Context160 does not exercise configured1024 sliding-window eviction; native cache classes are observed, not forced.',
            'Public stdlib replay recomputes23 target reductions and reads no arrays. Archived distribution and KV scalars are integrity checked only. The separate E02 replay checks49 selected pair/rows, eight full tensors and four reported global KV maxima, not all1081 rows or all global reductions.',
            'Instrumented child wall durations are scoped accounting, not a speed, active-device-time, full instance-lifetime or billed-cost comparison. Do not sum nested intervals or subtract timestamps across hosts.',
            'Thresholds and acceptance are null. Raw reconstruction/arithmetic tolerances verify evidence and do not define model accuracy acceptance. The49-task/28core ledger remains incomplete.'],
        'evidence':[{'label':label,'url':'evidence/'+ID+'/'+name} for name,label in zip(FILES,('Scoped partition/repeat report','Original49task coverage ledger','Ten anonymous target vectors','All23 sampled-distribution and four96tensor KV summaries','23pair standard-library target replay','Selected instrumented execution accounting','Selected independent scalar E02 checks'))],
        'archive':{'revision':revision,'prefix':PREFIX,'replay_cases':23,'file_sha256':pins}}


def append_history(history_raw,entry):
    previous=read(history_raw);require(len(previous['evaluations'])==107 and all(v['id']!=ID for v in previous['evaluations']),'exact107 prior records required')
    require((json.dumps(previous,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()==history_raw,'current Unicode/indent2 history format differs')
    marker=b'\n  ]\n}\n';require(history_raw.endswith(marker),'history array trailer differs');prefix=history_raw[:-len(marker)]
    stamp=previous['updated_at'];old=('"updated_at": "'+stamp+'"').encode();new=b'"updated_at": "2026-11-07"'
    require(prefix.count(old)==1,'unique top-level history date required');updated=prefix.replace(old,new,1)
    tail='\n'.join('    '+line for line in json.dumps(entry,ensure_ascii=False,indent=2,allow_nan=False).splitlines()).encode()
    raw=updated+b',\n'+tail+marker;current=read(raw)
    require(current['evaluations'][:-1]==previous['evaluations'] and len(current['evaluations'])==108,'prior107 object preservation failed')
    require(raw.startswith(updated+b',\n') and (json.dumps(current,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()==raw,'prior evaluation prefix/current format changed')
    return raw,digest(prefix[prefix.index(b'  "evaluations": ['):])


def render(repo,revision,output_root):
    repo=Path(repo).resolve(strict=True);output_root=Path(output_root)
    require(not output_root.is_symlink() and output_root.resolve(strict=True).is_relative_to(repo/CASE/'transfer'),'private transfer output root required')
    history=repo/'site/data/evaluations.json';repairs=repo/'site/data/repairs.json';history_raw=history.read_bytes();repairs_raw=repairs.read_bytes()
    require(digest(history_raw)==HISTORY_SHA and digest(repairs_raw)==REPAIRS_SHA and len(read(repairs_raw)['repairs'])==20,'published107/20 history pins changed')
    document=read(history_raw);require(len(document['evaluations'])==107 and document['evaluations'][-1]['id']=='gemma4-h100-ascend-cacheoff-20261106','known107th stage missing')
    old=document['evaluations'][-1];prior=repo/'site/evidence'/old['id']/'coverage.json'
    require(digest(prior.read_bytes())==old['archive']['file_sha256']['coverage.json'],'prior49task inventory bytes changed')
    documents,pins=archive_files(repo,revision,history_raw,repairs_raw);validate_evidence(documents,read(prior.read_bytes()))
    entry=build_entry(documents,pins,revision,old);raw=json.dumps(entry,ensure_ascii=False,allow_nan=False)
    require(not re.search(r'/(?:home|data|tmp|mnt)/|[A-Z]:\\|app-[a-z0-9]{8}|[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}',raw,re.I),'private identity/path in history candidate')
    candidate,prefix_sha=append_history(history_raw,entry)
    folder=output_root/('compare-i03-history-render-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));folder.mkdir(mode=0o700)
    put(folder/'candidate-entry.json',entry)
    with (folder/'new-history.json').open('xb') as stream:stream.write(candidate)
    require(history.read_bytes()==history_raw and repairs.read_bytes()==repairs_raw,'published histories changed during rendering')
    for name,pin in pins.items():require(digest((repo/PREFIX/name).read_bytes())==pin,'published evidence changed during rendering')
    receipt={'schema_version':1,'status':'private_history_candidate_rendered','archive_revision':revision,'entry_id':ID,'prior_evaluations':107,'candidate_evaluations':108,
        'repair_records_unchanged':20,'prior_history_sha256':HISTORY_SHA,'repairs_sha256':REPAIRS_SHA,'preserved_prior_evaluation_prefix_sha256':prefix_sha,
        'comparisons':27,'target_distribution_comparisons':23,'native_final_KV_comparisons':4,'primary_pair':entry['comparisons'][0]['side_ids'],
        'candidate_entry_path':str(folder/'candidate-entry.json'),'candidate_entry_sha256':digest((folder/'candidate-entry.json').read_bytes()),
        'new_history_path':str(folder/'new-history.json'),'new_history_sha256':digest(candidate),'public_history_written':False,'git_modified':False,'acceptance':None,'full_core_complete':False}
    put(folder/'render-receipt.json',receipt);return receipt


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--archive-commit',required=True)
    parser.add_argument('--repo',type=Path,default=Path(__file__).resolve().parents[5]);parser.add_argument('--output-root',type=Path)
    args=parser.parse_args();print(json.dumps(render(args.repo,args.archive_commit,args.output_root or args.repo/CASE/'transfer'),indent=2))

"""Independently freeze I03 labels, samples and all70 native-call coordinates.

Pure stdlib. Reads only the unchanged stage specification and fixed token IDs;
it imports no collector/framework, loads no weights and observes no score/device.
"""
import argparse
import hashlib
import json
from pathlib import Path

INPUT_SHA256='643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
STAGE_SHA256='6e53e3cdf3e7fad8f56b43cb99a42bdb999ac074a5a40a3c1e7df72eeb504005'
STAGE_ID='gemma4-gpu-npu-i03-partition-repeat-v1-20261106'
TASK='gemma4-i03-partition-repeat-v1'
VOCABULARY=262144
MODES=['full-r1','full-r2','full-r3','token','chunk63-65']


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)


def load(path):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)


def derive(document,input_sha256,stage_sha256):
    require(input_sha256==INPUT_SHA256 and stage_sha256==STAGE_SHA256,'original fixed input and I03 stage SHA required')
    require(isinstance(document,dict) and isinstance(document.get('sample'),str) and document['sample'].strip(),'sample ID required')
    prompt=document.get('prompt');continuation=document.get('continuation')
    require(isinstance(prompt,list) and len(prompt)==128 and isinstance(continuation,list) and len(continuation)==32,'exact128+32 fixed tokens required')
    sequence=prompt+continuation
    require(all(type(token) is int and 0<=token<VOCABULARY for token in sequence),'integer in-vocabulary token IDs required')
    # Each schedule partitions ALL160 inputs once, including the unscored last predictor.
    schedules=[[(0,160)] for _ in range(3)]
    schedules.append([(0,128)]+[(index,index+1) for index in range(128,160)])
    schedules.append([(0,63),(63,128)]+[(index,index+1) for index in range(128,160)])
    modes=[]
    for mode_index,(identifier,spans) in enumerate(zip(MODES,schedules)):
        calls=[];covered=[]
        for call_index,(start,end) in enumerate(spans):
            covered.extend(range(start,end))
            calls.append({'call_index':call_index,'stage':'full' if mode_index<3 else 'decode' if start>=128 else 'prefill',
                'start':start,'end':end,'prefix_length':start,'attention_mask_length':end,
                'position_ids':list(range(start,end)),'input_ids':sequence[start:end]})
        require(covered==list(range(160)),'independent call schedule dropped/repeated an input')
        modes.append({'id':identifier,'use_cache':mode_index>=3,'native_forward_calls':len(calls),
            'cached_decode_calls':sum(call['stage']=='decode' for call in calls),'calls':calls})
    grid=[index*127//15 for index in range(16)];selected=sorted(set(grid)|set(range(127,159)))
    require(len(selected)==47 and [m['native_forward_calls'] for m in modes]==[1,1,1,33,34] and sum(len(m['calls']) for m in modes)==70,
        'independent mode/sample inventory count differs')
    return {'schema_version':1,'task':TASK,'stage_id':STAGE_ID,'stage_spec_sha256':stage_sha256,'input_sha256':input_sha256,
        'sequence_length':160,'vocabulary_size':VOCABULARY,
        'all_targets':[{'sample':document['sample'],'position':position,'token':sequence[position]} for position in range(1,160)],
        'distribution_positions':[{'sample':document['sample'],'position':position,'history':sequence[:position+1]} for position in selected],
        'modes':modes,'conditioning_length':128,'continuation_length':32,'native_calls_per_backend':70,
        'raw_logits_per_mode':{'tensor_name':'logits','dtype':'BF16','shape':[1,160,VOCABULARY],
            'data_bytes':160*VOCABULARY*2,'unscored_prediction_indices':[159]},
        'sampling':{'conditioning_predictors':grid,'continuation_predictors':list(range(127,159)),
            'intersection_predictors':[127],'deduplicated_predictors':selected},
        'cached_final_state':{'sequence_length':160,'layer_count':48,'tensor_count':96,
            'tensor_keys':['layer-%03d.%s'%(layer,kind) for layer in range(48) for kind in ('key','value')],
            'native_dtype':'BF16','configured_data_bytes_per_cached_mode':55050240,'cache_implementation_must_be_observed':True},
        'scope':{'independent_inputs':1,'new_model_processes_per_backend':1,'same_loaded_model':True,
            'full_repeats':'three calls in one process; not three fresh processes','cached_mode_repeatability_measured':False,
            'cache_eviction_tested':False},'thresholds':None,'acceptance':None}


def stage_check(stage_path,stage_sha,expected):
    require(stage_sha==STAGE_SHA256 and sha(stage_path)==stage_sha,'original prepared I03 stage source SHA differs')
    stage=load(stage_path)
    require(stage.get('stage_id')==STAGE_ID and stage.get('status')=='prepared_not_executed' and stage.get('thresholds') is None and
        stage.get('acceptance') is None and stage.get('full_core_complete') is False,'unchanged prepared I03 stage required')
    semantics=stage['semantics'];require(stage['modes']==MODES and stage['same_loaded_model'] is True and stage['new_model_processes_per_backend']==1 and
        stage['expected_native_calls']==[m['native_forward_calls'] for m in expected['modes']] and stage['total_forward_calls_per_backend']==70 and
        stage['cached_decode_calls_per_mode']==32 and stage['prompt_chunk_lengths']==[63,65] and
        semantics['per_mode_raw_logits_shape']==expected['raw_logits_per_mode']['shape'] and semantics['targets_per_mode']==159 and
        semantics['selected_distribution_positions']==expected['sampling']['deduplicated_predictors'] and semantics['distribution_positions_per_mode']==47 and
        semantics['unscored_prediction_row159_retained'] is True,'stage semantics differ from independent schedules/coordinates')
    require(stage['input']['sha256']==INPUT_SHA256 and stage['limits']['max_native_model_processes_per_backend']==1 and
        stage['limits']['automatic_native_retries']==0,'finite original input/process/retry boundary differs')
    return stage


def build(input_path,output,stage_spec,stage_spec_sha256):
    expected=derive(load(input_path),sha(input_path),stage_spec_sha256);stage_check(stage_spec,stage_spec_sha256,expected)
    output=Path(output);require(output.parent.is_dir() and not output.exists(),'exclusive new expected inventory path required')
    with output.open('x',encoding='utf-8',newline='\n') as stream:json.dump(expected,stream,indent=2,allow_nan=False);stream.write('\n')
    return {'status':'i03_expected_inventory_frozen','path':str(output.resolve()),'sha256':sha(output),'size_bytes':output.stat().st_size,
        'native_calls_per_backend':70,'targets_per_mode':159,'distribution_positions_per_mode':47,'native_executions_started':0,'acceptance':None}


def verify(expected_path,input_path,stage_spec):
    expected=derive(load(input_path),sha(input_path),STAGE_SHA256);stage_check(stage_spec,STAGE_SHA256,expected)
    require(canonical(load(expected_path))==canonical(expected),'independently derived I03 expected bytes/semantics differ')
    return expected


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('input','output','stage-spec'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--stage-spec-sha256',required=True);args=parser.parse_args()
    print(json.dumps(build(args.input,args.output,args.stage_spec,args.stage_spec_sha256),indent=2),flush=True)


if __name__=='__main__':main()

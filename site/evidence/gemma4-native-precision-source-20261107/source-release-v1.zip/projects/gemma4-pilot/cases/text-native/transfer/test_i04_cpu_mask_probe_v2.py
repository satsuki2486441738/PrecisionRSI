"""Import-versus-initialization regression, without importing frameworks."""
import ast
import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i04_cpu_probe_v2_fixture',HERE/'i04_cpu_mask_probe_v2.py')
probe = importlib.util.module_from_spec(spec); spec.loader.exec_module(probe)


class InitializationBoundary(unittest.TestCase):
    def torch(self,npu=False,cuda=False,registered=True):
        def forbidden(*_): raise AssertionError('availability/device query is not a state observation')
        namespace = SimpleNamespace(is_initialized=lambda:npu,is_available=forbidden,device_count=forbidden,set_device=forbidden)
        result = SimpleNamespace(cuda=SimpleNamespace(is_initialized=lambda:cuda))
        if registered: result.npu = namespace
        return result

    def test_imported_backend_uninitialized_is_accepted_without_availability_query(self):
        with patch.dict(sys.modules,{'torch_npu':SimpleNamespace()}):
            observed = probe.initialization_observation(self.torch(),'after_configuration')
        self.assertIs(observed['torch_npu_imported'],True)
        self.assertIs(observed['npu_namespace_registered'],True)
        self.assertIs(observed['npu_initialized'],False)
        self.assertIs(observed['cuda_initialized'],False)

    def test_initialized_npu_or_cuda_fails_instead_of_being_hidden_by_import_state(self):
        for npu,cuda in ((True,False),(False,True)):
            with self.subTest(npu=npu,cuda=cuda),self.assertRaises(AssertionError):
                probe.initialization_observation(self.torch(npu,cuda),'after_masks')

    def test_absent_namespace_is_unknown_and_not_invented_false(self):
        with patch.dict(sys.modules):
            sys.modules.pop('torch_npu',None)
            observed = probe.initialization_observation(self.torch(registered=False),'after_torch')
        self.assertIs(observed['torch_npu_imported'],False)
        self.assertIs(observed['npu_namespace_registered'],False)
        self.assertIsNone(observed['npu_initialized'])

    def test_prior_twelve_capture_contracts_are_preserved_and_no_probe_device_queries(self):
        adapters = HERE.parent/'adapters'
        previous = ast.parse((adapters/'test_i04_capture_v1.py').read_text(encoding='utf-8'))
        current = ast.parse((adapters/'test_i04_capture_v2.py').read_text(encoding='utf-8'))
        classes = lambda tree:{x.name:ast.dump(x,include_attributes=False) for x in tree.body if isinstance(x,ast.ClassDef) and x.name != 'NativeMaskFactoryCPU'}
        self.assertEqual(classes(previous),classes(current))
        tree = ast.parse((HERE/'i04_cpu_mask_probe_v2.py').read_text(encoding='utf-8'))
        calls = {node.func.attr for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute)}
        self.assertFalse(calls & {'is_available','device_count','set_device','_lazy_init','init','synchronize'})


if __name__ == '__main__': unittest.main()

"""Freeze two logical requests and a finite four-call batch/padding stage.

Preparation only: no framework import, allocation, claim or model execution.
The second request is a prefix stress fixture, not a representative new sample.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def raw_json(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def main():
    case = Path(__file__).resolve().parents[1]
    original = case/'inputs/discovery-v1/wikitext2-discovery-001.json'
    digest = hashlib.sha256(original.read_bytes()).hexdigest()
    assert digest == '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
    document = json.loads(original.read_text(encoding='utf-8'))
    sequence = document['prompt'] + document['continuation']
    assert len(document['prompt']) == 128 and len(document['continuation']) == 32 and len(sequence) == 160
    assert all(type(token) is int and 0 <= token < 262144 for token in sequence)
    short = {'schema_version':1, 'sample':'wikitext2-prefix-stress-096',
        'kind':'derived_prefix_shape_stress', 'independent_representative_example':False,
        'parent_input_sha256':digest, 'parent_sample':document['sample'], 'parent_token_span':[0,96],
        'bos_policy':'Preserve the original token at logical position0; no retokenization or template.',
        'prompt':sequence[:64], 'continuation':sequence[64:96]}
    short_path = case/'inputs/i04-prefix-stress-096-v1.json'
    short_raw = raw_json(short)
    short_sha = hashlib.sha256(short_raw).hexdigest()
    positions = lambda prompt: sorted(set(i*(prompt-1)//15 for i in range(16)) | set(range(prompt-1,prompt+31)))
    assert len(positions(128)) == len(positions(64)) == 47
    assert 3*159+3*95 == 762 and 6*47 == 282 and 160+96+320+320 == 896
    raw_bytes, row_bytes = 896*262144*2, 282*262144*8
    assert raw_bytes == 469762048 and row_bytes == 591396864
    stage = {'schema_version':1, 'kind':'case_owned_bounded_stage_spec',
        'stage_id':'gemma4-gpu-npu-i04-batch-padding-v1-20261107',
        'prepared_utc':datetime.now(timezone.utc).isoformat(), 'status':'prepared_not_executed',
        'authorization':'Continued core GPU/NPU precision evaluation requested by the user; finite incremental single-device stage.',
        'model':{'repository':'google/gemma-4-12B','revision':'1a2c7729392586f5ecddae8807ee2ef741eabb9a',
            'model_class':'Gemma4UnifiedForConditionalGeneration','modalities':['text'],'parameter_dtype':'bfloat16','attention':'eager'},
        'requests':{'A':{'path':original.relative_to(case).as_posix(),'sha256':digest,'prompt_tokens':128,'continuation_tokens':32,'length':160},
            'B':{'path':short_path.relative_to(case).as_posix(),'sha256':short_sha,'prompt_tokens':64,'continuation_tokens':32,'length':96,
                'derived_prefix_stress':True,'independent_representative_example':False}},
        'modes':['alone-A','alone-B','batch-left','batch-right'], 'expected_native_calls':[1,1,1,1],
        'total_forward_calls_per_backend':4, 'new_model_processes_per_backend':1, 'same_loaded_model':True,
        'raw_shapes':{'alone-A':[1,160,262144],'alone-B':[1,96,262144],
            'batch-left':[2,160,262144],'batch-right':[2,160,262144]},
        'semantics':{'batch_slots':{'A':0,'B':1},'pad_token_id':0,'mask_dtype':'int64','position_dtype':'int64',
            'mask_rule':'Construct from frozen request lengths:1 valid,0 padding; never infer validity from token IDs.',
            'position_rule':'(attention_mask.cumsum(-1)-1).masked_fill(attention_mask==0,0)',
            'physical_offsets':{'alone-A':{'A':0},'alone-B':{'B':0},'batch-left':{'A':0,'B':64},'batch-right':{'A':0,'B':0}},
            'single_request_slot':0, 'use_cache':False,'past_key_values':None,'logits_to_keep':0,
            'labels_supplied':False,'shared_kv_states_supplied':False,'returned_cache_required':None,
            'returned_shared_kv_states_required':None,'native_logits_dtype':'bfloat16',
            'target_rule':'Request target t is scored from its physical offset+t-1 and original logical history[:t]. No cross-request pairing.',
            'valid_targets_per_request':{'A':159,'B':95},'distribution_positions':{'A':positions(128),'B':positions(64)},
            'distribution_positions_per_logical_observation':47,'logical_observations_per_backend':6,
            'target_scores_per_backend':762,'distribution_rows_per_backend':282,'physical_raw_rows_per_backend':896,
            'valid_raw_rows_per_backend':768,'pad_only_raw_rows_per_backend':128,
            'finiteness':'Require every valid logical raw row finite, including final unscored predictors A159/B95. Retain all physical rows losslessly and report pad-only nonfinite counts separately; never coerce or pair pad rows.',
            'final_logical_predictors_unscored':{'A':159,'B':95}, 'seed_before_each_mode':0,
            'state_control':'Same model object, parameter storage/config, available version counters and bounded small-buffer hashes; exact complete RNG digests as in I03. Reset seeds before every mode. Abort observed unexpected persistent state/policy changes; record unsupported probes.',
            'source_observations':['actual modeling_gemma4_unified.py','actual masking_utils.py','imported runtime package files'],
            'unsupported_policy':'Retain native failure; no alternative4D mask, backend switch, hidden truncation or automatic retry.'},
        'comparisons':{'within_backend_request_condition_pairs_per_backend':6,'matched_cross_backend_pairs':6,
            'target_distribution_pairs_total':18,'native_final_kv_pairs':0,
            'presentation':'Show cross GPU/NPU pairs first; retain source report order privately.',
            'pairing':'A and B each have alone/left/right logical observations; three within-condition pairs per request/backend plus matched cross-backend conditions. No A/B cross pairing.'},
        'payload_bytes_excluding_headers_per_backend':{'native_raw_logits':raw_bytes,'fp64_rows':row_bytes,
            'total':raw_bytes+row_bytes,'raw_tensor_files':4,'npy_files':282,'large_objects':286},
        'limits':{'max_native_model_processes_per_backend':1,'automatic_native_retries':0,
            'gpu_capture_timeout_seconds':900,'npu_capture_timeout_seconds':1200,
            'whole_attempt_timeout_seconds_per_backend':3000,'cpu_metadata_export_whole_timeout_seconds':960,
            'cpu_admission_timeout_seconds':900,'owned_cleanup_reserve_seconds':20,
            'minimum_free_device_bytes':35*1024**3,'minimum_gpu_host_effective_available_bytes':40*1024**3,
            'minimum_npu_host_effective_available_bytes':80*1024**3,'maximum_capture_product_bytes_per_backend':1342177280,
            'maximum_new_task_storage_bytes_per_backend':4*1024**3,'minimum_free_source_storage_bytes':5*1024**3,
            'maximum_logical_artifact_transport_bytes_per_direction':1207959552,
            'maximum_encoded_transport_bytes_per_direction':1610612736,'gpu_count':1,
            'npu_compute_visible_device_count':1,'npu_instance_visible_device_count':8},
        'native_prerequisite':{'requires_successful_i03_raw_numeric_admission':True,
            'prior_stage_sha256':'6e53e3cdf3e7fad8f56b43cb99a42bdb999ac074a5a40a3c1e7df72eeb504005',
            'analysis_source_sha256':'2468a5f2a1aafe9f9437edae2bd90b3bdca15f9c1abcc6fa3b927ddb8167691c',
            'artifact_helper_sha256':'b734babc65be6ec361acbc10905b6c3e02e8c5c57650efb11e3a195134a1b6eb',
            'tool_manifest_sha256':'d4db95a5ae22091417698109d0dd9836ff5665d66667c530aaf85a4f597ccf87',
            'binding':'Before native launch freeze actual completed I03 controller/report/comparison-spec/main/helper/two maps/tool-manifest original bytes and SHA in a portable proof wrapper and new source/claim. Require actual23 target/distribution and4KV comparisons; no placeholder or presumed success.'},
        'scope':{'independent_parent_inputs':1,'derived_prefix_shape_stress_requests':1,'cache_eviction_tested':False,
            'cached_serving_or_scheduler_tested':False,'repeatability_measured':False,'operator_cause_claimed':False},
        'cleanup':'Reap only owned descendants; stop owned H100/CPU apps after required transfer. Preserve shared NPU and unrelated workloads.',
        'thresholds':None,'acceptance':None,'full_core_complete':False}
    stage_path = case/'i04-stage-v1.json'
    assert not short_path.exists() and not stage_path.exists()
    with short_path.open('xb') as stream:stream.write(short_raw)
    with stage_path.open('xb') as stream:stream.write(raw_json(stage))
    print(json.dumps({'status':'i04_prepared_not_executed','input_B_sha256':short_sha,
        'stage_sha256':hashlib.sha256(stage_path.read_bytes()).hexdigest(),'payload_bytes':raw_bytes+row_bytes,
        'native_executions_started':0},indent=2))


if __name__ == '__main__':
    main()

"""Freeze actual I04 maps and run one bounded independent CPU comparison.

No model/framework/device import in this controller. The native arrays remain
unchanged. The pinned child performs independent admission and shared metrics.
"""
import argparse
from collections import Counter
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path,PurePosixPath
import signal
import sys
import time
import traceback

CASE='projects/gemma4-pilot/cases/text-native'
MAIN=CASE+'/adapters/admit_i04_batch_padding_v1.py'
MAIN_SHA='640b0af596111e12eb73aca20f7b8e5b101c04341af0aed2d3a5f9a1d2f19db0'
HELPER=CASE+'/adapters/i04_artifact_admission_v1.py'
HELPER_SHA='0d43e77420285436f4151d42c6cd8a6792001b004e0e0b870242f90c5bd33719'
RECORDER='skills/precision-compare/scripts/record_run.py'
RECORD_SHA='2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'
CONTROLLER=CASE+'/transfer/run_i04_actual_compare_v1.py'
STAGE_SHA='26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
EXPECTED_SHA='22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76'
PROOF_SHA='3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c'
CPU_SHA='8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec'
TASK='gemma4-i04-batch-padding-v1'
TOTAL,GENERIC,ANALYSIS,CLEANUP=960,920,900,20


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def load(path):
    def pairs(items):
        result={}
        for key,value in items:require(key not in result,'duplicate JSON key');result[key]=value
        return result
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    p=Path(path);require(p.is_file() and not p.is_symlink() and p.stat().st_size<=16*1024**2,'bounded regular metadata required')
    return json.loads(p.read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)


def put(path,document):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(document,stream,indent=2,allow_nan=False);stream.write('\n')


def safe_name(name):
    p=PurePosixPath(name)
    require(isinstance(name,str) and bool(name) and not p.is_absolute() and str(p)==name and '\\' not in name and
        all(x not in ('','.','..') for x in name.split('/')),'noncanonical relative source path')
    return name


def verify_tools(tools,manifest_sha):
    tools=Path(tools).resolve(strict=True);manifest=tools/'tool-bundle-manifest.json'
    require(sha(manifest)==manifest_sha,'external tool manifest SHA differs')
    doc=load(manifest)
    require(doc.get('kind')=='i04-offline-tool-bundle' and doc.get('native_executions_started')==0 and
        doc.get('acceptance',object()) is None,'wrong I04 CPU tool bundle')
    require(doc['files'][MAIN]['sha256']==MAIN_SHA and doc['files'][HELPER]['sha256']==HELPER_SHA and
        doc['files'][RECORDER]['sha256']==RECORD_SHA,'frozen admission/generic source differs')
    require({p.relative_to(tools).as_posix() for p in tools.rglob('*') if p.is_file()}==set(doc['files'])|{'tool-bundle-manifest.json'},
        'unexpected or omitted tool source')
    for name,ref in doc['files'].items():
        path=tools/safe_name(name)
        require(not path.is_symlink() and path.resolve(strict=True).is_relative_to(tools) and path.is_file() and
            path.stat().st_size==ref['size_bytes'] and sha(path)==ref['sha256'],'tool source changed: '+name)
    require(Path(__file__).resolve()==tools/CONTROLLER and sha(__file__)==doc['files'][CONTROLLER]['sha256'],
        'controller not from the frozen staged bundle')
    return doc


def endpoint(root,path,digest,category,retained_root=None):
    root=Path(root).resolve(strict=True);source=Path(path)
    require(not source.is_symlink(),'source-map symlink prohibited');source=source.resolve(strict=True)
    require(source.is_relative_to(root) and sha(source)==digest,'actual source-map path/SHA differs')
    mapping=load(source);request=mapping['request'];original=request['outer_receipt'];logical=PurePosixPath(original)
    require(request=={'task':'I04','backend':category,'outer_receipt':original} and logical.is_absolute() and
        '..' not in logical.parts and '\\' not in original,'actual I04/backend/original outer receipt differs')
    require(mapping.get('full_array_hashes_checked')==286 and mapping.get('retained_array_count')==(0 if category=='GPU' else 286),
        'actual complete copied/retained286 map required')
    ref=mapping['files'][original];actual=source.parent/safe_name(ref['path'])
    require(not actual.is_symlink() and actual.resolve(strict=True).is_relative_to(source.parent) and
        actual.stat().st_size==ref['size'] and sha(actual)==ref['sha256'],'mapped original outer bytes differ')
    outer=load(actual)
    fixed={'task':'I04','backend':category,'status':'completed','returncode':0,'timed_out':False,'native_capture_count':1,
        'native_forward_calls_total':4,'model_loads':1,'stage_spec_source_sha256':STAGE_SHA,
        'expected_inventory_source_sha256':EXPECTED_SHA,'i03_prerequisite_source_sha256':PROOF_SHA,'cpu_prerequisite_source_sha256':CPU_SHA}
    require(all(k in outer and type(outer[k]) is type(v) and outer[k]==v for k,v in fixed.items()),'actual successful four-call dual-proof identity differs')
    counts={'status':'i04_output_artifacts_checked','target_scores':762,'distribution_rows':282,'physical_raw_rows':896,'valid_raw_rows':768,'pad_only_raw_rows':128}
    require(all(outer.get('validation',{}).get(k)==v for k,v in counts.items()),'actual I04 physical/logical inventory differs')
    result={'source_map':{'path':str(source),'sha256':digest},'receipt':{'source_path':original,'sha256':ref['sha256']}}
    if category=='GPU':require(retained_root is None,'GPU must copy all native arrays')
    else:
        retained=Path(retained_root);require(not retained.is_symlink(),'retained root symlink prohibited');retained=retained.resolve(strict=True)
        require(retained==root/'i04-batch-padding-20261107' and Path(outer['output_dir']).is_relative_to(retained),
            'explicit actual NPU I04 retained root differs');result['retained_root']=str(retained)
    return result


def validate_report(report,spec_sha):
    require(report.get('status')=='i04_raw_bf16_batch_padding_and_request_pairs_checked' and report.get('task')==TASK and
        report.get('comparison_spec_sha256')==spec_sha and report.get('stage_spec_sha256')==STAGE_SHA and
        report.get('cpu_prerequisite_sha256')==CPU_SHA and report.get('thresholds',object()) is None and
        report.get('acceptance',object()) is None and report.get('full_core_complete') is False,'actual I04 numerical report identity differs')
    scope={'independent_parent_inputs':1,'derived_prefix_shape_stress_requests':1,'native_calls_per_backend':4,
        'logical_observations_per_backend':6,'target_scores_rederived':1524,'full_vocabulary_rows_rederived':564,
        'raw_physical_rows_retained':1792,'valid_raw_rows_finite_checked':1536,'pad_only_rows_separately_counted':256,
        'target_distribution_pairs':18,'matched_cross_backend_pairs':6,'within_backend_pairs':12,
        'original_large_sources_final_bytehash_checked':572,'comparison_documents':144}
    require(all(report['scope'].get(k)==v for k,v in scope.items()),'actual18-pair/raw572 scope differs')
    pairs=report['target_distribution_pairs']
    require(len(pairs)==18 and Counter(p['kind'] for p in pairs)=={'cross_backend_matched':6,'within_backend_batch_padding':12} and
        Counter(p['request'] for p in pairs)=={'A':9,'B':9},'request-specific18 pair inventory differs')
    return report['scope']


def run(root,tools,manifest_sha,gpu_map,gpu_sha,npu_map,npu_sha):
    require(os.name=='posix' and not Path(root).is_symlink(),'POSIX original R required')
    root=Path(root).resolve(strict=True);tools=Path(tools).resolve(strict=True)
    require(tools.is_relative_to(root/'tools'),'new tool import must be below R/tools')
    verify_tools(tools,manifest_sha)
    started=time.monotonic();folder=root/'runs'/('compare-i04-invocation-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));folder.mkdir(mode=0o700)
    state={'schema_version':1,'task':'I04','status':'running','started_utc':datetime.now(timezone.utc).isoformat(),
        'run':str(folder),'tools_root':str(tools),'tool_manifest_sha256':manifest_sha,'whole_cpu_seconds':TOTAL,
        'child_work_seconds':GENERIC,'analysis_seconds':ANALYSIS,'cleanup_reserve_seconds':CLEANUP,
        'native_executions_started':0,'acceptance':None};put(folder/'controller-start.json',state)
    code=2;generic=None
    def expire(*_):raise KeyboardInterrupt('I04 CPU controller whole960s deadline')
    previous={s:signal.signal(s,expire) for s in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
    signal.setitimer(signal.ITIMER_REAL,TOTAL)
    try:
        spec={'schema_version':1,'task':TASK,'stage_spec_sha256':STAGE_SHA,'expected_inventory_sha256':EXPECTED_SHA,
            'i03_prerequisite_sha256':PROOF_SHA,'cpu_prerequisite_sha256':CPU_SHA,
            'endpoints':{'GPU':endpoint(root,gpu_map,gpu_sha,'GPU'),
                'NPU':endpoint(root,npu_map,npu_sha,'NPU',root/'i04-batch-padding-20261107')},'thresholds':None,'acceptance':None}
        spec_path=folder/'comparison-spec.json';put(spec_path,spec);spec_sha=sha(spec_path)
        state['comparison_spec']={'path':str(spec_path),'sha256':spec_sha}
        args=[str(root/'venv/bin/python'),'-B',str(tools/MAIN),'--spec',str(spec_path),'--spec-sha256',spec_sha,
            '--output-dir',str(folder/'bundle'),'--timeout-seconds',str(ANALYSIS)]
        state['argv']=args;put(folder/'execution-start.json',state)
        recorder=tools/RECORDER;module_spec=importlib.util.spec_from_file_location('i04_cpu_compare_recorder',recorder)
        module=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(module)
        require(Path(module.__file__).resolve()==recorder and sha(recorder)==RECORD_SHA,'generic import differs')
        profile=folder/'cpu-execution-profile.json';put(profile,{'env':{'PYTHONHOME':None,'PYTHONPATH':None,
            'PYTHONHASHSEED':'0','PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1','TORCH_DEVICE_BACKEND_AUTOLOAD':'0'}})
        require(TOTAL-(time.monotonic()-started)-CLEANUP>=GENERIC,'full finite child budget unavailable')
        generic,command=module.record_run(folder,'cpu','i04-admission',GENERIC,args,cwd=tools,execution=profile)
        state['generic_receipt']={'path':str(generic/'command.json'),'sha256':sha(generic/'command.json')}
        state['child_returncode']=command['child_returncode'];state['timed_out']=command['status']=='timed_out'
        require(command['status']=='completed' and command['returncode']==0 and command['child_returncode']==0,
            'independent I04 numeric child did not complete0')
        report_path=folder/'bundle/i04-comparison-report.json';report=load(report_path);scope=validate_report(report,spec_sha)
        require(report['source_map_sha256']=={'GPU':gpu_sha,'NPU':npu_sha},'report endpoint map pins differ')
        verify_tools(tools,manifest_sha)
        require(sha(spec_path)==spec_sha and sha(gpu_map)==gpu_sha and sha(npu_map)==npu_sha,'spec or endpoint map changed')
        state.update(status='completed',returncode=0,report={'path':str(report_path),'sha256':sha(report_path)},scope=scope);code=0
    except BaseException as exc:
        state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),
            partial_output_preserved=True,automatic_retry=False)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        for s,h in previous.items():signal.signal(s,h)
        if generic is not None:
            for key,name in [('stdout','stdout.bin'),('stderr','stderr.bin')]:
                p=generic/name
                if p.is_file():state[key]={'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
        state.update(finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started)
        put(folder/'controller-receipt.json',state)
    print(json.dumps({'status':state['status'],'receipt':str(folder/'controller-receipt.json'),'report':state.get('report'),'error':state.get('error')},indent=2),flush=True)
    return code


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for n in ('root','tools-root','gpu-source-map','npu-source-map'):parser.add_argument('--'+n,type=Path,required=True)
    for n in ('tool-manifest-sha256','gpu-map-sha256','npu-map-sha256'):parser.add_argument('--'+n,required=True)
    a=parser.parse_args();return run(a.root,a.tools_root,a.tool_manifest_sha256,a.gpu_source_map,a.gpu_map_sha256,a.npu_source_map,a.npu_map_sha256)


if __name__=='__main__':raise SystemExit(main())

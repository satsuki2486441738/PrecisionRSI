"""Actual metadata final-copy/record regressions; no native arrays or history writes."""
from contextlib import contextmanager
import copy
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('_observer_finalizer_test', HERE/'finalize_observer_public_candidate_v2.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


@contextmanager
def no_arrays():
    actual_open, actual_stat = Path.open, Path.stat
    def opened(path, *args, **kwargs):
        if path.suffix in ('.npy', '.safetensors'): raise AssertionError('native array opened')
        return actual_open(path, *args, **kwargs)
    def stated(path, *args, **kwargs):
        if path.suffix in ('.npy', '.safetensors'): raise AssertionError('native array statted')
        return actual_stat(path, *args, **kwargs)
    with patch.object(Path, 'open', opened), patch.object(Path, 'stat', stated): yield


class FinalCopy(unittest.TestCase):
    def test_actual_final_copy_eight_files_six_pairs_zeroarrayIO_and_unchanged_originals(self):
        before = {name: m.metadata(m.ORIGINAL/name, sha) for name, sha in m.PINS.items()}
        with tempfile.TemporaryDirectory(prefix='compare-observer-finalcopy-fixture-', dir=HERE) as tmp, no_arrays():
            target = Path(tmp)/'candidate'; result = m.finalize(target)
            self.assertEqual(len(result['public_files']), 7)
            self.assertEqual(result['arrays_statted_opened_copied'], 0)
            public = target/'public'; record = json.loads((target/'private/evaluation-record.json').read_bytes())
            self.assertEqual(len(record['sides']), 4); self.assertEqual(len(record['comparisons']), 6)
            self.assertTrue(all(s['id'].startswith('gpu-') for s in record['sides']))
            self.assertEqual(record['scope']['unique_source_target_scores'], 636)
            self.assertFalse(record['scope']['GPU_NPU_observer_comparison_complete'])
            self.assertIsNone(record['archive']['revision']); self.assertEqual(record['archive']['replay_cases'], 6)
            self.assertEqual(record['status'], 'partial'); self.assertFalse(record['full_core_complete'])
            self.assertIsNone(record['acceptance']); self.assertIsNone(record['thresholds'])
            for name, pin in record['archive']['file_sha256'].items(): self.assertEqual(m.digest((public/name).read_bytes()), pin)
            changed = [name for name, raw in before.items() if raw != (public/Path(name).name).read_bytes()]
            self.assertEqual(changed, ['documents/report.md', 'documents/cost.json'])
            sample_pair = record['comparisons'][4]
            samples = json.loads(before['numeric/selected-metrics.json'])['boundary_samples']
            self.assertEqual(sample_pair['sampled_boundary_summary'], samples)
            self.assertEqual(len(sample_pair['sampled_boundary_summary']['per_boundary']), 98)
            self.assertNotEqual(sample_pair['sampled_boundary_summary']['per_boundary']['block.00.output']['cosine'], 1)
            self.assertEqual(record['plan_coverage']['counts'], {'complete': 9, 'partial': 9, 'pending': 8, 'deferred': 21, 'not_applicable': 2})
            self.assertEqual(record['NPU_observer']['owned_model_loads'], 0)
            self.assertEqual(record['NPU_observer']['owned_observer_forwards'], 0)
            self.assertFalse(record['NPU_observer']['other_processes_stopped'])
            run = subprocess.run([sys.executable, '-S', '-B', str(public/'replay-targets.py'), str(public/'selected-targets.json'),
                str(public/'selected-metrics.json')], capture_output=True, timeout=10)
            self.assertEqual(run.returncode, 0, run.stderr); self.assertEqual(json.loads(run.stdout)['pairs'], 6)
            for raw in [record, json.loads((public/'cost.json').read_bytes())]: m.privacy(raw)
            with self.assertRaises(ValueError): m.finalize(target)
        self.assertEqual(before, {name: m.metadata(m.ORIGINAL/name, sha) for name, sha in m.PINS.items()})

    def test_two_actual_failed_intervals_and_original_four_preserved_no_billing_total(self):
        cost = m.read(m.metadata(m.ORIGINAL/'documents/cost.json', m.PINS['documents/cost.json']))
        controls = [m.read(m.metadata(m.CASE/path, sha)) for _, path, sha, _ in m.FAILURES]
        result = m.augmented_cost(cost, controls)
        self.assertEqual(result['recorded_CPU_intervals'][2:], cost['recorded_CPU_intervals'])
        self.assertEqual([x['seconds'] for x in result['recorded_CPU_intervals'][:2]], [33.90709985199999, 41.989743333999996])
        self.assertTrue(result['known_formal_CPU_failure_intervals_included'])
        self.assertIsNone(result['monetary_cost']); self.assertIsNone(result['rate'])
        self.assertFalse(result['invoice_or_billed_GPU_hours_known']); self.assertFalse(result['P01_measured'])
        self.assertFalse(result['complete_executed_CPU_setup_failure_and_transfer_time_known'])
        bad = copy.deepcopy(controls); bad[0]['native_executions_started'] = 1
        with self.assertRaises(ValueError): m.augmented_cost(cost, bad)
        bad = copy.deepcopy(controls); bad[1]['elapsed_seconds'] += .01
        with self.assertRaises(ValueError): m.augmented_cost(cost, bad)

    def test_report_changes_whitespace_only_and_metrics_remain_immutable(self):
        raw = m.metadata(m.ORIGINAL/'documents/report.md', m.PINS['documents/report.md']); result = m.report_spacing(raw)
        self.assertNotEqual(raw, result)
        self.assertEqual(''.join(raw.decode().split()), ''.join(result.decode().split()))
        self.assertIn('same 128 + 32', result.decode()); self.assertIn('The 159 scores', result.decode())
        self.assertIn('4.7021875179805497e-17', result.decode())

    def test_actual_prepared_record_passes_owning_schema_only_after_real_revision_slot_bound(self):
        # An arbitrary hash is a schema fixture, never an observed Git commit.
        # Production output above deliberately leaves the revision None.
        with tempfile.TemporaryDirectory(prefix='compare-observer-record-schema-', dir=HERE) as tmp:
            root = Path(tmp); m.finalize(root/'candidate')
            record = m.read((root/'candidate/private/evaluation-record.json').read_bytes())
            validator_path = HERE.parents[4]/'.github/validate_history.py'
            s = importlib.util.spec_from_file_location('_observer_owner_history_validator', validator_path)
            owner = importlib.util.module_from_spec(s); s.loader.exec_module(owner)
            site = root/'site'; (site/'data').mkdir(parents=True)
            evidence = site/'evidence'/m.ID; evidence.mkdir(parents=True)
            for path in (root/'candidate/public').iterdir(): (evidence/path.name).write_bytes(path.read_bytes())
            document = {'schema_version': 1, 'updated_at': '2026-11-07', 'evaluations': [record]}
            (site/'data/evaluations.json').write_bytes(m.encode(document))
            with self.assertRaises((ValueError, TypeError)): owner.validate_evaluations(site)
            record['archive']['revision'] = 'a'*40
            (site/'data/evaluations.json').write_bytes(m.encode(document))
            self.assertEqual(owner.validate_evaluations(site), 1)

    @unittest.skipUnless(__import__('shutil').which('node'), 'Node is required for existing title/chart regression')
    def test_new_record_title_and_equal_value_charts_use_existing_UI(self):
        with tempfile.TemporaryDirectory(prefix='compare-observer-record-title-', dir=HERE) as tmp:
            target = Path(tmp)/'candidate'; m.finalize(target)
            source = "const fs=require('fs'),p=require('./site/evaluation-presentation.js'),c=require('./site/evaluations.js');const r=JSON.parse(fs.readFileSync(process.argv[1]));console.log(JSON.stringify({name:p.titleFor(r,'Gemma-4-12B'),chart:c.chartModel(r.comparisons[0].metrics[0],r.comparisons[0])}));"
            run = subprocess.run(['node', '-e', source, str(target/'private/evaluation-record.json')], cwd=HERE.parents[4], capture_output=True, timeout=10)
            self.assertEqual(run.returncode, 0, run.stderr)
            result = json.loads(run.stdout)
            self.assertEqual(result['name'], 'Transformers · observer transparency · Gemma-4-12B')
            self.assertEqual(result['chart']['reason'], 'equal-sides')


if __name__ == '__main__': unittest.main()

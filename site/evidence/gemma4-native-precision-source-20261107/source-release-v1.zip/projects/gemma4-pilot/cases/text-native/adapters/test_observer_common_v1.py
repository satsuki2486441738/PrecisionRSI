"""Meaningful NumPy/metadata CPU regressions; no Torch/model/device import."""
import copy
import json
import importlib.util
import math
from pathlib import Path
import random
import struct
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import observer_common_v1 as common


class Row:
    def __init__(self,values):self.values=np.asarray(values)
    def __getitem__(self,key):return Row(self.values[key])
    def double(self):return self
    def numpy(self):return self.values.astype(np.float64)


def inventory():
    sequence=[(i*7+3)%16 for i in range(160)]
    return common.coordinates({'sample':'synthetic-observer','prompt':sequence[:128],'continuation':sequence[128:]})


def rng():
    return {'python':{'sha256':'a'*64},'numpy':{'sha256':'b'*64,'header':{'algorithm':'MT19937','word_count':624,
        'word_encoding':'uint32-little-endian','position':624,'has_gauss':0,'cached_gaussian_binary64_le_hex':'0000000000000000'}},
        'torch_cpu':{'sha256':'c'*64},'device0':{'sha256':'d'*64}}


def census(dispatch=False):
    specs=common.collectors.boundary_specs();names=['']+list(dict.fromkeys(x['module'] for x in specs))+['not-fired']
    modules=[{'name':name,'class':'synthetic.nn.Module'} for name in names]
    items=[{**x,'invocations':int(x['name']!='not-fired'),'completed_invocations':int(x['name']!='not-fired')} for x in modules]
    record={'operator':'aten.synthetic.default','schema':'aten::synthetic(Tensor x)->Tensor','module_scope':[''],
        'inputs':{'shape':[1,160,3840]},'kwargs':{},'outputs':{'shape':[1,160,3840]}}
    return modules,{'schema_version':1,'enabled':True,'status':'completed','error':None,'actual_module_count':len(modules),
        'module_invocations':items,'zero_fired_modules':['not-fired'],'fired_module_count':len(items)-1,'total_module_invocations':len(items)-1,
        'hook_registry_restored':True,'boundary_specs':specs,'boundary_counts':{x['id']:1 for x in specs},
        'boundary_events':[{**spec,'ordinal':i,'observed':{'shape':[1,160,3840],'dtype':'torch.bfloat16','device':'synthetic'},
            'token_indices':common.collectors.TOKENS,'channel_indices':common.collectors.CHANNELS,'sample_shape':[1,47,64],'sample_dtype':'torch.bfloat16'} for i,spec in enumerate(specs)],
        'dispatcher':{'enabled':dispatch,'observed_invocations':1 if dispatch else 0,'unique_signatures':1 if dispatch else 0,
            'signatures':[{'signature_sha256':common.collectors.signature(record),'count':1,'first_invocation':1,**record}] if dispatch else [],
            'collector_generated_excluded_operations':{'aten.clone.default':2} if dispatch else {},'metadata_byte_budget_accounting':512 if dispatch else 0,
            'limits':{'invocations':common.collectors.MAX_CALLS,'unique_signatures':common.collectors.MAX_SIGNATURES,'serialized_bytes':common.collectors.MAX_BYTES}}}


class Common(unittest.TestCase):
    def test_production_pin_gates_before_any_framework_or_file_read(self):
        self.assertIsNone(common.STAGE_SHA256);self.assertIsNone(common.EXPECTED_SHA256);self.assertIsNone(common.I04_PREREQUISITE_SHA256)
        with patch.object(common,'sha',side_effect=AssertionError('must not read file before stage ready')):
            with self.assertRaisesRegex(ValueError,'unready'):common.prepare(SimpleNamespace(),__file__)

    def test_actual_static_inventory_signatures_match_both_recorded_backends(self):
        root=common.HERE.parent/'transfer/i01-numeric-small-local-20261106T145700Z/payload/payload'
        for key in ('0190','0337'):
            doc=common.read(root/key/'loaded-model-inventory.json')
            self.assertEqual(common.collectors.signature(doc['modules']),common.MODULE_SIGNATURE)
            params=[{k:x[k] for k in ('name','shape','dtype','numel')} for x in doc['parameters']]
            self.assertEqual(common.collectors.signature(params),common.PARAMETER_SIGNATURE)
            self.assertEqual((len(doc['modules']),len(params)),(875,630))

    def test_frozen_input_expected_coordinates_counts_and_no_last_target(self):
        actual=common.coordinates(common.read(common.HERE.parent/'inputs/discovery-v1/wikitext2-discovery-001.json'))
        core=common.expected_core(actual)
        self.assertEqual(core['raw_logits']['shape'],[1,160,262144]);self.assertEqual(core['targets_per_mode'],159)
        self.assertEqual(actual['all_targets'][-1]['position'],159);self.assertEqual(core['distribution_positions'][-1],158)
        self.assertEqual((len(core['boundaries']),len(core['channels']),core['numeric_data_bytes_excluding_headers']),(98,64,730988032))
        self.assertEqual(core['enabled_modes'],['hooks-only','hooks-plus-dispatch-metadata'])

    def test_complete_rng_rejects_unknown_device_bytes_or_truncated_numpy_header(self):
        self.assertEqual(common.complete_rng(rng()),rng())
        for name in ('python','numpy','torch_cpu','device0'):
            bad=rng();bad[name]={'unavailable':True,'error_type':'fixture'}
            with self.assertRaisesRegex(ValueError,'unavailable'):common.complete_rng(bad)
        bad=rng();bad['numpy']['header']['word_count']=623
        with self.assertRaisesRegex(ValueError,'NumPy'):common.complete_rng(bad)

    def test_complete_numpy_digest_changes_for_interior_state_word(self):
        state=np.random.RandomState(0).get_state();other=(state[0],state[1].copy(),*state[2:]);other[1][300]^=1
        with np.printoptions(threshold=20):self.assertEqual(repr(state),repr(other))
        self.assertNotEqual(common.controlled.numpy_rng_observation(state)['sha256'],common.controlled.numpy_rng_observation(other)['sha256'])

    def test_actual_cpu_probe_rng_digest_preserves_signed_zero_and_nan_payload_bits(self):
        source=common.HERE.parent/'transfer/probe_observer_cpu_v1.py';spec=importlib.util.spec_from_file_location('cpu_probe_digest_only',source)
        probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe);state=np.random.RandomState(0).get_state()
        positive=(*state[:4],0.0);negative=(*state[:4],-0.0)
        self.assertNotEqual(probe.numpy_state_digest(np,positive),probe.numpy_state_digest(np,negative))
        first=struct.unpack('<d',bytes.fromhex('010000000000f87f'))[0];second=struct.unpack('<d',bytes.fromhex('020000000000f87f'))[0]
        self.assertEqual(repr(first),repr(second));self.assertNotEqual(probe.numpy_state_digest(np,(*state[:4],first)),probe.numpy_state_digest(np,(*state[:4],second)))

    def test_159_targets_and47_rows_analytic_cpu_rederive(self):
        inv=inventory();values=np.asarray([[[j*.125+i*.0003*j for j in range(16)] for i in range(160)]])
        with tempfile.TemporaryDirectory() as temporary,patch.object(common,'VOCABULARY',16),patch.object(common,'save_tensors',side_effect=lambda tensors,path,*_:path.write_bytes(b'synthetic raw transport placeholder')):
            folder=Path(temporary)/'modes/hooks-only';folder.mkdir(parents=True)
            raw=common.derive_rows(Row(values),inv,folder,'hooks-only');common.validate_rows(folder,inv,'hooks-only',raw['sha256'])
            targets=common.read(folder/'target-scores.json')['scores'];rows=common.read(folder/'distributions.json')['positions']
            self.assertEqual(len(targets),159);self.assertEqual([x['position'] for x in rows],common.collectors.TOKENS)
            for p in (0,127,158):
                logits=values[0,p];maximum=max(logits);normalizer=math.log(math.fsum(math.exp(float(x)-maximum) for x in logits))
                expected=float(logits[inv['sequence'][p+1]])-maximum-normalizer
                self.assertAlmostEqual(targets[p]['logprob'],expected,places=14)
            overlap=next(x for x in rows if x['position']==127);self.assertEqual(overlap['roles'],['prompt_sample','continuation'])
            self.assertNotIn(159,[x['position'] for x in rows]);self.assertEqual(targets[-1]['position'],159)

    def test_target_history_and_npy_row_tamper_fail_structural_validator(self):
        inv=inventory();values=np.asarray([[[j*.125 for j in range(16)] for _ in range(160)]])
        with tempfile.TemporaryDirectory() as temporary,patch.object(common,'VOCABULARY',16),patch.object(common,'save_tensors',side_effect=lambda tensors,path,*_:path.write_bytes(b'synthetic raw')):
            folder=Path(temporary)/'modes/hooks-only';folder.mkdir(parents=True);raw=common.derive_rows(Row(values),inv,folder,'hooks-only')
            index_path=folder/'distributions.json';original=index_path.read_bytes();doc=common.read(index_path);doc['positions'][0]['history'][0]^=1
            index_path.write_text(json.dumps(doc),'utf8')
            with self.assertRaisesRegex(ValueError,'history'):common.validate_rows(folder,inv,'hooks-only',raw['sha256'])
            index_path.write_bytes(original)
            path=folder/'dist-p000.npy';array=np.load(path);array[0,inv['sequence'][1]]-=.01
            with path.open('wb') as stream:np.save(stream,array,allow_pickle=False)
            with self.assertRaisesRegex(ValueError,'selected value'):common.validate_rows(folder,inv,'hooks-only',raw['sha256'])

    def test_last_unscored_native_row_is_still_required_finite(self):
        inv=inventory();values=np.zeros((1,160,16));values[0,159,0]=np.nan
        with tempfile.TemporaryDirectory() as temporary,patch.object(common,'VOCABULARY',16),patch.object(common,'save_tensors',side_effect=lambda tensors,path,*_:path.write_bytes(b'synthetic raw')):
            folder=Path(temporary)/'modes/hooks-only';folder.mkdir(parents=True)
            with self.assertRaisesRegex(ValueError,'nonfinite'):common.derive_rows(Row(values),inv,folder,'hooks-only')
            self.assertFalse((folder/'capture-summary.json').exists())

    def test_census_boundary_and_dispatch_closure_accept_then_reject_tampers(self):
        for dispatch in (False,True):
            modules,doc=census(dispatch);common.validate_observer(doc,modules,True,dispatch)
            mutations=[lambda d:d['zero_fired_modules'].clear(),lambda d:d['boundary_events'][5]['token_indices'].append(159),
                lambda d:d['module_invocations'][0].update(invocations=0),lambda d:d['boundary_counts'].update({'block.00.input':0})]
            if dispatch:mutations+=[lambda d:d['dispatcher']['signatures'][0].update(schema='forged'),lambda d:d['dispatcher'].update(observed_invocations=2)]
            for mutation in mutations:
                bad=copy.deepcopy(doc);mutation(bad)
                with self.assertRaises(ValueError):common.validate_observer(bad,modules,True,dispatch)

    def test_disabled_control_does_not_fabricate_zero_fired_census(self):
        doc={'enabled':False,'dispatcher':{'enabled':False},'status':'disabled_control','boundary_specs':common.collectors.boundary_specs(),
            'boundary_counts':None,'module_invocations':None,'zero_fired_modules':None}
        common.validate_observer(doc,[],False,False);doc['zero_fired_modules']=[]
        with self.assertRaisesRegex(ValueError,'claimed'):common.validate_observer(doc,[],False,False)


if __name__=='__main__':unittest.main()

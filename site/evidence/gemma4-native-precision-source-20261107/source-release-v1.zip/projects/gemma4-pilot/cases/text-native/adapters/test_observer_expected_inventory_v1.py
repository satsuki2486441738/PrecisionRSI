"""Stdlib-only independent static/coordinate regressions; zero native work."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import observer_expected_inventory_v1 as expected

CASE=Path(__file__).resolve().parents[1]
REFERENCE=CASE/'transfer/i01-numeric-small-local-20261106T145700Z/payload/payload'
GPU=REFERENCE/'0190/loaded-model-inventory.json'
NPU=REFERENCE/'0337/loaded-model-inventory.json'
CONFIG=CASE/'transfer/hf-smallfiles-20261105T112300Z/snapshot/config.json'
MODELING=REFERENCE/'0101/modeling_gemma4_unified.py'
INPUT=CASE/'inputs/discovery-v1/wikitext2-discovery-001.json'
STAGE=CASE/'observer-stage-v1.json'


class Independent(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.geometry=expected.load_geometry(GPU,NPU,CONFIG,MODELING)
        cls.stage=expected.read(STAGE);cls.stage_sha=expected.digest(STAGE.read_bytes());cls.input=expected.read(INPUT)
        cls.document=expected.derive(cls.input,expected.INPUT_SHA,cls.stage,cls.stage_sha,cls.geometry)

    def test_actual_geometry_exact_source_and_loaded_graph875_630_629(self):
        self.assertEqual((self.geometry['modules'],self.geometry['named_parameter_entries_including_alias'],
            self.geometry['unique_parameter_objects_from_recorded_alias_groups']),(875,630,629))
        self.assertEqual(self.geometry['full_attention_block_indices'],[5,11,17,23,29,35,41,47])
        self.assertEqual(self.geometry['source_observation']['scaled_embedding_forward_line'],549)
        self.assertEqual(self.geometry['source_observation']['text_final_norm_line'],684)
        self.assertTrue(self.geometry['static_inventory_is_not_executed_module_or_kernel_coverage'])

    def test_exact160_input_mask_positions_zero_token_remains_valid(self):
        doc=copy.deepcopy(self.input);doc['prompt'][0]=0
        result=expected.derive(doc,expected.INPUT_SHA,self.stage,self.stage_sha,self.geometry)
        self.assertEqual(result['input_ids'][0][0],0);self.assertEqual(result['attention_mask'],[[1]*160])
        self.assertEqual(result['position_ids'],[list(range(160))]);self.assertEqual(len(result['sequence']),160)
        self.assertEqual([x['position'] for x in result['all_targets']],list(range(1,160)))
        self.assertEqual(result['all_targets'][-1]['prediction_position'],158);self.assertEqual(result['unscored_prediction_indices'],[159])
        self.assertNotIn(160,[x['position'] for x in result['all_targets']])

    def test_known159_targets_match_original_continuation_and47_deduplicated_histories(self):
        doc=self.document;self.assertEqual(len(doc['all_targets']),159)
        for target in doc['all_targets']:
            self.assertEqual(target['token'],doc['sequence'][target['position']]);self.assertEqual(target['prediction_position'],target['position']-1)
        positions=sorted({i*127//15 for i in range(16)}|set(range(127,159)))
        self.assertEqual(doc['distribution_positions'],positions);self.assertEqual(len(positions),47)
        overlap=[x for x in doc['distribution_rows'] if x['position']==127];self.assertEqual(len(overlap),1)
        self.assertEqual(overlap[0]['roles'],['prompt_sample','continuation'])
        for row in doc['distribution_rows']:self.assertEqual(row['history'],doc['sequence'][:row['position']+1])

    def test98_exact_ordered_boundaries_sample_retains_batch_axis(self):
        points=self.document['boundaries'];self.assertEqual(len(points),98);self.assertEqual(len({x['id'] for x in points}),98)
        self.assertEqual(points[0],{'id':'embedding.scaled.output','module':'model.language_model.embed_tokens','when':'output'})
        self.assertEqual(points[-1],{'id':'norm.final.output','module':'model.language_model.norm','when':'output'})
        self.assertEqual(self.document['sample_shape'],[1,47,64]);self.assertEqual(len(set(self.document['channels'])),64)
        self.assertEqual((self.document['channels'][0],self.document['channels'][-1]),(0,3839))
        self.assertNotIn('lm_head.input',[x['id'] for x in points])
        for i in range(48):self.assertEqual([x['id'] for x in points[1+i*2:3+i*2]],['block.%02d.input'%i,'block.%02d.output'%i])

    def test_four_modes16pairs188rows196keys194files_and_exact_bytes(self):
        doc=self.document;pairs=doc['comparison_pairs'];self.assertEqual(len(pairs),16);self.assertEqual(len({x['id'] for x in pairs}),16)
        self.assertEqual(sum(x['kind']=='within_backend_observer_modes' for x in pairs),12)
        self.assertEqual(sum(x['kind']=='matched_cross_backend_mode' for x in pairs),4)
        self.assertEqual(sum(x['distribution_rows'] for x in pairs),752)
        files=doc['native_files_per_backend'];self.assertEqual([len(files[x]) for x in ('raw_logits','distribution_rows','selected_boundaries')],[4,188,2])
        self.assertEqual(sum(map(len,files.values())),194)
        self.assertEqual(4*160*262144*2+188*262144*8+196*1*47*64*2,doc['numeric_data_bytes_excluding_headers'])
        self.assertEqual(len(doc['primary_boundary_pairs']),98)
        self.assertTrue(all(x['native_sample_shape']==[1,47,64] and x['upstream_propagation_possible'] for x in doc['primary_boundary_pairs']))

    def test_prepared_stage_resource_and_proof_nulls_never_open_native(self):
        expected.stage_check(self.stage);proof=self.stage['prerequisites']
        self.assertIsNone(proof['actual_i04_numeric_wrapper_sha256']);self.assertIsNone(proof['actual_observer_tiny_CPU_wrapper_sha256'])
        self.assertEqual(self.stage['limits']['controller_work_timeout_seconds']+self.stage['limits']['cpu_metadata_export_whole_timeout_seconds']+
            self.stage['limits']['owned_cleanup_reserve_seconds'],3600)
        self.assertEqual(self.document['native_gate_status'],'proof_hashes_missing');self.assertFalse(self.document['native_execution_allowed_by_inventory'])
        declared=copy.deepcopy(self.stage);declared['prerequisites']['actual_i04_numeric_wrapper_sha256']='a'*64;declared['prerequisites']['actual_observer_tiny_CPU_wrapper_sha256']='b'*64
        other=expected.derive(self.input,expected.INPUT_SHA,declared,'c'*64,self.geometry)
        self.assertEqual(other['native_gate_status'],'hashes_declared_but_proofs_not_validated');self.assertFalse(other['native_execution_allowed_by_inventory'])

    def test_typed_stage_budget_boundary_mask_and_proof_declarations_tampers_fail(self):
        changes=[lambda s:s['limits'].update(controller_work_timeout_seconds=2621),lambda s:s['limits'].update(automatic_native_retries=False),
            lambda s:s['boundaries'].update(sample_shape_required=[47,64]),lambda s:s['boundaries'].update(final_boundary_id='lm_head.input'),
            lambda s:s['input_semantics'].update(use_cache=0),lambda s:s['input_semantics'].pop('past_key_values'),lambda s:s['static_geometry'].update(hidden_width=262144),
            lambda s:s['prerequisites'].update(actual_i04_numeric_wrapper_sha256='not-known'),lambda s:s['prerequisites'].update(required_before_native=False),
            lambda s:s['observer_controls'].update(unknown_RNG_bytes_fail_closed=False),lambda s:s['dispatcher'].update(original_function_calls_per_interception=2)]
        for change in changes:
            with self.subTest(change=repr(change)):
                stage=copy.deepcopy(self.stage);change(stage)
                with self.assertRaises(ValueError):expected.stage_check(stage)

    def test_windows_built_native_roots_are_explicit_POSIX_and_backslash_regression(self):
        for value in self.stage['native_task_roots'].values():self.assertEqual(expected.posix_root(value),value);self.assertNotIn('\\',value)
        for bad in ('C:\\data\\observer','/data/afs\\observer','/data//observer','/data/../observer','relative/observer'):
            with self.assertRaisesRegex(ValueError,'POSIX'):expected.posix_root(bad)
        bad=copy.deepcopy(self.stage);bad['native_task_roots']['GPU']=str(Path('C:/data/observer'))
        with self.assertRaisesRegex(ValueError,'POSIX'):expected.stage_check(bad)

    def test_exact_source_bytes_and_geometry_alias_dtype_config_tampers_rejected(self):
        gpu,npu,config=expected.read(GPU),expected.read(NPU),expected.read(CONFIG);source=MODELING.read_text('utf8')
        changes=[lambda x:x['parameter_object_alias_groups'].clear(),lambda x:x['modules'].pop(),
            lambda x:x['parameters'][0].update(dtype='torch.float32'),lambda x:x['parameters'][0].update(shape=[262144,3841])]
        for change in changes:
            bad=copy.deepcopy(gpu);change(bad)
            with self.assertRaises(ValueError):expected.validate_geometry_documents(bad,npu,config,source)
        bad=copy.deepcopy(config);bad['text_config']['num_hidden_layers']=47
        with self.assertRaisesRegex(ValueError,'config'):expected.validate_geometry_documents(gpu,npu,bad,source)
        bad_source=source.replace('return super().forward(input_ids) * self.embed_scale.to(self.weight.dtype)','return super().forward(input_ids)')
        with self.assertRaisesRegex(ValueError,'scaled embedding'):expected.source_boundaries(bad_source)
        with tempfile.TemporaryDirectory() as temporary:
            changed=Path(temporary)/'config.json';changed.write_bytes(CONFIG.read_bytes()+b'\n')
            with self.assertRaisesRegex(ValueError,'bytes differ'):expected.load_geometry(GPU,NPU,changed,MODELING)

    def test_build_verify_roundtrip_and_coordinate_metadata_proof_tamper(self):
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'expected.json';receipt=expected.build(INPUT,path,STAGE,self.stage_sha,GPU,NPU,CONFIG,MODELING)
            actual=expected.verify(path,INPUT,STAGE,self.stage_sha,GPU,NPU,CONFIG,MODELING)
            self.assertEqual(actual,self.document);self.assertEqual(receipt['sha256'],expected.digest(path.read_bytes()))
            self.assertLess(receipt['size_bytes'],2*1024**2)
            with self.assertRaisesRegex(ValueError,'exclusive'):expected.build(INPUT,path,STAGE,self.stage_sha,GPU,NPU,CONFIG,MODELING)
            for mutation in (lambda d:d['attention_mask'][0].__setitem__(0,0),lambda d:d['sample_shape'].__setitem__(0,2),
                lambda d:d['distribution_rows'][0]['history'].__setitem__(0,d['sequence'][0]^1),
                lambda d:d['all_targets'][-1].update(position=160),lambda d:d['prerequisite_hashes_declared'].update(actual_i04_numeric_wrapper_sha256='a'*64)):
                bad=copy.deepcopy(actual);mutation(bad);path.write_text(json.dumps(bad),'utf8')
                with self.assertRaisesRegex(ValueError,'differ'):expected.verify(path,INPUT,STAGE,self.stage_sha,GPU,NPU,CONFIG,MODELING)

    def test_input_length_token_boolean_and_wrong_raw_SHA_fail_before_output(self):
        for field,value in [('prompt',self.input['prompt'][:-1]),('continuation',self.input['continuation']+[1])]:
            doc=copy.deepcopy(self.input);doc[field]=value
            with self.assertRaisesRegex(ValueError,r'128\+32'):expected.derive(doc,expected.INPUT_SHA,self.stage,self.stage_sha,self.geometry)
        doc=copy.deepcopy(self.input);doc['prompt'][0]=True
        with self.assertRaisesRegex(ValueError,'token IDs'):expected.derive(doc,expected.INPUT_SHA,self.stage,self.stage_sha,self.geometry)
        with tempfile.TemporaryDirectory() as temporary:
            source=Path(temporary)/'input.json';source.write_bytes(INPUT.read_bytes()+b'\n');output=Path(temporary)/'output.json'
            with self.assertRaisesRegex(ValueError,'byte SHA'):expected.build(source,output,STAGE,self.stage_sha,GPU,NPU,CONFIG,MODELING)
            self.assertFalse(output.exists())

    def test_builder_fresh_import_is_framework_and_collector_free(self):
        source=Path(expected.__file__)
        code="import importlib.util,sys; s=importlib.util.spec_from_file_location('independent',sys.argv[1]); m=importlib.util.module_from_spec(s);s.loader.exec_module(m);assert not any(n in sys.modules for n in ('torch','torch_npu','numpy','transformers','observer_collectors_v1','observer_common_v1','observer_native_v1'))"
        result=subprocess.run([sys.executable,'-S','-B','-c',code,str(source)],capture_output=True,text=True,timeout=10)
        self.assertEqual(result.returncode,0,result.stderr)


if __name__=='__main__':unittest.main()

"""CPU-only permanent-claim/process-table/owned-cleanup regressions."""
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace
from unittest.mock import patch
import importlib.util
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import tarfile
import time
import unittest

import npu_i04_launcher_v1 as launcher
import npu_i04_operations_v1 as operations


class GuardTests(unittest.TestCase):
    def test_unready_cpu_proof_blocks_packaging_run_probe_worker_before_queries(self):
        args=SimpleNamespace(cpu_prerequisite_sha256='a'*64,i03_prerequisite_sha256=launcher.I03_PREREQUISITE_SHA256)
        with patch.object(launcher,'CPU_PROOF_SHA',None),patch.object(launcher.subprocess,'run') as query,patch.object(launcher,'claim_once') as claim:
            for function in (launcher.source_check,launcher.probe,launcher.worker):
                with self.subTest(function=function.__name__),self.assertRaisesRegex(ValueError,'CPUv3 proof remains unready'):function(args)
            query.assert_not_called();claim.assert_not_called()
        repo=Path(__file__).resolve().parents[5]
        with tempfile.TemporaryDirectory() as folder:
            out=Path(folder)/'not_created'
            with patch.object(operations,'load',return_value=launcher),patch.object(launcher,'CPU_PROOF_SHA',None):
                with self.assertRaisesRegex(ValueError,'CPUv3 proof remains unready'):
                    operations.build(repo,out,Path('/missing/I03'),Path('/missing/CPU'))
            self.assertFalse(out.exists())

    def test_limits_equal_actual_stage_and_reserve_export_and_cleanup(self):
        repo=Path(__file__).resolve().parents[5];stage=launcher.read(repo/launcher.SPEC)
        launcher.limits_check(stage)
        self.assertEqual(launcher.WORK_SECONDS+launcher.METADATA_EXPORT_SECONDS+launcher.CLEANUP_SECONDS,3000)
        stage['limits']['maximum_logical_artifact_transport_bytes_per_direction']=1073741824
        with self.assertRaisesRegex(ValueError,'bounds differ'):launcher.limits_check(stage)

    def test_actual_independent_expected_rebuild_and_capture_argv_binds_both_inputs(self):
        repo=Path(__file__).resolve().parents[5]
        expected=launcher.load_module(repo/launcher.EXPECTED,'i04_test_pure_expected')
        doc=expected.derive(launcher.read(repo/launcher.INPUT),launcher.read(repo/launcher.INPUT_B),
            launcher.PINS[launcher.INPUT],launcher.PINS[launcher.INPUT_B],launcher.STAGE_SHA)
        raw=(json.dumps(doc,indent=2,allow_nan=False)+'\n').encode()
        self.assertEqual(len(raw),1082939);self.assertEqual(hashlib.sha256(raw).hexdigest(),launcher.EXPECTED_JSON_SHA256)
        args=SimpleNamespace(source_root=Path('/new/source'),model=Path('/model'),allocation=Path('/allocation'),
            native_mapping=Path('/map'),native_source=Path('/native'),driver_source=Path('/driver'),
            expected_inventory_sha256=launcher.EXPECTED_JSON_SHA256,i03_prerequisite=Path('/proof/i03'),
            i03_prerequisite_sha256=launcher.I03_PREREQUISITE_SHA256)
        argv=launcher.capture_argv(args,Path('/new/expected'),Path('/new/output'))
        self.assertEqual(argv[argv.index('--input-b')+1],str(args.source_root/launcher.INPUT_B))
        self.assertEqual(argv[argv.index('--i03-prerequisite-sha256')+1],launcher.I03_PREREQUISITE_SHA256)
        self.assertEqual(argv[argv.index('--device')+1],'npu:0')

    def test_real_reviewed_source_pins_match_original_bytes(self):
        repo=Path(__file__).resolve().parents[5]
        for name,digest in launcher.PINS.items():
            self.assertEqual(launcher.sha(repo/name),digest,name)
    def test_permanent_claim_concurrent_and_after_failure(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root/'claims').mkdir()
            with ThreadPoolExecutor(max_workers=8) as pool:
                results = list(pool.map(lambda n:launcher.claim_once(root,{'fixture':n}),range(8)))
            self.assertEqual(sum(result is not None for result in results),1)
            chosen=next(result for result in results if result is not None)
            raw=(chosen/'claim.json').read_bytes()
            self.assertIsNone(launcher.claim_once(root,{'retry':True}))
            self.assertEqual((chosen/'claim.json').read_bytes(),raw)
    def test_i04_claim_preserves_old_i03_claim_and_capture_bytes(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);old=root/'claims'/('npu-i03-'+launcher.ORIGINAL_UUID);old.mkdir(parents=True)
            sentinel=old/'capture-receipt.json';sentinel.write_bytes(b'{"historical_I01":"unchanged"}\n')
            before=sentinel.read_bytes();claim=launcher.claim_once(root,{'task':'I04','fixture':True})
            self.assertEqual(claim.name,'npu-i04-'+launcher.ORIGINAL_UUID)
            self.assertNotEqual(claim,old);self.assertEqual(sentinel.read_bytes(),before)
            self.assertIsNone(launcher.claim_once(root,{'retry':True}))
    def test_failed_i03_proof_stops_before_claim_or_process_query(self):
        args=SimpleNamespace(task_root=Path('/synthetic/new-I04'))
        with patch.object(launcher.sys,'platform','linux'),patch.dict(launcher.os.environ,{'PYTHONHASHSEED':'0'}),\
             patch.object(launcher,'source_check',side_effect=ValueError('actual I03 proof not admitted')),\
             patch.object(launcher,'claim_once') as claim,patch.object(launcher.subprocess,'run') as query:
            with self.assertRaisesRegex(ValueError,'I03 proof not admitted'):launcher.run(args)
            claim.assert_not_called();query.assert_not_called()
    def test_failed_popen_spends_operations_start_without_native_claim(self):
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder);task=base/operations.NAME;source=task/'source';source.mkdir(parents=True)
            python=base/'venv/bin/python';python.parent.mkdir(parents=True);python.write_bytes(b'CPU fixture only')
            module=SimpleNamespace(argv_copy=lambda args:[str(python),'fixture'],CPU_PROOF_SHA='a'*64)
            args=SimpleNamespace(task_root=task,source_root=source)
            with patch.object(operations,'validate',return_value=(module,args,{})),patch.object(operations.subprocess,'Popen',side_effect=OSError('synthetic startup failure')) as popen:
                with self.assertRaisesRegex(OSError,'startup failure'):operations.start(base,'b'*64)
                intent=task/'launch-once.json';raw=intent.read_bytes()
                first=next((task/'runs').iterdir());first.rename(first.with_name(first.name+'-preserved'))
                with self.assertRaises(FileExistsError):operations.start(base,'b'*64)
                self.assertEqual(popen.call_count,1);self.assertEqual(intent.read_bytes(),raw)
                self.assertFalse((task/'claims').exists())
    def test_owned_stop_refuses_reused_pid_without_any_signal(self):
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder);task=base/operations.NAME;run=task/'runs/fixture';run.mkdir(parents=True)
            receipt=run/'start-receipt.json';operations.put(receipt,{'pid':12345,'starttime':111})
            helper=task/'source'/operations.HELPER;helper.parent.mkdir(parents=True)
            helper.write_bytes(Path(__file__).with_name('npu_three_repeat_launcher_v4.py').read_bytes())
            fake=SimpleNamespace(proc_table=lambda:{12345:{'start':222,'state':'S'}})
            with patch.object(operations,'load',return_value=fake),patch.object(operations.os,'kill') as kill:
                result=operations.stop_owned(base,receipt,operations.sha(receipt))
            self.assertEqual(result['status'],'recorded_launcher_not_running');kill.assert_not_called()
    def test_process_section_empty_busy_and_unknown_fail_closed(self):
        empty=(''.join('| %d Ascend910 | OK |\n'%b for b in (0,1,3,4))+'| NPU Chip | Process id | Process name |\n'+''.join('| No running processes found in NPU %d |\n'%b for b in (0,1,3,4))).encode()
        self.assertEqual(launcher.process_gate(empty)['status'],'explicitly_empty')
        bads=[b'not an inventory',b'| NPU Chip | Process id | Name |\n',
              b'| NPU Chip | Process id | Name |\n| 0 0 | 123 | python |\n',
              b'| NPU Chip | Process id | Name |\n| 0 0 | 123 | python |\n'+empty,
              b'| NPU Chip | Process id | Name |\n| 0 0 | unknown | python |\n'+empty,
              b'| NPU | Chip | Process id | Name |\n| 0 | 0 | 123 | python |\n'+empty]
        for raw in bads:
            with self.subTest(raw=raw):
                with self.assertRaises(ValueError):launcher.process_gate(raw)
        with self.assertRaisesRegex(ValueError,'every observed board'):
            launcher.process_gate(b'| 2 Ascend910 | OK |\n'+empty)
        with self.assertRaisesRegex(ValueError,'duplicate empty-board'):
            launcher.process_gate(empty+b'| No running processes found in NPU 0 |\n')
    def test_actual_recorded_readiness_format_and_sha(self):
        path=Path(__file__).with_name('i01-readiness-20261106-a-npu-smi.stdout')
        self.assertEqual(launcher.sha(path),'18df4690bf3af9688092acb6a23debb2fae8311a44721cbbabc9dc64d7d10cb6')
        observed=launcher.process_gate(path.read_bytes())
        self.assertEqual(observed['explicitly_empty_board_ids'],[0,1,3,4])
    def test_cli_resolved_source_hash_rejects_changed_bytes(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'npu-smi';path.write_bytes(b'#!/bin/sh\nexit 0\n')
            before=launcher.smi_identity(path,launcher.sha(path))
            self.assertEqual(before['first_four_bytes_hex'],'23212f62')
            path.write_bytes(b'#!/bin/sh\nexit 1\n')
            with self.assertRaisesRegex(ValueError,'real bytes differ'):launcher.smi_identity(path,before['sha256'])
    def test_frozen_source_bytes_and_duplicate_json_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'source.py';path.write_bytes(b'# original\n')
            frozen={str(path):launcher.sha(path)};launcher.assert_frozen(frozen)
            path.write_bytes(b'# changed\n')
            with self.assertRaisesRegex(ValueError,'frozen source'):launcher.assert_frozen(frozen)
            path.write_text('{"task":1,"task":2}')
            with self.assertRaisesRegex(ValueError,'duplicate JSON'):launcher.read(path)
    def test_storage_rejects_links(self):
        if os.name!='posix':self.skipTest('POSIX link fixture')
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);source=root/'source';source.mkdir();(source/'data').write_bytes(b'123')
            self.assertEqual(launcher.tree_bytes(root),3)
            (source/'link').symlink_to(source/'data')
            with self.assertRaisesRegex(ValueError,'symlink'):launcher.tree_bytes(root)


class StagingTests(unittest.TestCase):
    def test_package_relative_portable_paths_resolve_before_raw_ref_copy(self):
        # Path plumbing only: the proof gate is an explicit CPU-only stub.
        # It deliberately returns resolved paths, as the real pure gates do.
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);code=root/operations.LAUNCHER;code.parent.mkdir(parents=True);code.write_bytes(b'# fixture only\n')
            for label in ('i03','cpu'):
                proof=root/label/'proof';proof.mkdir(parents=True);(proof/'source.json').write_bytes(b'{}\n')
                (root/label/'prerequisite.json').write_bytes(b'{"synthetic_path_fixture":true}\n')
            def validate(path,digest):
                self.assertTrue(path.is_absolute());original=path.parent/'proof/source.json'
                return {'refs':{'synthetic':{'path':str(original.resolve()),'sha256':operations.sha(original)}}}
            fake=SimpleNamespace(CPU_PROOF_SHA='a'*64,proof_ready=lambda args:None,PINS={},
                PREREQUISITE='i03-fixture',CPU_PREREQUISITE='cpu-fixture',load_module=lambda *args:SimpleNamespace(prerequisite=validate))
            previous=Path.cwd()
            try:
                os.chdir(root)
                with patch.object(operations,'load',return_value=fake):
                    result=operations.build(root,root/'new-package',Path('i03/prerequisite.json'),Path('cpu/prerequisite.json'))
            finally:os.chdir(previous)
            self.assertEqual(result['native_executions_started'],0)
            with tarfile.open(result['archive'],'r:gz') as package:
                self.assertEqual(package.extractfile(operations.NAME+'/source/prerequisites/cpu/proof/source.json').read(),b'{}\n')

    def test_file_ancestor_collision_rejected_before_staging(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);data=b'# code\n';names=['a.py','a.py/b.py']
            doc={'schema_version':1,'task_id':operations.TASK_ID,'files':{n:{'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data),'kind':'code'} for n in names}}
            raw=json.dumps(doc).encode();archive=root/'source.tar'
            with tarfile.open(archive,'w') as package:
                for name,content in [(operations.NAME+'/source-manifest.json',raw),*[(operations.NAME+'/source/'+n,data) for n in names]]:
                    member=tarfile.TarInfo(name);member.size=len(content);package.addfile(member,io.BytesIO(content))
            with self.assertRaisesRegex(ValueError,'ancestor collision'):operations.stage_archive(root,archive,operations.sha(archive),hashlib.sha256(raw).hexdigest())
            self.assertFalse((root/operations.NAME).exists())
    def test_large_metadata_allowed_but_same_bytes_as_code_rejected_before_write(self):
        for kind,suffix in [('metadata','.json'),('code','.py')]:
            with self.subTest(kind=kind),tempfile.TemporaryDirectory() as folder:
                root=Path(folder);name='inventory'+suffix;data=b' '*1082939
                doc={'schema_version':1,'task_id':operations.TASK_ID,'files':{name:{'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data),'kind':kind}}}
                raw=json.dumps(doc).encode();archive=root/'source.tar'
                with tarfile.open(archive,'w') as package:
                    for member_name,content in [(operations.NAME+'/source-manifest.json',raw),(operations.NAME+'/source/'+name,data)]:
                        member=tarfile.TarInfo(member_name);member.size=len(content);package.addfile(member,io.BytesIO(content))
                if kind=='metadata':self.assertEqual(operations.stage_archive(root,archive,operations.sha(archive),hashlib.sha256(raw).hexdigest())['source_files'],1)
                else:
                    with self.assertRaisesRegex(ValueError,'classification or bytes'):operations.stage_archive(root,archive,operations.sha(archive),hashlib.sha256(raw).hexdigest())
                    self.assertFalse((root/operations.NAME).exists())

    def archive(self,root,bad=None):
        source=b'# synthetic staging fixture only\n';relative='fixture.py'
        document={'schema_version':1,'task_id':operations.TASK_ID,'files':{relative:{'sha256':hashlib.sha256(source).hexdigest(),'size_bytes':len(source),'kind':'code'}}}
        raw=(json.dumps(document,indent=2)+'\n').encode();archive=root/'source.tar'
        with tarfile.open(archive,'w') as tf:
            for name,data in [(operations.NAME+'/source-manifest.json',raw),(operations.NAME+'/source/'+relative,source)]:
                member=tarfile.TarInfo('../escape' if bad=='escape' and name.endswith(relative) else name);member.size=len(data)
                if bad=='symlink' and name.endswith(relative):member.type=tarfile.SYMTYPE;member.linkname='/synthetic/unrelated';member.size=0
                tf.addfile(member,io.BytesIO(data))
        return archive,operations.sha(archive),hashlib.sha256(raw).hexdigest()
    def test_verified_new_staging_preserves_history_and_never_overwrites(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);old=root/'i01-cacheoff-20261107';old.mkdir();sentinel=old/'receipt.json';sentinel.write_bytes(b'old-I01-bytes')
            archive,digest,manifest=self.archive(root);result=operations.stage_archive(root,archive,digest,manifest)
            self.assertEqual(result['source_files'],1);self.assertIs(result['native_model_started'],False)
            operations.stage_archive(root,archive,digest,manifest)
            target=root/operations.NAME/'source/fixture.py';target.write_bytes(b'changed fixture')
            with self.assertRaisesRegex(ValueError,'never overwritten'):operations.stage_archive(root,archive,digest,manifest)
            self.assertEqual(target.read_bytes(),b'changed fixture');self.assertEqual(sentinel.read_bytes(),b'old-I01-bytes')
    def test_unsafe_or_link_archive_rejected_before_staging(self):
        for bad in ('escape','symlink'):
            with self.subTest(bad=bad),tempfile.TemporaryDirectory() as folder:
                root=Path(folder);archive,digest,manifest=self.archive(root,bad)
                with self.assertRaises(ValueError):operations.stage_archive(root,archive,digest,manifest)
                self.assertFalse((root/operations.NAME).exists())


@unittest.skipUnless(sys.platform.startswith('linux'),'Linux subreaper fixtures')
class CleanupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path=Path(__file__).with_name('npu_three_repeat_launcher_v4.py')
        spec=importlib.util.spec_from_file_location('i01_test_reviewed_helpers',path)
        cls.helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(cls.helper)
        if launcher.sha(path)!=launcher.PINS[launcher.HELPER]:raise AssertionError('reviewed cleanup helper changed')
        launcher.subreaper()
    def fixture(self, exit_leader):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        root=Path(temp.name);(root/'source').mkdir()
        pidfile=root/'grandchild.pid'
        grandchild="import os,signal,time,pathlib;os.setsid();signal.signal(signal.SIGTERM,signal.SIG_IGN);pathlib.Path("+repr(str(pidfile))+").write_text(str(os.getpid()));time.sleep(30)"
        leader="import subprocess,sys,time;subprocess.Popen([sys.executable,'-c',"+repr(grandchild)+"]);time.sleep("+('0.3' if exit_leader else '30')+")"
        return root,pidfile,[sys.executable,'-B','-c',leader]
    def assert_gone(self,pidfile):
        self.assertTrue(pidfile.exists());pid=int(pidfile.read_text())
        with self.assertRaises(ProcessLookupError):os.kill(pid,0)
        self.assertEqual(self.helper.descendants(),{})
    def test_timeout_reaps_session_escaping_term_resistant_child(self):
        root,pidfile,argv=self.fixture(False)
        with self.assertRaises(TimeoutError):launcher.bounded(self.helper,argv,root/'stdout',root/'stderr',time.monotonic()+.7,root)
        self.assert_gone(pidfile)
    def test_leader_success_with_leftover_child_is_failure_and_reaped(self):
        root,pidfile,argv=self.fixture(True)
        with self.assertRaisesRegex(ValueError,'unexpected owned descendant'):
            launcher.bounded(self.helper,argv,root/'stdout',root/'stderr',time.monotonic()+3,root)
        self.assert_gone(pidfile)
    def test_successful_cpu_worker_has_no_remaining_child(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'source').mkdir()
            code=launcher.bounded(self.helper,[sys.executable,'-B','-c','print("fixture")'],root/'stdout',root/'stderr',time.monotonic()+3,root)
            self.assertEqual(code,0);self.assertEqual(self.helper.descendants(),{})


if __name__=='__main__':unittest.main()

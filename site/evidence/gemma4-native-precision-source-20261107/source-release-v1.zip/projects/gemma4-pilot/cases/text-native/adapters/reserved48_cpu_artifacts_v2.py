"""Independent schema2/progress1 admission for reserved48 selected native BF16.

The source's all-target scalars are admitted as source evidence plus coordinate,
bit-scalar/formula and digest consistency. Only retained full-vocabulary rows can
be independently normalized afterwards. Newly written FP64 matrices are CPU
artifacts, never original GPU/NPU arrays. No Torch/model/device API is imported.
Actual stage/proof/budget/lifecycle/source-map gates deliberately remain None.
"""
import argparse
import hashlib
import importlib
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import struct
import sys
import time

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]
SCRIPTS = REPO / 'skills/precision-compare/scripts'
TASK = 'gemma4-reserved48-i05-q01-v1'
MANIFEST_SHA = '10f6b1a6976507e1af65706ddd4bb61d9276c43ae443b2a6852935e2967dca37'
VOCABULARY, CHUNK_ROWS = 262144, 32
MODES, BINS = ('full', 'token', 'chunk'), (128, 512, 2048, 8192)
HEX = re.compile(r'^[a-f0-9]{64}$')
# Actual activation is externally frozen only after the real source and receipts exist.
GATES = {key: None for key in ('stage_sha256', 'expected_inventory_sha256', 'budget_sha256',
    'native_budget_sha256', 'cpu_prerequisite_sha256', 'cpu_prerequisite_checker_sha256',
    'native_prerequisite_sha256', 'native_prerequisite_checker_sha256', 'expected_builder_sha256',
    'native_endpoint_schema_reviewed')}
SOURCE_PINS = {side: {name: None for name in ('collector', 'common', 'lifecycle', 'contract', 'expected')}
               for side in ('GPU', 'NPU')}
ENDPOINT_PINS = {side: {str(P): {name: None for name in ('source_map', 'receipt', 'controller', 'prepared_config')}
                      for P in BINS} for side in ('GPU', 'NPU')}
COVERAGE_STATES = ('completed', 'failed', 'unstarted', 'blocked', 'running')
SHARED = {'artifact_io': '0260cd5ee1fd4e9d37e39bfd79efa9e663a1d48cb75b5adb31b84af9e1edbf39',
          'inference_capture': '5d388e846249d7fd74df1b15036f8a371e3267ada1b2fb0408bc51345ffad19c',
          'compare_distributions': '6abc2eb0a741d554127911de9845d16e0d40f3f7759c42c172eae4907bbf8fc0',
          'score_metrics': 'f645a0092bb97229380c5da6302316978324baf38579476f980bb63da2d6a7da',
          'conditions': 'e012c025395f2f0474f0b35074d8417ec5a217f3659f82218de0f5d05068036d'}
DERIVATION = 'NEW common-CPU NumPy float64 log_softmax from original selected native BF16 rows'
SOURCE_LSE_ORIGIN = 'raw_max - shared_FP64_logprob_at_raw_argmax'
ATOL = 1e-12  # Evidence reconstruction diagnostic, never model acceptance.


def require(ok, message):
    if not ok: raise ValueError(message)


def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def parse(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate JSON key'); result[key] = value
        return result
    def reject(value): raise ValueError('nonfinite JSON token ' + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=reject)


def load(path): return parse(Path(path).read_bytes())


def sha(path, tick=lambda: None):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b''): tick(); digest.update(block)
    return digest.hexdigest()


def ref(path):
    path = Path(path); require(path.is_file() and not path.is_symlink(), 'regular file required')
    return {'path': str(path.resolve()), 'sha256': sha(path), 'size_bytes': path.stat().st_size}


def put(path, document):
    raw = (json.dumps(document, indent=2, allow_nan=False) + '\n').encode()
    require(len(raw) <= 16 * 1024**2, 'metadata exceeds16MiB')
    with Path(path).open('xb') as stream: stream.write(raw)


def safe_relative(name):
    require(isinstance(name, str) and name and not PurePosixPath(name).is_absolute() and str(PurePosixPath(name)) == name and
            '\\' not in name and all(part not in ('', '.', '..') for part in name.split('/')), 'canonical relative path required')
    return PurePosixPath(name)


def origin(name):
    require(isinstance(name, str) and name.startswith('/') and str(PurePosixPath(name)) == name and
            '\\' not in name and '..' not in PurePosixPath(name).parts, 'original absolute POSIX source path required')
    return name


def child(parent, name): return str(PurePosixPath(origin(parent)).joinpath(safe_relative(name)))


def libraries():
    """Reuse the owning tool interfaces; no collector math or framework import."""
    for name, digest in SHARED.items(): require(sha(SCRIPTS / (name + '.py')) == digest, 'shared tool bytes differ: ' + name)
    sys.path.insert(0, str(SCRIPTS)); modules = {name: importlib.import_module(name) for name in SHARED}
    for name, module in modules.items(): require(Path(module.__file__).resolve() == (SCRIPTS / (name + '.py')).resolve(), 'shared import path differs')
    import numpy as np
    require(not any(name in sys.modules for name in ('torch', 'torch_npu', 'transformers')), 'CPU artifact analysis imported a framework')
    return np, modules


class Audit:
    def __init__(self, seconds):
        require(type(seconds) in (int, float) and math.isfinite(seconds) and seconds > 0, 'finite CPU deadline required')
        self.deadline = time.monotonic() + seconds; self.checked = {}; self.originals = {}; self.large = set()

    def tick(self):
        if time.monotonic() >= self.deadline: raise TimeoutError('reserved48 CPU artifact deadline')

    def file(self, path, digest, size=None, large=False, force=False):
        self.tick(); path = Path(path)
        require(path.is_file() and not path.is_symlink() and isinstance(digest, str) and HEX.fullmatch(digest), 'regular frozen source/SHA required')
        resolved = str(path.resolve(strict=True)); actual_size = path.stat().st_size
        require(size is None or type(size) is int and size == actual_size, 'source byte count differs')
        if force or resolved not in self.checked:
            actual = sha(path, self.tick); require(actual == digest, 'source byte SHA differs: ' + str(path))
            require(resolved not in self.checked or self.checked[resolved] == (actual, actual_size), 'source changed during CPU analysis')
            self.checked[resolved] = (actual, actual_size)
        require(self.checked[resolved] == (digest, actual_size), 'conflicting source aliases')
        if large: self.large.add(resolved)
        return Path(resolved)

    def finish(self):
        for path, (digest, size) in list(self.checked.items()): self.file(path, digest, size, force=True)


class Endpoint:
    """Task-owned map geometry; no old160-row admission schema is reused."""
    def __init__(self, audit, info, backend, prompt_bin):
        self.audit, self.backend, self.prompt_bin = audit, backend, prompt_bin
        mapping = info['source_map']; self.path = audit.file(mapping['path'], mapping['sha256'])
        self.document = load(self.path); self.files = self.document['files']; self.info = info
        require(self.document.get('schema_version') == 1 and self.document.get('request') == {
            'task': 'RESERVED48', 'backend': backend, 'prompt_bin': prompt_bin,
            'outer_receipt': origin(info['receipt']['source_path'])}, 'new reserved48 endpoint request schema differs')
        self.root = Path(info['retained_root']).resolve(strict=True) if backend == 'NPU' and info.get('retained_root') else None
        require(backend in ('GPU', 'NPU') and prompt_bin in BINS and (backend == 'GPU' or self.root is not None), 'explicit source backend/bin/NPU root required')

    def get(self, name, digest=None, large=False):
        name = origin(name); item = self.files[name]
        require(type(item.get('size')) is int and item['size'] >= 0 and isinstance(item.get('sha256'), str) and
                HEX.fullmatch(item['sha256']) and (digest is None or digest == item['sha256']), 'source-map size/SHA differs')
        if item.get('retained_at_source') is True:
            require(self.backend == 'NPU' and large and self.root is not None and 'path' not in item and
                    PurePosixPath(name).name == 'selected-native-logits.safetensors', 'only explicit original NPU selected BF16 may remain at source')
            path = Path(name); require(path.is_relative_to(self.root) and path.resolve(strict=True).is_relative_to(self.root), 'retained source escapes declared root')
        else:
            relative = safe_relative(item['path']); path = self.path.parent.joinpath(*relative.parts)
            require(path.resolve(strict=True).is_relative_to(self.path.parent.resolve()), 'copied source escapes bundle')
            current = path
            while current != self.path.parent:
                require(not current.is_symlink(), 'copied source ancestor link'); current = current.parent
        actual = self.audit.file(path, item['sha256'], item['size'], large)
        self.audit.originals[(self.backend, self.prompt_bin, name)] = {'path': str(actual), 'sha256': item['sha256'], 'size_bytes': item['size']}
        return actual

    def json(self, name, digest=None):
        path = self.get(name, digest); require(path.stat().st_size <= 16 * 1024**2, 'source metadata exceeds16MiB'); return load(path)

    def bound_ref(self, value, large=False):
        require(set(value) == {'path', 'sha256', 'size_bytes'}, 'original file reference schema differs')
        path = self.get(value['path'], value['sha256'], large)
        require(path.stat().st_size == value['size_bytes'], 'original file reference size differs'); return path


def expected_rows(document, prompt_bin):
    require(document['task'] == TASK and document['manifest_sha256'] == MANIFEST_SHA and len(document['samples']) == 48,
            'independent complete48-input identity differs')
    rows = [value for value in document['samples'] if value['prompt_length'] == prompt_bin]
    require(len(rows) == 12 and len({value['sample'] for value in rows}) == 12, 'exact twelve distinct inputs per bin required')
    return rows


def bf16_scalar(word):
    require(type(word) is int and 0 <= word <= 65535, 'original BF16 scalar word required')
    value = struct.unpack('<f', struct.pack('<I', word << 16))[0]
    require(math.isfinite(value), 'source BF16 scalar is nonfinite'); return value


def admit_source_scalars(row, targets_doc, digest_doc, selection_doc, summary, vocabulary=VOCABULARY):
    """Admit all original scalars without pretending absent vectors can be replayed."""
    sequence, length, positions = row['input_ids'], row['sequence_length'], row['distribution_positions']
    scores, digests = targets_doc['scores'], digest_doc['rows']
    require(len(sequence) == length and len(scores) == length - 1 and len(digests) == length and len(positions) == 47,
            'complete causal target/raw digest/selected inventory required')
    require(targets_doc['input_sha256'] == row['input_sha256'] and targets_doc['sample'] == row['sample'] and
            targets_doc['mode'] == summary['mode'] and targets_doc['task'] == TASK and
            digest_doc['full_raw_rows_retained'] is False and digest_doc['all_valid_rows_checked_finite'] == length and
            digest_doc['unscored_finite_last_position'] == length - 1, 'source all-valid-finite evidence identity differs')
    for p, item in enumerate(digests):
        require(type(item.get('prediction_position')) is int and type(item.get('native_data_bytes')) is int and
                item == {'prediction_position': p, 'sha256': item.get('sha256'), 'native_data_bytes': vocabulary * 2} and
                isinstance(item['sha256'], str) and HEX.fullmatch(item['sha256']), 'source raw row digest inventory differs')
    for p, score in enumerate(scores):
        require(score['sample'] == row['sample'] and type(score['position']) is int and score['position'] == p + 1 and
                type(score['prediction_position']) is int and score['prediction_position'] == p and score['token'] == sequence[p + 1] and
                type(score['token']) is int and
                score['raw_row_sha256'] == digests[p]['sha256'] and score['source_logsumexp_origin'] == SOURCE_LSE_ORIGIN,
                'all-target causal coordinate/token/digest differs')
        native, maximum = bf16_scalar(score['raw_target_bf16_u16']), bf16_scalar(score['raw_argmax_bf16_u16'])
        lp, normalizer = score['logprob'], score['source_logsumexp']
        require(type(score['raw_target_value']) in (int, float) and score['raw_target_value'] == native and
                type(lp) in (int, float) and math.isfinite(lp) and lp <= 0 and
                type(normalizer) in (int, float) and math.isfinite(normalizer) and
                type(score['raw_argmax_token_lowest_id']) is int and 0 <= score['raw_argmax_token_lowest_id'] < vocabulary and
                native <= maximum and normalizer + ATOL >= maximum and normalizer <= maximum + math.log(vocabulary) + ATOL and
                abs((native - normalizer) - lp) <= ATOL,
                'source scalar/raw-BF16/normalizer formula differs')
    expected_positions = [{'row': i, 'prediction_position': p, 'target_position': p + 1, 'token': sequence[p + 1],
                          'raw_row_sha256': digests[p]['sha256']} for i, p in enumerate(positions)]
    require(selection_doc['sample'] == row['sample'] and selection_doc['mode'] == summary['mode'] and
            selection_doc['shape'] == [47, vocabulary] and selection_doc['original_sequence_native_shape'] == [1, length, vocabulary] and
            selection_doc['positions'] == expected_positions and summary['valid_rows'] == length and summary['targets'] == length - 1 and
            summary['selected_rows'] == 47 and summary['raw_stream_sha256'] == digest_doc['raw_stream_sha256'] and
            HEX.fullmatch(summary['raw_stream_sha256']), 'source selected-row/full stream declaration differs')
    return {'source_target_scores': length - 1, 'source_raw_rows_claimed_finite': length,
        'independently_replayed_selected_rows': 0, 'independent_all_target_normalizers': False,
        'independent_unretained_raw_finite_check': False, 'full_unselected_raw_audit': False,
        'scope': 'Original source evidence plus causal coordinate/BF16 scalar/formula/digest consistency; absent raw vectors cannot be independently normalized'}


def selected_array(path, vocabulary=VOCABULARY):
    """Bound the exact original tensor, then use the owning BF16 Array decoder."""
    np, modules = libraries(); path = Path(path)
    with path.open('rb') as stream:
        prefix = stream.read(8); require(len(prefix) == 8, 'truncated selected native length')
        length = struct.unpack('<Q', prefix)[0]; require(0 < length <= 131072, 'bounded selected native header required')
        header = parse(stream.read(length))
    require(set(header) in ({'logits'}, {'logits', '__metadata__'}) and header['logits'] == {
        'dtype': 'BF16', 'shape': [47, vocabulary], 'data_offsets': [0, 47 * vocabulary * 2]} and
        path.stat().st_size == 8 + length + 47 * vocabulary * 2, 'exact47-row BF16 tensor shape/offset/length required')
    require('__metadata__' not in header or isinstance(header['__metadata__'], dict) and
            all(type(k) is str and type(v) is str for k, v in header['__metadata__'].items()), 'native metadata must contain strings')
    array = modules['artifact_io'].Array(path.parent, {'path': path.name, 'key': 'logits'})
    require(array.bf16 and array.shape == [47, vocabulary], 'owning array reader geometry differs'); return array


def native_row_bytes(array, index, vocabulary=VOCABULARY):
    require(type(index) is int and 0 <= index < 47, 'selected native row index differs')
    with array.path.open('rb') as stream:
        stream.seek(array.offset + index * vocabulary * 2); raw = stream.read(vocabulary * 2)
    require(len(raw) == vocabulary * 2, 'truncated selected native row'); return raw


def derive_selected(path, source_ref, row, selection, scores, destination, audit, vocabulary=VOCABULARY):
    """Create one NEW [47,V] FP64 matrix in at most32-row derivation slabs."""
    np, modules = libraries(); array = selected_array(path, vocabulary)
    destination = Path(destination); require(destination.parent.is_dir() and not destination.exists() and not destination.is_symlink(), 'exclusive CPU matrix output required')
    fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600); os.close(fd)
    mapped = np.lib.format.open_memmap(destination, mode='w+', dtype='<f8', shape=(47, vocabulary))
    maximum, rows = 0.0, []
    try:
        for lo in range(0, 47, CHUNK_ROWS):
            audit.tick(); count = min(CHUNK_ROWS, 47 - lo)
            values = array.read(lo * vocabulary, count * vocabulary).reshape(count, vocabulary)
            require(np.isfinite(values).all(), 'retained selected native row is nonfinite')
            normalized = modules['inference_capture'].derive_logprobs(values, dtype='float64')
            require(normalized.shape == values.shape and np.isfinite(normalized).all(), 'shared matrix derivation differs')
            mapped[lo:lo + count] = normalized
            for relative in range(count):
                index = lo + relative; coordinate = selection['positions'][index]; p = coordinate['prediction_position']; target = scores[p]
                raw = native_row_bytes(array, index, vocabulary); digest = hashlib.sha256(raw).hexdigest()
                require(digest == coordinate['raw_row_sha256'] == target['raw_row_sha256'], 'retained native selected row digest differs')
                token = row['input_ids'][p + 1]; raw_word = struct.unpack_from('<H', raw, token * 2)[0]
                maximum_token = int(np.argmax(values[relative]))
                require(target['raw_argmax_token_lowest_id'] == maximum_token and
                    target['raw_argmax_bf16_u16'] == struct.unpack_from('<H', raw, maximum_token * 2)[0],
                    'retained native argmax/tie-breaking differs from source evidence')
                lp = float(normalized[relative, token]); normalizer = float(np.max(values[relative])) - float(np.max(normalized[relative]))
                delta = abs(lp - target['logprob']); maximum = max(maximum, delta)
                require(raw_word == target['raw_target_bf16_u16'] and delta <= ATOL and
                        abs(normalizer - target['source_logsumexp']) <= ATOL, 'retained full-row rederivation/source scalar mismatch')
                rows.append({'sample': row['sample'], 'position': p, 'history': row['input_ids'][:p + 1],
                    'scores': {'path': str(destination.resolve()), 'row': index},
                    'provenance': {'kind': 'new_common_cpu_artifact', 'derivation': DERIVATION, 'original_native_source': source_ref,
                        'selected_native_row': index, 'native_prediction_position': p, 'raw_row_sha256': digest,
                        'input_sha256': row['input_sha256']}})
            del normalized, values
        mapped.flush()
    finally: mapped._mmap.close()
    result = ref(destination)
    return {'matrix': result, 'positions': rows, 'new_derived_FP64_rows': 47,
        'maximum_selected_target_rederivation_delta': maximum, 'derivation': DERIVATION,
        'original_GPU_or_NPU_FP64_array': False, 'independent_all_target_normalizers': False}


def admit_cache_metadata(value, consumed, enabled, device):
    """Observe logical/physical cache geometry without claiming retained values."""
    if not enabled:
        require(value == {'present': False}, 'cache-off metadata must remain absent'); return
    if consumed == 0:
        require(value == {'present': False, 'logical_tokens': 0}, 'fresh cache prefix must be absent'); return
    require(value.get('present') is True and value['logical_tokens_consumed'] == value['reported_sequence_length'] == consumed and
            isinstance(value.get('class'), str) and len(value['layers']) == 48, 'cached logical prefix/layer inventory differs')
    for index, layer in enumerate(value['layers']):
        full = index % 6 == 5; heads, width = (1, 512) if full else (8, 256)
        require(layer['index'] == index and layer['configured_attention'] == ('full_attention' if full else 'sliding_attention') and
                layer['reported_sequence_length'] == consumed, 'per-layer cache prefix/profile differs')
        for name in ('keys', 'values'):
            tensor = layer[name]; shape = tensor['shape']
            require(len(shape) == 4 and shape[:2] == [1, heads] and shape[-1] == width and type(shape[-2]) is int and
                    0 < shape[-2] <= consumed and tensor['dtype'] == 'torch.bfloat16' and tensor['device'] == device,
                    'cache tensor geometry/dtype/device differs')
            if full: require(shape[-2] == consumed, 'full-attention cache was clipped')
            elif shape[-2] < consumed:
                require(layer['is_sliding'] is True and type(layer['sliding_window']) is int and
                        0 < shape[-2] <= layer['sliding_window'], 'trimmed cache lacks observed sliding provenance')
        require(layer['keys']['shape'] == layer['values']['shape'], 'cache K/V geometry differs')


def admit_observation(endpoint, output, row, mode, baseline, device, baseline_rng):
    prefix = child(output, 'samples/' + row['sample'] + '/' + mode)
    summary = endpoint.json(child(prefix, 'capture-summary.json'))
    scores = endpoint.json(child(prefix, 'source-target-scores.json'))
    digests = endpoint.json(child(prefix, 'native-row-digests.json'))
    selection = endpoint.json(child(prefix, 'selected-row-inventory.json'))
    checked = admit_source_scalars(row, scores, digests, selection, summary)
    native_ref = summary['selected_native']; require(native_ref == selection['native'] and
        native_ref['path'] == child(prefix, 'selected-native-logits.safetensors'), 'original selected native reference differs')
    native = endpoint.bound_ref(native_ref, True)
    invariant = {key: baseline[key] for key in ('model_object_id', 'class', 'config', 'module_training_flags', 'parameters')}
    parameter_sha = hashlib.sha256(canonical(invariant).encode()).hexdigest()
    buffer_sha = hashlib.sha256(canonical(baseline['buffers']).encode()).hexdigest()
    rng = summary['rng_before']
    require(set(rng) == {'python', 'numpy', 'torch_cpu', 'device0'} and all(isinstance(value, dict) and
            not value.get('unavailable') and isinstance(value.get('sha256'), str) and HEX.fullmatch(value['sha256']) for value in rng.values()),
            'complete source RNG observation required')
    if baseline_rng is not None: require(canonical(rng) == canonical(baseline_rng), 'source RNG reset differs across input/mode')
    require(summary['mode'] == mode and summary['sample'] == row['sample'] and
        summary['native_calls'] == {'full': 1, 'token': 33, 'chunk': 34}[mode] and
        summary['parameter_invariant_unchanged'] is True and summary['buffer_metadata_unchanged'] is True and
        summary['parameter_state_before_sha256'] == summary['parameter_state_after_sha256'] == parameter_sha and
        summary['buffer_metadata_before_sha256'] == summary['buffer_metadata_after_sha256'] == buffer_sha and
        canonical(summary['rng_before']) == canonical(summary['rng_after']), 'per-observation source state/RNG evidence differs')
    plans = next(plan for plan in row['modes'] if plan['mode'] == mode)['input_spans_zero_based_half_open']
    events = endpoint.json(child(prefix, 'events.json')); require(len(events) == len(plans), 'source forward count differs')
    for index, (event, (start, end)) in enumerate(zip(events, plans)):
        require(event['call'] == index and event['input_span'] == [start, end] and event['position_span'] == [start, end] and
            event['attention_mask_shape'] == [1, end] and event['attention_mask_values'] == 'all ones from length, including valid token0' and
            event['use_cache'] == (mode != 'full') and event['logits_to_keep'] == 0 and event['native_shape'] == [1, end - start, VOCABULARY] and
            event['input_token_sha256'] == hashlib.sha256(canonical(row['input_ids'][start:end]).encode()).hexdigest(),
            'causal source event/mask/token/position plan differs')
        admit_cache_metadata(event['cache_before'], start, mode != 'full', device)
        admit_cache_metadata(event['cache_after'], end, mode != 'full', device)
    final_cache = endpoint.json(child(prefix, 'final-cache-metadata.json'))
    admit_cache_metadata(final_cache, row['sequence_length'], mode != 'full', device)
    require(canonical(final_cache) == canonical(events[-1]['cache_after']), 'final cache metadata differs from final forward')
    source_path = child(prefix, 'source-target-scores.json'); descriptor = endpoint.files[source_path]
    return {'summary': summary, 'source_scores': scores['scores'], 'selection': selection, 'native_path': native,
            'native_ref': native_ref, 'source_admission': checked, 'output_prefix': prefix, 'rng_before': rng,
            'source_target_ref': {'path': source_path, 'sha256': descriptor['sha256'], 'size_bytes': descriptor['size']}}


def admit_endpoint_base(endpoint, inventory, stage_sha, expected_sha):
    """Validate one new12-input native job before admitting any numeric products.

    The outer lifecycle schema remains gated until that lifecycle exists and is
    independently reviewed. These are explicit new reserved48 fields, never an
    adapter that feeds new data into an old160-row receipt.
    """
    info = endpoint.info; outer_path = origin(info['receipt']['source_path'])
    outer = endpoint.json(outer_path, info['receipt']['sha256']); rows = expected_rows(inventory, endpoint.prompt_bin)
    require(outer['task'] == 'RESERVED48' and outer['task_id'] == TASK and outer['backend'] == endpoint.backend and
            outer['prompt_bin'] == endpoint.prompt_bin and outer['status'] == 'completed' and type(outer['returncode']) is int and
            outer['returncode'] == 0 and outer['timed_out'] is False and outer['native_capture_count'] == outer['model_loads'] == 1 and
            outer['native_forward_calls_total'] == 816 and outer['collector_sha256'] == SOURCE_PINS[endpoint.backend]['collector'],
            'completed new reserved48 native outer receipt required')
    require(outer['stage_spec_source_sha256'] == stage_sha and outer['expected_inventory_source_sha256'] == expected_sha and
            outer['cpu_prerequisite_source_sha256'] == GATES['cpu_prerequisite_sha256'], 'actual native stage/expected/CPU proof binding differs')
    source_hashes = outer['source_sha256']
    require(type(source_hashes) is dict and set(outer['dependency_paths']) == set(source_hashes) and
            len(outer['dependency_paths']) == len(source_hashes), 'native frozen source closure differs')
    for name, digest in source_hashes.items(): endpoint.get(origin(name), digest)
    for digest in SOURCE_PINS[endpoint.backend].values():
        require(digest in source_hashes.values(), 'native source closure lacks reviewed collector/expected/lifecycle')
    claim = str(PurePosixPath(outer_path).parent)
    before = endpoint.json(child(claim, 'sources-before.json')); after = endpoint.json(child(claim, 'sources-after.json'))
    require(canonical(before) == canonical(after) == canonical(source_hashes), 'native source-before/after bytes disagree')
    command = endpoint.json(outer['generic_receipt']['path'], outer['generic_receipt']['sha256'])
    require(command['status'] == 'completed' and command['returncode'] == 0 and command['child_returncode'] == 0 and
            command['argv'] == outer['argv'] and math.isfinite(command['wall_seconds']) and command['wall_seconds'] > 0,
            'immutable generic native command is not completed0')
    argv = command['argv']; require(len(argv) >= 3 and argv[2] == outer['collector_path'], 'direct native collector argv required')
    def flag(name):
        require(argv.count(name) == 1 and argv.index(name) + 1 < len(argv), 'missing/duplicate native flag ' + name)
        return argv[argv.index(name) + 1]
    output = origin(outer['output_dir'])
    require(flag('--backend') == endpoint.backend.lower() and flag('--prompt-bin') == str(endpoint.prompt_bin) and
        flag('--device') == ('cuda:0' if endpoint.backend == 'GPU' else 'npu:0') and flag('--output') == output and
        flag('--stage-spec') == outer['stage_spec_source_path'] and flag('--stage-spec-sha256') == stage_sha and
        flag('--expected-inventory') == outer['expected_inventory_source_path'] and flag('--expected-inventory-sha256') == expected_sha,
        'native argv is detached from actual outer/input/stage coordinates')
    manifest = endpoint.json(child(output, 'artifacts-manifest.json'), outer['artifacts_manifest_sha256'])
    require(manifest['schema_version'] == 1 and manifest['task'] == TASK and type(manifest['files']) is dict, 'new native artifact manifest differs')
    files = manifest['files']; native_names = {'samples/' + row['sample'] + '/' + mode + '/selected-native-logits.safetensors'
        for row in rows for mode in MODES}
    require({name for name in files if name.endswith(('.npy', '.safetensors'))} == native_names and len(native_names) == 36,
            'exact36 selected BF16 matrices required; no full raw/KV/old arrays')
    mapped_output = {name for name in endpoint.files if name.startswith(output + '/')}
    require(mapped_output == {child(output, name) for name in files} | {child(output, name) for name in ('artifacts-manifest.json', 'status.json')},
            'native source-map output inventory has omissions/extras')
    for name, item in files.items():
        safe_relative(name); require(set(item) == {'sha256', 'size_bytes'}, 'native manifest reference schema differs')
        actual = endpoint.get(child(output, name), item['sha256'], name in native_names)
        require(actual.stat().st_size == item['size_bytes'], 'native manifest size differs')
    status = endpoint.json(child(output, 'status.json'))
    expected_targets = 3 * sum(row['sequence_length'] - 1 for row in rows)
    expected_finite = 3 * sum(row['sequence_length'] for row in rows)
    require(status['task'] == TASK and status['status'] == 'completed' and status['backend'] == endpoint.backend.lower() and
        status['prompt_bin'] == endpoint.prompt_bin and status['inputs'] == 12 and status['observations'] == 36 and
        status['native_calls'] == 816 and status['model_loads'] == 1 and status['selected_rows'] == 1692 and
        status['all_target_scores'] == expected_targets and status['all_valid_native_rows'] == expected_finite and
        status['manifest_sha256'] == outer['artifacts_manifest_sha256'] and status['full_raw_retained'] is False and
        status['full_KV_retained'] is False and status['independent_all_target_normalizer_replay'] is False and
        status['Q02_executed'] is False and status['P01_executed'] is False and status['thresholds'] is status['acceptance'] is None,
        'complete source12-input capture status or replay limits differ')
    runtime = endpoint.json(child(output, 'runtime.json'))
    require(runtime['task'] == TASK and runtime['backend'] == endpoint.backend.lower() and runtime['model_loads'] == 1 and
        runtime['prompt_bin'] == endpoint.prompt_bin and runtime['seed'] == 0 and
        runtime['instance_visible_count'] == (1 if endpoint.backend == 'GPU' else 8) and runtime['compute_device_count'] == 1 and
        runtime['tensor_parallel_size'] == 1 and len(runtime['native_observations']) == 36,
        'actual source runtime model/process/backend scope differs')
    identity = runtime['model_identity']; require(identity['model_class'] == 'Gemma4UnifiedForConditionalGeneration' and
        identity['model_type'] == 'gemma4_unified' and identity['parameter_dtypes'] == ['torch.bfloat16'] and identity['actual_attention'] == 'eager',
        'actual unchanged loaded model identity differs')
    require(identity['snapshot_receipt_sha256'] == files['snapshot-verification.json']['sha256'] and
            endpoint.json(child(output, 'snapshot-verification.json'))['status'] == 'verified', 'original official snapshot verification differs')
    baseline = endpoint.json(child(output, 'model-state-before-capture.json'))
    require(canonical(baseline) == canonical(endpoint.json(child(output, 'model-state-after-capture.json'))), 'native loaded model state changed')
    require(all('content_sha256' in item and 'content_probe_gap' not in item for item in baseline['buffers']), 'source complete buffer fingerprints missing')
    policy = endpoint.json(child(output, 'policy-before-load.json'))
    require(canonical(policy) == canonical(endpoint.json(child(output, 'policy-after-load.json'))) ==
            canonical(endpoint.json(child(output, 'policy-after-capture.json'))), 'source backend policy changed')
    sources = endpoint.json(child(output, 'frozen-source-refs.json'))
    for value in sources.values(): endpoint.bound_ref(value)
    for values in runtime['runtime_sources'].values():
        original, copied = values['original'], values['frozen_copy']
        require(original['sha256'] == copied['sha256'] and original['size_bytes'] == copied['size_bytes'], 'runtime original/copy alias differs')
        endpoint.bound_ref(original); endpoint.bound_ref(copied)
    return {'endpoint': endpoint, 'output': output, 'rows': rows, 'runtime': runtime, 'policy': policy, 'outer': outer,
            'baseline': baseline,
            'native_paths': [child(output, name) for name in sorted(native_names)],
            'source_target_count': expected_targets, 'source_finite_row_claim': expected_finite}


def progress_plan(rows):
    """Independently translate the expected inventory, never import a collector."""
    result = [{'sample': row['sample'], 'mode': plan['mode'], 'prompt_length': row['prompt_length'],
               'sequence_length': row['sequence_length'], 'spans': plan['input_spans_zero_based_half_open']}
              for row in rows for plan in row['modes']]
    require(len(result) == 36 and len({(x['sample'], x['mode']) for x in result}) == 36 and
            sum(len(x['spans']) for x in result) == 816, 'independent36-cell/816-call plan required')
    return result


def inspect_progress(raw, rows, backend, require_success=True):
    """An independent state machine; summaries are byte-bound separately below.

    Incomplete/truncated records are rejected, not interpreted as unentered
    cells. A caller collecting failure diagnostics may label that rejection
    unknown. Terminal failures retain their observed ledger without assigning
    the active exception to future cells.
    """
    require(type(raw) is bytes and 0 < len(raw) <= 4 * 1024**2 and raw.endswith(b'\n'),
            'bounded complete JSONL progress required')
    lines = raw.splitlines(); require(2 <= len(lines) <= 4096 and all(0 < len(x) <= 131072 for x in lines),
                                    'bounded complete progress inventory required')
    records = [parse(line) for line in lines]; plan = progress_plan(rows)
    header, terminal = records[0], records[-1]
    require(header['event'] == 'plan' and header['schema_version'] == 1 and header['task'] == TASK and
            header['backend'] == backend.lower() and header['planned_cells'] == plan and
            header['planned_model_loads'] == 1 and header['native_execution_allowed_by_progress'] is False and
            terminal['event'] == 'terminal' and terminal['status'] in ('source_capture_completed', 'source_capture_failed'),
            'exact independent plan and one terminal required')
    states = [{'sample': x['sample'], 'mode': x['mode'], 'state': 'not_entered',
               'forward_attempts': 0, 'forward_returns': 0} for x in plan]
    active = None; next_cell = 0; last_time = -1; summaries = []
    phases = {'before_environment_preflight', 'environment_preflight', 'model_load', 'after_model_load',
              'mode_reset_and_state_checks', 'input_or_cache_preparation', 'native_model_forward_and_synchronize',
              'source_CPU_derivation_and_evidence', 'final_artifact_validation'}
    for index, event in enumerate(records):
        kind = event['event']; elapsed = event['elapsed_monotonic_seconds']
        require(type(event['index']) is int and event['index'] == index and type(event['pid']) is int and
                event['pid'] > 0 and event['pid'] == header['pid'] and type(elapsed) in (int, float) and
                math.isfinite(elapsed) and elapsed >= last_time and isinstance(event['utc'], str) and event['utc'] and
                event['phase'] in phases and (kind != 'terminal' or index == len(records) - 1),
                'ordered same-process finite progress records required')
        last_time = elapsed
        if kind == 'plan': require(index == 0, 'duplicate plan')
        elif kind == 'phase':
            if active is not None: require((event.get('sample'), event.get('mode')) ==
                (active['sample'], active['mode']), 'phase active-cell identity differs')
        elif kind == 'mode_entered':
            require(active is None and next_cell < 36 and (event['sample'], event['mode']) ==
                    (plan[next_cell]['sample'], plan[next_cell]['mode']), 'ordered single mode entry required')
            active = states[next_cell]; active['state'] = 'entered_no_forward_marker'
        elif kind in ('forward_entered', 'forward_returned', 'mode_capture_completed'):
            require(active is not None and (event['sample'], event['mode']) == (active['sample'], active['mode']),
                    'progress observation lacks matching active cell')
            spans = plan[next_cell]['spans']
            if kind == 'forward_entered':
                call = event['call_index']
                require(type(call) is int and call == active['forward_attempts'] == active['forward_returns'] and
                        call < len(spans) and event['input_span'] == spans[call] and
                        event['first_forward_of_cell'] is (call == 0), 'planned serial forward entry differs')
                active['forward_attempts'] += 1; active['state'] = 'forward_entered_return_unobserved'
            elif kind == 'forward_returned':
                call = event['call_index']
                require(type(call) is int and active['forward_attempts'] == call + 1 and active['forward_returns'] == call and
                        event['device_synchronize_returned'] is True, 'matching synchronized return differs')
                active['forward_returns'] += 1; active['state'] = 'forward_returned_capture_incomplete'
            else:
                value = event['summary']
                require(active['forward_attempts'] == active['forward_returns'] == len(spans) and
                        set(value) == {'path', 'sha256', 'size_bytes'} and origin(value['path']) and
                        type(value['size_bytes']) is int and 0 < value['size_bytes'] <= 16 * 1024**2 and
                        isinstance(value['sha256'], str) and HEX.fullmatch(value['sha256']), 'complete source summary reference differs')
                summaries.append({'sample': active['sample'], 'mode': active['mode'], 'source': value})
                active['state'] = 'source_capture_completed_not_independent_admission'; active = None; next_cell += 1
        elif kind != 'terminal': raise ValueError('unknown progress event')
    require(terminal['cell_ledger'] == states and terminal['numerical_admission_performed'] is False and
            terminal['acceptance'] is None, 'terminal ledger or scope conflicts with independently replayed transitions')
    if terminal['status'] == 'source_capture_completed':
        require(active is None and next_cell == 36 and len(summaries) == 36 and
                sum(x['forward_returns'] for x in states) == 816 and terminal['model_loads_observed_by_entry'] == 1,
                'complete36-cell/816-return terminal required')
    else:
        error = terminal['error']
        require(error['classification'] in ('typed_torch_out_of_memory', 'python_host_memory_error', 'bounded_timeout',
                    'runtime_message_mentions_OOM_type_unconfirmed', 'other_exception') and
                error['active_cell_only_no_unstarted_cell_OOM_attribution'] is True and
                error['independent_device_allocation_query_performed'] is False and
                type(error['typed_torch_OOM']) is bool and type(error['runtime_message_mentions_OOM']) is bool and
                error['typed_torch_OOM'] is (error['classification'] == 'typed_torch_out_of_memory') and
                isinstance(error['type'], str) and isinstance(error['message'], str) and len(error['message']) <= 32768 and
                isinstance(error['traceback'], str) and len(error['traceback']) <= 65536,
                'failure classification/attribution limits differ')
    require(not require_success or terminal['status'] == 'source_capture_completed', 'failed progress is not numeric input')
    return {'status': terminal['status'], 'cell_ledger': states,
        'forward_attempts': sum(x['forward_attempts'] for x in states),
        'forward_returns': sum(x['forward_returns'] for x in states),
        'not_entered_cells': sum(x['state'] == 'not_entered' for x in states),
        'progress_sha256': hashlib.sha256(raw).hexdigest(), 'independent_numeric_admission': False,
        'native_executions_started_by_validation': 0, 'summary_events': summaries,
        'source_failure': terminal.get('error')}


def inspect_native_stdout(raw, backend, status, progress_ref, runtime):
    """Only the known NPU driver prefix plus one exact final status is allowed."""
    require(type(raw) is bytes and len(raw) <= 16 * 1024**2, 'bounded original stdout required')
    lines = raw.splitlines(); require(len(lines) == (1 if backend == 'GPU' else 2), 'strict native stdout record inventory differs')
    records = [parse(x) for x in lines]
    require(records[-1] == dict(status, progress=progress_ref), 'native stdout/status/progress SHA binding differs')
    event = None
    if backend == 'NPU':
        event = records[0]
        require(set(event) == {'event', 'observation'} and event['event'] == 'driver_version_api_observation', 'unknown native stdout prefix')
        api = event['observation']
        require(api.get('call') == "torch_npu.utils.get_cann_version('DRIVER')" and api.get('status') in ('returned', 'error'),
                'known original driver observation required')
        if api['status'] == 'returned':
            require(set(api) == {'call', 'status', 'value', 'parsed_version'} and isinstance(api['value'], str) and
                    api['value'].strip() == api['parsed_version'] == '25.5.2', 'driver API returned version differs')
        else:
            require(set(api) in ({'call', 'status', 'error_type', 'error', 'traceback'},
                    {'call', 'status', 'value', 'error_type', 'error', 'traceback'}) and
                    all(isinstance(api[k], str) for k in ('error_type', 'error', 'traceback')) and api['error_type'] and api['traceback'],
                    'original driver API error must be retained')
        require(api == runtime['driver_version_provenance']['api'], 'driver prefix detached from original runtime')
    return {'record_count': len(records), 'driver_api_event': event, 'raw_bytes_rewritten': False}


def endpoint_ready(backend, prompt_bin, completed=True):
    require(backend in SOURCE_PINS and prompt_bin in BINS, 'explicit backend/bin required')
    names = ('source_map', 'receipt', 'controller', 'prepared_config') if completed else ('controller',)
    require(all(isinstance(ENDPOINT_PINS[backend][str(prompt_bin)][k], str) and
                HEX.fullmatch(ENDPOINT_PINS[backend][str(prompt_bin)][k]) for k in names), 'actual endpoint pins remain unready')
    if completed: require(all(isinstance(x, str) and HEX.fullmatch(x) for x in SOURCE_PINS[backend].values()),
                          'actual rendered source pins remain unready')


def admit_endpoint(endpoint, inventory, stage_sha, expected_sha):
    endpoint_ready(endpoint.backend, endpoint.prompt_bin)
    pins = ENDPOINT_PINS[endpoint.backend][str(endpoint.prompt_bin)]
    require(endpoint.info['source_map']['sha256'] == pins['source_map'] and endpoint.info['receipt']['sha256'] == pins['receipt'],
            'actual endpoint external map/receipt SHA differs')
    result = admit_endpoint_base(endpoint, inventory, stage_sha, expected_sha)
    outer, output, rows, runtime = result['outer'], result['output'], result['rows'], result['runtime']
    claim = str(PurePosixPath(endpoint.info['receipt']['source_path']).parent)
    require(outer['schema_version'] == 1 and outer['input_manifest_sha256'] == MANIFEST_SHA and
            outer['native_capture_schema_version'] == 2 and outer['progress_schema_version'] == 1 and
            outer['native_prerequisite_source_sha256'] == GATES['native_prerequisite_sha256'] and
            outer['thresholds'] is outer['acceptance'] is None and outer['full_core_complete'] is False,
            'schema2/progress1/actual prerequisite scope differs')
    controller_path = child(claim, 'controller-receipt.json')
    require(endpoint.files[controller_path]['sha256'] == pins['controller'], 'actual controller external SHA differs')
    controller = endpoint.json(controller_path, pins['controller'])
    require(controller['task'] == 'RESERVED48' and controller['backend'] == endpoint.backend and
            controller['prompt_bin'] == endpoint.prompt_bin and controller['status'] == 'completed' and
            controller['returncode'] == 0 and controller['timed_out'] is False and
            controller['timed_out_scope'] == 'outer_controller_only' and controller['remaining_descendants'] == [] and
            controller['automatic_retry'] is False and controller['capture_receipt'] == {
                'path': origin(endpoint.info['receipt']['source_path']), 'sha256': pins['receipt'],
                'size_bytes': endpoint.files[endpoint.info['receipt']['source_path']]['size']}, 'clean terminal original controller required')
    command = endpoint.json(outer['generic_receipt']['path'], outer['generic_receipt']['sha256'])
    require(controller['native_generic']['source'] == outer['generic_receipt'] and
            controller['native_generic']['status'] == 'completed' and controller['native_generic']['returncode'] == 0 and
            controller['native_generic']['child_returncode'] == 0 and controller['native_generic']['generic_deadline_reached'] is False and
            controller['timeout_observations'] == {'outer_controller_deadline': False,
                'original_generic_native_deadline': False, 'source_reported_timeout': None}, 'outer/generic/source timeout observations differ')
    pointer = endpoint.json(child(claim, 'generic-receipt-reference.json'))
    require(pointer['source'] == outer['generic_receipt'] and pointer['status'] == command['status'] and
            pointer['returncode'] == command['returncode'] and pointer['child_returncode'] == command['child_returncode'] and
            pointer['timeout_scope'] == 'original_generic_native_process_only', 'original generic pointer detached')
    claim_doc = endpoint.json(child(claim, 'claim.json')); config_ref = claim_doc['config']
    require(config_ref['sha256'] == pins['prepared_config'], 'actual prepared config external SHA differs')
    config = endpoint.json(config_ref['path'], config_ref['sha256']); endpoint.bound_ref(config_ref)
    require(config['task'] == claim_doc['task'] == TASK and config['backend'] == claim_doc['backend'] == endpoint.backend and
            config['prompt_bin'] == claim_doc['prompt_bin'] == endpoint.prompt_bin and
            config['reviewed_source_sha256'] == {key: SOURCE_PINS[endpoint.backend][key] for key in ('collector', 'common', 'lifecycle')} and
            config['expected_builder']['sha256'] == SOURCE_PINS[endpoint.backend]['expected'] == GATES['expected_builder_sha256'] and
            config['stage_spec']['sha256'] == stage_sha and config['budget']['sha256'] == GATES['native_budget_sha256'] and
            config['expected_inventory']['sha256'] == expected_sha and config['prerequisite']['sha256'] == GATES['native_prerequisite_sha256'] and
            config['model_loads'] == config['native_launches'] == 1 and config['automatic_retry'] is False and
            claim_doc['permanent_claim'] is True and claim_doc['automatic_retry'] is False and
            claim_doc['native_launches'] == claim_doc['model_loads'] == 1 and claim_doc['native_forward_calls'] == 816,
            'original config/claim/source/proof binding differs')
    platform = endpoint.json(claim_doc['allocation_source']['path'], claim_doc['allocation_source']['sha256'])
    endpoint.bound_ref(claim_doc['allocation_source']); allocation = endpoint.json(outer['allocation_path'], outer['allocation_sha256'])
    require(platform['allocation_id'] == allocation['allocation_id'] == claim_doc['allocation_id'] and
            platform['prepared_config_sha256'] == pins['prepared_config'] and platform['backend'] == endpoint.backend and
            platform['prompt_bin'] == endpoint.prompt_bin and platform['task'] == TASK and
            platform['lifecycle_sha256'] == SOURCE_PINS[endpoint.backend]['lifecycle'] and
            platform['stage_sha256'] == stage_sha and platform['expected_inventory_sha256'] == expected_sha and
            platform['budget_sha256'] == GATES['native_budget_sha256'] and
            platform['native_prerequisite_sha256'] == GATES['native_prerequisite_sha256'], 'actual allocation detached from source/config')
    require(runtime['allocation_receipt'] == {'path': outer['allocation_path'], 'sha256': outer['allocation_sha256'],
            'size_bytes': endpoint.files[outer['allocation_path']]['size']} and
            runtime['source_manifest'] == config['source_manifest'] and runtime['expected_inventory'] == config['expected_inventory'] and
            runtime['prerequisite'] == config['prerequisite'] and runtime['stage_spec'] == config['stage_spec'] and
            runtime['budget'] == config['budget'], 'runtime input/proof/allocation references differ')
    source_hashes = outer['source_sha256']
    require(all(source_hashes[value['path']] == value['sha256'] for value in
            (config_ref, claim_doc['allocation_source'], config['source_manifest'], config['stage_spec'], config['budget'],
             config['expected_inventory'], config['prerequisite'], config['expected_builder'])), 'pre-model source closure lacks bound metadata')
    typed = endpoint.json(config['source_manifest']['path'], config['source_manifest']['sha256'])
    require(typed['schema_version'] == 1 and typed['task'] == TASK and
            set(typed['files']) == set(typed['inventory']) and len(typed['files']) <= 512,
            'exact typed deployment manifest required')
    total_source_bytes = 0
    for name, digest in typed['files'].items():
        safe_relative(name); item = typed['inventory'][name]
        require(set(item) == {'sha256', 'size_bytes', 'kind'} and item['sha256'] == digest and
                item['kind'] == ('code' if name.endswith('.py') else 'metadata') and type(item['size_bytes']) is int and
                0 <= item['size_bytes'] <= (1024**2 if item['kind'] == 'code' else 16 * 1024**2), 'typed deployment source size/kind differs')
        original = child(config['source_root'], name)
        require(source_hashes[original] == digest and endpoint.files[original]['size'] == item['size_bytes'],
                'typed deployment manifest missing from original pre-model byte closure')
        total_source_bytes += item['size_bytes']
    require(total_source_bytes <= 512 * 1024**2, 'typed source closure exceeds512MiB')
    # Every dynamically copied runtime original is resolved through its explicit
    # original POSIX map key, never replaced with a manufactured path.
    require(runtime['runtime_sources'] == endpoint.json(child(output, 'runtime-source-map.json')), 'runtime map aliases differ')
    frozen = endpoint.json(child(output, 'frozen-source-refs.json'))
    for item in frozen.values(): require(source_hashes[item['path']] == item['sha256'], 'native frozen source absent from pre-model closure')
    packages = {'package/torch', 'package/numpy', 'package/transformers', 'implementation/modeling',
                'implementation/cache_utils', 'implementation/masking_utils', 'implementation/safetensors_torch'}
    if endpoint.backend == 'NPU': packages.add('package/torch_npu')
    require(set(runtime['runtime_sources']) == set(frozen) | packages and
            all(runtime['runtime_sources'][key]['original'] == value for key, value in frozen.items()) and
            runtime['runtime_sources']['implementation/modeling']['original'] == runtime['model_identity']['modeling_source'],
            'exact frozen/runtime implementation alias closure differs')
    progress = outer['native_progress']; value = progress['source']
    require(value['path'] == child(claim, 'native-progress.jsonl') and progress['status'] == 'source_capture_completed' and
            progress['summary_hashes_checked'] == 36 and progress['native_numeric_admission'] is False and
            progress['unexecuted_cells_inferred'] is False and value['path'] not in source_hashes, 'mutable progress/input or scope differs')
    checked = inspect_progress(endpoint.bound_ref(value).read_bytes(), rows, endpoint.backend)
    protocol = {k: v for k, v in checked.items() if k not in ('summary_events', 'source_failure')}
    require(protocol == progress['transition_protocol'], 'independent transition replay differs from original lifecycle')
    manifest = endpoint.json(child(output, 'artifacts-manifest.json'))['files']; observed = []
    for event in checked['summary_events']:
        relative = 'samples/' + event['sample'] + '/' + event['mode'] + '/capture-summary.json'; item = event['source']
        require(item['path'] == child(output, relative) and manifest[relative] == {
                'sha256': item['sha256'], 'size_bytes': item['size_bytes']}, 'progress summary detached from original manifest')
        observed.append(load(endpoint.bound_ref(item)))
    require(observed == runtime['native_observations'], 'runtime summaries differ from original36 completed progress cells')
    stdout = outer['native_stdout']; raw_ref = stdout['raw_source']
    require(raw_ref['path'] == child(str(PurePosixPath(outer['generic_receipt']['path']).parent), 'stdout.bin'), 'stdout is not sibling of original command')
    stdout_checked = inspect_native_stdout(endpoint.bound_ref(raw_ref).read_bytes(), endpoint.backend,
        endpoint.json(child(output, 'status.json')), value, runtime)
    require(stdout == dict(stdout_checked, raw_source=raw_ref), 'native stdout evidence differs')
    argv = outer['argv']
    def flag(name):
        require(argv.count(name) == 1 and argv.index(name) + 1 < len(argv), 'one native flag required: ' + name)
        return argv[argv.index(name) + 1]
    for name, actual in (('--progress-path', value['path']), ('--prerequisite', config['prerequisite']['path']),
                        ('--prerequisite-sha256', GATES['native_prerequisite_sha256']),
                        ('--prerequisite-helper-sha256', SOURCE_PINS[endpoint.backend]['contract']),
                        ('--budget', config['budget']['path']), ('--budget-sha256', GATES['native_budget_sha256'])):
        require(flag(name) == actual, 'native actual progress/proof/budget argv differs')
    result.update(progress=checked, controller=controller)
    return result


def activation_ready():
    require(all(isinstance(value, str) and HEX.fullmatch(value) for key, value in GATES.items()
                if key != 'native_endpoint_schema_reviewed') and GATES['native_endpoint_schema_reviewed'] is True,
            'reserved48 CPU-v2 stage/proof/budget/schema remains unready')


def check_coverage(document):
    coverage = document['coverage']
    require(set(coverage) == {'GPU', 'NPU'} and all(set(coverage[side]) == set(map(str, BINS)) for side in coverage),
            'all48/432 planned backend/bin coverage must remain explicit')
    for side in ('GPU', 'NPU'):
        for P in BINS:
            item = coverage[side][str(P)]
            require(item['status'] in COVERAGE_STATES and isinstance(item.get('reason'), str) and item['reason'],
                    'explicit completed/failed/unstarted/blocked/running status and reason required')
            require(set(item) <= {'status', 'reason', 'endpoint', 'failure_evidence'}, 'unknown coverage fields')
            if item['status'] == 'completed': require('endpoint' in item and 'failure_evidence' not in item, 'complete endpoint required')
            else: require('endpoint' not in item, 'failed/unstarted bin cannot supply successful-cell substitute')
            if item['status'] in ('unstarted', 'blocked'): require('failure_evidence' not in item, 'unstarted/blocked status is an external declaration, not an invented capture')
    return coverage


def inspect_failure_evidence(audit, item, rows, backend, prompt_bin):
    """Read only explicitly pinned small originals; a missing terminal is unknown."""
    result = {'status': item['status'], 'reason': item['reason'], 'declaration_is_platform_attestation': False,
              'cell_ledger': None, 'unexecuted_cells_inferred': False, 'numeric_observations_admitted': 0}
    if 'failure_evidence' not in item:
        result['progress_status'] = 'unavailable_unknown'; return result
    endpoint_ready(backend, prompt_bin, completed=False)
    evidence = item['failure_evidence']; catalog = evidence['files']; checked = {}; total = 0
    require(type(catalog) is dict and 1 <= len(catalog) <= 512, 'bounded failure metadata catalog required')
    for original, value in catalog.items():
        origin(original); require(not original.lower().endswith(('.npy', '.safetensors', '.pt', '.tar', '.gz', '.whl')),
                                  'failure diagnostics cannot reopen native/model/archive data')
        require(set(value) == {'path', 'sha256', 'size_bytes'} and type(value['size_bytes']) is int and
                0 <= value['size_bytes'] <= 16 * 1024**2, 'bounded original failure metadata reference required')
        total += value['size_bytes']; require(total <= 64 * 1024**2, 'failure metadata cap exceeded')
        checked[original] = audit.file(value['path'], value['sha256'], value['size_bytes'])
    source = origin(evidence['controller_source_path']); controller = load(checked[source])
    require(catalog[source]['sha256'] == ENDPOINT_PINS[backend][str(prompt_bin)]['controller'] and
            controller['task'] == 'RESERVED48' and controller['backend'] == backend and controller['prompt_bin'] == prompt_bin and
            controller['status'] != 'completed' and controller['returncode'] != 0 and item['status'] == 'failed',
            'failure controller external bytes/status/bin differ')
    result.update(controller={'source_path': source, **catalog[source]}, observed_controller=controller,
                  timeout_observations=controller.get('timeout_observations'))
    progress_source = evidence.get('progress_source_path')
    if progress_source is None: result['progress_status'] = 'unavailable_unknown'; return result
    try:
        checked_progress = inspect_progress(checked[origin(progress_source)].read_bytes(), rows, backend, require_success=False)
        require(checked_progress['status'] == 'source_capture_failed', 'failed controller cannot admit terminal-success numeric data')
    except (ValueError, KeyError, TypeError, IndexError) as exc:
        result.update(progress_status='partial_or_invalid_terminal_unknown', diagnostic_error=str(exc)); return result
    result.update(progress_status=checked_progress['status'], cell_ledger=checked_progress['cell_ledger'],
                  observed_not_entered_cells=checked_progress['not_entered_cells'], source_failure=checked_progress['source_failure'],
                  forward_attempts=checked_progress['forward_attempts'], forward_returns=checked_progress['forward_returns'])
    return result


def request(path, digest):
    activation_ready()  # Before any requested file, output, NumPy or framework IO.
    require(sha(path) == digest, 'external CPU-v2 request SHA differs')
    doc = load(path); require(doc['schema_version'] == 2 and doc['kind'] == 'reserved48-common-cpu-request-v2' and doc['task'] == TASK,
                              'case-owned schema2 CPU request required')
    for key, gate in (('stage_spec', 'stage_sha256'), ('expected_inventory', 'expected_inventory_sha256'),
        ('budget', 'budget_sha256'), ('native_budget', 'native_budget_sha256'), ('cpu_prerequisite', 'cpu_prerequisite_sha256'),
        ('native_prerequisite', 'native_prerequisite_sha256'), ('expected_builder', 'expected_builder_sha256')):
        value = doc[key]; require(value['sha256'] == GATES[gate] and ref(value['path']) == value, 'frozen CPU-v2 request dependency differs: ' + key)
    for label, gate, proof in (('cpu_prerequisite_checker', 'cpu_prerequisite_checker_sha256', 'cpu_prerequisite'),
                              ('native_prerequisite_checker', 'native_prerequisite_checker_sha256', 'native_prerequisite')):
        value = doc[label]; require(value['sha256'] == GATES[gate] and ref(value['path']) == value, 'reviewed pure prerequisite checker differs')
        spec = importlib.util.spec_from_file_location('_reserved48_cpu_v2_' + label, value['path'])
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        checked = module.prerequisite(doc[proof]['path'], doc[proof]['sha256'])
        require(checked['native_executions_started'] == 0 and not any(x in sys.modules for x in ('torch', 'torch_npu', 'transformers', 'numpy')),
                'portable preconditions must be verified before numeric imports')
    check_coverage(doc)
    require(ref(doc['manifest']['path']) == doc['manifest'] and doc['manifest']['sha256'] == MANIFEST_SHA, 'frozen all48 manifest differs')
    spec = importlib.util.spec_from_file_location('_reserved48_cpu_v2_independent_expected', doc['expected_builder']['path'])
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    generated = module.derive(doc['manifest']['path'], doc['input_dir'], GATES['stage_sha256'])
    require(canonical(generated) == canonical(load(doc['expected_inventory']['path'])) and generated['schema_version'] == 2 and
            generated['native_capture_schema_version'] == 2 and generated['native_progress']['schema_version'] == 1 and
            generated['counts']['pairs_total'] == 432, 'independently reconstructed all48/schema2/progress1 inventory differs')
    # A new internal view; the original externally hashed request bytes stay raw.
    doc = dict(doc, source_maps={side: {str(P): doc['coverage'][side][str(P)]['endpoint'] for P in BINS
        if doc['coverage'][side][str(P)]['status'] == 'completed'} for side in ('GPU', 'NPU')})
    return doc, generated



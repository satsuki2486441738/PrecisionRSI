"""Synthetic CPU protocol fixtures, never native-model evidence or admission."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i01_export_under_test', HERE / 'export_i01_evidence_v1.py')
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@unittest.skipUnless(os.name == 'posix', 'Original POSIX source-map keys')
class Evidence(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.root = self.base / 'new-i01-task'
        self.root.mkdir()
        self.claim = self.root / 'claims' / 'synthetic-CPU-fixture'
        self.claim.mkdir(parents=True)
        self.run = self.root / 'runs' / 'h100-i01-cacheoff-synthetic'
        self.artifacts = self.run / 'artifacts'
        self.artifacts.mkdir(parents=True)
        (self.root / 'exports').mkdir()
        self.entry = self.root / 'source' / 'entry.py'
        self.entry.parent.mkdir()
        self.entry.write_bytes(b'# Synthetic protocol fixture, not a model collector\n')
        self.input = self.root / 'source/input.json'
        self.input.write_text('{"synthetic_cpu_fixture":true}\n')
        self.stage = self.root / 'source/stage.json'
        self.stage.write_text('{"status":"synthetic_cpu_fixture"}\n')
        self.expected = self.claim / 'expected-inventory.json'
        self.expected.write_text('{"scope":"synthetic transport protocol only"}\n')
        self.allocation = self.claim / 'allocation.json'
        self.allocation.write_text('{"synthetic":true,"no_real_allocation":true}\n')
        self.stage_patch = patch.object(tool, 'STAGE_SHA', sha(self.stage))
        self.expected_patch = patch.object(tool, 'EXPECTED_SHA', sha(self.expected))
        self.stage_patch.start(); self.expected_patch.start()
        self.addCleanup(self.stage_patch.stop); self.addCleanup(self.expected_patch.stop)
        # Simulate an original GPU /tmp package source which is gone after UI
        # stop. Export must use the already-hashed AFS copy under its old key.
        self.original_module = self.base / 'old-gpu-tmp/package/__init__.py'
        self.original_module.parent.mkdir(parents=True)
        self.original_module.write_bytes(b'# Original GPU temporary module, synthetic\n')
        self.frozen_module = self.claim / 'frozen-runtime/0000/__init__.py'
        self.frozen_module.parent.mkdir(parents=True)
        self.frozen_module.write_bytes(self.original_module.read_bytes())
        self.module_ref = {'path': str(self.original_module), 'sha256': sha(self.original_module),
                           'size_bytes': self.original_module.stat().st_size}
        self.runtime_map = self.claim / 'frozen-runtime-source-map.json'
        tool.put(self.runtime_map, {str(self.original_module): {'path': str(self.frozen_module),
            'sha256': sha(self.original_module), 'size_bytes': self.original_module.stat().st_size}})
        runtime = {'model_identity': {'modeling_source': self.module_ref},
                   'package_sources': {'synthetic_module': self.module_ref},
                   'sources': {'synthetic_entry': {'path': str(self.entry), 'sha256': sha(self.entry),
                                                  'size_bytes': self.entry.stat().st_size}},
                   'scope': 'Synthetic CPU transport fixture, no native values'}
        tool.put(self.artifacts / 'runtime.json', runtime)
        # Small placeholder bytes intentionally cannot pass independent raw
        # BF16/numeric admission. This test exercises provenance/transport only.
        for name in sorted(tool.LARGE_NAMES):
            (self.artifacts / name).write_bytes(('synthetic fixture ' + name).encode())
        self.manifest = {'backend': 'gpu', 'stage_spec_sha256': tool.STAGE_SHA,
            'expected_inventory_sha256': tool.EXPECTED_SHA, 'synthetic': True,
            'files': {p.name: {'sha256': sha(p), 'size_bytes': p.stat().st_size}
                      for p in self.artifacts.iterdir()}}
        tool.put(self.artifacts / 'artifacts-manifest.json', self.manifest)
        tool.put(self.artifacts / 'status.json', {'status': 'completed', 'synthetic': True,
            'artifacts_manifest_sha256': sha(self.artifacts / 'artifacts-manifest.json')})
        argv = ['synthetic-never-executed', '--input', str(self.input), '--allocation-receipt', str(self.allocation),
            '--stage-spec', str(self.stage), '--stage-spec-sha256', tool.STAGE_SHA,
            '--expected-inventory', str(self.expected), '--expected-inventory-sha256', tool.EXPECTED_SHA,
            '--output', str(self.artifacts)]
        tool.put(self.run / 'command.json', {'status': 'completed', 'returncode': 0, 'argv': argv,
                                             'start': 'synthetic', 'timeout': 900})
        for name in ('stdout.bin', 'stderr.bin', 'execution.json'):
            (self.run / name).write_bytes(b'original generic fixture bytes\n')
        sources = {str(p): sha(p) for p in (self.entry, self.input, self.stage, self.expected,
                                            self.allocation, self.original_module)}
        self.outer = {'schema_version': 1, 'task': 'I01', 'backend': 'GPU', 'status': 'completed',
            'returncode': 0, 'timed_out': False, 'native_capture_count': 1,
            'started_utc': 'synthetic', 'argv': argv, 'output_dir': str(self.artifacts),
            'collector_path': str(self.entry), 'collector_sha256': sha(self.entry),
            'input_path': str(self.input), 'input_sha256': sha(self.input),
            'allocation_path': str(self.allocation), 'allocation_sha256': sha(self.allocation),
            'expected_inventory_source_path': str(self.expected), 'expected_inventory_source_sha256': tool.EXPECTED_SHA,
            'stage_spec_source_path': str(self.stage), 'stage_spec_source_sha256': tool.STAGE_SHA,
            'generic_receipt': {'path': str(self.run / 'command.json'), 'sha256': sha(self.run / 'command.json')},
            'runtime_source_map_path': str(self.runtime_map), 'runtime_source_map_sha256': sha(self.runtime_map),
            'source_sha256': sources, 'dependency_paths': list(sources),
            'artifacts_manifest_sha256': sha(self.artifacts / 'artifacts-manifest.json'), 'synthetic': True}
        self.outer_path = self.claim / 'capture-receipt.json'
        self.original_module.unlink()

    def invoke(self, name='export', retain=False):
        tool.put(self.outer_path, self.outer)
        output = self.root / 'exports' / name
        result = tool.export(self.outer_path, self.root, output, retain)
        return output, result

    def test_gpu_complete_copy_original_keys_and_raw_receipts(self):
        output, result = self.invoke()
        mapping = tool.read(output / 'source-map.json')
        self.assertEqual(mapping['full_array_hashes_checked'], 48)
        self.assertEqual(mapping['retained_array_count'], 0)
        self.assertTrue(all('path' in entry for entry in mapping['files'].values()))
        for original in (self.outer_path, self.run / 'command.json', self.runtime_map):
            entry = mapping['files'][str(original)]
            self.assertEqual((output / entry['path']).read_bytes(), original.read_bytes())
        entry = mapping['files'][str(self.original_module)]
        self.assertEqual((output / entry['path']).read_bytes(), self.frozen_module.read_bytes())
        self.assertEqual(result['archive_sha256'], sha(result['archive']))
        self.assertLessEqual(result['archive_bytes'], tool.MAX_TRANSPORT)
        with tarfile.open(result['archive']) as archive:
            members = archive.getmembers()
            self.assertTrue(all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members))
            self.assertEqual(len({m.name for m in members}), len(members))

    def test_npu_retains_exact48_but_rehashes_every_source(self):
        self.outer['backend'] = 'NPU'
        self.manifest['backend'] = 'npu'
        (self.artifacts / 'artifacts-manifest.json').unlink()
        tool.put(self.artifacts / 'artifacts-manifest.json', self.manifest)
        status = tool.read(self.artifacts / 'status.json')
        status['artifacts_manifest_sha256'] = sha(self.artifacts / 'artifacts-manifest.json')
        (self.artifacts / 'status.json').unlink(); tool.put(self.artifacts / 'status.json', status)
        self.outer['artifacts_manifest_sha256'] = status['artifacts_manifest_sha256']
        command = tool.read(self.run / 'command.json'); command['timeout'] = 1200
        (self.run / 'command.json').unlink(); tool.put(self.run / 'command.json', command)
        self.outer['generic_receipt']['sha256'] = sha(self.run / 'command.json')
        output, result = self.invoke(retain=True)
        mapping = tool.read(output / 'source-map.json')
        retained = {path: ref for path, ref in mapping['files'].items() if ref.get('retained_at_source')}
        self.assertEqual(len(retained), 48)
        self.assertTrue(all('path' not in ref and ref['sha256'] == sha(path) for path, ref in retained.items()))
        self.assertEqual(result['retained_array_count'], 48)

    def test_gpu_cannot_retain_arrays(self):
        with self.assertRaisesRegex(ValueError, 'GPU arrays'):
            self.invoke(retain=True)

    def test_frozen_runtime_copy_tamper_rejected(self):
        self.frozen_module.write_bytes(b'changed')
        with self.assertRaises(ValueError):
            self.invoke()
        self.assertFalse(any(self.root.rglob('*.tar.gz')))

    def test_raw_artifact_and_generic_receipt_mutation_rejected(self):
        (self.artifacts / 'raw-native-logits.safetensors').write_bytes(b'changed')
        with self.assertRaises(ValueError):
            self.invoke()

    def test_declared_sha_cannot_be_forged(self):
        self.outer['source_sha256'][str(self.entry)] = 'a' * 64
        with self.assertRaises(ValueError):
            self.invoke()

    def test_old_array_inventory_cannot_be_mixed_in(self):
        (self.artifacts / 'old-32-targets.npy').write_bytes(b'old unrelated fixture')
        with self.assertRaisesRegex(ValueError, 'inventory'):
            self.invoke()

    def test_literal_argv_binding_cannot_be_changed(self):
        self.outer['argv'] = list(self.outer['argv'])
        self.outer['argv'][self.outer['argv'].index('--output') + 1] = '/unrelated'
        with self.assertRaisesRegex(ValueError, 'argv'):
            self.invoke()

    def test_actual_compressed_size_gate_keeps_failure_without_transport(self):
        with patch.object(tool, 'MAX_TRANSPORT', 10), self.assertRaisesRegex(ValueError, 'transport cap'):
            self.invoke()
        failure = tool.read(self.root / 'exports/export-failure.json')
        self.assertFalse(failure['transport_allowed'])
        self.assertTrue((self.root / 'exports/export.tar.gz').is_file())
        self.assertTrue((self.artifacts / 'raw-native-logits.safetensors').is_file())

    def test_output_escape_and_symlink_are_rejected(self):
        tool.put(self.outer_path, self.outer)
        with self.assertRaises(ValueError):
            tool.export(self.outer_path, self.root, self.root / '..' / 'outside')
        link = self.root / 'source/linked.py'
        link.symlink_to(self.entry)
        with self.assertRaisesRegex(ValueError, 'symlink'):
            tool.export(self.outer_path, self.root, self.root / 'exports/export')


if __name__ == '__main__':
    unittest.main()

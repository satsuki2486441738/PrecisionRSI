"""Synthetic CPU metadata fixtures; never native model/accuracy evidence.

Production source pins have no CLI override. Tests patch them in-process for
clearly synthetic receipts. Every one of288 array paths is deliberately absent.
"""
from contextlib import ExitStack
import copy
import hashlib
import json
import os
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

import export_i01_actual_small_v1 as e


def write(path,doc):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8');return path


class Fixture:
    def __init__(self,root):
        self.root=Path(root);self.run=self.root/'run';self.run.mkdir();self.tools=self.root/'tools';self.tools.mkdir()
        analysis=self.tools/'analysis.py';analysis.write_text('# synthetic fixture; not native\n')
        self.stack=ExitStack();self.stack.enter_context(patch.object(e,'MAIN_SHA',e.sha(analysis)))
        manifest=write(self.tools/'tool-bundle-manifest.json',{'files':{'analysis.py':{'sha256':e.sha(analysis),'size_bytes':analysis.stat().st_size}}})
        self.stack.enter_context(patch.object(e,'TOOL_SHA',e.sha(manifest)))
        maps=[]
        for side,count in [('newGPU',47),('newNPU',47),('oldGPU',96),('oldNPU',96)]:
            arrays={'/synthetic/'+side+'/row-%03d.npy'%i:{'size':100,'sha256':'a'*64,'retained_at_source':True} for i in range(count)}
            if side.startswith('new'):arrays['/synthetic/'+side+'/raw-native-logits.safetensors']={'size':100,'sha256':'b'*64,'retained_at_source':True}
            path=write(self.root/(side+'.json'),{'files':arrays,'synthetic_fixture':True});maps.append({'path':str(path),'sha256':e.sha(path)})
        oldrefs={key:{'path':str(write(self.root/(key+'.json'),{'synthetic_fixture':True}))} for key in ('admission','gate')}
        for ref in oldrefs.values():ref['sha256']=e.sha(ref['path'])
        spec={'stage_spec_sha256':e.STAGE_SHA,'endpoints':{'GPU':{'source_map':maps[0]},'NPU':{'source_map':maps[1]}},
            'old_cached':{'gpu_map':maps[2],'npu_map':maps[3],**oldrefs},'synthetic_fixture':True}
        self.spec=write(self.run/'comparison-spec.json',spec);bundle=self.run/'bundle';bundle.mkdir()
        pairs=[]
        for index in range(7):
            folder=bundle/('pair-%d'%index);folder.mkdir();targets,positions=(159,47) if index==0 else (32,32)
            docs={}
            for name in ['targets-contract.json','distributions-contract.json','a-environment.json','b-environment.json','a-targets.json','b-targets.json','a-distributions.json','b-distributions.json']:
                path=write(folder/name,{'synthetic_fixture':True,'name':name});docs[name]=e.sha(path)
            pairs.append({'targets':{'status':'no_thresholds','coverage':{'expected':targets,'paired':targets},'sources':{'contract':str(folder/'targets-contract.json')}},
                'distributions':{'status':'no_thresholds','position_count':positions},'frozen_document_sha256':docs,
                'thresholds':None,'acceptance':None})
        report={'schema_version':1,'status':'i01_raw_bf16_and_scoped_comparisons_checked','stage_spec_sha256':e.STAGE_SHA,
            'comparison_spec_sha256':e.sha(self.spec),'scope':{'independent_inputs':1,'new_repeatability_measured':False,'full_targets_per_backend':159,
                'full_distribution_positions_per_backend':47,'old_cached_continuation_targets_only':32,'historical_peer_comparisons':6},
            'cross_backend':pairs[0],'historical_cached_peer_contrasts':pairs[1:],'thresholds':None,'acceptance':None,'full_core_complete':False,
            'native_executions_started_by_admission':0,'raw_derivation':{side:{'raw_sha256':'b'*64,'manifest_sha256':'c'*64,
                'largest_abs_logprob_derivation_delta':0.0} for side in ('GPU','NPU')},'offline_tool_source_sha256':{'i01_admission_compare_v1.py':e.MAIN_SHA},
            'synthetic_fixture':True}
        self.report=write(bundle/'i01-comparison-report.json',report)
        stdout=write(self.run/'01-independent-compare.stdout',{'status':report['status'],'cross_targets':159,'cross_positions':47,'cached_peer_contrasts':6,
            'native_executions_started':0,'acceptance':None});stderr=self.run/'01-independent-compare.stderr';stderr.write_bytes(b'')
        step={'step':'01-independent-compare','returncode':0,'timed_out':False,'timeout_seconds':620,
            'argv':['/synthetic/python','-B',str(analysis),'--spec',str(self.spec),'--spec-sha256',e.sha(self.spec),
                '--output-dir',str(bundle),'--timeout-seconds','600']}
        for key,path in [('stdout',stdout),('stderr',stderr)]:step[key]={'path':str(path),'sha256':e.sha(path),'bytes':path.stat().st_size}
        self.controller=write(self.run/'controller-receipt.json',{'status':'completed','returncode':0,'task':'I01','run':str(self.run),
            'native_executions_started':0,'acceptance':None,'tool_manifest_sha256':e.TOOL_SHA,'tools_root':str(self.tools),'steps':[step],
            'comparison_spec':{'path':str(self.spec),'sha256':e.sha(self.spec)},'report':{'path':str(self.report),'sha256':e.sha(self.report)}})
        self.selection=write(self.root/'selection/selection-receipt.json',{'status':'ready_to_execute_frozen_cpu_controller','returncode':0,
            'tools_root':str(self.tools),'gpu_source_map_sha256':maps[0]['sha256'],'npu_source_map_sha256':maps[1]['sha256'],
            'checked_source_sha256':{'/synthetic/newGPU/raw-native-logits.safetensors':'b'*64},'synthetic_fixture':True})
    def close(self):self.stack.close()
    def resign_report(self,edit):
        doc=e.load(self.report);edit(doc);write(self.report,doc)
        c=e.load(self.controller);c['report']['sha256']=e.sha(self.report);write(self.controller,c)


class Tests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.fx=Fixture(self.tmp.name)
    def tearDown(self):self.fx.close();self.tmp.cleanup()
    def test_actual_controller_schema_and_direct_arguments(self):
        _,_,report=e.verify_controller(self.fx.controller);self.assertEqual(report['scope']['full_targets_per_backend'],159)
        c=e.load(self.fx.controller);c['steps'][0]['argv'][-1]='999';write(self.fx.controller,c)
        with self.assertRaisesRegex(ValueError,'direct analysis argv'):e.verify_controller(self.fx.controller)
    def test_result_hash_and_returncode_mutations_rejected(self):
        c=e.load(self.fx.controller);c['returncode']=True;write(self.fx.controller,c)
        with self.assertRaisesRegex(ValueError,'completed0'):e.verify_controller(self.fx.controller)
        c['returncode']=0;c['report']['sha256']='0'*64;write(self.fx.controller,c)
        with self.assertRaisesRegex(ValueError,'path/SHA'):e.verify_controller(self.fx.controller)
    def test_resigned_raw_proof_and_scope_mutations_rejected(self):
        self.fx.resign_report(lambda d:d['raw_derivation']['NPU'].update(largest_abs_logprob_derivation_delta=.01))
        with self.assertRaisesRegex(ValueError,'raw BF16'):e.verify_controller(self.fx.controller)
    def test_resigned_cached_pair_scope_mutation_rejected(self):
        self.fx.resign_report(lambda d:d['historical_cached_peer_contrasts'][0]['targets'].update(coverage={'expected':159,'paired':159}))
        with self.assertRaisesRegex(ValueError,'pair result scope'):e.verify_controller(self.fx.controller)
    @unittest.skipUnless(os.name=='posix','production exporter requires original absolute POSIX source paths')
    def test_full_export_with_all288_arrays_absent_and_six_original_proofs(self):
        output=Path(self.tmp.name)/'export';result=e.export(self.fx.controller,self.fx.selection,output)
        self.assertEqual((result['omitted_npy_files'],result['omitted_raw_native_files'],result['arrays_opened_or_copied']),(286,2,0))
        proof=e.load(result['prerequisite_path']);refs=[proof[k] for k in ('controller','report','comparison_spec','analysis_source')]+list(proof['source_maps'].values())
        self.assertEqual(len(refs),6)
        for ref in refs:self.assertEqual((output/'i03-prerequisite'/ref['path']).read_bytes(),Path(ref['source_path']).read_bytes())
        for archive in result['archives']:
            path=output.parent/archive['basename'];self.assertEqual(e.sha(path),archive['sha256'])
            with tarfile.open(path) as tar:
                self.assertTrue(all(member.isfile() and not member.name.endswith(('.npy','.safetensors')) for member in tar.getmembers()))
    @unittest.skipUnless(os.name=='posix','production exporter requires original absolute POSIX source paths')
    def test_changed_frozen_document_and_output_reuse_rejected(self):
        path=self.fx.run/'bundle/pair-0/a-targets.json';path.write_bytes(b'{}\n')
        with self.assertRaisesRegex(ValueError,'metadata source SHA differs'):e.export(self.fx.controller,self.fx.selection,Path(self.tmp.name)/'bad-export')
        with self.assertRaisesRegex(ValueError,'exclusive new'):e.export(self.fx.controller,self.fx.selection,Path(self.tmp.name)/'bad-export')


if __name__=='__main__':unittest.main()

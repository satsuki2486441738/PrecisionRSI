"""Fresh one-H100 application entrypoint; prepare, probe, capture and exit."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import select
import shutil
import signal
import subprocess
import sys
import tarfile
import time

TASK=Path('/srv/precision-task')
STAGE=TASK/'h100-torch290-source-20261106'
CASE=STAGE/'projects/gemma4-pilot/cases/text-native'
PREP=TASK/'h100-envprep-20261106T071800Z'
ENV_ARCHIVE=TASK/'environment-py31213-torch290cu128-20261106.tar'
ENV_ARCHIVE_SHA='e29d65534fb7d5ef38e5a71a08dc149f4cb7f3252e44835520c6ce357100d574'
PACKAGE=TASK/'attempts/h100-torch290-candidate-upload-v1.tar'
PACKAGE_SHA='8492cbc2e6d004d1fdccfe763b1714ddb162a8ba21fe76fad4928222edbe93f1'
PLATFORM_SOURCE=TASK/'attempts/h100-torch290-allocation-source-20261106.json'
MIN_HOST=40*1024**3
RUNTIME_PARENT=Path('/tmp')
MEMORY_GUARD=TASK/'attempts/npu_three_repeat_launcher_v3-memory-guard-20261106.py'
MEMORY_GUARD_SHA='b3af6fceafeb6107308baf64824849c9754ced1daf3394058345b4eebbd2c938'


def utc(): return datetime.now(timezone.utc).isoformat()
def require(ok,message):
    if not ok: raise ValueError(message)
def load(p): return json.loads(Path(p).read_text())
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()
def put(p,value):
    with Path(p).open('x',encoding='utf-8') as f: json.dump(value,f,indent=2,allow_nan=False); f.write('\n')


def stage_candidate():
    require(sha(PACKAGE)==PACKAGE_SHA,'candidate archive differs from reviewed upload')
    manifest=load(PACKAGE.with_suffix('.manifest.json'))
    require(manifest['archive']['sha256']==PACKAGE_SHA,'candidate package manifest differs')
    with tarfile.open(PACKAGE) as tf:
        members=tf.getmembers(); entries=manifest['files']
        require(len(members)==len(entries),'candidate package member inventory differs')
        for member,entry in zip(members,entries):
            require(member.isfile() and member.name==entry['path'] and not PurePosixPath(member.name).is_absolute() and
                '..' not in PurePosixPath(member.name).parts,'unsafe candidate member')
            raw=tf.extractfile(member).read()
            require(len(raw)==entry['size'] and hashlib.sha256(raw).hexdigest()==entry['sha256'],'candidate member SHA differs')
            destination=STAGE/member.name
            require(destination.resolve().is_relative_to(STAGE),'candidate destination escapes task')
            if destination.exists(): require(destination.is_file() and sha(destination)==entry['sha256'],'existing source differs; no overwrite')
            else:
                destination.parent.mkdir(parents=True,exist_ok=True)
                with destination.open('xb') as f: f.write(raw)


def restore_environment(attempt):
    require(len(ENV_ARCHIVE_SHA)==64 and sha(ENV_ARCHIVE)==ENV_ARCHIVE_SHA,'environment archive is not reviewed or differs')
    parent=RUNTIME_PARENT/('h100-torch290-runtime-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+str(os.getpid()))
    require(not parent.exists(),'new runtime restore path required'); parent.mkdir(mode=0o700)
    with tarfile.open(ENV_ARCHIVE) as tf:
        members=tf.getmembers(); total=sum(x.size for x in members if x.isfile())
        require(shutil.disk_usage(parent).free>=total+1024**3,'container disk lacks environment plus 1GiB headroom')
        for m in members:
            parts=PurePosixPath(m.name).parts
            require(parts and parts[0]==PREP.name and '..' not in parts and not PurePosixPath(m.name).is_absolute(), 'unsafe environment member')
            require(m.isfile() or m.isdir() or m.issym() or m.islnk(),'unsupported environment archive member')
            if m.issym():
                if PurePosixPath(m.linkname).is_absolute():
                    target=Path(m.linkname)
                    require(target.is_relative_to(PREP),'external absolute environment link')
                    mapped=parent/PREP.name/target.relative_to(PREP)
                    m.linkname=os.path.relpath(mapped,(parent/m.name).parent)
                mapped=(parent/m.name).parent/m.linkname
                require(Path(os.path.normpath(mapped)).is_relative_to(parent/PREP.name),'environment link escapes restore')
            if m.islnk():
                require(PurePosixPath(m.linkname).parts[0]==PREP.name and '..' not in PurePosixPath(m.linkname).parts,
                        'environment hardlink escapes restore')
        for m in members: tf.extract(m,parent)
    restored=parent/PREP.name; config=restored/'venv/pyvenv.cfg'
    original=config.read_bytes(); text=original.decode().replace(str(PREP),str(restored)); config.write_text(text)
    put(attempt/'environment-restore.json',{'archive':str(ENV_ARCHIVE),'archive_sha256':ENV_ARCHIVE_SHA,
        'restored':str(restored),'uncompressed_regular_bytes':total,
        'pyvenv_original_sha256':hashlib.sha256(original).hexdigest(),'pyvenv_restored_sha256':sha(config),
        'changes':'new container copy only: absolute Python symlinks and pyvenv prefix relocated; package bytes retained'})
    return restored/'venv/bin/python'


def platform_source(attempt):
    deadline=time.monotonic()+30
    while not PLATFORM_SOURCE.is_file() and time.monotonic()<deadline: select.select([],[],[],min(1,max(0,deadline-time.monotonic())))
    require(PLATFORM_SOURCE.is_file(),'allocation source missing after bounded 30-second wait; no model started')
    raw=PLATFORM_SOURCE.read_bytes(); document=json.loads(raw)
    require(document.get('vendor')=='NVIDIA' and type(document.get('visible_count')) is int and document['visible_count']==1 and
        all(isinstance(document.get(k),str) and document[k].strip() for k in ('allocation_id','evidence_source')),
        'explicit authenticated one-GPU allocation source required')
    require(document['allocation_id'].startswith('app-'),'actual SenseCore application ID required')
    with (attempt/'platform-allocation-source.json').open('xb') as f: f.write(raw)
    return document,hashlib.sha256(raw).hexdigest()


def memory():
    require(sha(MEMORY_GUARD)==MEMORY_GUARD_SHA,'reviewed cgroup memory guard source changed')
    spec=importlib.util.spec_from_file_location('h100_reviewed_cgroup_observer',MEMORY_GUARD)
    helper=importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    observation=helper.memory_observation()
    require(observation['effective_available_bytes']>=MIN_HOST,'effective host memory headroom below 40GiB')
    return {**observation,'guard_source':str(MEMORY_GUARD),'guard_sha256':MEMORY_GUARD_SHA,
        'observer_original_minimum_bytes':observation['minimum_bytes'],'minimum_bytes':MIN_HOST}


def bootstrap():
    require(sys.platform.startswith('linux'),'Linux application required')
    attempt=TASK/'attempts'/('h100-torch290-startup-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    attempt.mkdir(mode=0o700); state={'status':'preparing','started_utc':utc(),'hostname':os.uname().nodename,
        'source_sha256':sha(__file__),'candidate_archive_sha256':PACKAGE_SHA,'environment_archive_sha256':ENV_ARCHIVE_SHA,
        'limitations':['supplied platform source and native UUID observations are not independent scheduler attestation']}
    put(attempt/'start.json',state)
    try:
        source,source_sha=platform_source(attempt); stage_candidate()
        state['host_memory']=memory(); python=restore_environment(attempt)
        probe='''import json,os,pathlib,subprocess,sys
# Query before importing or initializing Torch; this process owns no CUDA context.
smi=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,used_memory','--format=csv,noheader'],text=True,capture_output=True,timeout=30)
assert smi.returncode==0,'native compute-process inventory unavailable'
import torch,numpy,transformers
sys.path.insert(0,sys.argv[1])
from pilot_gpu_torch290_candidate import canonical_uuid,check_stack,H100_NAME,MIN_FREE_BYTES
check_stack({'torch':torch.__version__,'transformers':transformers.__version__,'cuda_runtime':torch.version.cuda,'numpy':numpy.__version__})
assert torch.cuda.is_available() and torch.cuda.device_count()==1,'requires exactly one native CUDA device'
torch.cuda.set_device(0); p=torch.cuda.get_device_properties(0); physical=canonical_uuid(getattr(p,'uuid',None))
assert p.name==H100_NAME and torch.cuda.is_bf16_supported(),'native H100 BF16 required'
free,total=torch.cuda.mem_get_info(0); assert free>=MIN_FREE_BYTES and total>=MIN_FREE_BYTES,'native device memory insufficient'
conflicts=[]
for line in smi.stdout.splitlines():
 fields=[x.strip() for x in line.split(',')]
 if len(fields)>=2 and canonical_uuid(fields[0])==physical: conflicts.append(line)
assert not conflicts,'conflicting native process on assigned UUID'
print(json.dumps({'status':'native_preflight_passed','runtime_uuid':physical,'device_name':p.name,'free_bytes':int(free),'total_bytes':int(total),
'visible_count':torch.cuda.device_count(),'logical_ordinal':0,'bf16':True,'executable':sys.executable,'torch_file':torch.__file__,
'python':sys.version,'versions':{'torch':torch.__version__,'transformers':transformers.__version__,'numpy':numpy.__version__,'cuda_runtime':torch.version.cuda},
'visible_env':{k:os.environ.get(k) for k in ('CUDA_VISIBLE_DEVICES','NVIDIA_VISIBLE_DEVICES')},
'compute_process_query_stage':'before Torch import or CUDA initialization','compute_process_query_stdout':smi.stdout,
'self_nspid':[x for x in pathlib.Path('/proc/self/status').read_text().splitlines() if x.startswith('NSpid:')]},indent=2))'''
        env=dict(os.environ,PYTHONHASHSEED='0',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1')
        env.pop('PYTHONPATH',None); env.pop('PYTHONHOME',None)
        native=subprocess.run([str(python),'-B','-c',probe,str(CASE/'adapters')],env=env,text=True,capture_output=True,timeout=120)
        (attempt/'native-preflight.stdout').write_text(native.stdout); (attempt/'native-preflight.stderr').write_text(native.stderr)
        require(native.returncode==0,'native preflight failed; inspect retained stderr; no model started')
        observed=json.loads(native.stdout)
        allocation={'vendor':'NVIDIA','visible_count':1,'logical_ordinal':0,'allocation_id':source['allocation_id'],
            'physical_device_id':observed['runtime_uuid'],'evidence_source':str(attempt/'platform-allocation-source.json'),
            'platform_source_sha256':source_sha,'native_source':str(attempt/'native-preflight.stdout'),
            'native_source_sha256':sha(attempt/'native-preflight.stdout')}
        put(attempt/'allocation.json',allocation)
        state.update(status='native_preflight_passed',python=str(python),allocation_source_sha256=source_sha)
        put(attempt/'bootstrap-receipt.json',state)
        os.execve(str(python),[str(python),'-B',str(Path(__file__).resolve()),'--capture',str(attempt)],env)
    except BaseException as exc:
        state.update(status='failed',finished_utc=utc(),error_type=type(exc).__name__,error=str(exc))
        put(attempt/'bootstrap-failure.json',state); print(json.dumps(state),flush=True); return 1


def capture(attempt):
    sys.path.insert(0,str(CASE/'adapters'))
    from repeat_gpu_torch290_candidate import run_three
    import record_execution_v2 as recorder
    def interrupt(signum,_frame): raise InterruptedError('signal '+str(signum))
    for sig in (signal.SIGTERM,signal.SIGINT): signal.signal(sig,interrupt)
    state={'status':'running','started_utc':utc(),'python':sys.executable,'hostname':os.uname().nodename,
        'marker':str(attempt/'three-repeat.jsonl'),'allocation_sha256':sha(attempt/'allocation.json')}
    code=1
    try:
        evidence=[Path(__file__).resolve(),attempt/'platform-allocation-source.json',attempt/'native-preflight.stdout',
            attempt/'environment-restore.json',attempt/'bootstrap-receipt.json',PACKAGE.with_suffix('.manifest.json'),MEMORY_GUARD]
        require(all(p.is_file() for p in evidence),'startup source evidence incomplete')
        def record_with_sources(collector,input_path,output,receipt_dir,timeout,extra,dependencies,backend):
            return recorder.run(collector,input_path,output,receipt_dir,timeout,extra,[*dependencies,*evidence],backend)
        code=run_three(model=TASK/'model-download/snapshot',input_path=CASE/'inputs/discovery-v1/wikitext2-discovery-001.json',
            allocation=attempt/'allocation.json',policy=CASE/'inputs/peer-math-policy-cu128-v1.json',
            environment=STAGE/'projects/gemma4-pilot/environments/gpu-torch290-environment-v1.json',
            output_root=TASK/'runs',marker=attempt/'three-repeat.jsonl',total_timeout=3600,per_run_timeout=900,run_one=record_with_sources)
        state['status']='completed' if code==0 else 'failed'
    except BaseException as exc: state.update(status='interrupted_or_failed',error_type=type(exc).__name__,error=str(exc))
    finally:
        state.update(finished_utc=utc(),returncode=code); put(attempt/'capture-receipt.json',state); print(json.dumps(state),flush=True)
    return code


if __name__=='__main__':
    if len(sys.argv)==3 and sys.argv[1]=='--capture': raise SystemExit(capture(Path(sys.argv[2]).resolve(strict=True)))
    require(len(sys.argv)==1,'entrypoint takes no arguments')
    raise SystemExit(bootstrap())

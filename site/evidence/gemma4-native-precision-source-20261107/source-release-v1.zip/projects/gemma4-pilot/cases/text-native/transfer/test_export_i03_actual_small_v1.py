"""Synthetic stdlib metadata tests, not native I03 measurements.

Production source pins have no CLI override. These tests patch only in-process
pins for explicitly synthetic receipts; all484 native array paths are absent.
"""
from contextlib import ExitStack
import copy
import json
import os
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

import export_i03_actual_small_v1 as e


def write(path,doc):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8');return path


class Fixture:
    def __init__(self,root):
        self.root=Path(root);self.run=self.root/'run';self.run.mkdir();self.tools=self.root/'tools';self.tools.mkdir();self.stack=ExitStack()
        files={}
        for name in [e.MAIN,e.HELPER,e.CONTROLLER]+['synthetic/tool-%02d.py'%i for i in range(17)]:
            path=self.tools/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('# synthetic-not-native '+name+'\n')
            files[name]={'sha256':e.sha(path),'size_bytes':path.stat().st_size}
        self.stack.enter_context(patch.multiple(e,MAIN_SHA=files[e.MAIN]['sha256'],HELPER_SHA=files[e.HELPER]['sha256'],CONTROLLER_SHA=files[e.CONTROLLER]['sha256']))
        manifest=write(self.tools/'tool-bundle-manifest.json',{'kind':'i03-offline-tool-bundle','files':files,'native_executions_started':0})
        self.stack.enter_context(patch.object(e,'TOOL_SHA',e.sha(manifest)))
        maps={}
        for category in ('GPU','NPU'):
            arrays={}
            for mode in e.MODES:
                for i in range(47):arrays['/synthetic-not-native/'+category+'/'+mode+'/dist-%03d.npy'%i]={'size':100,'sha256':'a'*64,'retained_at_source':True}
                arrays['/synthetic-not-native/'+category+'/'+mode+'/raw-native-logits.safetensors']={'size':100,'sha256':'b'*64,'retained_at_source':True}
            for mode in ('token','chunk63-65'):arrays['/synthetic-not-native/'+category+'/'+mode+'/final-native-kv.safetensors']={'size':100,'sha256':'c'*64,'retained_at_source':True}
            if category=='GPU':
                for index,item in enumerate(arrays.values()):
                    item.pop('retained_at_source');item['path']='missing-copied-native-arrays/%04d.safetensors'%index
            path=write(self.root/(category+'-source-map.json'),{'request':{'task':'I03','backend':category},'files':arrays,'synthetic_fixture':True})
            maps[category]={'path':str(path),'sha256':e.sha(path)}
        spec={'stage_spec_sha256':e.STAGE_SHA,'endpoints':{k:{'source_map':v} for k,v in maps.items()},'synthetic_fixture':True}
        self.spec=write(self.run/'comparison-spec.json',spec);bundle=self.run/'bundle';bundle.mkdir();scores=[];kv=[]
        kinds=['within_process_full_repeat']*6+['within_process_partition']*6+['cross_backend_full']*9+['cross_backend_cached']*2
        for index,kind in enumerate(kinds):
            folder=bundle/('score-%02d'%index);folder.mkdir();docs={}
            for name in ('targets-contract.json','distributions-contract.json','a-env.json','b-env.json','a-targets.json','b-targets.json','a-distributions.json','b-distributions.json'):
                path=write(folder/name,{'synthetic_fixture':True,'name':name});docs[name]=e.sha(path)
            scores.append({'kind':kind,'targets':{'status':'no_thresholds','coverage':{'expected':159,'paired':159},'sources':{'contract':str(folder/'targets-contract.json')}},
                'distributions':{'status':'no_thresholds','position_count':47},'frozen_document_sha256':docs,'thresholds':None,'acceptance':None})
        for index in range(4):
            folder=bundle/('kv-%02d'%index);folder.mkdir();docs={}
            for name in ('kv-contract.json','a-env.json','b-env.json','a-kv.json','b-kv.json'):
                path=write(folder/name,{'synthetic_fixture':True,'name':name});docs[name]=e.sha(path)
            kv.append({'metrics':{'status':'no_thresholds','per_tensor':{'tensor-%03d'%i:{'synthetic_fixture':True} for i in range(96)},'global':{'count':27525120},
                'sources':{'contract':str(folder/'kv-contract.json')}},'frozen_document_sha256':docs,'thresholds':None,'acceptance':None})
        scope={'independent_inputs':1,'new_model_processes_per_backend':1,'native_calls_per_backend':70,'modes_per_backend':5,'full_repeat_calls_per_backend':3,
            'fresh_process_repeatability_measured':False,'cached_mode_repeatability_measured':False,'targets_per_mode':159,'distribution_rows_per_mode':47,
            'raw_native_predictor_rows_finite_checked':1600,'full_vocabulary_rows_rederived':470,'target_scores_rederived':1590,'target_distribution_pairs':23,
            'native_final_kv_pairs':4,'native_kv_tensors_per_cached_mode':96,'cache_eviction_tested':False}
        report={'status':'i03_raw_bf16_partition_repeat_and_final_kv_checked','stage_spec_sha256':e.STAGE_SHA,'comparison_spec_sha256':e.sha(self.spec),
            'source_map_sha256':{k:v['sha256'] for k,v in maps.items()},'scope':scope,'target_distribution_pairs':scores,'native_final_kv_pairs':kv,
            'raw_derivation':{category:{mode:{'raw_sha256':'b'*64,'largest_abs_logprob_derivation_delta':0.0} for mode in e.MODES} for category in ('GPU','NPU')},
            'native_executions_started_by_admission':0,'thresholds':None,'acceptance':None,'full_core_complete':False,'synthetic_fixture':True}
        self.report=write(bundle/'i03-comparison-report.json',report)
        stdout=write(self.run/'stdout.json',{'status':report['status'],'target_distribution_pairs':23,'native_final_kv_pairs':4,'native_executions_started':0,'acceptance':None})
        stderr=self.run/'stderr.txt';stderr.write_bytes(b'')
        state={'status':'completed','returncode':0,'child_returncode':0,'task':'I03','run':str(self.run),'tools_root':str(self.tools),'scope':scope,
            'tool_manifest_sha256':e.TOOL_SHA,'whole_cpu_seconds':900,'child_work_seconds':870,'analysis_seconds':850,'native_executions_started':0,'acceptance':None,
            'comparison_spec':{'path':str(self.spec),'sha256':e.sha(self.spec)},'report':{'path':str(self.report),'sha256':e.sha(self.report)},
            'argv':['/synthetic/python','-B',str(self.tools/e.MAIN),'--spec',str(self.spec),'--spec-sha256',e.sha(self.spec),'--output-dir',str(bundle),'--timeout-seconds','850']}
        for key,path in (('stdout',stdout),('stderr',stderr)):state[key]={'path':str(path),'sha256':e.sha(path),'bytes':path.stat().st_size}
        self.controller=write(self.run/'controller-receipt.json',state)
        self.selection=write(self.root/'selection/selection-receipt.json',{'status':'ready_to_execute_frozen_cpu_controller','returncode':0,'tools_root':str(self.tools),
            'native_executions_started':0,'gpu_source_map_sha256':maps['GPU']['sha256'],'npu_source_map_sha256':maps['NPU']['sha256'],'checked_source_sha256':{},'synthetic_fixture':True})
    def close(self):self.stack.close()
    def resign_report(self,mutate):
        doc=e.load(self.report);mutate(doc);write(self.report,doc);state=e.load(self.controller);state['report']['sha256']=e.sha(self.report);write(self.controller,state)


class Tests(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.fx=Fixture(self.temp.name)
    def tearDown(self):self.fx.close();self.temp.cleanup()
    def check(self):return e.verify_controller(self.fx.controller,e.sha(self.fx.controller))
    def test_actual_controller_schema_and_external_pin(self):
        _,_,report,_=self.check();self.assertEqual(len(report['target_distribution_pairs']),23)
        with self.assertRaisesRegex(ValueError,'externally frozen'):e.verify_controller(self.fx.controller,'0'*64)
    def test_child_failure_and_resigned_native_scope_rejected(self):
        c=e.load(self.fx.controller);c['child_returncode']=True;write(self.fx.controller,c)
        with self.assertRaisesRegex(ValueError,'controller scope'):self.check()
        c['child_returncode']=0;c['native_executions_started']=1;write(self.fx.controller,c)
        with self.assertRaisesRegex(ValueError,'controller scope'):self.check()
    def test_resigned_incomplete_score_or_kv_scope_rejected(self):
        self.fx.resign_report(lambda d:d['native_final_kv_pairs'][0]['metrics']['per_tensor'].pop('tensor-095'))
        with self.assertRaisesRegex(ValueError,'native KV pair'):self.check()
    def test_resigned_wrong_raw_derivation_or_direct_argv_rejected(self):
        self.fx.resign_report(lambda d:d['raw_derivation']['NPU']['token'].update(largest_abs_logprob_derivation_delta=.01))
        with self.assertRaisesRegex(ValueError,'raw BF16'):self.check()
        self.fx.resign_report(lambda d:d['raw_derivation']['NPU']['token'].update(largest_abs_logprob_derivation_delta=0.0))
        c=e.load(self.fx.controller);c['argv'][-1]='999';write(self.fx.controller,c)
        with self.assertRaisesRegex(ValueError,'direct argv'):self.check()
    @unittest.skipUnless(os.name=='posix','production requires original absolute POSIX paths')
    def test_full_export_never_stats484_missing_arrays_and_keeps8_raw_proofs(self):
        original_stat=Path.stat;original_open=Path.open;reads=[]
        def stat(path,*args,**kwargs):
            if str(path).startswith('/synthetic-not-native/'):raise AssertionError('native array stat attempted')
            return original_stat(path,*args,**kwargs)
        def opened(path,*args,**kwargs):
            if str(path).startswith('/synthetic-not-native/'):raise AssertionError('native array open attempted')
            reads.append(str(path));return original_open(path,*args,**kwargs)
        output=Path(self.temp.name)/'export'
        with patch.object(Path,'stat',stat),patch.object(Path,'open',opened):result=e.export(self.fx.controller,e.sha(self.fx.controller),self.fx.selection,output)
        self.assertEqual((result['omitted_npy_files'],result['omitted_raw_native_files'],result['arrays_statted_opened_or_copied']),(470,14,0))
        self.assertEqual(result['frozen_comparison_documents_checked'],204);proof=e.load(result['prerequisite_path'])
        refs=[proof[k] for k in ('controller','report','comparison_spec','analysis_source','artifact_helper_source','tool_manifest')]+list(proof['source_maps'].values())
        self.assertEqual(len(refs),8)
        for ref in refs:self.assertEqual((output/'i04-prerequisite'/ref['path']).read_bytes(),Path(ref['source_path']).read_bytes())
        for ref in result['archives']:
            path=output.parent/ref['basename'];self.assertEqual(e.sha(path),ref['sha256'])
            with tarfile.open(path) as package:self.assertTrue(all(m.isfile() and not m.name.endswith(('.npy','.safetensors','.bin')) for m in package.getmembers()))
    @unittest.skipUnless(os.name=='posix','production requires original absolute POSIX paths')
    def test_frozen_document_hash_output_reuse_and_size_gate_rejected(self):
        path=self.fx.run/'bundle/score-00/a-targets.json';path.write_bytes(b'{}\n');output=Path(self.temp.name)/'bad'
        with self.assertRaisesRegex(ValueError,'metadata source SHA'):e.export(self.fx.controller,e.sha(self.fx.controller),self.fx.selection,output)
        with self.assertRaisesRegex(ValueError,'exclusive new'):e.export(self.fx.controller,e.sha(self.fx.controller),self.fx.selection,output)
        large=Path(self.temp.name)/'large.json'
        with large.open('xb') as stream:stream.seek(e.MAX_SMALL);stream.write(b' ')
        with self.assertRaisesRegex(ValueError,'exceeds16MiB'):e.Catalog(output).add(large)
    def test_duplicate_or_nonfinite_metadata_rejected(self):
        path=Path(self.temp.name)/'bad.json'
        for raw in ('{"x":1,"x":2}','{"x":NaN}'):
            path.write_text(raw)
            with self.assertRaises(ValueError):e.load(path)


if __name__=='__main__':unittest.main()

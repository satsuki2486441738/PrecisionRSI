"""Synthetic recorded CPU exporter protocol; no actual probe/model execution."""
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import run_observer_cpu_export_v1 as tool

REPO=Path(__file__).resolve().parents[5]
GOOD="""import sys,json,hashlib
from pathlib import Path
r=Path(sys.argv[sys.argv.index('--root')+1]);p=Path(sys.argv[sys.argv.index('--output')+1]);p.mkdir()
a=p.with_name(p.name+'.tar.gz');a.write_bytes(b'synthetic CPU metadata transport')
e=p.with_name(p.name+'-json-base64.txt');e.write_bytes(b'{}')
def ref(x):return {'path':str(x),'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()}
print(json.dumps({'status':'actual_observer_CPU_proof_exported','native_prerequisite_valid':True,'native_executions_started':0,'production_native_arrays_read':0,'tiny_CPU_tensor_payloads_opened_or_copied':0,'archive':ref(a),'envelope':ref(e)}))
"""


def setup(root,body):
    root=Path(root)/'R';root.mkdir();(root/'exports').mkdir();(root/'runs').mkdir();(root/tool.SUBDIR).mkdir(parents=True)
    here=root/'tools/cpu-export';here.mkdir(parents=True);producer=here/'export_observer_cpu_proof_v1.py';producer.write_text(body,'utf8')
    (here/'record_run.py').write_bytes((REPO/'skills/precision-compare/scripts/record_run.py').read_bytes())
    source=here/'run_observer_cpu_export_v1.py';source.write_bytes(Path(tool.__file__).read_bytes())
    spec=importlib.util.spec_from_file_location('synthetic_recorded_CPU_export',source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return root,module,producer


@unittest.skipUnless(os.name=='posix','actual source-host process groups are POSIX')
class Protocol(unittest.TestCase):
    def test_actual_frozen_recorder_success_and_permanent_marker(self):
        with tempfile.TemporaryDirectory() as temporary:
            root,module,producer=setup(temporary,GOOD)
            with patch.object(module,'PRODUCER_SHA',module.sha(producer)):
                self.assertEqual(module.run(root),0)
                with self.assertRaises(FileExistsError):module.run(root)
            receipts=list((root/'runs').glob('compare-observer-cpu-proof-export-*/controller-receipt.json'));self.assertEqual(len(receipts),1)
            doc=module.read(receipts[0]);self.assertEqual(doc['status'],'completed');self.assertEqual(doc['child_returncode'],0)
            self.assertEqual(doc['result']['production_native_arrays_read'],0)

    def test_actual_child7_preserves_failure_logs_and_marker(self):
        with tempfile.TemporaryDirectory() as temporary:
            root,module,producer=setup(temporary,"raise SystemExit(7)\n")
            with patch.object(module,'PRODUCER_SHA',module.sha(producer)):self.assertEqual(module.run(root),2)
            doc=module.read(next((root/'runs').glob('compare-observer-cpu-proof-export-*/controller-receipt.json')))
            self.assertEqual(doc['status'],'failed');self.assertEqual(doc['child_returncode'],7);self.assertFalse(doc['timed_out'])
            self.assertTrue((root/tool.SUBDIR/'cpu-proof-export-worker-once.json').exists())

    def test_timeout_reaps_actual_generic_child(self):
        with tempfile.TemporaryDirectory() as temporary:
            root,module,producer=setup(temporary,'import time\ntime.sleep(60)\n')
            with patch.object(module,'PRODUCER_SHA',module.sha(producer)),patch.object(module,'GENERIC',.05):self.assertEqual(module.run(root),2)
            doc=module.read(next((root/'runs').glob('compare-observer-cpu-proof-export-*/controller-receipt.json')))
            self.assertTrue(doc['timed_out']);generic=module.read(doc['generic_receipt']['path'])
            with self.assertRaises(ProcessLookupError):os.killpg(generic['child_pid'],0)

    def test_wrong_source_refused_before_permanent_marker(self):
        with tempfile.TemporaryDirectory() as temporary:
            root,module,producer=setup(temporary,GOOD)
            with self.assertRaisesRegex(ValueError,'SHA'):module.run(root)
            self.assertFalse((root/tool.SUBDIR/'cpu-proof-export-worker-once.json').exists())


if __name__=='__main__':unittest.main()

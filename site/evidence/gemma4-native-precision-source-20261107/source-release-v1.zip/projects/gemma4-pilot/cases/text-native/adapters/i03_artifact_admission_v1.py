"""Independent source-map-aware I03 raw/native/state artifact admission.

No model/framework/device import. Uses the frozen I01 scalar-fsum BF16 decoder;
does not call the collector's coordinate, numerical or cache validators.
"""
import hashlib
import math
from pathlib import Path,PurePosixPath
import struct

import numpy as np
import i01_admission_compare_v1 as old
import i03_expected_inventory_v1 as expected
import i03_prerequisite_v1 as proof_helper

require=old.require
canonical=old.canonical
load=old.load
sha=old.sha
origin=old.origin
child=old.child
VOCABULARY=262144
INPUT_SHA=expected.INPUT_SHA256
STAGE_SHA=expected.STAGE_SHA256
EXPECTED_SHA='5c8cdcc3c5b88732ccd589d95fa5ce86bd9eac71f83620e3bc48bcfc3b3b9a25'
EXPECTED_SOURCE_SHA='9c0d5cad39ae932d95fee34db3ee91cbb6232ed1ab554e6004fadc189425a7f8'
PROOF_SHA='2d26531b83af3a3f0acf63c9b8472ce547a5bd288de6f92cd390a38a6011d840'
PROOF_HELPER_SHA='e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36'
OLD_SOURCE_SHA='f7fe91cdcebeec910efed4579ecf379fd665cf305223a3fa77858004db81858a'
MODES=['full-r1','full-r2','full-r3','token','chunk63-65']
LAYERS,SLIDING_LAYERS,FULL_LAYERS=48,40,8
SLIDING_HEADS,SLIDING_DIM,FULL_HEADS,FULL_DIM=8,256,1,512
KV_BYTES=55050240
CAP_BYTES=1342177280
NORMALIZATION='Offline NumPy float64 log_softmax of copied native values'


def verify_tools():
    old.verify_tools()
    require(sha(old.__file__)==OLD_SOURCE_SHA and sha(expected.__file__)==EXPECTED_SOURCE_SHA and sha(proof_helper.__file__)==PROOF_HELPER_SHA,
        'independent raw/inventory/prerequisite source changed')


class Endpoint(old.Endpoint):
    def get(self,name,expected_sha=None):
        name=origin(name);entry=self.files[name]
        if entry.get('retained_at_source') is True and PurePosixPath(name).name=='final-native-kv.safetensors':
            require(self.retained_root is not None and 'path' not in entry and type(entry.get('size')) is int and
                isinstance(entry.get('sha256'),str) and old.HEX.fullmatch(entry['sha256']),'retained KV requires explicit NPU root')
            path=Path(name)
            require(path.is_absolute() and path.is_relative_to(self.retained_root) and path.resolve(strict=True).is_relative_to(self.retained_root),
                'retained final KV escapes explicit root')
            path=path.resolve(strict=True);digest=sha(path)
            require(path.is_file() and path.stat().st_size==entry['size'] and digest==entry['sha256'] and
                (expected_sha is None or digest==expected_sha),'retained final KV bytes differ')
            self.checked[name]=digest;self.resolved[name]=str(path);return path
        return super().get(name,expected_sha)


def file_ref(endpoint,logical):
    actual=endpoint.get(logical);return {'path':logical,'sha256':sha(actual),'size_bytes':actual.stat().st_size}


def safe_relative(name):
    p=PurePosixPath(name)
    require(isinstance(name,str) and name and not p.is_absolute() and '\\' not in name and str(p)==name and
        all(part not in ('','.','..') for part in name.split('/')),'canonical relative product path required')
    return name


def copied_proof(endpoint,output,folder):
    logical=child(output,'prerequisite/prerequisite.json');source=endpoint.get(logical,PROOF_SHA);doc=load(source)
    refs=[doc[k] for k in ('controller','report','comparison_spec','analysis_source')]+list(doc['source_maps'].values())
    require(len(refs)==6 and len({r['path'] for r in refs})==6,'six distinct copied I01 proof documents required')
    folder.mkdir()
    with (folder/'prerequisite.json').open('xb') as stream:stream.write(source.read_bytes())
    for ref in refs:
        relative=safe_relative(ref['path']);original=child(output,'prerequisite/'+relative)
        actual=endpoint.get(original,ref['sha256']);target=folder/relative;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:stream.write(actual.read_bytes())
    proof_helper.prerequisite(folder/'prerequisite.json',PROOF_SHA)
    return {'prerequisite/prerequisite.json',*('prerequisite/'+r['path'] for r in refs)}


def tensor_metadata(record,shape,device):
    require(isinstance(record,dict) and canonical(record.get('shape'))==canonical(shape) and record.get('dtype')=='torch.bfloat16' and
        record.get('device')==device and type(record.get('numel')) is int and record['numel']==math.prod(shape),'native cache tensor metadata differs')
    # Storage/version APIs may be unsupported; these are recorded probe gaps,
    # not fabricated pointers or an attestation of loaded parameter bytes.
    for key in ('stride','version','storage'):
        value=record.get(key)
        if isinstance(value,dict) and value.get('unavailable') is True:
            require(isinstance(value.get('error_type'),str) and isinstance(value.get('error'),str),'unrecorded tensor metadata probe gap')
        elif key=='stride':require(isinstance(value,list) and len(value)==len(shape) and all(type(x) is int and x>=0 for x in value),'native stride metadata differs')
        elif key=='version':require(type(value) is int,'native version counter metadata differs')
        else:require(isinstance(value,dict) and set(value)=={'data_ptr','nbytes','offset'} and all(type(value[k]) is int and value[k]>=0 for k in value),
            'native storage metadata differs')


def layer_descriptors(types,prefix):
    result={}
    for index,kind in enumerate(types):
        heads,dim=(SLIDING_HEADS,SLIDING_DIM) if kind=='sliding_attention' else (FULL_HEADS,FULL_DIM)
        for suffix in ('key','value'):result['layer-%03d.%s'%(index,suffix)]=[1,heads,prefix,dim]
    return result


def cache_observation(observation,prefix,types,device):
    if prefix==0:
        require(canonical(observation)==canonical({'present':False,'sequence_length':0,'layers':[]}),'fresh cached mode must begin without a cache/layers')
        return
    require(observation.get('present') is True and type(observation.get('sequence_length')) is int and observation['sequence_length']==prefix and
        isinstance(observation.get('class'),str) and observation['class'] and (observation.get('offloading') is False or observation.get('offloading') is None) and
        isinstance(observation.get('layers'),list) and len(observation['layers'])==LAYERS,'complete native cache observation differs')
    descriptors=layer_descriptors(types,prefix)
    for index,layer in enumerate(observation['layers']):
        require(type(layer.get('index')) is int and layer['index']==index and layer.get('configured_attention')==types[index] and
            type(layer.get('sequence_length')) is int and layer['sequence_length']==prefix and
            isinstance(layer.get('class'),str) and layer['class'] and type(layer.get('is_initialized')) is bool and layer['is_initialized'],
            'actual cache layer identity/growth differs')
        for name,suffix in (('keys','key'),('values','value')):tensor_metadata(layer[name],descriptors['layer-%03d.%s'%(index,suffix)],device)


def native_kv(path,descriptors):
    """Independently bound every BF16 key, offset and finite scalar coordinate."""
    path=Path(path)
    with path.open('rb') as stream:
        prefix=stream.read(8);require(len(prefix)==8,'truncated native KV prefix');length=struct.unpack('<Q',prefix)[0]
        require(0<length<=131072,'bounded native KV header required');raw=stream.read(length);require(len(raw)==length,'truncated native KV header')
    header=old.parse(raw);require(set(header)-{'__metadata__'}==set(descriptors),'exact native KV tensor-key inventory differs')
    if '__metadata__' in header:require(isinstance(header['__metadata__'],dict) and all(isinstance(v,str) for v in header['__metadata__'].values()),'KV metadata must be strings')
    spans=[];count=0
    for key,shape in descriptors.items():
        record=header[key];require(set(record)=={'dtype','shape','data_offsets'} and record['dtype']=='BF16' and record['shape']==shape,'KV native dtype/shape differs')
        start,end=record['data_offsets'];require(type(start) is int and type(end) is int and start>=0 and end-start==math.prod(shape)*2,'KV tensor offsets/size differ')
        spans.append((start,end));count+=math.prod(shape)
    offset=0
    for start,end in sorted(spans):require(start==offset,'native KV payload gap/overlap');offset=end
    require(offset==KV_BYTES and path.stat().st_size==8+length+offset,'native KV complete payload size differs')
    bits=np.memmap(path,mode='r',dtype='<u2',offset=8+length,shape=(offset//2,))
    try:
        for start in range(0,len(bits),1048576):
            values=(np.asarray(bits[start:start+1048576],dtype='<u4')<<np.uint32(16)).view('<f4')
            require(np.isfinite(values).all(),'native KV contains nonfinite values')
    finally:bits._mmap.close()
    return {'tensor_count':len(descriptors),'finite_coordinate_count':count,'data_bytes':offset,
        'arrays':{key:{'path':str(path),'key':key} for key in descriptors}}


def rng_descriptor(rng,before=False):
    require(set(rng)=={'python','numpy','torch_cpu','device0'},'complete observed RNG source inventory required')
    formats={'python':'untruncated Python random.getstate tuple repr UTF8','numpy':'canonical-JSON-header UTF8 + NUL + complete uint32LE state words',
        'torch_cpu':'complete Torch generator state ByteTensor bytes','device0':'complete Torch generator state ByteTensor bytes'}
    for key,observation in rng.items():
        if observation.get('unavailable') is True:
            require(key in ('torch_cpu','device0') and all(isinstance(observation.get(k),str) for k in ('error_type','error')),'unrecorded RNG gap')
        else:require(isinstance(observation.get('sha256'),str) and old.HEX.fullmatch(observation['sha256']) and observation.get('format')==formats[key],
            'complete untruncated RNG state digest/format missing')
    header=rng['numpy']['header'];require(set(header)=={'version','algorithm','word_count','word_encoding','position','has_gauss','cached_gaussian_binary64_le_hex'} and
        type(header['version']) is int and header['version']==1 and header['algorithm']=='MT19937' and type(header['word_count']) is int and
        header['word_count']==624 and header['word_encoding']=='uint32-little-endian' and
        type(header['position']) is int and 0<=header['position']<=624 and type(header['has_gauss']) is int and header['has_gauss'] in (0,1) and
        isinstance(header['cached_gaussian_binary64_le_hex'],str) and len(header['cached_gaussian_binary64_le_hex'])==16 and
        all(char in '0123456789abcdef' for char in header['cached_gaussian_binary64_le_hex']),'NumPy complete generator header differs')
    if before:require(header['position']==624 and header['has_gauss']==0 and header['cached_gaussian_binary64_le_hex']=='0000000000000000',
        'NumPy before-mode seed0 state coordinates differ')


def inspect_mode(endpoint,output,mode,plan,inventory,types,baseline,baseline_sha,policy,device):
    prefix=child(output,'modes/'+mode);sequence=old.expected.load(endpoint.get(child(output,'input.json'))) # original IDs stay private
    sequence=sequence['prompt']+sequence['continuation'];positions=[x['position'] for x in inventory['distribution_positions']]
    paths={name:endpoint.get(child(prefix,name)) for name in ('raw-native-logits.safetensors','target-scores.json','distributions.json','events.json',
        'final-cache.json','capture-summary.json','model-state-after.json','state-control.json')}
    raw_sha=sha(paths['raw-native-logits.safetensors']);scores_doc=load(paths['target-scores.json']);distribution=load(paths['distributions.json'])
    for doc,kind in ((scores_doc,'i03-native-target-scores'),(distribution,'i03-native-distribution-rows')):
        fixed={'schema_version':1,'task':expected.TASK,'kind':kind,'mode':mode,'stage_spec_sha256':STAGE_SHA,'input_sha256':INPUT_SHA,
            'raw_logits_sha256':raw_sha,'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':NORMALIZATION}
        require(all(k in doc and canonical(doc[k])==canonical(v) for k,v in fixed.items()),'mode raw-derived source identity differs')
    scores=scores_doc['scores'];rows=distribution['positions'];require(len(scores)==159 and len(rows)==47,'mode159/47 coverage differs')
    for row,coordinate in zip(scores,inventory['all_targets']):
        require(all(k in row and canonical(row[k])==canonical(v) for k,v in coordinate.items()) and type(row.get('prediction_position')) is int and
            row['prediction_position']==coordinate['position']-1 and type(row.get('logprob')) in (int,float) and math.isfinite(row['logprob']) and row['logprob']<=0,
            'all causal target coordinates/values required')
    normalized_rows=[];by_position={}
    for item,coordinate in zip(rows,inventory['distribution_positions']):
        p=coordinate['position'];name='dist-p%03d'%p;descriptor={'path':name+'.npy','row':0}
        roles=(['prompt_sample'] if p in [i*127//15 for i in range(16)] else [])+(['continuation'] if p>=127 else [])
        require(all(k in item and canonical(item[k])==canonical(v) for k,v in coordinate.items()) and item.get('roles')==roles and
            item.get('record')==name+'.json' and item.get('scores')==descriptor,'mode prescribed full-row inventory differs')
        record=endpoint.json(child(prefix,name+'.json'));wanted={**coordinate,'task':expected.TASK,'mode':mode,'stage_spec_sha256':STAGE_SHA,
            'input_sha256':INPUT_SHA,'raw_logits_sha256':raw_sha,'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64',
            'normalization':NORMALIZATION,'roles':roles,'target_position':p+1,'token':sequence[p+1],'scores':descriptor,'logprob':scores[p]['logprob']}
        require(all(k in record and canonical(record[k])==canonical(v) for k,v in wanted.items()),'mode retained row identity differs')
        actual=endpoint.get(child(prefix,name+'.npy'));array=np.load(actual,mmap_mode='r',allow_pickle=False)
        try:require(array.shape==(1,VOCABULARY) and array.dtype==np.dtype('float64') and np.isfinite(array).all() and float(array.max())<=0 and
            float(array[0,sequence[p+1]])==scores[p]['logprob'],'mode full-vocabulary shape/dtype/value differs')
        finally:array._mmap.close()
        by_position[p]=actual;normalized_rows.append({**coordinate,'scores':{'path':str(actual),'row':0}})
    events=load(paths['events.json']);require(len(events)==plan['native_forward_calls'],'mode native call count differs');previous=None
    for event,call in zip(events,plan['calls']):
        fixed={**call,'mode':mode,'use_cache':plan['use_cache'],'past_key_values_is_none':call['call_index']==0,'logits_to_keep':0,
            'labels_supplied':False,'shared_kv_states_supplied':False,'native_logits_shape':[1,call['end']-call['start'],VOCABULARY],'native_logits_dtype':'torch.bfloat16'}
        require(all(k in event and canonical(event[k])==canonical(v) for k,v in fixed.items()),'mode full/cache causal native event differs')
        if plan['use_cache']:
            cache_observation(event['cache_before'],call['start'],types,device);cache_observation(event['cache_after'],call['end'],types,device)
            if previous is not None:require(canonical(event['cache_before'])==canonical(previous),'cache changed between native call boundaries')
            previous=event['cache_after']
        else:
            cache_observation(event['cache_before'],0,types,device);cache_observation(event['cache_after'],0,types,device)
    require(canonical(load(paths['model-state-after.json']))==canonical(baseline),'persistent loaded model state changed during mode')
    control=load(paths['state-control.json']);require(control.get('mode')==mode and type(control.get('seed_reset',{}).get('seed')) is int and
        control['seed_reset']['seed']==0 and canonical(control['seed_reset']['settings'])==canonical(policy) and canonical(control['math_policy'])==canonical(policy) and
        control['baseline_model_state_sha256']==baseline_sha and control['model_state_after_sha256']==sha(paths['model-state-after.json']),
        'mode observed seed/model/policy state-control chain differs')
    if device=='cuda:0':require(all(type(control['seed_reset'].get(k)) is int and control['seed_reset'][k]==0 for k in
        ('seed','python_random_seed','numpy_seed','torch_initial_seed','cuda_initial_seed')),'GPU per-mode seed reset differs')
    rng=control['rng_before'];rng_descriptor(rng,before=True);rng_descriptor(control['rng_after'])
    native=old.raw_tensor(paths['raw-native-logits.safetensors']);maximum=0.0
    try:
        for p in range(160):
            if p==159:old.native_values(native[p]);continue
            derived=old.independent_logprobs(native[p]);delta=abs(float(derived[sequence[p+1]])-scores[p]['logprob'])
            require(delta<=old.ATOL,'raw BF16 target rederivation differs');maximum=max(maximum,delta)
            if p in by_position:
                array=np.load(by_position[p],mmap_mode='r',allow_pickle=False)
                try:delta=float(np.max(np.abs(array[0]-derived)))
                finally:array._mmap.close()
                require(delta<=old.ATOL,'raw BF16 full-row rederivation differs');maximum=max(maximum,delta)
    finally:native._mmap.close()
    summary=load(paths['capture-summary.json']);fixed={'schema_version':1,'task':expected.TASK,'mode':mode,'native_forward_calls':plan['native_forward_calls'],
        'use_cache':plan['use_cache'],'cached_decode_calls':plan['cached_decode_calls'],'native_logits_shape':[1,160,VOCABULARY],
        'native_logits_dtype':'torch.bfloat16','targets':159,'sampled_distributions':47,'unscored_native_prediction_indices':[159],
        'raw_logits':file_ref(endpoint,child(prefix,'raw-native-logits.safetensors')),'final_cache_sequence_length':160 if plan['use_cache'] else None,
        'final_kv_tensors':LAYERS*2 if plan['use_cache'] else 0}
    require(all(k in summary and canonical(summary[k])==canonical(v) for k,v in fixed.items()),'native mode capture summary differs')
    cache=load(paths['final-cache.json']);kv=None
    if plan['use_cache']:
        fixed={'schema_version':1,'kind':'i03-final-native-cache','task':expected.TASK,'mode':mode,'input_sha256':INPUT_SHA,'stage_spec_sha256':STAGE_SHA,
            'native_dtype':'torch.bfloat16','data_bytes':KV_BYTES,'safetensors':file_ref(endpoint,child(prefix,'final-native-kv.safetensors'))}
        require(all(k in cache and canonical(cache[k])==canonical(v) for k,v in fixed.items()) and canonical(cache['cache'])==canonical(previous),
            'final native K/V metadata differs from last actual call')
        descriptors=layer_descriptors(types,160);items=cache['tensors']
        require(len(items)==LAYERS*2 and len({item['key'] for item in items})==LAYERS*2 and {item['key'] for item in items}==set(descriptors),'all native K/V keys required')
        for item in items:
            index=int(item['key'].split('.')[0].split('-')[1]);kind=item['key'].split('.')[1];shape=descriptors[item['key']]
            require(canonical(item)==canonical({'key':item['key'],'layer':index,'kind':kind,'shape':shape,'dtype':'BF16','data_bytes':math.prod(shape)*2,
                'array':{'path':'final-native-kv.safetensors','key':item['key']}}),'KV tensor coordinate/dtype/byte descriptor differs')
        kv=native_kv(endpoint.get(child(prefix,'final-native-kv.safetensors')),descriptors)
        kv.update(sha256=cache['safetensors']['sha256'],descriptors=descriptors,configured_types=types,observation=cache['cache'])
    else:require(cache.get('schema_version')==1 and cache.get('task')==expected.TASK and cache.get('mode')==mode and cache.get('cache',object()) is None,
        'full cache-off mode returned a final cache')
    return {'mode':mode,'scores':[{k:row[k] for k in ('sample','position','token','logprob')} for row in scores],'positions':normalized_rows,
        'summary':summary,'rng_before':rng,'rng_after':control['rng_after'],'raw_sha256':raw_sha,'raw_derivation_max_abs_delta':maximum,
        'final_kv':kv,'mode_plan':plan}


def inspect_output(endpoint,outer,proof_folder):
    output=origin(outer['output_dir']);inp=endpoint.get(outer['input_path'],INPUT_SHA)
    stage=endpoint.get(outer['stage_spec_source_path'],STAGE_SHA);external=endpoint.get(outer['expected_inventory_source_path'],EXPECTED_SHA)
    inventory=expected.verify(external,inp,stage)
    manifest_path=endpoint.get(child(output,'artifacts-manifest.json'),outer['artifacts_manifest_sha256']);manifest=load(manifest_path)
    require(manifest.get('kind')=='i03-capture-artifacts' and manifest.get('task')==expected.TASK and manifest.get('backend')==outer['backend'].lower() and
        manifest.get('stage_spec_sha256')==STAGE_SHA and manifest.get('input_sha256')==INPUT_SHA and manifest.get('expected_inventory_sha256')==EXPECTED_SHA and
        manifest.get('i01_prerequisite_sha256')==PROOF_SHA and manifest.get('acceptance') is None,'I03 recursive manifest identity differs')
    files=manifest['files'];observed={name[len(output)+1:] for name in endpoint.files if name.startswith(output+'/')}
    require(observed==set(files)|{'artifacts-manifest.json','status.json'},'unmapped extra/missing capture artifact')
    total=0;paths={}
    for name,ref in files.items():
        safe_relative(name);require(set(ref)=={'sha256','size_bytes'} and type(ref['size_bytes']) is int and ref['size_bytes']>=0,'invalid recursive artifact descriptor')
        path=endpoint.get(child(output,name),ref['sha256']);require(path.stat().st_size==ref['size_bytes'],'recursive artifact size differs')
        total+=ref['size_bytes'];paths[name]=path
    require(total<=CAP_BYTES,'capture products exceed1.25GiB bound')
    require(sha(paths['input.json'])==INPUT_SHA and sha(paths['stage-spec.json'])==STAGE_SHA and sha(paths['expected-inventory.json'])==EXPECTED_SHA and
        external.read_bytes()==paths['expected-inventory.json'].read_bytes(),'retained independent input/stage/expected bytes differ')
    require(sha(endpoint.get(outer['i01_prerequisite_source_path'],PROOF_SHA))==sha(paths['prerequisite/prerequisite.json'])==PROOF_SHA,'original I01 prerequisite not preserved')
    required={'input.json','stage-spec.json','expected-inventory.json','snapshot-verification.json','loaded-model-inventory.json','loaded-model-state.json','runtime.json',
        'policy-before-load.json','policy-after-load.json','policy-after-capture.json','capture-summary.json'}|copied_proof(endpoint,output,proof_folder)
    if outer['backend']=='NPU':required.add('driver-version-provenance.json')
    runtime=load(paths['runtime.json']);baseline=load(paths['loaded-model-state.json']);policy=runtime['math_policy'];baseline_sha=sha(paths['loaded-model-state.json'])
    require(type(baseline.get('model_object_id')) is int and baseline['model_object_id']>0 and isinstance(baseline.get('class'),str) and
        baseline['class'].endswith('.Gemma4UnifiedForConditionalGeneration') and baseline['parameters'] and
        all(flag is False for _,flag in baseline['module_training_flags']),'loaded model identity/eval state differs')
    require(canonical(load(paths['loaded-model-inventory.json'])['config'])==canonical(baseline['config']),'loaded config metadata inventories differ')
    config=baseline['config']['text_config'];types=config['layer_types'];require(len(types)==LAYERS and types.count('sliding_attention')==SLIDING_LAYERS and
        types.count('full_attention')==FULL_LAYERS and config['num_key_value_heads']==SLIDING_HEADS and config['num_global_key_value_heads']==FULL_HEADS and
        config['head_dim']==SLIDING_DIM and config['global_head_dim']==FULL_DIM and config['num_kv_shared_layers']==0,'configured48-layer attention layout differs')
    modes={};anchor=None
    for plan in inventory['modes']:
        mode=plan['id'];names={'raw-native-logits.safetensors','target-scores.json','distributions.json','events.json','final-cache.json','capture-summary.json','model-state-after.json','state-control.json'}
        names|={'dist-p%03d%s'%(p['position'],suffix) for p in inventory['distribution_positions'] for suffix in ('.json','.npy')}
        if plan['use_cache']:names.add('final-native-kv.safetensors')
        required|={'modes/'+mode+'/'+name for name in names}
        modes[mode]=inspect_mode(endpoint,output,mode,plan,inventory,types,baseline,baseline_sha,policy,runtime['device_argument'])
        if anchor is None:anchor=modes[mode]['rng_before']
        require(canonical(modes[mode]['rng_before'])==canonical(anchor),'mode resets did not restore the same observed generator states')
    require(set(files)==required and len(files)==(530 if outer['backend']=='GPU' else 531),'exact5mode product inventory differs')
    summary=load(paths['capture-summary.json']);require(summary.get('task')==expected.TASK and summary.get('stage_spec_sha256')==STAGE_SHA and
        summary.get('native_forward_calls_total')==70 and summary.get('model_loads')==1 and canonical(summary['modes'])==canonical([modes[m]['summary'] for m in MODES]) and
        summary.get('acceptance') is None,'one loaded model/70call aggregate capture summary differs')
    status_path=endpoint.get(child(output,'status.json'));status=load(status_path)
    require(status.get('status')=='completed' and status.get('task')==expected.TASK and status.get('backend')==outer['backend'].lower() and
        status.get('stage_spec_sha256')==STAGE_SHA and type(status.get('rank')) is int and status['rank']==0 and status.get('modes')==MODES and
        status.get('native_forward_calls_total')==70 and status.get('model_loads')==1 and status.get('acceptance') is None and
        status.get('full_core_complete') is False and status.get('artifacts_manifest_sha256')==sha(manifest_path),'terminal I03 manifest binding differs')
    return {'inventory':inventory,'manifest':manifest,'manifest_sha256':sha(manifest_path),'runtime':runtime,'paths':paths,'modes':modes,
        'status_path':str(status_path),'loaded_model_state_sha256':baseline_sha,'configured_layer_types':types,'capture_product_bytes':total}

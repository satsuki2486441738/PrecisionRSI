"""CPU-only observer admission and frozen shared score/distribution/tensor math.

Activation stays closed until actual complete endpoint/source-map pins arrive.
Original capture/receipt JSON is never rewritten. New rank-status adapters cite
the admitted TP1 allocation and original status bytes explicitly.
"""
import argparse
import ast
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
import signal
import uuid

import observer_artifact_admission_v2 as native
import compare_tensors

old=native.old
require,canonical,load,sha,child=native.require,native.canonical,native.load,native.sha,native.child
put=old.put
argument=old.argument
HELPER_SHA=None
ACTUAL_ENDPOINTS={'GPU':None,'NPU':None}
COMMON_SHA='89270de32c6f6b5c60fd8d6408058ab2afe36188730c7c95c321ffd36221f3e2'
ENTRY_SHA='e0fd43dd50f31b7e4f8280616f7b2655ff22e1166e41e6c229206777b61f3191'
COLLECTOR_SHA='774b5cb210f294a23d6865f863d5facdf537c3ed3064ae39027425797b83101c'
LAUNCHERS={'GPU':('h100_observer_lifecycle_v2.py','3083f7b09f37f6c67e2bc49293231ace71038abc7c298025341882534c4a211a'),
    'NPU':('npu_observer_launcher_v1.py','1e37d7d146217f7e289fc226f77f2a6ac1b9150b7a49a7f217410d120da5a1ae')}
SOURCE_MAP_KEYS={'path','sha256'}
MAX_METADATA=128*1024**2


def verify_tools(activation=True):
    native.verify_tools()
    require(isinstance(HELPER_SHA,str) and old.HEX.fullmatch(HELPER_SHA) and sha(native.__file__)==HELPER_SHA,
        'independent observer artifact helper remains unready or changed')
    require(Path(compare_tensors.__file__).resolve()==old.prior.REPO/'skills/precision-compare/scripts/compare_tensors.py',
        'shared tensor comparator imported outside frozen repository')
    if activation:require(all(isinstance(v,dict) and set(v)=={'source_map_sha256','outer_receipt_sha256'} and
        all(isinstance(x,str) and old.HEX.fullmatch(x) for x in v.values()) for v in ACTUAL_ENDPOINTS.values()),
        'actual completed observer endpoints remain unready; no analysis activation')


def frozen_sources(endpoint,outer,claim):
    sources=outer['source_sha256'];require(isinstance(sources,dict) and len(outer['dependency_paths'])==len(set(outer['dependency_paths'])) and set(outer['dependency_paths'])==set(sources),
        'complete outer frozen source inventory differs')
    for path,digest in sources.items():require(isinstance(digest,str) and old.HEX.fullmatch(digest) and sha(endpoint.get(path,digest))==digest,'original source bytes differ')
    require(canonical(endpoint.json(child(claim,'sources-before.json')))==canonical(sources)==canonical(endpoint.json(child(claim,'sources-after.json'))),
        'original source-before/after maps differ');return sources


def runtime_copies(endpoint,outer,runtime,category):
    packages=runtime['package_sources'];implementation=runtime['implementation_sources'];base={'modeling','masking_utils','torch_dispatch','module_hooks'}
    require(set(packages)==({'torch','numpy','transformers'} if category=='GPU' else {'torch','numpy','transformers','torch_npu'}) and
        base<=set(implementation) and any(k.startswith('rotary/') for k in implementation) and all(k in base or k.startswith('rotary/') for k in implementation) and
        implementation['modeling']==runtime['model_identity']['modeling_source'],'actual package/model/mask/dispatch/hook/rotary source inventory differs')
    refs={}
    def add(item):
        require(set(item)=={'path','sha256','size_bytes'} and (item['path'] not in refs or refs[item['path']]==item),'original runtime aliases conflict');refs[item['path']]=item
    for item in [*packages.values(),*implementation.values()]:add(item)
    if category=='GPU':
        def visit(value):
            if isinstance(value,dict):
                if set(value)=={'path','sha256','size_bytes'} and str(value['path']).endswith(('.py','.pyi')):add(value)
                for item in value.values():visit(item)
            elif isinstance(value,list):
                for item in value:visit(item)
        visit(runtime)
    frozen=endpoint.json(outer['runtime_source_map_path'],outer['runtime_source_map_sha256']);require(set(frozen)==set(refs),'complete actual runtime preserved-copy map differs')
    for logical,item in refs.items():
        copied=frozen[logical];require(set(copied)==set(item) and copied['sha256']==item['sha256'] and copied['size_bytes']==item['size_bytes'],'runtime original/copy bytes differ')
        for path in (logical,copied['path']):require(endpoint.get(path,item['sha256']).stat().st_size==item['size_bytes'],'runtime source size differs')
    claim=str(PurePosixPath(outer['runtime_source_map_path']).parent);path=child(claim,'runtime-packages-before.json' if category=='GPU' else 'native-runtime-sources.json')
    observed=endpoint.json(path,outer['source_sha256'][path])
    if category=='GPU':require(set(observed)=={x['path'] for x in packages.values()} and all(observed[x['path']]['sha256']==x['sha256'] and observed[x['path']]['size_bytes']==x['size_bytes'] for x in packages.values()),'pre-model GPU package source differs')
    else:require(canonical(observed)==canonical(packages),'pre-model NPU package source differs')
    return {key:item['sha256'] for key,item in implementation.items()}


def capture_sources(endpoint,outer,runtime):
    case='projects/gemma4-pilot/cases/text-native';refs=runtime['sources']
    fixed={'observer/observer_common_v2.py':COMMON_SHA,'observer/observer_native_v2.py':ENTRY_SHA,'observer/observer_collectors_v1.py':COLLECTOR_SHA,
        'observer/observer_prerequisite_v1.py':native.PROOF_SOURCE_SHA,case+'/adapters/observer_expected_inventory_v1.py':native.EXPECTED_SOURCE_SHA,
        case+'/adapters/i01_common_v1.py':'fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c',
        case+'/adapters/i03_common_v1.py':'5cf67f53b5392e4425c4534ec6f97961066c190d24dc1280f31e66781a0fe03a',
        case+'/adapters/i03_prerequisite_v1.py':'e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36',
        case+'/transfer/export_observer_cpu_proof_v1.py':'cbad23821a46454426a0e61a017a3adb618b8f7a319aea9c92f383d248fe2bf5'}
    for key,digest in fixed.items():require(refs[key]['sha256']==digest,'reviewed observer dependency differs: '+key)
    p=endpoint.get(refs[case+'/adapters/i01_common_v1.py']['path'],fixed[case+'/adapters/i01_common_v1.py']);pins=None
    for node in ast.parse(p.read_bytes()).body:
        if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='PINNED' for x in node.targets):pins=ast.literal_eval(node.value)
    require(isinstance(pins,dict) and len(pins)==9,'original nine loader dependencies required')
    for key,digest in pins.items():require(refs[key]['sha256']==digest,'original loader dependency source differs')
    for item in refs.values():require(set(item)=={'path','sha256','size_bytes'} and endpoint.get(item['path'],item['sha256']).stat().st_size==item['size_bytes'],'actual source reference bytes differ')
    require(refs['observer/observer_native_v2.py']['path']==outer['collector_path'],'actual entry source differs');return refs


def backend_identity(endpoint,outer,runtime,paths,sources,claim,reservation,category):
    refs=capture_sources(endpoint,outer,runtime);implementation=runtime_copies(endpoint,outer,runtime,category)
    identity=runtime['model_identity'];require(identity['model_class']=='Gemma4UnifiedForConditionalGeneration' and identity['model_type']=='gemma4_unified' and
        identity['parameter_dtypes']==['torch.bfloat16'] and identity['actual_attention']=='eager' and identity['observed_config_commit'] in (None,old.prior.npu.REVISION) and
        'logits_to_keep' in identity['forward_signature'] and sha(paths['snapshot-verification.json'])==identity['snapshot_receipt_sha256'],'actual loaded checkpoint/class/dtype differs')
    metadata=refs['projects/gemma4-pilot/cases/text-native/adapters/upstream-identity.json'];require(metadata['sha256']==old.prior.npu.METADATA_SHA,'official upstream metadata differs')
    model=old.prior.npu.snapshot_identity(load(paths['snapshot-verification.json']),endpoint.json(metadata['path'],metadata['sha256']),identity['model_class'])
    policy=runtime['math_policy'];require(canonical(policy)==canonical(load(paths['policy-after-load.json']))==canonical(load(paths['policy-after-capture.json'])),'backend policy changed during observer')
    allocation=endpoint.json(outer['allocation_path'],outer['allocation_sha256']);physical=runtime['runtime_uuid']
    require(isinstance(physical,str) and str(uuid.UUID(physical))==physical and uuid.UUID(physical).int and allocation['physical_device_id']==physical and
        runtime['allocation_receipt_sha256']==outer['allocation_sha256'] and reservation['allocation_id']==allocation['allocation_id'] and allocation['logical_ordinal']==0 and type(allocation['logical_ordinal']) is int,
        'original allocation/runtime selected UUID/ordinal differs')
    versions=runtime['versions'];argv=outer['argv']
    if category=='GPU':
        require(versions=={'torch':'2.9.0+cu128','transformers':'5.10.1','cuda_runtime':'12.8','numpy':'1.26.4'} and runtime['device_name']=='NVIDIA H100 80GB HBM3' and
            canonical(policy)==canonical(old.prior.gpu.FROZEN_POLICY) and allocation['vendor']=='NVIDIA' and allocation['visible_count']==1,'actual H100 stack/policy/visible TP1 differs')
        initial=runtime['initial_rng_observations'];require(all(type(initial.get(k)) is int and initial[k]==0 for k in ('seed','python_random_seed','numpy_seed','torch_initial_seed','cuda_initial_seed')) and
            canonical(initial['settings'])==canonical(policy)==canonical(load(paths['policy-before-load.json'])['settings']),'initial GPU seed/policy differs')
        probe=endpoint.json(allocation['native_source'],allocation['native_source_sha256']);platform=endpoint.json(allocation['evidence_source'],allocation['platform_source_sha256'])
        require(probe['status']=='native_preflight_passed' and probe['runtime_uuid']==physical and probe['visible_count']==1 and probe['device_name']==runtime['device_name'] and
            platform['task_id']==native.STAGE_ID and platform['allocation_id']==allocation['allocation_id'] and platform['expected_inventory_sha256']==native.EXPECTED_SHA and
            platform['i04_prerequisite_sha256']==native.I04_SHA and platform['cpu_prerequisite_sha256']==native.CPU_SHA and platform['lifecycle_sha256']==LAUNCHERS[category][1] and
            reservation['source_sha256']==allocation['platform_source_sha256'],'actual GPU platform/native/claim source differs')
        for path,digest in [(allocation['native_source'],allocation['native_source_sha256']),(allocation['evidence_source'],allocation['platform_source_sha256'])]:require(sources.get(path)==digest,'GPU premodel allocation source not frozen')
        driver=endpoint.json(child(claim,'driver-receipt.json'));require(driver['status']=='observed' and driver['returncode']==0 and
            sum(row['uuid']==physical and row['name']==runtime['device_name'] and isinstance(row['driver_version'],str) for row in driver['rows'])==1 and
            sha(endpoint.get(child(claim,'driver.stdout')))==driver['stdout_sha256'] and sha(endpoint.get(child(claim,'driver.stderr')))==driver['stderr_sha256'],'actual raw GPU driver observation differs')
    else:
        require(versions=={'torch':'2.9.0+cpu','torch_npu':'2.9.0.post2','transformers':'5.10.1','numpy':'1.26.4','cann':'9.1.0','driver':'25.5.2'} and
            runtime['instance_visible_count']==8 and runtime['compute_device_count']==1,'actual NPU stack/selected TP1 differs')
        old.prior.npu.verify_binding({**runtime,'device':runtime['device_argument']},outer,endpoint,outer['allocation_path'],argument(argv,'--native-mapping'),argument(argv,'--native-source'))
        old.prior.npu.verify_driver_provenance(runtime,outer,endpoint,outer['output_dir'])
        required={'float32_matmul_precision':'highest','matmul_allow_hf32':False,'conv_allow_hf32':True,'deterministic_algorithms':False,'deterministic_warn_only':False,'pythonhashseed':'0'}
        require(all(k in policy and type(policy[k]) is type(v) and policy[k]==v for k,v in required.items()) and canonical(load(paths['policy-before-load.json'])['configured'])==canonical(policy),'NPU policy differs')
    require(type(runtime['free_bytes_before_load']) is int and runtime['free_bytes_before_load']>=35*old.GIB and
        type(runtime['host_memory']['effective_available_bytes']) is int and runtime['host_memory']['effective_available_bytes']>=(40 if category=='GPU' else 80)*old.GIB,'recorded native memory guards differ')
    return model,implementation,{'category':category,'model':runtime['device_name']},{'framework':'torch',**versions},policy,allocation


def admit(endpoint,receipt_ref,category,folder):
    outer=endpoint.json(receipt_ref['source_path'],receipt_ref['sha256']);fixed={'schema_version':1,'task':'OBSERVER','task_id':native.STAGE_ID,'capture_schema_version':2,'backend':category,
        'status':'completed','returncode':0,'timed_out':False,'collector_sha256':ENTRY_SHA,'input_sha256':native.expected.INPUT_SHA,'expected_inventory_source_sha256':native.EXPECTED_SHA,
        'stage_spec_source_sha256':native.STAGE_SHA,'i04_prerequisite_source_sha256':native.I04_SHA,'cpu_prerequisite_source_sha256':native.CPU_SHA,'native_capture_count':1,'native_forward_calls_total':4,'model_loads':1,'acceptance':None}
    require(all(k in outer and canonical(outer[k])==canonical(v) for k,v in fixed.items()),'exact completed observer outer receipt required')
    claim=str(PurePosixPath(receipt_ref['source_path']).parent);sources=frozen_sources(endpoint,outer,claim)
    for name,digest in [LAUNCHERS[category],('record_run.py',old.RECORDER_SHA),('observer_native_v2.py',ENTRY_SHA),('observer_common_v2.py',COMMON_SHA),
        ('observer_prerequisite_v1.py',native.PROOF_SOURCE_SHA),('observer_expected_inventory_v1.py',native.EXPECTED_SOURCE_SHA)]:
        found=[p for p in sources if PurePosixPath(p).name==name];require(len(found)==1 and sources[found[0]]==digest,'reviewed lifecycle/capture/expected source differs')
    argv=outer['argv'];offset=2 if len(argv)>1 and argv[1]=='-B' else 1;require(argv[offset]==outer['collector_path'] and sources.get(outer['collector_path'])==ENTRY_SHA,'direct frozen native entry required')
    flags={'--backend':category.lower(),'--input':outer['input_path'],'--output':outer['output_dir'],'--device':'cuda:0' if category=='GPU' else 'npu:0','--allocation-receipt':outer['allocation_path'],
        '--stage-spec':outer['stage_spec_source_path'],'--stage-spec-sha256':native.STAGE_SHA,'--expected-inventory':outer['expected_inventory_source_path'],'--expected-inventory-sha256':native.EXPECTED_SHA,
        '--i04-prerequisite':outer['i04_prerequisite_source_path'],'--i04-prerequisite-sha256':native.I04_SHA,'--cpu-prerequisite':outer['cpu_prerequisite_source_path'],'--cpu-prerequisite-sha256':native.CPU_SHA}
    for key,value in flags.items():require(argument(argv,key)==value,'executed observer argument differs: '+key)
    for key,digest in [('input_path',native.expected.INPUT_SHA),('stage_spec_source_path',native.STAGE_SHA),('expected_inventory_source_path',native.EXPECTED_SHA),
        ('i04_prerequisite_source_path',native.I04_SHA),('cpu_prerequisite_source_path',native.CPU_SHA),('allocation_path',outer['allocation_sha256'])]:require(sources.get(outer[key])==digest,'premodel input/binding/proof not frozen')
    reservation=endpoint.json(child(claim,'claim.json'));controller=endpoint.json(child(claim,'controller-receipt.json'));marker=endpoint.json(child(claim,'worker-once.json'))
    common={'task_id':native.STAGE_ID,'whole_attempt_seconds':3600,'capture_seconds':1200 if category=='GPU' else 1500,'controller_work_seconds':2620,
        'metadata_export_reserved_seconds':960,'logical_transport_cap':1073741824,'encoded_transport_cap':1610612736,'i04_prerequisite_sha256':native.I04_SHA,'cpu_prerequisite_sha256':native.CPU_SHA}
    require(all(k in reservation and canonical(reservation[k])==canonical(v) for k,v in common.items()) and controller['task']=='OBSERVER' and controller['status']=='completed' and
        type(controller['returncode']) is int and controller['returncode']==0 and controller['timed_out'] is False and controller['remaining_descendants']==[],'permanent finite claim/controller not clean/completed')
    marker_path=child(claim,'worker-once.json');require(marker_path in sources and sha(endpoint.get(marker_path))==sources[marker_path],'actual permanent worker marker not in source freeze')
    if category=='GPU':
        require(reservation['lifecycle_sha256']==LAUNCHERS[category][1] and reservation['collector_sha256']==ENTRY_SHA and reservation['stage_spec_sha256']==native.STAGE_SHA and
            reservation['independent_expected_sha256']==native.EXPECTED_SHA and reservation['independent_expected_bytes']==179495 and reservation['max_capture_bytes']==native.CAP_BYTES and
            reservation['max_new_task_bytes_sampled']==4*old.GIB and marker['task']=='OBSERVER' and marker['task_id']==native.STAGE_ID and
            marker['claim_sha256']==sha(endpoint.get(child(claim,'claim.json'))) and marker['lifecycle_sha256']==LAUNCHERS[category][1],'GPU permanent worker/lifecycle budget differs')
        override=outer['deployment_namespace_override'];require(override['frozen_stage_spec_sha256']==native.STAGE_SHA and override['independent_expected_inventory_sha256']==native.EXPECTED_SHA and
            override['lifecycle_sha256']==LAUNCHERS[category][1] and override['literal_stage_root_agreement_claimed'] is False and override['numeric_geometry_changed'] is False and
            override['frozen_stage_declared_GPU_root'].endswith('/observer-transparency-20261107-gpu-v1') and override['approved_GPU_root'].endswith('/observer-transparency-20261107-gpu-v2'),
            'approved versioned GPU namespace override must remain explicit')
    else:
        require(reservation['task']=='OBSERVER' and reservation['backend']=='NPU' and reservation['launcher_sha256']==LAUNCHERS[category][1] and
            reservation['stage_spec_sha256']==native.STAGE_SHA and reservation['max_capture_product_bytes']==native.CAP_BYTES and reservation['max_new_bytes_sampled']==4*old.GIB and
            reservation['expected_inventory_sha256']==native.EXPECTED_SHA and reservation['automatic_retries']==0 and reservation['native_forward_calls']==4 and reservation['model_loads']==1 and
            marker['status']=='internal_worker_attempt_spent' and marker['parent_pid']==reservation['controller_pid'] and marker['source_manifest_sha256']==reservation['source_manifest_sha256'],
            'NPU permanent worker/native claim differs')
        require(endpoint.json(child(claim,'process-2.json'))['status']=='explicitly_empty','second premodel all-board idle observation missing')
    generic=endpoint.json(outer['generic_receipt']['path'],outer['generic_receipt']['sha256']);require(generic['status']=='completed' and type(generic['returncode']) is int and generic['returncode']==0 and
        generic['child_returncode']==0 and generic['argv']==argv and generic['timeout']==common['capture_seconds'],'original successful bounded generic native execution required')
    utc=old.prior.npu.utc_time;require(utc(reservation['claimed_utc'])<=utc(controller['started_utc'])<=utc(generic['start'])==utc(outer['started_utc'])<utc(generic['end'])<=
        utc(outer['finished_utc'])<=utc(controller['finished_utc']),'original native UTC chain differs')
    result=native.inspect_output(endpoint,outer,folder);runtime=result['runtime'];fixed={'task':native.TASK,'stage_id':native.STAGE_ID,'stage_spec_sha256':native.STAGE_SHA,'input_sha256':native.expected.INPUT_SHA,
        'expected_inventory_sha256':native.EXPECTED_SHA,'i04_prerequisite_sha256':native.I04_SHA,'cpu_prerequisite_sha256':native.CPU_SHA,'capture_schema_version':2,'backend':category.lower(),
        'device_argument':flags['--device'],'native_forward_calls_total':4,'model_loads':1,'target_scores':636,'distribution_rows':188,'boundary_snapshots':196,'modes':native.MODES,
        'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':native.NORMALIZATION,'model_repository':'google/gemma-4-12B','requested_revision':old.prior.npu.REVISION,
        'thresholds':None,'acceptance':None,'full_core_complete':False,'seed':0}
    require(all(k in runtime and canonical(runtime[k])==canonical(v) for k,v in fixed.items()),'actual observer runtime semantics differ')
    require(runtime['source_pairing']=={'collector':'observer_collectors_v1.py','common':'observer_common_v2.py','native':'observer_native_v2.py','prerequisite':'observer_prerequisite_v1.py'},'capture v2 source pairing differs')
    model,implementation,hardware,software,policy,allocation=backend_identity(endpoint,outer,runtime,result['paths'],sources,claim,reservation,category)
    result.update(category=category,model=model,hardware=hardware,software=software,backend_policy=policy,implementation_sha256=implementation,outer_receipt_sha256=receipt_ref['sha256'],
        rank_binding={'rank':0,'logical_ordinal':allocation['logical_ordinal'],'compute_device_count':1,'allocation_id':allocation['allocation_id'],'allocation_sha256':outer['allocation_sha256'],
            'original_status_path':child(outer['output_dir'],'status.json'),'original_status_sha256':sha(result['status_path']),'original_outer_receipt_sha256':receipt_ref['sha256']})
    return result


def derive_pairs(inventory):
    pairs=inventory['comparison_pairs'];require(len(pairs)==16 and len({p['id'] for p in pairs})==16,'exact16 frozen score comparisons required')
    expected=[]
    import itertools
    for side in ('GPU','NPU'):
        expected.extend((side,a,side,b) for a,b in itertools.combinations(native.MODES,2))
    expected.extend(('GPU',mode,'NPU',mode) for mode in native.MODES)
    actual=[(p['left']['backend'],p['left']['mode'],p['right']['backend'],p['right']['mode']) for p in pairs]
    require(actual==expected and all(p['targets']==159 and p['distribution_rows']==47 for p in pairs),'frozen exact score pair membership/order differs')
    enabled=inventory['enabled_modes'];samples=[p for p in pairs if p['left']['mode'] in enabled and p['right']['mode'] in enabled]
    require(len(samples)==4 and len(inventory['boundaries'])==98 and len(inventory['primary_boundary_pairs'])==98,'four enabled sample comparisons/primary98 required')
    return pairs,samples


def mode_run(run,mode):
    return {**run['modes'][mode],'side':run['category'].lower()+'-'+mode,'model':run['model'],'hardware':run['hardware'],'software':run['software'],'backend_policy':run['backend_policy'],
        'rank_binding':run['rank_binding'],'mode':{'mode':mode,'use_cache':False,'native_forward_calls':1,'same_process_model_loads':1,'loaded_model_state_sha256':run['loaded_model_state_sha256'],
        'implementation_sha256':run['implementation_sha256'],'scalar_buffer_content_gaps':run['buffer_content_gaps']}}


def rank_status(run):
    b=run['rank_binding'];require(set(b)=={'rank','logical_ordinal','compute_device_count','allocation_id','allocation_sha256','original_status_path','original_status_sha256','original_outer_receipt_sha256'} and
        type(b['rank']) is int and b['rank']==0 and type(b['logical_ordinal']) is int and b['logical_ordinal']==0 and type(b['compute_device_count']) is int and b['compute_device_count']==1 and
        all(old.HEX.fullmatch(b[k]) for k in ('allocation_sha256','original_status_sha256','original_outer_receipt_sha256')),'derived rank requires admitted original TP1/allocation/status bindings')
    return {'rank':0,'status':'completed','derived_adapter':True,'rank_origin':'admitted TP1 logical ordinal0 allocation; original capture status has no rank field',
        'original_status':{'source_path':b['original_status_path'],'sha256':b['original_status_sha256']},'admitted_allocation_id':b['allocation_id'],'admitted_allocation_sha256':b['allocation_sha256'],
        'admitted_outer_receipt_sha256':b['original_outer_receipt_sha256'],'original_bytes_rewritten':False}


def shared_base(a,b,inventory,scope):
    require(canonical(a['model'])==canonical(b['model']),'shared comparison model identities differ')
    common={'model':a['model'],'inputs':{'sha256':native.expected.INPUT_SHA,'sequence_length':160},'numerics':{'parameter_dtypes':['torch.bfloat16'],'native_logits_dtype':'torch.bfloat16',
        'metric_dtype':'float64','logprob_dtype':'float64','attention':'eager','seed':0,'parallelism':'tp1','normalization':native.NORMALIZATION},'scope':scope}
    conditions={r['side']:{'hardware':r['hardware'],'software':r['software'],'backend_policy':r['backend_policy'],'execution_mode':r['mode']} for r in (a,b)}
    docs={}
    for r in (a,b):docs[r['side']+'-environment.json']={'rank':0,'versions':r['software'],'actual':{**common,**conditions[r['side']]}};docs[r['side']+'-status.json']=rank_status(r)
    return common,conditions,docs


def compare_scores(folder,a,b,inventory):
    common,conditions,docs=shared_base(a,b,inventory,'one fixed input; four same-loaded-model observer transparency modes; no kernel cause or numerical acceptance')
    base={'schema_version':1,'common':common,'expected_ranks':{r['side']:[0] for r in (a,b)},'side_conditions':conditions,'thresholds':None}
    targets=[{k:x[k] for k in ('sample','position','token')} for x in inventory['all_targets']];positions=[{k:x[k] for k in ('sample','position','history')} for x in inventory['distribution_rows']]
    docs.update({'targets-contract.json':{**base,'kind':'target-scores','targets':targets},'distributions-contract.json':{**base,'schema_version':2,'kind':'distributions','vocab_size':native.VOCABULARY,
        'normalization_tolerance':1e-5,'renormalization':'none','positions':positions}})
    for r in (a,b):
        side=r['side'];manifest={'common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':side+'-environment.json','status':side+'-status.json'}]}
        docs[side+'-targets.json']={**manifest,'schema_version':1,'kind':'target-scores','scores':[{k:x[k] for k in ('sample','position','token','logprob')} for x in r['scores']]}
        docs[side+'-distributions.json']={**manifest,'schema_version':2,'kind':'distributions','positions':r['positions']}
    require(len(docs)==10,'ten original-source-bound score adapter documents required');folder.mkdir()
    for name,doc in docs.items():put(folder/name,doc)
    checks={r['side']:old.prior.npu.validate(folder/'distributions-contract.json',folder/(r['side']+'-distributions.json')) for r in (a,b)}
    targets=old.prior.npu.compare_targets(folder/'targets-contract.json',folder/(a['side']+'-targets.json'),folder/(b['side']+'-targets.json'))
    distributions=old.prior.npu.compare_distributions(folder/'distributions-contract.json',folder/(a['side']+'-distributions.json'),folder/(b['side']+'-distributions.json'))
    require(all(x['status']=='validated' and x['item_count']==47 for x in checks.values()) and targets['status']==distributions['status']=='no_thresholds' and
        targets['coverage']=={'expected':159,'paired':159} and distributions['position_count']==47,'shared score/distribution tool rejected observer coverage')
    return {'sides':[a['side'],b['side']],'targets':targets,'distributions':distributions,'validations':checks,'frozen_document_sha256':{n:sha(folder/n) for n in docs},'thresholds':None,'acceptance':None}


def compare_samples(folder,a,b,inventory):
    require(a['samples'] is not None and b['samples'] is not None,'both modes need original enabled boundary samples')
    common,conditions,docs=shared_base(a,b,inventory,'selected native BF16 [1,47,64] at98 boundaries; upstream propagation possible; not full hidden states or local operator causes')
    tensors=[{'name':x['id'],'shape':[1,47,64],'present':True,'coordinates':{'sample':inventory['sample'],'boundary':x['id'],'module':x['module'],'when':x['when'],
        'token_indices':inventory['distribution_positions'],'channel_indices':inventory['channels']}} for x in inventory['boundaries']]
    docs['samples-contract.json']={'schema_version':2,'kind':'tensors','stage':'observations','common':common,'expected_ranks':{r['side']:[0] for r in (a,b)},'side_conditions':conditions,'tensors':tensors,'thresholds':None}
    for r in (a,b):
        side=r['side'];docs[side+'-samples.json']={'schema_version':2,'kind':'tensors','stage':'observations','common':common,'side':side,'expected_ranks':[0],
            'ranks':[{'rank':0,'environment':side+'-environment.json','status':side+'-status.json'}],
            'tensors':[{**x,'shards':[{'offset':0,'value':r['samples']['arrays'][x['name']]}]} for x in tensors]}
    require(len(docs)==7,'seven original-source-bound tensor adapter documents required');folder.mkdir()
    for name,doc in docs.items():put(folder/name,doc)
    result=compare_tensors.compare(folder/'samples-contract.json',folder/(a['side']+'-samples.json'),folder/(b['side']+'-samples.json'))
    require(result['status']=='no_thresholds' and len(result['per_tensor'])==98 and result['global']['count']==98*47*64,'shared tensor comparison rejected all98 samples')
    return {'sides':[a['side'],b['side']],'metrics':result,'frozen_document_sha256':{n:sha(folder/n) for n in docs},'thresholds':None,'acceptance':None}


def assess(spec_path,spec_sha,output):
    verify_tools();main_sha=sha(__file__);require(old.HEX.fullmatch(spec_sha) and sha(spec_path)==spec_sha,'external actual observer comparison spec differs');spec=load(spec_path)
    require(spec.get('schema_version')==1 and spec.get('task')==native.TASK and spec.get('stage_spec_sha256')==native.STAGE_SHA and spec.get('expected_inventory_sha256')==native.EXPECTED_SHA and
        spec.get('i04_prerequisite_sha256')==native.I04_SHA and spec.get('cpu_prerequisite_sha256')==native.CPU_SHA and set(spec.get('endpoints',{}))=={'GPU','NPU'} and
        spec.get('thresholds',object()) is None and spec.get('acceptance',object()) is None,'actual two-endpoint observer spec required')
    output=Path(output).resolve();require(not output.exists() and output.parent.is_dir(),'exclusive new CPU output directory required');output.mkdir();endpoints={};runs={}
    for category in ('GPU','NPU'):
        info=spec['endpoints'][category];m=info['source_map'];r=info['receipt'];require(set(m)==SOURCE_MAP_KEYS and m['sha256']==ACTUAL_ENDPOINTS[category]['source_map_sha256'] and
            r['sha256']==ACTUAL_ENDPOINTS[category]['outer_receipt_sha256'] and (category!='GPU' or 'retained_root' not in info),'actual endpoint pins/full GPU array role differ')
        endpoint=native.Endpoint(m['path'],m['sha256'],info.get('retained_root') if category=='NPU' else None);mapping=load(endpoint.manifest_path)
        require(mapping.get('request')=={'task':'OBSERVER','backend':category,'outer_receipt':r['source_path']} and mapping.get('raw_bytes_preserved') is True and
            mapping.get('full_array_hashes_checked')==194 and mapping.get('retained_array_count')==(194 if category=='NPU' else 0),'actual194-large original map request/roles differ')
        endpoints[category]=endpoint;runs[category]=admit(endpoint,r,category,output/('proof-'+category.lower()))
    require(canonical(runs['GPU']['model'])==canonical(runs['NPU']['model']) and canonical(runs['GPU']['inventory'])==canonical(runs['NPU']['inventory']),'same checkpoint/expected inventory required')
    inventory=runs['GPU']['inventory'];pairs,samples=derive_pairs(inventory)
    large=[(side,name,str(path)) for side,run in runs.items() for name,path in run['paths'].items() if name.endswith(('.npy','.safetensors'))]
    require(len(large)==388 and len({p for _,_,p in large})==388 and all(sum(s==side for s,_,_ in large)==194 for side in ('GPU','NPU')),'complete388 distinct original large sources required')
    reports=[];tensors=[]
    for i,pair in enumerate(pairs):
        a,b=(mode_run(runs[pair[k]['backend']],pair[k]['mode']) for k in ('left','right'));result=compare_scores(output/('scores-%02d'%i),a,b,inventory);result.update(id=pair['id'],kind=pair['kind']);reports.append(result)
    for i,pair in enumerate(samples):
        a,b=(mode_run(runs[pair[k]['backend']],pair[k]['mode']) for k in ('left','right'));result=compare_samples(output/('samples-%02d'%i),a,b,inventory)
        result.update(id=pair['id'],kind=pair['kind'],primary_cross_backend_hooks_only=pair['id']=='cross/hooks-only');tensors.append(result)
    for endpoint in endpoints.values():
        for name,digest in endpoint.checked.items():require(sha(endpoint.resolved[name])==digest,'original metadata/large source changed during math')
        require(sha(endpoint.manifest_path)==endpoint.expected_sha,'original source map changed during math')
    require(sha(spec_path)==spec_sha and sha(__file__)==main_sha and sum(p.stat().st_size for p in output.rglob('*') if p.is_file())<=MAX_METADATA,'comparison input/source/output cap changed');verify_tools()
    result={'schema_version':1,'status':'observer_raw_bf16_and_sampled_boundary_comparisons_checked','task':native.TASK,'checked_utc':datetime.now(timezone.utc).isoformat(),
        'comparison_spec_sha256':spec_sha,'stage_spec_sha256':native.STAGE_SHA,'expected_inventory_sha256':native.EXPECTED_SHA,'source_map_sha256':{s:e.expected_sha for s,e in endpoints.items()},
        'scope':{'independent_inputs':1,'same_loaded_model_processes_per_backend':1,'native_calls_per_backend':4,'finite_raw_rows_checked':1280,'targets_rederived':1272,'full_vocabulary_rows_rederived':376,
            'target_distribution_pairs':len(reports),'distribution_pair_rows':sum(r['distributions']['position_count'] for r in reports),'boundary_tensor_comparisons':len(tensors),
            'boundary_tensor_pairs':sum(len(x['metrics']['per_tensor']) for x in tensors),'primary_cross_backend_boundary_pairs':98,'original_large_sources_final_bytehash_checked':len(large),
            'new_comparison_documents':sum(len(x['frozen_document_sha256']) for x in reports+tensors),'loaded_parameter_or_full_buffer_byte_attestation':False,'native_kernel_identity_attested':False},
        'target_distribution_pairs':reports,'boundary_sample_comparisons':tensors,'raw_derivation':{s:{m:{'raw_sha256':x['raw_sha256'],'targets':len(x['scores']),'full_rows':len(x['positions']),
            'largest_abs_logprob_derivation_delta':x['raw_derivation_max_abs_delta']} for m,x in r['modes'].items()} for s,r in runs.items()},
        'execution_census':{s:{m:x['census'] for m,x in r['modes'].items()} for s,r in runs.items()},'scalar_buffer_content_gaps':{s:r['buffer_content_gaps'] for s,r in runs.items()},
        'offline_tool_source_sha256':{**old.prior.IMPORT_PINS,'observer_artifact_admission_v2.py':HELPER_SHA,'admit_observer_transparency_v2.py':main_sha,
            'observer_expected_inventory_v1.py':native.EXPECTED_SOURCE_SHA,'observer_prerequisite_v1.py':native.PROOF_SOURCE_SHA,'i04_artifact_admission_v1.py':native.PRIOR_SHA},
        'limitations':['One frozen160-token input; four modes share a loaded eval model and same-host RNG controls, not fresh-process repeatability',
            '47token positions and64hidden channels at98 boundaries are sampled; upstream propagation prevents a local operator cause claim',
            '875static module entries are distinct from actual fired/zero-fired module and dispatcher frontend observations',
            'Dispatcher overload/tensor metadata is not native kernel/fusion/accumulator identity or complete scalar/tensor operand values',
            'The unchanged bounded buffer probe retains unsupported scalar BF16 content-fingerprint gaps; loaded parameters/full buffer bytes are not attested',
            'Top100-union probability errors and complement-merged JS are not full-vocabulary errors/divergence; no quality or P01 measurement'],
        'native_executions_started_by_admission':0,'thresholds':None,'acceptance':None,'full_core_complete':False}
    require(result['scope']['distribution_pair_rows']==752 and result['scope']['boundary_tensor_pairs']==392 and result['scope']['new_comparison_documents']==188,'independent final comparison counts differ')
    put(output/'observer-comparison-report.json',result);return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--spec',type=Path,required=True);p.add_argument('--spec-sha256',required=True);p.add_argument('--output-dir',type=Path,required=True)
    p.add_argument('--timeout-seconds',type=int,default=900);args=p.parse_args();require(hasattr(signal,'SIGALRM') and 1<=args.timeout_seconds<=900,'POSIX finite CPU1..900 required')
    previous=signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('observer CPU admission900s')));signal.setitimer(signal.ITIMER_REAL,args.timeout_seconds)
    try:result=assess(args.spec,args.spec_sha256,args.output_dir)
    finally:signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)
    print(old.json.dumps({'status':result['status'],'score_pairs':len(result['target_distribution_pairs']),'boundary_comparisons':len(result['boundary_sample_comparisons']),'native_executions_started':0,'acceptance':None}))


if __name__=='__main__':main()

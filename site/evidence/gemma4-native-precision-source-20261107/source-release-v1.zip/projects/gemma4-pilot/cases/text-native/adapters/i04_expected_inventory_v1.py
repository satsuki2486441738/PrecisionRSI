"""Independently freeze I04 request, padding and causal-score coordinates.

Pure stdlib; no collector/common/framework imports or native observations.
Validity is defined by frozen lengths, never by token IDs (ID0 can be valid).
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path

INPUT_A_SHA256='643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
INPUT_B_SHA256='f4bca8e16d2e7768c6f9dff0677ea329ccf46ed254e211dc2ce2f9852f416792'
STAGE_SHA256='26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
STAGE_ID='gemma4-gpu-npu-i04-batch-padding-v1-20261107'
TASK='gemma4-i04-batch-padding-v1'
VOCABULARY=262144
MODES=['alone-A','alone-B','batch-left','batch-right']


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)


def parse(raw):
    def pairs(items):
        result={}
        for key,value in items:require(key not in result,'duplicate JSON key');result[key]=value
        return result
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=reject)


def load(path):return parse(Path(path).read_text(encoding='utf-8'))


def frozen_document(path,expected_sha):
    path=Path(path);require(path.is_file() and not path.is_symlink(),'original regular source required')
    raw=path.read_bytes();require(hashlib.sha256(raw).hexdigest()==expected_sha,'frozen input/stage source SHA differs')
    return parse(raw)


def request(document,prompt_length,length):
    require(isinstance(document,dict) and isinstance(document.get('sample'),str) and document['sample'].strip(),'nonempty sample ID required')
    prompt,continuation=document.get('prompt'),document.get('continuation')
    require(isinstance(prompt,list) and len(prompt)==prompt_length and isinstance(continuation,list) and len(continuation)==32,
        'exact frozen prompt/continuation lengths required')
    sequence=prompt+continuation
    require(len(sequence)==length and all(type(token) is int and 0<=token<VOCABULARY for token in sequence),
        'integer in-vocabulary token IDs required')
    grid=[index*(prompt_length-1)//15 for index in range(16)]
    selected=sorted(set(grid)|set(range(prompt_length-1,length-1)))
    require(len(grid)==len(set(grid))==16 and len(selected)==47,'independent47-position inventory differs')
    return {'sample':document['sample'],'prompt_length':prompt_length,'continuation_length':32,'sequence_length':length,
        'input_ids':sequence,'all_targets':[{'sample':document['sample'],'position':t,'token':sequence[t]} for t in range(1,length)],
        'distribution_positions':[{'sample':document['sample'],'position':p,'history':sequence[:p+1]} for p in selected]}


def derive(document_a,document_b,input_a_sha256,input_b_sha256,stage_sha256):
    require((input_a_sha256,input_b_sha256,stage_sha256)==(INPUT_A_SHA256,INPUT_B_SHA256,STAGE_SHA256),
        'original two input SHAs and prepared I04 stage SHA required')
    requests={'A':request(document_a,128,160),'B':request(document_b,64,96)}
    require(document_b.get('kind')=='derived_prefix_shape_stress' and document_b.get('independent_representative_example') is False and
        document_b.get('parent_input_sha256')==INPUT_A_SHA256 and document_b.get('parent_sample')==document_a['sample'] and
        document_b.get('parent_token_span')==[0,96] and requests['B']['input_ids']==requests['A']['input_ids'][:96],
        'B must be the declared derived A prefix, not an independent request or a different continuation')
    require(requests['A']['sample']!=requests['B']['sample'],'distinct logical request sample IDs required')
    modes=[]
    for mode in MODES:
        members=['A'] if mode=='alone-A' else ['B'] if mode=='alone-B' else ['A','B']
        width=requests[members[0]]['sequence_length'] if mode.startswith('alone-') else 160
        inputs,masks,positions,observations,pad_rows=[],[],[],[],[]
        for slot,identifier in enumerate(members):
            item=requests[identifier];length=item['sequence_length']
            offset=width-length if mode=='batch-left' else 0
            ids=[0]*offset+item['input_ids']+[0]*(width-offset-length)
            mask=[0]*offset+[1]*length+[0]*(width-offset-length)
            # Independent scalar implementation of (cumsum(mask)-1).masked_fill(mask==0,0).
            valid_count=0;pos=[]
            for valid in mask:
                if valid:pos.append(valid_count);valid_count+=1
                else:pos.append(0)
            require(valid_count==length and len(ids)==len(mask)==len(pos)==width,'native row construction lost a logical input')
            inputs.append(ids);masks.append(mask);positions.append(pos)
            pad_rows += [{'slot':slot,'physical_position':index} for index,valid in enumerate(mask) if valid==0]
            targets=[{**coordinate,'prediction_position':coordinate['position']-1,
                'physical_prediction_position':offset+coordinate['position']-1,'physical_target_position':offset+coordinate['position']}
                for coordinate in item['all_targets']]
            rows=[{**coordinate,'physical_prediction_position':offset+coordinate['position']} for coordinate in item['distribution_positions']]
            observations.append({'request':identifier,'sample':item['sample'],'slot':slot,'physical_offset':offset,
                'sequence_length':length,'all_targets':targets,'distribution_positions':rows})
        modes.append({'id':mode,'input_ids':inputs,'attention_mask':masks,'position_ids':positions,
            'raw_logits':{'tensor_name':'logits','dtype':'BF16','shape':[len(members),width,VOCABULARY],
                          'data_bytes':len(members)*width*VOCABULARY*2},
            'observations':observations,'pad_only_rows':pad_rows})
    observations=[(mode,observation) for mode in modes for observation in mode['observations']]
    physical=sum(len(mode['input_ids'])*len(mode['input_ids'][0]) for mode in modes)
    valid=sum(sum(sum(row) for row in mode['attention_mask']) for mode in modes)
    targets=sum(len(observation['all_targets']) for _,observation in observations)
    rows=sum(len(observation['distribution_positions']) for _,observation in observations)
    pad=sum(len(mode['pad_only_rows']) for mode in modes)
    require((len(modes),len(observations),targets,rows,physical,valid,pad)==(4,6,762,282,896,768,128),
        'independent I04 native/logical coverage counts differ')
    conditions={'A':['alone-A','batch-left','batch-right'],'B':['alone-B','batch-left','batch-right']}
    pairs=[]
    for identifier,condition in conditions.items():
        for mode in condition:pairs.append({'kind':'cross_backend_matched','request':identifier,
            'left':{'backend':'GPU','mode':mode},'right':{'backend':'NPU','mode':mode}})
    for backend in ('GPU','NPU'):
        for identifier,condition in conditions.items():
            for left,right in itertools.combinations(condition,2):pairs.append({'kind':'within_backend_request_conditions','request':identifier,
                'left':{'backend':backend,'mode':left},'right':{'backend':backend,'mode':right}})
    require(len(pairs)==len({canonical(pair) for pair in pairs})==18,'exact18 request-preserving comparison pairs required')
    raw_bytes=sum(mode['raw_logits']['data_bytes'] for mode in modes);row_bytes=rows*VOCABULARY*8
    require(raw_bytes+row_bytes==1061158912,'independent native/FP64 payload byte count differs')
    return {'schema_version':1,'task':TASK,'stage_id':STAGE_ID,'stage_spec_sha256':stage_sha256,
        'input_sha256s':{'A':input_a_sha256,'B':input_b_sha256},'requests':requests,'modes':modes,
        'counts':{'native_calls_per_backend':4,'logical_observations_per_backend':6,'targets_per_backend':targets,
            'distribution_rows_per_backend':rows,'physical_raw_rows_per_backend':physical,'valid_raw_rows_per_backend':valid,
            'pad_only_raw_rows_per_backend':pad,'raw_tensor_files':4,'npy_files':rows,'large_objects':4+rows,
            'target_distribution_pairs':len(pairs),'native_raw_data_bytes':raw_bytes,'fp64_row_data_bytes':row_bytes,
            'payload_data_bytes_excluding_headers':raw_bytes+row_bytes},
        'sampling':{identifier:{'prompt_predictors':[i*(item['prompt_length']-1)//15 for i in range(16)],
            'continuation_predictors':list(range(item['prompt_length']-1,item['sequence_length']-1)),
            'intersection_predictors':[item['prompt_length']-1],'deduplicated_predictors':[r['position'] for r in item['distribution_positions']]}
            for identifier,item in requests.items()},
        'comparison_pairs':pairs,'scope':{'independent_parent_inputs':1,'derived_prefix_shape_stress_requests':1,
            'new_model_processes_per_backend':1,'repeatability_measured':False,'cached_serving_or_scheduler_tested':False,
            'validity_from_lengths_only':True,'valid_token_ID0_preserved':True,'pad_only_rows_retained_losslessly':True,
            'unscored_logical_predictors':{'A':159,'B':95},'numeric_or_native_execution_performed_by_builder':False},
        'thresholds':None,'acceptance':None}


def stage_check(stage_path,stage_sha,expected):
    require(stage_sha==STAGE_SHA256,'original I04 stage SHA required');stage=frozen_document(stage_path,stage_sha)
    require(stage.get('stage_id')==STAGE_ID and stage.get('status')=='prepared_not_executed' and stage.get('thresholds') is None and
        stage.get('acceptance') is None and stage.get('full_core_complete') is False,'unchanged prepared I04 stage required')
    require(stage['modes']==MODES and stage['expected_native_calls']==[1,1,1,1] and stage['total_forward_calls_per_backend']==4 and
        stage['new_model_processes_per_backend']==1 and stage['same_loaded_model'] is True,'four-call one-model plan differs')
    semantics=stage['semantics'];counts=expected['counts']
    require(semantics['pad_token_id']==0 and semantics['mask_dtype']==semantics['position_dtype']=='int64' and
        semantics['position_rule']=='(attention_mask.cumsum(-1)-1).masked_fill(attention_mask==0,0)' and
        semantics['use_cache'] is False and semantics['past_key_values'] is None and semantics['logits_to_keep']==0 and
        semantics['labels_supplied'] is False and semantics['shared_kv_states_supplied'] is False,'fixed cache-off mask/position policy differs')
    for identifier,item in expected['requests'].items():
        require(stage['requests'][identifier]['sha256']==expected['input_sha256s'][identifier] and
            stage['requests'][identifier]['prompt_tokens']==item['prompt_length'] and stage['requests'][identifier]['length']==item['sequence_length'] and
            semantics['valid_targets_per_request'][identifier]==len(item['all_targets']) and
            semantics['distribution_positions'][identifier]==expected['sampling'][identifier]['deduplicated_predictors'], 'stage request/target/sample coordinates differ')
    for mode in expected['modes']:
        require(stage['raw_shapes'][mode['id']]==mode['raw_logits']['shape'] and all(
            semantics['physical_offsets'][mode['id']][observation['request']]==observation['physical_offset'] for observation in mode['observations']),
            'stage physical tensor/offset plan differs')
    require(semantics['logical_observations_per_backend']==6 and semantics['target_scores_per_backend']==counts['targets_per_backend'] and
        semantics['distribution_rows_per_backend']==counts['distribution_rows_per_backend'] and semantics['physical_raw_rows_per_backend']==896 and
        semantics['valid_raw_rows_per_backend']==768 and semantics['pad_only_raw_rows_per_backend']==128 and
        stage['comparisons']['target_distribution_pairs_total']==18 and stage['comparisons']['native_final_kv_pairs']==0 and
        stage['payload_bytes_excluding_headers_per_backend']['total']==counts['payload_data_bytes_excluding_headers'],'stage coverage/payload inventory differs')
    limits=stage['limits'];require(limits['max_native_model_processes_per_backend']==1 and limits['automatic_native_retries']==0 and
        limits['gpu_capture_timeout_seconds']==900 and limits['npu_capture_timeout_seconds']==1200 and limits['whole_attempt_timeout_seconds_per_backend']==3000 and
        limits['maximum_logical_artifact_transport_bytes_per_direction']==1207959552 and limits['maximum_encoded_transport_bytes_per_direction']==1610612736,
        'new finite stage process/retry/time/transport boundary differs')
    return stage


def build(input_a,input_b,output,stage_spec,stage_spec_sha256):
    a=frozen_document(input_a,INPUT_A_SHA256);b=frozen_document(input_b,INPUT_B_SHA256)
    expected=derive(a,b,INPUT_A_SHA256,INPUT_B_SHA256,stage_spec_sha256);stage_check(stage_spec,stage_spec_sha256,expected)
    output=Path(output);require(output.parent.is_dir() and not output.exists() and not output.is_symlink(),'exclusive new expected inventory path required')
    with output.open('x',encoding='utf-8',newline='\n') as stream:json.dump(expected,stream,indent=2,allow_nan=False);stream.write('\n')
    require(sha(input_a)==INPUT_A_SHA256 and sha(input_b)==INPUT_B_SHA256 and sha(stage_spec)==STAGE_SHA256,'frozen source changed during build')
    return {'status':'i04_expected_inventory_frozen','path':str(output.resolve()),'sha256':sha(output),'size_bytes':output.stat().st_size,
        'counts':expected['counts'],'native_executions_started':0,'acceptance':None}


def verify(expected_path,input_a,input_b,stage_spec):
    expected=derive(frozen_document(input_a,INPUT_A_SHA256),frozen_document(input_b,INPUT_B_SHA256),INPUT_A_SHA256,INPUT_B_SHA256,STAGE_SHA256)
    stage_check(stage_spec,STAGE_SHA256,expected)
    require(canonical(load(expected_path))==canonical(expected),'independently derived I04 inventory differs')
    return expected


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('input','input-b','output','stage-spec'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--stage-spec-sha256',required=True);args=parser.parse_args()
    print(json.dumps(build(args.input,args.input_b,args.output,args.stage_spec,args.stage_spec_sha256),indent=2))


if __name__=='__main__':main()

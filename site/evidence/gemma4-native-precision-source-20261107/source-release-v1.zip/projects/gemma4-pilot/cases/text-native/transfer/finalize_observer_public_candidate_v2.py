"""Build a NEW private final-copy candidate and unappended evaluation record.

Only frozen JSON/text candidates and two original CPU failure controllers are
read. No native arrays, framework, hardware, public history or Git writes.
The archive revision is deliberately None until Root verifies an actual commit.
"""
import argparse
import copy
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import re
import signal
import time

HERE = Path(__file__).resolve().parent
CASE = HERE.parent
ORIGINAL = HERE/'publication-candidate-observer-gpu-20261107T013917Z'
ID = 'gemma4-h100-observer-transparency-20261107'
PREFIX = 'site/evidence/'+ID+'/'
MODES = ['off-before', 'hooks-only', 'off-after', 'hooks-plus-dispatch-metadata']
PINS = {
    'numeric/selected-targets.json': 'cc8004ae8d6aac211647aa2dc8a15d6757ef46db0474e87ee4b9db621c99ca9d',
    'numeric/selected-metrics.json': '883c325d560efcad1ed9cb75c9e3c740a6ff67f83b8bee3e6619d7f65cf8d813',
    'numeric/replay-targets.py': '9a6b9ef5aa75a00f39c9b2c1fcbe42dabe90ef7b4aa6b68dade3ecfb8b1544a9',
    'documents/report.md': '093772015923a76038dd9b4d642e971ac38580194d7501d567aeb4e3a8a2b1c2',
    'documents/coverage.json': 'b9bd9e0e1de99eb4944e983ee7c1bb5b767313057ebfc02c10051e66d668000e',
    'documents/cost.json': '4740545319811a9d2c8ee203a5a9d8ed935f47812472f639f73ba38e7566819e',
    'ledger/e02-summary.json': 'bb0597edb1a0a968c59fc4e823a7f3cc4cf3a61beffd6dcee7a359d53e479a20'}
FAILURES = [
    ('formal_GPU_only_CPU_admission_v1_failed', 'runs/compare-observer-gpu-only-20261107T001752Z/controller-receipt.json',
     '401a764631636298488f456b68eb61a355e10edcc7524ca188d43cfa3089e86b', 33.90709985199999),
    ('formal_GPU_only_CPU_admission_v2_failed', 'runs/compare-observer-gpu-only-v2-20261107T002803Z/controller-receipt.json',
     '39f99e20485efb014bdf23b73981ede485f93f17254bf3420b014059862365b6', 41.989743333999996)]


def require(ok, message):
    if not ok: raise ValueError(message)


def digest(raw): return hashlib.sha256(raw).hexdigest()
def encode(doc): return (json.dumps(doc, indent=2, ensure_ascii=False, allow_nan=False)+'\n').encode()


def read(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            require(key not in out, 'duplicate JSON key'); out[key] = value
        return out
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))


def metadata(path, sha):
    path = Path(path)
    require(path.suffix in ('.json', '.md', '.py') and path.is_file() and not path.is_symlink() and
        path.stat().st_size <= 16*1024**2, 'bounded regular metadata only; arrays refused before read')
    raw = path.read_bytes(); require(digest(raw) == sha, 'frozen source SHA differs'); return raw


def privacy(doc):
    blocked = {'path', 'source_path', 'token', 'tokens', 'token_ids', 'history', 'prompt', 'pid', 'pids',
        'allocation_id', 'runtime_uuid', 'device_uuid', 'password', 'username', 'account'}
    if isinstance(doc, dict):
        require(not (set(doc) & blocked), 'private key in final candidate')
        for value in doc.values(): privacy(value)
    elif isinstance(doc, list):
        for value in doc: privacy(value)
    elif isinstance(doc, str):
        require(not re.search(r'/(?:home|mnt|data/afs)/|C:[/\\]|\bapp-[a-z0-9]{8}\b|\b(?:\d{1,3}\.){3}\d{1,3}\b|\b[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}\b', doc, re.I) and
            not any(s in doc for s in ('REDACTED_ACCOUNT', 'REDACTED_ACCOUNT', 'wikitext2-discovery-001', 'wxid_')), 'private identity/path in candidate')
    elif type(doc) in (int, float): require(math.isfinite(doc), 'nonfinite candidate number')
    else: require(doc is None or type(doc) is bool, 'unsupported public value')


def report_spacing(raw):
    text = raw.decode()
    replacements = [
        ('same128+32', 'same 128 + 32'), ('one160-token', 'one 160-token'), ('seed0', 'seed 0'),
        ('The159', 'The 159'), ('include127', 'include 127'), ('and32 continuation', 'and 32 continuation'),
        ('prediction159', 'prediction 159'), ('formal282', 'formal 282'), ('overlap1', 'overlap 1'),
        ('The98', 'The 98'), ('output,48', 'output, 48'), ('giving294784', 'giving 294784'),
        ('cosine1', 'cosine 1'), ('all6x159', 'all 6 x 159'), ('all282', 'all 282'), ('all98', 'all 98'),
        ('all194', 'all 194'), ('two98-tensor', 'two 98-tensor'), ('prediction0', 'prediction 0'),
        ('prediction144', 'prediction 144'), ('absolute1e-12/relative5e-12', 'absolute 1e-12 / relative 5e-12'),
        ('has875', 'has 875'), ('records,630', 'records, 630'), ('and629', 'and 629'), ('recorded863', 'recorded 863'),
        ('and864', 'and 864'), ('explicit12-record', 'explicit 12-record'), ('recorded5604', 'recorded 5604'),
        ('invocations/4922', 'invocations / 4922'), ('The49-task', 'The 49-task'), ('remains9', 'remains 9'),
        ('complete,9', 'complete, 9'), ('partial,8', 'partial, 8'), ('pending,21', 'pending, 21'), ('and2 not', 'and 2 not')]
    for old, new in replacements: text = text.replace(old, new)
    # This operation changes whitespace only. It cannot change a number,
    # punctuation mark, hash, scientific claim or link target.
    require(re.sub(r'\s+', '', text) == re.sub(r'\s+', '', raw.decode()), 'report editorial operation changed non-whitespace bytes')
    return text.encode()


def augmented_cost(original, controls):
    result = copy.deepcopy(original); additions = []
    require(original['record_id'] == ID and len(original['recorded_CPU_intervals']) == 4 and original['monetary_cost'] is None and
        original['invoice_or_billed_GPU_hours_known'] is False and original['P01_measured'] is False, 'frozen original accounting scope differs')
    for (label, _, sha, elapsed), controller in zip(FAILURES, controls):
        require(controller['task'] == 'OBSERVER-GPU-only-CPU' and controller['status'] == 'failed' and controller['returncode'] == 2 and
            controller['timed_out'] is False and controller['native_executions_started'] == 0 and controller['elapsed_seconds'] == elapsed,
            'actual prior failed CPU admission status/scope/duration differs')
        additions.append({'phase': label, 'status': 'failed', 'seconds': controller['elapsed_seconds'], 'source_controller_sha256': sha})
    result['recorded_CPU_intervals'] = additions + result['recorded_CPU_intervals']
    result['previous_cost_candidate_sha256'] = PINS['documents/cost.json']
    result['known_formal_CPU_failure_intervals_included'] = True
    require(len(result['recorded_CPU_intervals']) == 6 and result['complete_executed_CPU_setup_failure_and_transfer_time_known'] is False and
        result['recorded_intervals_are_not_a_total_and_may_overlap'] is True, 'new cost claims a total or loses unknown accounting')
    privacy(result); return result


def metric(identity, label, value, unit, **extra):
    require(type(value) in (int, float) and math.isfinite(value), 'finite history metric required')
    return dict(id=identity, label=label, value=value, unit=unit, **extra)


def evaluation_record(metrics, targets, coverage, cost, e02, files):
    require(metrics['record_id'] == targets['record_id'] == coverage['record_id'] == cost['record_id'] == e02['record_id'] == ID and
        metrics['selected_targets_sha256'] == digest(files['selected-targets.json']) and len(targets['vectors']) == 4 and
        metrics['scope']['target_distribution_pairs'] == 6 and metrics['scope']['P01_measured'] is False and
        metrics['scope']['GPU_NPU_observer_comparison_complete'] is False and e02['all_metrics_matched'] is True,
        'actual GPU-only candidate identity or paired scope differs')
    environment = metrics['environment']; versions = environment['software']
    require(versions == {'framework': 'torch', 'torch': '2.9.0+cu128', 'transformers': '5.10.1', 'cuda_runtime': '12.8', 'numpy': '1.26.4'},
        'actual software versions differ')
    sides = []
    for mode in MODES:
        sides.append({'id': 'gpu-'+mode, 'label': 'GPU / '+mode, 'hardware': environment['hardware']['model'],
            'libraries': [{'name': name, 'version': versions[key]} for name, key in
                [('PyTorch', 'torch'), ('Transformers', 'transformers'), ('NumPy', 'numpy'), ('CUDA runtime', 'cuda_runtime')]],
            'settings': {'parameter_dtype': 'BF16', 'native_logits_dtype': 'BF16', 'offline_logprob_dtype': 'FP64',
                'attention': 'eager', 'seed': 0, 'parallelism': 'tp1', 'device_count': 1,
                **copy.deepcopy(environment['backend_policy']), 'execution': {'mode': mode, 'use_cache': False,
                    'sequence_length': 160, 'native_forward_calls': 1, 'same_process_model_loads': 1, 'eval': True,
                    'logits_to_keep': 0, 'module_hooks_enabled': mode in ('hooks-only', 'hooks-plus-dispatch-metadata'),
                    'frontend_dispatcher_metadata_enabled': mode == 'hooks-plus-dispatch-metadata'},
                'fresh_process_repeatability_measured': False, 'P01_measured': False}})
    comparisons = []
    for pair, (left, right) in zip(metrics['target_distribution_pairs'], itertools.combinations(MODES, 2)):
        a, b = 'gpu-'+left, 'gpu-'+right; target, distribution = pair['targets'], pair['distributions']
        require(pair['sides'] == [a, b] and target['target_count'] == 159 and distribution['position_count'] == 47,
            'actual six within-GPU pair order/coverage differs')
        values = [metric('target-nll-abs-diff', 'Target NLL absolute difference', target['nll_abs_diff_nat_per_token'], 'nat/token',
            side_values={a: target['side_a_nll_nat_per_token'], b: target['side_b_nll_nat_per_token']}),
            metric('target-mae', 'Target logprob MAE', target['mae_nat'], 'nat'),
            metric('target-p99', 'Target absolute difference linear P99', target['p99_nat'], 'nat'),
            metric('target-max', 'Target maximum absolute difference', target['max_abs_nat'], 'nat',
                coordinate={'anonymous_target_index_zero_based': target['max_target_index']})]
        aggregate = distribution['aggregate']
        values += [metric('top1-agreements', 'Top-1 agreements', aggregate['top1_agreement']['count'], 'positions'),
            metric('top1-agreement-fraction', 'Top-1 agreement fraction', aggregate['top1_agreement']['fraction'], 'fraction'),
            metric('top100-overlap-mean', 'Top-100 overlap mean', aggregate['top100_overlap_mean'], 'fraction')]
        for key, slug, label, unit in [('probability_rmse', 'union-probability-rmse', 'Union-token probability RMSE', 'probability'),
                ('max_probability_error', 'union-max-probability-error', 'Union-token maximum probability error', 'probability'),
                ('tail_merged_js', 'tail-merged-js', 'Top-100 union plus complement JS', 'nat')]:
            for reduction in ('mean', 'p99', 'max'):
                extra = {'coordinate': {'prediction_index_zero_based': aggregate[key]['max_prediction_index']}} if reduction == 'max' else {}
                values.append(metric(slug+'-'+reduction, label+' '+reduction.upper(), aggregate[key][reduction], unit, **extra))
        for role, reductions in aggregate['coverage'].items():
            for reduction, value in reductions.items():
                values.append(metric(role.replace('_', '-')+'-'+reduction, role.replace('_', ' ')+' probability mass '+reduction.upper(), value, 'probability mass'))
        item = {'id': a+'-vs-'+b, 'title': 'Observer controls: '+left+' vs '+right,
            'side_ids': [a, b], 'kind': 'within_GPU_same_loaded_model_observer_control',
            'scope': 'One fixed input: 159 targets (127 prompt plus 32 continuation), 47 sampled distributions; one loaded GPU model.',
            'metrics': values, 'coverage': [{'label': 'Paired target logprobs', 'observed': 159, 'expected': 159, 'unit': 'targets'},
                {'label': 'Paired sampled distributions', 'observed': 47, 'expected': 47, 'unit': 'positions'}],
            'acceptance': None, 'thresholds': None}
        if [left, right] == ['hooks-only', 'hooks-plus-dispatch-metadata']:
            sample = metrics['boundary_samples']
            for key, unit in [('rmse', 'activation value'), ('max_abs', 'activation value'), ('cosine', '1'),
                    ('error_norm', 'activation L2')]:
                values.append(metric('sample-global-'+key.replace('_', '-'), 'Sampled boundary global '+key.replace('_', ' '), sample['global'][key], unit))
            values.append(metric('sample-global-side-norm-absolute-difference', 'Absolute difference of sampled side L2 norms',
                abs(sample['global']['side_a_norm']-sample['global']['side_b_norm']), 'activation L2',
                side_values={a: sample['global']['side_a_norm'], b: sample['global']['side_b_norm']}))
            item['coverage'] += [{'label': 'Paired sampled boundaries', 'observed': 98, 'expected': 98, 'unit': 'boundary tensors'},
                {'label': 'Paired selected boundary elements', 'observed': 294784, 'expected': 294784, 'unit': 'elements'}]
            item['sampled_boundary_summary'] = copy.deepcopy(sample)
        comparisons.append(item)
    record = {'id': ID, 'date': '2026-11-07', 'title': 'Transformers · observer transparency · Gemma-4-12B',
        'framework': {'name': 'Transformers'}, 'task': 'inference', 'status': 'partial', 'acceptance': None, 'thresholds': None,
        'full_core_complete': False, 'model': {'name': 'Gemma-4-12B', 'revision': metrics['model']['revision']},
        'summary': 'One H100 loaded-model observer check: four cache-off modes, six target/distribution contrasts and 98 sampled boundaries. Native BF16 payloads match bitwise in this scope. The NPU attempt failed before model load at the shared-instance idle guard.',
        'common': ['One fixed 128+32-token input, one loaded eval model, BF16 parameters/native logits, eager attention, seed0 and TP1.',
            'Four 160-token forwards use_cache=false/logits_to_keep=0; 159 scores include127 prompt and32 continuation targets. Final prediction159 is retained but unscored.',
            'Same complete RNG and available observed model-state controls; one scalar BF16 buffer fingerprint gap remains explicit.',
            'Public target replay covers six pairs with zero arrays. Actual E02 independently replays all282 distribution contrasts and98 sampled boundary reductions.'],
        'differences': ['The observer mode changes only owned module hooks and frontend dispatch metadata collection; all sides share the same loaded GPU model.',
            'Frontend overload/shape/dtype census is not native-kernel/fusion/accumulation identity or full operand capture.',
            'No NPU observer numeric side exists. The spent NPU attempt failed its first busy-process guard; occupant workload ownership remains unknown and no other process was stopped.'],
        'sides': sides, 'comparisons': comparisons, 'scope': copy.deepcopy(metrics['scope']),
        'plan_coverage': {key: copy.deepcopy(coverage[key]) for key in ('task_count', 'core_task_count', 'counts', 'full_core_complete', 'original_49_task_scope_complete')},
        'execution_census': copy.deepcopy(metrics['execution_census']), 'state_control': copy.deepcopy(metrics['state_control']),
        'NPU_observer': copy.deepcopy(metrics['NPU_observer']), 'instrumented_execution_accounting': copy.deepcopy(cost),
        'independent_checks': {'report_sha256': e02['source_report_sha256'], 'controller_sha256': e02['source_controller_sha256'],
            'formal_report_sha256': e02['formal_report_sha256'], 'scope': copy.deepcopy(e02['scope']),
            'payload_identity': copy.deepcopy(e02['payload_identity']), 'diagnostic_verification': copy.deepcopy(e02['diagnostic_verification']),
            'formal_metrics_rewritten': False},
        'notes': ['This is one independent fixed input and one loaded process, not fresh-process repeatability or a completed GPU/NPU observer comparison.',
            'Top100-union probability errors and complement-merged JS retain their coarsened definitions. Full-precision boundary cosines remain unclamped.',
            'Formal JS remains zero/tied maximum0. Independent scalar arithmetic preserves its4.7021875179805497e-17 residual at predictor144 separately; diagnostic tolerances are not model acceptance thresholds.',
            'Four raw BF16 logits payloads and two enabled boundary sample payloads are bit-identical by actual source-bound hashes excluding mode metadata headers.',
            'The original scalar BF16 buffer content gap remains; there is no complete parameter/buffer byte attestation, full hidden trajectory, full operand value, native-kernel cause, quality or P01 performance claim.',
            'Known failed and successful CPU checks are included in accounting; nested source intervals are not billing/P01 and unknown full setup/transfer time remains unknown.',
            'Full 49-task/28-core completion remains false and numerical acceptance/thresholds remain null.'],
        'evidence': [{'label': label, 'url': 'evidence/'+ID+'/'+name} for name, label in
            [('report.md', 'Scoped GPU observer report'), ('coverage.json', 'Original49 task coverage ledger'),
             ('selected-targets.json', 'Four anonymous159-target vectors'), ('selected-metrics.json', 'Six target/distribution and98 sampled-boundary metrics'),
             ('replay-targets.py', 'Six-pair stdlib target replay'), ('cost.json', 'Recorded instrumented execution and CPU failure accounting'),
             ('e02-summary.json', 'Independent full-scope E02 and BF16 payload checks')]],
        'archive': {'revision': None, 'prefix': PREFIX, 'replay_cases': 6,
            'file_sha256': {name: digest(raw) for name, raw in files.items()}}}
    require(len(record['sides']) == 4 and len(record['comparisons']) == 6 and len(record['archive']['file_sha256']) == 7 and
        record['archive']['revision'] is None, 'prepared record must have six GPU pairs and an unfilled actual archive identity')
    privacy(record); return record


def finalize(output):
    started = time.monotonic(); old_handler = signal.getsignal(signal.SIGALRM) if hasattr(signal, 'SIGALRM') else None
    def expired(*_): raise TimeoutError('private finalizer exceeded60 seconds')
    if old_handler is not None: signal.signal(signal.SIGALRM, expired); signal.alarm(60)
    try:
        output = Path(output).absolute()
        require(output.resolve().is_relative_to(HERE.resolve()) and not output.exists() and
            not any(p.is_symlink() for p in output.parents if p.is_relative_to(CASE)), 'new exclusive private transfer directory required')
        sources = {name: metadata(ORIGINAL/name, sha) for name, sha in PINS.items()}
        failure_raw = [metadata(CASE/name, sha) for _, name, sha, _ in FAILURES]
        controls = [read(raw) for raw in failure_raw]
        cost = augmented_cost(read(sources['documents/cost.json']), controls)
        files = {Path(name).name: raw for name, raw in sources.items()}
        files['report.md'] = report_spacing(files['report.md']); files['cost.json'] = encode(cost)
        record = evaluation_record(read(files['selected-metrics.json']), read(files['selected-targets.json']),
            read(files['coverage.json']), cost, read(files['e02-summary.json']), files)
        for name, raw in files.items(): privacy(read(raw) if name.endswith('.json') else raw.decode())
        for name, sha in PINS.items(): require(metadata(ORIGINAL/name, sha) == sources[name], 'original candidate changed')
        output.mkdir(); (output/'public').mkdir(); (output/'private').mkdir()
        # Generated artifacts are emitted as three bounded groups: 3 + 3 + 2.
        groups = [['selected-targets.json', 'selected-metrics.json', 'replay-targets.py'],
            ['report.md', 'coverage.json', 'cost.json'], ['e02-summary.json']]
        for group in groups:
            for name in group:
                with (output/'public'/name).open('xb') as stream: stream.write(files[name]); stream.flush(); os.fsync(stream.fileno())
        with (output/'private/evaluation-record.json').open('xb') as stream: stream.write(encode(record)); stream.flush(); os.fsync(stream.fileno())
        for name, sha in PINS.items(): require(metadata(ORIGINAL/name, sha) == sources[name], 'original candidate changed during finalization')
        for raw, (_, name, sha, _) in zip(failure_raw, FAILURES): require(metadata(CASE/name, sha) == raw, 'original failed CPU controller changed')
        result = {'status': 'private_final_copy_and_unappended_record_prepared', 'public_files': {
            name: {'sha256': digest(raw), 'size_bytes': len(raw)} for name, raw in files.items()},
            'evaluation_record_sha256': digest(encode(record)), 'archive_revision': None,
            'original_candidates_modified': False, 'public_history_modified': False, 'git_modified': False,
            'arrays_statted_opened_copied': 0, 'native_executions': 0, 'elapsed_seconds': time.monotonic()-started}
        print(json.dumps(result, indent=2)); return result
    finally:
        if old_handler is not None: signal.alarm(0); signal.signal(signal.SIGALRM, old_handler)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--output', type=Path, required=True)
    finalize(parser.parse_args().output)

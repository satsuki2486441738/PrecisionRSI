"""CPU-only synthetic evidence, not a native model result or accelerator test.

The reduced 128-word vocabulary leaves a real complement outside top-100.
Different predictor rows prevent an off-by-one implementation from passing.
"""
from contextlib import ExitStack
import copy
import hashlib
import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import i01_admission_compare_v1 as a
import i01_expected_inventory_v1 as e


class SyntheticEvidence:
    """Construct artifacts without importing the collector or any framework."""
    def __init__(self, root):
        self.root=Path(root);self.out='/synthetic/non-native/run/artifacts';self.files={}
        self.doc={'sample':'synthetic-non-native','prompt':list(range(128)),'continuation':list(range(32))}
        self.input=self.add('/synthetic/input.json',self.doc)
        self.stage=self.add('/synthetic/stage.json',{'stage_id':e.STAGE_ID,'status':'prepared_not_executed',
            'thresholds':None,'acceptance':None,'full_core_complete':False})
        self.stack=ExitStack();self.stack.enter_context(patch.multiple(e,VOCABULARY=128,
            INPUT_SHA256=a.sha(self.input),STAGE_SHA256=a.sha(self.stage)))
        self.stack.enter_context(patch.object(a,'VOCABULARY',128))
        self.inv=e.derive(self.doc,e.INPUT_SHA256,e.STAGE_SHA256)
        self.external=self.add('/synthetic/expected.json',self.inv)
        self.stack.enter_context(patch.object(a,'EXPECTED_SHA',a.sha(self.external)))
        self.product('expected-inventory.json',self.inv)
        values=((np.arange(160)[:,None]*7+np.arange(128)[None,:]*11)%47-23).astype('<f4')/4
        bits=(values.view('<u4')>>16).astype('<u2')
        self.bits=bits
        header=json.dumps({'logits':{'dtype':'BF16','shape':[1,160,128],
            'data_offsets':[0,bits.nbytes]}},separators=(',',':')).encode()
        header+=b' '*(-len(header)%8)
        self.product('raw-native-logits.safetensors',struct.pack('<Q',len(header))+header+bits.tobytes())
        self.raw_sha=a.sha(self.path('raw-native-logits.safetensors'))
        seq=self.doc['prompt']+self.doc['continuation']
        # Fixture derivation uses NumPy's reduction; admission uses scalar fsum.
        z=values.astype(np.float64);z-=z.max(axis=1)[:,None];lp=z-np.log(np.exp(z).sum(axis=1))[:,None]
        base={'schema_version':1,'input_sha256':e.INPUT_SHA256,'inventory_sha256':a.EXPECTED_SHA,
            'raw_logits_sha256':self.raw_sha,'native_logits_dtype':'torch.bfloat16',
            'logprob_dtype':'float64','normalization':e.NORMALIZATION}
        scores=[{**row,'prediction_position':i,'logprob':float(lp[i,seq[i+1]])} for i,row in enumerate(self.inv['all_targets'])]
        self.product('target-scores.json',{**base,'kind':'i01-native-target-scores','scores':scores})
        positions=[]
        for coord in self.inv['distribution_positions']:
            p=coord['position'];prefix='dist-p%03d'%p
            roles=(['prompt_sample'] if p in self.inv['sampling']['conditioning_predictors'] else [])+(['continuation'] if p>=127 else [])
            descriptor={'path':prefix+'.npy','row':0}
            positions.append({**coord,'roles':roles,'scores':descriptor,'record':prefix+'.json'})
            self.product(prefix+'.json',{**base,**coord,'roles':roles,'target_position':p+1,'token':seq[p+1],
                'logprob':scores[p]['logprob'],'scores':descriptor})
            path=self.root/('f%03d.npy'%len(self.files));np.save(path,lp[p:p+1],allow_pickle=False)
            self.register(self.out+'/'+prefix+'.npy',path)
        self.product('distributions.json',{**base,'kind':'i01-native-distribution-rows','positions':positions})
        self.product('events.json',[{'stage':'full_forward','input_ids':seq,'positions':list(range(160)),
            'attention_mask':[[1]*160],'past_key_values':None,'use_cache':False,'logits_to_keep':0,'return_dict':True,
            'returned_cache':None,'native_logits_shape':[1,160,128],'native_logits_dtype':'torch.bfloat16'}])
        self.product('capture-summary.json',{'native_forward_calls':1,'native_logits_shape':[1,160,128],
            'native_logits_dtype':'torch.bfloat16','use_cache':False,'returned_cache':None,'logits_to_keep':0,
            'targets':159,'sampled_distributions':47,'unscored_native_prediction_indices':[159],
            'raw_logits':{'path':self.out+'/raw-native-logits.safetensors','sha256':self.raw_sha,
                'size_bytes':self.path('raw-native-logits.safetensors').stat().st_size}})
        for name in ('runtime','snapshot-verification','policy-before-load','policy-after-load','policy-after-capture','loaded-model-inventory'):
            self.product(name+'.json',{'synthetic_fixture':True})
        self.outer={'backend':'GPU','input_path':'/synthetic/input.json','stage_spec_source_path':'/synthetic/stage.json',
            'expected_inventory_source_path':'/synthetic/expected.json'}
        self.refresh()
    def close(self):self.stack.close()
    def register(self,original,path):
        self.files[original]={'path':path.name,'sha256':a.sha(path),'size':path.stat().st_size}
        return path
    def add(self,original,document):
        path=self.root/('f%03d%s'%(len(self.files),Path(original).suffix))
        if isinstance(document,bytes):path.write_bytes(document)
        else:a.put(path,document)
        return self.register(original,path)
    def product(self,name,document):return self.add(self.out+'/'+name,document)
    def path(self,name):return self.root/self.files[self.out+'/'+name]['path']
    def edit(self,name,fn):
        path=self.path(name);doc=e.load(path);fn(doc);path.write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8')
    def refresh(self):
        # Re-sign every semantic tamper so tests do not stop only at a stale SHA.
        for original,entry in self.files.items():self.register(original,self.root/entry['path'])
        manifest={'schema_version':1,'kind':'i01-capture-artifacts','task':e.TASK,'backend':'gpu',
            'stage_spec_sha256':e.STAGE_SHA256,'input_sha256':e.INPUT_SHA256,'expected_inventory_sha256':a.EXPECTED_SHA,
            'acceptance':None,'files':{Path(original).name:{'sha256':ref['sha256'],'size_bytes':ref['size']}
            for original,ref in self.files.items() if original.startswith(self.out+'/') and
                Path(original).name not in ('artifacts-manifest.json','status.json')}}
        for name,doc in [('artifacts-manifest.json',manifest)]:
            if self.out+'/'+name in self.files:self.path(name).write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8');self.register(self.out+'/'+name,self.path(name))
            else:self.product(name,doc)
        self.outer['artifacts_manifest_sha256']=a.sha(self.path('artifacts-manifest.json'))
        status={'status':'completed','rank':0,'task':e.TASK,'backend':'gpu','stage_spec_sha256':e.STAGE_SHA256,
            'artifacts_manifest_sha256':self.outer['artifacts_manifest_sha256'],'targets':159,'distribution_positions':47,
            'acceptance':None,'full_core_complete':False}
        if self.out+'/status.json' in self.files:self.path('status.json').write_text(json.dumps(status)+'\n',encoding='utf-8');self.register(self.out+'/status.json',self.path('status.json'))
        else:self.product('status.json',status)
        self.map=self.root/'source-map.json';self.map.write_text(json.dumps({'schema_version':1,'files':self.files})+'\n',encoding='utf-8')
    def endpoint(self):return a.Endpoint(self.map,a.sha(self.map))
    def inspect(self):return a.inspect_artifacts(self.endpoint(),self.out,self.outer)


class AdmissionTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.fx=SyntheticEvidence(self.tmp.name)
    def tearDown(self):self.fx.close();self.tmp.cleanup()
    def test_inventory_exact_grid_and_causal_boundary(self):
        inv=self.fx.inv
        self.assertEqual(inv['sampling']['conditioning_predictors'],[0,8,16,25,33,42,50,59,67,76,84,93,101,110,118,127])
        self.assertEqual([r['position'] for r in inv['all_targets']],list(range(1,160)))
        self.assertEqual([r['position'] for r in inv['cached_overlap_targets']],list(range(128,160)))
        self.assertEqual(len(inv['distribution_positions']),47);self.assertEqual(inv['distribution_positions'][15]['position'],127)
        self.assertEqual(inv['all_targets'][-1]['token'],31)
        bad=copy.deepcopy(self.fx.doc);bad['continuation'][0]=True
        with self.assertRaisesRegex(ValueError,'integer token'):e.derive(bad,e.INPUT_SHA256,e.STAGE_SHA256)
    def test_complete_raw_bf16_and_all159_47(self):
        result=self.fx.inspect()
        self.assertEqual((len(result['scores']),len(result['positions'])),(159,47))
        self.assertLessEqual(result['raw_rederivation_max_abs_delta'],1e-12)
        self.assertNotIn('torch',sys.modules)
    def test_rehashed_causal_shift_rejected(self):
        self.fx.edit('target-scores.json',lambda d:d['scores'][0].update(prediction_position=1));self.fx.refresh()
        with self.assertRaisesRegex(ValueError,'causal target'):self.fx.inspect()
    def test_rehashed_omitted_sampling_or_history_rejected(self):
        self.fx.edit('distributions.json',lambda d:d['positions'][0]['history'].append(0));self.fx.refresh()
        with self.assertRaisesRegex(ValueError,'prespecified'):self.fx.inspect()
    def test_rehashed_invented_score_rejected_by_raw(self):
        # p=1 is not sampled; only independent raw decoding can detect this.
        self.fx.edit('target-scores.json',lambda d:d['scores'][1].update(logprob=d['scores'][1]['logprob']+.01));self.fx.refresh()
        with self.assertRaisesRegex(ValueError,'raw BF16 predictor/target'):self.fx.inspect()
    def test_rehashed_normalized_wrong_distribution_rejected_by_raw(self):
        path=self.fx.path('dist-p000.npy');row=np.load(path,allow_pickle=False);row[0,[2,3]]=row[0,[3,2]];np.save(path,row,allow_pickle=False);self.fx.refresh()
        with self.assertRaisesRegex(ValueError,'full-vocabulary distribution'):self.fx.inspect()
    def test_missing_required_artifact_even_after_resign_rejected(self):
        del self.fx.files[self.fx.out+'/loaded-model-inventory.json'];self.fx.refresh()
        with self.assertRaisesRegex(ValueError,'member inventory'):self.fx.inspect()
    def test_raw_header_shape_or_extra_byte_rejected(self):
        path=self.fx.path('raw-native-logits.safetensors');raw=path.read_bytes()
        path.write_bytes(raw+b'\0')
        with self.assertRaisesRegex(ValueError,'payload length'):a.raw_tensor(path)
        header=json.loads(raw[8:8+struct.unpack('<Q',raw[:8])[0]]);header['logits']['shape']=[1,159,128]
        payload=json.dumps(header).encode();path.write_bytes(struct.pack('<Q',len(payload))+payload+self.fx.bits.tobytes())
        with self.assertRaisesRegex(ValueError,'shape/dtype'):a.raw_tensor(path)
    def test_unscored_last_row_nonfinite_rejected_after_resign(self):
        path=self.fx.path('raw-native-logits.safetensors');raw=bytearray(path.read_bytes());start=8+struct.unpack('<Q',raw[:8])[0]
        raw[start+2*159*128:start+2*159*128+2]=struct.pack('<H',0x7f80);path.write_bytes(raw)
        digest=a.sha(path)
        for name in ['target-scores.json','distributions.json']+['dist-p%03d.json'%p for p in self.fx.inv['sampling']['deduplicated_predictors']]:
            self.fx.edit(name,lambda d:d.update(raw_logits_sha256=digest))
        self.fx.edit('capture-summary.json',lambda d:d['raw_logits'].update(sha256=digest));self.fx.refresh()
        with self.assertRaisesRegex(ValueError,'nonfinite'):self.fx.inspect()
    def test_portable_gpu_has_no_retained_raw_fallback(self):
        ref=self.fx.files[self.fx.out+'/raw-native-logits.safetensors'];ref.pop('path');ref['retained_at_source']=True
        self.fx.map.write_text(json.dumps({'schema_version':1,'files':self.fx.files}),encoding='utf-8')
        with self.assertRaisesRegex(ValueError,'explicit NPU root'):self.fx.inspect()
    def test_runtime_sources_bind_original_copy_and_premodel(self):
        f=self.fx;packages={};copies={};sources={}
        for name in ('torch','transformers','numpy','modeling_source'):
            original='/synthetic/runtime/'+name+'.py';preserved='/synthetic/claim/frozen/'+name+'.py'
            path=f.add(original,('# synthetic '+name+'\n').encode());copied=f.add(preserved,path.read_bytes())
            ref={'path':original,'sha256':a.sha(path),'size_bytes':path.stat().st_size}
            copies[original]={**ref,'path':preserved};sources[original]=ref['sha256']
            if name=='modeling_source':modeling=ref
            else:packages[name]=ref
        mapping='/synthetic/claim/frozen-runtime-map.json';path=f.add(mapping,copies)
        before='/synthetic/claim/runtime-packages-before.json'
        before_path=f.add(before,{r['path']:copies[r['path']] for r in packages.values()});sources[before]=a.sha(before_path)
        outer={'runtime_source_map_path':mapping,'runtime_source_map_sha256':a.sha(path),'source_sha256':sources}
        runtime={'package_sources':packages,'model_identity':{'modeling_source':modeling}}
        f.refresh();a.runtime_copies(f.endpoint(),outer,runtime,'GPU')
        del sources[before]
        with self.assertRaisesRegex(ValueError,'observation was not frozen'):a.runtime_copies(f.endpoint(),outer,runtime,'GPU')
    def test_runtime_copy_metadata_cannot_rebind_original_bytes(self):
        f=self.fx;ref={'path':'/synthetic/runtime.py','sha256':'0'*64,'size_bytes':3}
        mapping=f.add('/synthetic/claim/runtime-map.json',{ref['path']:{**ref,'path':'/synthetic/copy.py','sha256':'1'*64}})
        outer={'runtime_source_map_path':'/synthetic/claim/runtime-map.json','runtime_source_map_sha256':a.sha(mapping),'source_sha256':{}}
        runtime={'package_sources':{'torch':ref,'transformers':ref,'numpy':ref},'model_identity':{'modeling_source':{**ref,'sha256':'1'*64}}}
        f.refresh()
        with self.assertRaisesRegex(ValueError,'original/copy runtime identity'):a.runtime_copies(f.endpoint(),outer,runtime,'GPU')
    def test_shared_compare_159_and_only_continuation32(self):
        data=self.fx.inspect();policy={'synthetic_fixture':True}
        base={**data,'model':{'synthetic_non_native':True},'hardware':{'category':'CPU-fixture'},'software':{'framework':'numpy-fixture'},
            'backend_policy':policy,'mode':{'use_cache':False}}
        left={**base,'side':'fixture-full-a'};right={**base,'side':'fixture-full-b'}
        out=Path(self.tmp.name)/'cross';report=a.compare_pair(out,left,right,data['targets'],
            self.fx.inv['distribution_positions'],'synthetic non-native fixture')
        self.assertEqual(report['targets']['coverage']['paired'],159)
        self.assertEqual(report['distributions']['position_count'],47)
        cached={**base,'side':'fixture-cached','scores':data['scores'][127:],
            'positions':[r for r in data['positions'] if r['position']>=127],'mode':{'use_cache':True}}
        out=Path(self.tmp.name)/'overlap';report=a.compare_pair(out,left,cached,self.fx.inv['cached_overlap_targets'],
            [r for r in self.fx.inv['distribution_positions'] if r['position']>=127],'synthetic non-native cached peer fixture')
        self.assertEqual(report['targets']['coverage']['paired'],32);self.assertEqual(report['distributions']['position_count'],32)
        with self.assertRaisesRegex(ValueError,'not fully covered'):
            a.comparison_documents(left,cached,data['targets'],self.fx.inv['distribution_positions'],'synthetic wrong all159 cached claim')


if __name__=='__main__':unittest.main()

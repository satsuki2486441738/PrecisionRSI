"""One bounded CPU metadata export after the real NPU I03 terminal receipt.

The original242 raw/NPY sources are hashed by the pinned exporter and retained.
No model, framework or device probe is imported. This is transport provenance;
independent numerical admission remains mandatory.
"""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import signal
import sys
import time

ROOT = Path('/srv/npu-precision-task/i03-partition-repeat-20261106')
CLAIM_NAME = 'npu-i03-REDACTED_DEVICE_UUID'
HERE = Path(__file__).resolve().parent
EXPORT_SHA = 'f083e3c857c5df08316270a5e792d3fb24f9eb0db96c54dff57612d5206eaf0e'
RECORD_SHA = '2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'
TOTAL, CHILD, ENVELOPE, CLEANUP = 960, 900, 920, 20
GIB = 1024 ** 3


def require(ok, message):
    if not ok: raise ValueError(message)


def utc(): return datetime.now(timezone.utc).isoformat()


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 ** 2), b''): value.update(block)
    return value.hexdigest()


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate JSON key'); result[key] = value
        return result
    def reject(value): raise ValueError('nonfinite JSON token ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs, parse_constant=reject)


def put(path, document):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(document, stream, indent=2, allow_nan=False); stream.write('\n')


def regular(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'original regular source required')
    return path


def preflight(root, here):
    root, here = Path(root), Path(here)
    require(root.is_dir() and not root.is_symlink() and here.is_dir() and
        not here.is_symlink() and here.resolve().is_relative_to(root.resolve()), 'new I03 task/tool roots required')
    exporter, recorder = here / 'export_i03_evidence_v1.py', here / 'record_run.py'
    require(sha(regular(exporter)) == EXPORT_SHA and sha(regular(recorder)) == RECORD_SHA, 'frozen CPU tool source differs')
    claim = root / 'claims' / CLAIM_NAME
    terminal, outer = claim / 'controller-receipt.json', claim / 'capture-receipt.json'
    controller, receipt = read(regular(terminal)), read(regular(outer))
    require(controller.get('task') == 'I03' and controller.get('status') == 'completed' and
        type(controller.get('returncode')) is int and controller['returncode'] == 0 and
        controller.get('timed_out') is False and controller.get('remaining_descendants') == [], 'NPU I03 lifecycle must be terminal and cleaned')
    fixed = {'task':'I03','backend':'NPU','status':'completed','returncode':0,'timed_out':False,
             'native_capture_count':1,'native_forward_calls_total':70,'model_loads':1}
    require(all(key in receipt and type(receipt[key]) is type(value) and receipt[key] == value for key,value in fixed.items()),
        'real successful70-call one-process NPU I03 capture required')
    begin = datetime.fromisoformat(controller['started_utc'])
    end = datetime.fromisoformat(controller['finished_utc'])
    require(begin.tzinfo is not None and end.tzinfo is not None and end >= begin, 'recorded native UTC interval required')
    elapsed = (end - begin).total_seconds()
    require(elapsed + TOTAL <= 3600, 'recorded native duration plus finite CPU envelope exceeds3600s stage accounting')
    require(not any(name in sys.modules for name in ('torch','torch_npu','numpy')), 'CPU export runner imported a framework')
    return exporter, recorder, terminal, outer, elapsed


def verify_result(result, mapping, source_map, outer, root):
    require(mapping.get('request') == {'task':'I03','backend':'NPU','outer_receipt':str(outer)}, 'source-map request differs')
    require(mapping.get('full_array_hashes_checked') == 242 and mapping.get('retained_array_count') == 242, 'all242 source arrays must be hashed and retained')
    retained = {path:item for path,item in mapping['files'].items() if item.get('retained_at_source') is True}
    require(len(retained) == 242 and all('path' not in item for item in retained.values()), 'retained array metadata differs')
    positions = sorted(set(i * 127 // 15 for i in range(16)) | set(range(127,159)))
    modes = ['full-r1','full-r2','full-r3','token','chunk63-65']
    expected = {'modes/%s/%s' % (mode,name) for mode in modes for name in
        ({'raw-native-logits.safetensors'} | {'dist-p%03d.npy' % p for p in positions})}
    expected |= {'modes/%s/final-native-kv.safetensors' % mode for mode in modes[3:]}
    output = PurePosixPath(read(outer)['output_dir'])
    require({PurePosixPath(path).relative_to(output).as_posix() for path in retained} == expected, 'exact five logits/two KV/235 NPY retained inventory differs')
    require(result.get('status') == 'i03_transport_export_completed' and result.get('retained_array_count') == 242 and
        result.get('native_executions_started') == 0 and result.get('transport_allowed_by_actual_size') is True and
        type(result.get('archive_bytes')) is int and 0 < result['archive_bytes'] <= 1536*1024**2 and
        type(result.get('logical_payload_bytes')) is int and result['logical_payload_bytes'] <= GIB and
        result.get('source_map_sha256') == sha(source_map), 'actual transport receipt/budget differs')
    archive = regular(result['archive'])
    require(archive.resolve().is_relative_to(Path(root).resolve()) and archive.stat().st_size == result['archive_bytes'] and
        sha(archive) == result['archive_sha256'], 'actual retained-array archive size/SHA differs')
    return retained


def main():
    os.umask(0o077)
    started = time.monotonic()
    exporter, recorder, terminal, outer, prior = preflight(ROOT, HERE)
    put(HERE / 'metadata-export-claim.json', {'task':'I03-metadata-export','claimed_utc':utc(),
        'outer_receipt_sha256':sha(outer),'runner_sha256':sha(__file__),'native_executions_started':0,
        'cpu_envelope_seconds':TOTAL,'automatic_retry':False})
    spec = importlib.util.spec_from_file_location('i03_export_generic_recorder', recorder)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    require(Path(module.__file__).resolve() == recorder.resolve() and sha(recorder) == RECORD_SHA, 'actual generic module source differs')
    def interrupted(signum, frame): raise KeyboardInterrupt('finite CPU export signal ' + str(signum))
    previous = {sig:signal.signal(sig, interrupted) for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP,signal.SIGALRM)}
    signal.setitimer(signal.ITIMER_REAL, max(.01, TOTAL - (time.monotonic() - started)))
    state = {'schema_version':1,'task':'I03-metadata-export','backend':'NPU','status':'running','started_utc':utc(),
        'total_budget_seconds':TOTAL,'child_work_timeout_seconds':CHILD,'generic_envelope_timeout_seconds':ENVELOPE,
        'cleanup_reserve_seconds':CLEANUP,'prior_native_lifecycle_seconds':prior,'maximum_recorded_native_plus_cpu_seconds':prior+TOTAL,
        'native_executions_started':0,'source_arrays_retained':True,'exporter_sha256':EXPORT_SHA,'generic_recorder_sha256':RECORD_SHA,
        'runner_sha256':sha(__file__),'capture_controller_sha256':sha(terminal),'outer_receipt_sha256':sha(outer),'acceptance':None}
    code, run = 1, None
    try:
        remaining = TOTAL - (time.monotonic() - started) - CLEANUP
        require(remaining >= ENVELOPE, 'CPU export work budget unavailable')
        run, command = module.record_run(ROOT / 'exports','npu','i03-metadata-export',ENVELOPE,
            lambda folder:[sys.executable,'-B',str(exporter),'--outer-receipt',str(outer),'--task-root',str(ROOT),
                           '--output',str(folder / 'payload'),'--retain-arrays'],cwd=ROOT)
        state['generic_receipt'] = {'path':str(run / 'command.json'),'sha256':sha(run / 'command.json')}
        require(command['status'] == 'completed' and command['returncode'] == 0, 'CPU export failed; raw logs/partial output retained')
        result = read(run / 'stdout.bin'); payload = run / 'payload'; source_map = payload / 'source-map.json'
        mapping = read(source_map); retained = verify_result(result,mapping,source_map,outer,ROOT)
        require(sha(exporter) == EXPORT_SHA and sha(recorder) == RECORD_SHA and sha(terminal) == state['capture_controller_sha256'] and
            sha(outer) == state['outer_receipt_sha256'], 'frozen tool/capture source changed during CPU export')
        state.update(status='completed',source_map_path=str(source_map),source_map_sha256=sha(source_map),
            mapped_files=len(mapping['files']),retained_arrays=len(retained),archive=result,raw_capture_and_arrays_unmodified=True)
        code = 0
    except BaseException as exc:
        state.update(status='failed',error_type=type(exc).__name__,error=str(exc),automatic_retry=False)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        for sig,handler in previous.items():signal.signal(sig,handler)
        state.update(finished_utc=utc(),elapsed_seconds=time.monotonic()-started,returncode=code)
        target = run / 'metadata-export-controller.json' if run is not None else HERE / ('export-launch-failure-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '.json')
        put(target,state)
        print(json.dumps({**state,'controller_path':str(target)},allow_nan=False),flush=True)
    return code


if __name__ == '__main__': raise SystemExit(main())

"""Finite I03 tool/GPU archive import; regular members, exact hashes, no overwrite."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path,PurePosixPath
import re
import shutil
import signal
import tarfile
import time

CASE='projects/gemma4-pilot/cases/text-native'
MAIN=CASE+'/adapters/admit_i03_partition_repeat_v1.py'
MAIN_SHA='2468a5f2a1aafe9f9437edae2bd90b3bdca15f9c1abcc6fa3b927ddb8167691c'
HELPER=CASE+'/adapters/i03_artifact_admission_v1.py'
HELPER_SHA='b734babc65be6ec361acbc10905b6c3e02e8c5c57650efb11e3a195134a1b6eb'
STAGE_SHA='6e53e3cdf3e7fad8f56b43cb99a42bdb999ac074a5a40a3c1e7df72eeb504005'
MODES=['full-r1','full-r2','full-r3','token','chunk63-65']
POSITIONS=sorted(set(i*127//15 for i in range(16))|set(range(127,159)))
LARGE={'modes/'+mode+'/'+name for mode in MODES for name in ({'raw-native-logits.safetensors'}|{'dist-p%03d.npy'%p for p in POSITIONS})}
LARGE|={'modes/'+mode+'/final-native-kv.safetensors' for mode in MODES[3:]}
HEX=re.compile(r'^[a-f0-9]{64}$')


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def load(path):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_text(),object_pairs_hook=pairs,parse_constant=reject)


def put(path,value):
    with Path(path).open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def safe_name(name):
    p=PurePosixPath(name);require(isinstance(name,str) and name and not p.is_absolute() and '\\' not in name and str(p)==name and
        all(part not in ('','.','..') for part in name.split('/')),'unsafe/noncanonical archive path');return name


def extract(archive,output,max_expanded):
    require(not output.exists() and output.parent.is_dir(),'exclusive new import directory required')
    with tarfile.open(archive,'r:*') as package:
        members=package.getmembers();names=[safe_name(m.name) for m in members];memberset=set(names)
        require(members and len(members)<=2048 and len(names)==len(memberset) and all(m.isfile() and m.size>=0 for m in members),
            'unique regular archive members required')
        require(all(not any(str(parent) in memberset for parent in PurePosixPath(name).parents if str(parent)!='.') for name in names),'archive ancestor file collision')
        total=sum(m.size for m in members);require(total<=max_expanded,'archive exceeds finite expanded logical cap')
        require(shutil.disk_usage(output.parent).free>=max(5*1024**3,total+1024**3),'source observed free space below5GiB/import bound')
        output.mkdir(mode=0o700)
        for member in members:
            target=output/member.name;target.parent.mkdir(parents=True,exist_ok=True)
            require(target.resolve().is_relative_to(output.resolve()),'resolved archive member escapes new import')
            source=package.extractfile(member);require(source is not None,'regular member stream missing');count=0
            with source,target.open('xb') as destination:
                for block in iter(lambda:source.read(4*1024**2),b''):destination.write(block);count+=len(block)
            require(count==member.size,'member byte count differs')
    return set(names),total


def verify_tools(output,names,manifest_sha):
    manifest=output/'tool-bundle-manifest.json';require(HEX.fullmatch(manifest_sha) and sha(manifest)==manifest_sha,'external tool manifest pin differs')
    doc=load(manifest);require(doc['kind']=='i03-offline-tool-bundle' and doc['acceptance'] is None and doc['native_executions_started']==0,'wrong offline tool bundle')
    require(set(doc['files'])|{'tool-bundle-manifest.json'}==names and doc['files'][MAIN]['sha256']==MAIN_SHA and doc['files'][HELPER]['sha256']==HELPER_SHA,
        'tool member set/frozen independent source differs')
    for name,ref in doc['files'].items():
        path=output/safe_name(name);require(path.stat().st_size==ref['size_bytes'] and sha(path)==ref['sha256'],'tool byte identity differs: '+name)
    return {'manifest':str(manifest),'manifest_sha256':manifest_sha,'source_files_checked':len(doc['files'])}


def verify_gpu(output,names,map_sha):
    mapping=output/'source-map.json';require(HEX.fullmatch(map_sha) and sha(mapping)==map_sha,'external actual GPU source-map pin differs')
    doc=load(mapping);request=doc['request'];require(request['task']=='I03' and request['backend']=='GPU' and doc['full_array_hashes_checked']==242 and
        doc['retained_array_count']==0 and doc['acceptance'] is None,'full copied GPU I03 export required')
    payload=set();large=[];logical=0
    for original,ref in doc['files'].items():
        p=PurePosixPath(original);require(p.is_absolute() and '..' not in p.parts and '\\' not in original and 'path' in ref and
            not ref.get('retained_at_source') and type(ref.get('size')) is int and ref['size']>=0 and HEX.fullmatch(ref['sha256']),
            'complete original POSIX/copy descriptor required')
        relative=safe_name(ref['path']);require(relative.startswith('payload/') and relative not in payload,'duplicate/malformed mapped payload path')
        payload.add(relative);actual=output/relative;require(actual.is_file() and actual.stat().st_size==ref['size'] and sha(actual)==ref['sha256'],
            'actual mapped GPU payload size/SHA differs')
        logical+=ref['size']
        if p.suffix in ('.npy','.safetensors'):large.append(original)
        else:require(ref['size']<=16*1024**2,'unexpected metadata larger than16MiB')
    outerref=doc['files'][request['outer_receipt']];outer=load(output/outerref['path']);original_output=PurePosixPath(outer['output_dir'])
    require(outer['task']=='I03' and outer['backend']=='GPU' and outer['status']=='completed' and outer['returncode']==0 and outer['timed_out'] is False and
        outer['native_forward_calls_total']==70 and outer['model_loads']==1 and outer['stage_spec_source_sha256']==STAGE_SHA,'actual completed70call GPU envelope differs')
    relative_large=[]
    for original in large:
        path=PurePosixPath(original);require(path.is_relative_to(original_output),'unexpected model/environment/old arrays in GPU packet')
        relative_large.append(path.relative_to(original_output).as_posix())
    require(len(relative_large)==242 and set(relative_large)==LARGE and logical<=1024**3,'exact235NPY+5logits+2KV/logical1GiB inventory required')
    require(names==payload|{'source-map.json','export-summary.json'},'unmapped/omitted GPU archive member')
    return {'source_map':str(mapping),'source_map_sha256':map_sha,'mapped_files_checked':len(payload),'native_array_files_checked':242,
        'copied_logical_bytes':logical,'raw_receipts_rewritten':False,'numeric_admission_performed':False}


def import_archive(root,archive,kind,digest,size,manifest_sha=None,map_sha=None):
    require(not Path(root).is_symlink() and not Path(archive).is_symlink(),'original root/archive symlink prohibited')
    root=Path(root).resolve(strict=True);archive=Path(archive).resolve(strict=True)
    require(archive.is_relative_to(root) and archive.is_file(),'uploaded archive must be below explicit R')
    require(HEX.fullmatch(digest) and type(size) is int and size>0 and archive.stat().st_size==size and sha(archive)==digest,'uploaded archive size/SHA differs')
    require(kind in ('gpu','tools') and size<=(1536*1024**2 if kind=='gpu' else 2*1024**2),'encoded transport cap exceeded')
    parent=root/('imports' if kind=='gpu' else 'tools');require(not parent.is_symlink() and parent.resolve().is_relative_to(root),'new import parent escapes R')
    parent.mkdir(mode=0o700,exist_ok=True);label='gpu-i03-full' if kind=='gpu' else 'i03-cpu-compare-v1'
    output=parent/(label+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));receipt=parent/(output.name+'-import-receipt.json')
    state={'schema_version':1,'kind':kind,'status':'running','started_utc':datetime.now(timezone.utc).isoformat(),'archive':str(archive),
        'archive_sha256':digest,'archive_bytes':size,'output':str(output),'cpu_timeout_seconds':900,'original_archive_preserved':True,'automatic_retry':False,'acceptance':None}
    started=time.monotonic()
    try:
        names,expanded=extract(archive,output,1024**3 if kind=='gpu' else 4*1024**2)
        state.update(verify_gpu(output,names,map_sha) if kind=='gpu' else verify_tools(output,names,manifest_sha))
        require(sha(archive)==digest,'original uploaded archive changed during import')
        state.update(status='completed',returncode=0,regular_members=len(names),expanded_bytes=expanded)
    except BaseException as exc:state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),partial_output_preserved=True)
    finally:
        state.update(finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started);put(receipt,state)
    print(json.dumps({**state,'receipt':str(receipt)},indent=2),flush=True);return state['returncode']


def self_test():
    import io,tempfile
    for name in ('../bad','a/../x','a//x','/absolute','a\\x','./x',''):
        try:safe_name(name)
        except ValueError:pass
        else:raise AssertionError('unsafe synthetic name accepted')
    with tempfile.TemporaryDirectory() as temporary:
        root=Path(temporary)
        for kind in ('duplicate','symlink','ancestor'):
            path=root/(kind+'.tar')
            with tarfile.open(path,'w') as package:
                for name in (['x','x'] if kind=='duplicate' else ['x','x/y'] if kind=='ancestor' else ['x']):
                    info=tarfile.TarInfo(name);info.size=1
                    if kind=='symlink':info.type=tarfile.SYMTYPE;info.linkname='/synthetic/outside';info.size=0
                    package.addfile(info,io.BytesIO(b'x'))
            try:extract(path,root/(kind+'-output'),1024)
            except ValueError:pass
            else:raise AssertionError('unsafe synthetic archive accepted')
    print('synthetic_I03_archive_path_regressions_passed; native_executions_started=0')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--self-test',action='store_true')
    parser.add_argument('--root',type=Path);parser.add_argument('--archive',type=Path);parser.add_argument('--kind',choices=['gpu','tools'])
    parser.add_argument('--archive-sha256');parser.add_argument('--archive-bytes',type=int);parser.add_argument('--manifest-sha256');parser.add_argument('--source-map-sha256');args=parser.parse_args()
    if args.self_test:self_test();return 0
    require(all(getattr(args,name) is not None for name in ('root','archive','kind','archive_sha256','archive_bytes')),'all actual paths/size/SHA pins required')
    require(args.source_map_sha256 is not None if args.kind=='gpu' else args.manifest_sha256 is not None,'independent actual map/manifest pin required')
    def expire(*_):raise TimeoutError('I03 import CPU900s deadline reached')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,900)
    try:return import_archive(args.root,args.archive,args.kind,args.archive_sha256,args.archive_bytes,args.manifest_sha256,args.source_map_sha256)
    finally:signal.setitimer(signal.ITIMER_REAL,0)


if __name__=='__main__':raise SystemExit(main())

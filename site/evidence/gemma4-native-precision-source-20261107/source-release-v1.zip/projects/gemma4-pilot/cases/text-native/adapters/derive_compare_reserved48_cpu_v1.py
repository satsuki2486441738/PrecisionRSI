"""Draft common-CPU reserved48 derivation/comparison; actual gates remain None.

Each bin writes72 NEW [47,V] FP64 matrices from original selected BF16 evidence,
then compares108 input/pair observations. The cohort phase reads sealed numeric
metadata and admitted source-scalar views, without reopening native/FP64 arrays.
Unselected source normalizers are not independently replayable. No model/device.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import sys
import time

import reserved48_cpu_artifacts_v1 as artifacts

TASK = artifacts.TASK
NORMALIZATION_TOLERANCE = 1e-10  # Full-row evidence validity, not model acceptance.


def require(ok, message): artifacts.require(ok, message)
def put(path, doc): artifacts.put(path, doc)
def load(path): return artifacts.load(path)
def ref(path): return artifacts.ref(path)
def utc(): return datetime.now(timezone.utc).isoformat()


class Budget:
    """Software/time/RSS/storage observations, not memory/disk reservation."""
    def __init__(self, output, document, workspace):
        self.output = Path(output); self.document = document; self.started = time.monotonic(); self.sample = 0
        self.workspace = Path(workspace)
        require(self.workspace.is_absolute() and self.workspace.is_dir() and not self.workspace.is_symlink() and
                self.output.resolve().is_relative_to(self.workspace.resolve()), 'explicit owned CPU workspace required')
        limits = document['limits']
        require(limits['per_bin_cpu_seconds'] == 3600 and limits['cleanup_seconds'] == 20 and limits['cpu_row_chunk'] == 32 and
            limits['maximum_working_memory_bytes'] == 512 * 1024**2 and limits['maximum_bin_product_bytes'] == 12 * 1024**3 and
            limits['maximum_cohort_product_bytes'] == 64 * 1024**3 and limits['minimum_free_before_start_bytes'] == 96 * 1024**3,
            'reviewed finite CPU proposal differs')
        require(not self.output.exists() and not self.output.is_symlink() and self.output.parent.is_dir(), 'exclusive new CPU output required')
        require(shutil_free(self.output.parent) >= limits['minimum_free_before_start_bytes'], 'CPU free-space guard failed')
        self.check_workspace()
        self.output.mkdir(mode=0o700); self.audit = artifacts.Audit(3580)

    def check_workspace(self):
        total = 0
        for path in self.workspace.rglob('*'):
            require(not path.is_symlink(), 'CPU cohort workspace contains link')
            if path.is_file(): total += path.stat().st_size
        require(total <= self.document['limits']['maximum_cohort_product_bytes'], 'CPU cohort workspace exceeds64GiB')
        return total

    def tick(self):
        self.audit.tick()
        if time.monotonic() < self.sample: return
        self.sample = time.monotonic() + 2
        import resource
        require(sys.platform.startswith('linux'), 'RSS accounting requires the reviewed Linux CPU protocol')
        maximum = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
        require(maximum <= self.document['limits']['maximum_working_memory_bytes'], 'CPU observed maximum RSS exceeds512MiB')
        total = 0
        for path in self.output.rglob('*'):
            require(not path.is_symlink(), 'CPU output contains link')
            if path.is_file(): total += path.stat().st_size
        require(total <= self.document['limits']['maximum_bin_product_bytes'], 'CPU bin product cap exceeded')


def shutil_free(path):
    import shutil
    return shutil.disk_usage(path).free


def common_bindings(request):
    return {name: request[name]['sha256'] for name in ('stage_spec', 'expected_inventory', 'budget', 'cpu_prerequisite', 'manifest')}


def source_view(path, row, observation, backend, mode):
    """A NEW compact scalar view; original source JSON is never rewritten."""
    source = observation['source_target_ref']
    document = {'schema_version': 1, 'kind': 'new_cpu_view_of_admitted_source_target_scalars', 'task': TASK,
        'sample': row['sample'], 'backend': backend, 'mode': mode, 'input_sha256': row['input_sha256'],
        'source_path': source['path'], 'original_source': source,
        'source_normalization_execution': 'source-host NumPy float64 full-vocabulary matrices',
        'independent_all_target_normalizers': False,
        'scores': [{key: score[key] for key in ('sample', 'position', 'token', 'logprob')} for score in observation['source_scores']]}
    put(path, document); return ref(path)


def target_map(document, row, continuation_only=False):
    scores = document['scores']; expected = list(range(1, row['sequence_length']))
    require(len(scores) == len(expected) and document['sample'] == row['sample'], 'admitted scalar-view inventory differs')
    result = {}
    for score, position in zip(scores, expected):
        require(score['sample'] == row['sample'] and type(score['position']) is int and score['position'] == position and
                type(score['token']) is int and score['token'] == row['input_ids'][position] and
                type(score['logprob']) in (int, float) and math.isfinite(score['logprob']) and score['logprob'] <= 0,
                'admitted scalar-view coordinate/value differs')
        if not continuation_only or position >= row['prompt_length']:
            result[(row['sample'], position, score['token'])] = score['logprob']
    return result


def source_profile(endpoint_data, mode):
    runtime, policy = endpoint_data['runtime'], endpoint_data['policy']
    return {'backend': endpoint_data['endpoint'].backend, 'partition': mode,
        'source_software': runtime['versions'], 'source_backend_policy': policy,
        'source_native_receipt': endpoint_data['endpoint'].info['receipt'],
        'derivation': artifacts.DERIVATION, 'normalization_location': 'new_common_CPU_artifact'}


def write_rank(folder, side, profile, common, derived):
    """Owning condition/rank schema; actual source receipt remains a separate ref."""
    side_fields = {'backend': profile['backend'], 'partition': profile['partition'],
        'source_backend_policy_sha256': hashlib.sha256(artifacts.canonical(profile['source_backend_policy']).encode()).hexdigest(),
        'normalization_location': profile['normalization_location']}
    environment = folder / (side + '-environment.json'); status = folder / (side + '-status.json')
    put(environment, {'rank': 0, 'versions': profile['source_software'], 'actual': {**common, **side_fields},
        'original_native_execution': profile['source_native_receipt'], 'new_cpu_matrix': derived['matrix']})
    put(status, {'rank': 0, 'status': 'completed', 'original_native_execution': profile['source_native_receipt'],
                 'new_cpu_matrix_sha256': derived['matrix']['sha256']})
    return side_fields, {'rank': 0, 'environment': environment.name, 'status': status.name}


def compare_pair(folder, row, pair, observations, vocabulary=artifacts.VOCABULARY):
    """Use the shared full-array comparator; scores.row is owned/documented."""
    _, shared = artifacts.libraries(); folder.mkdir(mode=0o700)
    keys = [(pair['a_backend'], pair['a_mode']), (pair['b_backend'], pair['b_mode'])]
    sides = [backend.lower() + '-' + mode for backend, mode in keys]
    common = {'model': 'google/gemma-4-12B@1a2c7729392586f5ecddae8807ee2ef741eabb9a',
        'inputs': {'sample': row['sample'], 'input_sha256': row['input_sha256']},
        'numerics': {'parameter_dtype': 'BF16', 'native_logits_dtype': 'BF16', 'logprob_dtype': 'float64', 'attention': 'eager'},
        'scope': 'one reserved English article; selected47 full-vocabulary native predictors, newly derived on common CPU'}
    expected = [{'sample': row['sample'], 'position': p, 'history': row['input_ids'][:p + 1]} for p in row['distribution_positions']]
    contract = {'schema_version': 1, 'kind': 'distributions', 'thresholds': None, 'common': common,
        'expected_ranks': {side: [0] for side in sides}, 'side_conditions': {}, 'vocab_size': vocabulary,
        'normalization_tolerance': NORMALIZATION_TOLERANCE, 'renormalization': 'none', 'positions': expected}
    manifests = []
    for side, key in zip(sides, keys):
        observation = observations[key]; derived = load(observation['derivation']['path'])
        require(ref(observation['derivation']['path']) == observation['derivation'], 'new derived metadata changed')
        require(len(derived['positions']) == 47 and derived['derivation'] == artifacts.DERIVATION and
                derived['original_GPU_or_NPU_FP64_array'] is False, 'new CPU artifact provenance differs')
        for index, (coordinate, actual) in enumerate(zip(expected, derived['positions'])):
            require(all(actual[name] == coordinate[name] for name in ('sample', 'position', 'history')) and
                    actual['scores'] == {'path': derived['matrix']['path'], 'row': index},
                    'new multirow matrix selector/history differs')
        fields, rank = write_rank(folder, side, observation['profile'], common, derived)
        contract['side_conditions'][side] = fields
        manifest = {'schema_version': 1, 'kind': 'distributions', 'side': side, 'common': common, 'expected_ranks': [0],
            'ranks': [rank], 'positions': [{key: actual[key] for key in ('sample', 'position', 'history', 'scores')} for actual in derived['positions']]}
        path = folder / (side + '.json'); put(path, manifest); manifests.append(path)
    contract_path = folder / 'contract.json'; put(contract_path, contract)
    distribution = shared['compare_distributions'].compare(contract_path, *manifests)
    require(distribution['status'] == 'no_thresholds' and distribution['position_count'] == 47,
            'shared full-vocabulary comparison was unavailable; no partial aggregate')
    scalar = [load(observations[key]['source_scalar_view']['path']) for key in keys]
    target = shared['score_metrics'].reduce_scores(*[target_map(doc, row) for doc in scalar])
    continuation = shared['score_metrics'].reduce_scores(*[target_map(doc, row, True) for doc in scalar])
    document = {'schema_version': 1, 'kind': 'reserved48_input_pair', 'task': TASK, 'sample': row['sample'],
        'prompt_length': row['prompt_length'], 'pair': pair, 'sides': sides, 'target_metrics': target,
        'continuation_target_metrics': continuation, 'distribution': distribution,
        'independent_all_target_normalizers': False, 'new_common_cpu_selected_rows': True,
        'thresholds': None, 'acceptance': None, 'native_executions_started': 0}
    path = folder / 'pair-report.json'; put(path, document); return ref(path)


def run_bin(request, inventory, prompt_bin, output):
    budget = Budget(output, load(request['budget']['path']), request['cpu_workspace_root']); audit = budget.audit
    context = {}
    for backend in ('GPU', 'NPU'):
        endpoint = artifacts.Endpoint(audit, request['source_maps'][backend][str(prompt_bin)], backend, prompt_bin)
        context[backend] = artifacts.admit_endpoint(endpoint, inventory, request['stage_spec']['sha256'], request['expected_inventory']['sha256'])
    require(len({path for value in context.values() for path in value['native_paths']}) == 72,
            'two independent source-job native inventories must not alias')
    require(len({str(value['endpoint'].get(path, large=True).resolve()) for value in context.values() for path in value['native_paths']}) == 72,
            'distinct native observations resolve to the same physical source file')
    rows = artifacts.expected_rows(inventory, prompt_bin); catalog = {}; all_pair_refs = []; anchors = {}
    for row in rows:
        observations = {}
        for backend in ('GPU', 'NPU'):
            for mode in artifacts.MODES:
                budget.tick(); folder = budget.output / 'observations' / backend.lower() / row['sample'] / mode
                folder.mkdir(mode=0o700, parents=True)
                admitted = artifacts.admit_observation(context[backend]['endpoint'], context[backend]['output'], row, mode,
                    context[backend]['baseline'], context[backend]['runtime']['device_argument'], anchors.get(backend))
                anchors.setdefault(backend, admitted['rng_before'])
                derived = artifacts.derive_selected(admitted['native_path'], admitted['native_ref'], row, admitted['selection'],
                    admitted['source_scores'], folder / 'selected-logprobs.npy', audit)
                put(folder / 'derivation.json', derived)
                scalar = source_view(folder / 'admitted-source-scalars.json', row, admitted, backend, mode)
                item = {'sample': row['sample'], 'backend': backend, 'mode': mode, 'matrix': derived['matrix'],
                    'derivation': ref(folder / 'derivation.json'), 'source_scalar_view': scalar,
                    'original_selected_native': admitted['native_ref'], 'profile': source_profile(context[backend], mode),
                    'source_admission': admitted['source_admission']}
                observations[(backend, mode)] = item; catalog['/'.join((backend, row['sample'], mode))] = item
                del derived, admitted
        pair_root = budget.output / 'pairs' / row['sample']; pair_root.mkdir(mode=0o700, parents=True)
        for index, pair in enumerate(inventory['pairs_per_input']):
            budget.tick(); all_pair_refs.append(compare_pair(pair_root / ('pair-%02d' % index), row, pair, observations))
    require(len(catalog) == 72 and len(all_pair_refs) == 108, 'complete bin observations/pairs required')
    # Source hashes are refreshed once at completion, including selected BF16.
    audit.finish()
    for item in catalog.values():
        require(ref(item['matrix']['path']) == item['matrix'] and ref(item['derivation']['path']) == item['derivation'] and
                ref(item['source_scalar_view']['path']) == item['source_scalar_view'], 'new CPU artifact changed during comparison')
    budget.tick()
    workspace_bytes = budget.check_workspace()
    result = {'schema_version': 1, 'kind': 'reserved48_cpu_bin_report', 'task': TASK, 'status': 'completed', 'prompt_bin': prompt_bin,
        'bindings': common_bindings(request), 'source_maps': {backend: request['source_maps'][backend][str(prompt_bin)] for backend in context},
        'observations': catalog, 'input_pair_reports': all_pair_refs, 'input_count': 12, 'native_observations': 72,
        'source_target_scalars_checked': sum(context[side]['source_target_count'] for side in context),
        'source_native_rows_claimed_finite': sum(context[side]['source_finite_row_claim'] for side in context),
        'selected_BF16_full_rows_independently_rederived': 3384, 'new_FP64_matrices': 72,
        'input_pairs': 108, 'distribution_pair_positions': 5076,
        'independent_all_target_normalizers': False, 'full_unselected_raw_audit': False,
        'independent_algorithm_scalar_E02_executed': False,
        'whole_cohort_complete': False, 'Q02_executed': False, 'P01_executed': False,
        'thresholds': None, 'acceptance': None, 'native_executions_started': 0,
        'instrumented_cpu_seconds': time.monotonic() - budget.started,
        'observed_cohort_workspace_bytes_before_terminal': workspace_bytes, 'storage_guards_are_sampled_not_reserved': True,
        'scope': 'One complete12-input length bin; source scalar evidence and newly derived selected full rows, without native model work'}
    put(budget.output / 'bin-report.json', result); return ref(budget.output / 'bin-report.json')


def pinned_json(value, root=None, audit=None):
    path = Path(value['path']); require(ref(path) == value, 'sealed CPU metadata bytes changed')
    if root is not None: require(path.resolve().is_relative_to(Path(root).resolve()), 'sealed CPU metadata escapes bin output')
    if audit is not None: audit.file(path, value['sha256'], value['size_bytes'])
    return load(path)


def aggregate(request, inventory, bin_refs, output):
    """No native/derived tensor IO: combine sealed per-position numeric metadata."""
    require(len(bin_refs) == 4, 'all four completed bins required')
    np, shared = artifacts.libraries(); del np
    sealed = artifacts.Audit(3580)
    reports = [pinned_json(value, audit=sealed) for value in bin_refs]
    require({value['prompt_bin'] for value in reports} == set(artifacts.BINS), 'no missing/duplicated/failed length bin')
    by_bin = {value['prompt_bin']: (value, Path(reference['path']).parent) for value, reference in zip(reports, bin_refs)}
    rows = {row['sample']: row for row in inventory['samples']}; catalog = {}; pairs = [[] for _ in range(9)]; profiles = {}
    expected_samples = set(rows)
    for P, (report, root) in by_bin.items():
        require(report['kind'] == 'reserved48_cpu_bin_report' and report['task'] == TASK and report['status'] == 'completed' and
            report['bindings'] == common_bindings(request) and report['input_count'] == 12 and report['native_observations'] == 72 and
            report['input_pairs'] == 108 and report['distribution_pair_positions'] == 5076 and report['native_executions_started'] == 0 and
            report['independent_all_target_normalizers'] is False and report['full_unselected_raw_audit'] is False,
            'complete sealed bin scope differs')
        require(report['source_maps'] == {backend: request['source_maps'][backend][str(P)] for backend in ('GPU', 'NPU')},
                'sealed bin source map identity differs from final cohort request')
        for key, item in report['observations'].items():
            require(key not in catalog and item['sample'] in rows and rows[item['sample']]['prompt_length'] == P,
                    'duplicate or wrong-bin source observation')
            require(item['backend'] in ('GPU', 'NPU') and item['mode'] in artifacts.MODES and
                    key == '/'.join((item['backend'], item['sample'], item['mode'])) and
                    item['profile']['backend'] == item['backend'] and item['profile']['partition'] == item['mode'],
                    'cohort observation identity/profile differs')
            profile_key = (item['backend'], item['mode'])
            conditions = {field: item['profile'][field] for field in ('backend', 'partition', 'source_software', 'source_backend_policy', 'derivation', 'normalization_location')}
            if profile_key in profiles: require(artifacts.canonical(profiles[profile_key]) == artifacts.canonical(conditions), 'source software/policy drift across bins')
            profiles[profile_key] = conditions
            pinned_json(item['source_scalar_view'], root, sealed); pinned_json(item['derivation'], root, sealed)
            # Matrix and original native arrays remain descriptors in aggregate.
            catalog[key] = item
        require(len(report['input_pair_reports']) == 108, 'sealed bin pair inventory differs')
        observed = set()
        for item in report['input_pair_reports']:
            pair_report = pinned_json(item, root, sealed); sample = pair_report['sample']
            index = inventory['pairs_per_input'].index(pair_report['pair']); key = (sample, index)
            require(key not in observed and sample in rows and rows[sample]['prompt_length'] == P and
                pair_report['distribution']['status'] == 'no_thresholds' and pair_report['distribution']['position_count'] == 47,
                'sealed per-input comparison inventory differs')
            observed.add(key); pairs[index].append(pair_report)
        require(len(observed) == 108, 'missing input-level pair in sealed bin')
    require(len(catalog) == 288 and all(len(value) == 48 for value in pairs) and
            set(catalog) == {'/'.join((backend, sample, mode)) for backend in ('GPU', 'NPU') for sample in expected_samples for mode in artifacts.MODES},
            'complete48-input cohort required')
    budget = Budget(output, load(request['budget']['path']), request['cpu_workspace_root'])
    output = budget.output; corpus = []
    for index, pair in enumerate(inventory['pairs_per_input']):
        budget.tick()
        maps = [{}, {}]; continuations = [{}, {}]
        keys = [(pair['a_backend'], pair['a_mode']), (pair['b_backend'], pair['b_mode'])]
        for row in inventory['samples']:
            for side_index, (backend, mode) in enumerate(keys):
                item = catalog['/'.join((backend, row['sample'], mode))]
                document = pinned_json(item['source_scalar_view'], audit=sealed)
                current = target_map(document, row); tail = target_map(document, row, True)
                require(not set(maps[side_index]) & set(current), 'duplicate corpus target coordinate')
                maps[side_index].update(current); continuations[side_index].update(tail)
        require(all(len(value) == 132048 for value in maps) and all(len(value) == 1536 for value in continuations),
                'all-target/continuation corpus inventory differs')
        distribution_rows = [position for result in pairs[index] for position in result['distribution']['positions']]
        require(len(distribution_rows) == 2256, 'all48x47 distribution positions required per family')
        corpus.append({'pair': pair, 'all_target_metrics': shared['score_metrics'].reduce_scores(*maps),
            'continuation_only_metrics': shared['score_metrics'].reduce_scores(*continuations),
            'distribution_positions': 2256, 'distribution_aggregate': shared['compare_distributions'].summarize(distribution_rows),
            'input_level_reports': [{'sample': value['sample'], 'target_metrics': value['target_metrics'],
                'continuation_target_metrics': value['continuation_target_metrics'],
                'distribution_aggregate': value['distribution']['aggregate']} for value in pairs[index]],
            'length_bin_summaries': [{'prompt_length': P, 'independent_articles': 12,
                'all_target_metrics': shared['score_metrics'].reduce_scores(*[
                    {key: value for key, value in side.items() if rows[key[0]]['prompt_length'] == P} for side in maps]),
                'continuation_only_metrics': shared['score_metrics'].reduce_scores(*[
                    {key: value for key, value in side.items() if rows[key[0]]['prompt_length'] == P} for side in continuations]),
                'distribution_aggregate': shared['compare_distributions'].summarize([position for value in pairs[index]
                    if value['prompt_length'] == P for position in value['distribution']['positions']])} for P in artifacts.BINS]})
        del maps, continuations
    sealed.finish(); workspace_bytes = budget.check_workspace(); budget.tick()
    result = {'schema_version': 1, 'kind': 'reserved48_common_cpu_cohort_report', 'task': TASK, 'status': 'completed_at_frozen_scope',
        'bindings': common_bindings(request), 'bin_reports': bin_refs, 'independent_reserved_articles': 48,
        'article_scope': 'English train-reserved WikiText articles,12 per length; not an official validation split or multilingual/code/math evaluation',
        'native_observations_per_backend': 144, 'source_target_scores_per_backend': 396144,
        'source_finite_native_row_claim_per_backend': 396288, 'selected_original_BF16_rows_per_backend': 6768,
        'new_common_CPU_FP64_matrices': 288, 'input_pair_contrasts': 432, 'distribution_pair_positions': 20304,
        'corpus_primary_pair_reductions': 9, 'corpus': corpus,
        'independent_all_target_normalizers': False, 'full_unselected_raw_audit': False,
        'independent_algorithm_scalar_E02_executed': False,
        'fresh_native_or_derived_array_reads_by_aggregation': 0,
        'observed_cohort_workspace_bytes_before_terminal': workspace_bytes, 'storage_guards_are_sampled_not_reserved': True,
        'scope': 'Token-weighted corpus target reductions use admitted SOURCE scalars; sampled distributions use NEW common-CPU full-vocabulary derivations. Repeated row/pair contrasts are correlated, not additional independent articles.',
        'Q02_executed': False, 'P01_executed': False, 'full_core_complete': False,
        'thresholds': None, 'acceptance': None, 'native_executions_started': 0}
    put(output / 'cohort-report.json', result); return ref(output / 'cohort-report.json')


def main():
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('phase', choices=('bin', 'aggregate'))
    p.add_argument('--request', type=Path, required=True); p.add_argument('--request-sha256', required=True)
    p.add_argument('--output-dir', type=Path, required=True); p.add_argument('--prompt-bin', type=int, choices=artifacts.BINS)
    p.add_argument('--bin-report', type=Path, action='append', default=[]); p.add_argument('--bin-report-sha256', action='append', default=[])
    args = p.parse_args(); request, inventory = artifacts.request(args.request, args.request_sha256)
    require(sys.platform.startswith('linux') and hasattr(signal, 'SIGALRM'), 'finite owned Linux CPU execution required')
    def expire(*_): raise TimeoutError('reserved48 common-CPU work3580s; outer protocol owns cleanup reserve')
    old = signal.signal(signal.SIGALRM, expire); signal.setitimer(signal.ITIMER_REAL, 3580)
    try:
        if args.phase == 'bin':
            require(args.prompt_bin in artifacts.BINS, 'one explicit bin required'); result = run_bin(request, inventory, args.prompt_bin, args.output_dir)
        else:
            require(len(args.bin_report) == len(args.bin_report_sha256) == 4, 'four explicitly pinned bin reports required')
            refs = [{'path': str(path.resolve()), 'sha256': digest, 'size_bytes': path.stat().st_size}
                    for path, digest in zip(args.bin_report, args.bin_report_sha256)]
            result = aggregate(request, inventory, refs, args.output_dir)
        print(json.dumps({'status': 'completed', 'result': result, 'native_executions_started': 0, 'acceptance': None}, indent=2)); return 0
    finally: signal.setitimer(signal.ITIMER_REAL, 0); signal.signal(signal.SIGALRM, old)


if __name__ == '__main__': raise SystemExit(main())

"""New-claim observer NPU TP1 capture;1500native/2620work/3600with export.

Actual dual metadata proof verification precedes process queries and claim.
Only a new namespace is spent; no old main/claim or unrelated process is used.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import argparse
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path,PurePosixPath
import re
import shutil
import signal
import subprocess
import sys
import time

CASE='projects/gemma4-pilot/cases/text-native'
LAUNCHER=CASE+'/transfer/npu_observer_launcher_v1.py'
OPERATIONS=CASE+'/transfer/npu_observer_operations_v1.py'
ENTRY=CASE+'/adapters/observer_native_v2.py'
COMMON=CASE+'/adapters/observer_common_v2.py'
PREREQUISITE=CASE+'/adapters/observer_prerequisite_v1.py'
EXPECTED=CASE+'/adapters/observer_expected_inventory_v1.py'
SPEC=CASE+'/observer-stage-v2.json'
INPUT=CASE+'/inputs/discovery-v1/wikitext2-discovery-001.json'
EXPECTED_JSON=CASE+'/transfer/observer-independent-expected-v2-20261107.json'
RECORDER='skills/precision-compare/scripts/record_run.py'
HELPER=CASE+'/transfer/npu_three_repeat_launcher_v4.py'
LEGACY=CASE+'/transfer/npu_i04_launcher_v1.py'
TASK_ID='gemma4-gpu-npu-observer-v1-20261107'
NAME='observer-transparency-20261107/native-v1'
MODES=['off-before','hooks-only','off-after','hooks-plus-dispatch-metadata']
STAGE_SHA='54683b3e1697b8358e7371d516596c42db347ff04de7253231236498ad15e22d'
EXPECTED_SHA='2f9821d74578735f2d8f1c82ec86c5f28dedc077ae7e293dce474e701cd7181a'
EXPECTED_BYTES=179495
I04_SHA='59830ffb67bafb2c0497ef954392fb4fc830dc388afc16a7750195cd09986e54'
CPU_SHA='1c5bbfc0089a78cf5d8564a666feb11bf24144cbbb6814a7003da12cce2ebd63'
UUID='REDACTED_DEVICE_UUID'
SMI_SHA='22feac701ab31bf5cc8c68244a4d529cf8b4060a8dd95bd3888c65247eda7cf3'
DRIVER_SHA='1bc07a765a4b4c765510ec7979113ea03b0217f1dcc0c2eb4646d011d7f88902'
TOTAL,WORK,CAPTURE,EXPORT,CLEANUP=3600,2620,1500,960,20
MAX_BYTES,MAX_CAPTURE,MIN_FREE,LOGICAL,ENCODED=4294967296,1073741824,5368709120,1073741824,1610612736
GEOMETRY={'GPU':'geometry/gpu-loaded-inventory.json','NPU':'geometry/npu-loaded-inventory.json',
    'config':'geometry/config.json','modeling':'geometry/modeling_gemma4_unified.py'}
# Complete reviewed literal closure; operations and launcher are frozen before packaging.
PINS={'geometry/config.json': '14f38c5492ffc9cbcdf808647ca0c025bb5b9b4eb737526347134d500ace6098', 'geometry/gpu-loaded-inventory.json': '482a36375a1d8689f9e4ff6515c7e9f281e873a3a77f63c7cfa118c95ded8550', 'geometry/modeling_gemma4_unified.py': 'e356db9089642559f227c0bc1134986bdd5274066431be91a5400d38355818fb', 'geometry/npu-loaded-inventory.json': 'd4ccecc13a0d946452d0d448089a941963e5cc1e104dba057db74fa628e39093', 'projects/gemma4-pilot/cases/text-native/adapters/i01_common_v1.py': 'fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c', 'projects/gemma4-pilot/cases/text-native/adapters/i03_common_v1.py': '5cf67f53b5392e4425c4534ec6f97961066c190d24dc1280f31e66781a0fe03a', 'projects/gemma4-pilot/cases/text-native/adapters/i03_prerequisite_v1.py': 'e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36', 'projects/gemma4-pilot/cases/text-native/adapters/observer_collectors_v1.py': '774b5cb210f294a23d6865f863d5facdf537c3ed3064ae39027425797b83101c', 'projects/gemma4-pilot/cases/text-native/adapters/observer_common_v2.py': '89270de32c6f6b5c60fd8d6408058ab2afe36188730c7c95c321ffd36221f3e2', 'projects/gemma4-pilot/cases/text-native/adapters/observer_expected_inventory_v1.py': '50a5f870d60733a842379107887365641b4f21afe43682407f6f0e94d79c5ec0', 'projects/gemma4-pilot/cases/text-native/adapters/observer_native_v2.py': 'e0fd43dd50f31b7e4f8280616f7b2655ff22e1166e41e6c229206777b61f3191', 'projects/gemma4-pilot/cases/text-native/adapters/observer_prerequisite_v1.py': '610e349ae0ba0be42fc683ccb7fd573255c080d835c09f07f4dee73edf98aa4c', 'projects/gemma4-pilot/cases/text-native/adapters/pilot_ascend_candidate_v3.py': '95b7b9302543d8a14995e293c790d5de9e23abc6041a53bb1d627ae3b5cd7ee8', 'projects/gemma4-pilot/cases/text-native/adapters/pilot_gpu_peer_v2.py': 'fbf0b1dc4b03576852d166bc56d3bca14d6544be8aebd120ef0b92f146429eae', 'projects/gemma4-pilot/cases/text-native/adapters/pilot_gpu_torch290_candidate.py': '5a73efe31962788baa04fa21abb1079be8a47e43393c23f3fa483e71c64b4f53', 'projects/gemma4-pilot/cases/text-native/adapters/upstream-identity.json': '80dc0e0e59e5c526426b566d36a21f762a79d498986d5d6cd01098c8cb5decc3', 'projects/gemma4-pilot/cases/text-native/adapters/verify_snapshot.py': 'cd64a5f3f380d9cc04578848ba508ace3f1df0752ca952b8d575dd2904196f26', 'projects/gemma4-pilot/cases/text-native/inputs/discovery-v1/wikitext2-discovery-001.json': '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0', 'projects/gemma4-pilot/cases/text-native/observer-stage-v2.json': '54683b3e1697b8358e7371d516596c42db347ff04de7253231236498ad15e22d', 'projects/gemma4-pilot/cases/text-native/transfer/export_observer_cpu_proof_v1.py': 'cbad23821a46454426a0e61a017a3adb618b8f7a319aea9c92f383d248fe2bf5', 'projects/gemma4-pilot/cases/text-native/transfer/npu_i04_launcher_v1.py': '1ac8477196bfb40f2f38f4577e2b7383ae0654866518e4d7d214bdb913f5d451', 'projects/gemma4-pilot/cases/text-native/transfer/npu_observer_operations_v1.py': '0ec688dc263885a53dcd02ea56a99e09e4fc79891576660c0d67db0af7a8d5d2', 'projects/gemma4-pilot/cases/text-native/transfer/npu_three_repeat_launcher_v4.py': 'c1719e831a557cd9707374138d9219a8ae887854dd029a1ec165631d9259f485', 'projects/gemma4-pilot/cases/text-native/transfer/observer-independent-expected-v2-20261107.json': '2f9821d74578735f2d8f1c82ec86c5f28dedc077ae7e293dce474e701cd7181a', 'skills/precision-compare/scripts/artifact_io.py': '0260cd5ee1fd4e9d37e39bfd79efa9e663a1d48cb75b5adb31b84af9e1edbf39', 'skills/precision-compare/scripts/compare_distributions.py': '6abc2eb0a741d554127911de9845d16e0d40f3f7759c42c172eae4907bbf8fc0', 'skills/precision-compare/scripts/conditions.py': 'e012c025395f2f0474f0b35074d8417ec5a217f3659f82218de0f5d05068036d', 'skills/precision-compare/scripts/inference_capture.py': '5d388e846249d7fd74df1b15036f8a371e3267ada1b2fb0408bc51345ffad19c', 'skills/precision-compare/scripts/record_run.py': '2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'}


def require(ok,message):
    if not ok:raise ValueError(message)
def utc():return datetime.now(timezone.utc).isoformat()
def sha(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):value.update(block)
    return value.hexdigest()
def read(path):
    def pairs(items):
        out={}
        for k,v in items:require(k not in out,'duplicate JSON key');out[k]=v
        return out
    return json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def put(path,doc):
    with Path(path).open('x',encoding='utf8',newline='\n') as stream:json.dump(doc,stream,indent=2,allow_nan=False);stream.write('\n')
def raw_put(path,raw):
    with Path(path).open('xb') as stream:stream.write(raw)
def regular(path):
    path=Path(path);require(path.is_file() and not path.is_symlink(),'original regular source required');return path
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def assert_frozen(frozen):
    require(all(sha(regular(path))==digest for path,digest in frozen.items()),'frozen source/proof/binding changed')
def tree_bytes(root):
    total=0
    for path in Path(root).rglob('*'):
        require(not path.is_symlink(),'owned task tree contains symlink')
        if path.is_file():total+=path.stat().st_size
    return total
def ready():
    require({OPERATIONS,ENTRY,COMMON,PREREQUISITE,EXPECTED,SPEC,INPUT,RECORDER,HELPER,LEGACY,EXPECTED_JSON,*GEOMETRY.values()}<=set(PINS) and
        all(isinstance(value,str) and re.fullmatch('[a-f0-9]{64}',value) for value in PINS.values()),'observer source closure remains unready')


def claim_once(root,metadata):
    parent=Path(root)/'claims';require(not parent.is_symlink(),'claim parent cannot be symlink');parent.mkdir(exist_ok=True)
    claim=parent/('npu-observer-'+UUID)
    try:claim.mkdir(mode=0o700)
    except FileExistsError:return None
    put(claim/'claim.json',metadata);return claim


def process_start(pid):
    return int((Path('/proc')/str(pid)/'stat').read_text().rpartition(')')[2].split()[19])


def claim_fields(args,allocation):
    return {'schema_version':1,'task':'OBSERVER','task_id':TASK_ID,'backend':'NPU','allocation_id':allocation['allocation_id'],
        'runtime_uuid':UUID,'task_root':str(args.task_root.resolve()),'source_root':str(args.source_root.resolve()),'model':str(args.model.resolve()),
        'source_manifest_path':str(args.source_manifest.resolve()),'source_manifest_sha256':args.source_manifest_sha256,
        'launcher_path':str(args.source_root/LAUNCHER),'launcher_sha256':sha(args.source_root/LAUNCHER),
        'stage_spec_sha256':STAGE_SHA,'whole_attempt_seconds':TOTAL,'controller_work_seconds':WORK,'metadata_export_reserved_seconds':EXPORT,
        'owned_cleanup_reserve_seconds':CLEANUP,'capture_seconds':CAPTURE,'max_new_bytes_sampled':MAX_BYTES,'max_capture_product_bytes':MAX_CAPTURE,
        'logical_transport_cap':LOGICAL,'encoded_transport_cap':ENCODED,'native_launches':1,'automatic_retries':0,'native_forward_calls':4,'model_loads':1,
        'i04_prerequisite_path':str(args.i04_prerequisite),'i04_prerequisite_sha256':I04_SHA,'cpu_prerequisite_path':str(args.cpu_prerequisite),
        'cpu_prerequisite_sha256':CPU_SHA,'expected_inventory_sha256':EXPECTED_SHA,
        'binding_sha256':{str(p):sha(p) for p in (args.allocation,args.native_mapping,args.native_source,args.driver_source)}}


def claimed_context(args,allocation,frozen,claim,worker=False):
    """Internal entry points require the real live parent and original spent claim."""
    claim=Path(claim);expected=args.task_root.resolve()/'claims'/('npu-observer-'+UUID)
    require(claim==expected and claim.is_dir() and not claim.is_symlink(),'exact permanent observer claim required')
    document=read(regular(claim/'claim.json'));fields=claim_fields(args,allocation)
    require(set(document)==set(fields)|{'claimed_utc','controller_pid','controller_starttime'} and
        all(document.get(k)==v for k,v in fields.items()),'permanent claim task/source/allocation/proofs/bounds differ')
    require(type(document['controller_pid']) is int and document['controller_pid']==os.getppid() and
        type(document['controller_starttime']) is int and process_start(os.getppid())==document['controller_starttime'],
        'internal observer entry must be a direct child of the recorded live controller')
    controller=read(regular(claim/'controller-start.json'))
    require(controller['status']=='running' and controller['task']=='OBSERVER' and controller['task_id']==TASK_ID and
        controller['backend']=='NPU' and controller['claim']==str(claim) and controller['source_sha256']==frozen,
        'running original controller/source chain differs')
    copies=read(regular(claim/'frozen-source-map.json'));require(set(copies)==set(frozen),'frozen original source closure differs')
    for original,ref in copies.items():
        copied=regular(ref['path']);require(copied.resolve().is_relative_to(claim/'frozen-source') and
            set(ref)=={'path','sha256','size_bytes'} and ref['sha256']==frozen[original]==sha(original)==sha(copied) and
            copied.stat().st_size==ref['size_bytes'],'frozen original/copied source changed')
    if worker:
        before=read(regular(claim/'sources-pre-worker.json'));require(set(frozen)<=set(before) and
            all(before[p]==v for p,v in frozen.items()),'premodel source-before closure differs');assert_frozen(before)
        expected_file=regular(claim/'expected-inventory.json');require(expected_file.stat().st_size==EXPECTED_BYTES and sha(expected_file)==EXPECTED_SHA,
            'premodel independent expected inventory differs')
        require(read(regular(claim/'process-2.json'))['status']=='explicitly_empty','second fresh idle inventory is absent')
    return document


def expected_verify(source,output=None):
    module=load(source/EXPECTED,'observer_independent_coordinates_only')
    args=[source/INPUT,source/SPEC,STAGE_SHA,source/GEOMETRY['GPU'],source/GEOMETRY['NPU'],source/GEOMETRY['config'],source/GEOMETRY['modeling']]
    if output is None:return module.verify(source/EXPECTED_JSON,*args)
    return module.build(args[0],output,*args[1:])


def source_check(args,metadata_only=False):
    ready();root=args.task_root.resolve();source=args.source_root.resolve()
    require(root.is_dir() and not args.task_root.is_symlink() and source==root/'source' and not args.source_root.is_symlink(),'new owned observer task/source required')
    require(root.name=='native-v1' and root.parent.name=='observer-transparency-20261107','permanent new observer namespace required')
    require(args.i04_prerequisite_sha256==I04_SHA and args.cpu_prerequisite_sha256==CPU_SHA and args.expected_inventory_sha256==EXPECTED_SHA,
        'actual dualproof/expected external pins differ')
    manifest=regular(args.source_manifest);require(manifest.resolve().is_relative_to(root) and sha(manifest)==args.source_manifest_sha256,'external source manifest differs')
    doc=read(manifest);require(set(doc)=={'schema_version','task_id','files'} and doc['schema_version']==1 and doc['task_id']==TASK_ID and
        set(PINS)|{LAUNCHER}<=set(doc['files']) and len(doc['files'])<=127,'typed complete source manifest required')
    frozen={};actual=set()
    for path in source.rglob('*'):
        require(not path.is_symlink(),'source tree contains symlink')
        if path.is_file():actual.add(path.relative_to(source).as_posix())
    require(actual==set(doc['files']),'exact source tree inventory differs')
    for name,item in doc['files'].items():
        p=PurePosixPath(name);require(not p.is_absolute() and str(p)==name and '\\' not in name and all(x not in ('','.','..') for x in name.split('/')),'unsafe source identity')
        path=source/name;require(path.resolve().is_relative_to(source),'source escape')
        require(set(item)=={'sha256','size_bytes','kind'} and item['kind']==('code' if name.endswith('.py') else 'metadata') and type(item['size_bytes']) is int and
            regular(path).stat().st_size==item['size_bytes']<=(1024**2 if item['kind']=='code' else 16*1024**2) and sha(path)==item['sha256'],'source bytes/classification differ')
        if name in PINS:require(item['sha256']==PINS[name],'reviewed literal source pin differs')
        frozen[str(path)]=item['sha256']
    require(Path(__file__).resolve()==source/LAUNCHER,'execute frozen staged observer launcher itself')
    gate=load(source/PREREQUISITE,'observer_preclaim_actual_metadata_gate')
    checked=gate.prerequisite(args.i04_prerequisite,I04_SHA,args.cpu_prerequisite,CPU_SHA)
    closure=set(PINS)|{LAUNCHER}
    for item in checked['refs'].values():
        path=Path(item['path']);require(path.resolve().is_relative_to(source),'actual proof must remain inside source closure');closure.add(path.resolve().relative_to(source).as_posix())
    require(set(doc['files'])==closure and len(checked['refs'])==35,'source closure contains unbound extras or lacks actual35 proof refs')
    require((source/EXPECTED_JSON).stat().st_size==EXPECTED_BYTES and sha(source/EXPECTED_JSON)==EXPECTED_SHA,'independent expected bytes differ');expected_verify(source)
    stage=read(source/SPEC);require(stage['stage_id']==TASK_ID and stage['modes']==MODES and stage['total_forward_calls_per_backend']==4 and
        stage['limits']['whole_attempt_timeout_seconds_per_backend']==TOTAL and stage['limits']['controller_work_timeout_seconds']==WORK and
        stage['limits']['cpu_metadata_export_whole_timeout_seconds']==EXPORT and stage['limits']['owned_cleanup_reserve_seconds']==CLEANUP and
        stage['limits']['maximum_capture_product_bytes_per_backend']==MAX_CAPTURE and stage['limits']['maximum_new_task_storage_bytes_per_backend']==MAX_BYTES,
        'frozen observer mode/resource bounds differ')
    expected_limits={'npu_capture_timeout_seconds':CAPTURE,'minimum_free_source_storage_bytes':MIN_FREE,
        'maximum_logical_artifact_transport_bytes_per_direction':LOGICAL,'maximum_encoded_transport_bytes_per_direction':ENCODED,
        'minimum_npu_host_effective_available_bytes':80*1024**3,'minimum_free_device_bytes':35*1024**3,'maximum_code_source_bytes':1024**2,
        'maximum_metadata_member_bytes':16*1024**2,'max_native_model_processes_per_backend':1,'automatic_native_retries':0}
    require(all(type(stage['limits'].get(k)) is int and stage['limits'][k]==v for k,v in expected_limits.items()),'literal native/storage/transport bounds differ')
    require(not any(name in sys.modules for name in ('torch','torch_npu','numpy','transformers')),'preclaim proof/source checks imported a framework')
    if metadata_only:return {'files':frozen,'proof_refs':35,'stage':stage,'native_executions_started':0}
    require(stage['native_task_roots']['NPU']==str(root),'actual task root differs from frozen explicit POSIX NPU root')
    helper=load(source/HELPER,'observer_reviewed_native_pure_helpers');allocation,physical=helper.binding(args.allocation,args.native_mapping,args.native_source)
    require(physical==UUID,'selected original logical NPU UUID differs')
    legacy=load(source/LEGACY,'observer_reviewed_process_inventory_helpers_only')
    require(str(args.npu_smi)=='/srv/precision-user/.local/bin/npu-smi' and args.npu_smi_sha256==SMI_SHA and sha(args.driver_source)==DRIVER_SHA,'native CLI/driver source differs')
    identity=legacy.smi_identity(args.npu_smi,SMI_SHA)
    for path in (args.source_manifest,args.allocation,args.native_mapping,args.native_source,args.driver_source,Path(identity['resolved_path'])):frozen[str(regular(path).resolve())]=sha(path)
    return helper,legacy,allocation,frozen


def bounded(helper,argv,stdout,stderr,deadline,root):
    process=None
    try:
        with stdout.open('xb') as out,stderr.open('xb') as err:
            process=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True,cwd=Path(root)/'source')
            next_sample=0
            while process.poll() is None:
                now=time.monotonic()
                if now>=deadline:raise TimeoutError('observer controller work deadline reached')
                if now>=next_sample:
                    require(tree_bytes(root)<=MAX_BYTES,'observer sampled task storage cap exceeded')
                    for output in (Path(root)/'runs').glob('*/artifacts'):require(tree_bytes(output)<=MAX_CAPTURE,'observer sampled1GiB capture cap exceeded')
                    next_sample=now+2
                try:process.wait(timeout=min(.2,max(.01,deadline-now)))
                except subprocess.TimeoutExpired:pass
            require(not any(x['state']!='Z' for x in helper.descendants().values()),'unexpected owned descendant after child exited');return process.returncode
    finally:helper.cleanup(process)


def argv_copy(args):
    values=[sys.executable,'-B',str(Path(__file__).resolve())]
    for name in ('task_root','source_root','model','allocation','native_mapping','native_source','driver_source','source_manifest','source_manifest_sha256',
        'npu_smi','npu_smi_sha256','expected_inventory_sha256','i04_prerequisite','i04_prerequisite_sha256','cpu_prerequisite','cpu_prerequisite_sha256'):
        values+=['--'+name.replace('_','-'),str(getattr(args,name))]
    return values


def capture_argv(args,expected,output):
    return [sys.executable,'-B',str(args.source_root/ENTRY),'--backend','npu','--model',str(args.model),'--input',str(args.source_root/INPUT),
        '--allocation-receipt',str(args.allocation),'--native-mapping',str(args.native_mapping),'--native-source',str(args.native_source),
        '--driver-source',str(args.driver_source),'--device','npu:0','--stage-spec',str(args.source_root/SPEC),'--stage-spec-sha256',STAGE_SHA,
        '--expected-inventory',str(expected),'--expected-inventory-sha256',EXPECTED_SHA,'--i04-prerequisite',str(args.i04_prerequisite),
        '--i04-prerequisite-sha256',I04_SHA,'--cpu-prerequisite',str(args.cpu_prerequisite),'--cpu-prerequisite-sha256',CPU_SHA,'--output',str(output)]


def probe(args):
    helper,_,allocation,frozen=source_check(args);require(allocation['physical_device_id']==UUID,'native original UUID differs')
    claim=args.task_root.resolve()/'claims'/('npu-observer-'+UUID);require(args.probe_output==claim/'native-preflight.json','exact internal probe output required')
    claimed_context(args,allocation,frozen,claim)
    put(claim/'probe-once.json',{'status':'internal_probe_attempt_spent','pid':os.getpid(),'parent_pid':os.getppid(),'source_manifest_sha256':args.source_manifest_sha256,'automatic_retry':False})
    helper.native_probe(args,args.probe_output)
    packages={name:{'path':str(Path(sys.modules[name].__file__).resolve()),'sha256':sha(sys.modules[name].__file__),
        'size_bytes':Path(sys.modules[name].__file__).stat().st_size} for name in ('torch','torch_npu','numpy','transformers')}
    put(args.probe_output.with_name('native-runtime-sources.json'),packages);assert_frozen(frozen);return 0


def worker(args):
    helper,_,allocation,frozen=source_check(args);require(args.worker.is_absolute() and not args.worker.is_symlink(),'original absolute internal worker claim required')
    claim=args.worker.resolve();claimed_context(args,allocation,frozen,claim,worker=True)
    marker=claim/'worker-once.json';put(marker,{'status':'internal_worker_attempt_spent','pid':os.getpid(),'parent_pid':os.getppid(),'source_manifest_sha256':args.source_manifest_sha256,'automatic_retry':False})
    expected=claim/'expected-inventory.json';require(sha(expected)==EXPECTED_SHA and expected.stat().st_size==EXPECTED_BYTES,'claim expected bytes differ')
    before=read(claim/'sources-pre-worker.json');before[str(marker)]=sha(marker);assert_frozen(before);put(claim/'sources-before.json',before)
    sys.path.insert(0,str(args.source_root/'skills/precision-compare/scripts'));recorder=load(args.source_root/RECORDER,'observer_original_generic_recorder')
    def stop(*_):raise KeyboardInterrupt('observer owned worker interrupted')
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,stop)
    run,command=recorder.record_run(args.task_root/'runs','ascend','observer',CAPTURE,lambda folder:capture_argv(args,expected,folder/'artifacts'),
        cwd=args.source_root,execution=claim/'execution-profile.json')
    generic={'path':str(run/'command.json'),'sha256':sha(run/'command.json')};put(claim/'generic-receipt-reference.json',generic)
    require(command['status']=='completed' and command['returncode']==command['child_returncode']==0,'observer native collector failed')
    sys.path.insert(0,str(args.source_root/(CASE+'/adapters')));import observer_common_v2 as common
    require(Path(common.__file__).resolve()==args.source_root/COMMON,'actual observer validator module differs')
    output=run/'artifacts';validation=common.validate_output(output,args.source_root/INPUT);manifest=read(output/'artifacts-manifest.json');files=manifest['files']
    require(validation['status']=='observer_output_artifacts_checked' and validation['native_forward_calls_total']==4 and validation['model_loads']==1 and
        validation['target_scores']==636 and validation['distribution_rows']==188 and validation['boundary_snapshots']==196 and validation['modes']==MODES and
        len(files)==453 and sum(x.endswith('.npy') for x in files)==188 and sum(x.endswith('.safetensors') for x in files)==6 and tree_bytes(output)<=MAX_CAPTURE,
        'complete four-mode/98-boundary/194large/453file product gate failed')
    runtime=read(output/'runtime.json');require(runtime['package_sources']==read(claim/'native-runtime-sources.json'),'actual package sources differ from fresh preflight')
    implementation=runtime['implementation_sources'];require({'modeling','masking_utils','torch_dispatch','module_hooks'}<=set(implementation) and
        any(x.startswith('rotary/') for x in implementation) and all(x in {'modeling','masking_utils','torch_dispatch','module_hooks'} or x.startswith('rotary/') for x in implementation),
        'actual model/mask/dispatcher/hook/rotary implementation closure differs')
    unique={}
    for item in [*runtime['package_sources'].values(),*implementation.values()]:
        require(item['path'] not in unique or unique[item['path']]==item,'runtime original aliases disagree');unique[item['path']]=item
    runtime_map={}
    for index,item in enumerate(unique.values()):
        original=regular(item['path']);require(sha(original)==item['sha256'] and original.stat().st_size==item['size_bytes']<=4*1024**2,'actual runtime import source bytes differ')
        target=claim/'frozen-runtime'/('%02d'%index)/original.name;target.parent.mkdir(parents=True);raw_put(target,original.read_bytes())
        runtime_map[str(original)]={'path':str(target),'sha256':sha(target),'size_bytes':target.stat().st_size}
    put(claim/'frozen-runtime-map.json',runtime_map);assert_frozen(before);put(claim/'sources-after.json',before)
    put(claim/'capture-receipt.json',{'schema_version':1,'task':'OBSERVER','task_id':TASK_ID,'capture_schema_version':2,'backend':'NPU','status':'completed',
        'returncode':0,'timed_out':False,'started_utc':command['start'],'finished_utc':utc(),'argv':command['argv'],'collector_path':str(args.source_root/ENTRY),
        'collector_sha256':PINS[ENTRY],'input_path':str(args.source_root/INPUT),'input_sha256':PINS[INPUT],'dependency_paths':list(before),'source_sha256':before,
        'output_dir':str(output),'artifacts_manifest_sha256':sha(output/'artifacts-manifest.json'),'expected_inventory_source_path':str(expected),'expected_inventory_source_sha256':EXPECTED_SHA,
        'stage_spec_source_path':str(args.source_root/SPEC),'stage_spec_source_sha256':STAGE_SHA,'i04_prerequisite_source_path':str(args.i04_prerequisite),
        'i04_prerequisite_source_sha256':I04_SHA,'cpu_prerequisite_source_path':str(args.cpu_prerequisite),'cpu_prerequisite_source_sha256':CPU_SHA,
        'generic_receipt':generic,'allocation_path':str(args.allocation),'allocation_sha256':sha(args.allocation),'runtime_source_map_path':str(claim/'frozen-runtime-map.json'),
        'runtime_source_map_sha256':sha(claim/'frozen-runtime-map.json'),'validation':validation,'native_capture_count':1,'native_forward_calls_total':4,'model_loads':1,'acceptance':None})
    return 0


def run(args):
    started=time.monotonic();require(sys.platform.startswith('linux') and os.environ.get('PYTHONHASHSEED')=='0','Linux/PYTHONHASHSEED0 required')
    handlers={};helper=None;claim=None;state={};code=1
    def stop(*_):raise TimeoutError('observer work2620 deadline/signal; preserve20cleanup+960export reserve')
    try:
        for sig in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT,signal.SIGHUP):handlers[sig]=signal.signal(sig,stop)
        signal.setitimer(signal.ITIMER_REAL,WORK)
        helper,legacy,allocation,frozen=source_check(args)
        require(shutil.disk_usage(args.task_root).free>=MIN_FREE and tree_bytes(args.task_root)<=MAX_BYTES,'source free5GiB/task4GiB guard failed')
        legacy.subreaper();assert_frozen(frozen)  # All35 original proof refs immediately before this sole claim.
        claim=claim_once(args.task_root,{**claim_fields(args,allocation),'claimed_utc':utc(),'controller_pid':os.getpid(),'controller_starttime':process_start(os.getpid())})
        if claim is None:print(json.dumps({'status':'refused','reason':'permanent_observer_claim_exists','native_capture_started':False}),flush=True);return 0
        state={'schema_version':1,'task':'OBSERVER','task_id':TASK_ID,'backend':'NPU','status':'running','started_utc':utc(),'claim':str(claim),'source_sha256':frozen,
            'controller_work_seconds':WORK,'metadata_export_reserved_seconds':EXPORT,'owned_cleanup_reserve_seconds':CLEANUP,'storage_limit_is_sampled_not_hard_quota':True,'acceptance':None}
        put(claim/'controller-start.json',state)
        copies={}
        for index,(original,digest) in enumerate(frozen.items()):
            target=claim/'frozen-source'/('%03d'%index)/Path(original).name;target.parent.mkdir(parents=True);raw_put(target,Path(original).read_bytes());require(sha(target)==digest,'source changed during freeze')
            copies[original]={'path':str(target),'sha256':digest,'size_bytes':target.stat().st_size}
        put(claim/'frozen-source-map.json',copies);cli=legacy.smi_identity(args.npu_smi,SMI_SHA);put(claim/'npu-smi-identity.json',cli)
        expected=claim/'expected-inventory.json';expected_verify(args.source_root,expected);require(sha(expected)==EXPECTED_SHA and expected.stat().st_size==EXPECTED_BYTES,'premodel expected regeneration differs')
        execution=claim/'execution-profile.json';put(execution,{'env':{'PYTHONHASHSEED':'0','PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1','PYTHONHOME':None,'PYTHONPATH':None,'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','TORCH_DEVICE_BACKEND_AUTOLOAD':'0'}})
        for number in (1,2):
            require(legacy.smi_identity(args.npu_smi,SMI_SHA)==cli,'process CLI changed before inventory')
            result=subprocess.run([str(args.npu_smi),'info'],capture_output=True,timeout=20,check=False)
            require(legacy.smi_identity(args.npu_smi,SMI_SHA)==cli,'process CLI changed after inventory');raw_put(claim/f'process-{number}.stdout',result.stdout);raw_put(claim/f'process-{number}.stderr',result.stderr)
            require(result.returncode==0,'process inventory failed');put(claim/f'process-{number}.json',{**legacy.process_gate(result.stdout),'observed_utc':utc(),'returncode':result.returncode})
            if number==1:
                output=claim/'native-preflight.json';status=bounded(helper,argv_copy(args)+['--probe-output',str(output)],claim/'preflight.stdout',claim/'preflight.stderr',min(started+WORK,time.monotonic()+120),args.task_root)
                require(status==0 and read(output)['status']=='preflight_passed','fresh selected UUID/free35GiB/host80GiB preflight failed')
                packages=read(claim/'native-runtime-sources.json');package_map={}
                for index,item in enumerate(packages.values()):
                    original=regular(item['path']);require(sha(original)==item['sha256'],'native package changed');target=claim/'frozen-native-packages'/('%02d'%index)/original.name;target.parent.mkdir(parents=True);raw_put(target,original.read_bytes())
                    package_map[str(original)]={'path':str(target),'sha256':sha(target),'size_bytes':target.stat().st_size};frozen[str(original)]=item['sha256']
                put(claim/'frozen-native-packages-map.json',package_map)
        dynamic=[expected,execution,claim/'native-preflight.json',claim/'native-runtime-sources.json',claim/'npu-smi-identity.json',claim/'probe-once.json',claim/'claim.json',claim/'controller-start.json',claim/'frozen-source-map.json']
        dynamic += [claim/('process-%d%s'%(n,suffix)) for n in (1,2) for suffix in ('.stdout','.stderr','.json')]
        frozen.update({str(path):sha(path) for path in dynamic});assert_frozen(frozen);put(claim/'sources-pre-worker.json',frozen)
        code=bounded(helper,argv_copy(args)+['--worker',str(claim)],claim/'worker.stdout',claim/'worker.stderr',started+WORK,args.task_root)
        require(code==0 and read(claim/'capture-receipt.json')['status']=='completed','owned observer capture worker failed');assert_frozen(frozen)
        require(tree_bytes(args.task_root)<=MAX_BYTES,'task storage exceeded4GiB');state['status']='completed'
    except BaseException as exc:
        code=124 if isinstance(exc,TimeoutError) else 1;state.update(status='failed',error_type=type(exc).__name__,error=str(exc))
    finally:
        if helper is not None:
            try:helper.cleanup(None)
            except BaseException as exc:code=1;state.update(status='cleanup_failed',cleanup_error=str(exc))
        signal.setitimer(signal.ITIMER_REAL,0)
        for sig,handler in handlers.items():signal.signal(sig,handler)
        if claim is not None:
            state.update(returncode=code,timed_out=code==124,finished_utc=utc(),wall_seconds=time.monotonic()-started,remaining_descendants=sorted(helper.descendants()),claim_remains_spent=True)
            put(claim/'controller-receipt.json',state)
    print(json.dumps({'status':state.get('status','failed_before_claim'),'returncode':code,'claim':str(claim) if claim else None,'error':state.get('error')},allow_nan=False),flush=True);return code


def main():
    os.umask(0o077);parser=argparse.ArgumentParser(description=__doc__)
    for name in ('task-root','source-root','model','allocation','native-mapping','native-source','driver-source','source-manifest','npu-smi','i04-prerequisite','cpu-prerequisite'):parser.add_argument('--'+name,type=Path,required=True)
    for name in ('source-manifest-sha256','npu-smi-sha256','expected-inventory-sha256','i04-prerequisite-sha256','cpu-prerequisite-sha256'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--probe-output',type=Path);parser.add_argument('--worker',type=Path);args=parser.parse_args()
    if args.probe_output:return probe(args)
    if args.worker:return worker(args)
    return run(args)


if __name__=='__main__':raise SystemExit(main())

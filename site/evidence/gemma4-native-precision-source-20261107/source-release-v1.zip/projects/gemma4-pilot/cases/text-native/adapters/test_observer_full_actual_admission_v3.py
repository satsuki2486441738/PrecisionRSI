"""Actual full GPU Endpoint/admit integration, bounded by an owning900s runner.

Uses the complete original674-member import retained after the original CPU
interface failure. It actually reads194 large sources:640 raw rows,636 target
derivations,188 full-vocabulary rows and196 sampled-boundary tensors. No model,
Torch, device API or NPU endpoint exists in this fixture. Never label it native.
"""
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import time
import unittest

HERE = Path(__file__).resolve().parent
CASE = HERE.parent
for path in (HERE, CASE/'transfer', HERE.parents[4]/'skills/precision-compare/scripts'):
    sys.path.insert(0, str(path))
import observer_artifact_admission_v2 as previous
import observer_artifact_admission_v3 as native
import admit_observer_transparency_v3 as driver

IMPORTED = CASE/'runs/compare-observer-gpu-only-20261107T001752Z/imported'
MAP_SHA = '11f6107b3f86f55f9d5f4a213f0233a1b9f2a8b8a9af0169cbd036abdcb59b1b'
OUTER = {'source_path': '/srv/precision-task/observer-transparency-20261107-gpu-v2/claims/REDACTED_APP_ID/capture-receipt.json',
         'sha256': '71538b5c387d56997f5b1bf3553d8f29236f6f1255f63e3943080a3b5bb01765'}


def functions(text):
    return {item.name: ast.dump(item, include_attributes=False) for item in ast.parse(text).body
            if isinstance(item, (ast.FunctionDef, ast.ClassDef))}


class ActualAdmission(unittest.TestCase):
    def test_01_only_producer_root_member_added_and_numeric_AST_unchanged(self):
        old = Path(previous.__file__).read_text(encoding='utf-8'); new = Path(native.__file__).read_text(encoding='utf-8')
        a = "required={'input.json','stage-spec.json','expected-inventory.json','snapshot-verification.json','observed-static-model.json'"
        b = "required={'input.json','stage-spec.json','expected-inventory.json','snapshot-verification.json','loaded-model-inventory.json','observed-static-model.json'"
        self.assertEqual(new, old.replace(a, b)); self.assertEqual(old.count(a), 1)
        old_functions, new_functions = functions(old), functions(new)
        self.assertEqual({k:v for k,v in old_functions.items() if k != 'inspect_output'},
                         {k:v for k,v in new_functions.items() if k != 'inspect_output'})
        loader = HERE/'i01_common_v1.py'
        self.assertEqual(native.sha(loader), 'fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c')
        self.assertIn("put(args.output / 'loaded-model-inventory.json', loaded_model_inventory(model))", loader.read_text(encoding='utf-8'))

    def test_02_old_exact_root_member_gap_reproduced_from_actual_manifest(self):
        endpoint = native.Endpoint(IMPORTED/'source-map.json', MAP_SHA)
        outer = endpoint.json(OUTER['source_path'], OUTER['sha256'])
        manifest = endpoint.json(native.child(outer['output_dir'], 'artifacts-manifest.json'), outer['artifacts_manifest_sha256'])
        roots = {name for name in manifest['files'] if '/' not in name}
        self.assertEqual(len(roots), 12); self.assertEqual(len(manifest['files']), 452)
        self.assertIn('loaded-model-inventory.json', roots)
        required = next(node for node in ast.walk(ast.parse(Path(previous.__file__).read_bytes()))
            if isinstance(node, ast.Assign) and any(isinstance(x, ast.Name) and x.id == 'required' for x in node.targets)
            and isinstance(node.value, ast.BinOp))
        original = ast.literal_eval(required.value.left)
        self.assertEqual(len(original), 11); self.assertEqual(roots-original, {'loaded-model-inventory.json'})

    def test_03_full_actual_GPU_admit_all_remaining_identity_state_and_raw_checks(self):
        self.assertEqual(os.name, 'posix', 'actual retained original source identity requires the Linux fixture')
        self.assertIsNone(driver.HELPER_SHA); self.assertEqual(driver.ACTUAL_ENDPOINTS, {'GPU': None, 'NPU': None})
        started = time.monotonic(); stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        root = CASE/'runs'/('compare-observer-v3-full-actual-CPU-'+stamp); root.mkdir()
        source_paths = [Path(native.__file__), Path(driver.__file__), Path(__file__), HERE/'observer_artifact_admission_v1.py',
            HERE/'admit_observer_transparency_v1.py', HERE/'observer_artifact_admission_v2.py', HERE/'admit_observer_transparency_v2.py']
        before = {str(path): native.sha(path) for path in source_paths}
        receipt = {'schema_version': 1, 'status': 'running', 'actual_data_fixture': True,
            'input_original_source_map_sha256': MAP_SHA, 'outer_receipt': OUTER, 'source_sha256_before': before,
            'native_model_executions': 0, 'acceptance': None, 'full_core_complete': False}
        prior = signal.getsignal(signal.SIGALRM)
        def timeout(*_): raise TimeoutError('actual full admission CPU fixture840s; owning runner900s')
        signal.signal(signal.SIGALRM, timeout); signal.setitimer(signal.ITIMER_REAL, 840)
        try:
            native.verify_tools()
            endpoint = native.Endpoint(IMPORTED/'source-map.json', MAP_SHA)
            result = driver.admit(endpoint, OUTER, 'GPU', root/'proof-gpu')
            self.assertEqual(len(result['paths']), 452)
            self.assertEqual(list(result['modes']), native.MODES)
            self.assertEqual(sum(len(value['scores']) for value in result['modes'].values()), 636)
            self.assertEqual(sum(len(value['positions']) for value in result['modes'].values()), 188)
            self.assertEqual(sum(value['samples']['tensor_count'] if value['samples'] else 0 for value in result['modes'].values()), 196)
            self.assertEqual(result['rank_binding']['rank'], 0)
            self.assertEqual(result['rank_binding']['compute_device_count'], 1)
            self.assertEqual(result['hardware']['category'], 'GPU')
            self.assertEqual(result['software']['torch'], '2.9.0+cu128')
            self.assertFalse(result['modes']['off-before']['census']['execution_census_measured'])
            self.assertEqual(result['modes']['hooks-only']['census']['static_modules'], 875)
            large = {name for name in endpoint.checked if name.endswith(('.npy', '.safetensors'))}
            self.assertEqual(len(large), 194)
            for name, digest in endpoint.checked.items(): self.assertEqual(native.sha(endpoint.resolved[name]), digest)
            self.assertEqual(native.sha(endpoint.manifest_path), MAP_SHA)
            self.assertEqual(before, {str(path): native.sha(path) for path in source_paths})
            self.assertFalse(any(k == 'torch' or k.startswith(('torch.', 'torch_npu', 'transformers')) for k in sys.modules))
            receipt.update(status='full_actual_GPU_Endpoint_admit_checked', source_sha256_after=before,
                actual_raw_rows_finite_checked=640, actual_target_scores_rederived=636,
                actual_full_vocabulary_rows_rederived=188, actual_boundary_snapshots_checked=196,
                all_original_large_sources_final_rehashed=194, capture_manifest_products=452,
                checked_original_source_count=len(endpoint.checked), raw_derivation_max_abs_delta_by_mode={
                    key:value['raw_derivation_max_abs_delta'] for key,value in result['modes'].items()},
                buffer_content_gaps=result['buffer_content_gaps'], software=result['software'],
                all_state_runtime_backend_generic_assertions_passed=True,
                scope='One actual GPU capture, four same-loaded-model modes. Numeric admission fixture, not the6 shared comparison pairs or NPU result.')
        except BaseException as exc:
            receipt.update(status='failed_full_actual_GPU_Endpoint_admit_fixture', error_type=type(exc).__name__, error=str(exc))
            raise
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0); signal.signal(signal.SIGALRM, prior)
            receipt['wall_seconds'] = time.monotonic()-started
            raw = (json.dumps(receipt, indent=2, allow_nan=False)+'\n').encode()
            with (root/'receipt.json').open('xb') as stream: stream.write(raw)
            print('ACTUAL_ADMISSION_RECEIPT '+str(root/'receipt.json')+' SHA256 '+hashlib.sha256(raw).hexdigest(), flush=True)

    def test_04_main_only_versioned_names_changed_and_prior_versions_preserved(self):
        old = (HERE/'admit_observer_transparency_v2.py').read_text(encoding='utf-8')
        self.assertEqual(Path(driver.__file__).read_text(encoding='utf-8'),
            old.replace('observer_artifact_admission_v2', 'observer_artifact_admission_v3').replace('admit_observer_transparency_v2', 'admit_observer_transparency_v3'))
        self.assertEqual(native.sha(HERE/'observer_artifact_admission_v1.py'), 'd6b4458e0bb861ef4b12d62655eff58712fa06c3e702abe2b456a44ac081c95a')
        self.assertEqual(native.sha(HERE/'observer_artifact_admission_v2.py'), '30a35c8bf082c0695fe3d8c5d6e83665d0b1bb88f960d18505e18584f340c76d')


if __name__ == '__main__': unittest.main()

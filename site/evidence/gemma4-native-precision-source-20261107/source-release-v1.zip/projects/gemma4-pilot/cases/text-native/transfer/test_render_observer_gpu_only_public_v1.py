"""Actual-metadata/public-replay fixtures; no arrays, native model or Git."""
from contextlib import contextmanager
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('_observer_renderer_test', HERE/'render_observer_gpu_only_public_v1.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
CASE = HERE.parent
RUN = CASE/'runs/compare-observer-gpu-only-v3-20261107T005745Z'


@contextmanager
def no_arrays():
    original_open, original_stat = Path.open, Path.stat
    def opened(path, *args, **kwargs):
        if path.suffix in ('.npy', '.safetensors'): raise AssertionError('renderer opened native array')
        return original_open(path, *args, **kwargs)
    def stated(path, *args, **kwargs):
        if path.suffix in ('.npy', '.safetensors'): raise AssertionError('renderer statted native array')
        return original_stat(path, *args, **kwargs)
    with patch.object(Path, 'open', opened), patch.object(Path, 'stat', stated): yield


def actual():
    report = m.parse(m.metadata(RUN/'observer-gpu-only-report.json', m.REPORT_SHA)); documents = {}
    for index, pair in enumerate(report['target_distribution_pairs']):
        root = RUN/'analysis'/('scores-%02d' % index)
        # Every original adapter document remains byte-bound to the admitted
        # report. Local filename lookup here does not rewrite its POSIX sources.
        for name, digest in pair['frozen_document_sha256'].items(): m.metadata(root/name, digest)
        for side in pair['sides']:
            name = side+'-targets.json'
            documents[(index, side.removeprefix('gpu-'))] = m.parse(m.metadata(root/name, pair['frozen_document_sha256'][name]))
    return report, documents


class Publication(unittest.TestCase):
    def test_actual6pairs4vectors282rows98samples_lossless_and_private(self):
        with no_arrays():
            report, documents = actual(); targets, metrics = m.safe_main(report, documents)
        self.assertEqual(len(targets['vectors']), 4)
        self.assertEqual(sum(len(row['logprobs']) for row in targets['vectors']), 636)
        self.assertEqual(len(metrics['target_distribution_pairs']), 6)
        self.assertEqual(sum(len(row['distributions']['positions']) for row in metrics['target_distribution_pairs']), 282)
        self.assertEqual(len(metrics['boundary_samples']['per_boundary']), 98)
        self.assertEqual(metrics['boundary_samples']['global']['count'], 294784)
        self.assertFalse(metrics['scope']['GPU_NPU_observer_comparison_complete'])
        self.assertIsNone(metrics['acceptance']); m.privacy(targets); m.privacy(metrics)
        for source, public in zip(report['target_distribution_pairs'], metrics['target_distribution_pairs']):
            for key in ('side_a_nll_nat_per_token', 'side_b_nll_nat_per_token', 'mae_nat', 'p99_nat', 'max_abs_nat'):
                self.assertEqual(source['targets']['metrics'][key], public['targets'][key])
            for original, row in zip(source['distributions']['positions'], public['distributions']['positions']):
                self.assertEqual(row['prediction_index'], original['position'])
                self.assertEqual(row['tail_merged_js'], original['tail_merged_js']['value'])
                self.assertEqual(row['coverage'], original['coverage'])

    def test_cosine_roundoff_is_preserved_not_clamped_to1(self):
        report, documents = actual(); _, metrics = m.safe_main(report, documents)
        source = report['boundary_sample_comparisons'][0]['metrics']['per_tensor']
        for key, value in metrics['boundary_samples']['per_boundary'].items(): self.assertEqual(value['cosine'], source[key]['cosine']['value'])
        self.assertNotEqual(metrics['boundary_samples']['per_boundary']['block.00.output']['cosine'], 1.0)
        self.assertEqual(metrics['boundary_samples']['sample_shape'], [1, 47, 64])

    def test_real_stdlib6pair_replay_and_tampered_vectors_or_metrics_fail(self):
        report, documents = actual(); targets, metrics = m.safe_main(report, documents)
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder); script = root/'replay-targets.py'; script.write_text(m.replay_source(), encoding='utf-8')
            a, b = root/'selected-targets.json', root/'selected-metrics.json'
            a.write_bytes(m.encoded(targets)); b.write_bytes(m.encoded(metrics))
            def run(): return subprocess.run([sys.executable, '-S', '-B', str(script), str(a), str(b)], capture_output=True, timeout=10)
            success = run(); self.assertEqual(success.returncode, 0, success.stderr)
            self.assertEqual(json.loads(success.stdout)['arrays_opened'], 0)
            self.assertEqual(json.loads(success.stdout)['pairs'], 6)
            bad = copy.deepcopy(metrics); bad['target_distribution_pairs'][0]['targets']['mae_nat'] = .01; b.write_bytes(m.encoded(bad))
            self.assertNotEqual(run().returncode, 0)
            b.write_bytes(m.encoded(metrics)); changed = copy.deepcopy(targets); changed['vectors'][0]['logprobs'][50] -= .01; a.write_bytes(m.encoded(changed))
            self.assertNotEqual(run().returncode, 0)

    def test_causal_position_and_source_input_identity_corruption_rejected(self):
        report, documents = actual()
        for field in ('position', 'source_input', 'vector_value'):
            corrupted = copy.deepcopy(documents); row = corrupted[(0, 'off-before')]
            if field == 'position': row['scores'][0]['position'] = 0
            if field == 'source_input': row['common']['inputs']['sha256'] = '0'*64
            if field == 'vector_value': row['scores'][0]['logprob'] -= .01
            with self.subTest(field=field), self.assertRaises(ValueError): m.safe_main(report, corrupted)

    def test_privacy_scan_rejects_private_identifiers_and_actual_tokens(self):
        for value in ({'token': 123}, {'safe': '/srv/precision-user/source.py'}, {'safe': 'REDACTED_PLATFORM_HOST'},
            {'safe': 'REDACTED_DEVICE_UUID'}, {'safe': 'wikitext2-discovery-001'}):
            with self.subTest(value=value), self.assertRaises(ValueError): m.privacy(value)

    def test_v6_keeps49_identity_only3statuses_change(self):
        matrix = m.parse(m.metadata(CASE/'matrix-gpu-npu-v5.json', m.MATRIX_SHA)); coverage = m.coverage_v6(matrix)
        self.assertEqual(len(coverage['tasks']), 49)
        self.assertEqual(coverage['counts'], {'complete': 9, 'partial': 9, 'pending': 8, 'deferred': 21, 'not_applicable': 2})
        for a, b in zip(matrix['public_summary_allowlist']['tasks'], coverage['tasks']):
            self.assertEqual(a['task_id'], b['task_id']); self.assertEqual(a['expected_coverage'], b['expected_coverage'])
            if a['task_id'] not in ('D03', 'O01', 'O02'): self.assertEqual(a['status'], b['status'])
        self.assertFalse(coverage['full_core_complete']); self.assertFalse(coverage['original_49_task_scope_complete'])

    def test_E02_missing_gate_refuses_before_creating_candidates(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder)/'candidate'
            with patch.object(m, 'E02_REPORT_SHA', None), self.assertRaisesRegex(ValueError, 'E02 report/controller'):
                m.render('/missing/spec', 'a'*64, target, 'numeric')
            self.assertFalse(target.exists())

    def test_actual_E02_fullscope_payload_framing_and_roundoff_not_clamped(self):
        with no_arrays():
            formal, _ = actual()
            report = m.parse(m.metadata(CASE/'runs/compare-observer-gpu-e02-20261107T012332Z/e02-report.json', m.E02_REPORT_SHA))
            result = m.safe_e02(report, formal)
        self.assertEqual(len(result['target_distribution_checks']), 6)
        self.assertEqual(sum(len(x['distribution_rows']) for x in result['target_distribution_checks']), 282)
        self.assertEqual(len(result['boundary_samples']['per_boundary']), 98)
        self.assertEqual(result['boundary_samples']['global']['side_a_norm'], 577.1515429296232)
        for family in ('raw_logits', 'boundary_samples'):
            self.assertTrue(result['payload_identity'][family]['all_equal'])
        d = result['target_distribution_checks'][0]['distribution_maximum_coordinate_diagnostics']['tail_merged_js']
        self.assertEqual(d['reported_max_prediction_index'], 0)
        self.assertEqual(d['independent_exact_max_prediction_index'], 144)
        self.assertEqual(d['independent_unrounded_max_value'], 4.7021875179805497e-17)
        self.assertEqual(d['independent_value_at_reported_coordinate'], 0)
        self.assertIsNone(d['model_acceptance_threshold']); m.privacy(result)
        for mutation in ('shape', 'hash', 'source', 'row'):
            bad = copy.deepcopy(report)
            if mutation == 'shape': bad['payload_identity']['raw_logits']['files']['off-before']['per_tensor']['logits']['shape'][1] = 159
            if mutation == 'hash': bad['payload_identity']['raw_logits']['files']['off-before']['physical_data_payload_sha256'] = '0'*64
            if mutation == 'source': bad['source_report']['sha256'] = '0'*64
            if mutation == 'row': bad['target_distribution_checks'][0]['distribution_rows'][0]['position'] = 1
            with self.subTest(mutation=mutation), self.assertRaises(ValueError): m.safe_e02(bad, formal)

    @unittest.skipUnless(os.name == 'posix', 'production original-path identities are POSIX; pure transforms run on both hosts')
    def test_actual_full_private_emission_zero_arrayIO_all_metadata_chain(self):
        plan = HERE/'observer-gpu-only-publication-plan-v1.json'; digest = hashlib.sha256(plan.read_bytes()).hexdigest()
        with tempfile.TemporaryDirectory(prefix='compare-observer-public-render-fixture-', dir=CASE/'runs') as folder, no_arrays():
            root = Path(folder)
            for phase in ('numeric', 'documents', 'ledger'):
                result = m.render(plan, digest, root/phase, phase)
                self.assertEqual(len(result['files']), 3)
                self.assertEqual(result['arrays_statted_opened_or_copied'], 0)
                self.assertEqual(result['public_or_git_writes'], 0)
                self.assertGreaterEqual(result['source_metadata_files_rehashed'], 85)
            public = root/'numeric'; cp = subprocess.run([sys.executable, '-S', '-B', str(public/'replay-targets.py'),
                str(public/'selected-targets.json'), str(public/'selected-metrics.json')], capture_output=True, timeout=10)
            self.assertEqual(cp.returncode, 0, cp.stderr)
            self.assertEqual(json.loads(cp.stdout)['pairs'], 6)
            matrix = json.loads((root/'ledger/matrix-gpu-npu-v6.json').read_bytes())
            workload = (root/'ledger/workload-gpu-npu-v6.json').read_bytes()
            self.assertEqual(matrix['workload']['sha256'], hashlib.sha256(workload).hexdigest())
            for phase in ('numeric', 'documents'):
                for path in (root/phase).iterdir():
                    if path.suffix == '.json': m.privacy(json.loads(path.read_bytes()))
            self.assertIn(b'4.7021875179805497e-17', (root/'documents/report.md').read_bytes())
            with self.assertRaises(ValueError): m.render(plan, digest, root/'numeric', 'numeric')


if __name__ == '__main__': unittest.main()

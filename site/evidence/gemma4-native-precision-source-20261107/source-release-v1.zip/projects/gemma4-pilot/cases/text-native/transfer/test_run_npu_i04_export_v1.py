"""CPU transport protocol fixtures, never evidence of native captures/numerics."""
import hashlib
import importlib.util
from pathlib import Path
import shutil
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i04_npu_export_runner_test',HERE/'run_npu_i04_export_v1.py')
tool = importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)


class Runner(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)/'new-i04-task';self.here=self.root/'tools/export';self.here.mkdir(parents=True)
        shutil.copyfile(HERE/'export_i04_evidence_v1.py',self.here/'export_i04_evidence_v1.py')
        repo = next(path for path in HERE.parents if (path/'skills/precision-compare/scripts/record_run.py').is_file())
        shutil.copyfile(repo/'skills/precision-compare/scripts/record_run.py',self.here/'record_run.py')
        self.claim=self.root/'claims'/tool.CLAIM_NAME;self.claim.mkdir(parents=True)
        self.controller={'task':'I04','status':'completed','returncode':0,'timed_out':False,'remaining_descendants':[],
            'started_utc':'2026-11-06T15:00:00+00:00','finished_utc':'2026-11-06T15:06:00+00:00','synthetic_cpu_fixture':True,
            'wall_seconds':360.0,'metadata_export_reserved_seconds':960,'controller_work_seconds':2020}
        self.launcher=self.root/'source/projects/gemma4-pilot/cases/text-native/transfer/npu_i04_launcher_v1.py'
        self.launcher.parent.mkdir(parents=True);shutil.copyfile(HERE/'npu_i04_launcher_v1.py',self.launcher)
        self.outer={'task':'I04','backend':'NPU','status':'completed','returncode':0,'timed_out':False,
            'native_capture_count':1,'native_forward_calls_total':4,'model_loads':1,
            'stage_spec_source_sha256':tool.STAGE_SHA,'expected_inventory_source_sha256':tool.EXPECTED_SHA,
            'cpu_prerequisite_source_sha256':tool.CPU_SHA,'i03_prerequisite_source_sha256':tool.I03_SHA,'collector_sha256':tool.COLLECTOR_SHA,
            'source_sha256':{str(self.launcher):tool.LAUNCHER_SHA},
            'validation':{'status':'i04_output_artifacts_checked','target_scores':762,'distribution_rows':282,'physical_raw_rows':896,'valid_raw_rows':768,'pad_only_raw_rows':128},
            'output_dir':self.root.as_posix()+'/runs/synthetic/artifacts','synthetic_cpu_fixture':True}
        self.terminal=self.claim/'controller-receipt.json';self.receipt=self.claim/'capture-receipt.json'
        self.save(self.claim/'claim.json',{'runtime_uuid':'REDACTED_DEVICE_UUID','whole_attempt_seconds':3000,
            'capture_seconds':1200,'native_forward_calls':4,'model_loads':1,'cpu_prerequisite_sha256':tool.CPU_SHA})
        self.save(self.terminal,self.controller);self.save(self.receipt,self.outer)
        self.payload=self.root/'synthetic-payload';self.payload.mkdir()
        self.map_path=self.payload/'source-map.json';self.archive=self.root/'synthetic.tar.gz';self.archive.write_bytes(b'CPU transport fixture, not a tar or native evidence')
        positions={'A':sorted(set(i*127//15 for i in range(16))|set(range(127,159))),
                   'B':sorted(set(i*63//15 for i in range(16))|set(range(63,95)))}
        modes=['alone-A','alone-B','batch-left','batch-right']
        names={'modes/%s/raw-native-logits.safetensors'%mode for mode in modes}
        names|={'modes/%s/request-%s/dist-p%03d.npy'%(mode,request,p) for mode in modes
            for request in ([mode[-1]] if mode.startswith('alone-') else ['A','B']) for p in positions[request]}
        self.mapping={'request':{'task':'I04','backend':'NPU','outer_receipt':str(self.receipt)},
            'full_array_hashes_checked':286,'retained_array_count':286,'files':{
                self.outer['output_dir']+'/'+name:{'sha256':'a'*64,'size':1,'retained_at_source':True} for name in names}}
        self.save(self.map_path,self.mapping)
        self.result={'status':'i04_transport_export_completed','retained_array_count':286,'native_executions_started':0,
            'transport_allowed_by_actual_size':True,'archive':str(self.archive),'archive_bytes':self.archive.stat().st_size,
            'archive_sha256':tool.sha(self.archive),'logical_payload_bytes':1000,'source_map_sha256':tool.sha(self.map_path)}

    def save(self,path,doc):
        if path.exists():path.unlink()
        tool.put(path,doc)

    def verify(self):return tool.verify_result(self.result,self.mapping,self.map_path,self.receipt,self.root)

    def test_exact_native_terminal_and_frozen_stdlib_tools(self):
        exporter,recorder,terminal,outer,seconds=tool.preflight(self.root,self.here)
        self.assertEqual((tool.sha(exporter),tool.sha(recorder)),(tool.EXPORT_SHA,tool.RECORD_SHA))
        self.assertEqual(seconds,360)

    def test_changed_tool_or_terminal_is_rejected(self):
        (self.here/'export_i04_evidence_v1.py').write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'source differs'):tool.preflight(self.root,self.here)
        shutil.copyfile(HERE/'export_i04_evidence_v1.py',self.here/'export_i04_evidence_v1.py')
        self.controller['remaining_descendants']=[123];self.save(self.terminal,self.controller)
        with self.assertRaisesRegex(ValueError,'terminal and cleaned'):tool.preflight(self.root,self.here)

    def test_proof_product_or_launcher_source_changes_rejected_before_export(self):
        self.outer['cpu_prerequisite_source_sha256']='a'*64;self.save(self.receipt,self.outer)
        with self.assertRaisesRegex(ValueError,'source identities'):tool.preflight(self.root,self.here)
        self.outer['cpu_prerequisite_source_sha256']=tool.CPU_SHA;self.outer['validation']['distribution_rows']=281;self.save(self.receipt,self.outer)
        with self.assertRaisesRegex(ValueError,'inventory differs'):tool.preflight(self.root,self.here)
        self.outer['validation']['distribution_rows']=282;self.save(self.receipt,self.outer);self.launcher.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'launcher binding'):tool.preflight(self.root,self.here)

    def test_native_claim_wrong_uuid_or_call_count_rejected(self):
        path=self.claim/'claim.json';value=tool.read(path);value['native_forward_calls']=3;self.save(path,value)
        with self.assertRaisesRegex(ValueError,'native claim differs'):tool.preflight(self.root,self.here)
        value['native_forward_calls']=4;value['runtime_uuid']='not-the-same-device';self.save(path,value)
        with self.assertRaisesRegex(ValueError,'native claim differs'):tool.preflight(self.root,self.here)

    def test_cumulative3000_bound_and_strict4counts(self):
        self.controller['wall_seconds']=2040.1;self.save(self.terminal,self.controller)
        with self.assertRaisesRegex(ValueError,'3000s'):tool.preflight(self.root,self.here)
        self.controller['wall_seconds']=360.0;self.save(self.terminal,self.controller)
        self.outer['model_loads']=True;self.save(self.receipt,self.outer)
        with self.assertRaisesRegex(ValueError,'one-process'):tool.preflight(self.root,self.here)

    def test_exact286_retained_inventory_and_archive_pin(self):
        self.assertEqual(len(self.verify()),286)
        self.archive.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'size/SHA differs'):self.verify()

    def test_no_copied_arrays_or_missing_raw_are_accepted(self):
        key=next(key for key in self.mapping['files'] if key.endswith('raw-native-logits.safetensors'))
        self.mapping['files'][key]['path']='payload/copied'
        with self.assertRaisesRegex(ValueError,'retained array metadata'):self.verify()
        self.mapping['files'][key].pop('path');self.mapping['files'].pop(key)
        with self.assertRaises(ValueError):self.verify()

    def test_actual_transport_caps_and_map_pin(self):
        for field,value in [('logical_payload_bytes',tool.LOGICAL_CAP+1),('archive_bytes',tool.ENCODED_CAP+1),('source_map_sha256','b'*64)]:
            old=self.result[field];self.result[field]=value
            with self.assertRaises(ValueError):self.verify()
            self.result[field]=old

    def test_original_receipts_stay_byte_identical_and_duplicate_keys_fail(self):
        before=self.terminal.read_bytes(),self.receipt.read_bytes()
        tool.preflight(self.root,self.here);self.verify()
        self.assertEqual(before,(self.terminal.read_bytes(),self.receipt.read_bytes()))
        self.terminal.write_text('{"status":"completed","status":"failed"}')
        with self.assertRaisesRegex(ValueError,'duplicate JSON'):tool.preflight(self.root,self.here)

    def test_exclusive_export_claim_is_permanent(self):
        claim=self.root/'metadata-export-once.json';tool.put(claim,{'native_executions_started':0})
        before=claim.read_bytes()
        with self.assertRaises(FileExistsError):tool.put(claim,{'retry':True})
        self.assertEqual(claim.read_bytes(),before)


if __name__=='__main__':unittest.main()

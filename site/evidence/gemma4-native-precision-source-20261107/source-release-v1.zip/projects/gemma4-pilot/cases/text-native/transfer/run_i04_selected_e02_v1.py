"""One I04 stdlib selected E02 CPU900/generic920/whole960 attempt.

The original comparison must already have completed0. Export only metadata;
classify all572 native arrays before source stat/open/copy. Keep every raw path
and byte unchanged, including copied aliases of original GPU temporary paths.
"""
import argparse
import base64
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import tarfile
import time
import traceback

VERIFY_SHA='2cdb98c37f2e3690ed9b7918ff0b223f4f662d90014c0bbd649c2dc76ecc639c'
INDEPENDENT_SHA='863019a1bd9875d418630c4c5e547576232e225fd66a98d63d51f3023701a44e'
RECORDER_SHA='2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'
CONTROLLER_SOURCE_SHA='a01ab2aef1ebb99402bd04f739f9f8e751979e77d87599835d5f413c88c59178'
MAIN_SOURCE_SHA='640b0af596111e12eb73aca20f7b8e5b101c04341af0aed2d3a5f9a1d2f19db0'
TOTAL,GENERIC,CHILD,CLEANUP=960,920,900,20
MAX_SMALL,MAX_TOTAL,MAX_GZIP,MAX_ENVELOPE=16*1024**2,192*1024**2,32*1024**2,64*1024**2


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def read(path):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,parse_constant=reject)


def put(path,document):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(document,stream,indent=2,allow_nan=False);stream.write('\n')


def tick(started):require(time.monotonic()-started<TOTAL-CLEANUP,'I04 E02 metadata/export cleanup reserve exhausted')


def excluded(path):
    if Path(path).name in ('stdout.bin','stderr.bin'):return False
    return str(path).lower().endswith(('.npy','.safetensors','.tar','.gz','.zst','.whl','.part','.bin'))


def small_closure(proof,extra,payload,started):
    """No stat/open of large arrays, including their original/copied aliases."""
    sources=dict(extra);resolved={};catalog={};total=0
    for name,ref in proof['checked_sources'].items():
        if excluded(name):continue
        require(name not in sources or sources[name]==ref['sha256'],'conflicting checked metadata SHA');sources[name]=ref['sha256']
    for original,ref in proof['original_source_files'].items():
        if ref['large'] or excluded(original) or excluded(ref['actual_path']):continue
        require(original not in sources or sources[original]==ref['sha256'],'conflicting original metadata alias')
        sources[original]=ref['sha256'];resolved[original]=ref['actual_path']
    for i,(original,digest) in enumerate(sorted(sources.items())):
        tick(started)
        if excluded(original):continue
        actual=Path(resolved.get(original,original));require(not excluded(actual),'metadata alias resolves to a forbidden array/archive')
        require(actual.is_file() and not actual.is_symlink() and actual.stat().st_size<=MAX_SMALL and sha(actual)==digest,'original small source bytes differ')
        total+=actual.stat().st_size;require(total<=MAX_TOTAL,'small copied metadata exceeds192MiB')
        relative='payload/%04d/%s'%(i,actual.name);target=payload/relative;target.parent.mkdir(parents=True)
        raw=actual.read_bytes();require(hashlib.sha256(raw).hexdigest()==digest,'source changed before copying')
        with target.open('xb') as stream:stream.write(raw)
        require(sha(target)==digest,'copied metadata SHA differs')
        catalog[original]={'path':relative,'sha256':digest,'size':len(raw)}
    # Close the source-copy interval without touching any omitted large source.
    for original,ref in catalog.items():
        tick(started);require(sha(resolved.get(original,original))==ref['sha256'] and sha(payload/ref['path'])==ref['sha256'],
            'metadata changed before closing small export')
    return catalog


class BoundedSink:
    def __init__(self,stream,started):self.stream,self.started=stream,started
    def write(self,raw):
        tick(self.started);require(self.stream.tell()+len(raw)<=MAX_GZIP,'I04 E02 gzip32MiB hard cap');return self.stream.write(raw)
    def tell(self):return self.stream.tell()
    def flush(self):return self.stream.flush()


def archive_small(reservation,archive,started):
    members={};total=0
    for path in sorted(reservation.rglob('*')):
        tick(started);require(not path.is_symlink(),'symlink in E02 metadata output')
        if path.is_file():
            require(not excluded(path) or path.name in ('stdout.bin','stderr.bin'),'array/archive unexpectedly present in E02 metadata output')
            size=path.stat().st_size;total+=size
            require(size<=MAX_SMALL and total<=MAX_TOTAL and len(members)<4096,'E02 complete metadata archive inventory exceeds finite caps')
            members[path.relative_to(reservation).as_posix()]={'sha256':sha(path),'size_bytes':size}
    put(reservation/'archive-members.json',{'schema_version':1,'kind':'i04-e02-small-archive-members','files':members,
        'native_array_files':0,'native_executions_started':0,'acceptance':None})
    with archive.open('xb') as stream,tarfile.open(fileobj=BoundedSink(stream,started),mode='w:gz') as package:
        for name in sorted(set(members)|{'archive-members.json'}):
            tick(started);path=reservation/name
            if name in members:require(sha(path)==members[name]['sha256'],'small member changed before archiving')
            package.add(path,arcname=name,recursive=False)
    require(archive.stat().st_size<=MAX_GZIP,'completed gzip cap differs')
    for name,ref in members.items():tick(started);require(sha(reservation/name)==ref['sha256'],'small member changed during archive creation')
    return members


def preflight(root,controller,digest):
    controller=Path(controller);require(not controller.is_symlink() and controller.resolve(strict=True).is_relative_to(root) and sha(controller)==digest,
        'external actual controller bytes/path differ')
    doc=read(controller);require(doc['task']=='I04' and doc['status']=='completed' and doc['returncode']==doc['child_returncode']==0 and
        doc['timed_out'] is False and doc['native_executions_started']==0 and doc['whole_cpu_seconds']==960 and doc['analysis_seconds']==900,
        'original I04 independent comparison must complete0 before E02')
    tools=Path(doc['tools_root']);manifest=tools/'tool-bundle-manifest.json'
    require(tools.resolve(strict=True).is_relative_to(root/'tools') and sha(manifest)==doc['tool_manifest_sha256'],'original CPU tool manifest differs')
    data=read(manifest);controller_source='projects/gemma4-pilot/cases/text-native/transfer/run_i04_actual_compare_v1.py'
    main='projects/gemma4-pilot/cases/text-native/adapters/admit_i04_batch_padding_v1.py'
    require(data['files'][controller_source]['sha256']==CONTROLLER_SOURCE_SHA and sha(tools/controller_source)==CONTROLLER_SOURCE_SHA and
        data['files'][main]['sha256']==MAIN_SOURCE_SHA and sha(tools/main)==MAIN_SOURCE_SHA and Path(doc['argv'][2]).resolve()==(tools/main).resolve(),
        'original reviewed a01 controller and640b numerical analysis source differ')
    require(Path(doc['report']['path']).resolve(strict=True).is_relative_to(controller.parent.resolve()) and
        sha(doc['report']['path'])==doc['report']['sha256'],'original comparison report path/SHA differs')
    report=read(doc['report']['path']);require(report['status']=='i04_raw_bf16_batch_padding_and_request_pairs_checked' and
        report['scope']['target_distribution_pairs']==18 and report['scope']['original_large_sources_final_bytehash_checked']==572 and
        report['thresholds'] is None and report['acceptance'] is None,'original18/572 numerical report differs')
    return doc


def run(root,controller,controller_sha):
    os.umask(0o077);started=time.monotonic();root=Path(root)
    require(os.name=='posix' and root.is_dir() and not root.is_symlink(),'original POSIX task root required');root=root.resolve(strict=True)
    here=Path(__file__).resolve().parent
    require(here.is_relative_to(root) and not Path(__file__).is_symlink() and not (root/'runs').is_symlink(),'owned CPU source/runs paths required')
    verifier=here/'verify_i04_selected_e02_v1.py';independent=here/'verify_i03_selected_e02_v1.py';recorder=here/'record_run.py'
    dependencies={str(verifier):VERIFY_SHA,str(independent):INDEPENDENT_SHA,str(recorder):RECORDER_SHA,str(Path(__file__).resolve()):sha(__file__)}
    for name,digest in dependencies.items():require(Path(name).is_file() and not Path(name).is_symlink() and sha(name)==digest,'reviewed E02 source closure differs')
    preflight(root,controller,controller_sha)
    require(not any(name in sys.modules for name in ('torch','torch_npu','numpy','transformers')),'CPU E02 runner imported a framework')
    put(root/'i04-selected-e02-claim.json',{'task':'I04-selected-E02','controller_sha256':controller_sha,'claimed_utc':datetime.now(timezone.utc).isoformat(),
        'native_executions_started':0,'automatic_retry':False,'whole_seconds':TOTAL,'numeric_child_seconds':CHILD})
    reservation=root/'runs'/('compare-i04-selected-e02-invocation-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));reservation.mkdir(mode=0o700)
    spec=importlib.util.spec_from_file_location('i04_e02_original_generic',recorder);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    require(sha(recorder)==RECORDER_SHA,'generic source changed after import')
    def interrupted(signum,_):raise KeyboardInterrupt('bounded I04 E02 signal '+str(signum))
    handlers={sig:signal.signal(sig,interrupted) for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP,signal.SIGALRM)}
    signal.setitimer(signal.ITIMER_REAL,max(.01,TOTAL-(time.monotonic()-started)))
    state={'schema_version':1,'task':'I04-selected-E02','status':'running','started_utc':datetime.now(timezone.utc).isoformat(),
        'original_controller':str(controller),'original_controller_sha256':controller_sha,'verifier_sha256':VERIFY_SHA,'independent_scalar_source_sha256':INDEPENDENT_SHA,
        'runner_sha256':sha(__file__),'generic_sha256':RECORDER_SHA,'child_cpu_seconds':CHILD,'generic_envelope_seconds':GENERIC,
        'whole_cpu_seconds':TOTAL,'cleanup_reserve_seconds':CLEANUP,'native_executions_started':0,'thresholds':None,'acceptance':None}
    put(reservation/'controller-start.json',state);code=2
    try:
        require(TOTAL-(time.monotonic()-started)-CLEANUP>=GENERIC,'insufficient finite E02 numeric envelope')
        generic,command=module.record_run(reservation,'cpu','i04-e02-scalar-selected',GENERIC,
            lambda folder:[sys.executable,'-S','-B',str(verifier),'--controller',str(controller),'--controller-sha256',controller_sha,
                '--output-dir',str(folder/'e02'),'--timeout-seconds',str(CHILD)],cwd=here)
        state['generic_receipt']={'path':str(generic/'command.json'),'sha256':sha(generic/'command.json')}
        state['child_returncode']=command['child_returncode'];state['timed_out']=command['status']=='timed_out'
        require(command['status']=='completed' and command['returncode']==command['child_returncode']==0,'I04 E02 numeric child failed; preserve original logs')
        result_path=generic/'e02/e02-report.json';result=read(result_path);scope=result['scope']
        require(result['status']=='independent_i04_selected_e02_checks_matched' and scope['target_pairs']==18 and scope['request_target_counts']=={'A':159,'B':95} and
            scope['matched_cross_backend_distribution_pair_rows']==282 and 282<=scope['independent_distribution_pair_rows']<=285 and
            scope['admitted_large_sources_final_bytehash_checked']==572 and scope['native_KV_checks']==0 and result['native_KV_checks']==[] and
            result['native_executions_started']==0 and result['thresholds'] is None and result['acceptance'] is None,'independent selected E02 scope/result differs')
        proof=read(generic/'e02/source-proof.json');omitted=read(generic/'e02/admitted-large-source-hashes.json')
        require(proof['all_admitted_large_final_hashes']==572 and len(omitted)==572,'fresh all572 large source catalog required')
        payload=reservation/'payload';payload.mkdir()
        catalog=small_closure(proof,dependencies,payload,started)
        put(payload/'metadata-source-map.json',{'schema_version':1,'kind':'i04-selected-e02-metadata','files':catalog,'source_report':result['source_report'],
            'omitted_large_sources':omitted,'native_executions_started':0,'native_array_files_copied':0,'numeric_scope':scope,'acceptance':None})
        state.update(status='numeric_and_small_proof_completed_pending_export',report={'path':str(result_path),'sha256':sha(result_path)},scope=scope)
        put(reservation/'preexport-controller.json',state);archive=reservation.with_name(reservation.name+'-small.tar.gz')
        members=archive_small(reservation,archive,started)
        for name,digest in dependencies.items():require(sha(name)==digest,'immutable E02 dependency changed during replay/export')
        require(sha(controller)==controller_sha,'original admitted controller changed')
        state.update(status='completed',archive={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive)},
            copied_small_sources=len(catalog),archive_regular_members=len(members)+1,native_array_files_copied=0);code=0
    except BaseException as exc:state.update(status='failed',error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),partial_files_preserved=True,automatic_retry=False)
    finally:
        receipt=reservation/'controller-receipt.json';envelope=None
        try:
            if code==0:
                tick(started);encoded=base64.b64encode(archive.read_bytes()).decode('ascii')
                state.update(returncode=0,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started)
                raw=(json.dumps(state,indent=2,allow_nan=False)+'\n').encode();envelope=reservation.with_name(reservation.name+'-json-base64.txt')
                require(len(encoded)+len(raw)*2+8192<=MAX_ENVELOPE,'bounded envelope encoding estimate exceeds64MiB')
                put(envelope,{'schema_version':1,'kind':'i04-selected-e02-small-transport','controller_path':str(receipt),
                    'controller_sha256':hashlib.sha256(raw).hexdigest(),'controller_raw_base64':base64.b64encode(raw).decode('ascii'),
                    'archive':{**state['archive'],'base64':encoded}})
                require(envelope.stat().st_size<=MAX_ENVELOPE,'actual E02 envelope exceeds64MiB');tick(started)
                with receipt.open('xb') as stream:stream.write(raw)
                summary={'status':'completed','receipt':str(receipt),'receipt_sha256':sha(receipt),'archive':state['archive'],
                    'envelope':str(envelope),'envelope_bytes':envelope.stat().st_size,'envelope_sha256':sha(envelope),'native_executions_started':0}
            else:
                state.update(returncode=code,finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started);put(receipt,state);summary=state
        except BaseException as exc:
            code=2;state.update(status='export_failed',returncode=2,error_type=type(exc).__name__,error=str(exc),partial_files_preserved=True,automatic_retry=False,
                finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started)
            if not receipt.exists():put(receipt,state)
            summary=state
        finally:
            signal.setitimer(signal.ITIMER_REAL,0)
            for sig,handler in handlers.items():signal.signal(sig,handler)
    print(json.dumps(summary,indent=2),flush=True);return code


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('root','controller'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--controller-sha256',required=True);a=p.parse_args();return run(a.root,a.controller,a.controller_sha256)


if __name__=='__main__':raise SystemExit(main())

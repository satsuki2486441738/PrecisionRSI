"""Export actual observer CPU originals; success proof or failure diagnostic.

Only existing metadata/source bytes are copied. Tiny CPU tensor descriptors are
retained without opening their payloads. No framework import, model or device
query occurs. A successful portable proof is checked with verify_portable().
"""
import argparse
import base64
from datetime import datetime,timezone
import hashlib
import io
import json
import os
from pathlib import Path,PurePosixPath
import re
import signal
import tarfile
import time
import traceback

CASE='projects/gemma4-pilot/cases/text-native'
SUBDIR='observer-transparency-20261107/cpu-prerequisite-v1'
MANIFEST_SHA='32150fc86e53d506d43f371712ea88ff1bbc26026892ff118e46684ec2b4f5b1'
ARCHIVE_SHA='13b689907d1ddaf98498ddd2d0938c68f29c1b5472a8d2bbfdc5a1ba8c433642'
ACTUAL_CONTROLLER_SHA='a95ce139480687fb667ac2d3863558a74cd2640719858b4eae12c1214ff75c7a'
ACTUAL_PROBE_SHA='45765642fab5fed7c61dc5d8d4dafb6e872004208ebfb0d282cf13186d180651'
CODE={'collector':(CASE+'/adapters/observer_collectors_v1.py','774b5cb210f294a23d6865f863d5facdf537c3ed3064ae39027425797b83101c'),
    'tests':(CASE+'/adapters/test_observer_collectors_v1.py','f58dbb0ee596d465ff35008ca92d30c1f6ca162ad363c198d5754c4c4af30d43'),
    'cleanup_helper':(CASE+'/transfer/i04_cpu_stage_operations_v3.py','36973a846475161e3ab05ff65c75bd56a535bcaad2056f3e42e6fa498d4002a2'),
    'operations':(CASE+'/transfer/observer_cpu_operations_v1.py','418f71583b8d82257a6b7d6ad40baf7b5359cca031c28bae389701bc2c460514'),
    'probe':(CASE+'/transfer/probe_observer_cpu_v1.py','d10abe1986188ba56a24d1cccf2102860d340d3beddef3e352f3265df6c103b2')}
RUNTIME={'torch','numpy','safetensors','torch_dispatch','module_hooks'}
MAX_MEMBER,MAX_RAW,MAX_GZIP,MAX_ENVELOPE=4*1024**2,32*1024**2,16*1024**2,24*1024**2
HEX=re.compile('[a-f0-9]{64}')


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return (json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
def parse(raw):
    def pairs(items):
        out={}
        for k,v in items:require(k not in out,'duplicate JSON key');out[k]=v
        return out
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def put(path,value):
    with Path(path).open('xb') as stream:stream.write(encoded(value))
def origin(value):
    require(isinstance(value,str) and value.startswith('/') and '\\' not in value and str(PurePosixPath(value))==value and
        all(x not in ('','.','..') for x in value.split('/')[1:]),'original absolute POSIX source path required')
    return PurePosixPath(value)
def relative(value):
    require(isinstance(value,str) and value and '\\' not in value and not PurePosixPath(value).is_absolute() and str(PurePosixPath(value))==value and
        all(x not in ('','.','..') for x in value.split('/')),'canonical relative proof member required');return PurePosixPath(value)
def reject_array(path):
    require(not str(path).lower().endswith(('.npy','.safetensors','.tar','.gz','.bin','.whl','.part')),'tensor/archive is descriptor-only, not a metadata source')
def original(path,root=None):
    path=Path(path);reject_array(path)
    require(path.is_absolute() and path.is_file() and not path.is_symlink() and path.stat().st_size<=MAX_MEMBER,'bounded original regular metadata required')
    if root is not None:
        require(path.is_relative_to(root) and path.resolve().is_relative_to(root),'original CPU metadata escapes root')
        current=path
        while current!=root:require(not current.is_symlink(),'symlink in original CPU source path');current=current.parent
    return path.read_bytes()


def audit(files,origins):
    """Pure original-byte CPU proof checks, usable after portable download."""
    require(set(files)==set(origins) and len(files)==24,'exact24 original CPU documents required')
    docs={name:parse(raw) for name,raw in files.items() if name not in {'tests_stdout','tests_stderr','probe_stderr','validation_stderr'} and not name.startswith(('code_','runtime_'))}
    # runtime_map is JSON, while runtime_<package> are literal source bytes.
    docs['runtime_map']=parse(files['runtime_map']);start=docs['start'];controller=docs['controller'];probe=docs['probe_receipt']
    require(sha(files['controller'])==ACTUAL_CONTROLLER_SHA and sha(files['probe_receipt'])==ACTUAL_PROBE_SHA,
        'machine-observed actual controller/probe original bytes differ')
    root=origin(start['argv'][start['argv'].index('--root')+1]);target=root/SUBDIR;source=target/'source';run=origin(origins['controller']).parent
    require(run.parent==target/'runs' and re.fullmatch(r'compare-observer-tiny-cpu-\d{8}T\d{6}Z',run.name),'original CPU run identity differs')
    expected={'start':target/'cpu-start-once.json','attempt':target/'cpu-attempt-once.json','stage':target/'stage-receipt.json',
        'manifest':target/'source-manifest.json','controller_start':run/'controller-start.json','controller':run/'controller-receipt.json',
        'validation_stdout':target/'cpu-validation.stdout','validation_stderr':target/'cpu-validation.stderr','tests_stdout':run/'tests.stdout',
        'tests_stderr':run/'tests.stderr','probe_stdout':run/'probe.stdout','probe_stderr':run/'probe.stderr','probe_receipt':run/'probe/receipt.json',
        'runtime_map':run/'runtime-source-map.json'}
    expected.update({'code_'+name:source/value[0] for name,value in CODE.items()})
    expected.update({'runtime_'+name:run/('runtime-sources/'+name+'.py') for name in RUNTIME})
    require({k:str(v) for k,v in expected.items()}==origins,'original CPU document paths/identities differ')
    manifest=docs['manifest'];require(sha(files['manifest'])==MANIFEST_SHA and manifest['kind']=='observer-tiny-cpu-source-v1' and
        manifest['production_model_loads']==manifest['native_executions_started']==0 and len(manifest['files'])==5,'fixed actual CPU source manifest differs')
    for name,(path,digest) in CODE.items():
        raw=files['code_'+name];require(sha(raw)==digest and manifest['files'][path]=={'sha256':digest,'size_bytes':len(raw)},'actual CPU scientific source changed')
    require(start['status']=='observer_tiny_CPU_spawned_not_result' and start['source_sha256']==CODE['operations'][1] and
        start['source_manifest_sha256']==MANIFEST_SHA and start['whole_cpu_seconds']==210 and start['cleanup_reserve_seconds']==20 and
        start['production_model_loads']==start['native_executions_started']==0 and start['native_claim_created'] is False and start['automatic_retry'] is False,
        'original CPU single-start scope differs')
    python=start['argv'][0]
    require(start['argv']==[python,'-S','-B',str(source/CODE['operations'][0]),'run','--root',str(root),'--manifest-sha256',MANIFEST_SHA] and
        origin(start['stdout'])==target/'cpu-validation.stdout' and origin(start['stderr'])==target/'cpu-validation.stderr','actual direct CPU argv/log identities differ')
    stage,attempt=docs['stage'],docs['attempt']
    require(stage['status']=='observer_cpu_sources_staged_not_native' and stage['source_files']==5 and stage['manifest_sha256']==MANIFEST_SHA and stage['archive_sha256']==ARCHIVE_SHA and
        stage['production_model_loads']==stage['native_executions_started']==0 and stage['native_claim_created'] is False and
        attempt['manifest_sha256']==MANIFEST_SHA and attempt['native_claim_created'] is False and attempt['native_executions_started']==0 and attempt['automatic_retry'] is False,
        'source stage/CPU attempt scope differs')
    require(controller['task']=='observer-cpu-validation-v1' and controller['status']=='completed' and controller['returncode']==0 and
        controller['source_manifest_sha256']==MANIFEST_SHA and origin(controller['source_root'])==source and
        controller['whole_cpu_seconds']==210 and controller['cleanup_reserve_seconds']==20 and controller['native_executions_started']==controller['production_model_loads']==0 and
        controller['native_claim_created'] is False and controller['automatic_retry'] is False and controller['pure_tests']==14 and controller['pure_test_skips']==0 and
        controller['actual_tiny_probe_checks']==29 and controller['remaining_owned_process_groups']==[] and
        type(controller['elapsed_seconds']) in (int,float) and 0<=controller['elapsed_seconds']<190,'actual CPU terminal14/29/cleanup scope differs')
    initial=docs['controller_start']
    require(initial['status']=='running' and all(initial[k]==controller[k] for k in ('task','started_utc','source_manifest_sha256','source_root','whole_cpu_seconds','cleanup_reserve_seconds')),
        'actual controller-start provenance differs')
    terminal=docs['validation_stdout'];require(terminal['status']=='completed' and terminal['returncode']==0 and
        terminal['receipt']=={'path':origins['controller'],'sha256':sha(files['controller']),'size_bytes':len(files['controller'])},'actual CPU stdout/controller raw SHA differs')
    steps=controller['steps'];require(len(steps)==2 and len({x['cleanup']['owned_process_group'] for x in steps})==2,'two distinct actual CPU owned process groups required')
    argv=[[python,'-S','-B','-m','unittest','test_observer_collectors_v1','-v'],
        [python,'-B',str(source/CODE['probe'][0]),'--collectors',str(source/CODE['collector'][0]),'--collectors-sha256',CODE['collector'][1],'--output',str(run/'probe')]]
    for index,(step,prefix,timeout) in enumerate(zip(steps,('tests','probe'),(30,120))):
        require(step['argv']==argv[index] and step['returncode']==0 and step['timed_out'] is False and step['timeout_seconds']==timeout and
            step['cleanup']['remaining_owned_process_group'] is False,'fresh CPU child argv/status/timeout/cleanup differs')
        for stream in ('stdout','stderr'):
            name=prefix+'_'+stream;require(step[stream]=={'path':origins[name],'sha256':sha(files[name]),'bytes':len(files[name])},'original CPU child log bytes differ')
    text=files['tests_stderr'].decode('utf8');require(re.search(r'Ran 14 tests? in ',text) and re.search(r'\nOK\s*$',text) and 'skipped' not in text,'fresh14 tests must pass with zero skips')
    require(controller['probe']=={'path':origins['probe_receipt'],'sha256':sha(files['probe_receipt']),'size_bytes':len(files['probe_receipt'])} and
        controller['runtime_source_map']=={'path':origins['runtime_map'],'sha256':sha(files['runtime_map']),'size_bytes':len(files['runtime_map'])},'original probe/runtime map refs differ')
    require(probe['task']=='observer-tiny-cpu-prerequisite-v1' and probe['status']=='completed' and probe['returncode']==0 and probe['timeout_seconds']==90 and
        probe['source']['sha256']==CODE['probe'][1] and probe['source']['path']==origins['code_probe'] and probe['collectors_source']['sha256']==CODE['collector'][1] and
        probe['collectors_source']['path']==origins['code_collector'] and probe['production_model_loads']==probe['production_model_forward_calls']==0 and
        probe['agent_hardware_or_availability_queries']==probe['agent_accelerator_initialization_requests']==0 and probe['library_internal_availability_queries']=='not instrumented',
        'actual tiny CPU source/scope differs')
    summary=docs['probe_stdout'];require(summary['status']=='completed' and summary['receipt']==origins['probe_receipt'] and summary['receipt_sha256']==sha(files['probe_receipt']) and summary['checks_passed']==29,
        'actual tiny probe stdout/ref differs')
    result=probe['result'];require(result['checks_passed']==len(set(result['checks']))==29 and result['tiny_cpu_forward_calls']==5 and result['production_model_loads']==result['production_model_forward_calls']==0 and
        result['production_boundary_count']==98 and result['tiny_boundary_count']==4 and result['tiny_module_count']==5,'actual tiny5module/4boundary/29checks result differs')
    require([x['mode'] for x in result['mode_outputs']]==['off-before','hooks-only','off-after','hooks-plus-dispatch-metadata'] and
        len({x['raw_bits_sha256'] for x in result['mode_outputs']})==1 and all(HEX.fullmatch(x['raw_bits_sha256']) for x in result['mode_outputs']),
        'actual tiny four-control output hashes differ')
    phases=probe['phase_observations'];require([x['phase'] for x in phases]==['after_torch','before_tiny_cpu_calls','after_tiny_cpu_calls'] and
        all(type(x['torch_npu_imported']) is bool and type(x['npu_namespace_registered']) is bool and
            x['npu_initialized'] is (False if x['npu_namespace_registered'] else None) and x['cuda_initialized'] is False for x in phases),
        'actual CPU probe observed initialized accelerator context')
    require(probe['versions']['torch'].split('+')[0]=='2.9.0' and set(probe['runtime_sources'])==set(docs['runtime_map'])==RUNTIME,'actual CPU version/five source inventory differs')
    aliases={}
    for name in RUNTIME:
        item=docs['runtime_map'][name];require(item['source']==probe['runtime_sources'][name] and item['copy']==
            {'path':origins['runtime_'+name],'sha256':sha(files['runtime_'+name]),'size_bytes':len(files['runtime_'+name])} and
            item['source']['sha256']==item['copy']['sha256'] and item['source']['size_bytes']==item['copy']['size_bytes'],
            'original actual runtime source/copy alias bytes differ')
        origin(item['source']['path']);aliases[name]=item['source']
    omitted=[x['artifact'] for x in result['mode_outputs']]+[result['selected_samples']]
    require(len(omitted)==5 and len({x['path'] for x in omitted})==5 and all(origin(x['path']).is_relative_to(run/'probe') and HEX.fullmatch(x['sha256']) and
        type(x['size_bytes']) is int and 0<x['size_bytes']<=65536 for x in omitted),'five tiny CPU tensor descriptors differ')
    return {'pure_tests':14,'pure_test_skips':0,'actual_tiny_probe_checks':29,'tiny_cpu_forward_calls':5,'runtime_source_aliases':aliases,
        'omitted_tiny_CPU_tensor_files':omitted,'production_model_loads':0,'production_model_forward_calls':0,'native_executions_started':0,
        'scope':'Tiny synthetic CPU nn.Module/dispatcher/BF16 proof, not Gemma execution, operator accuracy, or scheduler attestation.'}


def verify_portable(path,digest):
    path=Path(path);raw=original(path);require(sha(raw)==digest,'external actual CPU wrapper SHA differs');wrapper=parse(raw)
    require(wrapper['kind']=='observer-tiny-cpu-prerequisite-v1' and wrapper['native_prerequisite_valid'] is True and len(wrapper['files'])==24,
        'diagnostic/pending CPU evidence is not a native prerequisite')
    files={};origins={};refs={};seen=set()
    for name,item in wrapper['files'].items():
        require(set(item)=={'path','source_path','sha256','size_bytes'} and HEX.fullmatch(item['sha256']),'exact portable original ref required')
        source=path.parent.joinpath(*relative(item['path']).parts);require(source.resolve().is_relative_to(path.parent.resolve()) and item['path'] not in seen,'portable proof path escapes/aliases')
        body=original(source);require(sha(body)==item['sha256'] and len(body)==item['size_bytes'],'portable original bytes differ')
        files[name]=body;origins[name]=str(origin(item['source_path']));refs[name]={'path':str(source.resolve()),'sha256':sha(body),'size_bytes':len(body)};seen.add(item['path'])
    result=audit(files,origins);require(wrapper['summary']==result,'portable CPU summary differs from original checked bytes')
    require(sha(original(path))==digest,'actual CPU wrapper changed during verification')
    return {'document':wrapper,'refs':refs,'prerequisite_sha256':digest,'native_executions_started':0}


def export(root,output):
    require(os.name=='posix','original POSIX source root required');root=Path(root)
    require(root.is_dir() and not root.is_symlink(),'explicit existing original root required');root=root.resolve(strict=True);target=root/SUBDIR
    started=time.monotonic();old=signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('observer CPU export90s')));signal.setitimer(signal.ITIMER_REAL,90)
    try:
        candidates={'start':target/'cpu-start-once.json','attempt':target/'cpu-attempt-once.json','stage':target/'stage-receipt.json',
            'manifest':target/'source-manifest.json','validation_stdout':target/'cpu-validation.stdout','validation_stderr':target/'cpu-validation.stderr'}
        start=parse(original(candidates['start'],root));terminal_raw=original(candidates['validation_stdout'],root)
        try:terminal=parse(terminal_raw) if terminal_raw else None
        except (ValueError,json.JSONDecodeError):terminal=None
        if terminal is not None:
            controller=Path(terminal['receipt']['path']);require(controller.parent.parent==target/'runs','actual controller path escapes CPU task');run=controller.parent
        else:
            pid=Path('/proc')/str(start['pid'])/'stat'
            try:matching=int(pid.read_text().rpartition(')')[2].split()[19])==start['starttime']
            except FileNotFoundError:matching=False
            require(not matching,'CPU validation still running; no diagnostic snapshot yet')
            dirs=list((target/'runs').iterdir());require(len(dirs)==1 and dirs[0].is_dir() and not dirs[0].is_symlink(),'one actual CPU attempt run required');run=dirs[0]
        for name,suffix in {'controller_start':'controller-start.json','controller':'controller-receipt.json','tests_stdout':'tests.stdout','tests_stderr':'tests.stderr',
            'probe_stdout':'probe.stdout','probe_stderr':'probe.stderr','probe_receipt':'probe/receipt.json','runtime_map':'runtime-source-map.json'}.items():candidates[name]=run/suffix
        candidates.update({'code_'+name:target/'source'/value[0] for name,value in CODE.items()})
        candidates.update({'runtime_'+name:run/('runtime-sources/'+name+'.py') for name in RUNTIME})
        files={};origins={};total=0
        for name,path in candidates.items():
            if path.exists():
                raw=original(path,root);total+=len(raw);require(total<=MAX_RAW,'CPU metadata exceeds32MiB');files[name]=raw;origins[name]=str(path)
        valid=False;error=None
        try:summary=audit(files,origins);valid=True
        except (ValueError,KeyError,TypeError,IndexError) as exc:summary={'production_model_loads':0,'native_executions_started':0};error=str(exc)
        # A failed source/task produces only a clearly typed diagnostic archive.
        output=Path(output);require(output.is_absolute() and output.parent.is_dir() and output.resolve().is_relative_to((root/'exports').resolve()) and
            not output.exists() and not output.is_symlink(),'exclusive original-root exports directory required')
        output.mkdir(mode=0o700);proof=output/'proof';proof.mkdir();catalog={}
        for index,(name,body) in enumerate(sorted(files.items())):
            suffix='.py' if name.startswith(('code_','runtime_')) and name!='runtime_map' else '.json' if name not in {'tests_stdout','tests_stderr','probe_stderr','validation_stderr'} else '.txt'
            member='proof/%02d-%s%s'%(index,name,suffix);path=output/member
            with path.open('xb') as stream:stream.write(body)
            require(sha(original(Path(origins[name]),root))==sha(body),'original CPU metadata changed before copying')
            catalog[name]={'path':member,'source_path':origins[name],'sha256':sha(body),'size_bytes':len(body)}
        wrapper={'schema_version':1,'kind':'observer-tiny-cpu-prerequisite-v1' if valid else 'observer-cpu-failed-diagnostic-v1',
            'native_prerequisite_valid':valid,'files':catalog,'summary':summary,'diagnostic_reason':error,'native_execution_allowed_by_export':False,
            'production_model_loads':0,'native_executions_started':0,'acceptance':None}
        wrapper_path=output/'prerequisite.json';put(wrapper_path,wrapper)
        if valid:verify_portable(wrapper_path,sha(wrapper_path.read_bytes()))
        members={'prerequisite.json':{'sha256':sha(wrapper_path.read_bytes()),'size_bytes':wrapper_path.stat().st_size},
            **{item['path']:{'sha256':item['sha256'],'size_bytes':item['size_bytes']} for item in catalog.values()}}
        archive=output.with_name(output.name+'.tar.gz')
        with archive.open('xb') as stream,tarfile.open(fileobj=stream,mode='w:gz',format=tarfile.USTAR_FORMAT) as package:
            for name,item in sorted(members.items()):
                raw=(output/name).read_bytes();require(sha(raw)==item['sha256'],'copied CPU member changed');info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;package.addfile(info,io.BytesIO(raw))
        require(archive.stat().st_size<=MAX_GZIP,'CPU gzip exceeds16MiB')
        for name,raw in files.items():require(sha(original(Path(origins[name]),root))==sha(raw),'original CPU metadata changed during archive creation')
        raw=archive.read_bytes();envelope={'schema_version':1,'kind':'observer-tiny-cpu-proof-small-transport-v1','native_prerequisite_valid':valid,
            'prerequisite_sha256':sha(wrapper_path.read_bytes()),'archive':{'path':str(archive),'bytes':len(raw),'sha256':sha(raw),'base64':base64.b64encode(raw).decode()},
            'regular_members':len(members),'files':members,'production_model_loads':0,'native_executions_started':0,'production_native_arrays_read':0,
            'tiny_CPU_tensor_payloads_opened_or_copied':0,'acceptance':None}
        envelope_path=output.with_name(output.name+'-json-base64.txt');put(envelope_path,envelope);require(envelope_path.stat().st_size<=MAX_ENVELOPE,'CPU envelope exceeds24MiB')
        return {'status':'actual_observer_CPU_proof_exported' if valid else 'observer_CPU_diagnostic_exported_not_prerequisite','native_prerequisite_valid':valid,
            'wrapper_path':str(wrapper_path),'wrapper_sha256':envelope['prerequisite_sha256'],'archive':{k:v for k,v in envelope['archive'].items() if k!='base64'},
            'envelope':{'path':str(envelope_path),'bytes':envelope_path.stat().st_size,'sha256':sha(envelope_path.read_bytes())},'regular_members':len(members),
            'elapsed_seconds':time.monotonic()-started,'production_native_arrays_read':0,'tiny_CPU_tensor_payloads_opened_or_copied':0,
            'native_executions_started':0,'diagnostic_reason':error,'acceptance':None}
    finally:signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,old)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path);parser.add_argument('--output',type=Path)
    parser.add_argument('--verify-portable',type=Path);parser.add_argument('--sha256');args=parser.parse_args()
    if args.verify_portable:
        result=verify_portable(args.verify_portable,args.sha256);print(json.dumps({'status':'actual_observer_CPU_portable_proof_checked','documents':len(result['refs']),
            'prerequisite_sha256':result['prerequisite_sha256'],'native_executions_started':0},indent=2))
    else:
        require(args.root is not None and args.output is not None,'root and new output required');print(json.dumps(export(args.root,args.output),indent=2))


if __name__=='__main__':main()

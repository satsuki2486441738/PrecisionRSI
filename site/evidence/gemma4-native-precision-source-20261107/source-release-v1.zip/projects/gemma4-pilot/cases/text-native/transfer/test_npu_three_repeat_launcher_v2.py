"""CPU fixtures for launcher supervision; no accelerator or real model execution."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import textwrap
import time
import types
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('launcher', HERE / 'npu_three_repeat_launcher_v2.py')
m = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(m)
UUID = 'REDACTED_DEVICE_UUID'


class Base(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.root = Path(self.temp.name)
        self.a, self.mapping, self.source = [self.root / x for x in ('allocation.json', 'native-mapping.json', 'native-source.json')]
        m.put(self.a, {'vendor': 'Ascend', 'visible_count': 8, 'logical_ordinal': 0,
                      'allocation_id': 'fixture-notebook', 'physical_device_id': UUID, 'evidence_source': 'CPU fixture'})
        m.put(self.source, {'native_requested': True,
            'status': 'native_observations_recorded_needs_allocation_mapping_review', 'availability': {'visible_count': 8},
            'device': {'current_ordinal': 0, 'runtime_uuid': UUID},
            'cann_user_physical_mapping': {'ok': True, 'value': {'user_ordinal': 0, 'physical_device_id': 0,
                'forward_returncode': 0, 'reverse_returncode': 0, 'reverse_user_ordinal': 0}}})
        m.put(self.mapping, {'schema_version': 1, 'vendor': 'Ascend', 'allocation_id': 'fixture-notebook',
            'visible_count': 8, 'logical_ordinal': 0, 'device': 'npu:0', 'physical_device_id': UUID,
            'runtime_uuid': UUID, 'method': 'runtime_uuid',
            'source': {'source_path': str(self.source), 'file': {'path': self.source.name, 'sha256': m.sha(self.source)}}})
        self.args = argparse.Namespace(allocation=self.a, native_mapping=self.mapping, native_source=self.source)

    def tearDown(self):
        self.temp.cleanup()


class BindingTests(Base):
    def test_valid_frozen_uuid(self):
        self.assertEqual(m.binding(self.a, self.mapping, self.source)[1], UUID)

    def test_zero_uuid_rejected(self):
        a = m.read(self.a); a['physical_device_id'] = 'REDACTED_DEVICE_UUID'; m.put(self.a, a)
        with self.assertRaises(ValueError): m.binding(self.a, self.mapping, self.source)

    def test_changed_source_rejected(self):
        self.source.write_text('{}')
        with self.assertRaises(ValueError): m.binding(self.a, self.mapping, self.source)

    def test_wrong_ordinal_rejected(self):
        a = m.read(self.a); a['logical_ordinal'] = 1; m.put(self.a, a)
        with self.assertRaises(ValueError): m.binding(self.a, self.mapping, self.source)


class MemoryTests(Base):
    def fixture(self, group='/', host=200, limit='max', used=10):
        proc, cg = self.root / 'proc', self.root / 'cgroup'
        (proc / 'self').mkdir(parents=True); cg.mkdir()
        (proc / 'meminfo').write_text('MemAvailable: %d kB\n' % (host * 1024 ** 2))
        (proc / 'self/cgroup').write_text('0::' + group + '\n')
        mount_text=str(cg).replace(' ', r'\040')
        (proc / 'self/mountinfo').write_text('22 1 0:21 / '+mount_text+' rw - cgroup2 cgroup rw\n')
        (cg / 'memory.max').write_text(str(limit if limit == 'max' else limit * m.GIB))
        (cg / 'memory.current').write_text(str(used * m.GIB))
        return proc, cg

    def test_unlimited_cgroup_uses_observed_host(self):
        proc, cg = self.fixture()
        self.assertEqual(m.memory_observation(proc)['effective_available_bytes'], 200 * m.GIB)

    def test_nested_limit_is_honored(self):
        proc, cg = self.fixture(group='/nested', limit=200)
        (cg / 'nested').mkdir()
        (cg / 'nested/memory.max').write_text(str(100 * m.GIB))
        (cg / 'nested/memory.current').write_text(str(30 * m.GIB))
        self.assertEqual(m.memory_observation(proc)['effective_available_bytes'], 70 * m.GIB)

    def test_unresolved_membership_fails_closed(self):
        proc, cg = self.fixture(group='/missing')
        with self.assertRaises(RuntimeError): m.memory_observation(proc)

    def test_v1_nested_limits_are_not_ignored(self):
        proc, cg = self.root / 'proc', self.root / 'cgroup'
        (proc / 'self').mkdir(parents=True); (cg / 'memory/nested').mkdir(parents=True)
        (proc / 'meminfo').write_text('MemAvailable: %d kB\n' % (200 * 1024 ** 2))
        (proc / 'self/cgroup').write_text('4:memory:/nested\n')
        (proc / 'self/mountinfo').write_text('29 1 0:22 / '+str(cg / 'memory')+' rw - cgroup cgroup rw,memory\n')
        for base, limit, used in ((cg / 'memory', 200, 10), (cg / 'memory/nested', 100, 30)):
            (base / 'memory.limit_in_bytes').write_text(str(limit * m.GIB))
            (base / 'memory.usage_in_bytes').write_text(str(used * m.GIB))
        self.assertEqual(m.memory_observation(proc)['effective_available_bytes'], 70 * m.GIB)


class NativeGuardTests(Base):
    def modules(self, free=40 * m.GIB, uid=UUID, version='2.9.0+cpu'):
        torch = types.SimpleNamespace(__version__=version, get_float32_matmul_precision=lambda: 'highest',
                                      set_float32_matmul_precision=lambda x: None)
        npu = types.SimpleNamespace(is_available=lambda: True, device_count=lambda: 8, set_device=lambda n: None,
            current_device=lambda: 0, is_bf16_supported=lambda: True,
            get_device_properties=lambda n: types.SimpleNamespace(uuid=uid),
            mem_get_info=lambda n: (free, 64 * m.GIB), matmul=types.SimpleNamespace(allow_hf32=False),
            conv=types.SimpleNamespace(allow_hf32=True))
        return {'torch': torch, 'torch_npu': types.SimpleNamespace(__version__='2.9.0.post2', npu=npu),
                'transformers': types.SimpleNamespace(__version__='5.10.1')}

    def exercise(self, modules, memory=100 * m.GIB):
        with patch.dict(sys.modules, modules), patch.object(m, 'memory_observation', return_value={'effective_available_bytes': memory}):
            m.native_probe(self.args, self.root / 'probe.json')

    def test_native_guard_accepts_frozen_fixture(self):
        self.exercise(self.modules())
        self.assertEqual(m.read(self.root / 'probe.json')['runtime_uuid'], UUID)

    def test_gpu_memory_guard(self):
        with self.assertRaisesRegex(RuntimeError, '35GiB'): self.exercise(self.modules(free=34 * m.GIB))

    def test_host_memory_guard(self):
        with self.assertRaisesRegex(RuntimeError, '80GiB'): self.exercise(self.modules(), 79 * m.GIB)

    def test_native_uuid_guard(self):
        with self.assertRaisesRegex(RuntimeError, 'UUID'): self.exercise(self.modules(uid='REDACTED_DEVICE_UUID'))

    def test_stack_guard(self):
        with self.assertRaisesRegex(RuntimeError, '2.9.0'): self.exercise(self.modules(version='2.7.0'))


class MountRootRegressionTests(Base):
    ACTUAL = '/kubepods/burstable/pod3535c55b-8a87-4549-b07d-bc038ea13c09/648fb850def4283418e8a78c1b9f102ae04cebf415e5c67a4d9ac9c54e5d9358'

    def setup_proc(self, member, hierarchy='cgroup'):
        proc = self.root / 'proc'; (proc / 'self').mkdir(parents=True)
        (proc / 'meminfo').write_text('MemAvailable: %d kB\n' % (2000 * 1024 ** 2))
        (proc / 'self/cgroup').write_text(('5:memory:' if hierarchy == 'cgroup' else '0::') + member + '\n')
        return proc

    def values(self, base, limit, used, hierarchy='cgroup'):
        base.mkdir(parents=True, exist_ok=True)
        (base / ('memory.max' if hierarchy == 'cgroup2' else 'memory.limit_in_bytes')).write_text(str(limit))
        (base / ('memory.current' if hierarchy == 'cgroup2' else 'memory.usage_in_bytes')).write_text(str(used))

    def mount(self, root, point, hierarchy='cgroup'):
        escaped = str(point).replace(' ', r'\040')
        return '3966 3961 0:34 ' + root + ' ' + escaped + ' ro,nosuid,nodev,noexec,relatime master:9 - ' + hierarchy + ' cgroup rw' + (',memory' if hierarchy == 'cgroup' else '') + '\n'

    def test_actual_npu_root_equals_member(self):
        proc = self.setup_proc(self.ACTUAL)
        point = self.root / 'memory'
        self.values(point, 962072674304, 15110914048)
        (proc / 'self/mountinfo').write_text(self.mount(self.ACTUAL, point))
        result = m.memory_observation(proc)
        self.assertEqual(result['effective_available_bytes'], 962072674304 - 15110914048)
        self.assertGreaterEqual(result['effective_available_bytes'], 80 * m.GIB)
        self.assertEqual(result['cgroup_mappings'][0]['resolved_leaf'], str(point))

    def test_v1_bind_root_with_nested_member(self):
        proc = self.setup_proc('/pod/child'); point = self.root / 'memory'
        self.values(point, 150 * m.GIB, 10 * m.GIB)
        self.values(point / 'child', 100 * m.GIB, 30 * m.GIB)
        (proc / 'self/mountinfo').write_text(self.mount('/pod', point))
        self.assertEqual(m.memory_observation(proc)['effective_available_bytes'], 70 * m.GIB)

    def test_v2_bind_root_equals_member(self):
        proc = self.setup_proc('/pod/container', 'cgroup2'); point = self.root / 'unified'
        self.values(point, 100 * m.GIB, 10 * m.GIB, 'cgroup2')
        (proc / 'self/mountinfo').write_text(self.mount('/pod/container', point, 'cgroup2'))
        self.assertEqual(m.memory_observation(proc)['effective_available_bytes'], 90 * m.GIB)

    def test_all_exposed_views_include_stricter_ancestor(self):
        proc = self.setup_proc('/pod/leaf'); full, narrow = self.root / 'full', self.root / 'narrow'
        self.values(full, 200 * m.GIB, 10 * m.GIB)
        self.values(full / 'pod', 60 * m.GIB, 10 * m.GIB)
        self.values(full / 'pod/leaf', 100 * m.GIB, 10 * m.GIB)
        self.values(narrow, 100 * m.GIB, 10 * m.GIB)
        (proc / 'self/mountinfo').write_text(self.mount('/', full) + self.mount('/pod/leaf', narrow))
        result = m.memory_observation(proc)
        self.assertEqual(result['effective_available_bytes'], 50 * m.GIB)
        self.assertEqual(len(result['cgroup_mappings']), 2)

    def test_octal_root_and_mountpoint_spaces(self):
        proc = self.setup_proc('/tenant space/leaf'); point = self.root / 'memory space'
        self.values(point, 150 * m.GIB, 10 * m.GIB)
        self.values(point / 'leaf', 100 * m.GIB, 30 * m.GIB)
        (proc / 'self/mountinfo').write_text(self.mount(r'/tenant\040space', point))
        self.assertEqual(m.memory_observation(proc)['effective_available_bytes'], 70 * m.GIB)

    def test_wrong_root_rejected(self):
        proc = self.setup_proc('/pod/leaf'); point = self.root / 'memory'; self.values(point, 100 * m.GIB, 0)
        (proc / 'self/mountinfo').write_text(self.mount('/another', point))
        with self.assertRaisesRegex(RuntimeError, 'outside'): m.memory_observation(proc)

    def test_missing_current_rejected(self):
        proc = self.setup_proc('/pod'); point = self.root / 'memory'; self.values(point, 100 * m.GIB, 0)
        (point / 'memory.usage_in_bytes').unlink()
        (proc / 'self/mountinfo').write_text(self.mount('/pod', point))
        with self.assertRaisesRegex(RuntimeError, 'not both exposed'): m.memory_observation(proc)

    def test_negative_current_rejected(self):
        proc = self.setup_proc('/pod'); point = self.root / 'memory'; self.values(point, 100 * m.GIB, -1)
        (proc / 'self/mountinfo').write_text(self.mount('/pod', point))
        with self.assertRaises(ValueError): m.memory_observation(proc)

    def test_namespace_parent_escape_rejected(self):
        proc = self.setup_proc('/../pod'); point = self.root / 'memory'; self.values(point, 100 * m.GIB, 0)
        (proc / 'self/mountinfo').write_text(self.mount('/', point))
        with self.assertRaises(RuntimeError): m.memory_observation(proc)


@unittest.skipUnless(sys.platform.startswith('linux'), 'real Linux /proc/subreaper test')
class LifecycleTests(Base):
    def fixture(self, behaviour='success'):
        task = self.root / 'task'; task.mkdir(); (task / 'model').mkdir()
        collector_root = task / 'collector'; collector_root.mkdir()
        paths = {}
        real_recorder = HERE.parent / 'adapters/record_execution_v2.py'
        real_input = HERE.parent / 'inputs/discovery-v1/wikitext2-discovery-001.json'
        child_code = "import os,signal,time; signal.signal(signal.SIGTERM,signal.SIG_IGN); open(os.environ['FIXTURE_PIDLOG'],'a').write(str(os.getpid())+'\\n'); time.sleep(3600)"
        nested_code = "import os,signal,subprocess,sys,time; signal.signal(signal.SIGTERM,signal.SIG_IGN); open(os.environ['FIXTURE_PIDLOG'],'a').write(str(os.getpid())+'\\n'); subprocess.Popen([sys.executable,'-c'," + repr(child_code) + "],start_new_session=True); time.sleep(3600)"
        collector = textwrap.dedent('''
            import argparse,json,os,subprocess,sys,time
            from pathlib import Path
            p=argparse.ArgumentParser();p.add_argument('--input');p.add_argument('--output');a,_=p.parse_known_args()
            open(os.environ['FIXTURE_PIDLOG'],'a').write(str(os.getpid())+'\\n')
            if os.environ['FIXTURE_BEHAVIOUR']=='fail': raise SystemExit(7)
            if os.environ['FIXTURE_BEHAVIOUR']=='hang':
                subprocess.Popen([sys.executable,'-c',NESTED],start_new_session=True)
                time.sleep(3600)
            out=Path(a.output);out.mkdir(); data=json.load(open(a.input))
            for name in ('runtime.json','policy-after-load.json','policy-after-capture.json','snapshot-verification.json'):
                (out/name).write_text('{}')
            (out/'status.json').write_text(json.dumps({'status':'completed','rank':0}))
            for i,token in enumerate(data['continuation']):
                (out/('row-%03d.npy'%i)).write_bytes(b'CPU fixture; not a real array')
                (out/('row-%03d.json'%i)).write_text(json.dumps({'step':i,'token':token,'scores':{'path':'row-%03d.npy'%i,'row':0}}))
        ''').replace('NESTED', repr(nested_code))
        for rel in m.PINNED:
            path = collector_root / rel; path.parent.mkdir(parents=True, exist_ok=True)
            if rel == m.COLLECTOR:
                path.write_text(collector)
            elif rel == m.RECORDER:
                path.write_bytes(real_recorder.read_bytes())
            elif rel == m.INPUT:
                path.write_bytes(real_input.read_bytes())
            else:
                path.write_text('# CPU fixture dependency\n')
            paths[rel] = m.sha(path)
        wrapper = self.root / 'fixture_launcher.py'
        wrapper.write_text('import sys,json\nfrom pathlib import Path\nsys.path.insert(0,' + repr(str(HERE)) + ')\n'
            'import npu_three_repeat_launcher_v2 as m\n'
            'm.PINNED=' + repr(paths) + '\n'
            'def fake_probe(args,output):\n m.put(output,{"status":"preflight_passed","scope":"CPU fixture only"})\n'
            'm.native_probe=fake_probe\nm.__file__=__file__\nraise SystemExit(m.main())\n')
        argv = [sys.executable, '-B', str(wrapper), '--task-root', str(task), '--model', str(task / 'model'),
                '--allocation', str(self.a), '--native-mapping', str(self.mapping), '--native-source', str(self.source)]
        env = {**os.environ, 'PYTHONHASHSEED': '0', 'FIXTURE_BEHAVIOUR': behaviour,
               'FIXTURE_PIDLOG': str(self.root / 'pids.txt')}
        return task, argv, env

    def assert_pids_gone(self):
        ids = (self.root / 'pids.txt').read_text().splitlines()
        self.assertGreaterEqual(len(ids), 1)
        for pid in ids:
            self.assertFalse(Path('/proc', pid).exists(), 'task process leaked: ' + pid)

    def test_three_serial_success_uses_real_recorder(self):
        task, argv, env = self.fixture()
        r = subprocess.run(argv, env=env, capture_output=True, text=True, timeout=30)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        batch = next((task / 'runs').iterdir()); status = m.read(batch / 'status.json')
        self.assertEqual(status['status'], 'completed')
        self.assertEqual(len(status['runs']), 3)
        for run in status['runs']:
            receipt = m.read(Path(run['root']) / 'recorder/receipt.json')
            self.assertEqual(receipt['status'], 'completed')
            self.assertIn('--allocation-receipt', receipt['argv'])
            self.assertEqual(receipt['timeout_seconds'], 1800)
        self.assert_pids_gone()

    def test_failure_stops_remaining_rounds(self):
        task, argv, env = self.fixture('fail')
        r = subprocess.run(argv, env=env, capture_output=True, text=True, timeout=30)
        self.assertNotEqual(r.returncode, 0)
        batch = next((task / 'runs').iterdir()); status = m.read(batch / 'status.json')
        self.assertEqual(status['status'], 'failed')
        self.assertEqual(len(list(batch.glob('npu-inference-r*'))), 1)
        self.assert_pids_gone()

    def test_term_cleans_nested_escaped_sessions(self):
        task, argv, env = self.fixture('hang')
        proc = subprocess.Popen(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            end = time.monotonic() + 10
            while time.monotonic() < end:
                pids = self.root / 'pids.txt'
                if pids.exists() and len(pids.read_text().splitlines()) >= 3:
                    break
                time.sleep(.05)
            else:
                self.fail('nested fixture processes did not start')
            proc.send_signal(signal.SIGTERM)
            out, err = proc.communicate(timeout=20)
            self.assertNotEqual(proc.returncode, 0, out + err)
            status = m.read(next((task / 'runs').iterdir()) / 'status.json')
            self.assertEqual(status['status'], 'interrupted', out + err)
            self.assertEqual(status['remaining_descendants'], [])
            self.assert_pids_gone()
        finally:
            if proc.poll() is None:
                proc.kill(); proc.wait()

    def test_concurrent_reentry_lock_is_rejected(self):
        import fcntl
        task, argv, env = self.fixture()
        with (task / 'npu-repeat-launch.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            r = subprocess.run(argv, env=env, capture_output=True, text=True, timeout=10)
        self.assertNotEqual(r.returncode, 0)
        self.assertFalse((task / 'runs').exists())


if __name__ == '__main__':
    unittest.main()

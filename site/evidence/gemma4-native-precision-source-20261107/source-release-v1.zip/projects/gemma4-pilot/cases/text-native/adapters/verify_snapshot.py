"""Verify a pinned Gemma 4 snapshot against retained Hugging Face blob metadata.

This checks snapshot bytes, not what a runtime actually loaded. Retain a separate
runtime/loading/module receipt and compare both peers before pairing results.
"""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

REPOSITORY = 'google/gemma-4-12B'
REVISION = '1a2c7729392586f5ecddae8807ee2ef741eabb9a'
REQUIRED = {'.gitattributes', 'README.md', 'config.json', 'generation_config.json',
            'model.safetensors', 'processor_config.json', 'tokenizer.json',
            'tokenizer_config.json'}


def verify(snapshot, metadata):
    snapshot = Path(snapshot)
    if not snapshot.is_dir():
        raise ValueError('snapshot must be an existing directory')
    if metadata.get('repository') != REPOSITORY or metadata.get('revision') != REVISION:
        raise ValueError('unexpected upstream repository or immutable revision')
    files = metadata.get('files')
    if not isinstance(files, list) or any(not isinstance(x, dict) for x in files):
        raise ValueError('invalid upstream file metadata')
    names = [x.get('rfilename') for x in files]
    if len(names) != len(set(names)) or set(names) != REQUIRED:
        raise ValueError('unexpected or duplicate upstream file inventory')
    results = []
    for entry in files:
        name = entry['rfilename']
        expected_size = entry.get('size')
        if type(expected_size) is not int or expected_size < 0:
            raise ValueError('invalid upstream size: ' + name)
        expected = entry.get('lfs', {}).get('sha256') if 'lfs' in entry else entry.get('blobId')
        algorithm = 'sha256' if 'lfs' in entry else 'git-blob-sha1'
        if not isinstance(expected, str) or len(expected) != (64 if algorithm == 'sha256' else 40):
            raise ValueError('invalid upstream digest: ' + name)
        path = snapshot / name
        result = {'file': name, 'expected_size': expected_size,
                  'expected_algorithm': algorithm, 'expected_digest': expected}
        try:
            size = path.stat().st_size
            sha256 = hashlib.sha256()
            git_blob = hashlib.sha1(('blob %d\0' % size).encode('ascii'))
            with path.open('rb') as f:
                while True:
                    chunk = f.read(8 * 1024 * 1024)
                    if not chunk:
                        break
                    sha256.update(chunk)
                    git_blob.update(chunk)
            digest = sha256.hexdigest() if algorithm == 'sha256' else git_blob.hexdigest()
            result.update(actual_size=size, actual_sha256=sha256.hexdigest(),
                          actual_expected_algorithm_digest=digest,
                          verified=(size == expected_size and digest == expected))
        except OSError as exc:
            result.update(verified=False, error=type(exc).__name__ + ': ' + str(exc))
        results.append(result)
    return {'repository':REPOSITORY, 'revision':REVISION, 'snapshot':str(snapshot.resolve()),
            'checked_utc':datetime.now(timezone.utc).isoformat(),
            'status':'verified' if all(x['verified'] for x in results) else 'failed',
            'scope':'Snapshot files only. Runtime-loaded identity and module inventory require separate evidence.',
            'files':results}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--snapshot', required=True, type=Path)
    parser.add_argument('--metadata', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path, help='New receipt path')
    args = parser.parse_args()
    metadata_bytes = args.metadata.read_bytes()
    result = verify(args.snapshot, json.loads(metadata_bytes))
    result['upstream_metadata_sha256'] = hashlib.sha256(metadata_bytes).hexdigest()
    with args.output.open('x', encoding='utf-8') as f:
        json.dump(result, f, indent=2, allow_nan=False)
        f.write('\n')
    print(json.dumps({'status':result['status'], 'receipt':str(args.output),
                      'files':len(result['files'])}))
    return 0 if result['status'] == 'verified' else 1


if __name__ == '__main__':
    raise SystemExit(main())

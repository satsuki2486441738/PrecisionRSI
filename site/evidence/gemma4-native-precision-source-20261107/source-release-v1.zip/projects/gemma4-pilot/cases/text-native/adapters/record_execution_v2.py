r"""Linux-only external recorder for one fixed-history GPU or NPU collector.

Example: python -B record_execution_v2.py --collector /case/adapters/pilot_ascend_candidate.py \
  --input /case/input.json --capture-output /case/new-capture --receipt-dir /case/new-receipt \
  --backend NPU --timeout 3600 \
  --dependency /case/adapters/pilot_gpu_peer_v2.py --dependency /case/adapters/verify_snapshot.py \
  --dependency /case/adapters/upstream-identity.json \
  --dependency /repo/skills/precision-compare/scripts/inference_capture.py \
  --dependency /repo/skills/precision-compare/scripts/artifact_io.py \
  --dependency /repo/skills/precision-compare/scripts/compare_distributions.py \
  --dependency /repo/skills/precision-compare/scripts/conditions.py \
  -- --model /snapshot --allocation-receipt /case/allocation.json --device npu:0

The receipt records observed subprocess exit status and hashes, not physical
device identity, actual loaded weights, trusted execution, or numerical accuracy.
Output is always private. Only a completed, intact capture produces schema v2.
The caller must freeze/check collector and all transitive dependencies separately;
listed file names and hashes alone cannot prove actual dynamic import paths or a
complete dependency closure.
Process cleanup applies to the spawned process group, not descendants that escape
the group; use a scheduler/cgroup for a stronger lifecycle boundary.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def stamp():
    return datetime.now(timezone.utc).isoformat()


def write_new(path, document):
    with path.open('x', encoding='utf-8') as f:
        json.dump(document, f, allow_nan=False, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


def terminate_group(proc):
    # Group may still contain grandchildren when the direct child has exited.
    try:
        os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    deadline = time.monotonic() + 3
    while time.monotonic() < deadline:
        try:
            os.killpg(proc.pid, 0)
        except ProcessLookupError:
            return
        time.sleep(.05)
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


class Interrupted(Exception):
    pass


REQUIRED_DEPENDENCIES = {
    'GPU': {'inference_capture.py', 'artifact_io.py', 'compare_distributions.py', 'conditions.py'},
    'NPU': {'pilot_gpu_peer_v2.py', 'verify_snapshot.py', 'upstream-identity.json',
            'inference_capture.py', 'artifact_io.py', 'compare_distributions.py', 'conditions.py'},
}
POLICIES = {'GPU': ('math-policy-after-load.json', 'math-policy-after.json'),
            'NPU': ('policy-after-load.json', 'policy-after-capture.json')}


def run(collector, input_path, output, receipt_dir, timeout, extra, dependencies=(), backend=None):
    if os.name != 'posix':
        raise RuntimeError('recorder requires POSIX process groups; no process started')
    collector, input_path = Path(collector).resolve(strict=True), Path(input_path).resolve(strict=True)
    output, receipt_dir = Path(output).absolute(), Path(receipt_dir).absolute()
    dependencies = [Path(p).resolve(strict=True) for p in dependencies]
    if backend not in REQUIRED_DEPENDENCIES:
        raise ValueError('explicit GPU or NPU backend required')
    dep_names = [p.name for p in dependencies]
    if len(set(dep_names)) != len(dep_names) or not REQUIRED_DEPENDENCIES[backend].issubset(dep_names):
        raise ValueError('required named collector dependencies missing or ambiguous')
    if not collector.is_file() or collector.suffix != '.py' or not input_path.is_file():
        raise ValueError('collector must be a Python file and input must be a file')
    if type(timeout) is not int or not 1 <= timeout <= 14400:
        raise ValueError('timeout must be from 1 to 14400 seconds')
    if output.exists() or receipt_dir.exists() or output == receipt_dir or receipt_dir.is_relative_to(output):
        raise FileExistsError('capture output and receipt directory must be distinct and new')
    if any(not isinstance(x, str) or not x for x in extra) or any(
            x in ('--input', '--output') or x.startswith(('--input=', '--output=')) for x in extra):
        raise ValueError('input and output arguments are controlled by recorder')
    data = json.loads(input_path.read_text(encoding='utf-8'))
    continuation = data.get('continuation')
    if not isinstance(continuation, list) or not continuation or not all(type(v) is int and v >= 0 for v in continuation):
        raise ValueError('invalid frozen continuation')
    source_paths = [collector, input_path] + dependencies
    if len(set(source_paths)) != len(source_paths) or not all(p.is_file() for p in source_paths):
        raise ValueError('duplicate or invalid source/dependency')
    source_hashes = {str(p): digest(p) for p in source_paths}
    argv = [sys.executable, '-B', str(collector), '--input', str(input_path), '--output', str(output), *extra]
    receipt_dir.mkdir(parents=False, exist_ok=False)
    started, proc, old_handlers = stamp(), None, {}
    result = {'schema_version': 2, 'status': 'not_started', 'argv': argv,
              'started_utc': started, 'collector_sha256': source_hashes[str(collector)],
              'input_sha256': source_hashes[str(input_path)], 'source_sha256': source_hashes,
              'backend': backend, 'collector_path': str(collector), 'input_path': str(input_path),
              'dependency_paths': [str(p) for p in dependencies],
              'capture_output': str(output), 'timeout_seconds': timeout,
              'limitations': ['subprocess and hashes are observations by this recorder, not independent attestation',
                  'descendants escaping the process group require scheduler/cgroup cleanup',
                  'physical device, runtime-loaded bytes and imported dependency closure are not proven']}

    def interrupt(signum, _frame):
        raise Interrupted('received signal ' + str(signum))
    try:
        for signum in (signal.SIGTERM, signal.SIGINT):
            old_handlers[signum] = signal.signal(signum, interrupt)
        with (receipt_dir/'stdout.log').open('xb') as stdout, (receipt_dir/'stderr.log').open('xb') as stderr:
            proc = subprocess.Popen(argv, stdout=stdout, stderr=stderr, start_new_session=True)
            result.update(status='running', child_pid=proc.pid)
            try:
                code = proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                result.update(status='timed_out', reason='collector exceeded timeout')
                terminate_group(proc)
                proc.wait()
                result['returncode'] = proc.returncode
            else:
                result['returncode'] = code
                terminate_group(proc)
                if code != 0:
                    result.update(status='failed', reason='collector exited nonzero')
                else:
                    if any(digest(Path(p)) != h for p, h in source_hashes.items()):
                        raise ValueError('collector, input, or pinned dependency changed during execution')
                    status = json.loads((output/'status.json').read_text(encoding='utf-8'))
                    if status.get('status') != 'completed' or status.get('rank') != 0:
                        raise ValueError('collector completion evidence missing')
                    names = ['runtime.json', *POLICIES[backend]]
                    if backend == 'NPU':
                        names.append('snapshot-verification.json')
                    native_hashes = {}
                    for name in names:
                        native_path = output/name
                        if not isinstance(json.loads(native_path.read_text(encoding='utf-8')), dict):
                            raise ValueError('native runtime/policy evidence must be a JSON object')
                        native_hashes[name] = digest(native_path)
                    records = [output/f'row-{i:03d}.json' for i in range(len(continuation))]
                    rows = [output/f'row-{i:03d}.npy' for i in range(len(continuation))]
                    if set(output.glob('row-*.json')) != set(records) or set(output.glob('row-*.npy')) != set(rows):
                        raise ValueError('capture row inventory incomplete or has extra rows')
                    for i, record_path in enumerate(records):
                        record = json.loads(record_path.read_text(encoding='utf-8'))
                        if (record.get('step') != i or record.get('token') != continuation[i] or
                                record.get('scores') != {'path': rows[i].name, 'row': 0}):
                            raise ValueError('capture record and array mapping differ')
                    result.update(status='completed', record_sha256=[digest(p) for p in records],
                                  row_sha256=[digest(p) for p in rows], status_sha256=digest(output/'status.json'),
                                  native_evidence_sha256=native_hashes)
    except Interrupted as exc:
        result.update(status='interrupted', reason=str(exc))
        if proc is not None:
            terminate_group(proc)
            proc.wait()
            result['returncode'] = proc.returncode
    except (OSError, ValueError, KeyError, TypeError) as exc:
        if proc is not None:
            terminate_group(proc)
            proc.wait()
            result['returncode'] = proc.returncode
        result.update(status='failed' if proc is not None else 'not_started', reason=str(exc))
    finally:
        for signum, old in old_handlers.items():
            signal.signal(signum, old)
        result['finished_utc'] = stamp()
        write_new(receipt_dir/'receipt.json', result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--collector', required=True, type=Path)
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--capture-output', required=True, type=Path)
    parser.add_argument('--receipt-dir', required=True, type=Path)
    parser.add_argument('--timeout', required=True, type=int)
    parser.add_argument('--backend', required=True, choices=['GPU', 'NPU'])
    parser.add_argument('--dependency', action='append', type=Path, default=[])
    parser.add_argument('collector_args', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    extra = args.collector_args
    if extra and extra[0] == '--':
        extra = extra[1:]
    result = run(args.collector, args.input, args.capture_output, args.receipt_dir,
                 args.timeout, extra, args.dependency, args.backend)
    return 0 if result['status'] == 'completed' else 1


if __name__ == '__main__':
    raise SystemExit(main())

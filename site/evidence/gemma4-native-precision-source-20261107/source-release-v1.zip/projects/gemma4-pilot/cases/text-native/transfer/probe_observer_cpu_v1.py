"""Bounded tiny real-Torch CPU hook/dispatcher transparency prerequisite.

The four calls use a tiny synthetic nn.Module, never Gemma/model weights or an
accelerator. Backend module imports are recorded separately from context state.
No hardware/availability query is explicitly requested by this program.
"""
import argparse
from contextlib import nullcontext
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import signal
import struct
import sys
import time
import traceback


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ref(path):
    path=Path(path);require(path.is_file() and not path.is_symlink(),'regular original CPU source required')
    return {'path':str(path.resolve()),'sha256':sha(path),'size_bytes':path.stat().st_size}


def flags(torch,phase):
    namespace=getattr(torch,'npu',None)
    result={'phase':phase,'torch_npu_imported':'torch_npu' in sys.modules,
        'npu_namespace_registered':namespace is not None,'npu_initialized':None if namespace is None else bool(namespace.is_initialized()),
        'cuda_initialized':bool(torch.cuda.is_initialized())}
    require(result['npu_initialized'] in (None,False) and result['cuda_initialized'] is False,'CPU probe found initialized accelerator context')
    return result


def numpy_state_digest(np,state=None):
    algorithm,words,position,has_gauss,cached=np.random.get_state() if state is None else state
    header={'algorithm':algorithm,'word_count':int(words.size),'word_encoding':'uint32-little-endian',
        'position':int(position),'has_gauss':int(has_gauss),'cached_gaussian_binary64_le_hex':struct.pack('<d',float(cached)).hex()}
    raw=json.dumps(header,sort_keys=True,separators=(',',':'),allow_nan=False).encode()+b'\0'+words.astype('<u4',copy=False).tobytes()
    return hashlib.sha256(raw).hexdigest()


def run_checks(torch,np,safetensors,collector,output):
    """Real CPU tensors with an intentional in-place boundary mutation."""
    checks=[]
    def check(ok,name):require(bool(ok),name);checks.append(name)
    class Embedding(torch.nn.Module):
        def __init__(self):
            super().__init__();self.weight=torch.nn.Parameter(torch.arange(80,dtype=torch.float32).reshape(10,8).to(torch.bfloat16),requires_grad=False)
        def forward(self,ids):return self.weight[ids]*2
    class Block(torch.nn.Module):
        def forward(self,hidden_states):hidden_states.add_(1);return hidden_states*3
    class Norm(torch.nn.Module):
        def forward(self,hidden_states):hidden_states.sub_(2);return hidden_states
    class Tiny(torch.nn.Module):
        def __init__(self):
            super().__init__();self.embedding=Embedding();self.block=Block();self.norm=Norm();self.unused=torch.nn.Identity()
        def forward(self,ids):return self.norm(self.block(self.embedding(ids)))
    model=Tiny().eval();ids=torch.tensor([[0,1,2,3]],dtype=torch.long,device='cpu')
    specs=collector.boundary_specs(1,prefix='block',embedding='embedding',norm='norm')
    # Tiny's single block has no numeric suffix; keep the production boundary IDs.
    specs[1]['module']=specs[2]['module']='block'
    tokens,channels=[0,3],[0,7];modes=['off-before','hooks-only','off-after','hooks-plus-dispatch-metadata']
    external=model.block.register_forward_hook(lambda *_:None)
    registry=collector.hook_registry(list(model.named_modules(remove_duplicate=False)))
    baseline=model.embedding.weight.detach().clone();parameter_version=model.embedding.weight._version
    expected_embedding=model.embedding.weight[ids]*2
    expected_output=(expected_embedding+1)*3-2
    selected=lambda value:value[:,tokens,:][:,:,channels].contiguous().clone()
    bitbytes=lambda value:value.detach().cpu().contiguous().view(torch.uint16).numpy().tobytes()
    cpu_state=lambda:hashlib.sha256(torch.get_rng_state().numpy().tobytes()).hexdigest()
    np_state=lambda:numpy_state_digest(np)
    rng_before=(repr(random.getstate()),np_state(),cpu_state());outputs=[];observed=[];sample_buffers={}
    from safetensors.torch import load_file,save_file
    with torch.inference_mode():
        for mode in modes:
            enabled=mode in (modes[1],modes[3]);dispatch=mode==modes[3]
            observer=collector.Observer(model,torch,'cpu',specs=specs,tokens=tokens,channels=channels,hidden_shape=(1,4,8)) if enabled else None
            with observer if enabled else nullcontext():
                with observer.dispatch_mode() if dispatch else nullcontext():actual=model(ids)
            check(bitbytes(actual)==bitbytes(expected_output),mode+': exact output despite in-place block/norm')
            check(collector.hook_registry(list(model.named_modules(remove_duplicate=False)))==registry,mode+': original external hook registries restored')
            saved=output/(mode+'.safetensors');save_file({'logits':actual.detach().cpu().contiguous().clone()},str(saved))
            check(bitbytes(load_file(str(saved),device='cpu')['logits'])==bitbytes(actual),mode+': native BF16 serialization bitwise')
            outputs.append({'mode':mode,'raw_bits_sha256':hashlib.sha256(bitbytes(actual)).hexdigest(),'artifact':ref(saved)})
            if observer is not None:
                report=observer.report(dispatch);observed.append(report)
                check(report['boundary_counts']=={x['id']:1 for x in specs} and [x['id'] for x in report['boundary_events']]==[x['id'] for x in specs],mode+': four exact ordered boundary snapshots')
                check(report['actual_module_count']==5 and report['zero_fired_modules']==['unused'] and all(x['invocations']==x['completed_invocations'] for x in report['module_invocations']),mode+': actual invocation and zero-fired census')
                expected_samples={'embedding.scaled.output':selected(expected_embedding),'block.00.input':selected(expected_embedding),
                    'block.00.output':selected((expected_embedding+1)*3),'norm.final.output':selected(expected_output)}
                check(all(bitbytes(observer.samples[key])==bitbytes(value) for key,value in expected_samples.items()),mode+': pre-mutation snapshots preserved')
                check(len({x.untyped_storage().data_ptr() for x in observer.samples.values()})==4,mode+': four independent sample storages')
                sample_buffers.update({mode+'/'+key:value.detach().cpu().contiguous().clone() for key,value in observer.samples.items()})
                if dispatch:
                    check(report['dispatcher']['observed_invocations']>0 and sum(x['count'] for x in report['dispatcher']['signatures'])==report['dispatcher']['observed_invocations'],mode+': dispatcher count/signature closure')
                    check(sum(report['dispatcher']['collector_generated_excluded_operations'].values())>0,mode+': collector operations excluded by scoped guard')
    check(len({x['raw_bits_sha256'] for x in outputs})==1,'all four tiny control outputs bitwise equal')
    check(rng_before==(repr(random.getstate()),np_state(),cpu_state()),'full CPU/Python/NumPy RNG states unchanged')
    check(torch.equal(model.embedding.weight,baseline) and model.embedding.weight._version==parameter_version,'loaded tiny parameter values/version unchanged')
    # Same overload is observed outside the guard and excluded inside it. There
    # is no global operator-name filter that could hide a model's clone calls.
    direct=collector.Observer(model,torch,'cpu',specs=specs,tokens=tokens,channels=channels,hidden_shape=(1,4,8))
    with direct.dispatch_mode():
        native_clone=expected_output.clone()
        with direct.collector_guard():guarded_clone=expected_output.clone()
    check(direct.dispatch_calls==1 and sum(direct.excluded_calls.values())==1 and bitbytes(native_clone)==bitbytes(guarded_clone),
        'same clone overload distinguished by collector guard scope')
    # Actual module exception must not leave any collector hook installed.
    throwing=collector.Observer(model,torch,'cpu',specs=specs,tokens=tokens,channels=channels,hidden_shape=(1,4,8))
    def boom(*_):raise RuntimeError('intentional tiny CPU failure')
    old=model.block.forward;model.block.forward=boom
    try:
        try:
            with throwing:model(ids)
        except RuntimeError as exc:check(str(exc)=='intentional tiny CPU failure','original tiny exception preserved')
        else:raise ValueError('intentional module exception was swallowed')
    finally:model.block.forward=old
    check(throwing.status=='incomplete' and collector.hook_registry(list(model.named_modules(remove_duplicate=False)))==registry,
        'actual exception removed every owned hook')
    samples=output/'boundary-samples.safetensors';save_file(sample_buffers,str(samples));loaded=load_file(str(samples),device='cpu')
    check(len(loaded)==8 and all(bitbytes(loaded[k])==bitbytes(v) for k,v in sample_buffers.items()),'eight BF16 selected samples serialize bitwise')
    external.remove()
    return {'checks':checks,'checks_passed':len(checks),'tiny_cpu_forward_calls':5,'production_model_loads':0,'production_model_forward_calls':0,
        'production_boundary_count':98,'tiny_boundary_count':4,'tiny_module_count':5,'mode_outputs':outputs,
        'observations':observed,'selected_samples':ref(samples),'scope':'Tiny synthetic CPU nn.Module evidence; no Gemma/native backend execution.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--collectors',type=Path,required=True)
    parser.add_argument('--collectors-sha256',required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    require('torch' not in sys.modules and 'torch_npu' not in sys.modules,'fresh CPU prerequisite process required')
    require(args.collectors.is_file() and sha(args.collectors)==args.collectors_sha256,'frozen collector source SHA differs')
    require(args.output.parent.is_dir() and not args.output.exists() and not args.output.is_symlink(),'exclusive new CPU probe output required')
    require(sys.platform.startswith('linux'),'bounded POSIX CPU probe required')
    os.environ['TORCH_DEVICE_BACKEND_AUTOLOAD']='0';args.output.mkdir(mode=0o700);started=time.monotonic()
    state={'schema_version':1,'task':'observer-tiny-cpu-prerequisite-v1','status':'running','started_utc':datetime.now(timezone.utc).isoformat(),
        'timeout_seconds':90,'source':ref(__file__),'collectors_source':ref(args.collectors),'acceptance':None,
        'production_model_loads':0,'production_model_forward_calls':0,'agent_hardware_or_availability_queries':0,
        'agent_accelerator_initialization_requests':0,'library_internal_availability_queries':'not instrumented'}
    def expire(*_):raise TimeoutError('tiny observer CPU prerequisite90s')
    previous=signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,90)
    try:
        import torch
        phases=[flags(torch,'after_torch')]
        import numpy as np
        import safetensors
        require(torch.__version__.split('+')[0]=='2.9.0' and torch.version.cuda is None,'exact native CPU Torch2.9.0 build required')
        spec=importlib.util.spec_from_file_location('actual_observer_collectors',args.collectors);collector=importlib.util.module_from_spec(spec);spec.loader.exec_module(collector)
        phases.append(flags(torch,'before_tiny_cpu_calls'));result=run_checks(torch,np,safetensors,collector,args.output)
        phases.append(flags(torch,'after_tiny_cpu_calls'))
        import torch.utils._python_dispatch as dispatch
        import torch.nn.modules.module as module_hooks
        state.update(status='completed',returncode=0,versions={'torch':torch.__version__,'numpy':np.__version__,'safetensors':safetensors.__version__},
            phase_observations=phases,result=result,runtime_sources={'torch':ref(torch.__file__),'numpy':ref(np.__file__),
                'safetensors':ref(safetensors.__file__),'torch_dispatch':ref(dispatch.__file__),'module_hooks':ref(module_hooks.__file__)})
        require(sha(args.collectors)==args.collectors_sha256,'collector source changed during actual CPU probe')
    except BaseException as exc:state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc())
    finally:
        signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)
        state.update(finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started)
        with (args.output/'receipt.json').open('x',encoding='utf-8') as stream:json.dump(state,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'status':state['status'],'receipt':str(args.output/'receipt.json'),'receipt_sha256':sha(args.output/'receipt.json'),
        'checks_passed':state.get('result',{}).get('checks_passed'),'error':state.get('error')},indent=2),flush=True)
    return state['returncode']


if __name__=='__main__':raise SystemExit(main())

"""Freeze reserved WikiText article inputs without model execution or selection on outputs.

The source is the pinned train parquet. Reservation is a new disjoint document
partition, not the dataset's official validation split. English encyclopedia
coverage does not establish multilingual/code/math or task-quality coverage.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

SOURCE_SHA = 'e83889baabc497075506f91975be5fac0d45c5290b6b20582c8cd1e853d0c9f7'
TOKENIZER_SHA = '42cacba08980fc39bfe2c73cb8c4486b9d00f2f2671072c6cb9c45ee2c5cfaae'
DISCOVERY_SHA = '589d0f677be94597903cb8e7bb5a3b78b6d61a66ad1f76ef443f204f63319525'
SEED = 'gemma4-wikitext-document-reserved-v1'
BINS, PER_BIN, CONTINUATION = (128,512,2048,8192), 12, 32
HEADER = re.compile(r'\s*=\s+[^=\s][^=\n]*?\s+=\s*')


def sha(raw): return hashlib.sha256(raw).hexdigest()
def norm(text): return ' '.join(text.split()).casefold()


def articles(rows):
    if not all(isinstance(row,str) for row in rows): raise ValueError('all source rows must be strings')
    starts = [i for i,text in enumerate(rows) if HEADER.fullmatch(text)]
    if not starts: raise ValueError('top-level article headings absent')
    return [(start,end) for start,end in zip(starts,starts[1:]+[len(rows)])]


def select(rows, encode, discovery_rows, bins=BINS, per_bin=PER_BIN, continuation=CONTINUATION):
    if not discovery_rows or any(type(i) is not int or not 0<=i<len(rows) for i in discovery_rows):
        raise ValueError('nonempty valid discovery source rows required')
    discovery_hashes = {sha(norm(rows[i]).encode()) for i in discovery_rows}
    excluded, seen, candidates = 0, set(), []
    for start,end in articles(rows):
        row_hashes = {sha(norm(row).encode()) for row in rows[start:end] if norm(row)}
        if any(start<=i<end for i in discovery_rows) or discovery_hashes & row_hashes:
            excluded += 1; continue
        text = ''.join(rows[start:end]); digest = sha(norm(text).encode())
        if digest in seen: continue
        seen.add(digest)
        ids = encode(text)
        if not isinstance(ids,list) or any(type(i) is not int or not 0<=i<262144 for i in ids):
            raise ValueError('invalid encoded article token')
        if any(i in (0,1,2,3) for i in ids): continue
        candidates.append({'source_rows_zero_based_half_open':[start,end], 'normalized_article_sha256':digest,
                           'source_text_sha256':sha(text.encode()), 'source_token_count_without_BOS':len(ids), 'ids':ids,
                           'rank':sha((SEED+':'+digest).encode())})
    candidates.sort(key=lambda item:(item['rank'],item['normalized_article_sha256']))
    counts = {n:0 for n in bins}; selected = []
    for item in candidates:
        for n in sorted(bins,reverse=True):
            if counts[n]<per_bin and len(item['ids'])+1>=n+continuation:
                selected.append({**item,'bin':n});counts[n]+=1;break
    if counts != {n:per_bin for n in bins}: raise ValueError('declared bins not filled: '+str(counts))
    selected.sort(key=lambda item:(item['bin'],item['rank'],item['normalized_article_sha256']))
    assert len({tuple(item['source_rows_zero_based_half_open']) for item in selected}) == len(selected)
    return selected, {'article_candidates_after_exclusion_and_dedup':len(candidates),
                      'excluded_discovery_or_duplicate_paragraph_documents':excluded, 'observed_per_bin':counts,
                      'discovery_normalized_row_sha256':sorted(discovery_hashes)}


def records(selected):
    output = {}
    for index,item in enumerate(selected,1):
        name = 'wikitext2-reserved-doc-%03d'%index; n = item['bin']; span = n+CONTINUATION-1
        sequence = [2]+item['ids'][:span]
        if len(sequence)!=n+CONTINUATION: raise ValueError('short reserved sequence')
        output[name+'.json'] = {
            'sample':name, 'prompt':sequence[:n], 'continuation':sequence[n:],
            'input_role':'reserved_validation_not_for_policy_selection', 'independent_representative_example':True,
            'source_partition':'train_reserved_disjoint_articles',
            'source_rows_zero_based_half_open':item['source_rows_zero_based_half_open'],
            'source_text_sha256':item['source_text_sha256'], 'normalized_article_sha256':item['normalized_article_sha256'],
            'source_token_count_without_BOS':item['source_token_count_without_BOS'],
            'source_token_span_without_BOS_half_open':[0,span],
            'prompt_length_including_BOS':n, 'continuation_length':CONTINUATION,
            'mask':'all ones; no padding', 'positions':'zero-based consecutive; no truncation beyond recorded prefix',
        }
    return output


def encoded(doc): return (json.dumps(doc,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('source','tokenizer','discovery','output'): parser.add_argument('--'+key,type=Path,required=True)
    args = parser.parse_args()
    for path,digest in ((args.source,SOURCE_SHA),(args.tokenizer,TOKENIZER_SHA),(args.discovery,DISCOVERY_SHA)):
        if not path.is_file() or path.is_symlink() or sha(path.read_bytes())!=digest: raise ValueError('fixed source identity differs')
    if args.output.exists() or not args.output.parent.is_dir(): raise ValueError('new reserved output directory required')
    import platform
    import pyarrow,pyarrow.parquet as pq
    import tokenizers
    if platform.python_version()!='3.12.14' or pyarrow.__version__!='22.0.0' or tokenizers.__version__!='0.22.1':
        raise ValueError('reuse the exact private CPU preparation stack')
    rows = pq.read_table(args.source,columns=['text'])['text'].to_pylist()
    discovery = json.loads(args.discovery.read_text(encoding='utf-8'))
    tokenizer = tokenizers.Tokenizer.from_file(str(args.tokenizer))
    selected, inventory = select(rows,lambda text:tokenizer.encode(text,add_special_tokens=False).ids,
                                 {item['source_row_zero_based'] for item in discovery['samples']})
    files = {name:encoded(doc) for name,doc in records(selected).items()}
    if any(len(raw)>256*1024 for raw in files.values()) or sum(map(len,files.values()))>16*1024**2:
        raise ValueError('reserved input payload exceeds finite CPU preparation cap')
    manifest = {
        'schema_version':1, 'state':'frozen_reserved_english_article_validation',
        'source':{**discovery['source'],'partition':'train_reserved_disjoint_articles', 'official_validation_split':False},
        'tokenizer':discovery['tokenizer'], 'selection_source_sha256':sha(Path(__file__).read_bytes()),
        'discovery_manifest_sha256':DISCOVERY_SHA, 'seed':SEED, 'assignment':'seeded article rank; largest unmet eligible bin first; one article once',
        'article_boundary':'whole source row with one leading and trailing spaced equals sign; nested headings stay in their article',
        'concatenation':'original adjacent rows within each original article joined byte-for-byte; never concatenate independent articles',
        'selection_on_model_outputs':False, 'pretraining_contamination_assessed':False,
        'scope':'English encyclopedia text only; disjoint from all discovery source articles and selected normalized paragraphs; no multilingual/code/math claim.',
        'requested_prompt_bins_including_BOS':list(BINS), 'requested_per_bin':PER_BIN, 'continuation_tokens':CONTINUATION,
        'inventory':inventory, 'samples':[{'file':name,'sha256':sha(raw),'bytes':len(raw),
            **{k:v for k,v in json.loads(raw).items() if k not in ('prompt','continuation','mask','positions')}} for name,raw in files.items()],
        'native_runs_started':0,
    }
    args.output.mkdir()
    for name,raw in files.items():
        with (args.output/name).open('xb') as stream:stream.write(raw)
    with (args.output/'reserved.json').open('xb') as stream:stream.write(encoded(manifest))
    print(json.dumps({'status':manifest['state'],'manifest_sha256':sha((args.output/'reserved.json').read_bytes()),
                      'inputs':len(files),'observed_per_bin':inventory['observed_per_bin'],'native_runs_started':0},indent=2))


if __name__=='__main__':main()

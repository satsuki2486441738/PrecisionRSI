"""Once-only CPU I04 small export:200s work/210s generic/240s whole/20s cleanup."""
import argparse
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

EXPORTER='export_i04_actual_small_v1.py'
EXPORT_SHA='4153db0b6b8bcdd2f240ef70f5c57249d21bee569e920754b136b1a2ff63dbd5'
RECORDER='record_run.py'
RECORD_SHA='2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'
OPS='i04_actual_small_operations_v1.py'
TOTAL,GENERIC,CHILD,CLEANUP=240,210,200,20


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    p=Path(path);require(p.is_file() and not p.is_symlink() and p.stat().st_size<=64*1024**2,'bounded original regular metadata required')
    return hashlib.sha256(p.read_bytes()).hexdigest()


def load(path):
    def pairs(items):
        result={}
        for k,v in items:require(k not in result,'duplicate JSON key');result[k]=v
        return result
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    sha(path);return json.loads(Path(path).read_text(),object_pairs_hook=pairs,parse_constant=reject)


def put(path,doc):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(doc,stream,indent=2,allow_nan=False);stream.write('\n')


def imported(path,name):
    sys.dont_write_bytecode=True;s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
    require(Path(m.__file__).resolve()==Path(path).resolve(),'loaded source path differs');return m


def preflight(root,tools,manifest_sha,controller,digest):
    root,tools=Path(root),Path(tools)
    require(root.is_dir() and not root.is_symlink() and tools.is_dir() and not tools.is_symlink() and
        tools.resolve().is_relative_to((root/'tools').resolve()),'explicit original R/tools roots required')
    manifest=tools/'tool-manifest.json';require(sha(manifest)==manifest_sha,'external small-export tool manifest SHA differs')
    doc=load(manifest);require(doc.get('kind')=='i04-actual-small-export-tools' and set(doc.get('files',{}))=={EXPORTER,RECORDER,OPS},'exact three-source small-export package required')
    require({p.name for p in tools.iterdir() if p.is_file()}=={EXPORTER,RECORDER,OPS,'tool-manifest.json'},'unexpected tool file')
    for name,ref in doc['files'].items():require((tools/name).stat().st_size==ref['size_bytes'] and sha(tools/name)==ref['sha256'],'small-export tool source bytes differ')
    require(doc['files'][EXPORTER]['sha256']==EXPORT_SHA and doc['files'][RECORDER]['sha256']==RECORD_SHA and
        Path(__file__).resolve()==(tools/OPS).resolve() and sha(__file__)==doc['files'][OPS]['sha256'],'frozen small-export source chain differs')
    controller=Path(controller);require(controller.resolve(strict=True).is_relative_to((root/'runs').resolve()),'actual numerical controller escapes R/runs')
    exporter=imported(tools/EXPORTER,'i04_result_small_exporter_preflight');state,*_=exporter.verify_controller(controller,digest)
    require(not any(n in sys.modules for n in ('torch','torch_npu','numpy')),'stdlib metadata preflight imported a framework')
    return state,exporter


def discover(root):
    root=Path(root);start=load(root/'i04-comparison-start.json');stdout=Path(start['stdout'])
    require(stdout.resolve(strict=True).is_relative_to((root/'runs').resolve()),'actual comparison startup stdout escapes R/runs')
    result=load(stdout);require(result.get('status')=='completed','actual I04 comparison must finish before small export')
    controller=Path(result['receipt']);require(controller.resolve(strict=True).is_relative_to((root/'runs').resolve()),'actual controller escapes R/runs')
    return controller,sha(controller)


def worker(root,tools,manifest_sha,controller,digest):
    os.umask(0o077);root,tools=Path(root),Path(tools);started=time.monotonic()
    state,exporter=preflight(root,tools,manifest_sha,controller,digest)
    task=root/'i04-batch-padding-20261107';require(task.is_dir() and not task.is_symlink(),'actual I04 task root required')
    put(task/'numeric-small-export-once.json',{'task':'I04-result-small-export','claimed_utc':datetime.now(timezone.utc).isoformat(),
        'controller':str(controller),'controller_sha256':digest,'operations_sha256':sha(__file__),'exporter_sha256':EXPORT_SHA,
        'automatic_retry':False,'native_executions_started':0})
    generic=imported(tools/RECORDER,'i04_small_generic_recorder')
    result={'schema_version':1,'task':'I04-result-small-export','status':'running','started_utc':datetime.now(timezone.utc).isoformat(),
        'source_controller':{'path':str(controller),'sha256':digest},'operations_sha256':sha(__file__),'exporter_sha256':EXPORT_SHA,
        'generic_source_sha256':RECORD_SHA,'tool_manifest_sha256':manifest_sha,'whole_cpu_seconds':TOTAL,'generic_seconds':GENERIC,
        'child_work_seconds':CHILD,'cleanup_reserve_seconds':CLEANUP,'native_executions_started':0,'arrays_statted_opened_or_copied':0,'acceptance':None}
    def expired(*_):raise KeyboardInterrupt('I04 small-export whole240s deadline')
    previous={s:signal.signal(s,expired) for s in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
    signal.setitimer(signal.ITIMER_REAL,max(.01,TOTAL-(time.monotonic()-started)));run=None;code=2
    try:
        require(TOTAL-(time.monotonic()-started)-CLEANUP>=GENERIC,'finite small-export work budget unavailable')
        run,command=generic.record_run(task/'metadata-exports','cpu','i04-numeric-small',GENERIC,
            lambda folder:[sys.executable,'-S','-B',str(tools/EXPORTER),'--controller',str(controller),'--controller-sha256',digest,'--output',str(folder/'payload')],cwd=root)
        result['generic_receipt']={'path':str(run/'command.json'),'sha256':sha(run/'command.json')}
        require(command['status']=='completed' and command['returncode']==0 and command['child_returncode']==0,'small-export child failed; raw logs retained')
        exported=load(run/'stdout.bin');receipt=run/'payload-export-receipt.json'
        require(load(receipt)==exported and exported.get('status')=='i04_actual_small_export_completed' and
            exported.get('controller_sha256')==digest and exported.get('frozen_comparison_documents_checked')==144 and
            exported.get('omitted_npy_files')==564 and exported.get('omitted_raw_native_files')==8 and
            exported.get('arrays_statted_opened_or_copied')==0 and exported.get('fresh_array_hashes_by_exporter')==0 and
            exported.get('native_executions_started')==0 and exported.get('prerequisite_raw_documents')==8,'actual metadata export scope differs')
        for ref in exported['archives']:
            path=run/ref['basename'];require(path.stat().st_size==ref['bytes'] and sha(path)==ref['sha256'] and ref['bytes']<=32*1024**2,'actual small archive differs')
        envelope=Path(exported['json_base64_path']);require(envelope.resolve().is_relative_to(run.resolve()) and sha(envelope)==exported['json_base64_sha256'],'actual envelope differs')
        preflight(root,tools,manifest_sha,controller,digest)
        result.update(status='completed',returncode=0,export_receipt={'path':str(receipt),'sha256':sha(receipt)},result=exported);code=0
    except BaseException as exc:result.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),automatic_retry=False)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        for s,h in previous.items():signal.signal(s,h)
        result.update(finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started)
        target=run/'small-export-controller.json' if run is not None else task/('numeric-small-export-failure-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.json')
        put(target,result);print(json.dumps({**result,'controller_path':str(target)},allow_nan=False),flush=True)
    return code


def start(root,tools,manifest_sha):
    root,tools=Path(root),Path(tools);controller,digest=discover(root);preflight(root,tools,manifest_sha,controller,digest)
    task=root/'i04-batch-padding-20261107';require(not (task/'numeric-small-export-once.json').exists(),'permanent small-export claim already spent')
    folder=task/'metadata-exports'/('start-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));folder.mkdir(parents=True,mode=0o700)
    argv=[sys.executable,'-S','-B',str(tools/OPS),'--worker','--root',str(root),'--tools-root',str(tools),'--manifest-sha256',manifest_sha,
        '--controller',str(controller),'--controller-sha256',digest]
    env=dict(os.environ)
    for k in ('PYTHONHOME','PYTHONPATH'):env.pop(k,None)
    env.update(PYTHONHASHSEED='0',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',TORCH_DEVICE_BACKEND_AUTOLOAD='0')
    with (task/'numeric-small-export-start.json').open('x',encoding='utf-8') as receipt:
        with (folder/'stdout.json').open('xb') as out,(folder/'stderr.txt').open('xb') as err:
            process=subprocess.Popen(argv,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
        try:creation=int((Path('/proc')/str(process.pid)/'stat').read_text().rpartition(')')[2].split()[19])
        except FileNotFoundError:creation=None
        d={'status':'small_CPU_export_spawned_not_result','pid':process.pid,'starttime':creation,'argv':argv,
            'stdout':str(folder/'stdout.json'),'stderr':str(folder/'stderr.txt'),'source_controller_sha256':digest,
            'automatic_retry':False,'native_executions_started':0};json.dump(d,receipt,indent=2);receipt.write('\n')
    print(json.dumps(d,indent=2));return 0


def query(root):
    task=Path(root)/'i04-batch-padding-20261107';s=load(task/'numeric-small-export-start.json');p=Path(s['stdout'])
    try:d=load(p) if p.is_file() and p.stat().st_size else None
    except json.JSONDecodeError:d=None
    if d is None:print(json.dumps({'status':'not_terminal','pid':s['pid'],'stderr_bytes':Path(s['stderr']).stat().st_size}));return 0
    controller=Path(d['controller_path']);require(controller.resolve(strict=True).is_relative_to(task.resolve()) and
        load(controller)=={k:v for k,v in d.items() if k!='controller_path'},'actual small-export controller/stdout differs')
    out={'status':d['status'],'returncode':d['returncode'],'controller_path':str(controller),'controller_sha256':sha(controller),
        'elapsed_seconds':d['elapsed_seconds'],'result':d.get('result'),'error':d.get('error'),'native_executions_started':0}
    print(json.dumps(out,indent=2));return 0


def main():
    p=argparse.ArgumentParser(description=__doc__);mode=p.add_mutually_exclusive_group(required=True)
    for n in ('worker','start','query'):mode.add_argument('--'+n,action='store_true')
    p.add_argument('--root',type=Path,required=True);p.add_argument('--tools-root',type=Path);p.add_argument('--manifest-sha256')
    p.add_argument('--controller',type=Path);p.add_argument('--controller-sha256');a=p.parse_args()
    if not a.worker:
        def expire(*_):raise TimeoutError('I04 small-export start/query30s deadline')
        signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,30)
    if a.query:return query(a.root)
    require(a.tools_root is not None and a.manifest_sha256 is not None,'frozen tool root and external manifest pin required')
    if a.start:return start(a.root,a.tools_root,a.manifest_sha256)
    require(a.controller is not None and a.controller_sha256 is not None,'actual controller reference required')
    return worker(a.root,a.tools_root,a.manifest_sha256,a.controller,a.controller_sha256)


if __name__=='__main__':raise SystemExit(main())

"""Wrap the immutable actual I03 gzip bytes in two UI-compatible regular TARs."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import signal
import tarfile
import time

ARCHIVE_NAME = 'gpu-i03-full-REDACTED_APP_ID-20261106T153711Z.tar.gz'
ARCHIVE_BYTES = 529888535
ARCHIVE_SHA = '406294d2a911e81b4dfbd90f05f14cf958976f7b2999a988c0714ff33979c894'
CHUNK_BYTES = 256 * 1024 ** 2
LOGICAL_BYTES = 1041054681
WIRE_CAP, DISK_CAP = 1536 * 1024 ** 2, 4 * 1024 ** 3
MANIFEST_NAME = 'i03-gpu-transport-manifest-v1.json'


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 ** 2), b''): value.update(block)
    return value.hexdigest()


def tar_size(data_bytes):
    return ((512 + ((data_bytes + 511) // 512) * 512 + 1024 + 10239) // 10240) * 10240


def member_name(index): return 'chunk-%04d.bin' % index


def wrapper_name(index): return ARCHIVE_NAME[:-7] + '-transport-%04d.tar' % index


class LimitedReader:
    def __init__(self, source, size, deadline):
        self.source, self.remaining, self.deadline = source, size, deadline
        self.digest = hashlib.sha256()

    def read(self, size=-1):
        require(time.monotonic() < self.deadline, 'split deadline reached')
        size = self.remaining if size < 0 else min(size, self.remaining)
        data = self.source.read(size)
        require(len(data) == size, 'immutable source truncated during split')
        self.remaining -= len(data); self.digest.update(data)
        return data


def split(archive, output):
    started = time.monotonic(); deadline = started + 900
    archive, output = Path(archive), Path(output)
    require(archive.name == ARCHIVE_NAME and archive.is_file() and not archive.is_symlink(), 'actual original gzip path required')
    require(archive.stat().st_size == ARCHIVE_BYTES and sha(archive) == ARCHIVE_SHA, 'original actual gzip size/SHA differs')
    require(output.parent.is_dir() and not output.exists() and not output.is_symlink(), 'exclusive new transport directory required')
    require(0 < CHUNK_BYTES <= 256 * 1024 ** 2 and CHUNK_BYTES < ARCHIVE_BYTES <= 2 * CHUNK_BYTES, 'exact two bounded data chunks required')
    output.mkdir(mode=0o700)
    parts = []
    with archive.open('rb') as source:
        for index in range(2):
            offset = index * CHUNK_BYTES; size = min(CHUNK_BYTES, ARCHIVE_BYTES - offset)
            wrapper = output / wrapper_name(index)
            reader = LimitedReader(source, size, deadline)
            with wrapper.open('xb') as destination:
                with tarfile.open(fileobj=destination, mode='w', format=tarfile.USTAR_FORMAT) as package:
                    item = tarfile.TarInfo(member_name(index)); item.size = size; item.mode = 0o600
                    item.mtime = item.uid = item.gid = 0; item.uname = item.gname = ''
                    package.addfile(item, reader)
            require(reader.remaining == 0 and wrapper.stat().st_size == tar_size(size), 'exact wrapper byte accounting differs')
            parts.append({'index':index,'offset':offset,'data_size_bytes':size,'data_sha256':reader.digest.hexdigest(),
                'member_name':member_name(index),'wrapper_basename':wrapper.name,'wrapper_size_bytes':wrapper.stat().st_size,'wrapper_sha256':sha(wrapper)})
        require(source.tell() == ARCHIVE_BYTES and source.read(1) == b'', 'source coverage differs')
    require(archive.stat().st_size == ARCHIVE_BYTES and sha(archive) == ARCHIVE_SHA, 'original gzip changed during split')
    wire = sum(item['wrapper_size_bytes'] for item in parts)
    require(wire <= WIRE_CAP and wire + ARCHIVE_BYTES + LOGICAL_BYTES < DISK_CAP, 'actual transport/storage accounting exceeds stage caps')
    document = {'schema_version':1,'kind':'i03-gpu-archive-tar-chunks','archive':{'basename':ARCHIVE_NAME,'size_bytes':ARCHIVE_BYTES,'sha256':ARCHIVE_SHA},
        'chunk_data_limit_bytes':CHUNK_BYTES,'parts':parts,'transport_accounting':{
            'chunk_data_bytes':sum(item['data_size_bytes'] for item in parts),'wrapper_wire_bytes':wire,
            'wrapper_header_and_padding_bytes':wire-ARCHIVE_BYTES,'encoded_transport_cap_bytes':WIRE_CAP,
            'logical_artifact_payload_bytes':LOGICAL_BYTES,'logical_artifact_cap_bytes':1024**3,
            'parts_plus_reconstructed_plus_artifact_payload_bytes':wire+ARCHIVE_BYTES+LOGICAL_BYTES,'new_disk_cap_bytes':DISK_CAP},
        'original_gzip_bytes_preserved':True,'native_executions_started':0,'acceptance':None}
    manifest = output / MANIFEST_NAME
    with manifest.open('x',encoding='utf-8',newline='\n') as stream:json.dump(document,stream,indent=2,allow_nan=False);stream.write('\n')
    receipt = {'status':'i03_gpu_transport_wrappers_created','finished_utc':datetime.now(timezone.utc).isoformat(),
        'manifest':str(manifest.resolve()),'manifest_sha256':sha(manifest),'archive_sha256':ARCHIVE_SHA,
        'parts':parts,'transport_accounting':document['transport_accounting'],'elapsed_seconds':time.monotonic()-started,'native_executions_started':0}
    with (output/'split-receipt.json').open('x',encoding='utf-8') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
    return receipt


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--archive',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    def expire(*_):raise TimeoutError('I03 CPU split900s bound exceeded')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,900)
    try:print(json.dumps(split(args.archive,args.output)));return 0
    finally:signal.setitimer(signal.ITIMER_REAL,0)


if __name__=='__main__':raise SystemExit(main())

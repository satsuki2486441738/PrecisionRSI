"""Finite I04 tool/GPU archive import; regular members, exact hashes, no overwrite."""
import argparse
import ast
import io
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path,PurePosixPath
import re
import shutil
import signal
import tarfile
import time

CASE='projects/gemma4-pilot/cases/text-native'
MAIN=CASE+'/adapters/admit_i04_batch_padding_v1.py'
MAIN_SHA='640b0af596111e12eb73aca20f7b8e5b101c04341af0aed2d3a5f9a1d2f19db0'
HELPER=CASE+'/adapters/i04_artifact_admission_v1.py'
HELPER_SHA='0d43e77420285436f4151d42c6cd8a6792001b004e0e0b870242f90c5bd33719'
STAGE_SHA='26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
LOGICAL_CAP=1207959552
ENCODED_CAP=1610612736
MODES=['alone-A','alone-B','batch-left','batch-right']
POSITIONS={'A':sorted(set(i*127//15 for i in range(16))|set(range(127,159))),
 'B':sorted(set(i*63//15 for i in range(16))|set(range(63,95)))}
LARGE={'modes/'+m+'/raw-native-logits.safetensors' for m in MODES}
LARGE|={'modes/%s/request-%s/dist-p%03d.npy'%(m,r,p) for m in MODES
 for r in ([m[-1]] if m.startswith('alone-') else ['A','B']) for p in POSITIONS[r]}
HEX=re.compile(r'^[a-f0-9]{64}$')


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def load(path):
    def pairs(items):
        out={}
        for key,value in items:require(key not in out,'duplicate JSON key');out[key]=value
        return out
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_text(),object_pairs_hook=pairs,parse_constant=reject)


def put(path,value):
    with Path(path).open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def safe_name(name):
    p=PurePosixPath(name);require(isinstance(name,str) and name and not p.is_absolute() and '\\' not in name and str(p)==name and
        all(part not in ('','.','..') for part in name.split('/')),'unsafe/noncanonical archive path');return name


def extract(archive,output,max_expanded):
    require(not output.exists() and output.parent.is_dir(),'exclusive new import directory required')
    with tarfile.open(archive,'r:*') as package:
        members=package.getmembers();names=[safe_name(m.name) for m in members];memberset=set(names)
        require(members and len(members)<=2048 and len(names)==len(memberset) and all(m.isfile() and m.size>=0 for m in members),
            'unique regular archive members required')
        require(all(not any(str(parent) in memberset for parent in PurePosixPath(name).parents if str(parent)!='.') for name in names),'archive ancestor file collision')
        total=sum(m.size for m in members);require(total<=max_expanded,'archive exceeds finite expanded logical cap')
        require(shutil.disk_usage(output.parent).free>=max(5*1024**3,total+1024**3),'source observed free space below5GiB/import bound')
        output.mkdir(mode=0o700)
        for member in members:
            target=output/member.name;target.parent.mkdir(parents=True,exist_ok=True)
            require(target.resolve().is_relative_to(output.resolve()),'resolved archive member escapes new import')
            source=package.extractfile(member);require(source is not None,'regular member stream missing');count=0
            with source,target.open('xb') as destination:
                for block in iter(lambda:source.read(4*1024**2),b''):destination.write(block);count+=len(block)
            require(count==member.size,'member byte count differs')
    return set(names),total


def verify_tools(output,names,manifest_sha):
    manifest=output/'tool-bundle-manifest.json';require(HEX.fullmatch(manifest_sha) and sha(manifest)==manifest_sha,'external tool manifest pin differs')
    doc=load(manifest);require(doc['kind']=='i04-offline-tool-bundle' and doc['acceptance'] is None and doc['native_executions_started']==0,'wrong offline tool bundle')
    require(set(doc['files'])|{'tool-bundle-manifest.json'}==names and doc['files'][MAIN]['sha256']==MAIN_SHA and doc['files'][HELPER]['sha256']==HELPER_SHA,
        'tool member set/frozen independent source differs')
    for name,ref in doc['files'].items():
        path=output/safe_name(name);require(ref['size_bytes']<=1024**2 and path.stat().st_size==ref['size_bytes'] and sha(path)==ref['sha256'],'tool byte identity differs: '+name)
    return {'manifest':str(manifest),'manifest_sha256':manifest_sha,'source_files_checked':len(doc['files'])}


def verify_gpu(output,names,map_sha):
    mapping=output/'source-map.json';require(HEX.fullmatch(map_sha) and sha(mapping)==map_sha,'external actual GPU source-map pin differs')
    doc=load(mapping);request=doc['request'];require(request['task']=='I04' and request['backend']=='GPU' and doc['full_array_hashes_checked']==286 and
        doc['retained_array_count']==0 and doc['acceptance'] is None,'full copied GPU I04 export required')
    payload=set();large=[];logical=0
    for original,ref in doc['files'].items():
        p=PurePosixPath(original);require(p.is_absolute() and '..' not in p.parts and '\\' not in original and 'path' in ref and
            not ref.get('retained_at_source') and type(ref.get('size')) is int and ref['size']>=0 and HEX.fullmatch(ref['sha256']),
            'complete original POSIX/copy descriptor required')
        relative=safe_name(ref['path']);require(relative.startswith('payload/') and relative not in payload,'duplicate/malformed mapped payload path')
        payload.add(relative);actual=output/relative;require(actual.is_file() and actual.stat().st_size==ref['size'] and sha(actual)==ref['sha256'],
            'actual mapped GPU payload size/SHA differs')
        logical+=ref['size']
        if p.suffix in ('.npy','.safetensors'):large.append(original)
        else:require(ref['size']<=16*1024**2,'unexpected metadata larger than16MiB')
    outerref=doc['files'][request['outer_receipt']];outer=load(output/outerref['path']);original_output=PurePosixPath(outer['output_dir'])
    require(outer['task']=='I04' and outer['backend']=='GPU' and outer['status']=='completed' and outer['returncode']==0 and outer['timed_out'] is False and
        outer['native_forward_calls_total']==4 and outer['model_loads']==1 and outer['stage_spec_source_sha256']==STAGE_SHA,'actual completed4call GPU envelope differs')
    relative_large=[]
    for original in large:
        path=PurePosixPath(original);require(path.is_relative_to(original_output),'unexpected model/environment/old arrays in GPU packet')
        relative_large.append(path.relative_to(original_output).as_posix())
    require(len(relative_large)==286 and set(relative_large)==LARGE and logical<=LOGICAL_CAP,'exact282NPY+4logits/logical1.125GiB inventory required')
    require(names==payload|{'source-map.json','export-summary.json'},'unmapped/omitted GPU archive member')
    return {'source_map':str(mapping),'source_map_sha256':map_sha,'mapped_files_checked':len(payload),'native_array_files_checked':286,
        'copied_logical_bytes':logical,'raw_receipts_rewritten':False,'numeric_admission_performed':False}


def import_archive(root,archive,kind,digest,size,manifest_sha=None,map_sha=None):
    require(not Path(root).is_symlink() and not Path(archive).is_symlink(),'original root/archive symlink prohibited')
    root=Path(root).resolve(strict=True);archive=Path(archive).resolve(strict=True)
    require(archive.is_relative_to(root) and archive.is_file(),'uploaded archive must be below explicit R')
    require(HEX.fullmatch(digest) and type(size) is int and size>0 and archive.stat().st_size==size and sha(archive)==digest,'uploaded archive size/SHA differs')
    require(kind in ('gpu','tools') and size<=(ENCODED_CAP if kind=='gpu' else 2*1024**2),'encoded transport cap exceeded')
    parent=root/('imports' if kind=='gpu' else 'tools');require(not parent.is_symlink() and parent.resolve().is_relative_to(root),'new import parent escapes R')
    parent.mkdir(mode=0o700,exist_ok=True);label='gpu-i04-full' if kind=='gpu' else 'i04-cpu-compare-v1'
    output=parent/(label+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));receipt=parent/(output.name+'-import-receipt.json')
    state={'schema_version':1,'kind':kind,'status':'running','started_utc':datetime.now(timezone.utc).isoformat(),'archive':str(archive),
        'archive_sha256':digest,'archive_bytes':size,'output':str(output),'cpu_timeout_seconds':900,'original_archive_preserved':True,'automatic_retry':False,'acceptance':None}
    started=time.monotonic()
    try:
        names,expanded=extract(archive,output,LOGICAL_CAP if kind=='gpu' else 4*1024**2)
        state.update(verify_gpu(output,names,map_sha) if kind=='gpu' else verify_tools(output,names,manifest_sha))
        require(sha(archive)==digest,'original uploaded archive changed during import')
        state.update(status='completed',returncode=0,regular_members=len(names),expanded_bytes=expanded)
    except BaseException as exc:state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),partial_output_preserved=True)
    finally:
        state.update(finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started);put(receipt,state)
    print(json.dumps({**state,'receipt':str(receipt)},indent=2),flush=True);return state['returncode']


def self_test():
    import io,tempfile
    for name in ('../bad','a/../x','a//x','/absolute','a\\x','./x',''):
        try:safe_name(name)
        except ValueError:pass
        else:raise AssertionError('unsafe synthetic name accepted')
    with tempfile.TemporaryDirectory() as temporary:
        root=Path(temporary)
        for kind in ('duplicate','symlink','ancestor'):
            path=root/(kind+'.tar')
            with tarfile.open(path,'w') as package:
                for name in (['x','x'] if kind=='duplicate' else ['x','x/y'] if kind=='ancestor' else ['x']):
                    info=tarfile.TarInfo(name);info.size=1
                    if kind=='symlink':info.type=tarfile.SYMTYPE;info.linkname='/synthetic/outside';info.size=0
                    package.addfile(info,io.BytesIO(b'x'))
            try:extract(path,root/(kind+'-output'),1024)
            except ValueError:pass
            else:raise AssertionError('unsafe synthetic archive accepted')
    print('synthetic_I04_archive_path_regressions_passed; native_executions_started=0')


CONTROLLER=CASE+'/transfer/run_i04_actual_compare_v1.py'
OPERATIONS=CASE+'/transfer/i04_compare_operations_v1.py'
BUILDER=CASE+'/adapters/build_gpu290_npu3_compare_v1.py'
PINS={'projects/gemma4-pilot/cases/text-native/adapters/build_gpu290_npu3_compare_v1.py': '43115d8572e30ddedcdb4a85194ca4ddd3046e90e780be6f17f11c0bd8150c24', 'projects/gemma4-pilot/cases/text-native/adapters/i01_admission_compare_v1.py': 'f7fe91cdcebeec910efed4579ecf379fd665cf305223a3fa77858004db81858a', 'projects/gemma4-pilot/cases/text-native/adapters/i01_expected_inventory_v1.py': '834de8fef3d6147b908450116e39a48ea75a026bfc13a290db7db25492fbb40b', 'projects/gemma4-pilot/cases/text-native/adapters/i03_artifact_admission_v1.py': 'b734babc65be6ec361acbc10905b6c3e02e8c5c57650efb11e3a195134a1b6eb', 'projects/gemma4-pilot/cases/text-native/adapters/admit_i03_partition_repeat_v1.py': '2468a5f2a1aafe9f9437edae2bd90b3bdca15f9c1abcc6fa3b927ddb8167691c', 'projects/gemma4-pilot/cases/text-native/adapters/i03_expected_inventory_v1.py': '9c0d5cad39ae932d95fee34db3ee91cbb6232ed1ab554e6004fadc189425a7f8', 'projects/gemma4-pilot/cases/text-native/adapters/i03_prerequisite_v1.py': 'e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36', 'projects/gemma4-pilot/cases/text-native/adapters/test_i03_independent_admission_v1.py': '8d32035d07fbdecba54dbcce54169db6bf3a84c0a3be1996946493429ecc163e', 'projects/gemma4-pilot/cases/text-native/adapters/test_i03_expected_inventory_v1.py': 'd63009cb2b24ae2b6fa598fd0f2eb634d854901f78145c982feea2778ec3fe3c', 'projects/gemma4-pilot/cases/text-native/adapters/i04_artifact_admission_v1.py': '0d43e77420285436f4151d42c6cd8a6792001b004e0e0b870242f90c5bd33719', 'projects/gemma4-pilot/cases/text-native/adapters/admit_i04_batch_padding_v1.py': '640b0af596111e12eb73aca20f7b8e5b101c04341af0aed2d3a5f9a1d2f19db0', 'projects/gemma4-pilot/cases/text-native/adapters/i04_expected_inventory_v1.py': 'b8f134724a295072a77e292864ebf12e0e5944f184690ba36f0f9d55937f1752', 'projects/gemma4-pilot/cases/text-native/adapters/i04_prerequisite_v1.py': '8d42c0eb525c92c23c5324dc751149b47f3c20b8e74d65d4ba76de6c1ca068f0', 'projects/gemma4-pilot/cases/text-native/adapters/i04_cpu_prerequisite_v2.py': '8943f40ceb3b6c98408142843db72aa9d3b53df176b4a9add0ab3d5222a78e38'}

def build(root,archive):
 root=Path(root).resolve(strict=True);archive=Path(archive).resolve();require(not archive.exists() and archive.parent.is_dir(),'new output archive required')
 require(sha(root/BUILDER)==PINS[BUILDER],'prior reviewed builder source changed');imports=None
 for node in ast.parse((root/BUILDER).read_text()).body:
  if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='IMPORT_PINS' for t in node.targets):imports=ast.literal_eval(node.value)
 require(isinstance(imports,dict) and len(imports)==10,'fixed10 prior import closure not found')
 pins={**imports,**PINS,'skills/precision-compare/scripts/record_run.py':'2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b',CONTROLLER:sha(root/CONTROLLER),OPERATIONS:sha(root/OPERATIONS)};files={}
 for name,digest in sorted(pins.items()):
  path=root/name;require(path.is_file() and not path.is_symlink() and path.stat().st_size<=1024**2 and sha(path)==digest,'fixed source changed: '+name)
  files[name]={'sha256':digest,'size_bytes':path.stat().st_size}
 manifest={'schema_version':1,'kind':'i04-offline-tool-bundle','files':files,'native_executions_started':0,'thresholds':None,'acceptance':None,
  'scope':'independent I04 raw BF16/padding admission,18 pairs,572 source arrays; no native execution'}
 raw=(json.dumps(manifest,indent=2,allow_nan=False)+'\n').encode()
 with archive.open('xb') as destination,tarfile.open(fileobj=destination,mode='w') as package:
  for name,ref in files.items():
   data=(root/name).read_bytes();require(hashlib.sha256(data).hexdigest()==ref['sha256'],'source changed during package')
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;package.addfile(info,io.BytesIO(data))
  info=tarfile.TarInfo('tool-bundle-manifest.json');info.size=len(raw);info.mode=0o600;package.addfile(info,io.BytesIO(raw))
 require(archive.stat().st_size<=2*1024**2,'tool archive exceeds2MiB')
 for name,ref in files.items():require(sha(root/name)==ref['sha256'],'source changed after package')
 receipt={'status':'i04_offline_tool_bundle_created','archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),
  'manifest_sha256':hashlib.sha256(raw).hexdigest(),'regular_members':len(files)+1,'source_members':len(files),'controller_sha256':files[CONTROLLER]['sha256'],
  'native_executions_started':0,'acceptance':None}
 with archive.with_name(archive.name+'.receipt.json').open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
 print(json.dumps(receipt,indent=2));return receipt




def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--self-test',action='store_true');parser.add_argument('--build',action='store_true')
    parser.add_argument('--root',type=Path);parser.add_argument('--archive',type=Path);parser.add_argument('--kind',choices=['gpu','tools'])
    parser.add_argument('--archive-sha256');parser.add_argument('--archive-bytes',type=int);parser.add_argument('--manifest-sha256');parser.add_argument('--source-map-sha256');args=parser.parse_args()
    if args.self_test:self_test();return 0
    if args.build:
        require(args.root is not None and args.archive is not None,'build requires repository root and new archive');build(args.root,args.archive);return 0
    require(all(getattr(args,name) is not None for name in ('root','archive','kind','archive_sha256','archive_bytes')),'all actual paths/size/SHA pins required')
    require(args.source_map_sha256 is not None if args.kind=='gpu' else args.manifest_sha256 is not None,'independent actual map/manifest pin required')
    def expire(*_):raise TimeoutError('I04 import CPU900s deadline reached')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,900)
    try:return import_archive(args.root,args.archive,args.kind,args.archive_sha256,args.archive_bytes,args.manifest_sha256,args.source_map_sha256)
    finally:signal.setitimer(signal.ITIMER_REAL,0)


if __name__=='__main__':raise SystemExit(main())

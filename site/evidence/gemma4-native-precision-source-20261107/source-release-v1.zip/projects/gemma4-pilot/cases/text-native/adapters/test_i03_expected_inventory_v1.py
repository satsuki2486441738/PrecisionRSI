"""Pure stdlib, synthetic fixed-token scheduling regressions; no native work."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import i03_expected_inventory_v1 as e


class Tests(unittest.TestCase):
    def setUp(self):
        self.doc={'sample':'synthetic-not-native','prompt':list(range(128)),'continuation':list(range(32))}
    def expected(self,doc=None):return e.derive(self.doc if doc is None else doc,e.INPUT_SHA256,e.STAGE_SHA256)
    def test_seventy_calls_partition_all160_once_and_masks_absolute(self):
        result=self.expected();self.assertEqual([m['native_forward_calls'] for m in result['modes']],[1,1,1,33,34])
        self.assertEqual(sum(m['native_forward_calls'] for m in result['modes']),70)
        for mode in result['modes']:
            calls=mode['calls'];self.assertEqual([c['call_index'] for c in calls],list(range(len(calls))))
            self.assertEqual([p for c in calls for p in c['position_ids']],list(range(160)))
            self.assertEqual([t for c in calls for t in c['input_ids']],self.doc['prompt']+self.doc['continuation'])
            for call in calls:
                self.assertEqual(call['prefix_length'],call['start']);self.assertEqual(call['attention_mask_length'],call['end'])
    def test_token_decode32_and_chunk63_65_boundaries(self):
        token,chunk=self.expected()['modes'][3:]
        self.assertEqual([(c['start'],c['end']) for c in chunk['calls'][:2]],[(0,63),(63,128)])
        for mode in (token,chunk):
            decode=[c for c in mode['calls'] if c['stage']=='decode'];self.assertEqual(len(decode),32)
            self.assertEqual((decode[0]['start'],decode[-1]['start'],decode[-1]['end']),(128,159,160))
            self.assertEqual(decode[-1]['position_ids'],[159]);self.assertEqual(decode[-1]['input_ids'],[31])
    def test_159_labels_47_rows_no_unprovided_label160(self):
        result=self.expected();targets=result['all_targets'];positions=result['distribution_positions']
        self.assertEqual([t['position'] for t in targets],list(range(1,160)))
        self.assertEqual(targets[127]['token'],0);self.assertEqual(targets[-1]['token'],31)
        self.assertEqual(result['sampling']['conditioning_predictors'],[0,8,16,25,33,42,50,59,67,76,84,93,101,110,118,127])
        self.assertEqual(len(positions),47);self.assertEqual(positions[15]['position'],127);self.assertEqual(positions[-1]['position'],158)
        self.assertEqual(result['raw_logits_per_mode']['unscored_prediction_indices'],[159])
        self.assertEqual(result['cached_final_state']['tensor_count'],96);self.assertEqual(len(set(result['cached_final_state']['tensor_keys'])),96)
    def test_invalid_input_or_unfrozen_identity_rejected(self):
        for mutate in (lambda d:d['continuation'].pop(),lambda d:d['prompt'].__setitem__(0,True),lambda d:d['prompt'].__setitem__(0,262144)):
            doc=copy.deepcopy(self.doc);mutate(doc)
            with self.assertRaises(ValueError):self.expected(doc)
        with self.assertRaisesRegex(ValueError,'SHA'):e.derive(self.doc,'0'*64,e.STAGE_SHA256)
    def test_file_build_exact_bytes_preserved_and_semantic_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);inp=root/'input.json';inp.write_text(json.dumps(self.doc)+'\n');input_sha=e.sha(inp)
            expected=self.expected()
            stage={'stage_id':e.STAGE_ID,'status':'prepared_not_executed','thresholds':None,'acceptance':None,'full_core_complete':False,
                'modes':e.MODES,'same_loaded_model':True,'new_model_processes_per_backend':1,'expected_native_calls':[1,1,1,33,34],
                'total_forward_calls_per_backend':70,'cached_decode_calls_per_mode':32,'prompt_chunk_lengths':[63,65],
                'semantics':{'per_mode_raw_logits_shape':[1,160,262144],'targets_per_mode':159,'selected_distribution_positions':expected['sampling']['deduplicated_predictors'],
                    'distribution_positions_per_mode':47,'unscored_prediction_row159_retained':True},'input':{'sha256':input_sha},
                'limits':{'max_native_model_processes_per_backend':1,'automatic_native_retries':0}}
            src=root/'stage.json';src.write_text(json.dumps(stage)+'\n');stage_sha=e.sha(src);original=src.read_bytes()
            with patch.multiple(e,INPUT_SHA256=input_sha,STAGE_SHA256=stage_sha):
                output=root/'expected.json';receipt=e.build(inp,output,src,stage_sha)
                self.assertEqual(receipt['native_executions_started'],0);self.assertEqual(receipt['sha256'],e.sha(output))
                e.verify(output,inp,src);self.assertEqual(src.read_bytes(),original)
                with self.assertRaisesRegex(ValueError,'exclusive'):e.build(inp,output,src,stage_sha)
                data=e.load(output);data['modes'][3]['calls'].pop();output.write_text(json.dumps(data))
                with self.assertRaisesRegex(ValueError,'derived I03'):e.verify(output,inp,src)
            stage['expected_native_calls'][-1]=33;src.write_text(json.dumps(stage));changed=e.sha(src)
            with patch.multiple(e,INPUT_SHA256=input_sha,STAGE_SHA256=changed):
                with self.assertRaisesRegex(ValueError,'stage semantics'):e.build(inp,root/'bad.json',src,changed)
    def test_duplicate_or_nonfinite_json_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'bad.json'
            for raw in ('{"sample":"a","sample":"b"}','{"x":NaN}'):
                path.write_text(raw)
                with self.assertRaises(ValueError):e.load(path)


if __name__=='__main__':unittest.main()

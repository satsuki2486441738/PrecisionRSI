"""Independent observer raw-BF16, sampled-boundary and metadata admission.

CPU NumPy only; never import Torch, the collector or its common validator.
Original source-map keys and original document bytes are preserved.
"""
import hashlib
import math
from pathlib import Path,PurePosixPath
import struct

import numpy as np
import i04_artifact_admission_v1 as prior
import observer_expected_inventory_v1 as expected
import observer_prerequisite_v1 as proof

old=prior.old
require,canonical,load,sha,child=prior.require,prior.canonical,prior.load,prior.sha,prior.child
TASK=expected.TASK
STAGE_ID=expected.STAGE_ID
STAGE_SHA='54683b3e1697b8358e7371d516596c42db347ff04de7253231236498ad15e22d'
EXPECTED_SHA='2f9821d74578735f2d8f1c82ec86c5f28dedc077ae7e293dce474e701cd7181a'
I04_SHA='59830ffb67bafb2c0497ef954392fb4fc830dc388afc16a7750195cd09986e54'
CPU_SHA='1c5bbfc0089a78cf5d8564a666feb11bf24144cbbb6814a7003da12cce2ebd63'
PRIOR_SHA='0d43e77420285436f4151d42c6cd8a6792001b004e0e0b870242f90c5bd33719'
EXPECTED_SOURCE_SHA='50a5f870d60733a842379107887365641b4f21afe43682407f6f0e94d79c5ec0'
PROOF_SOURCE_SHA='610e349ae0ba0be42fc683ccb7fd573255c080d835c09f07f4dee73edf98aa4c'
MODES=['off-before','hooks-only','off-after','hooks-plus-dispatch-metadata']
VOCABULARY=262144
NORMALIZATION=prior.NORMALIZATION
ATOL=1e-12
CAP_BYTES=1073741824


def verify_tools():
    prior.verify_tools()
    for module,digest in [(prior,PRIOR_SHA),(expected,EXPECTED_SOURCE_SHA),(proof,PROOF_SOURCE_SHA)]:
        require(sha(module.__file__)==digest and Path(module.__file__).resolve().parent==Path(__file__).resolve().parent,
            'reviewed independent observer helper changed or imported outside staged adapters')


class Endpoint(prior.Endpoint):
    """Extend retained resolution only to explicit bounded BF16 boundary packs."""
    def get(self,name,expected_sha=None):
        name=old.origin(name)
        if name in self.checked:
            require(expected_sha is None or self.checked[name]==expected_sha,'original source digest conflict');return Path(self.resolved[name])
        item=self.files[name]
        if item.get('retained_at_source') is True and PurePosixPath(name).name=='boundary-samples.safetensors':
            require(self.retained_root is not None and 'path' not in item and type(item.get('size')) is int and 0<item['size']<2*1024**2 and
                isinstance(item.get('sha256'),str) and old.HEX.fullmatch(item['sha256']),'retained boundary pack needs explicit NPU root and bounded digest')
            p=Path(name);require(p.is_absolute() and not p.is_symlink() and p.is_relative_to(self.retained_root) and p.resolve(strict=True).is_relative_to(self.retained_root),
                'boundary samples escape retained NPU root')
            cursor=p
            while cursor!=self.retained_root:require(not cursor.is_symlink(),'retained boundary ancestor symlink');cursor=cursor.parent
            require(p.is_file() and p.stat().st_size==item['size'] and sha(p)==item['sha256'] and
                (expected_sha is None or expected_sha==item['sha256']),'retained boundary size/hash differs')
            self.checked[name]=item['sha256'];self.resolved[name]=str(p);return p
        return super().get(name,expected_sha)


def signature(value):return hashlib.sha256(canonical(value).encode()).hexdigest()


def tensor_pack(path,descriptors):
    """Strict BF16 framing and finite payload; shared tensor tool computes metrics."""
    path=Path(path)
    with path.open('rb') as f:
        raw=f.read(8);require(len(raw)==8,'truncated sample tensor prefix');length=struct.unpack('<Q',raw)[0]
        require(0<length<=131072,'bounded sample header required');raw=f.read(length);require(len(raw)==length,'truncated sample header')
    header=old.parse(raw);require(set(header)-{'__metadata__'}==set(descriptors),'exact sample tensor keys required')
    if '__metadata__' in header:require(isinstance(header['__metadata__'],dict) and all(isinstance(k,str) and isinstance(v,str) for k,v in header['__metadata__'].items()),'tensor metadata strings required')
    spans=[];count=0
    for key,shape in descriptors.items():
        item=header[key];require(set(item)=={'dtype','shape','data_offsets'} and item['dtype']=='BF16' and item['shape']==shape,'sample dtype/shape differs')
        start,end=item['data_offsets'];require(type(start) is int and type(end) is int and start>=0 and end-start==math.prod(shape)*2,'sample offset/length differs')
        spans.append((start,end));count+=math.prod(shape)
    end=0
    for a,b in sorted(spans):require(a==end,'sample offset overlap/gap');end=b
    require(end==count*2 and path.stat().st_size==8+length+end,'sample payload length differs')
    bits=np.memmap(path,mode='r',dtype='<u2',offset=8+length,shape=(count,))
    try:require(np.isfinite(prior.decode_bits(bits)).all(),'sample native BF16 values are nonfinite')
    finally:bits._mmap.close()
    return {'tensor_count':len(descriptors),'finite_coordinate_count':count,'data_bytes':end,
        'arrays':{key:{'path':str(path),'key':key} for key in descriptors}}


def complete_rng(record,before=False):
    prior.prior.rng_descriptor(record,before)
    require(all(not x.get('unavailable') for x in record.values()),'unknown generator bytes cannot establish observer transparency')
    return record


def buffer_coverage(baseline):
    buffers=baseline['buffers'];gaps=[]
    for item in buffers:
        if 'content_sha256' in item:require(isinstance(item['content_sha256'],str) and old.HEX.fullmatch(item['content_sha256']) and 'content_probe_gap' not in item,'buffer fingerprint/gap conflict')
        else:require(isinstance(item.get('content_probe_gap'),dict),'unavailable buffer fingerprint needs explicit retained gap')
        if 'content_probe_gap' in item:gaps.append({'name':item['name'],'content_probe_gap':item['content_probe_gap']})
    return {'observed_buffer_entries':len(buffers),'entries_with_content_sha256':sum('content_sha256' in x for x in buffers),'unavailable_entries':gaps,
        'method':'Unchanged reviewed I03 bounded8MiB probe, including retained scalar BF16 view(uint8) gap; no reshape fix under old CPU proof.','complete_loaded_model_content_attested':False}


def metadata_tree(value,depth=0,budget=None):
    if budget is None:budget=[0]
    budget[0]+=1;require(isinstance(value,dict) and depth<=12 and budget[0]<=4096,'bounded dispatcher metadata tree required')
    if 'container' in value:
        require(set(value)=={'container','items'} and value['container'] in ('list','tuple','dict'),'metadata container schema differs')
        items=value['items'];require(isinstance(items,dict) if value['container']=='dict' else isinstance(items,list),'metadata container type differs')
        require(len(items)<=128,'metadata container exceeds128')
        if isinstance(items,dict):require(all(isinstance(k,str) for k in items),'metadata keys must be strings');items=items.values()
        for item in items:metadata_tree(item,depth+1,budget)
    elif 'python_type' in value:require(set(value)=={'python_type'} and isinstance(value['python_type'],str) and 0<len(value['python_type'])<=512,'scalar metadata must record only Python type')
    else:
        base={'path','shape','dtype','device','layout','stride'};require(set(value) in (base,base|{'stride_gap'}) and isinstance(value['path'],str) and
            isinstance(value['shape'],list) and all(type(x) is int and x>=0 for x in value['shape']) and all(isinstance(value[k],str) for k in ('dtype','device','layout')),
            'tensor metadata shape/dtype/device/schema differs')
        if value['stride'] is None:require(isinstance(value.get('stride_gap'),dict) and set(value['stride_gap'])=={'error_type','error'} and all(isinstance(x,str) for x in value['stride_gap'].values()),'explicit stride observation gap required')
        else:require(isinstance(value['stride'],list) and len(value['stride'])==len(value['shape']) and all(type(x) is int for x in value['stride']) and 'stride_gap' not in value,'tensor stride metadata differs')


def observer_metadata(doc,modules,inventory,enabled,dispatch,device):
    specs=inventory['boundaries'];require(doc.get('enabled') is enabled and doc.get('dispatcher',{}).get('enabled') is dispatch and
        doc.get('boundary_specs')==specs,'exact boundary inventory/collector mode differs')
    if not enabled:
        require(doc.get('status')=='disabled_control' and all(doc.get(k) is None for k in ('boundary_counts','module_invocations','zero_fired_modules')),
            'disabled controls must not invent execution counts');return {'execution_census_measured':False}
    census=doc.get('module_invocations',[])
    require(doc.get('status')=='completed' and doc.get('error') is None and doc.get('actual_module_count')==len(modules) and doc.get('hook_registry_restored') is True and
        [{k:x[k] for k in ('name','class')} for x in census]==modules,'complete actual static/census module identity differs')
    require(all(type(x.get('invocations')) is int and x['invocations']>=0 and type(x.get('completed_invocations')) is int and x['completed_invocations']==x['invocations'] for x in census),
        'module pre/post invocation counts differ')
    require(census[0]['name']=='' and census[0]['invocations']==1 and doc.get('zero_fired_modules')==[x['name'] for x in census if x['invocations']==0] and
        doc.get('fired_module_count')==sum(x['invocations']>0 for x in census) and doc.get('total_module_invocations')==sum(x['invocations'] for x in census),
        'actual fired/zero-fired census closure differs')
    require(doc.get('boundary_counts')=={x['id']:1 for x in specs} and len(doc.get('boundary_events',[]))==len(specs),'boundary events missing/duplicated')
    counts={x['name']:x['invocations'] for x in census};require(all(counts[x['module']]==1 for x in specs),'boundary events contradict module invocation census')
    for ordinal,(event,spec) in enumerate(zip(doc['boundary_events'],specs)):
        require(all(event.get(k)==v for k,v in spec.items()) and event.get('ordinal')==ordinal and
            event.get('token_indices')==inventory['distribution_positions'] and event.get('channel_indices')==inventory['channels'] and
            event.get('sample_shape')==[1,47,64] and event.get('sample_dtype')=='torch.bfloat16' and
            event.get('observed',{}).get('shape')==[1,160,3840] and event['observed'].get('dtype')=='torch.bfloat16' and
            event['observed'].get('device')==device,'ordered original sample boundary/shape/dtype/device differs')
    d=doc['dispatcher'];records=d.get('signatures',[]);count=d.get('observed_invocations');limits={'invocations':200000,'unique_signatures':10000,'serialized_bytes':16777216}
    require(d.get('limits')==limits and type(count) is int and 0<=count<=limits['invocations'] and len(records)==d.get('unique_signatures') and
        len(records)<=limits['unique_signatures'] and type(d.get('metadata_byte_budget_accounting')) is int and 0<=d['metadata_byte_budget_accounting']<=limits['serialized_bytes'],
        'frontend dispatcher finite count/byte bounds differ')
    if dispatch:require(count>0 and records,'enabled dispatcher has no actual frontend census')
    else:require(count==0 and records==[] and d.get('collector_generated_excluded_operations')=={},'hooks-only mode reported a dispatcher')
    seen=set();total=0;names={x['name'] for x in modules}
    for item in records:
        record={k:v for k,v in item.items() if k not in ('signature_sha256','count','first_invocation')};key=item.get('signature_sha256')
        require(set(record)=={'operator','schema','module_scope','inputs','kwargs','outputs'} and key==signature(record) and key not in seen and
            type(item.get('count')) is int and item['count']>0 and type(item.get('first_invocation')) is int and 1<=item['first_invocation']<=count and
            isinstance(record['operator'],str) and isinstance(record['schema'],str) and isinstance(record['module_scope'],list) and record['module_scope'] and
            record['module_scope'][0]=='' and all(x in names for x in record['module_scope']),'actual dispatcher signature/scope identity differs')
        for k in ('inputs','kwargs','outputs'):metadata_tree(record[k])
        seen.add(key);total+=item['count']
    require(total==count and all(isinstance(k,str) and type(v) is int and v>0 for k,v in d.get('collector_generated_excluded_operations',{}).items()) and
        len(canonical(doc).encode())<=limits['serialized_bytes'],'dispatcher count/metadata closure differs')
    return {'execution_census_measured':True,'static_modules':len(modules),'fired_modules':doc['fired_module_count'],'zero_fired_modules':doc['zero_fired_modules'],
        'total_module_invocations':doc['total_module_invocations'],'frontend_dispatcher_enabled':dispatch,'frontend_invocations':count,'frontend_unique_signatures':len(records),
        'native_kernel_identity_attested':False,'full_operand_values_attested':False}


def copy_dual(endpoint,i04,cpu,folder):
    folder.mkdir();names=set()
    for label,logical,digest,count in [('i04',i04,I04_SHA,8),('cpu',cpu,CPU_SHA,24)]:
        p=endpoint.get(logical,digest);wrapper=load(p);target=folder/label;target.mkdir();files={}
        def visit(value):
            if isinstance(value,dict):
                if set(value) in ({'path','source_path','sha256'},{'path','source_path','sha256','size_bytes'}):
                    rel=prior.safe_relative(value['path']).as_posix();require(rel not in files,'duplicate portable raw proof')
                    files[rel]=endpoint.get(child(str(PurePosixPath(logical).parent),rel),value['sha256'])
                else:
                    for item in value.values():visit(item)
            elif isinstance(value,list):
                for item in value:visit(item)
        visit(wrapper);require(len(files)==count,'complete actual8/24 raw docs required')
        for rel,original in {'prerequisite.json':p,**files}.items():
            output=target/rel;output.parent.mkdir(parents=True,exist_ok=True)
            with output.open('xb') as f:f.write(original.read_bytes())
            require(sha(output)==sha(original),'original proof copy changed');names.add('prerequisites/'+label+'/'+rel)
    checked=proof.prerequisite(folder/'i04/prerequisite.json',I04_SHA,folder/'cpu/prerequisite.json',CPU_SHA)
    require(len(checked['refs'])==35 and checked['native_executions_started']==0,'actual dual proof check failed');return names


def inspect_mode(endpoint,output,mode,inventory,baseline,baseline_sha,policy,modules,device):
    prefix=child(output,'modes/'+mode);enabled=mode in inventory['enabled_modes'];dispatch=mode==MODES[-1]
    summary=endpoint.json(child(prefix,'capture-summary.json'));observed=endpoint.json(child(prefix,'observer.json'))
    fixed={'task':TASK,'mode':mode,'native_forward_calls':1,'model_loads':0,'use_cache':False,'past_key_values_is_none':True,'returned_cache':None,
        'returned_shared_kv_states':None,'logits_to_keep':0,'native_logits_shape':[1,160,VOCABULARY],'native_logits_dtype':'torch.bfloat16',
        'targets':159,'distribution_positions':47,'unscored_native_prediction_indices':[159],'observer_enabled':enabled,'dispatcher_enabled':dispatch,'boundary_snapshots':98 if enabled else 0}
    require(all(k in summary and canonical(summary[k])==canonical(v) for k,v in fixed.items()),'complete observer native mode semantics differ')
    raw_path=endpoint.get(child(prefix,'raw-native-logits.safetensors'));raw_sha=endpoint.checked[child(prefix,'raw-native-logits.safetensors')]
    require(summary['raw_logits']=={'path':child(prefix,'raw-native-logits.safetensors'),'sha256':raw_sha,'size_bytes':raw_path.stat().st_size},'original raw reference differs')
    observed_path=endpoint.get(child(prefix,'observer.json'));require(summary['observer']=={'path':child(prefix,'observer.json'),'sha256':sha(observed_path),'size_bytes':observed_path.stat().st_size},'original observer reference differs')
    target=endpoint.json(child(prefix,'target-scores.json'));distribution=endpoint.json(child(prefix,'distributions.json'))
    base={'schema_version':1,'task':TASK,'mode':mode,'stage_spec_sha256':STAGE_SHA,'input_sha256':expected.INPUT_SHA,'raw_logits_sha256':raw_sha,
        'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':NORMALIZATION}
    for doc,kind in ((target,'observer-native-target-scores'),(distribution,'observer-native-distribution-rows')):
        require(all(k in doc and canonical(doc[k])==canonical(v) for k,v in {**base,'kind':kind}.items()),'raw-derived target/distribution provenance differs')
    scores=target['scores'];rows=distribution['positions'];require(len(scores)==159 and len(rows)==47,'exact159/47 inventory required')
    for item,coordinate in zip(scores,inventory['all_targets']):
        require(all(k in item and canonical(item[k])==canonical(v) for k,v in coordinate.items()) and type(item.get('logprob')) in (int,float) and math.isfinite(item['logprob']) and item['logprob']<=0,'exact scored target coordinate/value differs')
    selected={};positions=[]
    for item,coordinate in zip(rows,inventory['distribution_rows']):
        p=coordinate['position'];stem='dist-p%03d'%p;record=endpoint.json(child(prefix,stem+'.json'))
        wanted={k:coordinate[k] for k in ('sample','position','history','roles')};wanted.update(scores={'path':stem+'.npy','row':0},record=stem+'.json')
        require(canonical(item)==canonical(wanted) and all(k in record and canonical(record[k])==canonical(v) for k,v in {**base,**coordinate,'scores':wanted['scores'],'logprob':scores[p]['logprob']}.items()),'selected row/history/target identity differs')
        path=endpoint.get(child(prefix,stem+'.npy'));selected[p]=path
        positions.append({k:coordinate[k] for k in ('sample','position','history')}|{'scores':{'path':str(path),'row':0}})
    native=prior.raw_tensor(raw_path,[1,160,VOCABULARY]);maximum=0.0
    try:
        for p in range(160):
            if p==159:require(np.isfinite(prior.decode_bits(native[0,p])).all(),'unscored final predictor must also be finite');continue
            row=prior.independent_logprobs(native[0,p]);delta=abs(float(row[inventory['sequence'][p+1]])-scores[p]['logprob']);maximum=max(maximum,delta)
            require(delta<=ATOL,'native BF16 target logprob derivation mismatch')
            if p in selected:
                values=np.load(selected[p],allow_pickle=False,mmap_mode='r')
                try:
                    require(values.shape==(1,VOCABULARY) and values.dtype==np.dtype('float64') and np.isfinite(values).all() and np.max(values)<=0,'complete finite FP64 selected row required')
                    delta=float(np.max(np.abs(values[0]-row)));maximum=max(maximum,delta);require(delta<=ATOL,'native BF16 complete FP64 row derivation mismatch')
                    require(float(values[0,inventory['sequence'][p+1]])==scores[p]['logprob'],'selected NPY target differs')
                finally:
                    if getattr(values,'_mmap',None) is not None:values._mmap.close()
    finally:native._mmap.close()
    census=observer_metadata(observed,modules,inventory,enabled,dispatch,device);sample=None
    if enabled:
        p=endpoint.get(child(prefix,'boundary-samples.safetensors'));sample=tensor_pack(p,{x['id']:[1,47,64] for x in inventory['boundaries']})
        require(observed.get('native_samples')=={'path':child(prefix,'boundary-samples.safetensors'),'sha256':sha(p),'size_bytes':p.stat().st_size},'selected snapshot original ref differs')
    after_path=endpoint.get(child(prefix,'model-state-after.json'));require(canonical(load(after_path))==canonical(baseline),'observed persistent model state changed')
    state=endpoint.json(child(prefix,'state-control.json'));before_rng=complete_rng(state['rng_before'],True);after_rng=complete_rng(state['rng_after'])
    require(state.get('mode')==mode and canonical(before_rng)==canonical(after_rng) and canonical(state['math_policy'])==canonical(policy) and
        state.get('seed_reset',{}).get('seed')==0 and type(state['seed_reset']['seed']) is int and canonical(state['seed_reset'].get('settings'))==canonical(policy) and
        state['baseline_model_state_sha256']==baseline_sha and state['model_state_after_sha256']==sha(after_path),'same-state/full-RNG/policy provenance differs')
    return {'summary':summary,'scores':scores,'positions':positions,'samples':sample,'rng_before':before_rng,'raw_sha256':raw_sha,
        'raw_derivation_max_abs_delta':maximum,'census':census}


def inspect_output(endpoint,outer,folder):
    output=old.origin(outer['output_dir']);external=endpoint.get(outer['expected_inventory_source_path'],EXPECTED_SHA)
    geometry=[]
    for name in ('gpu-loaded-inventory.json','npu-loaded-inventory.json','config.json','modeling_gemma4_unified.py'):
        found=[p for p in outer['source_sha256'] if p.endswith('/geometry/'+name)];require(len(found)==1,'one frozen actual geometry reference required');geometry.append(endpoint.get(found[0],outer['source_sha256'][found[0]]))
    inventory=expected.verify(external,endpoint.get(outer['input_path'],expected.INPUT_SHA),endpoint.get(outer['stage_spec_source_path'],STAGE_SHA),STAGE_SHA,*geometry)
    manifest_path=endpoint.get(child(output,'artifacts-manifest.json'),outer['artifacts_manifest_sha256']);manifest=load(manifest_path)
    fixed={'schema_version':1,'kind':'observer-capture-artifacts','task':TASK,'backend':outer['backend'].lower(),'stage_spec_sha256':STAGE_SHA,'expected_inventory_sha256':EXPECTED_SHA,
        'i04_prerequisite_sha256':I04_SHA,'cpu_prerequisite_sha256':CPU_SHA,'capture_schema_version':2,'acceptance':None}
    require(all(k in manifest and canonical(manifest[k])==canonical(v) for k,v in fixed.items()),'original recursive observer manifest differs')
    files=manifest['files'];mapped={n[len(output)+1:] for n in endpoint.files if n.startswith(output+'/')}
    require(mapped==set(files)|{'artifacts-manifest.json','status.json'},'unmapped or extra source output files');paths={};total=0
    for name,item in files.items():
        prior.safe_relative(name);require(set(item)=={'sha256','size_bytes'} and type(item['size_bytes']) is int and item['size_bytes']>=0 and old.HEX.fullmatch(item['sha256']),'invalid exact artifact descriptor')
        p=endpoint.get(child(output,name),item['sha256']);require(p.stat().st_size==item['size_bytes'],'original artifact size differs');paths[name]=p;total+=item['size_bytes']
    require(total<=CAP_BYTES and sha(paths['input.json'])==expected.INPUT_SHA and sha(paths['stage-spec.json'])==STAGE_SHA and
        paths['expected-inventory.json'].read_bytes()==external.read_bytes(),'bounded capture/input/stage/expected bytes differ')
    proof_names=copy_dual(endpoint,child(output,'prerequisites/i04/prerequisite.json'),child(output,'prerequisites/cpu/prerequisite.json'),folder)
    for label,digest in [('i04',I04_SHA),('cpu',CPU_SHA)]:require(endpoint.get(outer[label+'_prerequisite_source_path'],digest).read_bytes()==paths['prerequisites/'+label+'/prerequisite.json'].read_bytes(),'premodel actual proof bytes were not retained')
    static=load(paths['observed-static-model.json']);modules=static['modules'];parameters=static['parameters']
    require(static['kind']=='actual-loaded-static-model-observation' and len(modules)==875 and len(parameters)==630 and
        len({x['name'] for x in modules})==875 and signature(modules)==inventory['module_name_class_signature_sha256'] and signature(parameters)==inventory['parameter_signature_sha256'] and
        static['actual_module_count']==875 and static['actual_named_parameter_entries']==630 and static['actual_unique_parameter_objects']==629 and
        static['tied_embedding_head_parameter_object'] is True,'actual loaded875/630/629/static signatures/tie observation differs')
    profiles=static['attention_profiles'];require(len(profiles)==48,'actual48 static attention profiles required')
    for i,x in enumerate(profiles):
        full=i in [5,11,17,23,29,35,41,47];require(x=={'layer':i,'configured_type':'full_attention' if full else 'sliding_attention',
            'q_projection_shape':[8192,3840] if full else [4096,3840],'k_projection_shape':[512,3840] if full else [2048,3840],
            'v_projection_shape':None if full else [2048,3840],'output_projection_shape':[3840,8192] if full else [3840,4096]},'actual static attention geometry differs')
    runtime=load(paths['runtime.json']);baseline=load(paths['loaded-model-state.json']);policy=runtime['math_policy'];baseline_sha=sha(paths['loaded-model-state.json'])
    require(type(baseline.get('model_object_id')) is int and baseline['model_object_id']>0 and baseline.get('class','').endswith('.Gemma4UnifiedForConditionalGeneration') and
        len(baseline['parameters'])==630 and all(flag is False for _,flag in baseline['module_training_flags']),'actual persistent model/eval state differs')
    required={'input.json','stage-spec.json','expected-inventory.json','snapshot-verification.json','observed-static-model.json','loaded-model-state.json','runtime.json',
        'policy-before-load.json','policy-after-load.json','policy-after-capture.json','capture-summary.json'}|proof_names
    if outer['backend']=='NPU':required.add('driver-version-provenance.json')
    modes={};anchor=None
    for mode in MODES:
        prefix='modes/'+mode+'/';names={'raw-native-logits.safetensors','target-scores.json','distributions.json','observer.json','capture-summary.json','model-state-after.json','state-control.json'}
        names|={'dist-p%03d%s'%(p,suffix) for p in inventory['distribution_positions'] for suffix in ('.json','.npy')}
        if mode in inventory['enabled_modes']:names.add('boundary-samples.safetensors')
        required|={prefix+n for n in names};modes[mode]=inspect_mode(endpoint,output,mode,inventory,baseline,baseline_sha,policy,modules,runtime['device_argument'])
        if anchor is None:anchor=modes[mode]['rng_before']
        require(canonical(modes[mode]['rng_before'])==canonical(anchor),'same-host seed resets differ between modes')
    require(set(files)==required and len(files)==(452 if outer['backend']=='GPU' else 453),'exact four-mode453/452 recursive inventory differs')
    coverage=buffer_coverage(baseline);gaps=coverage['unavailable_entries']
    require(canonical(runtime['buffer_content_fingerprint_coverage'])==canonical(coverage),'retained scalar buffer fingerprint gap must remain explicit')
    summary=load(paths['capture-summary.json']);wanted={'task':TASK,'modes':[modes[m]['summary'] for m in MODES],'native_forward_calls_total':4,'model_loads':1,'target_scores':636,
        'distribution_rows':188,'native_boundary_snapshots':196,'buffer_content_fingerprint_gaps':gaps,'loaded_parameter_byte_attestation':False,'acceptance':None}
    require(canonical(summary)==canonical(wanted),'aggregate native coverage/state-gap summary differs')
    status_path=endpoint.get(child(output,'status.json'));status=load(status_path)
    require(canonical(status)==canonical({'status':'completed','task':TASK,'backend':outer['backend'].lower(),'modes':MODES,'native_forward_calls_total':4,'model_loads':1,
        'artifacts_manifest_sha256':sha(manifest_path),'acceptance':None,'full_core_complete':False}),'terminal artifact/call/model identity differs')
    return {'inventory':inventory,'runtime':runtime,'paths':paths,'modes':modes,'status_path':str(status_path),'manifest_sha256':sha(manifest_path),
        'capture_product_bytes':total,'loaded_model_state_sha256':baseline_sha,'buffer_content_gaps':gaps,'static_modules':modules}

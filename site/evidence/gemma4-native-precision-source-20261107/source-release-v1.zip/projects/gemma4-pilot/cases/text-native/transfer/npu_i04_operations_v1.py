"""Stage/validate/start/query/stop only the new case-owned NPU I04 launcher.

All stage/validation operations are standard-library filesystem work. Starting
requires actual source/archive pins and the admitted I03 and CPU proofs. Stop uses an
exact saved PID, creation time and staged command; it never targets shared jobs.
"""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import signal
import subprocess
import sys
import tarfile
import time

NAME = 'i04-batch-padding-20261107'
CASE = 'projects/gemma4-pilot/cases/text-native'
LAUNCHER = CASE + '/transfer/npu_i04_launcher_v1.py'
OPERATIONS = CASE + '/transfer/npu_i04_operations_v1.py'
HELPER = CASE + '/transfer/npu_three_repeat_launcher_v4.py'
HELPER_SHA = 'c1719e831a557cd9707374138d9219a8ae887854dd029a1ec165631d9259f485'
TASK_ID = 'gemma4-gpu-npu-i04-batch-padding-v1-20261107'
UUID = 'REDACTED_DEVICE_UUID'
EXPECTED_SHA = '22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76'
PROOF_SHA = '3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c'


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2), b''):digest.update(block)
    return digest.hexdigest()


def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))


def put(path, document):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(document,stream,indent=2,allow_nan=False);stream.write('\n')


def load(path, name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module


def safe(name):
    path=PurePosixPath(name)
    require(isinstance(name,str) and name and not path.is_absolute() and '\\' not in name and str(path)==name and
        all(part not in ('','.','..') for part in name.split('/')), 'unsafe archive member')
    return path


def build(repo,output,i03_proof,cpu_proof):
    """Pure packaging requires a frozen successful actual CPUv3 wrapper."""
    repo,output=Path(repo).resolve(strict=True),Path(output)
    module=load(repo/LAUNCHER,'i04_local_package_launcher')
    require(isinstance(module.CPU_PROOF_SHA,str),'actual successful CPUv3 proof remains unready; no source package/native start')
    module.proof_ready(argparse.Namespace(cpu_prerequisite_sha256=module.CPU_PROOF_SHA,i03_prerequisite_sha256=PROOF_SHA))
    require(not output.exists() and not output.is_symlink() and output.parent.is_dir(),'new exclusive source package directory required')
    contents={}
    for name,digest in {**module.PINS,LAUNCHER:sha(repo/LAUNCHER)}.items():
        safe(name);path=repo/name
        require(path.is_file() and not path.is_symlink() and sha(path)==digest,'new reviewed package source pins differ')
        raw=path.read_bytes();require(len(raw)<=(1024**2 if name.endswith('.py') else 16*1024**2),'source/metadata payload exceeds bound')
        if name.endswith('.py'):ast.parse(raw)
        contents[name]=raw
    for label,path,relative,digest in [('i03',Path(i03_proof),module.PREREQUISITE,PROOF_SHA),
            ('cpu',Path(cpu_proof),module.CPU_PREREQUISITE,module.CPU_PROOF_SHA)]:
        require(not path.is_symlink(),'portable proof wrapper cannot be a symlink')
        path=path.resolve(strict=True)
        checked=module.load_module(repo/relative,'i04_package_'+label+'_proof').prerequisite(path,digest)
        root=PurePosixPath('prerequisites')/label
        contents[str(root/'prerequisite.json')]=path.read_bytes()
        for ref in checked['refs'].values():
            original=Path(ref['path']);name=str(root/original.relative_to(path.parent).as_posix())
            safe(name);raw=original.read_bytes();require(hashlib.sha256(raw).hexdigest()==ref['sha256'],'portable raw proof changed')
            require(name not in contents,'portable proof member collision');contents[name]=raw
    require(not any(name in sys.modules for name in ('torch','torch_npu','numpy')),'source packaging imported a framework')
    files={name:{'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw),
        'kind':'code' if name.endswith('.py') else 'metadata'} for name,raw in sorted(contents.items())}
    manifest={'schema_version':1,'task_id':TASK_ID,'files':files};manifest_raw=(json.dumps(manifest,indent=2,allow_nan=False)+'\n').encode()
    require(len(files)<=127 and sum(map(len,contents.values()))+len(manifest_raw)<=64*1024**2,'source package closure exceeds budget')
    output.mkdir(mode=0o700);archive=output/'npu-i04-source-v1.tar.gz'
    with archive.open('xb') as stream,tarfile.open(fileobj=stream,mode='w:gz') as package:
        for name,raw in [(NAME+'/source-manifest.json',manifest_raw),*[(NAME+'/source/'+name,raw) for name,raw in sorted(contents.items())]]:
            info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;package.addfile(info,io.BytesIO(raw))
    require(archive.stat().st_size<=16*1024**2,'source archive exceeds16MiB')
    result={'status':'i04_source_package_created_not_executed','archive':str(archive),'archive_bytes':archive.stat().st_size,
        'archive_sha256':sha(archive),'source_manifest_sha256':hashlib.sha256(manifest_raw).hexdigest(),'source_files':len(files),
        'cpu_prerequisite_sha256':module.CPU_PROOF_SHA,'i03_prerequisite_sha256':PROOF_SHA,'native_executions_started':0}
    put(output/'receipt.json',result);return result


def stage_archive(base, archive, archive_sha, manifest_sha):
    require(not Path(base).is_symlink(),'explicit R base cannot be a symlink')
    base,archive=Path(base).resolve(strict=True),Path(archive)
    require(archive.is_file() and not archive.is_symlink() and archive.resolve().is_relative_to(base) and
        archive.stat().st_size<=16*1024**2 and sha(archive)==archive_sha,'uploaded source archive path/SHA/size differs')
    prefix=NAME+'/'
    with tarfile.open(archive,'r:*') as package:
        members=package.getmembers();require(0<len(members)<=128 and len({member.name for member in members})==len(members),'duplicate/excess source members')
        require(sum(member.size for member in members)<=64*1024**2,'expanded source budget exceeded')
        data={}
        for member in members:
            safe(member.name)
            require(member.name.startswith(prefix) and member.isfile() and not member.issym() and not member.islnk() and
                0<=member.size<=16*1024**2,'source archive must contain bounded regular files')
            raw=package.extractfile(member).read(member.size+1);require(len(raw)==member.size,'source archive member truncated')
            data[member.name]=raw
    manifest_raw=data[prefix+'source-manifest.json']
    require(hashlib.sha256(manifest_raw).hexdigest()==manifest_sha,'external source manifest SHA differs')
    manifest=json.loads(manifest_raw)
    require(manifest.get('schema_version')==1 and manifest.get('task_id')==TASK_ID and
        set(data)=={prefix+'source/'+name for name in manifest['files']}|{prefix+'source-manifest.json'},'source member/manifest closure differs')
    names=set(data)
    require(all(not any(str(parent) in names for parent in PurePosixPath(name).parents if str(parent) != '.') for name in names),'archive file/ancestor collision')
    for name,ref in manifest['files'].items():
        safe(name);raw=data[prefix+'source/'+name]
        require(set(ref)=={'sha256','size_bytes','kind'} and ref['kind']==('code' if name.endswith('.py') else 'metadata') and
            type(ref['size_bytes']) is int and len(raw)==ref['size_bytes'] <= (1024**2 if ref['kind']=='code' else 16*1024**2) and
            hashlib.sha256(raw).hexdigest()==ref['sha256'],'source/metadata classification or bytes differ')
        if ref['kind']=='code':ast.parse(raw)
    for name,raw in data.items():
        target=base/name;require(target.resolve().is_relative_to(base),'source target escapes R')
        current=target
        while current!=base:
            require(not current.is_symlink(),'source target ancestor is symlink');current=current.parent
        if target.exists():require(target.is_file() and target.read_bytes()==raw,'existing source differs; never overwritten')
        else:
            target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as stream:stream.write(raw)
    return {'source_manifest_sha256':manifest_sha,'source_files':len(manifest['files']),
            'archive_sha256':archive_sha,'native_model_started':False}


def configuration(base, manifest_sha):
    base=Path(base).resolve(strict=True);task=base/NAME;source=task/'source';manifest=task/'source-manifest.json'
    require(task.is_dir() and not task.is_symlink() and source.resolve().is_relative_to(task) and not source.is_symlink() and
        manifest.is_file() and not manifest.is_symlink() and sha(manifest)==manifest_sha,'staged new I04 task/source manifest differs')
    document=read(manifest);launcher=source/LAUNCHER
    require(sha(__file__)==document['files'][OPERATIONS]['sha256'], 'executed operations source differs from frozen staged copy')
    require(launcher.is_file() and not launcher.is_symlink() and sha(launcher)==document['files'][LAUNCHER]['sha256'],'staged launcher source differs')
    module=load(launcher,'i04_operations_frozen_launcher')
    args=argparse.Namespace(task_root=task,source_root=source,model=base/'model-download-v1/snapshot',
        allocation=base/'allocation-20261106-b.json',native_mapping=base/'native-mapping-20261106-b.json',
        native_source=base/'native-preflight-20261106-b.json',driver_source=Path('/usr/local/Ascend/driver/version.info'),
        source_manifest=manifest,source_manifest_sha256=manifest_sha,npu_smi=Path('/srv/precision-user/.local/bin/npu-smi'),
        npu_smi_sha256='22feac701ab31bf5cc8c68244a4d529cf8b4060a8dd95bd3888c65247eda7cf3',
        expected_inventory_sha256=EXPECTED_SHA,
        i03_prerequisite=source/'prerequisites/i03/prerequisite.json',i03_prerequisite_sha256=PROOF_SHA,
        cpu_prerequisite=source/'prerequisites/cpu/prerequisite.json',cpu_prerequisite_sha256=module.CPU_PROOF_SHA)
    return module,args


def validate(base, manifest_sha):
    module,args=configuration(base,manifest_sha)
    helper,allocation,files=module.source_check(args)
    expected=module.load_module(args.source_root/module.EXPECTED,'i04_operations_independent_expected')
    document=expected.derive(module.read(args.source_root/module.INPUT),module.read(args.source_root/module.INPUT_B),
        module.PINS[module.INPUT],module.PINS[module.INPUT_B],module.STAGE_SHA)
    raw=(json.dumps(document,indent=2,allow_nan=False)+'\n').encode()
    require(len(raw)==1082939 and hashlib.sha256(raw).hexdigest()==EXPECTED_SHA,'independent I04 expected JSON bytes differ')
    require(not any(name in sys.modules for name in ('torch','torch_npu','numpy')),'filesystem validation imported a framework')
    return module,args,{'status':'i04_filesystem_i03_and_cpu_prerequisites_checked','source_files_checked':len(files),
        'expected_inventory_sha256':EXPECTED_SHA,'i03_prerequisite_sha256':PROOF_SHA,'cpu_prerequisite_sha256':module.CPU_PROOF_SHA,'source_manifest_sha256':manifest_sha,
        'runtime_uuid_binding':allocation['physical_device_id'],'native_model_started':False,'native_device_initialized':False}


def start(base, manifest_sha):
    module,args,verified=validate(base,manifest_sha)
    claim=args.task_root/'claims'/('npu-i04-'+UUID)
    require(not claim.exists() and not claim.is_symlink(),'permanent I04 claim already exists; never retry')
    python=Path(base)/'venv/bin/python';require(python.is_file(),'original verified NPU interpreter missing')
    run=args.task_root/'runs'/('compare-i04-launch-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));run.mkdir(parents=True)
    argv=module.argv_copy(args);argv[0]=str(python)
    # Separate from the native claim: even a failed Popen is a spent start.
    put(args.task_root/'launch-once.json',{'status':'launch_attempt_claimed_not_result','started_utc':datetime.now(timezone.utc).isoformat(),
        'run':str(run),'argv':argv,'source_manifest_sha256':manifest_sha,'automatic_retry':False})
    env=dict(os.environ)
    for name in ('PYTHONPATH','PYTHONHOME'):env.pop(name,None)
    env.update(PYTHONHASHSEED='0',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    with (run/'stdout.bin').open('xb') as out,(run/'stderr.bin').open('xb') as err:
        process=subprocess.Popen(argv,stdout=out,stderr=err,stdin=subprocess.DEVNULL,cwd=args.source_root,env=env,start_new_session=True)
    try:creation=int((Path('/proc')/str(process.pid)/'stat').read_text().rpartition(')')[2].split()[19])
    except FileNotFoundError:creation=None
    receipt={'status':'launcher_spawned_not_result','started_utc':datetime.now(timezone.utc).isoformat(),'pid':process.pid,
        'starttime':creation,'immediate_child_returncode':process.poll(),'argv':argv,'claim':str(claim),'preflight':verified,
        'launcher_sha256':sha(args.source_root/LAUNCHER),'operations_source_sha256':sha(__file__),
        'source_manifest_sha256':manifest_sha,'max_native_model_processes':1,'max_forward_calls':4,
        'capture_timeout_seconds':1200,'whole_timeout_seconds':3000,'automatic_retry':False,'cpu_prerequisite_sha256':module.CPU_PROOF_SHA,'acceptance':None}
    put(run/'start-receipt.json',receipt)
    return {'status':receipt['status'],'pid':process.pid,'start_receipt':str(run/'start-receipt.json'),
            'start_receipt_sha256':sha(run/'start-receipt.json')}


def query(base):
    claim=Path(base)/NAME/'claims'/('npu-i04-'+UUID);result=[]
    for name in ('controller-receipt.json','capture-receipt.json','generic-receipt-reference.json'):
        path=claim/name
        if not path.is_file():result.append({'path':str(path),'present':False});continue
        document=read(path)
        result.append({'path':str(path),'sha256':sha(path),'status':document.get('status'),'returncode':document.get('returncode'),
            'timed_out':document.get('timed_out'),'remaining_descendants':document.get('remaining_descendants'),
            'output_dir':document.get('output_dir'),'native_forward_calls_total':document.get('native_forward_calls_total'),
            'model_loads':document.get('model_loads'),'artifacts_manifest_sha256':document.get('artifacts_manifest_sha256')})
    return result


def stop_owned(base, receipt_path, receipt_sha):
    task=Path(base)/NAME;receipt_path=Path(receipt_path)
    require(receipt_path.resolve().is_relative_to((task/'runs').resolve()) and not receipt_path.is_symlink() and
            sha(receipt_path)==receipt_sha,'actual exclusive I04 launch receipt path/hash required')
    start_receipt=read(receipt_path);pid,creation=start_receipt['pid'],start_receipt['starttime']
    helper_path=task/'source'/HELPER;require(sha(helper_path)==HELPER_SHA,'owned-process helper source differs')
    helper=load(helper_path,'i04_operations_owned_process_helpers');row=helper.proc_table().get(pid)
    if row is None or row['start']!=creation or row['state']=='Z':return {'status':'recorded_launcher_not_running','signals_sent':0}
    command=(Path('/proc')/str(pid)/'cmdline').read_bytes().split(b'\0')
    require(str(task/'source'/LAUNCHER).encode() in command and str(task).encode() in command,'recorded PID command is not this staged I04 launcher')
    owned={pid:creation};sent=[]
    def living():
        table=helper.proc_table()
        while True:
            added={p:r['start'] for p,r in table.items() if p not in owned and r['ppid'] in owned and table.get(r['ppid'],{}).get('start')==owned[r['ppid']]}
            if not added:break
            owned.update(added)
        return {p:r for p,r in table.items() if p in owned and r['start']==owned[p] and r['state']!='Z'}
    living();fresh=helper.proc_table().get(pid)
    require(fresh and fresh['start']==creation,'launcher already exited; never signal a reused PID')
    os.kill(pid,signal.SIGTERM);sent.append({'pid':pid,'creation':creation,'signal':'TERM'})
    deadline=time.monotonic()+20
    while living() and time.monotonic()<deadline:time.sleep(.1)
    for target in living():
        current=helper.proc_table().get(target)
        if current and current['start']==owned[target]:
            try:os.kill(target,signal.SIGKILL);sent.append({'pid':target,'creation':owned[target],'signal':'KILL'})
            except ProcessLookupError:pass
    deadline=time.monotonic()+3
    while living() and time.monotonic()<deadline:time.sleep(.1)
    result={'status':'owned_stop_checked','utc':datetime.now(timezone.utc).isoformat(),'launch_receipt':str(receipt_path),
        'launch_receipt_sha256':receipt_sha,'owned_creation_times':owned,'signals':sent,
        'remaining_owned_non_zombie':sorted(living()),'claim_preserved':True,'shared_instance_stopped':False}
    output=receipt_path.parent/'owned-stop-receipt.json';put(output,result)
    return {'receipt':str(output),'sha256':sha(output),'remaining_owned':result['remaining_owned_non_zombie']}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('mode',choices=['build','stage','validate','start','query','stop'])
    parser.add_argument('--base',type=Path);parser.add_argument('--archive',type=Path);parser.add_argument('--archive-sha256')
    for name in ('repo','output','i03-proof','cpu-proof'):parser.add_argument('--'+name,type=Path)
    parser.add_argument('--source-manifest-sha256');parser.add_argument('--start-receipt',type=Path);parser.add_argument('--start-receipt-sha256')
    args=parser.parse_args()
    if args.mode=='build':
        require(all(value is not None for value in (args.repo,args.output,args.i03_proof,args.cpu_proof)),'actual source/proof paths required')
        result=build(args.repo,args.output,args.i03_proof,args.cpu_proof)
        print(json.dumps(result,indent=2,allow_nan=False),flush=True);return
    require(args.base is not None and not args.base.is_symlink(),'explicit nonsymlink original R required')
    base=args.base.resolve(strict=True)
    if args.mode=='stage':
        require(args.archive is not None and args.archive_sha256 and args.source_manifest_sha256,'actual package pins required')
        staged=stage_archive(base,args.archive,args.archive_sha256,args.source_manifest_sha256)
        _,_,checked=validate(base,args.source_manifest_sha256);result={**staged,**checked}
    elif args.mode=='validate':require(args.source_manifest_sha256,'actual source manifest SHA required');result=validate(base,args.source_manifest_sha256)[2]
    elif args.mode=='start':require(args.source_manifest_sha256,'actual source manifest SHA required');result=start(base,args.source_manifest_sha256)
    elif args.mode=='query':result=query(base)
    else:
        require(args.start_receipt is not None and args.start_receipt_sha256,'actual saved launch receipt/hash required')
        result=stop_owned(base,args.start_receipt,args.start_receipt_sha256)
    print(json.dumps(result,indent=2,allow_nan=False),flush=True)


if __name__=='__main__':main()

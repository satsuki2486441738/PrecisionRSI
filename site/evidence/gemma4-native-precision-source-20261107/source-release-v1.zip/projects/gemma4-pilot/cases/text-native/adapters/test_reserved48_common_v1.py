"""CPU streaming tests; fake tensors are labelled and never native evidence."""
import hashlib
import importlib.util
import math
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import numpy as np
import reserved48_common_v1 as common

SCRIPTS = common.REPO / 'skills/precision-compare/scripts'
sys.path.insert(0, str(SCRIPTS))
from inference_capture import derive_logprobs


class ArrayResult:
    def __init__(self, array): self.array = array
    def numpy(self): return self.array


class FakeTensor:
    """CPU uint16-backed fixture only; real Torch fixture is separately skipped/run."""
    def __init__(self, bits, device='cuda:0'):
        self.bits = np.asarray(bits, dtype=np.uint16); self.device = device; self.dtype = 'torch.bfloat16'
    @property
    def shape(self): return self.bits.shape
    def __getitem__(self, key): return FakeTensor(self.bits[key], self.device)
    def detach(self): return self
    def to(self, *, device, non_blocking, copy):
        if (device, non_blocking, copy) != ('cpu', False, True): raise AssertionError('expected synchronous copied slab')
        return FakeTensor(self.bits.copy(), 'cpu')
    def contiguous(self): return self
    def double(self): return ArrayResult((self.bits.astype('<u4') << 16).view('<f4').astype(np.float64))
    def view(self, dtype):
        if dtype != 'fixture-uint16': raise AssertionError('BF16 view dtype differs')
        return ArrayResult(self.bits)
    def clone(self): return FakeTensor(self.bits.copy(), self.device)


def bits(values): return (np.asarray(values, dtype='<f4').view('<u4') >> 16).astype('<u2')


class StreamTests(unittest.TestCase):
    def fixture(self, length=65, vocabulary=7):
        values = (np.arange(length * vocabulary).reshape(1, length, vocabulary) % 19 - 9).astype(np.float32)
        tensor = FakeTensor(bits(values)); row = {'L': length, 'sample': 'fixture-only', 'sequence': [i % vocabulary for i in range(length)],
            'positions': [0, 31, 32, 63] if length == 65 else [0]}
        return tensor, row

    def test_32_row_stream_clone_and_source_scalars(self):
        tensor, row = self.fixture(); selected, targets, digests = {}, [], []; shapes = []
        def shared(values, dtype): shapes.append(values.shape); return derive_logprobs(values, dtype=dtype)
        original = tensor.bits.copy(); digest = hashlib.sha256()
        with patch.object(common, 'VOCABULARY', 7):
            common.stream_logits(tensor, 0, row, SimpleNamespace(uint16='fixture-uint16'), np, shared,
                                 selected, targets, digests, digest)
        self.assertEqual(shapes, [(32, 7), (32, 7)])
        self.assertEqual((len(digests), len(targets)), (65, 64))
        self.assertEqual(digest.hexdigest(), hashlib.sha256(original.astype('<u2').tobytes()).hexdigest())
        tensor.bits.fill(0x7f80)
        for position, retained in selected.items(): np.testing.assert_array_equal(retained.bits, original[0, position])
        for index, score in enumerate(targets):
            values = (original[0, index].astype('<u4') << 16).view('<f4').astype(np.float64)
            normalizer = max(values) + math.log(math.fsum(math.exp(float(x - max(values))) for x in values))
            self.assertAlmostEqual(score['source_logsumexp'], normalizer, places=12)
            self.assertEqual(score['position'], index + 1)
            self.assertAlmostEqual(score['logprob'], float(values[row['sequence'][index + 1]]) - normalizer, places=12)

    def test_unscored_last_row_nonfinite_is_rejected(self):
        tensor, row = self.fixture(); tensor.bits[0, -1, 0] = 0x7f80
        with patch.object(common, 'VOCABULARY', 7):
            with self.assertRaisesRegex(ValueError, 'unscored final'):
                common.stream_logits(tensor, 0, row, SimpleNamespace(uint16='fixture-uint16'), np, derive_logprobs,
                                     {}, [], [], hashlib.sha256())

    def test_disjoint_calls_and_duplicate_gap_detection(self):
        tensor, row = self.fixture(); selected, targets, digests = {}, [], []; digest = hashlib.sha256()
        with patch.object(common, 'VOCABULARY', 7):
            common.stream_logits(tensor[:, :17, :], 0, row, SimpleNamespace(uint16='fixture-uint16'), np, derive_logprobs,
                                 selected, targets, digests, digest)
            common.stream_logits(tensor[:, 17:, :], 17, row, SimpleNamespace(uint16='fixture-uint16'), np, derive_logprobs,
                                 selected, targets, digests, digest)
            with self.assertRaisesRegex(ValueError, 'gap/overlap'):
                common.stream_logits(tensor[:, :1, :], 0, row, SimpleNamespace(uint16='fixture-uint16'), np, derive_logprobs,
                                     selected, targets, digests, digest)
        self.assertEqual(len(targets), 64)

    def test_actual_numpy_32_by_full_vocabulary_derivation(self):
        original = np.zeros((32, 262144), dtype=np.float64)
        normalized = derive_logprobs(original, dtype='float64')
        self.assertEqual(normalized.shape, original.shape); self.assertEqual(normalized.dtype, np.float64)
        self.assertTrue(np.isfinite(normalized).all()); self.assertTrue((original == 0).all())
        self.assertLess(float(np.max(np.abs(normalized + math.log(262144)))), 1e-14)

    def test_oom_is_a_failure_without_fabricated_unexecuted_rows(self):
        tensor, row = self.fixture(); targets, digests, selected = [], [], {}
        def oom(values, dtype): raise MemoryError('fixture OOM')
        with patch.object(common, 'VOCABULARY', 7):
            with self.assertRaises(MemoryError):
                common.stream_logits(tensor, 0, row, SimpleNamespace(uint16='fixture-uint16'), np, oom,
                                     selected, targets, digests, hashlib.sha256())
        self.assertEqual((targets, digests, selected), ([], [], {}))

    @unittest.skipUnless(importlib.util.find_spec('torch') is not None, 'actual Torch2.9 CPU roundtrip remains required before freeze')
    def test_actual_torch_cpu_bf16_slab_bits_and_clone(self):
        import torch
        self.assertTrue(str(torch.__version__).startswith('2.9.0'))
        value = torch.tensor([[[0.0, -0.0, 1.0, -2.0, 0.125, 3.5, -4.25], [1.0] * 7]], dtype=torch.bfloat16, device='cpu')
        raw = value.view(torch.uint16).numpy().copy(); row = {'L': 2, 'sample': 'actual-tiny-CPU', 'sequence': [2, 0], 'positions': [0]}
        selected = {}; scores = []; digests = []
        with patch.object(common, 'VOCABULARY', 7):
            common.stream_logits(value, 0, row, torch, np, derive_logprobs, selected, scores, digests, hashlib.sha256())
        value.fill_(10)
        np.testing.assert_array_equal(selected[0].view(torch.uint16).numpy(), raw[0, 0])
        self.assertEqual(digests[0]['sha256'], hashlib.sha256(raw[0, 0].astype('<u2').tobytes()).hexdigest())
        from safetensors.torch import save_file, load_file
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'tiny-selected.safetensors'
            save_file({'logits': selected[0].reshape(1, 7)}, str(path), metadata={'scope': 'actual tiny CPU API probe, no model'})
            loaded = load_file(str(path), device='cpu')['logits']
            self.assertEqual(list(loaded.shape), [1, 7]); self.assertEqual(loaded.dtype, torch.bfloat16)
            np.testing.assert_array_equal(loaded.view(torch.uint16).numpy()[0], raw[0, 0])
        scalar = torch.tensor(-0.0, dtype=torch.bfloat16, device='cpu')
        model = SimpleNamespace(named_buffers=lambda remove_duplicate: [('scalar', scalar)])
        controlled = SimpleNamespace(model_state=lambda *args: {'buffers': [{'name': 'scalar',
            'content_probe_gap': {'error_type': 'RuntimeError', 'error': 'synthetic historical scalar-view gap'}}]})
        observation = common.observed_model_state(model, torch, controlled)['buffers'][0]
        self.assertEqual(observation['content_sha256'], hashlib.sha256(b'\x00\x80').hexdigest())
        self.assertIn('prior_helper_content_probe_gap', observation); self.assertNotIn('content_probe_gap', observation)


class CacheAndWriterTests(unittest.TestCase):
    def cache(self, consumed=8224):
        types = ['sliding_attention'] * 40 + ['full_attention'] * 8
        layers = []
        for kind in types:
            length, heads, width = (1023, 8, 256) if kind == 'sliding_attention' else (consumed, 1, 512)
            tensor = lambda: SimpleNamespace(shape=[1, heads, length, width], dtype='torch.bfloat16', device='npu:0')
            layers.append(SimpleNamespace(get_seq_length=lambda: consumed, is_sliding=kind == 'sliding_attention',
                sliding_window=1024, keys=tensor(), values=tensor()))
        return SimpleNamespace(layers=layers, offloading=False, get_seq_length=lambda: consumed), types

    def test_cache_sliding_trim_is_metadata_not_value_equivalence(self):
        cache, types = self.cache(); controlled = SimpleNamespace(tensor_metadata=lambda t: {'shape': t.shape})
        result = common.cache_metadata(cache, 8224, types, controlled, 'npu:0')
        self.assertEqual(result['layers'][0]['keys']['shape'][-2], 1023)
        self.assertEqual(result['layers'][-1]['keys']['shape'][-2], 8224)
        cache.layers[0].is_sliding = False
        with self.assertRaisesRegex(ValueError, 'sliding-window provenance'): common.cache_metadata(cache, 8224, types, controlled, 'npu:0')

    def test_wrong_logical_prefix_or_full_cache_length_rejected(self):
        cache, types = self.cache(); controlled = SimpleNamespace(tensor_metadata=lambda t: {'shape': t.shape})
        cache.layers[0].get_seq_length = lambda: 1023
        with self.assertRaisesRegex(ValueError, 'logical consumed'): common.cache_metadata(cache, 8224, types, controlled, 'npu:0')
        cache, types = self.cache(); cache.layers[-1].keys.shape[-2] = 8223
        with self.assertRaisesRegex(ValueError, 'unexpectedly clipped'): common.cache_metadata(cache, 8224, types, controlled, 'npu:0')

    def test_writer_no_overwrite_and_counted_storage(self):
        with tempfile.TemporaryDirectory() as tmp:
            limits = {'bin_product_bytes': 256, 'mode_product_bytes': 64, 'input_product_bytes': 128,
                      'minimum_source_free_bytes': 0}
            writer = common.Writer(Path(tmp) / 'new', limits)
            writer.put('s/m/first.json', {'ok': True}, 's/m', 's')
            with self.assertRaisesRegex(ValueError, 'already exists'): writer.put('s/m/first.json', {'ok': False}, 's/m', 's')
            with self.assertRaisesRegex(ValueError, 'cap exceeded'): writer.put('s/m/second.json', {'long': 'x' * 80}, 's/m', 's')
            self.assertEqual(len(writer.files), 1)
            with self.assertRaisesRegex(ValueError, 'contained'): writer.target('../escape')

    def test_parameter_versions_and_storage_are_part_of_invariant(self):
        first = {'model_object_id': 4, 'class': 'fixture', 'config': {}, 'module_training_flags': [['', False]],
                 'parameters': [{'version': 0, 'storage': {'data_ptr': 10}}], 'buffers': []}
        import copy
        second = copy.deepcopy(first); second['parameters'][0]['version'] = 1
        self.assertNotEqual(common.parameter_invariant(first), common.parameter_invariant(second))
        second = copy.deepcopy(first); second['parameters'][0]['storage']['data_ptr'] = 11
        self.assertNotEqual(common.parameter_invariant(first), common.parameter_invariant(second))
        first['buffers'] = [{'name': 'scalar', 'content_sha256': '0' * 64}]
        rng = {'python': {'sha256': '1' * 64}}
        common.check_mode_state(first, first, first, rng, rng)
        with self.assertRaisesRegex(ValueError, 'RNG advanced'):
            common.check_mode_state(first, first, first, rng, {'python': {'sha256': '2' * 64}})
        second = copy.deepcopy(first); second['buffers'][0]['content_sha256'] = '3' * 64
        with self.assertRaisesRegex(ValueError, 'loaded baseline'): common.check_mode_state(first, first, second, rng, rng)
        with self.assertRaisesRegex(ValueError, 'loaded baseline'): common.check_mode_state(first, second, first, rng, rng)
        incomplete = copy.deepcopy(first); incomplete['buffers'][0].pop('content_sha256')
        with self.assertRaisesRegex(ValueError, 'fingerprints unavailable'): common.check_model_state(incomplete, incomplete)


if __name__ == '__main__': unittest.main()

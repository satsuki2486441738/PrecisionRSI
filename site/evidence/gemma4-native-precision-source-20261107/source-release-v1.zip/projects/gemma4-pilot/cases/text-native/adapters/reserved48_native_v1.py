"""Draft parameterized GPU/NPU entry for one reserved48 twelve-input bin.

The stdlib gate runs before framework imports or hardware queries. No capture
can start until actual new stage/proof/budget/outer-lifecycle pins are reviewed.
This entry uses the original verified loader and backend policies, without
altering model configuration. Native execution is deliberately not ready.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import json
import os
from pathlib import Path
import sys

import reserved48_common_v1 as common


def import_reviewed_helpers():
    """Load only the unchanged reviewed helpers after the pure gate succeeds."""
    sys.path.insert(0, str(common.HERE)); sys.path.insert(0, str(common.HERE.parent / 'transfer'))
    for name in ('i01_common_v1', 'i03_common_v1', 'i03_prerequisite_v1', 'pilot_gpu_torch290_candidate',
                 'pilot_gpu_peer_v2', 'pilot_ascend_candidate_v3', 'verify_snapshot', 'npu_three_repeat_launcher_v4'):
        if name in sys.modules:
            expected = (common.HERE.parent / 'transfer' if name == 'npu_three_repeat_launcher_v4' else common.HERE) / (name + '.py')
            common.require(Path(sys.modules[name].__file__).resolve() == expected.resolve(), 'preloaded helper path differs: ' + name)
    import i03_common_v1 as controlled
    from npu_three_repeat_launcher_v4 import memory_observation
    controlled.prior.check_import_paths()
    common.require(Path(controlled.__file__).resolve() == (common.HERE / 'i03_common_v1.py').resolve(), 'controlled helper path differs')
    for name, digest in common.OLD_PINS.items(): common.require(common.sha(common.REPO / name) == digest, 'reviewed helper changed during import')
    return controlled, memory_observation


def gpu_environment(args, context, memory_observation):
    from pilot_gpu_torch290_candidate import check_allocation, check_device, check_stack, POLICY_SHA256
    from pilot_gpu_peer_v2 import seed_and_check, math_policy, check_policy
    allocation = common.read(args.allocation_receipt); check_allocation(allocation)
    common.require(common.sha(args.numerics_policy) == POLICY_SHA256, 'original GPU math policy differs')
    policy = common.read(args.numerics_policy)
    memory = memory_observation()
    common.require(memory['effective_available_bytes'] >= context['budget']['limits']['minimum_gpu_host_effective_available_bytes'],
                   'GPU host/cgroup free-memory guard failed')
    import torch
    import numpy
    import transformers
    from transformers import AutoModelForMultimodalLM
    versions = {'torch': str(torch.__version__), 'transformers': str(transformers.__version__),
                'cuda_runtime': str(torch.version.cuda), 'numpy': str(numpy.__version__)}
    check_stack(versions); props, physical, free, total = check_device(torch, allocation)
    common.require(free >= context['budget']['limits']['minimum_free_device_bytes'], 'reviewed GPU free-memory guard failed')
    initial = seed_and_check(torch, numpy, policy)
    def seed(): return seed_and_check(torch, numpy, policy)
    def observe():
        actual = math_policy(torch); check_policy(actual, policy); return actual
    return {'torch': torch, 'numpy': numpy, 'transformers': transformers, 'loader': AutoModelForMultimodalLM,
        'seed': seed, 'policy': observe, 'synchronize': lambda: torch.cuda.synchronize(0),
        'metadata': {'backend': 'gpu', 'versions': versions, 'physical_runtime_uuid': physical, 'device_name': props.name,
            'instance_visible_count': 1, 'compute_device_count': 1, 'tensor_parallel_size': 1,
            'free_bytes_before_load': free, 'total_bytes': total, 'host_memory': memory,
            'visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES'), 'initial_seed_and_policy': initial,
            'numerics_policy_sha256': POLICY_SHA256}}


def npu_environment(args, context, memory_observation):
    from pilot_ascend_candidate_v3 import (check_allocation, check_stack, check_version,
        normalize_runtime_uuid, observe_driver_version, set_policy, get_policy)
    from npu_three_repeat_launcher_v4 import binding
    allocation, physical = binding(args.allocation_receipt, args.native_mapping, args.native_source)
    check_allocation(allocation, 0)
    memory = memory_observation()
    common.require(memory['effective_available_bytes'] >= context['budget']['limits']['minimum_npu_host_effective_available_bytes'],
                   'NPU host/cgroup free-memory guard failed')
    import torch
    import torch_npu
    import numpy
    import transformers
    from transformers import AutoModelForMultimodalLM
    npu = torch_npu.npu
    driver, provenance = observe_driver_version(torch_npu.utils.get_cann_version, args.driver_source)
    versions = {'torch': str(torch.__version__), 'torch_npu': str(torch_npu.__version__), 'transformers': str(transformers.__version__),
        'numpy': str(numpy.__version__), 'cann': check_version('CANN', torch_npu.utils.get_cann_version('CANN')), 'driver': driver}
    check_stack(versions)
    common.require(versions == {'torch': '2.9.0+cpu', 'torch_npu': '2.9.0.post2', 'transformers': '5.10.1',
        'numpy': '1.26.4', 'cann': '9.1.0', 'driver': '25.5.2'}, 'original NPU stack differs')
    common.require(npu.is_available() and npu.device_count() == 8, 'eight-visible-device NPU allocation unavailable')
    npu.set_device(0); common.require(npu.current_device() == 0 and npu.is_bf16_supported(), 'single NPU ordinal0/BF16 differs')
    actual = normalize_runtime_uuid(getattr(npu.get_device_properties(0), 'uuid', None)); free, total = map(int, npu.mem_get_info(0))
    common.require(actual == physical and free >= context['budget']['limits']['minimum_free_device_bytes'], 'native NPU UUID/free-memory guard failed')
    before, configured = set_policy(torch, npu, numpy)
    def seed():
        previous, current = set_policy(torch, npu, numpy); common.require(current == configured, 'NPU policy changed during reset')
        return {'seed': 0, 'before': previous, 'settings': current}
    def observe():
        current = get_policy(torch, npu); common.require(current == configured, 'NPU policy changed'); return current
    return {'torch': torch, 'numpy': numpy, 'transformers': transformers, 'torch_npu': torch_npu,
        'loader': AutoModelForMultimodalLM, 'seed': seed, 'policy': observe, 'synchronize': lambda: npu.synchronize(0),
        'metadata': {'backend': 'npu', 'versions': versions, 'physical_runtime_uuid': actual, 'device_name': npu.get_device_name(0),
            'instance_visible_count': 8, 'compute_device_count': 1, 'tensor_parallel_size': 1,
            'free_bytes_before_load': free, 'total_bytes': total, 'host_memory': memory,
            'initial_seed_and_policy': {'before': before, 'settings': configured}, 'driver_version_provenance': provenance,
            'visible_device_env': {key: os.environ.get(key) for key in ('ASCEND_RT_VISIBLE_DEVICES', 'ASCEND_VISIBLE_DEVICES')}}}


def main():
    args = common.arguments()
    common.require(Path(common.__file__).resolve() == (Path(__file__).resolve().parent / 'reserved48_common_v1.py'), 'common import path differs')
    context = common.prepare(args, __file__)  # None gates refuse here, before any framework/helper/device work.
    seconds = context['budget']['limits']['native_seconds_by_prompt_bin'][str(args.prompt_bin)]
    with common.bounded_native(seconds):
        controlled, memory_observation = import_reviewed_helpers()
        environment = (gpu_environment if args.backend == 'gpu' else npu_environment)(args, context, memory_observation)
        torch, numpy = environment['torch'], environment['numpy']
        common.check_refs(context['refs'])
        writer = common.Writer(args.output, context['budget']['limits'])
        writer.put('policy-before-load.json', environment['policy']())
        model, identity = controlled.prior.load_verified_model(args, torch, environment['loader'], common.read(common.HERE / 'upstream-identity.json'))
        writer.adopt(args.output / 'snapshot-verification.json'); writer.adopt(args.output / 'loaded-model-inventory.json')
        writer.put('policy-after-load.json', environment['policy']())
        config = model.config.text_config
        common.require(config.max_position_embeddings == common.CONTEXT_LIMIT and len(config.layer_types) == 48 and
            config.layer_types.count('sliding_attention') == 40 and config.layer_types.count('full_attention') == 8 and
            config.sliding_window == 1024 and config.num_kv_shared_layers == 0 and config.vocab_size == common.VOCABULARY,
            'loaded context/cache/model configuration differs from retained official bytes')
        import transformers.cache_utils as cache_utils
        import transformers.masking_utils as masking_utils
        import safetensors.torch as serialization
        runtime_refs = {'package/torch': common.ref(torch.__file__), 'package/numpy': common.ref(numpy.__file__),
            'package/transformers': common.ref(environment['transformers'].__file__), 'implementation/modeling': identity['modeling_source'],
            'implementation/cache_utils': common.ref(cache_utils.__file__), 'implementation/masking_utils': common.ref(masking_utils.__file__),
            'implementation/safetensors_torch': common.ref(serialization.__file__)}
        if args.backend == 'npu': runtime_refs['package/torch_npu'] = common.ref(environment['torch_npu'].__file__)
        # Keep ephemeral runtime files and every pre-native proof/source byte in the new output before a GPU app may stop.
        runtime_copies = common.runtime_sources(writer, dict(context['refs'], **runtime_refs))
        summaries = common.capture_all(model, torch, numpy, controlled, args, context, writer,
                                      environment['seed'], environment['policy'], environment['synchronize'])
        environment['synchronize'](); writer.put('policy-after-capture.json', environment['policy']())
        runtime = dict(environment['metadata'], schema_version=1, task=common.TASK, prompt_bin=args.prompt_bin,
            model_identity=identity, model_loads=1, device_argument=args.device, seed=0, runtime_sources=runtime_copies,
            native_observations=summaries, allocation_receipt=common.ref(args.allocation_receipt),
            source_manifest=common.ref(args.source_manifest), expected_inventory=common.ref(args.expected_inventory),
            prerequisite=common.ref(args.prerequisite), stage_spec=common.ref(args.stage_spec), budget=common.ref(args.budget),
            python=sys.version, python_executable=sys.executable, instrumentation=True,
            normalization_scope='Source NumPy FP64 streaming full-vocabulary derivation; only47 native BF16 rows per observation retained',
            scope='English train-reserved articles; one bin of12; I05/Q01 only; no kernel equivalence/quality preservation/performance acceptance')
        print(json.dumps(common.finalize(args, context, writer, runtime), allow_nan=False), flush=True)


if __name__ == '__main__': main()

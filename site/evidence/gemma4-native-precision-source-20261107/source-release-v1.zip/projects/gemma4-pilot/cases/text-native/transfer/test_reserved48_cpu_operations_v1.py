"""Pure process/source protocol regressions, never actual Torch/native proof."""
import copy
import ast
from contextlib import redirect_stdout
import hashlib
import importlib.util
import json
import io
import os
import re
from pathlib import Path
import signal
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('reserved48_cpu_protocol_under_test', HERE / 'reserved48_cpu_operations_v1.py')
tool = importlib.util.module_from_spec(spec); spec.loader.exec_module(tool)
REPO = HERE.parents[4]


def probe_fixture():
    """Synthetic metadata shape only; never persisted as actual successful proof."""
    phases = [{'phase': name, 'torch_npu_imported': False, 'npu_namespace_registered': False,
               'npu_initialized': None, 'cuda_initialized': False} for name in
              ('after_torch', 'after_runtime_imports', 'before_tests', 'after_tests', 'after_tiny_roundtrip')]
    return {'status': 'completed', 'returncode': 0, 'timeout_seconds': 90,
        'source': {'sha256': tool.FROZEN[tool.PROBE]}, 'operations_source': {'sha256': tool.sha(tool.__file__)},
        'versions': {'torch': '2.9.0+cpu', 'numpy': '1.26.4', 'safetensors': 'synthetic'},
        'tests': {'run': 23, 'skipped': 0, 'failures': 0, 'errors': 0, 'real_torch_BF16_fixture_enabled': True},
        'phase_observations': phases, 'production_model_loads': 0, 'native_model_forward_calls': 0,
        'agent_accelerator_initialization_requests': 0, 'agent_hardware_or_availability_queries': 0,
        'library_internal_availability_queries': 'not instrumented', 'device_initialization_checks': 'getter_only',
        'production_activation_gates': 'all None', 'actual_tiny_roundtrip': {'checks_passed': 8, 'checks': [str(i) for i in range(8)],
            'native_rows': 65, 'target_scores': 64, 'selected_rows': 4, 'vocabulary': 7,
            'native_model_loads': 0, 'native_model_forward_calls': 0},
        'runtime_sources': {key: {} for key in ('torch', 'numpy', 'safetensors', 'safetensors_torch', 'torch_tensor',
                                             'inference_capture', 'artifact_io', 'conditions')}}


class ProtocolTests(unittest.TestCase):
    def test_actual71_source_closure_hashes_without_frameworks(self):
        self.assertFalse(any(name in sys.modules for name in ('torch', 'numpy', 'torch_npu', 'transformers')))
        files = tool.frozen_files(REPO); self.assertEqual(len(files), 71)
        for name, digest in files.items(): self.assertEqual(tool.sha(REPO / name), digest)
        self.assertEqual(sum(name.endswith('.json') for name in files), 51)

    def test_actual_packet_safe_stage_source_mutation_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp).resolve(); packet = tool.build(REPO, base / 'packet')
            archive = Path(packet['archive']['path']); uploaded = base / archive.name; uploaded.write_bytes(archive.read_bytes())
            result = tool.stage(base, uploaded, packet['archive']['sha256'], packet['manifest_sha256'])
            self.assertEqual(result['source_files'], 71); self.assertEqual(packet['regular_members'], 72)
            with self.assertRaises(ValueError): tool.stage(base, uploaded, packet['archive']['sha256'], packet['manifest_sha256'])
            source = Path(result['source_root']); target = source / tool.EXPECTED
            target.write_bytes(target.read_bytes() + b'\n# fixture mutation\n')
            with self.assertRaises(ValueError): tool.verify_tree(source, source.parent / 'source-manifest.json', packet['manifest_sha256'])

    def test_probe_all23_zero_skip_and_no_initialized_context(self):
        original = probe_fixture()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'synthetic-probe.json'; tool.put(path, original)
            self.assertEqual(tool.validate_probe(path, False)['tests']['run'], 23)
            for mutation in ('skip', 'cuda', 'npu', 'invented_pre_namespace_false', 'wrong_version', 'missing_runtime'):
                bad = copy.deepcopy(original)
                if mutation == 'skip': bad['tests']['skipped'] = 1
                elif mutation == 'cuda': bad['phase_observations'][-1]['cuda_initialized'] = True
                elif mutation == 'npu': bad['phase_observations'][1].update(npu_namespace_registered=True, npu_initialized=True)
                elif mutation == 'invented_pre_namespace_false': bad['phase_observations'][0]['npu_initialized'] = False
                elif mutation == 'wrong_version': bad['versions']['torch'] = '2.9.0+cu128'
                else: bad['runtime_sources'].pop('torch_tensor')
                path.write_text(json.dumps(bad), encoding='utf-8')
                with self.assertRaises(ValueError, msg=mutation): tool.validate_probe(path, False)

    def test_imported_registered_but_uninitialized_is_truthful(self):
        document = probe_fixture()
        for item in document['phase_observations']: item.update(torch_npu_imported=True, npu_namespace_registered=True, npu_initialized=False)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'synthetic.json'; tool.put(path, document)
            self.assertFalse(tool.validate_probe(path, False)['phase_observations'][-1]['npu_initialized'])

    def test_cpu_marker_permanent_and_no_retry(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'cpu-attempt-once.json'
            tool.put(path, {'synthetic_cpu_marker_not_native': True})
            with self.assertRaises(FileExistsError): tool.put(path, {'retry': True})
            self.assertEqual(tool.read(path), {'synthetic_cpu_marker_not_native': True})

    def test_query_keeps_controller_ref_after_runtime_alias_loop(self):
        paste = (HERE / 'reserved48-cpu-operations-20261107.txt').read_text(encoding='utf-8')
        blocks = re.findall(r"<<'(PY_RESERVED48_[A-Z_]+)'\n(.*?)\n\1", paste, re.S)
        body = dict(blocks)['PY_RESERVED48_CPU_QUERY']; tree = ast.parse(body)
        loop = next(node for node in tree.body if isinstance(node, ast.For) and 'catalog.items' in ast.unparse(node.iter))
        output = next(node for node in reversed(tree.body) if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and
                      isinstance(node.value.func, ast.Name) and node.value.func.id == 'print')
        controller = {'path': '/original/controller-receipt.json', 'sha256': 'a' * 64, 'size_bytes': 23}
        folder = Path(tempfile.gettempdir()).resolve() / 'synthetic-reserved-cpu-query'
        source = {'path': str(folder / 'original.py'), 'sha256': 'b' * 64, 'size_bytes': 8}
        copied = dict(source, path=str(folder / 'runtime-sources/torch.py'))
        catalog = {'torch': {'source': source, 'copy': copied}}
        refs = {source['path']: source, copied['path']: copied}
        state = {'probe': {}, 'independent_inventory': {}, 'runtime_source_map': {}, 'elapsed_seconds': 2}
        probe = {'runtime_sources': {'torch': source}, 'tests': {}, 'actual_tiny_roundtrip': {}, 'versions': {}, 'phase_observations': []}
        namespace = {'Path': Path, 'json': json, 'controller_ref': controller, 'item': controller,
            'folder': folder, 'catalog': catalog, 'state': state, 'probe': probe,
            'module': SimpleNamespace(ref=lambda path: refs[str(path)])}
        stream = io.StringIO()
        with redirect_stdout(stream): exec(compile(ast.Module(body=[loop, output], type_ignores=[]), 'actual-query-output', 'exec'), namespace)
        self.assertEqual(json.loads(stream.getvalue())['controller'], controller)

    @unittest.skipUnless(os.name == 'posix', 'reviewed POSIX process cleanup')
    def test_real_scoped_child_rc7_and_timeout_cleanup(self):
        helper = tool.load_cleanup(REPO)
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            failed = helper.child([sys.executable, '-S', '-B', '-c', 'raise SystemExit(7)'], folder, 2, folder / 'fail.out', folder / 'fail.err')
            self.assertEqual(failed['returncode'], 7); self.assertFalse(failed['timed_out'])
            self.assertFalse(failed['cleanup']['remaining_owned_process_group'])
            timeout = helper.child([sys.executable, '-S', '-B', '-c', 'import time;time.sleep(60)'], folder, .05,
                                   folder / 'timeout.out', folder / 'timeout.err')
            self.assertTrue(timeout['timed_out']); self.assertFalse(timeout['cleanup']['remaining_owned_process_group'])

    @unittest.skipUnless(os.name == 'posix', 'real bounded protocol child failure')
    def test_real_runner_failure7_keeps_permanent_marker_and_refuses_retry(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp).resolve(); packet = tool.build(REPO, base / 'packet')
            archive = Path(packet['archive']['path']); uploaded = base / archive.name; uploaded.write_bytes(archive.read_bytes())
            stage = tool.stage(base, uploaded, packet['archive']['sha256'], packet['manifest_sha256'])
            source = Path(stage['source_root'])
            spec = importlib.util.spec_from_file_location('actual_staged_reserved48_protocol_fixture', source / tool.SELF)
            staged = importlib.util.module_from_spec(spec); spec.loader.exec_module(staged)
            helper = staged.load_cleanup(source)
            def actual_failure(argv, cwd, timeout, stdout, stderr):
                return helper.child([sys.executable, '-S', '-B', '-c', 'raise SystemExit(7)'], cwd, timeout, stdout, stderr)
            saved = {name: sys.modules.get(name) for name in ('reserved48_common_v1', 'reserved48_expected_v1')}
            try:
                for name in saved: sys.modules.pop(name, None)
                with patch.object(staged, 'load_cleanup', return_value=SimpleNamespace(child=actual_failure)):
                    self.assertEqual(staged.run(base, packet['manifest_sha256']), 2)
                    with self.assertRaises(FileExistsError): staged.run(base, packet['manifest_sha256'])
                target = base / staged.SUBDIR
                self.assertTrue((target / 'cpu-attempt-once.json').is_file())
                receipts = list((target / 'runs').glob('*/controller-receipt.json')); self.assertEqual(len(receipts), 1)
                receipt = staged.read(receipts[0]); self.assertEqual(receipt['status'], 'failed')
                self.assertEqual(receipt['steps'][0]['returncode'], 7)
                self.assertFalse(receipt['steps'][0]['cleanup']['remaining_owned_process_group'])
                self.assertFalse((receipts[0].parent / 'probe/receipt.json').exists())
            finally:
                for name, old in saved.items():
                    sys.modules.pop(name, None)
                    if old is not None: sys.modules[name] = old

    @unittest.skipUnless(os.name == 'posix', 'reviewed POSIX owned descendant cleanup')
    def test_term_resistant_descendant_after_leader_exit_is_removed(self):
        helper = tool.load_cleanup(REPO)
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp); pidfile = folder / 'descendant.pid'
            code = ('import os,signal,time,pathlib\npid=os.fork()\n'
                'if pid==0:\n signal.signal(signal.SIGTERM,signal.SIG_IGN)\n pathlib.Path(' + repr(str(pidfile)) + ').write_text(str(os.getpid()))\n time.sleep(60)\n'
                'else:\n time.sleep(.1)\n')
            result = helper.child([sys.executable, '-S', '-B', '-c', code], folder, 2, folder / 'out', folder / 'err')
            self.assertEqual(result['returncode'], 0); self.assertFalse(result['cleanup']['remaining_owned_process_group'])
            pid = int(pidfile.read_text())
            with self.assertRaises(ProcessLookupError): os.kill(pid, 0)

    @unittest.skipUnless(os.name == 'posix', 'finite POSIX source preparation timer')
    def test_whole_work_timer_is_armed_before_source_validation(self):
        observed = {}
        def check(root, manifest, started):
            remaining, _ = signal.getitimer(signal.ITIMER_REAL); observed['remaining'] = remaining
            raise ValueError('synthetic preparation failure')
        old = signal.getsignal(signal.SIGALRM)
        with patch.object(tool, 'run_attempt', check):
            with self.assertRaisesRegex(ValueError, 'preparation failure'): tool.run('not-read', '0' * 64)
        self.assertGreater(observed['remaining'], 150); self.assertEqual(signal.getitimer(signal.ITIMER_REAL)[0], 0)
        self.assertEqual(signal.getsignal(signal.SIGALRM), old)


if __name__ == '__main__': unittest.main()

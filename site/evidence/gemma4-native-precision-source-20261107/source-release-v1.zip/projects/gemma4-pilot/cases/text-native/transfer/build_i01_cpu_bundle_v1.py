"""Create a finite source-pinned offline I01 tool archive, without results."""
import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile

CASE='projects/gemma4-pilot/cases/text-native'
BUILDER=CASE+'/adapters/build_gpu290_npu3_compare_v1.py'
BUILDER_SHA='43115d8572e30ddedcdb4a85194ca4ddd3046e90e780be6f17f11c0bd8150c24'
PINS={BUILDER:BUILDER_SHA,
    CASE+'/adapters/i01_admission_compare_v1.py':'f7fe91cdcebeec910efed4579ecf379fd665cf305223a3fa77858004db81858a',
    CASE+'/adapters/i01_expected_inventory_v1.py':'834de8fef3d6147b908450116e39a48ea75a026bfc13a290db7db25492fbb40b',
    CASE+'/adapters/test_i01_admission_v1.py':'b9a14ba815b84d7abff28a743561a09987e505000e9c4355aac8b281145ec446'}
CONTROLLER=CASE+'/transfer/run_i01_actual_compare_v1.py'


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build(root,archive):
    root=Path(root).resolve(strict=True);archive=Path(archive).resolve()
    require(not archive.exists() and archive.parent.is_dir(),'new archive output required')
    require(sha(root/BUILDER)==BUILDER_SHA,'reviewed historical builder changed')
    tree=ast.parse((root/BUILDER).read_text(encoding='utf-8'));imports=None
    for node in tree.body:
        if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='IMPORT_PINS' for target in node.targets):
            imports=ast.literal_eval(node.value)
    require(isinstance(imports,dict) and len(imports)==10,'fixed historical import closure not found')
    pins={**imports,**PINS,CONTROLLER:sha(root/CONTROLLER)}
    files={}
    for name,digest in sorted(pins.items()):
        path=root/name
        require(path.is_file() and not path.is_symlink() and sha(path)==digest and path.stat().st_size<=1024**2,
            'fixed source changed or is too large: '+name)
        files[name]={'sha256':digest,'size_bytes':path.stat().st_size}
    manifest={'schema_version':1,'kind':'i01-offline-tool-bundle','files':files,
        'scope':'offline actual raw-BF16 admission and scoped comparisons; includes only source and synthetic CPU tests',
        'native_executions_started':0,'thresholds':None,'acceptance':None}
    raw=(json.dumps(manifest,indent=2,allow_nan=False)+'\n').encode('utf-8')
    with archive.open('xb') as destination,tarfile.open(fileobj=destination,mode='w') as package:
        for name,ref in files.items():
            data=(root/name).read_bytes();require(hashlib.sha256(data).hexdigest()==ref['sha256'],'source changed while packaging')
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0;package.addfile(info,io.BytesIO(data))
        info=tarfile.TarInfo('tool-bundle-manifest.json');info.size=len(raw);info.mode=0o600;info.mtime=0;package.addfile(info,io.BytesIO(raw))
    require(archive.stat().st_size<=2*1024**2,'tool archive exceeds2MiB budget')
    for name,ref in files.items():require(sha(root/name)==ref['sha256'],'source changed after packaging')
    result={'status':'offline_i01_tool_bundle_created','archive':str(archive),'archive_bytes':archive.stat().st_size,
        'archive_sha256':sha(archive),'tool_manifest_sha256':hashlib.sha256(raw).hexdigest(),'regular_members':len(files)+1,
        'source_members':len(files),'controller_sha256':files[CONTROLLER]['sha256'],'native_executions_started':0,'acceptance':None}
    receipt=archive.with_name(archive.name+'.receipt.json')
    with receipt.open('x',encoding='utf-8',newline='\n') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps(result,indent=2));return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True);parser.add_argument('--archive',type=Path,required=True)
    args=parser.parse_args();build(args.root,args.archive)


if __name__=='__main__':main()

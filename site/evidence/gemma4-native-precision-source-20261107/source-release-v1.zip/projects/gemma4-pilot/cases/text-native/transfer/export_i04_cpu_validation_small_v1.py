"""Copy nineteen actual I04 CPU proof documents under a finite30s budget.

No tests, framework import, model, allocation or native query is executed. The
frozen pure-stdlib checker validates the complete copied prerequisite before any
success archive/envelope is produced. Original JSON/source paths stay verbatim.
"""
import argparse
import base64
import hashlib
import importlib.util
import json
from pathlib import Path,PurePosixPath
import re
import signal
import sys
import tarfile

CASE='projects/gemma4-pilot/cases/text-native'
CHECKER_SHA='b2a1e5ef6d28aa6a76de5d6081eae0eae9115bcb010ebcb2da95741e1b6606e7'
UTIL_SHA='8d42c0eb525c92c23c5324dc751149b47f3c20b8e74d65d4ba76de6c1ca068f0'
STAGE_SHA='26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
PRIOR_SHA='3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c'
EXPECTED_SHA='22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76'
MANIFEST_SHA='5a5c72b5d47066c32b665a7b53f21216c812fddad70fb6f4c024be03cdcac6fa'
OPS_SHA='bffba407af697b0891e11d0309612d43b5b507b6297e095726c22c795e2a8c2a'
PROBE_SHA='86dec2ea7ae77195951db5b9b57014225df7c8c00290d48335c474bd4e052a8a'
TEST_PINS={'expected':'f567bc9397a801593e49efe081e97510c550e88eb0245aa7a5eadba7e732ce99',
           'capture':'515a795150bc01f2158524029052b2f987b9b5bc74d5fe2321f1fe68a5a831f5'}
MAX_FILE,MAX_TOTAL,MAX_GZIP,MAX_ENVELOPE=4*1024**2,16*1024**2,8*1024**2,16*1024**2
HEX=re.compile(r'^[a-f0-9]{64}$')


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def regular(path):
    path=Path(path);text=str(path)
    require(path.is_absolute() and '\\' not in text and '..' not in PurePosixPath(text).parts,'original absolute POSIX metadata path required')
    # Reject native/model arrays before any filesystem stat or open.
    require(path.suffix not in ('.npy','.safetensors','.pt','.pth','.bin','.tar','.gz','.whl'),'native arrays/archives are outside CPU proof')
    require(not path.is_symlink() and path.is_file() and path.stat().st_size<=MAX_FILE,'bounded original regular CPU proof file required')
    return path


def read(path):
    def pairs(items):
        doc={}
        for key,value in items:require(key not in doc,'duplicate JSON key');doc[key]=value
        return doc
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(regular(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)


def put(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def checker_module(path):
    path=regular(path);utility=regular(path.with_name('i04_prerequisite_v1.py'))
    require(path.name=='i04_cpu_prerequisite_v1.py' and sha(path)==CHECKER_SHA and sha(utility)==UTIL_SHA,'frozen pure CPU checker closure differs')
    require(not any(name in sys.modules for name in ('torch','torch_npu','numpy')),'CPU metadata producer imported a framework')
    spec=importlib.util.spec_from_file_location('i04_cpu_export_pure_checker',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    require(Path(module.__file__).resolve()==path.resolve(),'actual pure CPU checker source differs');return module


def export(root,controller_sha,output,checker):
    root=Path(root);require(root.is_dir() and not root.is_symlink(),'original explicit R root required');root=root.resolve(strict=True)
    target=root/'i04-batch-padding-20261107/cpu-stage-v2';stdout=target/'cpu-validation-v2.stdout'
    require(not target.is_symlink() and target.resolve(strict=True).is_relative_to(root),'original CPU stage root escapes R')
    selected=read(stdout);controller=regular(selected['controller_path'])
    require(controller.parent.parent==target/'runs' and re.fullmatch(r'compare-i04-cpu-tests-\d{8}T\d{6}Z',controller.parent.name),
        'exact actual CPU controller must be selected from fixed stdout')
    require(HEX.fullmatch(controller_sha) and sha(controller)==controller_sha,'externally frozen actual CPU controller SHA differs')
    state=read(controller);require({k:v for k,v in selected.items() if k!='controller_path'}==state,'actual stdout/controller raw state differs')
    require(state['status']=='completed' and type(state['returncode']) is int and state['returncode']==0 and state['CPU_tests_passed']==21 and
        state['CPU_tests_skipped']==0 and state['CPU_test_groups_passed']=={'expected':8,'capture':13} and state['native_executions_started']==0 and
        state['model_loads']==0 and state['native_claim_created'] is False and len(state['steps'])==3,'actual21test zero-skip CPU success required')
    source=Path(state['source']);require(source==target/'source' and state['manifest_sha256']==MANIFEST_SHA,'actual CPU source identity differs')
    pure=checker_module(checker);output=Path(output)
    require(not output.is_symlink() and not output.exists() and output.parent.is_dir() and output.resolve().is_relative_to(root/'exports') and
        not (root/'exports').is_symlink(),'exclusive new R/exports CPU proof directory required')
    output.mkdir(mode=0o700);(output/'proof').mkdir(mode=0o700)
    entries={'controller':(controller,controller_sha),'startup_receipt':(target/'cpu-validation-v2-start.json',None),
        'stage_receipt':(target/'stage-receipt.json',None),'source_manifest':(target/'source-manifest.json',MANIFEST_SHA),
        'operations_source':(root/'i04_cpu_stage_operations_v2.py',OPS_SHA),'probe_source':(source/(CASE+'/transfer/i04_cpu_mask_probe_v1.py'),PROBE_SHA),
        'test_sources/expected':(source/(CASE+'/adapters/test_i04_expected_inventory_v1.py'),TEST_PINS['expected']),
        'test_sources/capture':(source/(CASE+'/adapters/test_i04_capture_v1.py'),TEST_PINS['capture'])}
    for label,step in zip(('expected','capture','probe'),state['steps']):
        for stream in ('stdout','stderr'):entries['test_logs/'+label+'_'+stream]=(Path(step[stream]['path']),step[stream]['sha256'])
    runtime=state['actual_mask_probe']['sources'];require(set(runtime)=={'torch','numpy','transformers','masking_utils','configuration'},'five actual CPU runtime sources required')
    for name,ref in runtime.items():entries['runtime_sources/'+name]=(Path(ref['path']),ref['sha256'])
    require(len(entries)==19 and len({str(path) for path,_ in entries.values()})==19,'nineteen distinct original metadata sources required')
    total=0;refs={};sources={};stdout_sha=sha(stdout)
    for index,(name,(original,expected)) in enumerate(sorted(entries.items())):
        original=regular(original);raw=original.read_bytes();digest=hashlib.sha256(raw).hexdigest()
        require(expected is None or digest==expected,'original CPU proof source SHA differs: '+name)
        total+=len(raw);require(total<=MAX_TOTAL,'nineteen CPU proof files exceed16MiB')
        relative='proof/%02d-%s%s'%(index,name.replace('/','-'),original.suffix);copied=output/relative
        with copied.open('xb') as stream:stream.write(raw)
        refs[name]={'path':relative,'source_path':str(original),'sha256':digest};sources[name]=(original,len(raw),digest)
    singles=('controller','startup_receipt','stage_receipt','source_manifest','operations_source','probe_source')
    wrapper={'schema_version':1,'kind':'i04-cpu-validation-prerequisite','stage_spec_sha256':STAGE_SHA,
        'i03_prerequisite_sha256':PRIOR_SHA,'expected_inventory_sha256':EXPECTED_SHA,**{name:refs[name] for name in singles}}
    for group in ('test_sources','test_logs','runtime_sources'):wrapper[group]={name.split('/',1)[1]:ref for name,ref in refs.items() if name.startswith(group+'/')}
    put(output/'prerequisite.json',wrapper);wrapper_sha=sha(output/'prerequisite.json')
    checked=pure.prerequisite(output/'prerequisite.json',wrapper_sha);require(len(checked['refs'])==19 and checked['native_executions_started']==0,'complete pure CPU prerequisite gate failed')
    for name,(original,size,digest) in sources.items():require(original.stat().st_size==size and sha(original)==sha(output/refs[name]['path'])==digest,'CPU source/copy changed during export')
    require(sha(stdout)==stdout_sha and sha(controller)==controller_sha and sha(checker)==CHECKER_SHA,'CPU source/checker changed during export')
    archive=output.with_name(output.name+'.tar.gz');members=['prerequisite.json']+sorted(ref['path'] for ref in refs.values())
    with archive.open('xb') as stream,tarfile.open(fileobj=stream,mode='w:gz') as package:
        for name in members:package.add(output/name,arcname=name,recursive=False)
    require(archive.stat().st_size<=MAX_GZIP,'CPU proof gzip exceeds8MiB');archive_ref={'basename':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)}
    envelope=output.with_name(output.name+'-json-base64.txt')
    put(envelope,{'schema_version':1,'kind':'i04-cpu-validation-proof-transport','prerequisite_sha256':wrapper_sha,'source_controller_sha256':controller_sha,
        'source_stdout_sha256':stdout_sha,'archive':{**archive_ref,'base64':base64.b64encode(archive.read_bytes()).decode('ascii')}})
    require(envelope.stat().st_size<=MAX_ENVELOPE,'CPU proof JSONbase64 envelope exceeds16MiB')
    for name,(original,size,digest) in sources.items():require(original.stat().st_size==size and sha(original)==sha(output/refs[name]['path'])==digest,'CPU source/copy changed during packaging')
    require(sha(output/'prerequisite.json')==wrapper_sha and sha(controller)==controller_sha and sha(stdout)==stdout_sha,'CPU control/proof changed during packaging')
    result={'schema_version':1,'status':'i04_cpu_validation_proof_exported','prerequisite_path':str(output/'prerequisite.json'),'prerequisite_sha256':wrapper_sha,
        'source_controller_path':str(controller),'source_controller_sha256':controller_sha,'source_stdout_sha256':stdout_sha,'original_raw_documents':19,
        'regular_archive_members':20,'raw_source_bytes':total,'checker_sha256':CHECKER_SHA,'utility_sha256':UTIL_SHA,'archive':archive_ref,
        'json_base64_path':str(envelope),'json_base64_bytes':envelope.stat().st_size,'json_base64_sha256':sha(envelope),'source_original_bytes_preserved':True,
        'native_arrays_opened':0,'native_executions_started':0,'model_loads':0,'acceptance':None}
    put(output.with_name(output.name+'-export-receipt.json'),result);return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('root','output','checker'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--controller-sha256',required=True);args=parser.parse_args()
    def expire(*_):raise TimeoutError('pure CPU proof export30s deadline reached')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,30)
    try:print(json.dumps(export(args.root,args.controller_sha256,args.output,args.checker),indent=2),flush=True)
    except BaseException as exc:
        path=args.output.with_name(args.output.name+'-failure.json')
        if path.parent.is_dir() and not path.exists():put(path,{'status':'failed','error_type':type(exc).__name__,'error':str(exc),'partial_files_preserved':True,'automatic_retry':False,'native_executions_started':0})
        raise
    finally:signal.setitimer(signal.ITIMER_REAL,0)

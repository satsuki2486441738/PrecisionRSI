"""Synthetic CPU-receipt contracts only; no actual factory/model execution."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest

import i04_cpu_prerequisite_v2 as gate

HERE = Path(__file__).resolve().parent
CASE = HERE.parent


class CPUProof(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name); (self.base/'proof').mkdir(); self.path = self.base/'prerequisite.json'
        self.target = '/synthetic/R/i04-batch-padding-20261107/cpu-stage-v3'; self.source = self.target+'/source'
        self.run = self.target+'/runs/compare-i04-cpu-tests-synthetic'
        sources = {
            'controller':self.run+'/controller-receipt.json','startup_receipt':self.target+'/cpu-validation-v3-start.json',
            'stage_receipt':self.target+'/stage-receipt.json','source_manifest':self.target+'/source-manifest.json',
            'operations_source':'/synthetic/R/i04_cpu_stage_operations_v3.py','probe_source':self.source+'/'+gate.PROBE}
        sources.update({'test_sources/'+k:self.source+'/'+name for k,name in [('expected',gate.EXPECTED_TEST),('capture',gate.CAPTURE_TEST)]})
        sources.update({'test_logs/'+name+'_'+stream:self.run+'/'+('mask-probe' if name == 'probe' else name)+'.'+stream
            for name in ('expected','capture','probe') for stream in ('stdout','stderr')})
        sources.update({'runtime_sources/'+name:'/synthetic/runtime/'+name+'.py' for name in gate.RUNTIME_NAMES})
        sources['runtime_sources/import_utils'] = '/synthetic/runtime/transformers/utils/import_utils.py'
        sources['runtime_sources/torch_npu_npu'] = '/synthetic/runtime/torch_npu/npu/__init__.py'
        self.refs = {name:{'path':'proof/%02d-%s'%(i,name.replace('/','-')),'source_path':source,'sha256':''}
            for i,(name,source) in enumerate(sorted(sources.items()))}
        self.wrapper = {'schema_version':1,'kind':'i04-cpu-validation-prerequisite-v2','stage_spec_sha256':gate.STAGE_SHA,
            'i03_prerequisite_sha256':gate.I03_PROOF_SHA,'expected_inventory_sha256':gate.EXPECTED_SHA,
            **{name:self.refs[name] for name in gate.SINGLES}}
        for group in ('test_sources','test_logs','runtime_sources'):
            self.wrapper[group] = {name.split('/',1)[1]:ref for name,ref in self.refs.items() if name.startswith(group+'/')}
        self.bytes = {}
        for name,source in [('operations_source',CASE/'transfer/i04_cpu_stage_operations_v3.py'),('probe_source',CASE/'transfer/i04_cpu_mask_probe_v2.py'),
                ('test_sources/expected',HERE/'test_i04_expected_inventory_v1.py'),('test_sources/capture',HERE/'test_i04_capture_v2.py')]:
            self.bytes[name] = source.read_bytes()
        archive = CASE/'runs/compare-i04-cpu-source-package-v3-20261106T181148Z/i04-cpu-stage-v3.tar.gz'
        with tarfile.open(archive,'r:gz') as package: self.bytes['source_manifest'] = package.extractfile('source-manifest.json').read()
        self.assertEqual(hashlib.sha256(self.bytes['source_manifest']).hexdigest(),gate.MANIFEST_SHA)
        for name in gate.RUNTIME_NAMES: self.bytes['runtime_sources/'+name] = ('# Synthetic CPU source fixture '+name+'\n').encode()
        self.bytes['test_logs/expected_stdout'] = b''; self.bytes['test_logs/capture_stdout'] = b''; self.bytes['test_logs/probe_stderr'] = b''
        self.bytes['test_logs/expected_stderr'] = b'Synthetic fixture\nRan 8 tests\n\nOK\n'
        self.bytes['test_logs/capture_stderr'] = b'test_pinned_factory_masks_valid_queries_for_both_padding_sides ... ok\nRan 13 tests\n\nOK\n'
        check = {'prerequisite_sha256':gate.I03_PROOF_SHA,'prior_report_sha256':gate.I03_REPORT_SHA,
            'original_proof_documents_checked':8,'expected_inventory_sha256':gate.EXPECTED_SHA,'native_executions_started':0}
        self.stage = {'status':'i04_cpu_stage_checked_not_native','source':self.source,'manifest_sha256':gate.MANIFEST_SHA,
            'files_checked':38,'model_loads':0,'native_claim_created':False,**check}
        self.start = {'status':'cpu_validation_spawned_not_result','automatic_retry':False,'ops_sha256':gate.OPS_SHA,
            'manifest_sha256':gate.MANIFEST_SHA,'stage_receipt_sha256':'','total_cpu_seconds':300,'native_executions_started':0,
            'model_loads':0,'native_claim_created':False,'pid':100,'starttime':1234,'started_utc':'2026-11-06T17:30:00+00:00',
            'argv':['/synthetic/R/venv/bin/python','-B',sources['operations_source'],'run','--base','/synthetic/R','--manifest-sha256',gate.MANIFEST_SHA]}
        self.probe = {'status':'i04_cpu_only_actual_mask_factories_checked','versions':{'torch':'2.9.0+cpu','transformers':'5.10.1','numpy':'1.26.4'},
            'valid_query_key_cells_checked':192,'torch_npu_imported':True,'npu_initialized':False,'cuda_initialized':False,'device_backend_autoload':'0',
            'device_initialization_checks':'getter_only','agent_hardware_or_availability_queries':0,
            'library_internal_availability_queries':'not_counted_and_not_prohibited',
            'model_loads':0,'native_model_forward_calls':0,'agent_accelerator_initialization_requests':0,'sources':{},
            'phase_observations':[{'phase':name,'torch_npu_imported':index>=2,'npu_namespace_registered':index>=2,
                'npu_initialized':None if index<2 else False,'cuda_initialized':False} for index,name in enumerate(
                ['after_torch','after_transformers','after_configuration','after_masking_utils','before_masks','after_masks'])],
            'observations':[{'side':side,'factory':factory,'shape':[2,1,4,4],'dtype':'torch.bfloat16','device':'cpu'} for side in ('left','right')
                for factory in ('sliding_attention','full_attention','direct_full','direct_sliding')]}
        self.controller = {'task':'I04-CPU-validation','status':'completed','returncode':0,'CPU_tests_passed':21,'CPU_tests_skipped':0,
            'CPU_test_groups_passed':{'expected':8,'capture':13},'native_executions_started':0,'model_loads':0,'native_claim_created':False,
            'whole_timeout_seconds':300,'work_timeout_seconds':240,'owned_cleanup_reserve_seconds':20,'elapsed_seconds':12.0,
            'manifest_sha256':gate.MANIFEST_SHA,'before':check.copy(),'after':check.copy(),'source':self.source,
            'automatic_retry':False,'module_import_policy':'observed_not_forbidden','agent_hardware_or_availability_queries':0,
            'library_internal_availability_queries':'not_counted_and_not_prohibited',
            'started_utc':'2026-11-06T17:30:01+00:00','finished_utc':'2026-11-06T17:30:13+00:00','steps':[]}
        for i,(name,module,timeout) in enumerate([('expected','test_i04_expected_inventory_v1',30),('capture','test_i04_capture_v2',150),('probe',None,60)]):
            argv = [self.start['argv'][0],'-B','-m','unittest','-v',module] if module else [self.start['argv'][0],'-B',sources['probe_source']]
            self.controller['steps'].append({'argv':argv,'returncode':0,'timed_out':False,'timeout_seconds':timeout,
                'cleanup':{'owned_process_group':101+i,'remaining_owned_process_group':False}})
        self.save()

    def save_bytes(self,name,raw):
        self.bytes[name] = raw; target = self.base/self.refs[name]['path']; target.write_bytes(raw)
        self.refs[name]['sha256'] = hashlib.sha256(raw).hexdigest()

    def encode(self,value): return (json.dumps(value,indent=2,allow_nan=False)+'\n').encode()

    def save(self):
        for name,raw in list(self.bytes.items()): self.save_bytes(name,raw)
        self.save_bytes('stage_receipt',self.encode(self.stage)); self.start['stage_receipt_sha256'] = self.refs['stage_receipt']['sha256']
        self.save_bytes('startup_receipt',self.encode(self.start))
        self.probe['sources'] = {name:{'path':self.refs['runtime_sources/'+name]['source_path'],
            'sha256':self.refs['runtime_sources/'+name]['sha256'],'size_bytes':len(self.bytes['runtime_sources/'+name])} for name in gate.RUNTIME_NAMES}
        self.save_bytes('test_logs/probe_stdout',self.encode(self.probe)); self.controller['actual_mask_probe'] = copy.deepcopy(self.probe)
        for step,name in zip(self.controller['steps'],('expected','capture','probe')):
            for stream in ('stdout','stderr'):
                key = 'test_logs/'+name+'_'+stream; ref = self.refs[key]
                step[stream] = {'path':ref['source_path'],'sha256':ref['sha256'],'bytes':len(self.bytes[key])}
        self.save_bytes('controller',self.encode(self.controller)); self.path.write_bytes(self.encode(self.wrapper)); self.digest = gate.sha(self.path)

    def test_complete_twenty_one_raw_docs_pass_purely(self):
        result = gate.prerequisite(self.path,self.digest)
        self.assertEqual(len(result['refs']),21); self.assertEqual(result['native_executions_started'],0)
        self.assertEqual(result['prerequisite_sha256'],self.digest)

    def test_combined_namespace_and_skipped_factory_fail_even_if_resigned(self):
        self.controller['steps'][0]['argv'].append('test_i04_capture_v2'); self.save()
        with self.assertRaisesRegex(ValueError,'fresh CPU step'): gate.prerequisite(self.path,self.digest)
        self.controller['steps'][0]['argv'].pop(); self.bytes['test_logs/capture_stderr'] = b'Ran 13 tests\nOK (skipped=1)\n'; self.save()
        with self.assertRaisesRegex(ValueError,'zero skips'): gate.prerequisite(self.path,self.digest)

    def test_unclean_descendants_or_reused_group_fail(self):
        self.controller['steps'][1]['cleanup']['remaining_owned_process_group'] = True; self.save()
        with self.assertRaises(ValueError): gate.prerequisite(self.path,self.digest)
        self.controller['steps'][1]['cleanup']['remaining_owned_process_group'] = False
        self.controller['steps'][1]['cleanup']['owned_process_group'] = 101; self.save()
        with self.assertRaisesRegex(ValueError,'distinct owned groups'): gate.prerequisite(self.path,self.digest)

    def test_noinit_flags_probe_version_or_count_cannot_be_forged_by_wrapper_only(self):
        self.probe['npu_initialized'] = True; self.save()
        with self.assertRaisesRegex(ValueError,'no-accelerator'): gate.prerequisite(self.path,self.digest)
        self.probe['npu_initialized'] = False; self.controller['CPU_tests_passed'] = True; self.save()
        with self.assertRaisesRegex(ValueError,'21-test'): gate.prerequisite(self.path,self.digest)

    def test_any_initialized_phase_or_invented_pre_registration_state_fails(self):
        self.probe['phase_observations'][-1]['npu_initialized'] = True; self.save()
        with self.assertRaisesRegex(ValueError,'initialization phase'): gate.prerequisite(self.path,self.digest)
        self.probe['phase_observations'][-1]['npu_initialized'] = False
        self.probe['phase_observations'][0]['npu_initialized'] = False; self.save()
        with self.assertRaisesRegex(ValueError,'initialization phase'): gate.prerequisite(self.path,self.digest)

    def test_all_seven_runtime_sources_and_honest_library_query_scope_required(self):
        self.wrapper['runtime_sources'].pop('torch_npu_npu'); self.path.write_bytes(self.encode(self.wrapper)); self.digest = gate.sha(self.path)
        with self.assertRaisesRegex(ValueError,'runtime proof'): gate.prerequisite(self.path,self.digest)
        self.wrapper['runtime_sources']['torch_npu_npu'] = self.refs['runtime_sources/torch_npu_npu']
        self.probe['library_internal_availability_queries'] = 0; self.save()
        with self.assertRaisesRegex(ValueError,'no-accelerator'): gate.prerequisite(self.path,self.digest)

    def test_runtime_source_raw_tamper_and_missing_copy_fail(self):
        path = self.base/self.refs['runtime_sources/torch']['path']; path.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'proof bytes'): gate.prerequisite(self.path,self.digest)
        self.save(); path.unlink()
        with self.assertRaises(ValueError): gate.prerequisite(self.path,self.digest)

    def test_actual_before_after_or_source_manifest_mismatch_fails(self):
        self.controller['after']['expected_inventory_sha256'] = 'a'*64; self.save()
        with self.assertRaisesRegex(ValueError,'before/after'): gate.prerequisite(self.path,self.digest)
        self.controller['after'] = self.controller['before'].copy(); self.bytes['source_manifest'] += b' '; self.save()
        with self.assertRaisesRegex(ValueError,'source-manifest'): gate.prerequisite(self.path,self.digest)

    def test_pure_source_import_with_python_S_and_unsafe_path_rejection(self):
        program = "import importlib.util,sys;s=importlib.util.spec_from_file_location('gate',sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);assert not any(n in sys.modules for n in ('torch','torch_npu','numpy'))"
        result = subprocess.run([sys.executable,'-S','-B','-c',program,str(HERE/'i04_cpu_prerequisite_v2.py')],capture_output=True,timeout=20)
        self.assertEqual(result.returncode,0,result.stderr.decode(errors='replace'))
        self.wrapper['controller']['path'] = '../escape'; self.path.write_bytes(self.encode(self.wrapper)); self.digest = gate.sha(self.path)
        with self.assertRaises(ValueError): gate.prerequisite(self.path,self.digest)


if __name__ == '__main__': unittest.main()

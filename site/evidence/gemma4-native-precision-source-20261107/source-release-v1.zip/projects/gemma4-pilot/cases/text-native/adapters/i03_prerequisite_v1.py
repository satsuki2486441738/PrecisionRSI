"""Pure-standard-library portable I01 prerequisite checks for I03 launchers.

No framework, accelerator, subprocess or model is imported or executed.
Original metadata bytes/paths are retained; external new-claim source pins
must freeze the actual admitted report and this prerequisite digest.
"""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re

PRIOR_STAGE_SHA256='5aa7d50bb472aab82108ad6711fdd6c5bdd4780bbecb27cdf78c734d13093c05'
I01_ANALYSIS_SHA256='f7fe91cdcebeec910efed4579ecf379fd665cf305223a3fa77858004db81858a'
ACTUAL_GPU_MAP_SHA256='dbf3d67094a3b5399d46fc488724b89a497f9051486d4e50c8b2056e31cffd9b'
HEX=re.compile(r'^[a-f0-9]{64}$')

def require(ok,message):
    if not ok:raise ValueError(message)

def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):digest.update(block)
    return digest.hexdigest()

def read(path):
    def pairs(items):
        result={}
        for key,value in items:
            require(key not in result,'duplicate JSON key');result[key]=value
        return result
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    result=json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)
    json.dumps(result,allow_nan=False)
    return result

def file_ref(path):
    path=Path(path)
    require(path.is_file() and not path.is_symlink(),'original regular proof file required')
    return {'path':str(path.resolve()),'sha256':sha(path),'size_bytes':path.stat().st_size}

def safe_relative(name):
    require(isinstance(name, str) and name and '\\' not in name, 'POSIX relative path required')
    path = PurePosixPath(name)
    require(not path.is_absolute() and str(path) == name and all(p not in ('', '.', '..') for p in name.split('/')), 'unsafe relative path')
    return path

def prerequisite(path, digest):
    """Read copied original proof bytes; never reinterpret missing success as true."""
    path = Path(path)
    require(HEX.fullmatch(digest) and file_ref(path)['sha256'] == digest, 'I01 prerequisite source SHA differs')
    document = read(path)
    require(set(document) == {'schema_version', 'kind', 'prior_stage_sha256', 'report', 'comparison_spec',
        'controller', 'analysis_source', 'source_maps'} and document['schema_version'] == 1 and
        document['kind'] == 'i03-i01-numeric-prerequisite' and document['prior_stage_sha256'] == PRIOR_STAGE_SHA256,
        'complete portable I01 numeric prerequisite required')
    require(set(document['source_maps']) == {'GPU', 'NPU'}, 'both actual I01 source maps required')
    require(document['source_maps']['GPU']['sha256'] == ACTUAL_GPU_MAP_SHA256, 'original actual I01 GPU source map differs')
    refs = {name: document[name] for name in ('report', 'comparison_spec', 'controller', 'analysis_source')}
    refs.update({name + '_map': ref for name, ref in document['source_maps'].items()})
    observed, documents = {}, {}
    for name, ref in refs.items():
        require(isinstance(ref, dict) and set(ref) == {'path', 'source_path', 'sha256'} and HEX.fullmatch(ref['sha256']), 'invalid copied proof reference')
        relative = safe_relative(ref['path'])
        require(relative.parts[0] == 'proof', 'copied prerequisite references must use proof/ namespace')
        original = PurePosixPath(ref['source_path'])
        require(original.is_absolute() and '..' not in original.parts and '\\' not in ref['source_path'], 'original proof path must remain absolute POSIX')
        actual = path.parent.joinpath(*relative.parts)
        require(actual.resolve().is_relative_to(path.parent.resolve()), 'proof copy escapes prerequisite bundle')
        current = actual
        while current != path.parent:
            require(not current.is_symlink(), 'proof path contains symlink'); current = current.parent
        observed[name] = file_ref(actual)
        require(observed[name]['sha256'] == ref['sha256'] and observed[name]['size_bytes'] <= 16 * 1024**2, 'copied proof bytes differ or exceed bound')
        if name != 'analysis_source': documents[name] = read(actual)
    require(document['analysis_source']['sha256'] == I01_ANALYSIS_SHA256, 'I01 independent analysis source differs')
    report, spec, controller = (documents[name] for name in ('report', 'comparison_spec', 'controller'))
    require(report.get('status') == 'i01_raw_bf16_and_scoped_comparisons_checked' and
        report.get('task') == 'gemma4-i01-cache-off-anchor-v1' and report.get('stage_spec_sha256') == PRIOR_STAGE_SHA256 and
        report.get('comparison_spec_sha256') == document['comparison_spec']['sha256'] and
        report.get('native_executions_started_by_admission') == 0 and report.get('acceptance') is None and
        report.get('full_core_complete') is False and 'thresholds' in report and report['thresholds'] is None and
        report.get('scope', {}).get('independent_inputs') == 1 and report['scope'].get('new_repeatability_measured') is False and
        report['scope'].get('full_targets_per_backend') == 159 and report['scope'].get('full_distribution_positions_per_backend') == 47,
        'actual successful I01 raw-BF16 numeric admission is required before I03')
    require(controller.get('status') == 'completed' and type(controller.get('returncode')) is int and controller['returncode'] == 0 and
        controller.get('native_executions_started') == 0 and controller.get('report') == {
            'path': document['report']['source_path'], 'sha256': document['report']['sha256']} and
        controller.get('comparison_spec') == {'path': document['comparison_spec']['source_path'], 'sha256': document['comparison_spec']['sha256']},
        'I01 completed controller/report/spec chain differs')
    require(spec.get('task') == report['task'] and spec.get('stage_spec_sha256') == PRIOR_STAGE_SHA256 and
        set(spec.get('endpoints', {})) == {'GPU', 'NPU'}, 'I01 comparison specification differs')
    for category in ('GPU', 'NPU'):
        ref = document['source_maps'][category]
        require(spec['endpoints'][category]['source_map'] == {'path': ref['source_path'], 'sha256': ref['sha256']} and
                documents[category + '_map'].get('request', {}).get('backend') == category and
                documents[category + '_map']['request'].get('task') == 'I01', 'actual I01 endpoint source-map chain differs')
    steps = controller.get('steps', [])
    require(len(steps) == 1 and steps[0].get('returncode') == 0 and steps[0].get('timed_out') is False, 'I01 numeric child did not complete')
    argv = steps[0].get('argv', [])
    direct = 2 if isinstance(argv, list) and len(argv) > 1 and argv[1] == '-B' else 1
    require(isinstance(argv, list) and len(argv) > direct and argv[direct] == document['analysis_source']['source_path'] and
            '--spec' in argv and argv[argv.index('--spec')+1] == document['comparison_spec']['source_path'] and
            '--spec-sha256' in argv and argv[argv.index('--spec-sha256')+1] == document['comparison_spec']['sha256'], 'I01 executed independent analysis argv differs')
    return {'document':document,'refs':observed,'prerequisite_sha256':digest,'native_executions_started':0}

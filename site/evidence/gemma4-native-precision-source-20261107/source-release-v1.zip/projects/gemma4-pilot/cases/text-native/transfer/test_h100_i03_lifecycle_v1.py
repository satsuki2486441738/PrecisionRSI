"""CPU-only new I03 lifecycle gates; never execute native worker/model code."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i03_lifecycle_under_test', HERE / 'h100_i03_lifecycle_v1.py')
job = importlib.util.module_from_spec(spec); spec.loader.exec_module(job)


class Gates(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(); self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name).resolve()
        self.fixed, self.new = {}, {}
        for name in job.FIXED:
            p = self.root / 'source' / name; p.parent.mkdir(parents=True, exist_ok=True)
            if name == job.CLEANUP:
                p.write_bytes((HERE / 'npu_three_repeat_launcher_v4.py').read_bytes())
            elif name in (job.INPUT, job.SPEC):
                p.write_text('{}\n')
            else:
                p.write_bytes(('CPU protocol fixture ' + name).encode())
            self.fixed[name] = job.sha(p)
        helper = '''import json
from pathlib import Path
def prerequisite(path,digest):
 d=json.loads(Path(path).read_text())
 if d.get('verified') is not True:raise ValueError('synthetic I01 proof was not admitted')
 return {'document':d,'refs':{},'prerequisite_sha256':digest,'native_executions_started':0}
'''
        for name in job.NEW_PINS:
            p = self.root / 'source' / name; p.parent.mkdir(parents=True, exist_ok=True)
            expected_stub = "def derive(*args):return {'synthetic_cpu_inventory':True}\ndef stage_check(*args):return {}\n"
            p.write_text(helper if name == job.PREREQUISITE else expected_stub if name == job.EXPECTED else '# CPU-only fixture, not a collector\n')
            self.new[name] = job.sha(p)
        proofdir = self.root / 'prerequisite/proof'; proofdir.mkdir(parents=True)
        refs = {}
        for name in ('report', 'comparison_spec', 'controller', 'analysis_source', 'GPU', 'NPU'):
            p = proofdir / (name + '.json'); p.write_text('{"synthetic_cpu_fixture":true}\n')
            refs[name] = {'path': 'proof/' + p.name, 'source_path': '/synthetic-original/' + p.name,
                          'sha256': job.sha(p)}
        self.proof = self.root / 'prerequisite/manifest.json'
        self.proofdoc = {'verified': True, **{name: refs[name] for name in
            ('report', 'comparison_spec', 'controller', 'analysis_source')},
            'source_maps': {'GPU': refs['GPU'], 'NPU': refs['NPU']}}
        job.put(self.proof, self.proofdoc)
        for name in (job.ENTRY, job.LIFECYCLE):
            (self.root / name).write_text('# synthetic never executed\n')
        expected_raw = (json.dumps({'synthetic_cpu_inventory': True}, indent=2) + '\n').encode()
        self.expected_json_sha = hashlib.sha256(expected_raw).hexdigest()
        self.expected_sha_patch = patch.object(job, 'EXPECTED_JSON_SHA', self.expected_json_sha)
        self.expected_bytes_patch = patch.object(job, 'EXPECTED_JSON_BYTES', len(expected_raw))
        self.expected_sha_patch.start(); self.expected_bytes_patch.start()
        self.addCleanup(self.expected_sha_patch.stop); self.addCleanup(self.expected_bytes_patch.stop)
        self.source = {'schema_version': 1, 'task_id': job.TASK_ID,
            'allocation_id': 'app-new-i03-cpu-fixture', 'vendor': 'NVIDIA', 'visible_count': 1,
            'observed_utc': '2026-11-06T14:00:00+00:00', 'evidence_source': 'Synthetic CPU fixture; no real app',
            'entry_path': str(self.root / job.ENTRY), 'entry_sha256': job.sha(self.root / job.ENTRY),
            'lifecycle_path': str(self.root / job.LIFECYCLE), 'lifecycle_sha256': job.sha(self.root / job.LIFECYCLE),
            'source_pins': {**self.fixed, **self.new}, 'expected_inventory_sha256': self.expected_json_sha,
            'i01_prerequisite_path': str(self.proof), 'i01_prerequisite_sha256': job.sha(self.proof)}
        self.patchfixed = patch.dict(job.FIXED, self.fixed, clear=True)
        self.patchnew = patch.dict(job.NEW_PINS, self.new, clear=True)
        self.patchfixed.start(); self.patchnew.start()
        self.addCleanup(self.patchnew.stop); self.addCleanup(self.patchfixed.stop)

    def source_file(self):
        job.put(self.root / job.SOURCE, self.source)

    def query(self, *_args, **_kwargs):
        return subprocess.CompletedProcess([], 0,
            b'GPU-REDACTED_DEVICE_UUID, NVIDIA H100 80GB HBM3, 580.95.05\n', b'')

    def test_exact_bounds_match_actual_frozen_spec(self):
        stage = json.loads((HERE.parent / 'i03-stage-v1.json').read_text())
        self.assertEqual(job.sha(HERE.parent / 'i03-stage-v1.json'), job.SPEC_SHA)
        limits = stage['limits']
        self.assertEqual(stage['total_forward_calls_per_backend'], 70)
        self.assertEqual(stage['modes'], ['full-r1', 'full-r2', 'full-r3', 'token', 'chunk63-65'])
        self.assertEqual(job.CAPTURE_SECONDS, limits['gpu_capture_timeout_seconds'])
        self.assertEqual(job.MAX_SECONDS, limits['whole_attempt_timeout_seconds_per_backend'])
        self.assertEqual(job.MAX_CAPTURE_BYTES, limits['maximum_capture_product_bytes_per_backend'])
        self.assertEqual(job.MAX_TASK_BYTES, limits['maximum_new_task_storage_bytes_per_backend'])
        self.assertEqual(job.MIN_FREE, limits['minimum_free_source_storage_bytes'])
        self.assertEqual(job.LOGICAL_TRANSPORT, limits['maximum_logical_artifact_transport_bytes_per_direction'])
        self.assertEqual(job.ENCODED_TRANSPORT, limits['maximum_encoded_transport_bytes_per_direction'])

    def test_old_apps_and_unready_pins_fail_before_claim(self):
        for old in ('REDACTED_APP_ID', 'REDACTED_APP_ID'):
            with self.assertRaises(ValueError):
                job.validate_source({**self.source, 'allocation_id': old}, self.root)
        with patch.dict(job.NEW_PINS, {job.PREREQUISITE: None}), self.assertRaisesRegex(ValueError, 'unready'):
            job.validate_source(self.source, self.root)
        self.assertFalse((self.root / 'claims').exists())

    def test_failed_i01_proof_blocks_query_restore_claim(self):
        self.proofdoc['verified'] = False
        self.proof.unlink(); job.put(self.proof, self.proofdoc)
        self.source['i01_prerequisite_sha256'] = job.sha(self.proof)
        self.source_file()
        with patch.object(job.sys, 'platform', 'linux'), self.assertRaisesRegex(ValueError, 'not admitted'):
            job.launch(self.root, lambda *_a, **_k: self.fail('GPU query before admitted I01'),
                       lambda *_a: self.fail('worker before admitted I01'))
        self.assertFalse((self.root / 'claims').exists())

    def test_copied_proof_mutation_rejected_before_query(self):
        (self.root / 'prerequisite/proof/report.json').write_bytes(b'changed')
        self.source_file()
        with patch.object(job.sys, 'platform', 'linux'), self.assertRaisesRegex(ValueError, 'proof changed'):
            job.launch(self.root, lambda *_a, **_k: self.fail('query ran'), lambda *_a: self.fail('worker ran'))

    def test_duplicate_json_relative_source_escape_rejected(self):
        p = self.root / 'dup.json'; p.write_text('{"x":1,"x":2}')
        with self.assertRaises(ValueError):
            job.read(p)
        with self.assertRaises(ValueError):
            job.original(Path('relative.json'), self.root)
        pins = {**self.source['source_pins'], '../old/claim': 'b' * 64}
        with self.assertRaises(ValueError):
            job.validate_source({**self.source, 'source_pins': pins}, self.root)

    def test_permanent_claim_concurrency(self):
        (self.root / 'claims').mkdir()
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda _: job.claim_once(self.root, 'app-fixture', {'synthetic': True}), range(16)))
        self.assertEqual(sum(value is not None for value in results), 1)

    def test_once_and_driver_failure_never_retry(self):
        self.source_file()
        def failed(*_args, **_kwargs):
            return subprocess.CompletedProcess([], 1, b'', b'synthetic failure')
        with patch.object(job.sys, 'platform', 'linux'):
            self.assertEqual(job.launch(self.root, failed, lambda *_a: self.fail('worker after failed driver')), 1)
            self.assertEqual(job.launch(self.root, lambda *_a, **_k: self.fail('second query'),
                                       lambda *_a: self.fail('retry worker')), 0)
        self.assertTrue((self.root / 'claims' / self.source['allocation_id'] / 'launch-failure.json').exists())

    def test_successful_stub_does_not_use_old_worker(self):
        self.source_file(); calls = []
        def run(argv, directory, root, deadline, helper):
            calls.append(argv)
            self.assertEqual(root, self.root)
            self.assertLessEqual(deadline - time.monotonic(), 3600)
            self.assertEqual(argv[-2], '--worker')
            return 0, {'status': 'completed'}
        with patch.object(job.sys, 'platform', 'linux'):
            self.assertEqual(job.launch(self.root, self.query, run), 0)
        self.assertEqual(len(calls), 1)

    @unittest.skipUnless(os.name == 'posix', 'POSIX source symlink')
    def test_symlink_proof_or_source_rejected(self):
        report = self.root / 'prerequisite/proof/report.json'
        moved = report.with_name('actual-report.json'); report.rename(moved); report.symlink_to(moved)
        with self.assertRaises(ValueError):
            job.prerequisite(self.source, self.root)


@unittest.skipUnless(sys.platform.startswith('linux'), 'Real CPU Linux subreaper/process lifecycle')
class OwnedProcesses(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.helper = job.load_pinned(HERE / 'npu_three_repeat_launcher_v4.py', job.CLEANUP_SHA, 'i03_test_reviewed_cleanup')

    def run_cpu(self, script, seconds=2, max_bytes=1024 ** 2):
        tmp = tempfile.TemporaryDirectory(); self.addCleanup(tmp.cleanup)
        root = Path(tmp.name); directory = root / 'receipt'; directory.mkdir()
        started = time.monotonic()
        with patch.object(job, 'MAX_TASK_BYTES', max_bytes):
            code, state = job.supervise([sys.executable, '-c', script, str(root)], directory, root,
                started + job.CLEANUP_SECONDS + seconds, self.helper)
        self.assertLess(time.monotonic() - started, seconds + 12)
        self.assertEqual(state['remaining_descendants'], [])
        self.assertEqual(json.loads((directory / 'controller-receipt.json').read_text())['returncode'], code)
        return code, state

    def test_normal_cpu_worker(self):
        code, state = self.run_cpu("print('CPU only, no model')")
        self.assertEqual((code, state['status']), (0, 'completed'))

    def test_timeout_reaps_term_resistant_session_escaping_grandchild(self):
        child = 'import os,signal,time;os.setsid();signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(60)'
        parent = "import subprocess,sys,signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);subprocess.Popen([sys.executable,'-c',%r]);time.sleep(60)" % child
        code, state = self.run_cpu(parent, seconds=.8)
        self.assertEqual((code, state['timed_out']), (124, True))

    def test_leader_exit_with_escaped_orphan_is_failed_and_reaped(self):
        child = 'import os,signal,time;os.setsid();signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(60)'
        parent = "import subprocess,sys,time;subprocess.Popen([sys.executable,'-c',%r]);time.sleep(.3)" % child
        code, state = self.run_cpu(parent)
        self.assertEqual(code, 1)
        self.assertIn('unexpected live descendants', state['error'])

    def test_sampled_new_task_budget_terminates_only_cpu_worker(self):
        code, state = self.run_cpu("import pathlib,sys,time;(pathlib.Path(sys.argv[1])/'large').write_bytes(b'x'*8192);time.sleep(60)", seconds=4, max_bytes=4096)
        self.assertEqual(code, 1)
        self.assertIn('4GiB limit', state['error'])


class ActualOfflineInputs(unittest.TestCase):
    def test_independent_real_expected_bytes_without_framework(self):
        case = HERE.parent
        module = job.load_pinned(case / 'adapters/i03_expected_inventory_v1.py',
            '9c0d5cad39ae932d95fee34db3ee91cbb6232ed1ab554e6004fadc189425a7f8', 'i03_actual_expected_cpu_fixture')
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / 'expected.json'
            result = module.build(case / 'inputs/discovery-v1/wikitext2-discovery-001.json',
                output, case / 'i03-stage-v1.json', job.SPEC_SHA)
            self.assertEqual(output.stat().st_size, 148509)
            self.assertEqual(job.sha(output), '5c8cdcc3c5b88732ccd589d95fa5ce86bd9eac71f83620e3bc48bcfc3b3b9a25')
            self.assertEqual(result['native_calls_per_backend'], 70)

    def test_actual_admitted_i01_portable_six_documents(self):
        case = HERE.parent
        proof = HERE / 'i01-numeric-small-local-20261106T145700Z/payload/i03-prerequisite/prerequisite.json'
        self.assertTrue(proof.is_file(), 'Root verified actual I01 prerequisite must be retained')
        helper = job.load_pinned(case / 'adapters/i03_prerequisite_v1.py',
            'e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36', 'i03_actual_prerequisite_cpu_fixture')
        result = helper.prerequisite(proof, '2d26531b83af3a3f0acf63c9b8472ce547a5bd288de6f92cd390a38a6011d840')
        self.assertEqual(set(result['refs']), {'report','comparison_spec','controller','analysis_source','GPU_map','NPU_map'})
        self.assertEqual(result['native_executions_started'], 0)


if __name__ == '__main__':
    unittest.main()

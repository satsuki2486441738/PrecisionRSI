"""One bounded native H100 I01 cache-off anchor; invoke under a new owned claim."""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import json
import os
from pathlib import Path
import sys

import i01_common_v1 as common
from pilot_gpu_torch290_candidate import check_allocation, check_device, check_stack, POLICY_SHA256
from pilot_gpu_peer_v2 import seed_and_check, math_policy, check_policy


def main():
    args = common.arguments('gpu')
    stage, inventory, refs = common.prepare(args, 'gpu', __file__)
    allocation = common.read(args.allocation_receipt)
    check_allocation(allocation)
    common.require(common.sha(args.numerics_policy) == POLICY_SHA256, 'frozen GPU numerical policy differs')
    policy = common.read(args.numerics_policy)
    sys.path.insert(0, str(common.HERE.parent / 'transfer'))
    from npu_three_repeat_launcher_v4 import memory_observation
    memory = memory_observation()
    common.require(memory['effective_available_bytes'] >= stage['limits']['minimum_gpu_host_effective_available_bytes'],
                   'effective host/cgroup free memory is below 40GiB')
    with common.bounded_native(stage, 'gpu'):
        import torch
        import transformers
        import numpy
        from transformers import AutoModelForMultimodalLM
        stack = {'torch': str(torch.__version__), 'transformers': str(transformers.__version__),
                 'cuda_runtime': str(torch.version.cuda), 'numpy': str(numpy.__version__)}
        check_stack(stack)
        props, physical, free, total = check_device(torch, allocation)
        rng = seed_and_check(torch, numpy, policy)
        common.check_refs(refs)
        args.output.mkdir()
        with (args.output / 'expected-inventory.json').open('xb') as stream:
            stream.write(args.expected_inventory.read_bytes())
        common.put(args.output / 'policy-before-load.json', rng)
        model, identity = common.load_verified_model(args, torch, AutoModelForMultimodalLM,
            common.read(common.HERE / 'upstream-identity.json'))
        after_load = math_policy(torch)
        check_policy(after_load, policy)
        common.put(args.output / 'policy-after-load.json', after_load)
        summary = common.capture(model, torch, args.device, inventory, args.output)
        torch.cuda.synchronize(0)
        after_capture = math_policy(torch)
        check_policy(after_capture, policy)
        common.put(args.output / 'policy-after-capture.json', after_capture)
        runtime = {'backend': 'gpu', 'model_identity': identity, 'versions': stack,
            'device_argument': args.device, 'device_name': props.name, 'runtime_uuid': physical,
            'visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES'),
            'free_bytes_before_load': free, 'total_bytes': total, 'host_memory': memory,
            'allocation_receipt_sha256': common.sha(args.allocation_receipt),
            'numerics_policy_sha256': POLICY_SHA256, 'math_policy': after_capture, 'seed': 0,
            'rng_observations': rng, 'native_capture': summary,
            'python': sys.version, 'python_executable': sys.executable,
            'package_sources': {'torch': common.file_ref(torch.__file__),
                                'transformers': common.file_ref(transformers.__file__),
                                'numpy': common.file_ref(numpy.__file__)}}
        result = common.finalize(args, 'gpu', inventory, refs, runtime)
        print(json.dumps(result, allow_nan=False), flush=True)


if __name__ == '__main__':
    main()

"""One finite CPU observer transport export after an actual native terminal0.

No resource, framework, model, probe or independent numerical admission occurs.
Exporter/actual terminal pins remain unready until root freezes observed bytes.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

EXPORT_SHA = '1d9c0b12aba73c73e33b14840a23f60094d7d427decc20f482289912cc1ffcc0'
RECORDER_SHA = '2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'
TOTAL, GENERIC, CHILD, CLEANUP = 960, 920, 900, 20


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4*1024**2), b''): h.update(block)
    return h.hexdigest()


def read(path):
    def pairs(items):
        out = {}
        for key, value in items:
            require(key not in out, 'duplicate JSON key'); out[key] = value
        return out
    return json.loads(Path(path).read_bytes(), object_pairs_hook=pairs,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def put(path, doc):
    with Path(path).open('x', encoding='utf8') as stream:
        json.dump(doc, stream, indent=2, allow_nan=False); stream.write('\n')


def module(path, digest, name):
    path = Path(path)
    require(isinstance(digest, str) and len(digest) == 64 and path.is_file() and not path.is_symlink() and
            path.stat().st_size <= 1024**2 and sha(path) == digest, 'reviewed CPU tool source remains unready or differs')
    spec = importlib.util.spec_from_file_location(name, path); result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    require(not any(name in sys.modules for name in ('torch','torch_npu','numpy','transformers')), 'CPU transport imported a framework')
    return result


def preflight(root, outer_path, backend, here):
    root, outer_path, here = Path(root), Path(outer_path), Path(here)
    require(backend in ('GPU','NPU') and root.is_absolute() and root.is_dir() and not root.is_symlink() and
        outer_path.is_file() and not outer_path.is_symlink() and outer_path.stat().st_size <= 16*1024**2 and
        outer_path.resolve().is_relative_to(root.resolve()) and here.is_dir() and not here.is_symlink() and
        here.resolve().is_relative_to(root.resolve()), 'explicit original task/outer/tool identities required')
    exporter = module(here/'export_observer_evidence_v1.py', EXPORT_SHA, 'observer_pinned_transport_only')
    profile = exporter.ready_profile(backend)
    require(sha(outer_path) == profile['outer_sha256'], 'actual terminal capture outer SHA differs')
    outer = read(outer_path); claim = outer_path.parent; controller_path = claim/'controller-receipt.json'
    require(controller_path.is_file() and not controller_path.is_symlink() and controller_path.stat().st_size <= 16*1024**2 and
        sha(controller_path) == profile['controller_sha256'], 'actual native lifecycle controller SHA differs')
    controller = read(controller_path)
    require(controller.get('task') == 'OBSERVER' and controller.get('status') == 'completed' and
        type(controller.get('returncode')) is int and controller['returncode'] == 0 and controller.get('timed_out') is False and
        controller.get('remaining_descendants') == [], 'actual native observer attempt must have completed0/cleaned')
    fixed = {'task':'OBSERVER','backend':backend,'status':'completed','returncode':0,'timed_out':False,
        'capture_schema_version':2,'native_capture_count':1,'native_forward_calls_total':4,'model_loads':1}
    require(all(key in outer and type(outer[key]) is type(value) and outer[key] == value for key,value in fixed.items()),
        'completed one-model/four-mode observer outer required')
    require(outer['artifacts_manifest_sha256'] == profile['artifacts_manifest_sha256'] and outer['collector_sha256'] == profile['collector_sha256'],
        'actual native collector/manifest binding differs')
    native_seconds = exporter.native_attempt_seconds(backend,controller,read(claim/'claim.json'))
    require(native_seconds + TOTAL <= exporter.WHOLE_SECONDS, 'native attempt has insufficient reserved960s export envelope')
    return exporter, profile, native_seconds


def run(root, outer_receipt, backend):
    started = time.monotonic(); root = Path(root)
    require(os.name == 'posix', 'POSIX finite CPU export controller required')
    here = Path(__file__).resolve().parent; outer_path = Path(outer_receipt)
    exporter, profile, native_seconds = preflight(root,outer_path,backend,here)
    recorder = here/'record_run.py'
    require(recorder.is_file() and not recorder.is_symlink() and sha(recorder) == RECORDER_SHA, 'original generic recorder source differs')
    for name in ('exports','runs'):
        p=root/name; require(not p.is_symlink(), 'owned export/run parent cannot be a symlink'); p.mkdir(exist_ok=True)
        require(p.resolve().is_relative_to(root.resolve()), 'owned export/run parent escapes root')
    # CPU transport marker is distinct from both allocation and native workers.
    put(root/'exports'/'observer-transport-export-once.json', {'kind':'one CPU hash/transport export; not an allocation or model claim',
        'backend':backend,'claimed_utc':datetime.now(timezone.utc).isoformat(),'actual_outer_sha256':profile['outer_sha256'],
        'exporter_sha256':EXPORT_SHA,'runner_sha256':sha(__file__),'automatic_retry':False,'native_executions_started':0})
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    folder=root/'runs'/('compare-observer-'+backend.lower()+'-metadata-export-'+stamp);folder.mkdir(mode=0o700)
    output=root/'exports'/('observer-'+backend.lower()+'-'+('retained' if backend=='NPU' else 'full')+'-'+stamp)
    state={'schema_version':1,'task':'observer-CPU-transport-export','backend':backend,'status':'running',
        'started_utc':datetime.now(timezone.utc).isoformat(),'whole_CPU_seconds':TOTAL,'generic_seconds':GENERIC,
        'export_work_seconds':CHILD,'cleanup_reserve_seconds':CLEANUP,'prior_native_attempt_seconds':native_seconds,
        'cumulative_native_and_reserved_export_seconds':native_seconds+TOTAL,'actual_native_terminal_pins':profile,
        'exporter_sha256':EXPORT_SHA,'runner_sha256':sha(__file__),'recorder_sha256':RECORDER_SHA,
        'outer_receipt':str(outer_path),'output':str(output),'native_executions_started':0,'numeric_admission_performed':False,'automatic_retry':False}
    put(folder/'controller-start.json',state); code=2
    def stop(signum, frame): raise KeyboardInterrupt('observer CPU export bounded signal '+str(signum))
    handlers={sig:signal.signal(sig,stop) for sig in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
    signal.setitimer(signal.ITIMER_REAL,max(.01,TOTAL-CLEANUP-(time.monotonic()-started)))
    try:
        recorded=module(recorder,RECORDER_SHA,'observer_original_generic_record_run')
        require(time.monotonic()-started+GENERIC < TOTAL-CLEANUP, 'insufficient finite generic transport envelope')
        argv=[sys.executable,'-S','-B',str(here/'export_observer_evidence_v1.py'),'--outer-receipt',str(outer_path),
            '--task-root',str(root),'--output',str(output)]
        if backend=='NPU': argv.append('--retain-arrays')
        generic, command=recorded.record_run(folder,'cpu','observer-transport-export',GENERIC,lambda _:argv,cwd=here)
        state['generic_receipt']={'path':str(generic/'command.json'),'sha256':sha(generic/'command.json')}
        state['child_returncode']=command.get('child_returncode');state['timed_out']=command['status']=='timed_out'
        require(command['status']=='completed' and command['returncode']==command['child_returncode']==0,
            'transport exporter failed; keep original generic logs and partial data')
        result=read(generic/'stdout.bin')
        require(result['status']=='observer_transport_export_completed' and result['native_executions_started']==0 and
            result['retained_array_count']==(194 if backend=='NPU' else 0) and result['model_acceptance'] is None,
            'transport result cannot stand in for numerical admission')
        archive=Path(result['archive']); receipt_path=output.with_name(output.name+'-receipt.json')
        require(result==read(receipt_path) and archive.is_file() and not archive.is_symlink() and archive.resolve().is_relative_to(root.resolve()) and
            archive.stat().st_size==result['archive_bytes']<=exporter.MAX_TRANSPORT and sha(archive)==result['archive_sha256'] and
            result['logical_payload_bytes']<=exporter.MAX_LOGICAL and result['transport_allowed_by_actual_size'] is True,
            'actual transport archive/result/caps differ')
        require(sha(here/'export_observer_evidence_v1.py')==EXPORT_SHA and sha(recorder)==RECORDER_SHA, 'CPU export source changed')
        state.update(status='completed',returncode=0,result=result,source_map_path=str(output/'source-map.json'),
            source_map_sha256=result['source_map_sha256'],source_arrays_retained=backend=='NPU',raw_capture_unmodified=True)
        code=0
    except BaseException as exc:
        state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),partial_files_preserved=True)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        for sig, handler in handlers.items(): signal.signal(sig,handler)
        state.update(finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started)
        put(folder/'controller-receipt.json',state)
    print(json.dumps({'status':state['status'],'receipt':str(folder/'controller-receipt.json'),
        'receipt_sha256':sha(folder/'controller-receipt.json'),'result':state.get('result'),'error':state.get('error'),
        'native_executions_started':0,'numeric_admission_performed':False},indent=2),flush=True)
    return code


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--task-root',type=Path,required=True)
    p.add_argument('--outer-receipt',type=Path,required=True);p.add_argument('--backend',choices=['GPU','NPU'],required=True)
    a=p.parse_args();raise SystemExit(run(a.task_root,a.outer_receipt,a.backend))

"""Read-only30s observer idle-failure diagnostic; no native query or signals.

Preserve original failure/source bytes and inspect only recorded process IDs.
Same UID or a Python name alone never proves ownership or a model identity.
"""
import argparse
import base64
from datetime import datetime,timezone
import hashlib
import io
import json
import os
from pathlib import Path,PurePosixPath
import re
import signal
import tarfile
import time

TASK='observer-transparency-20261107/native-v1'
UUID='REDACTED_DEVICE_UUID'
CONTROLLER_SHA='605385b0baecc5c0864fa2302809a08bdb69bc15e2e5d58d3442ac93198d4d75'
MANIFEST_SHA='7a3a2c733e852bf3990ee8a3844ee7594a9cb3966e9e43d1c8cd80dfaa33576a'
LAUNCHER_SHA='1e37d7d146217f7e289fc226f77f2a6ac1b9150b7a49a7f217410d120da5a1ae'
CASE='projects/gemma4-pilot/cases/text-native'
MEMBER,TOTAL=16*1024**2,64*1024**2
ERROR='a shared-instance NPU process is present; no model launch or unrelated stop'


def require(ok,message):
    if not ok:raise ValueError(message)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def parse(raw):
    def pairs(items):
        result={}
        for key,value in items:require(key not in result,'duplicate JSON key');result[key]=value
        return result
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def encoded(doc):return (json.dumps(doc,indent=2,allow_nan=False)+'\n').encode()
def put(path,raw):
    with Path(path).open('xb') as f:f.write(raw)
def safe(name):
    p=PurePosixPath(name);require(isinstance(name,str) and name and not p.is_absolute() and '\\' not in name and str(p)==name and all(x not in ('','.','..') for x in name.split('/')),'unsafe relative metadata path');return p
def original(path,root):
    path,root=Path(path),Path(root)
    require(not str(path).lower().endswith(('.npy','.safetensors','.tar','.gz','.pt','.whl','.part')),'native arrays/model/archive are outside idle diagnostic before IO')
    require(path.is_absolute() and path.is_relative_to(root) and path.resolve().is_relative_to(root),'metadata escapes explicit original root')
    cursor=path
    while cursor!=root:require(not cursor.is_symlink(),'metadata ancestor symlink');cursor=cursor.parent
    require(path.is_file() and path.stat().st_size<=MEMBER,'bounded original regular metadata required')
    with path.open('rb') as f:raw=f.read(MEMBER+1)
    require(len(raw)<=MEMBER,'metadata grew beyond16MiB');return raw


def recorded_processes(raw):
    """Only explicit Process id columns from the archived npu-smi table."""
    text=raw.decode('utf8');pid_column=None;name_column=None;found_header=False;rows=[]
    for line in text.splitlines():
        cells=[x.strip() for x in line.strip().strip('|').split('|')]
        matches=[i for i,x in enumerate(cells) if re.fullmatch(r'process\s+id',x,re.I)]
        if matches:
            require(len(matches)==1,'ambiguous original Process id header');pid_column=matches[0];found_header=True
            names=[i for i,x in enumerate(cells) if re.fullmatch(r'process\s+name',x,re.I)];name_column=names[0] if len(names)==1 else None;continue
        if not found_header or pid_column>=len(cells) or not cells[pid_column].isdigit():continue
        pid=int(cells[pid_column]);require(0<pid<2**31,'recorded process ID out of range')
        name=cells[name_column] if name_column is not None and name_column<len(cells) else None
        require(name is None or len(name)<=256,'bounded recorded process name required')
        rows.append({'pid':pid,'recorded_process_name':name});require(len(rows)<=64,'bounded explicit process-row inventory required')
    require(found_header,'archived Process id header absent; no guessed PID parsing')
    return rows


def proc_observation(pid,proc_root=Path('/proc')):
    """Getter-only PID identity: no cmdline, environ, FD or device reads."""
    require(type(pid) is int and 0<pid<2**31,'explicit recorded PID required');directory=Path(proc_root)/str(pid)
    def stat():
        with (directory/'stat').open('rb') as f:raw=f.read(8193)
        require(len(raw)<=8192,'bounded proc stat required');parts=raw.decode('utf8').rpartition(')')[2].split();require(len(parts)>19,'proc stat fields absent')
        return {'state':parts[0],'ppid':int(parts[1]),'starttime':int(parts[19])}
    try:
        first=stat()
        with (directory/'status').open('rb') as f:raw=f.read(16385)
        require(len(raw)<=16384,'bounded proc status required');name=None;uids=None
        for line in raw.decode('utf8').splitlines():
            if line.startswith('Name:'):name=line.split(':',1)[1].strip()
            if line.startswith('Uid:'):uids=[int(x) for x in line.split(':',1)[1].split()]
        require(isinstance(name,str) and len(name)<=256 and isinstance(uids,list) and len(uids)==4,'proc Name/Uid getter fields absent')
        last=stat()
        if first!=last:return {'pid':pid,'exists_at_observation':True,'identity_stable_during_read':False,'ownership':'unknown; identity changed during getter reads'}
        return {'pid':pid,'exists_at_observation':True,'identity_stable_during_read':True,**first,'name':name,'uids':uids}
    except FileNotFoundError:return {'pid':pid,'exists_at_observation':False,'ownership':'not present at later observation; recorded earlier busy table remains valid'}
    except (PermissionError,ProcessLookupError) as exc:return {'pid':pid,'exists_at_observation':None,'getter_error_type':type(exc).__name__,'ownership':'unknown; getter unavailable'}


def ownership(observed,owned_refs,current_uid):
    if observed.get('exists_at_observation') is not True or observed.get('identity_stable_during_read') is not True:return observed
    matching=[x for x in owned_refs if x['pid']==observed['pid'] and x.get('starttime') is not None and x['starttime']==observed['starttime']]
    same_pid=[x for x in owned_refs if x['pid']==observed['pid']]
    if matching:kind='matches recorded case-owned PID and creation time'
    elif same_pid and any(x.get('starttime') is not None for x in same_pid):kind='recorded case PID reused or different creation; not the recorded process'
    elif observed['uids'][0]!=current_uid:kind='different real UID from diagnostic user; no case ownership established'
    else:kind='same UID only; workload/case ownership unknown'
    return {**observed,'ownership':kind,'matched_case_refs':matching,'process_type_hint':'Python process name only; model/workload unknown' if observed['name'].lower().startswith('python') else 'process name only; model/workload unknown'}


def export(root,output):
    started=time.monotonic();root=Path(root);require(os.name=='posix' and root.is_absolute() and root.is_dir() and not root.is_symlink(),'original POSIX R required');root=root.resolve(strict=True)
    previous=signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('observer idle diagnostic30s')));signal.setitimer(signal.ITIMER_REAL,30)
    try:
        task=root/TASK;claim=task/'claims'/('npu-observer-'+UUID);files={};bytes_total=0
        def add(path,expected=None):
            nonlocal bytes_total
            path=Path(path);raw=original(path,root)
            if expected is not None:require(digest(raw)==expected,'machine-observed original metadata SHA differs')
            key=str(path)
            if key in files:require(files[key]==raw,'original metadata changed between reads')
            else:bytes_total+=len(raw);require(bytes_total<=TOTAL and len(files)<256,'diagnostic64MiB/256 originals exceeded');files[key]=raw
            return raw
        controller_path=claim/'controller-receipt.json';controller=parse(add(controller_path,CONTROLLER_SHA))
        require(controller['task']=='OBSERVER' and controller['task_id']=='gemma4-gpu-npu-observer-v1-20261107' and controller['status']=='failed' and
            controller['returncode']==1 and controller['timed_out'] is False and controller['remaining_descendants']==[] and controller['error']==ERROR,
            'only the machine-observed clean idle-gate failure may be diagnosed')
        manifest_path=task/'source-manifest.json';manifest=parse(add(manifest_path,MANIFEST_SHA));source=task/'source'
        require(manifest['schema_version']==1 and manifest['task_id']==controller['task_id'] and len(manifest['files'])==64,'exact original source manifest required')
        for name,item in manifest['files'].items():
            p=source.joinpath(*safe(name).parts);raw=add(p,item['sha256']);require(len(raw)==item['size_bytes'],'original source size changed')
        add(source/CASE/'transfer/npu_observer_launcher_v1.py',LAUNCHER_SHA)
        for path in sorted(claim.rglob('*')):
            require(not path.is_symlink(),'claim metadata symlink')
            if path.is_file():add(path)
        native_launch=parse(add(task/'launch-once.json'));reference=parse(add(task/'operations-start-reference.json'))
        start_path=Path(reference['start_receipt']);start=parse(add(start_path,reference['start_receipt_sha256']));require(start_path.parent==Path(native_launch['run']) and start_path.resolve().is_relative_to(task/'runs') and
            start['status']=='launcher_spawned_not_result' and start['launcher_sha256']==LAUNCHER_SHA,'original launch intent/start source differs')
        for name in ('stdout.bin','stderr.bin'):add(start_path.parent/name)
        operations_controller=Path(reference['operations_controller'])
        require(operations_controller.parent.parent==root/'runs','original operations controller escapes owned runs')
        for name in ('controller-start.json','controller-receipt.json','stdout.json','stderr.txt'):
            p=operations_controller.parent/name
            if p.is_file():add(p)
        stage_dirs=sorted((root/'runs').glob('compare-observer-npu-stage-*'));require(len(stage_dirs)<=8,'bounded own source-stage evidence inventory exceeded')
        for directory in stage_dirs:
            for name in ('controller-start.json','controller-receipt.json','stdout.json','stderr.txt'):
                p=directory/name
                if p.is_file():add(p)
        busy=[];inventories=[]
        for number in (1,2):
            p=claim/('process-%d.stdout'%number)
            if str(p) in files:
                rows=recorded_processes(files[str(p)]);inventories.append({'idle_gate_number':number,'stdout_path':str(p),'stdout_sha256':digest(files[str(p)]),'recorded_busy_processes':rows})
                busy.extend((number,x) for x in rows)
        require(busy,'recorded explicit Process id rows required; no inference from summary')
        failed_gate=max(n for n,_ in busy);require(not (claim/'capture-receipt.json').exists() and not (claim/'generic-receipt-reference.json').exists() and
            not (claim/'worker-once.json').exists(),'unexpected native model/worker artifacts; diagnostic scope must be reviewed')
        if failed_gate==1:require(not (claim/'probe-once.json').exists() and not (claim/'process-2.stdout').exists(),'first-idle failure contradicts preflight/second gate evidence')
        reservation=parse(files[str(claim/'claim.json')]);owned=[{'role':'native launcher start','pid':start['pid'],'starttime':start.get('starttime')},
            {'role':'permanent claim controller','pid':reservation['controller_pid'],'starttime':reservation['controller_starttime']}]
        for marker in ('probe-once.json','worker-once.json'):
            p=claim/marker
            if str(p) in files:
                d=parse(files[str(p)]);owned.append({'role':marker,'pid':d['pid'],'starttime':None})
        require(all(type(x['pid']) is int and 0<x['pid']<2**31 for x in owned),'recorded owned PID refs invalid')
        pids=sorted({x['pid'] for _,x in busy}|{x['pid'] for x in owned});require(len(pids)<=64,'bounded recorded-only proc inventory exceeded')
        proc=[ownership(proc_observation(pid),owned,os.getuid()) for pid in pids]
        summary={'schema_version':1,'kind':'observer-npu-idle-failure-diagnostic-v1','status':'original_idle_failure_diagnosed_not_a_capture_or_admission',
            'observed_utc':datetime.now(timezone.utc).isoformat(),'original_controller_sha256':CONTROLLER_SHA,'failed_idle_gate_number':failed_gate,'recorded_idle_inventories':inventories,
            'recorded_case_owned_pid_refs':owned,'later_proc_getter_observations':proc,'proc_fields_read':['stat: state,ppid,starttime','status: Name,Uid'],
            'model_loads_started_by_failed_attempt':0,'native_model_forward_calls_by_failed_attempt':0,'native_model_work_retried':False,'original_start_and_claim_remain_spent':True,
            'hardware_queries_by_diagnostic':0,'framework_imports_by_diagnostic':0,'signals_sent':0,'native_activation_allowed':False,'acceptance':None,
            'limitations':['Same UID or Python name alone cannot identify case ownership or a model/workload',
                'A later disappeared process does not retroactively make the original busy inventory idle',
                'Only explicitly recorded busy PIDs and original case-owned PID refs were inspected; no process scan, cmdline, environ, device query or stop occurred']}
        exports=root/'exports';output=Path(output);require(exports.is_dir() and not exports.is_symlink() and output.is_absolute() and output.parent==exports and
            output.resolve().is_relative_to(root) and not output.exists() and not output.is_symlink(),'exclusive new original-root exports target required')
        output.mkdir(mode=0o700);(output/'originals').mkdir();catalog={}
        for index,(logical,raw) in enumerate(sorted(files.items())):
            require(original(Path(logical),root)==raw,'original diagnostic source changed while copying');name='originals/%03d%s'%(index,'.py' if logical.endswith('.py') else '.bin' if logical.endswith('.bin') else '.json' if logical.endswith('.json') else '.txt')
            put(output/name,raw);catalog[logical]={'path':name,'sha256':digest(raw),'size_bytes':len(raw)}
        put(output/'diagnostic.json',encoded(summary));put(output/'source-map.json',encoded({'schema_version':1,'original_bytes_preserved':True,'files':catalog,'native_activation_allowed':False}))
        members={p.relative_to(output).as_posix():{'sha256':digest(p.read_bytes()),'size_bytes':p.stat().st_size} for p in output.rglob('*') if p.is_file()};archive=output.with_name(output.name+'.tar.gz')
        with archive.open('xb') as f,tarfile.open(fileobj=f,mode='w:gz',format=tarfile.USTAR_FORMAT) as t:
            for name,item in sorted(members.items()):
                raw=(output/name).read_bytes();require(digest(raw)==item['sha256'],'copied diagnostic bytes changed');info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;t.addfile(info,io.BytesIO(raw))
        require(archive.stat().st_size<=16*1024**2,'diagnostic gzip exceeds16MiB')
        for logical,raw in files.items():require(original(Path(logical),root)==raw,'original failed evidence changed during archive')
        raw=archive.read_bytes();envelope=output.with_name(output.name+'-json-base64.txt');put(envelope,encoded({'schema_version':1,'kind':'observer-npu-idle-failure-diagnostic-transport-v1','files':members,
            'archive':{'path':str(archive),'bytes':len(raw),'sha256':digest(raw),'base64':base64.b64encode(raw).decode()},'native_activation_allowed':False,'acceptance':None}))
        require(envelope.stat().st_size<=24*1024**2 and time.monotonic()-started<30,'diagnostic envelope/time cap exceeded')
        return {'status':summary['status'],'failed_idle_gate_number':failed_gate,'recorded_busy_pids':sorted({x['pid'] for _,x in busy}),'later_proc_getter_observations':proc,
            'original_documents':len(files),'original_bytes_preserved':True,'archive':{'path':str(archive),'bytes':len(raw),'sha256':digest(raw)},
            'envelope':{'path':str(envelope),'bytes':envelope.stat().st_size,'sha256':digest(envelope.read_bytes())},'elapsed_seconds':time.monotonic()-started,
            'native_model_work_retried':False,'hardware_queries':0,'signals_sent':0,'native_activation_allowed':False}
    finally:signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    print(json.dumps(export(args.root,args.output),indent=2,allow_nan=False),flush=True)

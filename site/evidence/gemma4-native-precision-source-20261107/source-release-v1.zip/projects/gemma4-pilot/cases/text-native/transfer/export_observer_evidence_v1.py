"""Bounded observer hash/transport export; no framework, model or numeric admission.

GPU exports copy its four raw BF16 logits,188 NPY rows and two packed BF16 samples. Only NPU may explicitly
retain those194 source arrays. Original absolute source-map keys and all raw
receipt bytes survive relocation. A successfully built archive must still pass
the independent observer admission; this exporter cannot establish model acceptance.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import tarfile
import time

STAGE_SHA = '54683b3e1697b8358e7371d516596c42db347ff04de7253231236498ad15e22d'
EXPECTED_SHA = '2f9821d74578735f2d8f1c82ec86c5f28dedc077ae7e293dce474e701cd7181a'
MAX_TRANSPORT = 1536 * 1024 ** 2
MAX_LOGICAL = 1073741824
PROOF_SHA = '59830ffb67bafb2c0497ef954392fb4fc830dc388afc16a7750195cd09986e54'
CPU_PROOF_SHA = '1c5bbfc0089a78cf5d8564a666feb11bf24144cbbb6814a7003da12cce2ebd63'
INPUT_SHA = '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
MAX_CAPTURE = 1073741824
WHOLE_SECONDS,EXPORT_WHOLE_SECONDS = 3600,960
MAX_TASK_BYTES = 4 * 1024 ** 3
MAX_SMALL = 16 * 1024 ** 2
MIN_FREE = 5 * 1024 ** 3
POSITIONS = sorted(set(i*127//15 for i in range(16)) | set(range(127,159)))
MODES = ['off-before','hooks-only','off-after','hooks-plus-dispatch-metadata']
LARGE_NAMES = {'modes/%s/raw-native-logits.safetensors'%mode for mode in MODES}
LARGE_NAMES |= {'modes/%s/dist-p%03d.npy'%(mode,p) for mode in MODES for p in POSITIONS}
LARGE_NAMES |= {'modes/%s/boundary-samples.safetensors'%mode for mode in MODES[1::2]}
TASK_ID = 'gemma4-gpu-npu-observer-v1-20261107'
# Freeze only from root-observed completed0 raw bytes. Unknown means refuse,
# never permission to guess a controller, source manifest, launcher or output.
ACTUAL_CAPTURE_PINS = {'GPU': {'outer_sha256': '71538b5c387d56997f5b1bf3553d8f29236f6f1255f63e3943080a3b5bb01765', 'controller_sha256': '6a0e0777938a1d68d12cb95b1d8648cad8cfea7f1ae731bce817437a5df7e29c', 'artifacts_manifest_sha256': 'cec57b3ccc5bba9841cf74256d86937c1427bab1b6264d5126df8326e683a229', 'source_manifest_path': '/srv/precision-task/observer-transparency-20261107-gpu-v2/source-manifest.json', 'source_manifest_sha256': 'bcca74886a74808fa1d6b3bd09734b7b4eed8bd549a30f3793ef21b44a2e5437', 'launcher_path': '/srv/precision-task/observer-transparency-20261107-gpu-v2/h100_observer_lifecycle_v2.py', 'launcher_sha256': '3083f7b09f37f6c67e2bc49293231ace71038abc7c298025341882534c4a211a', 'collector_sha256': 'e0fd43dd50f31b7e4f8280616f7b2655ff22e1166e41e6c229206777b61f3191'}, 'NPU': None}
HEX = re.compile(r'^[a-f0-9]{64}$')


def ready_profile(backend):
    profile = ACTUAL_CAPTURE_PINS.get(backend)
    fields = {'outer_sha256','controller_sha256','artifacts_manifest_sha256','source_manifest_path','source_manifest_sha256',
              'launcher_path','launcher_sha256','collector_sha256'}
    require(isinstance(profile,dict) and set(profile)==fields and
            all(isinstance(profile[name],str) and HEX.fullmatch(profile[name]) for name in fields if name.endswith('_sha256')),
            'actual completed observer terminal/manifest/source pins remain unready')
    for name in ('source_manifest_path','launcher_path'):
        value=profile[name];require(isinstance(value,str) and value.startswith('/') and '\\' not in value and
            str(PurePosixPath(value))==value and '..' not in PurePosixPath(value).parts,'actual original source identity required')
    return profile


def safe_relative(name):
    part = PurePosixPath(name)
    require(isinstance(name, str) and name and not part.is_absolute() and '\\' not in name and
        str(part) == name and all(p not in ('', '.', '..') for p in name.split('/')), 'unsafe artifact member')
    return name


def require(ok, message):
    if not ok:
        raise ValueError(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    def pairs(items):
        value = {}
        for key, item in items:
            require(key not in value, 'duplicate JSON key')
            value[key] = item
        return value
    def reject(value):
        raise ValueError('nonfinite JSON token: ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'),
                      object_pairs_hook=pairs, parse_constant=reject)


def put(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def regular(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'original regular file required: ' + str(path))
    return path


def digest(path, deadline):
    value = hashlib.sha256()
    with regular(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 ** 2), b''):
            require(time.monotonic() < deadline, 'export deadline reached')
            value.update(block)
    return value.hexdigest()


def tree_size(root):
    total = 0
    for path in Path(root).rglob('*'):
        require(not path.is_symlink(), 'task tree contains symlink')
        if path.is_file():
            total += path.stat().st_size
    return total


def flag(argv, name):
    require(isinstance(argv, list) and argv.count(name) == 1, 'unique literal argv flag required: ' + name)
    position = argv.index(name)
    require(position + 1 < len(argv), 'argv flag has no literal value')
    return argv[position + 1]


def native_attempt_seconds(backend,controller,claim):
    require(controller.get('metadata_export_reserved_seconds') == EXPORT_WHOLE_SECONDS and
        controller.get('controller_work_seconds') == 2620 and claim.get('whole_attempt_seconds') == WHOLE_SECONDS,
        'observer cumulative capture/export budget declaration differs')
    if backend == 'NPU':
        value=controller.get('wall_seconds')
    else:
        started=datetime.fromisoformat(claim['entry_started_utc'].replace('Z','+00:00'))
        finished=datetime.fromisoformat(controller['finished_utc'].replace('Z','+00:00'))
        require(started.tzinfo is not None and finished.tzinfo is not None and
            started.utcoffset().total_seconds()==finished.utcoffset().total_seconds()==0,'actual GPU attempt timestamps must be UTC')
        value=(finished-started).total_seconds()
    require(type(value) in (int,float) and math.isfinite(value) and value>=0 and
        value+EXPORT_WHOLE_SECONDS<=WHOLE_SECONDS,'actual native duration leaves insufficient960s CPU export budget')
    return value


def export(outer_receipt, task_root, output, retain_arrays=False, timeout=900):
    require(os.name == 'posix' and timeout == 900, 'POSIX export with fixed900s bound required')
    started = time.monotonic()
    deadline = started + timeout
    root = Path(task_root).resolve(strict=True)
    outer_path = regular(outer_receipt).resolve()
    require(not Path(output).is_symlink(),'new export output cannot be a symlink')
    output = Path(output).resolve()
    require(outer_path.is_relative_to(root) and output.is_relative_to(root) and
            output.parent.is_dir() and not output.exists(), 'new export and original outer receipt must belong to explicit task root')
    require(not Path(task_root).is_symlink() and shutil.disk_usage(root).free >= MIN_FREE,
            'task root identity/free5GiB gate failed')
    archive = output.with_name(output.name + '.tar.gz')
    require(not archive.exists(), 'archive must be new')
    outer = read(outer_path)
    backend = outer.get('backend')
    profile = ready_profile(backend)
    require(digest(outer_path, deadline) == profile['outer_sha256'], 'actual outer receipt byte SHA differs')
    controller_path = regular(outer_path.parent / 'controller-receipt.json')
    require(digest(controller_path, deadline) == profile['controller_sha256'], 'actual native controller byte SHA differs')
    controller_preflight = read(controller_path)
    require(controller_preflight.get('status') == 'completed' and controller_preflight.get('returncode') == 0 and
            controller_preflight.get('timed_out') is False and controller_preflight.get('remaining_descendants') == [],
            'actual native lifecycle must have completed0 and cleaned before array IO')
    require(tree_size(root) <= MAX_TASK_BYTES, 'existing task exceeds4GiB sampled budget')
    require(outer.get('task') == 'OBSERVER' and outer.get('status') == 'completed' and
            outer.get('returncode') == 0 and outer.get('timed_out') is False and
            backend in ('GPU', 'NPU') and outer.get('native_capture_count') == 1 and
            outer.get('native_forward_calls_total') == 4 and outer.get('model_loads') == 1,
            'completed one-capture observer outer receipt required')
    require(retain_arrays is (backend == 'NPU'), 'GPU copies all194 arrays; NPU must explicitly retain all194 at source')
    require(outer['stage_spec_source_sha256'] == STAGE_SHA and
            outer['expected_inventory_source_sha256'] == EXPECTED_SHA and
            outer['i04_prerequisite_source_sha256'] == PROOF_SHA and outer.get('cpu_prerequisite_source_sha256') == CPU_PROOF_SHA and
            outer.get('input_sha256') == INPUT_SHA,
            'frozen stage/expected/two-input/two-prerequisite identities differ')
    artifacts = Path(outer['output_dir'])
    require(artifacts.is_dir() and not artifacts.is_symlink() and
            artifacts.resolve().is_relative_to(root), 'new native output must belong to task')
    require(all(flag(outer['argv'], name) == value for name, value in {
        '--input': outer['input_path'], '--allocation-receipt': outer['allocation_path'], '--backend': backend.lower(),
        '--stage-spec': outer['stage_spec_source_path'], '--stage-spec-sha256': STAGE_SHA,
        '--expected-inventory': outer['expected_inventory_source_path'],
        '--expected-inventory-sha256': EXPECTED_SHA,
        '--i04-prerequisite': outer['i04_prerequisite_source_path'],
        '--i04-prerequisite-sha256': PROOF_SHA,
        '--cpu-prerequisite': outer['cpu_prerequisite_source_path'],
        '--cpu-prerequisite-sha256': CPU_PROOF_SHA, '--output': str(artifacts)}.items()),
        'outer identity does not match original literal collector argv')
    command = read(outer['generic_receipt']['path'])
    require(Path(outer['generic_receipt']['path']).resolve().is_relative_to(root),
            'generic recorder run escapes new task')
    require(command.get('status') == 'completed' and command.get('returncode') == 0 and
            command.get('argv') == outer['argv'] and command.get('start') == outer['started_utc'] and
            command.get('timeout') == (1200 if backend == 'GPU' else 1500), 'generic receipt differs from observer envelope')
    status = read(artifacts / 'status.json')
    manifest = read(artifacts / 'artifacts-manifest.json')
    require(digest(artifacts / 'artifacts-manifest.json', deadline) == profile['artifacts_manifest_sha256'] == outer['artifacts_manifest_sha256'] and
            outer['collector_sha256'] == profile['collector_sha256'] and outer.get('capture_schema_version') == 2,
            'actual frozen collector/manifest capture schema differs')
    require(status.get('status') == 'completed' and
            status.get('artifacts_manifest_sha256') == outer['artifacts_manifest_sha256'] and
            manifest.get('backend') == backend.lower() and manifest.get('stage_spec_sha256') == STAGE_SHA and
            manifest.get('expected_inventory_sha256') == EXPECTED_SHA and
            manifest.get('i04_prerequisite_sha256') == PROOF_SHA and manifest.get('cpu_prerequisite_sha256') == CPU_PROOF_SHA and
            manifest.get('capture_schema_version') == 2 and manifest.get('files',{}).get('input.json',{}).get('sha256') == INPUT_SHA and
            manifest.get('kind') == 'observer-capture-artifacts' and len(manifest.get('files',{})) == (452 if backend=='GPU' else 453),
            'capture completion/manifest binding differs')
    require(tree_size(artifacts)<=MAX_CAPTURE,'native capture exceeds1GiB product bound')
    require(all(not p.is_symlink() for p in artifacts.rglob('*')), 'artifact tree contains symlink')
    require({p.relative_to(artifacts).as_posix() for p in artifacts.rglob('*') if p.is_file()} == set(manifest['files']) |
            {'artifacts-manifest.json', 'status.json'}, 'artifact inventory is not exact')
    require({name for name in manifest['files'] if name.endswith(('.npy', '.safetensors'))} == LARGE_NAMES,
            'only exact new observer4raw/188NPY/2packed sample files may be exported')
    output.mkdir(mode=0o700)
    state = {'schema_version': 1, 'status': 'exporting', 'started_utc': utc(),
             'task': 'OBSERVER', 'backend': backend, 'native_executions_started': 0,
             'timeout_seconds': timeout, 'max_transport_bytes': MAX_TRANSPORT,
             'max_logical_transport_bytes': MAX_LOGICAL,
             'max_new_task_bytes_sampled': MAX_TASK_BYTES, 'acceptance': None,
             'numeric_admission': 'Not performed by this hash/transport exporter.'}
    catalog, aliases = {}, {}
    claim = outer_path.parent

    def add_alias_map(path, expected=None):
        path = regular(path)
        require(path.resolve().is_relative_to(root), 'frozen source map escapes explicit new task')
        if expected is not None:
            require(digest(path, deadline) == expected, 'frozen source map SHA differs')
        for original, ref in read(path).items():
            require(PurePosixPath(original).is_absolute() and isinstance(ref, dict) and
                    {'path', 'sha256'} <= set(ref), 'invalid original/frozen source mapping')
            require(not str(original).lower().endswith(('.npy','.safetensors','.tar','.gz','.whl','.pt')) and
                    not str(ref['path']).lower().endswith(('.npy','.safetensors','.tar','.gz','.whl','.pt')),
                    'source alias map cannot introduce unplanned native arrays')
            actual = regular(ref['path'])
            require(actual.resolve().is_relative_to(root), 'frozen copy escapes task')
            normalized = {'path': str(actual), 'sha256': ref['sha256'],
                          'size_bytes': ref.get('size_bytes', actual.stat().st_size)}
            if original in aliases:
                require(aliases[original]['sha256'] == normalized['sha256'] and
                        aliases[original]['size_bytes'] == normalized['size_bytes'], 'conflicting frozen source aliases')
            aliases[original] = normalized

    def add(original, expected=None, size=None, role='evidence'):
        original = str(original)
        require(PurePosixPath(original).is_absolute() and '\\' not in original,
                'original source keys must be absolute POSIX paths')
        original_path = Path(original)
        large = original_path.is_relative_to(artifacts) and original_path.relative_to(artifacts).as_posix() in LARGE_NAMES
        require(large or not original.lower().endswith(('.npy','.safetensors','.tar','.gz','.whl','.pt')),
                'unplanned array/model/archive ref rejected before filesystem IO')
        alias = aliases.get(original)
        actual_name = alias['path'] if alias is not None else original
        require(large or not str(actual_name).lower().endswith(('.npy','.safetensors','.tar','.gz','.whl','.pt')),
                'unplanned frozen array/model/archive rejected before filesystem IO')
        actual = regular(actual_name)
        if alias is not None:
            require(expected is None or expected == alias['sha256'], 'reference disagrees with frozen copy SHA')
            expected = alias['sha256']
            require(alias['size_bytes'] == actual.stat().st_size, 'frozen copy size differs')
        require(large or actual.stat().st_size <= MAX_SMALL, 'large model/environment/legacy array export prohibited')
        require(not original.endswith('.py') or actual.stat().st_size<=1024**2,'Python code/source evidence exceeds1MiB')
        observed = digest(actual, deadline)
        require(expected is None or observed == expected, 'original/frozen evidence SHA differs: ' + original)
        require(size is None or actual.stat().st_size == size, 'evidence size differs')
        entry = {'actual': str(actual), 'sha256': observed, 'size': actual.stat().st_size, 'large': large}
        if original in catalog:
            require(all(catalog[original][k] == entry[k] for k in ('sha256', 'size', 'large')), 'duplicate source identity differs')
            catalog[original]['roles'].add(role)
        else:
            catalog[original] = dict(entry, roles={role})

    try:
        maps = ['frozen-source-map.json', 'frozen-bootstrap-map.json',
                'frozen-native-packages-map.json', 'frozen-runtime-source-map.json', 'frozen-runtime-map.json']
        for name in maps:
            path = claim / name
            if path.exists():
                add_alias_map(path)
        require('runtime_source_map_path' in outer, 'runtime implementation source map missing')
        add_alias_map(outer['runtime_source_map_path'], outer['runtime_source_map_sha256'])
        controller = read(claim / 'controller-receipt.json')
        require(controller.get('task') == 'OBSERVER' and controller.get('status') == 'completed' and
            controller.get('returncode') == 0 and controller.get('timed_out') is False and
            controller.get('remaining_descendants') == [], 'native lifecycle must be completed and cleaned')
        native_seconds=native_attempt_seconds(backend,controller,read(claim/'claim.json'))
        state['prior_native_attempt_seconds']=native_seconds
        state['cumulative_attempt_budget_seconds']=WHOLE_SECONDS
        state['reserved_export_whole_seconds']=EXPORT_WHOLE_SECONDS
        source_manifest_path = regular(profile['source_manifest_path'])
        require(source_manifest_path.resolve().is_relative_to(root) and digest(source_manifest_path,deadline)==profile['source_manifest_sha256'], 'actual frozen deployment source manifest differs')
        launcher_path = regular(profile['launcher_path'])
        require(launcher_path.resolve().is_relative_to(root) and digest(launcher_path,deadline)==profile['launcher_sha256'] and
                outer['source_sha256'].get(str(launcher_path))==profile['launcher_sha256'], 'actual reviewed native launcher/source chain differs')
        add(source_manifest_path, profile['source_manifest_sha256'], role='deployment_source_manifest')
        add(launcher_path, profile['launcher_sha256'], role='native_lifecycle_source')
        deployment = read(source_manifest_path)
        stage_document = read(outer['stage_spec_source_path'])
        declared_root = stage_document['native_task_roots'][backend]
        namespace_override = outer.get('deployment_namespace_override')
        if str(root) != declared_root:
            require(backend == 'GPU' and isinstance(namespace_override,dict) and
                    deployment.get('deployment_namespace_override') == namespace_override and
                    namespace_override.get('frozen_stage_spec_sha256') == STAGE_SHA and
                    namespace_override.get('independent_expected_inventory_sha256') == EXPECTED_SHA and
                    namespace_override.get('frozen_stage_declared_GPU_root') == declared_root and
                    namespace_override.get('approved_GPU_root') == str(root) and
                    namespace_override.get('lifecycle_sha256') == profile['launcher_sha256'] and
                    namespace_override.get('literal_stage_root_agreement_claimed') is False and
                    namespace_override.get('numeric_geometry_changed') is False,
                    'approved versioned namespace override must remain explicit and unchanged')
        else:
            require(namespace_override is None or namespace_override == deployment.get('deployment_namespace_override'),
                    'deployment namespace metadata conflicts with literal stage root')
        state['deployment_namespace_override'] = namespace_override
        add(outer_path, role='outer_receipt')
        for path in sorted(claim.rglob('*')):
            require(not str(path).lower().endswith(('.npy','.safetensors','.tar','.gz','.whl','.pt')),
                    'claim metadata closure cannot contain unplanned arrays/archives')
            require(not path.is_symlink(), 'claim evidence contains symlink')
            if path.is_file():
                add(path, role='claim_closure')
        require(set(outer['source_sha256']) == set(outer['dependency_paths']), 'outer source/dependency inventory differs')
        for original, expected in outer['source_sha256'].items():
            add(original, expected, role='outer_frozen_source')
        for path_key, sha_key in [('collector_path', 'collector_sha256'), ('input_path', 'input_sha256'),
                ('allocation_path', 'allocation_sha256'), ('expected_inventory_source_path', 'expected_inventory_source_sha256'),
                ('stage_spec_source_path', 'stage_spec_source_sha256'),
                ('i04_prerequisite_source_path', 'i04_prerequisite_source_sha256'),
                ('cpu_prerequisite_source_path','cpu_prerequisite_source_sha256')]:
            add(outer[path_key], outer[sha_key], role=path_key)
        generic = outer['generic_receipt']
        add(generic['path'], generic['sha256'], role='original_generic_receipt')
        for name in ('stdout.bin', 'stderr.bin', 'execution.json'):
            path = Path(generic['path']).parent / name
            require(path.is_file(), 'generic log/profile missing')
            add(path, role='original_generic_log_or_profile')
        add(artifacts / 'artifacts-manifest.json', outer['artifacts_manifest_sha256'], role='artifact_manifest')
        add(artifacts / 'status.json', role='capture_status')
        for name, ref in manifest['files'].items():
            safe_relative(name)
            add(artifacts / name, ref['sha256'], ref['size_bytes'], role='native_capture_artifact')
        runtime = read(artifacts / 'runtime.json')
        refs = []
        def collect_refs(value):
            if isinstance(value, dict):
                if set(value) == {'path', 'sha256', 'size_bytes'}:
                    refs.append(value)
                for nested in value.values(): collect_refs(nested)
            elif isinstance(value, list):
                for nested in value: collect_refs(nested)
        collect_refs(runtime)
        for ref in refs:
            add(ref['path'], ref['sha256'], ref['size_bytes'], role='actual_runtime_source')
        require(sum(entry['size'] for entry in catalog.values() if not
            (retain_arrays and entry['large'])) <= MAX_LOGICAL,
            'actual copied evidence exceeds1GiB logical transport cap')
        files = {}
        for index, (original, entry) in enumerate(sorted(catalog.items())):
            require(time.monotonic() < deadline, 'export deadline reached')
            item = {'sha256': entry['sha256'], 'size': entry['size'], 'roles': sorted(entry['roles'])}
            if retain_arrays and entry['large']:
                item['retained_at_source'] = True
            else:
                relative = 'payload/%04d/%s' % (index, Path(original).name)
                destination = output / relative
                destination.parent.mkdir(parents=True)
                observed = hashlib.sha256()
                with Path(entry['actual']).open('rb') as source, destination.open('xb') as target:
                    for block in iter(lambda: source.read(4 * 1024 ** 2), b''):
                        require(time.monotonic() < deadline, 'export deadline reached')
                        target.write(block)
                        observed.update(block)
                require(observed.hexdigest() == entry['sha256'] and destination.stat().st_size == entry['size'],
                        'source changed while copying original bytes')
                item['path'] = relative
            files[original] = item
        require(sum(entry['large'] for entry in catalog.values()) == 194, 'exact194 observer large source objects required')
        source_map = {'schema_version': 1, 'request': {'task': 'OBSERVER', 'backend': backend,
            'outer_receipt': str(outer_path)}, 'files': files, 'raw_bytes_preserved': True,
            'full_array_hashes_checked': 194, 'retained_array_count': 194 if retain_arrays else 0,
            'numeric_admission': 'Not performed; independent raw-BF16 admission is still required.', 'acceptance': None}
        source_map['deployment_namespace_override'] = namespace_override
        source_map['actual_native_terminal_pins'] = profile
        put(output / 'source-map.json', source_map)
        state.update(status='payload_copied_and_rehashed', mapped_files=len(files),
            copied_files=sum('path' in x for x in files.values()),
            retained_arrays=194 if retain_arrays else 0,
            source_map_sha256=digest(output / 'source-map.json', deadline))
        put(output / 'export-summary.json', state)
        require(tree_size(root) <= MAX_TASK_BYTES, 'task capture+payload exceeds4GiB sampled budget')
        logical_bytes = tree_size(output)
        require(logical_bytes <= MAX_LOGICAL, 'actual logical payload exceeds1GiB transport cap')
        # Regular members only; no path rewriting inside original evidence.
        with archive.open('xb') as destination:
            with tarfile.open(fileobj=destination, mode='w:gz') as package:
                for path in sorted(output.rglob('*')):
                    if path.is_file():
                        require(time.monotonic() < deadline, 'archive deadline reached')
                        package.add(path, arcname=path.relative_to(output).as_posix(), recursive=False)
                        require(destination.tell() <= MAX_TRANSPORT, 'actual compressed archive exceeds1.5GiB transport cap')
        require(archive.stat().st_size <= MAX_TRANSPORT, 'actual compressed archive exceeds1.5GiB transport cap')
        require(tree_size(root) <= MAX_TASK_BYTES, 'task including archive exceeds4GiB sampled budget')
        require(tree_size(output) == logical_bytes and
            digest(output / 'source-map.json', deadline) == state['source_map_sha256'],
            'export metadata changed during archive creation')
        for original, item in files.items():
            path = output / item['path'] if 'path' in item else Path(catalog[original]['actual'])
            require(path.stat().st_size == item['size'] and digest(path, deadline) == item['sha256'],
                    'payload or retained source changed during archive creation')
            actual = Path(catalog[original]['actual'])
            if actual != path:
                require(actual.stat().st_size == item['size'] and digest(actual, deadline) == item['sha256'],
                        'original/frozen source changed after payload/archive creation')
        receipt = {'schema_version': 1, 'status': 'observer_transport_export_completed',
            'finished_utc': utc(), 'archive': str(archive), 'archive_bytes': archive.stat().st_size,
            'archive_sha256': digest(archive, deadline), 'source_map_sha256': state['source_map_sha256'],
            'logical_payload_bytes': logical_bytes, 'max_logical_transport_bytes': MAX_LOGICAL,
            'max_encoded_transport_bytes': MAX_TRANSPORT, 'transport_allowed_by_actual_size': True, 'retained_array_count': state['retained_arrays'],
            'model_acceptance': None, 'native_executions_started': 0}
        put(output.with_name(output.name + '-receipt.json'), receipt)
        return receipt
    except BaseException as exc:
        put(output.with_name(output.name + '-failure.json'), {'status': 'failed', 'finished_utc': utc(),
            'error_type': type(exc).__name__, 'error': str(exc), 'partial_payload_and_archive_preserved': True,
            'transport_allowed': False, 'automatic_retry': False})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--outer-receipt', type=Path, required=True)
    parser.add_argument('--task-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--retain-arrays', action='store_true')
    args = parser.parse_args()
    def expire(_signum, _frame):
        raise TimeoutError('observer CPU exporter exceeded900 seconds')
    signal.signal(signal.SIGALRM, expire)
    signal.setitimer(signal.ITIMER_REAL, 900)
    try:
        result = export(args.outer_receipt, args.task_root, args.output, args.retain_arrays)
        print(json.dumps(result, allow_nan=False))
        return 0
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


if __name__ == '__main__':
    raise SystemExit(main())

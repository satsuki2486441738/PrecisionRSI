"""Actual archived schema and tamper checks; no public/Git writes or native work."""
import copy
import importlib.util
import json
from pathlib import Path
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('i04_history_renderer', HERE / 'render_i04_history_v1.py')
M = importlib.util.module_from_spec(spec); spec.loader.exec_module(M)
REPO = HERE.parents[4]
CANDIDATE = HERE / 'publication-candidate-i04-20261106T213515Z'
REVISION = 'b9f0ce6ec3d930df6fe251c847685ab65402e8c5'


class HistoryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.documents = {n: M.read((CANDIDATE / n).read_bytes()) if n.endswith('.json') else
                         (CANDIDATE / n).read_text('utf8') for n in M.FILES}
        cls.pins = {n: M.digest((CANDIDATE / n).read_bytes()) for n in M.FILES}
        cls.history_raw = (REPO / 'site/data/evaluations.json').read_bytes()
        cls.previous = M.read(cls.history_raw)['evaluations'][-1]
        cls.prior = M.read((REPO / 'site/evidence' / cls.previous['id'] / 'coverage.json').read_bytes())

    def test_actual18pair_projection_keeps_unequal_counts_and_policies(self):
        M.validate_evidence(self.documents, self.prior)
        e = M.build_entry(self.documents, self.pins, REVISION, self.previous)
        self.assertEqual(e['comparisons'][0]['side_ids'], ['gpu-alone-a-a', 'npu-alone-a-a'])
        self.assertEqual([len(x['metrics']) for x in e['comparisons']], [28] * 18)
        self.assertEqual([x['coverage'][0]['expected'] for x in e['comparisons']], [159] * 3 + [95] * 3 + ([159] * 3 + [95] * 3) * 2)
        self.assertEqual(e['comparisons'][3]['metrics'][1]['value'], 0.03505970429405074)
        gpu, npu = e['sides'][0]['settings'], e['sides'][6]['settings']
        self.assertIn('cuda_matmul_allow_tf32', gpu); self.assertNotIn('matmul_allow_hf32', gpu)
        self.assertIn('matmul_allow_hf32', npu); self.assertNotIn('cuda_matmul_allow_tf32', npu)
        self.assertEqual(e['sides'][3]['settings']['execution']['physical_offset'], 64)
        self.assertFalse(e['sides'][3]['settings']['execution']['use_cache'])
        self.assertFalse(e['full_core_complete']); self.assertIsNone(e['acceptance'])

    def test_append_preserves108_original_objects_and_UTF8_prefix(self):
        entry = M.build_entry(self.documents, self.pins, REVISION, self.previous)
        original = M.read(self.history_raw); new, prefix_sha = M.append_history(self.history_raw, entry)
        self.assertEqual(M.read(new)['evaluations'][:-1], original['evaluations'])
        marker = b'\n  ]\n}\n'; self.assertTrue(new.startswith(self.history_raw[:-len(marker)] + b',\n'))
        self.assertEqual(len(prefix_sha), 64)
        self.assertEqual(M.digest((REPO / 'site/data/repairs.json').read_bytes()), M.REPAIRS_SHA)

    def test_claiming_all846_independently_replayed_is_rejected(self):
        d = copy.deepcopy(self.documents)
        d['independent-checks.json']['scope']['independent_distribution_pair_rows'] = 846
        with self.assertRaisesRegex(ValueError, 'selected283row'):
            M.validate_evidence(d, self.prior)

    def test_B95_cannot_be_relabelled159_or_pooled(self):
        d = copy.deepcopy(self.documents)
        for name in ('selected-targets.json', 'selected-metrics.json'):
            d[name]['target_pairs'][3]['coverage'] = {'expected': 159, 'paired': 159}
        with self.assertRaisesRegex(ValueError, 'per-request'):
            M.validate_evidence(d, self.prior)

    def test_full_plan_and_extra_status_transitions_are_rejected(self):
        for field in ('status', 'full_plan_task_complete'):
            d = copy.deepcopy(self.documents); row = next(x for x in d['coverage.json']['tasks'] if x['task_id'] == 'Q01')
            row[field] = 'complete' if field == 'status' else True
            with self.assertRaises(ValueError): M.validate_evidence(d, self.prior)

    def test_editorial_report_uses_real_archive_blob_SHA(self):
        repairs = (REPO / 'site/data/repairs.json').read_bytes()
        d, pins = M.archive_files(REPO, REVISION, self.history_raw, repairs)
        self.assertEqual(pins['report.md'], '9f470dfead3ef263151fe5035d172a83a713aec64e0eb68027d41e91cdd2d696')
        self.assertNotEqual(pins['report.md'], self.pins['report.md'])
        self.assertEqual({n: pins[n] for n in M.FIXED}, M.FIXED)
        M.validate_evidence(d, self.prior)

    def test_changed_archive_blob_is_rejected_without_writes(self):
        real_git = M.git
        def changed(repo, *args):
            raw = real_git(repo, *args)
            return raw + b' ' if args == ('show', REVISION + ':' + M.PREFIX + 'selected-metrics.json') else raw
        with patch.object(M, 'git', side_effect=changed):
            with self.assertRaisesRegex(ValueError, 'archived blob'):
                M.archive_files(REPO, REVISION, self.history_raw, (REPO / 'site/data/repairs.json').read_bytes())

    def test_missing_or_placeholder_commit_refused_before_git(self):
        with patch.object(M, 'git', side_effect=AssertionError('must not query Git')):
            for revision in ('', 'ACTUAL_ARCHIVE_COMMIT', '1' * 39):
                with self.assertRaisesRegex(ValueError, 'actual full40hex'):
                    M.archive_files(REPO, revision, self.history_raw, b'')


if __name__ == '__main__':
    unittest.main()

"""Export failed CPUv2 evidence using its known venv/system-site provenance.

Only stdlib top-level find_spec/metadata discovery is used. No Torch, Transformers
or TorchNPU module is executed; no device/model/array operation is performed.
Export success records failure evidence and never creates a CPU prerequisite.
"""
import argparse
import base64
import hashlib
import importlib.metadata
import importlib.util
import json
from pathlib import Path,PurePosixPath
import re
import signal
import sys
import tarfile

CASE='projects/gemma4-pilot/cases/text-native'
MANIFEST_SHA='5a5c72b5d47066c32b665a7b53f21216c812fddad70fb6f4c024be03cdcac6fa'
OPS_SHA='bffba407af697b0891e11d0309612d43b5b507b6297e095726c22c795e2a8c2a'
MAX_FILE,MAX_TOTAL,MAX_GZIP,MAX_ENVELOPE=4*1024**2,16*1024**2,8*1024**2,16*1024**2
SOURCE_PLAN={'transformers':['__init__.py','utils/__init__.py','utils/import_utils.py','masking_utils.py','models/gemma4_unified/configuration_gemma4_unified.py'],
             'torch_npu':['__init__.py','npu/__init__.py','utils/collect_env.py'],'torch':['__init__.py','cuda/__init__.py'],'numpy':['__init__.py']}
BASE_PREFIX=Path('/usr/local/python3.12.13')
ORIGIN_EVIDENCE_SHA='9132572e669ff47a3788be51f5a2abfb55bd6079a1237dddf968e6e117e8fe67'
PACKAGE_IDENTITIES={
    'transformers':{'environment':'venv','sha256':'18ef948db06a19dcc22616ef892fd18a51855892534e11e2babe30bcd978be6e','version':'5.10.1'},
    'torch':{'environment':'base','sha256':'3caf7f40140ede2465bde40b9003af10cbbc8f7bcf436fa1de026471daa1b288','version':'2.9.0+cpu'},
    'torch_npu':{'environment':'base','sha256':'27f372506192fe194032728d1d4b296202937ecc71de2d65215d33a64640371d','version':'2.9.0.post2'},
    'numpy':{'environment':'base','sha256':'22cd1535fa14d74ef6f457cca149ffdc80875f460be313b8f895273f78bc402e','version':'1.26.4'}}
HEX=re.compile(r'^[a-f0-9]{64}$')


def require(ok,message):
    if not ok:raise ValueError(message)


def framework_modules():return sorted(name for name in sys.modules if any(name==prefix or name.startswith(prefix+'.') for prefix in ('torch','torch_npu','transformers','numpy')))


def regular(path):
    path=Path(path);text=str(path)
    require(path.is_absolute() and '\\' not in text and '..' not in PurePosixPath(text).parts,'original absolute POSIX metadata path required')
    require(path.suffix not in ('.npy','.safetensors','.pt','.pth','.bin','.so','.tar','.gz','.whl'),'native arrays/binaries/archives are excluded before stat/open')
    require(path.is_file() and not path.is_symlink() and path.stat().st_size<=MAX_FILE,'bounded original regular metadata/source required');return path


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    def pairs(items):
        doc={}
        for key,value in items:require(key not in doc,'duplicate JSON key');doc[key]=value
        return doc
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(regular(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)


def put(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


class Catalog:
    def __init__(self,output):self.output=output;self.files={};self.total=0
    def add(self,path,expected=None,role='failed_CPU_metadata'):
        path=regular(path);key=str(path);digest=sha(path);require(expected is None or digest==expected,'original source hash differs: '+key)
        if key in self.files:require(self.files[key]['sha256']==digest,'same original path changed');return
        raw=path.read_bytes();require(hashlib.sha256(raw).hexdigest()==digest,'metadata changed before copy')
        self.total+=len(raw);require(self.total<=MAX_TOTAL,'diagnostic source bytes exceed16MiB')
        relative='payload/%04d/%s'%(len(self.files),path.name);target=self.output/relative;target.parent.mkdir(parents=True)
        with target.open('xb') as stream:stream.write(raw)
        self.files[key]={'path':relative,'sha256':digest,'size':len(raw),'role':role}
    def recheck(self):
        for source,ref in self.files.items():require(sha(source)==sha(self.output/ref['path'])==ref['sha256'],'diagnostic original/copy changed')


def stdlib_paths(base,paths):return [entry for entry in paths if entry and Path(entry).resolve().is_relative_to(base)]


def installed_sources(root,catalog):
    require(not framework_modules(),'diagnostic process already imported a framework')
    # -S avoids startup hooks. Read pyvenv.cfg as data; never process .pth files.
    # The base roots/hashes are copied from actual retained NPU I03 source-map
    # evidence. Missing venv packages cannot silently fall back to another stack.
    require(sys.version_info[:2]==(3,12) and Path(sys.base_prefix).resolve()==BASE_PREFIX,'known actual Python base prefix differs')
    cfg=regular(root/'venv/pyvenv.cfg');catalog.add(cfg,role='actual_pyvenv_system_site_provenance');fields={}
    for line in cfg.read_text(encoding='utf-8').splitlines():
        if not line.strip() or line.lstrip().startswith('#'):continue
        require('=' in line,'invalid original pyvenv.cfg line');key,value=(part.strip() for part in line.split('=',1));key=key.casefold()
        require(key not in fields,'duplicate pyvenv.cfg key');fields[key]=value
    require(fields.get('include-system-site-packages','').casefold()=='true' and fields.get('version')=='3.12.13' and
        fields.get('home')==str(BASE_PREFIX/'bin'),'actual pyvenv.cfg must authorize the known system-site stack')
    sites={'venv':root/'venv/lib/python3.12/site-packages','base':BASE_PREFIX/'lib/python3.12/site-packages'}
    require(all(path.is_dir() and not path.is_symlink() for path in sites.values()),'known venv/base package directories missing')
    original_path=list(sys.path);sys.path[:]=[str(sites['venv']),str(sites['base'])]+stdlib_paths(BASE_PREFIX,original_path);observed={}
    try:
        for name,files in SOURCE_PLAN.items():
            require('.' not in name,'find_spec is restricted to top-level package names')
            spec=importlib.util.find_spec(name);require(spec is not None and spec.origin and spec.submodule_search_locations,'installed package source unavailable: '+name)
            identity=PACKAGE_IDENTITIES[name];allowed=sites[identity['environment']].resolve(strict=True)
            origin=Path(spec.origin).resolve(strict=True);require(origin==allowed/name/'__init__.py' and sha(regular(origin))==identity['sha256'],
                'actual package origin/class/source SHA differs from retained NPU evidence')
            package=origin.parent;refs={}
            for relative in files:
                path=(package/relative).resolve(strict=True);require(path.is_relative_to(package) and path.suffix=='.py','installed source path escapes package')
                catalog.add(path,role='installed_'+name+'_source_not_executed');refs[relative]={'path':str(path),'sha256':sha(path),'size_bytes':path.stat().st_size}
            try:version=importlib.metadata.version(name)
            except importlib.metadata.PackageNotFoundError:version=None
            require(version==identity['version'],'actual distribution version differs from retained NPU stack')
            observed[name]={'top_level_spec_origin':str(origin),'origin_environment':identity['environment'],
                'version_from_distribution_metadata':version,'prior_runtime_source_sha256':identity['sha256'],'source_files':refs}
        require(not framework_modules(),'top-level source discovery executed a framework')
    finally:sys.path[:]=original_path
    return {'lookup_method':'stdlib importlib.util.find_spec(top-level) and importlib.metadata.version; no package execution',
        'explicit_site_packages':{key:str(value) for key,value in sites.items()},'pyvenv_cfg':{'path':str(cfg),'sha256':sha(cfg),'fields':fields},
        'python_base_prefix':str(BASE_PREFIX),'prior_NPU_source_map_sha256':ORIGIN_EVIDENCE_SHA,'packages':observed,'framework_modules_imported_during_export':[],
        'device_queries_executed':0,'native_model_forward_calls':0,'dynamic_import_flags_measured':False,
        'torch_npu_registered_after_config_import':None,'torch_npu_initialized_after_config_import':None,
        'scope':'Source snapshot only. Prior manual import observations require their own original logs.'}


def export(root,controller_sha,output):
    require(not framework_modules(),'CPU diagnostic imported a framework')
    root=Path(root);require(root.is_dir() and not root.is_symlink(),'explicit original R root required');root=root.resolve(strict=True)
    target=root/'i04-batch-padding-20261107/cpu-stage-v2';stdout=target/'cpu-validation-v2.stdout'
    selected=read(stdout);controller=regular(selected['controller_path']);state=read(controller)
    require(controller.parent.parent==target/'runs' and re.fullmatch(r'compare-i04-cpu-tests-\d{8}T\d{6}Z',controller.parent.name),'original CPUv2 controller namespace differs')
    require(HEX.fullmatch(controller_sha) and sha(controller)==controller_sha and {k:v for k,v in selected.items() if k!='controller_path'}==state,'actual failed stdout/controller machine binding differs')
    require(state['task']=='I04-CPU-validation' and state['status']=='failed' and type(state['returncode']) is int and state['returncode']==2 and
        state['native_executions_started']==state['model_loads']==0 and state['native_claim_created'] is False and len(state['steps'])==2 and
        state['manifest_sha256']==MANIFEST_SHA and state['source']==str(target/'source'),'exact original failed CPUv2 evidence required')
    require('fresh-process capture CPU tests must pass with no skips' in state.get('error',''),'different CPU failure needs a separate diagnostic scope')
    output=Path(output);require(not output.exists() and not output.is_symlink() and output.parent.is_dir() and
        output.resolve().is_relative_to(root/'exports') and not (root/'exports').is_symlink(),'exclusive new R/exports diagnostic directory required')
    output.mkdir(mode=0o700);catalog=Catalog(output)
    for path in (stdout,target/'cpu-validation-v2.stderr',target/'cpu-validation-v2-start.json',target/'stage-receipt.json',
                 target/'source-manifest.json',controller,controller.parent/'start-receipt.json'):
        catalog.add(path,MANIFEST_SHA if path.name=='source-manifest.json' else None)
    catalog.add(root/'i04_cpu_stage_operations_v2.py',OPS_SHA,'original_failed_CPU_operations_source')
    manifest=read(target/'source-manifest.json')
    for name in ('adapters/test_i04_expected_inventory_v1.py','adapters/test_i04_capture_v1.py','transfer/i04_cpu_mask_probe_v1.py'):
        relative=CASE+'/'+name;catalog.add(target/'source'/relative,manifest['files'][relative]['sha256'],'original_failed_CPU_test_or_unexecuted_probe_source')
    for step in state['steps']:
        require(step['cleanup']['remaining_owned_process_group'] is False,'original failed CPU group cleanup is incomplete')
        for stream in ('stdout','stderr'):
            ref=step[stream];path=regular(ref['path']);require(path.parent==controller.parent and path.stat().st_size==ref['bytes'],'original failed step log path/size differs')
            catalog.add(path,ref['sha256'],'original_failed_CPU_step_'+stream)
    reference=target/'cpu-stage-source-reference.json';ref=read(reference);catalog.add(reference)
    path=regular(ref['path']);require(path.resolve(strict=True).is_relative_to(root/'runs'),'original static stage controller escapes R');catalog.add(path,ref['sha256'],'original_static_stage_controller')
    catalog.add(Path(__file__).resolve(),role='diagnostic_exporter_source')
    inspection=installed_sources(root,catalog);put(output/'installed-source-inspection.json',inspection)
    metadata={'schema_version':1,'kind':'i04_failed_cpu_import_diagnostic_v2','cpu_validation_status':'failed','cpu_validation_returncode':2,
        'cpu_validation_succeeded':False,'cpu_prerequisite_produced':False,'original_controller':{'path':str(controller),'sha256':controller_sha},
        'files':catalog.files,'generated_files':{'installed-source-inspection.json':{'sha256':sha(output/'installed-source-inspection.json'),'size':(output/'installed-source-inspection.json').stat().st_size}},
        'native_arrays_opened':0,'framework_modules_imported_by_exporter':[],'native_executions_started':0,'model_loads':0,'acceptance':None}
    put(output/'metadata-source-map.json',metadata);catalog.recheck()
    require(sum(path.stat().st_size for path in output.rglob('*') if path.is_file())<=MAX_TOTAL,'complete diagnostic metadata exceeds16MiB')
    archive=output.with_name(output.name+'.tar.gz')
    with archive.open('xb') as stream,tarfile.open(fileobj=stream,mode='w:gz') as package:
        for path in sorted(output.rglob('*')):
            require(not path.is_symlink(),'diagnostic package contains symlink')
            if path.is_file():package.add(path,arcname=path.relative_to(output).as_posix(),recursive=False)
    require(archive.stat().st_size<=MAX_GZIP,'diagnostic gzip exceeds8MiB');archive_ref={'basename':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)}
    envelope=output.with_name(output.name+'-json-base64.txt')
    put(envelope,{'schema_version':1,'kind':'i04-failed-cpu-diagnostic-transport-v2','archive':{**archive_ref,'base64':base64.b64encode(archive.read_bytes()).decode('ascii')}})
    require(envelope.stat().st_size<=MAX_ENVELOPE,'diagnostic envelope exceeds16MiB');catalog.recheck();require(not framework_modules(),'diagnostic imported a framework')
    result={'schema_version':1,'status':'i04_failed_cpu_diagnostic_metadata_exported_v2','cpu_validation_status':'failed','cpu_validation_returncode':2,
        'cpu_validation_succeeded':False,'cpu_prerequisite_produced':False,'controller_sha256':controller_sha,'metadata_source_map_sha256':sha(output/'metadata-source-map.json'),
        'copied_metadata_source_files':len(catalog.files),'metadata_source_bytes':catalog.total,'installed_package_sources':list(inspection['packages']),
        'archive':archive_ref,'json_base64_path':str(envelope),'json_base64_bytes':envelope.stat().st_size,'json_base64_sha256':sha(envelope),
        'native_arrays_opened':0,'framework_modules_imported_by_exporter':[],'device_queries_executed':0,'native_executions_started':0,'model_loads':0,'acceptance':None}
    put(output.with_name(output.name+'-diagnostic-receipt.json'),result);return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('root','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--controller-sha256',required=True);args=parser.parse_args()
    def expire(*_):raise TimeoutError('failed CPU diagnostic export30s deadline')
    signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,30)
    try:print(json.dumps(export(args.root,args.controller_sha256,args.output),indent=2),flush=True)
    except BaseException as exc:
        path=args.output.with_name(args.output.name+'-diagnostic-failure.json')
        if path.parent.is_dir() and not path.exists():put(path,{'status':'diagnostic_export_failed','error_type':type(exc).__name__,'error':str(exc),'cpu_prerequisite_produced':False,'partial_files_preserved':True,'native_executions_started':0})
        raise
    finally:signal.setitimer(signal.ITIMER_REAL,0)

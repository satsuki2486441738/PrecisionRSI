"""Case-owned I01 full-sequence capture and offline evidence validation.

No model/framework is imported by this module. Native callers inject Torch and
an already verified BF16/eager model. One call retains lossless native logits;
shared NumPy FP64 derivation is performed on individual CPU rows afterwards.
Outer launchers own permanent claims, process conflict checks and whole budgets.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import inspect
import json
import math
import os
from pathlib import Path
import shutil
import signal
import struct
import sys
import time

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]
SCRIPTS = REPO / 'skills/precision-compare/scripts'
sys.path.insert(0, str(SCRIPTS))
from artifact_io import Array, parse_json
from inference_capture import derive_logprobs
import numpy as np

VOCABULARY = 262144
INPUT_SHA256 = '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
STAGE_SHA256 = '5aa7d50bb472aab82108ad6711fdd6c5bdd4780bbecb27cdf78c734d13093c05'
STAGE_ID = 'gemma4-gpu-npu-i01-cacheoff-v1-20261106'
EXPECTED_SHA256 = '416b4f7384c5676c7b1fc9c6d41a7e5c53e654d95554ceebe71dceb94049d5ee'
TASK = 'gemma4-i01-cache-off-anchor-v1'
NORMALIZATION = 'Offline NumPy float64 log_softmax of copied native values'
REVISION = '1a2c7729392586f5ecddae8807ee2ef741eabb9a'
ORIGINAL_NPU_UUID = 'REDACTED_DEVICE_UUID'
MAX_STORAGE = 1024 ** 3
PINNED = {
 'projects/gemma4-pilot/cases/text-native/adapters/pilot_gpu_torch290_candidate.py': '5a73efe31962788baa04fa21abb1079be8a47e43393c23f3fa483e71c64b4f53',
 'projects/gemma4-pilot/cases/text-native/adapters/pilot_ascend_candidate_v3.py': '95b7b9302543d8a14995e293c790d5de9e23abc6041a53bb1d627ae3b5cd7ee8',
 'projects/gemma4-pilot/cases/text-native/adapters/pilot_gpu_peer_v2.py': 'fbf0b1dc4b03576852d166bc56d3bca14d6544be8aebd120ef0b92f146429eae',
 'projects/gemma4-pilot/cases/text-native/adapters/verify_snapshot.py': 'cd64a5f3f380d9cc04578848ba508ace3f1df0752ca952b8d575dd2904196f26',
 'projects/gemma4-pilot/cases/text-native/adapters/upstream-identity.json': '80dc0e0e59e5c526426b566d36a21f762a79d498986d5d6cd01098c8cb5decc3',
 'projects/gemma4-pilot/cases/text-native/transfer/npu_three_repeat_launcher_v4.py': 'c1719e831a557cd9707374138d9219a8ae887854dd029a1ec165631d9259f485',
 'skills/precision-compare/scripts/inference_capture.py': '5d388e846249d7fd74df1b15036f8a371e3267ada1b2fb0408bc51345ffad19c',
 'skills/precision-compare/scripts/artifact_io.py': '0260cd5ee1fd4e9d37e39bfd79efa9e663a1d48cb75b5adb31b84af9e1edbf39',
 'skills/precision-compare/scripts/conditions.py': 'e012c025395f2f0474f0b35074d8417ec5a217f3659f82218de0f5d05068036d',
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 ** 2), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return parse_json(Path(path).read_bytes())


def put(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def file_ref(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'regular non-symlink source required: ' + str(path))
    return {'path': str(path.resolve()), 'sha256': sha(path), 'size_bytes': path.stat().st_size}


def check_refs(refs):
    for ref in refs.values():
        require(file_ref(ref['path']) == ref, 'frozen dependency changed: ' + ref['path'])


def check_import_paths():
    names = {'artifact_io': SCRIPTS / 'artifact_io.py', 'inference_capture': SCRIPTS / 'inference_capture.py',
             'conditions': SCRIPTS / 'conditions.py',
             'npu_three_repeat_launcher_v4': HERE.parent / 'transfer/npu_three_repeat_launcher_v4.py'}
    for name in ('pilot_gpu_torch290_candidate', 'pilot_ascend_candidate_v3', 'pilot_gpu_peer_v2', 'verify_snapshot'):
        names[name] = HERE / (name + '.py')
    for name, expected in names.items():
        if name in sys.modules:
            require(Path(sys.modules[name].__file__).resolve() == expected.resolve(), 'imported helper path differs: ' + name)


def source_refs(entry):
    check_import_paths()
    refs = {}
    for name, expected in PINNED.items():
        ref = file_ref(REPO / name)
        require(ref['sha256'] == expected, 'reviewed dependency hash differs: ' + name)
        refs[name] = ref
    for name in ('i01_common_v1.py', Path(entry).name):
        refs['i01/' + name] = file_ref(HERE / name)
    for name, module_path in [('artifact_io', SCRIPTS / 'artifact_io.py'),
                              ('inference_capture', SCRIPTS / 'inference_capture.py'),
                              ('conditions', SCRIPTS / 'conditions.py')]:
        require(Path(sys.modules[name].__file__).resolve() == module_path.resolve(), 'imported shared module path differs')
    return refs


def input_inventory(document):
    require(isinstance(document.get('sample'), str) and document['sample'].strip(), 'sample required')
    prompt, continuation = document.get('prompt'), document.get('continuation')
    require(isinstance(prompt, list) and len(prompt) == 128 and isinstance(continuation, list) and len(continuation) == 32,
            'exact original 128+32 token workload required')
    sequence = prompt + continuation
    require(all(type(token) is int and 0 <= token < VOCABULARY for token in sequence), 'invalid input token')
    grid = [i * 127 // 15 for i in range(16)]
    positions = sorted(set(grid + list(range(127, 159))))
    return {'sample': document['sample'], 'sequence': sequence,
            'all_targets': [{'sample': document['sample'], 'position': p, 'token': sequence[p]} for p in range(1, 160)],
            'distribution_positions': [{'sample': document['sample'], 'position': p, 'history': sequence[:p+1]} for p in positions],
            'prompt_positions': grid, 'positions': positions}


def check_expected(expected, inventory):
    require(expected.get('schema_version') == 1 and expected.get('task') == TASK and
            expected.get('stage_id') == STAGE_ID and expected.get('stage_spec_sha256') == STAGE_SHA256 and
            expected.get('input_sha256') == INPUT_SHA256, 'external expected inventory identity differs')
    require(expected.get('all_targets') == inventory['all_targets'] and
            expected.get('distribution_positions') == inventory['distribution_positions'] and
            expected.get('cached_overlap_targets') == inventory['all_targets'][127:], 'independently derived coordinates differ')
    require(expected.get('raw_logits') == {'tensor_name': 'logits', 'dtype': 'BF16', 'shape': [1, 160, VOCABULARY],
            'data_bytes': 320 * VOCABULARY, 'unscored_prediction_indices': [159]}, 'external raw-logit inventory differs')


def arguments(backend):
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('model', 'input', 'allocation-receipt', 'stage-spec', 'expected-inventory', 'output'):
        parser.add_argument('--' + key, type=Path, required=True)
    for key in ('stage-spec-sha256', 'expected-inventory-sha256'):
        parser.add_argument('--' + key, required=True)
    parser.add_argument('--device', required=True, choices=['cuda:0'] if backend == 'gpu' else ['npu:0'])
    if backend == 'gpu':
        parser.add_argument('--numerics-policy', type=Path, required=True)
    else:
        for key in ('driver-source', 'native-mapping', 'native-source'):
            parser.add_argument('--' + key, type=Path, required=True)
    return parser.parse_args()


def prepare(args, backend, entry):
    require(args.stage_spec_sha256 == STAGE_SHA256 and sha(args.stage_spec) == STAGE_SHA256, 'frozen finite stage SHA differs')
    stage = read(args.stage_spec)
    require(stage.get('stage_id') == STAGE_ID and stage.get('status') == 'prepared_not_executed' and
            stage.get('acceptance') is None and stage.get('thresholds') is None, 'invalid prepared stage source')
    require(sha(args.input) == INPUT_SHA256, 'original input bytes required')
    document = read(args.input)
    inventory = input_inventory(document)
    require(args.expected_inventory_sha256 == EXPECTED_SHA256 and sha(args.expected_inventory) == EXPECTED_SHA256,
            'original independently frozen expected inventory SHA differs')
    check_expected(read(args.expected_inventory), inventory)
    limits = stage['limits']
    require(limits['max_native_launches_per_backend'] == 1 and limits['automatic_native_retries'] == 0 and
            limits['maximum_new_capture_and_export_storage_bytes_per_backend'] == MAX_STORAGE and
            limits['minimum_free_source_storage_bytes'] == 2 * 1024 ** 3 and
            stage['selected_prediction_positions'] == inventory['positions'] and
            stage['semantics']['expected_logits_shape'] == [1, 160, VOCABULARY], 'stage bounds or semantics differ')
    require(args.output.parent.is_dir() and not args.output.exists(), 'new output under an existing run directory required')
    require(shutil.disk_usage(args.output.parent).free >= limits['minimum_free_source_storage_bytes'], 'source filesystem has less than 2GiB free')
    refs = source_refs(entry)
    for key in ('input', 'allocation_receipt', 'stage_spec', 'expected_inventory',
                'numerics_policy' if backend == 'gpu' else 'driver_source'):
        refs['input/' + key] = file_ref(getattr(args, key))
    if backend == 'npu':
        for key in ('native_mapping', 'native_source'):
            refs['input/' + key] = file_ref(getattr(args, key))
    return stage, inventory, refs


@contextmanager
def bounded_native(stage, backend):
    """Linux in-process bound; outer recorder also kills/reaps owned descendants."""
    require(hasattr(signal, 'SIGALRM'), 'native entry requires POSIX bounded execution')
    seconds = stage['limits'][backend + '_capture_timeout_seconds']
    require(seconds == (900 if backend == 'gpu' else 1200), 'native timeout differs from finite stage')
    def expire(signum, frame):
        raise TimeoutError('I01 native entry exceeded ' + str(seconds) + ' seconds')
    previous = signal.signal(signal.SIGALRM, expire)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous)


def load_verified_model(args, torch, loader, metadata):
    from verify_snapshot import verify
    receipt = verify(args.model, metadata)
    receipt['upstream_metadata_sha256'] = PINNED['projects/gemma4-pilot/cases/text-native/adapters/upstream-identity.json']
    put(args.output / 'snapshot-verification.json', receipt)
    require(receipt['status'] == 'verified', 'complete local eight-file snapshot verification failed')
    model = loader.from_pretrained(str(args.model), revision=REVISION, local_files_only=True,
                                   dtype=torch.bfloat16, attn_implementation='eager')
    require(type(model).__name__ == 'Gemma4UnifiedForConditionalGeneration' and
            getattr(model.config, 'model_type', None) == 'gemma4_unified', 'actual model class/type differs')
    commit = getattr(model.config, '_commit_hash', None)
    require(not commit or commit.lower() == REVISION, 'loaded model commit differs')
    model = model.to(args.device).eval()
    require(sorted({str(p.dtype) for p in model.parameters()}) == ['torch.bfloat16'] and
            getattr(model.config, '_attn_implementation', None) == 'eager', 'actual model dtype/attention differs')
    signature = inspect.signature(model.forward)
    require('logits_to_keep' in signature.parameters and signature.parameters['logits_to_keep'].default == 0,
            'actual Gemma4 forward all-position default differs')
    source = inspect.getsourcefile(type(model))
    require(source is not None, 'modeling implementation source unavailable')
    put(args.output / 'loaded-model-inventory.json', loaded_model_inventory(model))
    return model, {'model_class': type(model).__name__, 'model_type': model.config.model_type,
        'observed_config_commit': commit, 'parameter_dtypes': ['torch.bfloat16'], 'actual_attention': 'eager',
        'forward_signature': str(signature), 'modeling_source': file_ref(source),
        'snapshot_receipt_sha256': sha(args.output / 'snapshot-verification.json')}


def loaded_model_inventory(model):
    """Observe metadata only; listing a module does not establish execution coverage."""
    modules = [{'name': name, 'class': type(module).__module__ + '.' + type(module).__qualname__}
               for name, module in model.named_modules(remove_duplicate=False)]
    parameters, by_object, by_storage, gaps = [], {}, {}, []
    for name, parameter in model.named_parameters(remove_duplicate=False):
        record = {'name': name, 'shape': list(parameter.shape), 'dtype': str(parameter.dtype),
                  'device': str(parameter.device), 'numel': int(parameter.numel())}
        by_object.setdefault(id(parameter), []).append(name)
        try:
            storage = parameter.untyped_storage()
            pointer, nbytes = int(storage.data_ptr()), int(storage.nbytes())
            if pointer <= 0:
                raise ValueError('storage address is unavailable')
            # Addresses are transient private observations, never public identity.
            identity = (str(parameter.device), pointer, nbytes)
            by_storage.setdefault(identity, []).append(name)
            record['storage'] = {'data_ptr': pointer, 'nbytes': nbytes,
                'storage_offset': int(parameter.storage_offset()), 'stride': list(parameter.stride())}
        except Exception as exc:
            record['storage'] = None
            gaps.append({'parameter': name, 'operation': 'untyped_storage metadata',
                         'error_type': type(exc).__name__, 'error': str(exc)})
        parameters.append(record)
    config = model.config.to_dict()
    return {'schema_version': 1, 'kind': 'loaded-model-metadata-inventory',
        'model_class': type(model).__module__ + '.' + type(model).__qualname__,
        'modules': modules, 'parameters': parameters,
        'parameter_object_alias_groups': [names for names in by_object.values() if len(names) > 1],
        'observable_shared_storage_groups': [names for names in by_storage.values() if len(names) > 1],
        'config': config, 'tied_weight_declarations': {
            name: getattr(model, name, None) for name in ('_tied_weights_keys', '_dynamic_tied_weights_keys')},
        'storage_observation_gaps': gaps,
        'scope': 'Loaded model CPU metadata only; no parameter copies or mutations, no extra forward; module listing is not execution coverage'}


def _save_raw(logits, path):
    from safetensors.torch import save_file
    save_file({'logits': logits}, str(path), metadata={'task': TASK, 'boundary': 'native model output before score processing'})


def capture(model, torch, device, inventory, output, save_raw=None):
    """Exactly one full call; no generate, token substitution or cache reuse."""
    output = Path(output)
    sequence = inventory['sequence']
    started = time.monotonic()
    kwargs = dict(input_ids=torch.tensor([sequence], dtype=torch.long, device=device),
        attention_mask=torch.ones((1, 160), dtype=torch.long, device=device),
        position_ids=torch.tensor([list(range(160))], dtype=torch.long, device=device),
        past_key_values=None, use_cache=False, logits_to_keep=0, return_dict=True)
    with torch.inference_mode():
        result = model(**kwargs)
        require(getattr(result, 'past_key_values', object()) is None, 'cache-off native call returned a cache')
        logits = result.logits
        require(list(logits.shape) == [1, 160, VOCABULARY], 'native logits were sliced or have incorrect shape')
        require(str(logits.dtype) == 'torch.bfloat16', 'native logits must be original BF16, never converted before retention')
        native_cpu = logits.detach().cpu().contiguous()
    raw_path = output / 'raw-native-logits.safetensors'
    require(not raw_path.exists(), 'raw-logit output already exists')
    (save_raw or _save_raw)(native_cpu, raw_path)
    raw_ref = file_ref(raw_path)
    check_raw_header(raw_path)
    require(np.isfinite(native_cpu[0, 159, :].double().numpy()).all(), 'unscored raw row 159 is nonfinite')
    inventory_sha = sha(output / 'expected-inventory.json')
    base = {'schema_version': 1, 'input_sha256': INPUT_SHA256, 'inventory_sha256': inventory_sha,
            'raw_logits_sha256': raw_ref['sha256'], 'native_logits_dtype': 'torch.bfloat16',
            'logprob_dtype': 'float64', 'normalization': NORMALIZATION}
    targets, distributions = [], []
    for p in range(159):
        row = derive_logprobs(native_cpu[0, p, :].double().numpy(), dtype='float64')
        require(np.isfinite(row).all(), 'nonfinite derived target distribution')
        target = sequence[p + 1]
        score = float(row[target])
        targets.append({'sample': inventory['sample'], 'position': p+1, 'prediction_position': p,
                        'token': target, 'logprob': score})
        if p in inventory['positions']:
            prefix = 'dist-p%03d' % p
            descriptor = {'path': prefix + '.npy', 'row': 0}
            with (output / descriptor['path']).open('xb') as stream:
                np.save(stream, row.reshape(1, VOCABULARY), allow_pickle=False)
            roles = (['prompt_sample'] if p in inventory['prompt_positions'] else []) + (['continuation'] if p >= 127 else [])
            record = dict(base, sample=inventory['sample'], position=p, history=sequence[:p+1], roles=roles,
                          target_position=p+1, token=target, logprob=score, scores=descriptor)
            put(output / (prefix + '.json'), record)
            distributions.append({key: record[key] for key in ('sample', 'position', 'history', 'roles', 'scores')})
            distributions[-1]['record'] = prefix + '.json'
        check_storage(output)
    put(output / 'target-scores.json', dict(base, kind='i01-native-target-scores', scores=targets))
    put(output / 'distributions.json', dict(base, kind='i01-native-distribution-rows', positions=distributions))
    event = {'stage': 'full_forward', 'input_ids': sequence, 'positions': list(range(160)),
             'attention_mask': [[1] * 160], 'past_key_values': None, 'use_cache': False,
             'logits_to_keep': 0, 'return_dict': True, 'returned_cache': None,
             'native_logits_shape': list(logits.shape), 'native_logits_dtype': str(logits.dtype)}
    put(output / 'events.json', [event])
    summary = {'native_forward_calls': 1, 'native_logits_shape': list(logits.shape),
        'native_logits_dtype': str(logits.dtype), 'use_cache': False, 'returned_cache': None,
        'logits_to_keep': 0, 'targets': 159, 'sampled_distributions': 47,
        'unscored_native_prediction_indices': [159], 'raw_logits': raw_ref,
        'capture_and_derivation_seconds': time.monotonic() - started}
    put(output / 'capture-summary.json', summary)
    return summary


def check_raw_header(path):
    path = Path(path)
    with path.open('rb') as stream:
        length_raw = stream.read(8)
        require(len(length_raw) == 8, 'truncated safetensors length')
        length = struct.unpack('<Q', length_raw)[0]
        require(0 < length <= 65536, 'unbounded safetensors header')
        header = parse_json(stream.read(length))
    require(set(header) in ({'logits'}, {'logits', '__metadata__'}), 'exactly one raw tensor required')
    require(header['logits'] == {'dtype': 'BF16', 'shape': [1, 160, VOCABULARY], 'data_offsets': [0, 320 * VOCABULARY]},
            'raw tensor shape/dtype/offsets differ')
    require(path.stat().st_size == 8 + length + 320 * VOCABULARY, 'raw safetensors payload size differs')
    return header


def check_storage(output):
    files = list(Path(output).iterdir())
    require(all(p.is_file() and not p.is_symlink() for p in files), 'unexpected directory/link in capture output')
    size = sum(p.stat().st_size for p in files)
    require(size <= MAX_STORAGE, 'new capture output exceeded 1GiB storage bound')
    return size


def finalize(args, backend, inventory, refs, runtime):
    check_import_paths()
    check_refs(refs)
    check_refs({'modeling_source': runtime['model_identity']['modeling_source']})
    runtime.update(task=TASK, stage_id=STAGE_ID, stage_spec_sha256=STAGE_SHA256,
        input_sha256=INPUT_SHA256, expected_inventory_external_path=str(args.expected_inventory.resolve()),
        expected_inventory_sha256=sha(args.expected_inventory), sources=refs,
        model_repository='google/gemma-4-12B', requested_revision=REVISION,
        native_logits_dtype='torch.bfloat16', logprob_dtype='float64', normalization=NORMALIZATION,
        execution='one full native forward; use_cache=False; past_key_values=None; logits_to_keep=0',
        thresholds=None, acceptance=None, full_core_complete=False,
        limitations=['one input and one new process per backend; no new repeatability measurement',
            'supplied allocation is not independently authenticated',
            'snapshot verification does not attest loader-consumed bytes',
            'reuse of prior cached scores is not necessarily a cache-only physical-device intervention'])
    put(args.output / 'runtime.json', runtime)
    manifest = {'schema_version': 1, 'kind': 'i01-capture-artifacts', 'task': TASK,
        'backend': backend, 'stage_spec_sha256': STAGE_SHA256, 'expected_inventory_sha256': sha(args.expected_inventory),
        'input_sha256': INPUT_SHA256, 'files': {p.name: {'sha256': sha(p), 'size_bytes': p.stat().st_size}
            for p in sorted(args.output.iterdir())}, 'acceptance': None}
    put(args.output / 'artifacts-manifest.json', manifest)
    validate_output(args.output, args.input, require_completed=False)
    check_refs(refs)
    put(args.output / 'status.json', {'schema_version': 1, 'status': 'completed', 'rank': 0,
        'task': TASK, 'backend': backend, 'stage_spec_sha256': STAGE_SHA256,
        'artifacts_manifest_sha256': sha(args.output / 'artifacts-manifest.json'),
        'targets': 159, 'distribution_positions': 47, 'acceptance': None, 'full_core_complete': False})
    return validate_output(args.output, args.input)


def validate_output(output, input_path, require_completed=True):
    """Offline hash/coordinate/schema checks; never import Torch or execute a model.

    Independent admission separately decodes retained BF16 and recomputes the
    values. This validator checks output closure and shared array descriptors.
    """
    output = Path(output)
    require(sha(input_path) == INPUT_SHA256, 'validation input SHA differs')
    inventory = input_inventory(read(input_path))
    manifest = read(output / 'artifacts-manifest.json')
    require(manifest.get('task') == TASK and manifest.get('stage_spec_sha256') == STAGE_SHA256 and
            manifest.get('input_sha256') == INPUT_SHA256, 'artifact manifest identity differs')
    files = manifest['files']
    required_files = {'expected-inventory.json', 'raw-native-logits.safetensors', 'target-scores.json',
        'distributions.json', 'events.json', 'capture-summary.json', 'loaded-model-inventory.json',
        'snapshot-verification.json', 'runtime.json', 'policy-before-load.json', 'policy-after-load.json',
        'policy-after-capture.json'}
    required_files.update('dist-p%03d%s' % (p, suffix) for p in inventory['positions'] for suffix in ('.json', '.npy'))
    require(manifest.get('backend') in ('gpu', 'npu'), 'artifact backend missing')
    if manifest['backend'] == 'npu':
        required_files.add('driver-version-provenance.json')
    require(set(files) == required_files, 'artifact manifest omits required evidence or contains unexpected products')
    actual = {p.name for p in output.iterdir()}
    require(actual == set(files) | {'artifacts-manifest.json'} | ({'status.json'} if require_completed else set()), 'output inventory is not exact')
    for name, ref in files.items():
        require(Path(name).name == name and name not in ('.', '..'), 'unsafe manifest member')
        path = output / name
        require(path.is_file() and not path.is_symlink() and ref == {'sha256': sha(path), 'size_bytes': path.stat().st_size}, 'artifact bytes changed: ' + name)
    expected = read(output / 'expected-inventory.json')
    check_expected(expected, inventory)
    require(sha(output / 'expected-inventory.json') == manifest['expected_inventory_sha256'], 'expected inventory copy differs')
    check_raw_header(output / 'raw-native-logits.safetensors')
    raw_sha = sha(output / 'raw-native-logits.safetensors')
    targets, distributions = read(output / 'target-scores.json'), read(output / 'distributions.json')
    for document, kind in ((targets, 'i01-native-target-scores'), (distributions, 'i01-native-distribution-rows')):
        require(document.get('kind') == kind and document.get('raw_logits_sha256') == raw_sha and
                document.get('inventory_sha256') == manifest['expected_inventory_sha256'] and
                document.get('input_sha256') == INPUT_SHA256 and document.get('native_logits_dtype') == 'torch.bfloat16' and
                document.get('normalization') == NORMALIZATION and document.get('logprob_dtype') == 'float64', 'derived artifact provenance differs')
    rows = targets['scores']
    require(len(rows) == 159, 'exactly 159 target scores required')
    for actual_row, coordinate in zip(rows, inventory['all_targets']):
        require(all(actual_row.get(k) == v for k, v in coordinate.items()) and
                actual_row.get('prediction_position') == coordinate['position'] - 1 and
                type(actual_row.get('logprob')) in (int, float) and math.isfinite(actual_row['logprob']) and actual_row['logprob'] <= 0,
                'target score coordinate/value differs')
    positions = distributions['positions']
    require(len(positions) == 47, 'exactly 47 distribution rows required')
    for item, coordinate in zip(positions, inventory['distribution_positions']):
        p = coordinate['position']
        prefix = 'dist-p%03d' % p
        require(all(item.get(k) == v for k, v in coordinate.items()) and item['record'] == prefix + '.json' and
                item['scores'] == {'path': prefix + '.npy', 'row': 0}, 'distribution coordinate/path differs')
        record = read(output / item['record'])
        require(all(record.get(k) == item[k] for k in ('sample', 'position', 'history', 'roles', 'scores')) and
                record.get('target_position') == p+1 and record.get('token') == inventory['sequence'][p+1] and
                record.get('logprob') == rows[p]['logprob'] and record.get('raw_logits_sha256') == raw_sha,
                'row JSON target/provenance differs')
        array = Array(output, {'path': prefix + '.npy'})
        require(array.shape == [1, VOCABULARY] and array.dtype.kind == 'f' and array.dtype.itemsize == 8, 'full FP64 row shape/dtype differs')
        values = np.load(output / (prefix + '.npy'), mmap_mode='r', allow_pickle=False)
        try:
            require(np.isfinite(values).all() and values.max() <= 0 and
                    float(values[0, inventory['sequence'][p+1]]) == rows[p]['logprob'], 'distribution row/target is invalid')
        finally:
            values._mmap.close()
    summary = read(output / 'capture-summary.json')
    require(summary.get('native_forward_calls') == 1 and summary.get('native_logits_shape') == [1, 160, VOCABULARY] and
            summary.get('native_logits_dtype') == 'torch.bfloat16' and summary.get('use_cache') is False and
            summary.get('returned_cache', object()) is None and summary.get('logits_to_keep') == 0 and
            summary.get('targets') == 159 and summary.get('sampled_distributions') == 47, 'native full-call summary differs')
    events = read(output / 'events.json')
    require(len(events) == 1 and events[0] == {'stage': 'full_forward', 'input_ids': inventory['sequence'],
        'positions': list(range(160)), 'attention_mask': [[1] * 160], 'past_key_values': None,
        'use_cache': False, 'logits_to_keep': 0, 'return_dict': True, 'returned_cache': None,
        'native_logits_shape': [1, 160, VOCABULARY], 'native_logits_dtype': 'torch.bfloat16'}, 'full-call input/event evidence differs')
    if require_completed:
        status = read(output / 'status.json')
        require(status.get('status') == 'completed' and status.get('task') == TASK and
                status.get('artifacts_manifest_sha256') == sha(output / 'artifacts-manifest.json'), 'completion is not bound to manifest')
    return {'status': 'i01_output_artifacts_checked', 'targets': 159, 'distribution_positions': 47,
            'raw_logits_shape': [1, 160, VOCABULARY], 'artifacts_manifest_sha256': sha(output / 'artifacts-manifest.json'),
            'output_bytes': check_storage(output), 'native_executions_started_by_validator': 0,
            'value_rederivation': 'delegated to independent raw-BF16 admission', 'acceptance': None}

"""Private Linux serial launcher for the frozen Ascend TP1 candidate.

No model runs on import or during --_probe-output. The normal CLI uses the
existing task-root/collector tree and writes a new runs/npu-repeat-launch-UTC
batch. Linux subreaper cleanup applies only to this launcher's descendants.
"""

SOURCE_RELEASE_DEPLOYMENT_ENABLED = None
if __name__ == '__main__' and SOURCE_RELEASE_DEPLOYMENT_ENABLED is not True:
    raise SystemExit('SOURCE_RELEASE_NATIVE_DISABLED: configure and review fresh deployment paths, hashes, allocation and finite claims')
import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import uuid

GIB = 1024 ** 3
PINNED = {
 'projects/gemma4-pilot/cases/text-native/adapters/pilot_ascend_candidate.py': '3d5417342f32e06db6651ff6ca0f168ec933402a194116619e31bbf7c942eb72',
 'projects/gemma4-pilot/cases/text-native/adapters/record_execution_v2.py': 'd0dd1968ba05d5f7c58b97f054287b3ed478809d38743e45f2f4e42ab6e7d79b',
 'projects/gemma4-pilot/cases/text-native/adapters/pilot_gpu_peer_v2.py': 'fbf0b1dc4b03576852d166bc56d3bca14d6544be8aebd120ef0b92f146429eae',
 'projects/gemma4-pilot/cases/text-native/adapters/verify_snapshot.py': 'cd64a5f3f380d9cc04578848ba508ace3f1df0752ca952b8d575dd2904196f26',
 'projects/gemma4-pilot/cases/text-native/adapters/upstream-identity.json': '80dc0e0e59e5c526426b566d36a21f762a79d498986d5d6cd01098c8cb5decc3',
 'projects/gemma4-pilot/cases/text-native/inputs/discovery-v1/wikitext2-discovery-001.json': '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0',
 'skills/precision-compare/scripts/inference_capture.py': '5d388e846249d7fd74df1b15036f8a371e3267ada1b2fb0408bc51345ffad19c',
 'skills/precision-compare/scripts/artifact_io.py': '0260cd5ee1fd4e9d37e39bfd79efa9e663a1d48cb75b5adb31b84af9e1edbf39',
 'skills/precision-compare/scripts/compare_distributions.py': '6abc2eb0a741d554127911de9845d16e0d40f3f7759c42c172eae4907bbf8fc0',
 'skills/precision-compare/scripts/conditions.py': 'e012c025395f2f0474f0b35074d8417ec5a217f3659f82218de0f5d05068036d',
}
COLLECTOR = 'projects/gemma4-pilot/cases/text-native/adapters/pilot_ascend_candidate.py'
RECORDER = 'projects/gemma4-pilot/cases/text-native/adapters/record_execution_v2.py'
INPUT = 'projects/gemma4-pilot/cases/text-native/inputs/discovery-v1/wikitext2-discovery-001.json'
REPEATS = 3
PER_RUN_TIMEOUT = 1800


def stamp():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def put(path, value):
    temp = path.with_name(path.name + '.tmp')
    with temp.open('w', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n')
        f.flush(); os.fsync(f.fileno())
    os.replace(temp, path)


def nonzero_uuid(value):
    parsed = uuid.UUID(str(value).strip())
    if not parsed.int:
        raise ValueError('unavailable all-zero UUID')
    return str(parsed)


def binding(allocation_path, mapping_path, source_path):
    a, m, s = read(allocation_path), read(mapping_path), read(source_path)
    physical = nonzero_uuid(a.get('physical_device_id'))
    if (a.get('physical_device_id') != physical or a.get('vendor') != 'Ascend' or a.get('visible_count') != 8 or type(a.get('visible_count')) is not int
            or a.get('logical_ordinal') != 0 or type(a.get('logical_ordinal')) is not int
            or not isinstance(a.get('allocation_id'), str) or not a['allocation_id'].strip()
            or not isinstance(a.get('evidence_source'), str) or not a['evidence_source'].strip()):
        raise ValueError('allocation must explicitly bind ordinal 0 in the observed eight-device allocation')
    if (m.get('schema_version') != 1 or m.get('vendor') != 'Ascend' or m.get('allocation_id') != a['allocation_id']
            or m.get('visible_count') != 8 or type(m.get('visible_count')) is not int
            or m.get('logical_ordinal') != 0 or type(m.get('logical_ordinal')) is not int
            or m.get('device') != 'npu:0' or m.get('method') != 'runtime_uuid'
            or m.get('runtime_uuid') != physical or m.get('physical_device_id') != physical):
        raise ValueError('native mapping does not match the supplied UUID allocation')
    source = m.get('source', {})
    if (not isinstance(source, dict) or set(source) != {'source_path', 'file'}
            or not isinstance(source.get('file'), dict) or set(source['file']) != {'path', 'sha256'}
            or not isinstance(source['file'].get('path'), str) or not source['file']['path']
            or Path(source.get('source_path', '')).resolve() != source_path.resolve()
            or source.get('file', {}).get('sha256') != sha(source_path)):
        raise ValueError('native source path/hash differs from frozen mapping')
    acl = s.get('cann_user_physical_mapping', {})
    v = acl.get('value', {})
    if (s.get('native_requested') is not True
            or s.get('status') != 'native_observations_recorded_needs_allocation_mapping_review'
            or s.get('availability', {}).get('visible_count') != 8
            or s.get('device', {}).get('current_ordinal') != 0
            or nonzero_uuid(s.get('device', {}).get('runtime_uuid')) != physical
            or acl.get('ok') is not True or v.get('user_ordinal') != 0
            or v.get('forward_returncode') != 0 or v.get('reverse_returncode') != 0
            or v.get('reverse_user_ordinal') != 0 or type(v.get('physical_device_id')) is not int
            or v['physical_device_id'] < 0):
        raise ValueError('native preflight does not establish the supplied ordinal/UUID mapping')
    return a, physical


def memory_observation(proc_root=Path('/proc'), cgroup_root=Path('/sys/fs/cgroup')):
    entries = dict(line.split(':', 1) for line in (proc_root / 'meminfo').read_text().splitlines() if ':' in line)
    available = int(entries['MemAvailable'].split()[0]) * 1024
    records = []
    if (cgroup_root / 'memory.max').is_file():
        bases = [cgroup_root]
        memberships = (proc_root / 'self/cgroup').read_text().splitlines()
        group = next((x.split(':', 2)[2] for x in memberships if x.startswith('0::')), None)
        if group is None or '..' in Path(group).parts:
            raise RuntimeError('unresolved cgroup v2 membership')
        nested = cgroup_root / group.lstrip('/')
        if nested != cgroup_root and nested.is_dir():
            bases = [nested, *[p for p in nested.parents if p != cgroup_root and p.is_relative_to(cgroup_root)], cgroup_root]
        elif group != '/':
            raise RuntimeError('cgroup membership is not exposed under its mount; review memory limits')
        for base in bases:
            if not (base / 'memory.max').is_file():
                continue
            limit_raw = (base / 'memory.max').read_text().strip()
            used = int((base / 'memory.current').read_text().strip())
            limit = None if limit_raw == 'max' else int(limit_raw)
            records.append({'limit_source': str(base / 'memory.max'), 'used_source': str(base / 'memory.current'),
                            'limit_bytes': limit, 'used_bytes': used})
    else:
        base = cgroup_root / 'memory'
        memberships = (proc_root / 'self/cgroup').read_text().splitlines()
        group = next((x.split(':', 2)[2] for x in memberships if 'memory' in x.split(':', 2)[1].split(',')), None)
        if group is None or '..' in Path(group).parts:
            raise RuntimeError('unresolved cgroup v1 memory membership')
        nested = base / group.lstrip('/')
        if nested != base and nested.is_dir():
            bases = [nested, *[p for p in nested.parents if p != base and p.is_relative_to(base)], base]
        elif group == '/':
            bases = [base]
        else:
            raise RuntimeError('cgroup v1 membership is not exposed under its mount')
        for current in bases:
            limit = int((current / 'memory.limit_in_bytes').read_text().strip())
            used = int((current / 'memory.usage_in_bytes').read_text().strip())
            records.append({'limit_source': str(current / 'memory.limit_in_bytes'),
                            'used_source': str(current / 'memory.usage_in_bytes'),
                            'limit_bytes': None if limit >= 2 ** 60 else limit, 'used_bytes': used})
    if not records:
        raise RuntimeError('no cgroup memory observation available')
    effective = min([available] + [max(0, x['limit_bytes'] - x['used_bytes']) for x in records if x['limit_bytes'] is not None])
    return {'host_available_bytes': available, 'cgroup_records': records, 'effective_available_bytes': effective,
            'minimum_bytes': 80 * GIB, 'scope': 'Visible host and cgroup limits at the time of observation'}


def native_probe(args, output):
    a, physical = binding(args.allocation, args.native_mapping, args.native_source)
    memory = memory_observation()
    if memory['effective_available_bytes'] < 80 * GIB:
        raise RuntimeError('effective host/cgroup free memory is below 80GiB')
    import torch
    import torch_npu
    import transformers
    if (str(torch.__version__).split('+')[0] != '2.9.0'
            or str(torch_npu.__version__) != '2.9.0.post2' or transformers.__version__ != '5.10.1'):
        raise RuntimeError('actual Torch/TorchNPU/Transformers differ from 2.9.0/2.9.0.post2/5.10.1')
    npu = torch_npu.npu
    if not npu.is_available() or npu.device_count() != 8:
        raise RuntimeError('native NPU availability/count differs from allocation')
    npu.set_device(0)
    if npu.current_device() != 0 or not npu.is_bf16_supported():
        raise RuntimeError('native ordinal or BF16 availability differs')
    actual = nonzero_uuid(getattr(npu.get_device_properties(0), 'uuid', None))
    free, total = map(int, npu.mem_get_info(0))
    if actual != physical or free < 35 * GIB:
        raise RuntimeError('native UUID mismatch or selected NPU has less than 35GiB free')
    torch.set_float32_matmul_precision('highest')
    npu.matmul.allow_hf32 = False; npu.conv.allow_hf32 = True
    policy = {'float32_matmul_precision': torch.get_float32_matmul_precision(),
              'matmul_allow_hf32': npu.matmul.allow_hf32, 'conv_allow_hf32': npu.conv.allow_hf32}
    if (type(policy['matmul_allow_hf32']) is not bool or type(policy['conv_allow_hf32']) is not bool
            or policy != {'float32_matmul_precision': 'highest', 'matmul_allow_hf32': False, 'conv_allow_hf32': True}):
        raise RuntimeError('native process-local HF32 policy set/read differs')
    if output.exists():
        raise FileExistsError('round preflight output already exists')
    put(output, {'status': 'preflight_passed', 'utc': stamp(), 'versions': {'torch': str(torch.__version__),
        'torch_npu': str(torch_npu.__version__), 'transformers': transformers.__version__},
        'logical_ordinal': 0, 'visible_count': 8, 'runtime_uuid': actual, 'allocation_id': a['allocation_id'],
        'free_bytes': free, 'total_bytes': total, 'bf16': True, 'policy': policy, 'host_memory': memory,
        'scope': 'Fresh TP1 process preflight only; no model loaded; resource availability is a point-in-time observation'})


class Abort(Exception):
    pass


def proc_table(proc_root=Path('/proc')):
    result = {}
    for p in proc_root.iterdir():
        if not p.name.isdigit():
            continue
        try:
            fields = (p / 'stat').read_text().rpartition(')')[2].split()
            result[int(p.name)] = {'state': fields[0], 'ppid': int(fields[1]), 'pgrp': int(fields[2]), 'start': int(fields[19])}
        except (OSError, IndexError, ValueError):
            continue
    return result


def descendants():
    table, owned = proc_table(), {os.getpid()}
    while True:
        new = {p for p, data in table.items() if data['ppid'] in owned} - owned
        if not new:
            break
        owned.update(new)
    return {p: table[p] for p in owned if p != os.getpid() and p in table}


def reap_adopted(skip=None):
    for pid, record in descendants().items():
        if record['ppid'] == os.getpid() and pid != skip:
            try:
                os.waitpid(pid, os.WNOHANG)
            except ChildProcessError:
                pass


def cleanup(proc):
    """First allow recorder v2 to clean its collector, then reap own orphans."""
    old = {s: signal.signal(s, signal.SIG_IGN) for s in (signal.SIGTERM, signal.SIGINT)}
    try:
        if proc is not None and proc.poll() is None:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                proc.wait(timeout=4)
            except subprocess.TimeoutExpired:
                pass
        for sig, grace in ((signal.SIGTERM, 3), (signal.SIGKILL, 2)):
            live = {p: d for p, d in descendants().items() if d['state'] != 'Z'}
            for pid, record in live.items():
                # Fresh lineage snapshot and start-time guard avoid stale PID reuse.
                current = proc_table().get(pid)
                if current is not None and current['start'] == record['start']:
                    try:
                        os.kill(pid, sig)
                    except ProcessLookupError:
                        pass
            end = time.monotonic() + grace
            while time.monotonic() < end:
                if proc is not None:
                    proc.poll()
                reap_adopted(proc.pid if proc is not None and proc.returncode is None else None)
                if not any(d['state'] != 'Z' for d in descendants().values()):
                    break
                time.sleep(.05)
        if proc is not None:
            proc.wait(timeout=1)
        reap_adopted()
        remaining = descendants()
        if remaining:
            raise RuntimeError('task descendants remain after cleanup: ' + str(sorted(remaining)))
    finally:
        for sig, handler in old.items():
            signal.signal(sig, handler)


def bounded(argv, cwd, stdout_path, stderr_path, deadline):
    proc = None
    try:
        with stdout_path.open('xb') as out, stderr_path.open('xb') as err:
            proc = subprocess.Popen(argv, cwd=cwd, stdout=out, stderr=err, stdin=subprocess.DEVNULL,
                                    start_new_session=True)
            while proc.poll() is None:
                if time.monotonic() >= deadline:
                    raise TimeoutError('bounded child deadline exceeded')
                try:
                    proc.wait(timeout=min(.5, max(.01, deadline - time.monotonic())))
                except subprocess.TimeoutExpired:
                    pass
            return proc.returncode
    finally:
        cleanup(proc)


def validate_files(args):
    root = args.task_root / 'collector'
    paths = {name: root / name for name in PINNED}
    for name, path in paths.items():
        if not path.is_file() or path.is_symlink() or sha(path) != PINNED[name]:
            raise ValueError('uploaded frozen source differs: ' + name)
    binding(args.allocation, args.native_mapping, args.native_source)
    extra = [args.allocation, args.native_mapping, args.native_source, Path(__file__).resolve()]
    frozen = {str(path.resolve()): sha(path) for path in [*paths.values(), *extra]}
    return paths, frozen


def assert_frozen(frozen):
    if any(sha(Path(path)) != value for path, value in frozen.items()):
        raise RuntimeError('frozen source or allocation evidence changed')


def run(args):
    import fcntl
    if os.environ.get('PYTHONHASHSEED') != '0':
        raise ValueError('launch with PYTHONHASHSEED=0')
    paths, frozen = validate_files(args)
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise OSError(ctypes.get_errno(), 'Linux child subreaper unavailable')
    lock = (args.task_root / 'npu-repeat-launch.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    started = time.monotonic()
    deadline = started + args.max_seconds - 20  # reserve bounded cleanup before the 6000s maximum
    batch = args.task_root / 'runs' / ('npu-repeat-launch-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    batch.parent.mkdir(exist_ok=True); batch.mkdir(exist_ok=False)
    state = {'status': 'running', 'started_utc': stamp(), 'max_seconds': args.max_seconds,
             'per_run_timeout': PER_RUN_TIMEOUT, 'source_sha256': frozen, 'runs': [],
             'scope': 'Three serial independent TP1 captures; no numerical acceptance or distributed-model claim'}
    handlers = {}
    def interrupt(signum, _frame):
        raise Abort('signal ' + str(signum))
    try:
        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGALRM):
            handlers[sig] = signal.signal(sig, interrupt)
        signal.setitimer(signal.ITIMER_REAL, args.max_seconds)
        put(batch / 'status.json', state)
        for number in range(1, REPEATS + 1):
            assert_frozen(frozen)
            if deadline - time.monotonic() < PER_RUN_TIMEOUT + 80:
                raise TimeoutError('not enough total budget for another full round and cleanup')
            runroot = batch / ('npu-inference-r%02d-' % number + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
            runroot.mkdir(exist_ok=False)
            probe = runroot / 'round-native-preflight.json'
            probe_argv = [sys.executable, '-B', str(Path(__file__).resolve()),
                '--task-root', str(args.task_root), '--model', str(args.model), '--allocation', str(args.allocation),
                '--native-mapping', str(args.native_mapping), '--native-source', str(args.native_source),
                '--_probe-output', str(probe)]
            code = bounded(probe_argv, args.task_root, runroot / 'preflight.stdout', runroot / 'preflight.stderr',
                           min(deadline, time.monotonic() + 60))
            if code != 0 or read(probe).get('status') != 'preflight_passed':
                raise RuntimeError('round native preflight failed: ' + str(number))
            dependencies = [path for key, path in paths.items() if key not in (COLLECTOR, INPUT)]
            dependencies += [args.allocation, args.native_mapping, args.native_source, Path(__file__).resolve(), probe]
            if len({p.name for p in dependencies}) != len(dependencies):
                raise ValueError('dependency basenames must be distinct')
            argv = [sys.executable, '-B', str(paths[RECORDER]), '--collector', str(paths[COLLECTOR]),
                    '--input', str(paths[INPUT]), '--capture-output', str(runroot / 'artifacts'),
                    '--receipt-dir', str(runroot / 'recorder'), '--backend', 'NPU',
                    '--timeout', str(PER_RUN_TIMEOUT)]
            for path in dependencies:
                argv += ['--dependency', str(path.resolve())]
            argv += ['--', '--model', str(args.model), '--allocation-receipt', str(args.allocation), '--device', 'npu:0']
            put(runroot / 'launcher-argv.json', argv)
            code = bounded(argv, args.task_root, runroot / 'recorder.stdout', runroot / 'recorder.stderr',
                           min(deadline, time.monotonic() + PER_RUN_TIMEOUT + 20))
            receipt = read(runroot / 'recorder/receipt.json')
            if code != 0 or receipt.get('schema_version') != 2 or receipt.get('status') != 'completed' or receipt.get('returncode') != 0:
                raise RuntimeError('round collector/recorder failed: ' + str(number))
            assert_frozen(frozen)
            state['runs'].append({'round': number, 'root': str(runroot), 'receipt_sha256': sha(runroot / 'recorder/receipt.json'),
                                  'preflight_sha256': sha(probe)})
            put(batch / 'status.json', state)
        state['status'] = 'completed'
    except BaseException as exc:
        state.update(status='interrupted' if isinstance(exc, Abort) else 'failed',
                     error_type=type(exc).__name__, error=str(exc))
    finally:
        try:
            cleanup(None)
        except Exception as exc:
            state.update(status='cleanup_failed', cleanup_error=str(exc))
        signal.setitimer(signal.ITIMER_REAL, 0)
        for sig, handler in handlers.items():
            signal.signal(sig, handler)
        state.update(finished_utc=stamp(), elapsed_seconds=time.monotonic() - started,
                     remaining_descendants=sorted(descendants()))
        put(batch / 'status.json', state)
        fcntl.flock(lock, fcntl.LOCK_UN); lock.close()
    print(json.dumps({'status': state['status'], 'batch': str(batch), 'completed_rounds': len(state['runs'])}), flush=True)
    return 0 if state['status'] == 'completed' else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--task-root', type=Path, required=True)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--allocation', type=Path, required=True)
    parser.add_argument('--native-mapping', type=Path, required=True)
    parser.add_argument('--native-source', type=Path, required=True)
    parser.add_argument('--max-seconds', type=int, default=6000)
    parser.add_argument('--_probe-output', type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if os.name != 'posix' or not Path('/proc/self/stat').is_file() or not sys.platform.startswith('linux'):
        parser.error('Linux process supervision required; no model started')
    if not 30 <= args.max_seconds <= 6000:
        parser.error('max-seconds must be 30..6000')
    for name in ('task_root', 'model', 'allocation', 'native_mapping', 'native_source'):
        p = getattr(args, name)
        if not p.is_absolute() or p.is_symlink() or not p.exists():
            parser.error(name + ' must be an existing explicit absolute nonsymlink path')
        setattr(args, name, p.resolve())
    if not args.task_root.is_dir() or not args.model.is_dir():
        parser.error('task-root and model must be directories')
    if args._probe_output:
        native_probe(args, args._probe_output)
        return 0
    return run(args)


if __name__ == '__main__':
    raise SystemExit(main())

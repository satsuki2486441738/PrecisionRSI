"""Exclusive observer NPU source packaging/staging/start/query/owned-stop.

Build and stage are stdlib metadata work. Only start spawns the reviewed new
launcher; each attempt is permanent. Original dual proof documents are copied
verbatim, with their original POSIX source references intact.
"""
import argparse
import ast
from datetime import datetime,timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path,PurePosixPath
import signal
import subprocess
import sys
import tarfile
import time

CASE='projects/gemma4-pilot/cases/text-native'
NAME='observer-transparency-20261107/native-v1'
TASK_ID='gemma4-gpu-npu-observer-v1-20261107'
LAUNCHER=CASE+'/transfer/npu_observer_launcher_v1.py'
OPERATIONS=CASE+'/transfer/npu_observer_operations_v1.py'
HELPER=CASE+'/transfer/npu_three_repeat_launcher_v4.py'
HELPER_SHA='c1719e831a557cd9707374138d9219a8ae887854dd029a1ec165631d9259f485'
UUID='REDACTED_DEVICE_UUID'
GEOMETRY_SOURCES={
    'geometry/gpu-loaded-inventory.json':CASE+'/transfer/i01-numeric-small-local-20261106T145700Z/payload/payload/0190/loaded-model-inventory.json',
    'geometry/npu-loaded-inventory.json':CASE+'/transfer/i01-numeric-small-local-20261106T145700Z/payload/payload/0337/loaded-model-inventory.json',
    'geometry/config.json':CASE+'/transfer/hf-smallfiles-20261105T112300Z/snapshot/config.json',
    'geometry/modeling_gemma4_unified.py':CASE+'/transfer/i01-numeric-small-local-20261106T145700Z/payload/payload/0101/modeling_gemma4_unified.py'}
LIMIT,EXPANDED,COUNT=16*1024**2,64*1024**2,128


def require(ok,message):
    if not ok:raise ValueError(message)
def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):digest.update(block)
    return digest.hexdigest()
def read(path):
    def pairs(items):
        out={}
        for k,v in items:require(k not in out,'duplicate JSON key');out[k]=v
        return out
    return json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def raw_put(path,raw):
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
def put(path,doc):raw_put(path,(json.dumps(doc,indent=2,allow_nan=False)+'\n').encode())
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def safe(name):
    require(isinstance(name,str) and name and '\\' not in name,'unsafe package path');p=PurePosixPath(name)
    require(not p.is_absolute() and str(p)==name and all(x not in ('','.','..') for x in name.split('/')),'unsafe package path');return p
def contained(path,root):
    path,root=Path(path),Path(root);require(path.is_absolute() and root.is_absolute() and not root.is_symlink() and path.resolve().is_relative_to(root.resolve()),'path escapes task/root')
    cursor=path
    while cursor!=root:require(not cursor.is_symlink(),'source/target ancestor is symlink');cursor=cursor.parent
    return path
def original(path,root=None):
    path=Path(path)
    if root is not None:contained(path,root)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size<=LIMIT,'bounded regular metadata/source required');return path


def build(repo,output,i04_proof,cpu_proof):
    started=time.monotonic();repo=Path(repo).resolve(strict=True);output=Path(output).absolute();job=load(repo/LAUNCHER,'observer_source_packager_launcher');job.ready()
    require(not output.exists() and not output.is_symlink() and output.parent.is_dir(),'new exclusive package directory required')
    contents={}
    for name,digest in {**job.PINS,LAUNCHER:sha(repo/LAUNCHER)}.items():
        safe(name);path=original(repo/GEOMETRY_SOURCES.get(name,name),repo);raw=path.read_bytes()
        require(sha(path)==digest and len(raw)<=(1024**2 if name.endswith('.py') else LIMIT),'reviewed source bytes differ: '+name)
        if name.endswith('.py'):ast.parse(raw)
        contents[name]=raw
    i04,cpu=original(Path(i04_proof).absolute()),original(Path(cpu_proof).absolute())
    gate=load(repo/job.PREREQUISITE,'observer_packager_actual_dual_proof');checked=gate.prerequisite(i04,job.I04_SHA,cpu,job.CPU_SHA)
    require(len(checked['refs'])==35,'actual35 original dual proof refs required')
    for wrapper,label,count in ((i04,'i04',9),(cpu,'cpu',25)):
        prefix='prerequisites/'+label;contents[prefix+'/prerequisite.json']=wrapper.read_bytes()
        def visit(value):
            if isinstance(value,dict):
                if set(value) in ({'path','source_path','sha256'},{'path','source_path','sha256','size_bytes'}):
                    name=str(safe(value['path']));path=original(wrapper.parent/name,wrapper.parent);raw=path.read_bytes();key=prefix+'/'+name
                    require(sha(path)==value['sha256'] and ('size_bytes' not in value or len(raw)==value['size_bytes']) and key not in contents,'original proof changed/duplicate')
                    contents[key]=raw
                else:
                    for child in value.values():visit(child)
            elif isinstance(value,list):
                for child in value:visit(child)
        visit(read(wrapper));require(sum(name.startswith(prefix+'/') for name in contents)==count,'actual8/24 raw proof count differs')
    for item in checked['refs'].values():require(sha(original(item['path']))==item['sha256'],'proof original changed during packaging')
    require(not any(name in sys.modules for name in ('torch','torch_npu','numpy','transformers')),'packager imported a framework')
    files={name:{'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw),'kind':'code' if name.endswith('.py') else 'metadata'} for name,raw in sorted(contents.items())}
    manifest={'schema_version':1,'task_id':TASK_ID,'files':files};raw_manifest=(json.dumps(manifest,indent=2,allow_nan=False)+'\n').encode()
    require(len(files)<COUNT and sum(map(len,contents.values()))+len(raw_manifest)<=EXPANDED and time.monotonic()-started<120,'source count/storage/time cap exceeded')
    output.mkdir(mode=0o700);archive=output/'npu-observer-source-v1.tar.gz'
    with archive.open('xb') as stream,tarfile.open(fileobj=stream,mode='w:gz',format=tarfile.USTAR_FORMAT) as package:
        for name,raw in [(NAME+'/source-manifest.json',raw_manifest),*[(NAME+'/source/'+name,raw) for name,raw in sorted(contents.items())]]:
            info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o600;package.addfile(info,io.BytesIO(raw))
    require(archive.stat().st_size<=LIMIT,'source archive exceeds16MiB')
    receipt={'status':'observer_source_package_created_not_executed','archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),
        'source_manifest_sha256':hashlib.sha256(raw_manifest).hexdigest(),'source_files':len(files),'dual_proof_ref_count':35,
        'i04_prerequisite_sha256':job.I04_SHA,'cpu_prerequisite_sha256':job.CPU_SHA,'native_executions_started':0}
    put(output/'receipt.json',receipt);return receipt


def stage_archive(base,archive,archive_sha,manifest_sha):
    base=Path(base).absolute();require(base.is_dir() and not base.is_symlink(),'original R base required');base=base.resolve(strict=True)
    archive=original(Path(archive).absolute(),base);require(sha(archive)==archive_sha,'uploaded archive external SHA differs')
    prefix=NAME+'/';data={}
    with tarfile.open(archive,'r:*') as package:
        members=package.getmembers();require(0<len(members)<=COUNT and len({x.name for x in members})==len(members) and sum(x.size for x in members)<=EXPANDED,'duplicate/excess/large package')
        for item in members:
            safe(item.name);require(item.name.startswith(prefix) and item.isfile() and not item.issym() and not item.islnk() and not item.pax_headers and
                not getattr(item,'sparse',None) and 0<=item.size<=LIMIT,'bounded regular USTAR members only')
            raw=package.extractfile(item).read(item.size+1);require(len(raw)==item.size,'truncated package member');data[item.name]=raw
    names=set(data);require(all(not any(str(p) in names for p in PurePosixPath(n).parents if str(p)!='.') for n in names),'member ancestor collision')
    raw=data[prefix+'source-manifest.json'];require(hashlib.sha256(raw).hexdigest()==manifest_sha,'external source manifest differs')
    doc=json.loads(raw);require(set(doc)=={'schema_version','task_id','files'} and doc['schema_version']==1 and doc['task_id']==TASK_ID and
        set(data)=={prefix+'source/'+n for n in doc['files']}|{prefix+'source-manifest.json'},'exact manifest closure differs')
    for name,item in doc['files'].items():
        safe(name);raw=data[prefix+'source/'+name];require(set(item)=={'sha256','size_bytes','kind'} and item['kind']==('code' if name.endswith('.py') else 'metadata') and
            type(item['size_bytes']) is int and len(raw)==item['size_bytes']<=(1024**2 if item['kind']=='code' else LIMIT) and hashlib.sha256(raw).hexdigest()==item['sha256'],'typed source hash/size differs')
        if item['kind']=='code':ast.parse(raw)
    task=contained(base/NAME,base);require(not task.exists(),'new observer native-v1 namespace must not already exist')
    task.parent.mkdir(parents=True,exist_ok=True);task.mkdir(mode=0o700)
    for name,raw in data.items():
        target=contained(base/name,base);target.parent.mkdir(parents=True,exist_ok=True);raw_put(target,raw)
    return {'status':'observer_sources_staged_not_executed','source_files':len(doc['files']),'source_manifest_sha256':manifest_sha,'archive_sha256':archive_sha,'native_executions_started':0}


def configuration(base,manifest_sha):
    base=Path(base).resolve(strict=True);task=contained(base/NAME,base);source=contained(task/'source',base);manifest=original(task/'source-manifest.json',task)
    require(sha(manifest)==manifest_sha,'actual source manifest external SHA differs');doc=read(manifest)
    require(sha(__file__)==doc['files'][OPERATIONS]['sha256'],'executed operations source differs from staged original')
    launcher=original(source/LAUNCHER,source);require(sha(launcher)==doc['files'][LAUNCHER]['sha256'],'staged launcher changed');job=load(launcher,'observer_operations_staged_launcher')
    args=argparse.Namespace(task_root=task,source_root=source,model=base/'model-download-v1/snapshot',allocation=base/'allocation-20261106-b.json',
        native_mapping=base/'native-mapping-20261106-b.json',native_source=base/'native-preflight-20261106-b.json',driver_source=Path('/usr/local/Ascend/driver/version.info'),
        source_manifest=manifest,source_manifest_sha256=manifest_sha,npu_smi=Path('/srv/precision-user/.local/bin/npu-smi'),npu_smi_sha256=job.SMI_SHA,
        expected_inventory_sha256=job.EXPECTED_SHA,i04_prerequisite=source/'prerequisites/i04/prerequisite.json',i04_prerequisite_sha256=job.I04_SHA,
        cpu_prerequisite=source/'prerequisites/cpu/prerequisite.json',cpu_prerequisite_sha256=job.CPU_SHA)
    return job,args


def validate(base,manifest_sha):
    job,args=configuration(base,manifest_sha);helper,legacy,allocation,files=job.source_check(args)
    return job,args,{'status':'observer_sources_and_actual35proofs_checked','source_files_checked':len(files),'source_manifest_sha256':manifest_sha,
        'expected_inventory_sha256':job.EXPECTED_SHA,'i04_prerequisite_sha256':job.I04_SHA,'cpu_prerequisite_sha256':job.CPU_SHA,
        'runtime_uuid_binding':allocation['physical_device_id'],'native_device_initialized':False,'native_model_started':False}


def start(base,manifest_sha):
    job,args,verified=validate(base,manifest_sha);claim=args.task_root/'claims'/('npu-observer-'+UUID)
    require(not claim.exists() and not claim.is_symlink(),'permanent observer claim already spent; never retry')
    python=original(Path(base)/'venv/bin/python') if not (Path(base)/'venv/bin/python').is_symlink() else Path(base)/'venv/bin/python'
    require(python.is_file(),'original NPU interpreter missing')
    run=args.task_root/'runs'/('compare-observer-launch-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'));run.mkdir(parents=True)
    argv=job.argv_copy(args);argv[0]=str(python)
    put(args.task_root/'launch-once.json',{'status':'launch_attempt_claimed_not_result','started_utc':datetime.now(timezone.utc).isoformat(),'run':str(run),
        'argv':argv,'source_manifest_sha256':manifest_sha,'automatic_retry':False})
    env=dict(os.environ)
    for key in ('PYTHONPATH','PYTHONHOME'):env.pop(key,None)
    env.update(PYTHONHASHSEED='0',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',TORCH_DEVICE_BACKEND_AUTOLOAD='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    with (run/'stdout.bin').open('xb') as out,(run/'stderr.bin').open('xb') as err:
        proc=subprocess.Popen(argv,cwd=args.source_root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
    try:creation=job.process_start(proc.pid)
    except FileNotFoundError:creation=None
    receipt={'status':'launcher_spawned_not_result','started_utc':datetime.now(timezone.utc).isoformat(),'pid':proc.pid,'starttime':creation,
        'immediate_child_returncode':proc.poll(),'argv':argv,'claim':str(claim),'preflight':verified,'launcher_sha256':sha(args.source_root/LAUNCHER),
        'operations_source_sha256':sha(__file__),'source_manifest_sha256':manifest_sha,'max_native_model_processes':1,'max_forward_calls':4,
        'capture_timeout_seconds':1500,'controller_work_seconds':2620,'whole_timeout_seconds':3600,'automatic_retry':False,'acceptance':None}
    put(run/'start-receipt.json',receipt);return {'status':receipt['status'],'pid':proc.pid,'start_receipt':str(run/'start-receipt.json'),'start_receipt_sha256':sha(run/'start-receipt.json')}


def query(base):
    task=Path(base)/NAME;claim=task/'claims'/('npu-observer-'+UUID);result={'claim':str(claim),'receipts':[],'native_executions_started_by_query':0}
    intent=task/'launch-once.json'
    if intent.is_file():
        launch=read(original(intent,task));run=Path(launch['run']);contained(run,task/'runs');receipt=run/'start-receipt.json'
        if receipt.is_file():
            ref=read(original(receipt,task));result['start_receipt']={'path':str(receipt),'sha256':sha(receipt),'pid':ref['pid'],'starttime':ref['starttime']}
            try:matches=int((Path('/proc')/str(ref['pid'])/'stat').read_text().rpartition(')')[2].split()[19])==ref['starttime']
            except FileNotFoundError:matches=False
            result['recorded_pid_matches_starttime']=matches
        for name in ('stdout.bin','stderr.bin'):
            path=run/name
            if path.is_file():
                with path.open('rb') as stream:stream.seek(max(0,path.stat().st_size-4096));tail=stream.read(4096)
                result[name]={'path':str(path),'size_bytes':path.stat().st_size,'tail':tail.decode('utf8','replace')}
    for name in ('controller-receipt.json','capture-receipt.json','generic-receipt-reference.json'):
        path=claim/name
        if not path.is_file():result['receipts'].append({'path':str(path),'present':False});continue
        doc=read(original(path,task));result['receipts'].append({'path':str(path),'sha256':sha(path),**{key:doc.get(key) for key in
            ('status','returncode','timed_out','remaining_descendants','output_dir','native_forward_calls_total','model_loads','artifacts_manifest_sha256','wall_seconds','error')}})
    return result


def stop_owned(base,receipt_path,receipt_sha):
    task=Path(base)/NAME;receipt=original(Path(receipt_path).absolute(),task/'runs');require(sha(receipt)==receipt_sha,'actual original start receipt SHA required')
    doc=read(receipt);pid,creation=doc['pid'],doc['starttime'];path=original(task/'source'/HELPER,task)
    require(sha(path)==HELPER_SHA,'owned cleanup helper bytes differ');helper=load(path,'observer_owned_process_lineage_only');row=helper.proc_table().get(pid)
    if row is None or row['start']!=creation or row['state']=='Z':return {'status':'recorded_launcher_not_running','signals_sent':0}
    command=(Path('/proc')/str(pid)/'cmdline').read_bytes().split(b'\0')
    require(str(task/'source'/LAUNCHER).encode() in command and str(task).encode() in command,'saved PID is not this observer launcher')
    owned={pid:creation};sent=[]
    def living():
        table=helper.proc_table()
        while True:
            added={p:r['start'] for p,r in table.items() if p not in owned and r['ppid'] in owned and table.get(r['ppid'],{}).get('start')==owned[r['ppid']]}
            if not added:break
            owned.update(added)
        return {p:r for p,r in table.items() if p in owned and r['start']==owned[p] and r['state']!='Z'}
    living();fresh=helper.proc_table().get(pid);require(fresh and fresh['start']==creation,'saved launcher already exited')
    os.kill(pid,signal.SIGTERM);sent.append({'pid':pid,'creation':creation,'signal':'TERM'});deadline=time.monotonic()+16
    while living() and time.monotonic()<deadline:time.sleep(.1)
    for target in living():
        current=helper.proc_table().get(target)
        if current and current['start']==owned[target]:
            try:os.kill(target,signal.SIGKILL);sent.append({'pid':target,'creation':owned[target],'signal':'KILL'})
            except ProcessLookupError:pass
    deadline=time.monotonic()+3
    while living() and time.monotonic()<deadline:time.sleep(.1)
    result={'status':'owned_stop_checked','launch_receipt':str(receipt),'launch_receipt_sha256':receipt_sha,'owned_creation_times':owned,'signals':sent,
        'remaining_owned_non_zombie':sorted(living()),'claim_preserved':True,'shared_instance_stopped':False}
    output=receipt.parent/'owned-stop-receipt.json';put(output,result);return {'receipt':str(output),'sha256':sha(output),'remaining_owned':result['remaining_owned_non_zombie']}


def main():
    os.umask(0o077);parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('mode',choices=['build','stage','validate','start','query','stop'])
    for name in ('base','archive','repo','output','i04-proof','cpu-proof','start-receipt'):parser.add_argument('--'+name,type=Path)
    for name in ('archive-sha256','source-manifest-sha256','start-receipt-sha256'):parser.add_argument('--'+name)
    args=parser.parse_args()
    if args.mode=='build':result=build(args.repo,args.output,args.i04_proof,args.cpu_proof)
    else:
        require(args.base is not None and not args.base.is_symlink(),'explicit original R required');base=args.base.resolve(strict=True)
        if args.mode=='stage':result={**stage_archive(base,args.archive,args.archive_sha256,args.source_manifest_sha256),**validate(base,args.source_manifest_sha256)[2]}
        elif args.mode=='validate':result=validate(base,args.source_manifest_sha256)[2]
        elif args.mode=='start':result=start(base,args.source_manifest_sha256)
        elif args.mode=='query':result=query(base)
        else:result=stop_owned(base,args.start_receipt,args.start_receipt_sha256)
    print(json.dumps(result,indent=2,allow_nan=False),flush=True)


if __name__=='__main__':main()

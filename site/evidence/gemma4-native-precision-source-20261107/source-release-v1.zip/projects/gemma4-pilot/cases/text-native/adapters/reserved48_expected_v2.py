"""Independent stdlib inventory for48 English reserved I05/Q01 inputs.

No collector/common/framework import. Native activation and build remain closed
until the separate stage is reviewed and its exact hash replaces None.
"""
import argparse
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path,PurePosixPath

TASK='gemma4-reserved48-i05-q01-v1'
STAGE_ID='gemma4-gpu-npu-reserved48-i05-q01-v1'
STAGE_SHA256=None
MANIFEST_SHA256='10f6b1a6976507e1af65706ddd4bb61d9276c43ae443b2a6852935e2967dca37'
CONFIG_SHA256='14f38c5492ffc9cbcdf808647ca0c025bb5b9b4eb737526347134d500ace6098'
VOCABULARY=262144
CONTEXT_LIMIT=262144
BINS=[128,512,2048,8192]
MODES=['full','token','chunk']


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    def pairs(items):
        result={}
        for key,value in items:require(key not in result,'duplicate JSON key');result[key]=value
        return result
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)


def pair_plan():
    result=[{'a_backend':'GPU','a_mode':m,'b_backend':'NPU','b_mode':m,'kind':'cross_backend_matched'} for m in MODES]
    for backend in ('GPU','NPU'):
        result.extend({'a_backend':backend,'a_mode':a,'b_backend':backend,'b_mode':b,'kind':'within_backend_partition'} for a,b in itertools.combinations(MODES,2))
    require(len(result)==9,'exact three-cross/six-within inventory required');return result


def derive(manifest_path,input_dir,stage_sha=None):
    manifest_path,input_dir=Path(manifest_path),Path(input_dir)
    require(manifest_path.is_file() and not manifest_path.is_symlink() and sha(manifest_path)==MANIFEST_SHA256,'exact frozen48-article manifest required')
    manifest=load(manifest_path)
    require(manifest.get('state')=='frozen_reserved_english_article_validation' and manifest.get('requested_prompt_bins_including_BOS')==BINS and
        manifest.get('requested_per_bin')==12 and manifest.get('continuation_tokens')==32 and len(manifest.get('samples',[]))==48 and
        manifest.get('selection_on_model_outputs') is False and manifest.get('source',{}).get('official_validation_split') is False,
        'frozen English train-reserved cohort semantics differ')
    rows=[];names=set();articles=set();counts=Counter()
    for ref in manifest['samples']:
        name=ref['file'];relative=PurePosixPath(name)
        require(relative.name==name and '\\' not in name and name not in ('','.','..') and name.endswith('.json'),'one original input filename required')
        path=input_dir/name
        require(path.is_file() and not path.is_symlink() and path.resolve(strict=True).is_relative_to(input_dir.resolve(strict=True)) and
            path.stat().st_size==ref['bytes'] and sha(path)==ref['sha256'],'frozen input file bytes differ')
        doc=load(path);P=ref['prompt_length_including_BOS'];seq=doc['prompt']+doc['continuation'];L=P+32
        require(P in BINS and len(doc['prompt'])==P and len(doc['continuation'])==32 and len(seq)==L<=CONTEXT_LIMIT and
            all(type(t) is int and 0<=t<VOCABULARY for t in seq) and seq[0]==2,'untruncated P+32 tokens including BOS required')
        require(doc['sample']==ref['sample'] and doc.get('input_role')=='reserved_validation_not_for_policy_selection' and
            doc.get('source_partition')=='train_reserved_disjoint_articles' and doc.get('independent_representative_example') is True and
            doc.get('normalized_article_sha256')==ref['normalized_article_sha256'],'original article/role identity differs')
        require(doc['sample'] not in names and ref['normalized_article_sha256'] not in articles,'distinct reserved samples/articles required')
        names.add(doc['sample']);articles.add(ref['normalized_article_sha256']);counts[P]+=1
        selected=sorted(set((j*(P-1))//15 for j in range(16))|set(range(P-1,P+31)))
        require(len(selected)==47 and selected[-1]==L-2,'47 deduplicated prompt/continuation predictors required')
        split=P//2-1
        plans=[]
        for mode in MODES:
            spans=[[0,L]] if mode=='full' else ([[0,P]] if mode=='token' else [[0,split],[split,P]])+[[j,j+1] for j in range(P,L)]
            plans.append({'mode':mode,'use_cache':mode!='full','native_calls':len(spans),'input_spans_zero_based_half_open':spans,
                'attention_mask_rule':'ones[1,end] by length, never token!=0','position_rule':'absolute start..end-1',
                'logits_to_keep':0,'labels_supplied':False,'shared_kv_states_supplied':False})
        rows.append({'sample':doc['sample'],'input_file':name,'input_sha256':ref['sha256'],'article_sha256':ref['normalized_article_sha256'],
            'prompt_length':P,'continuation_length':32,'sequence_length':L,'input_ids':seq,
            'all_target_positions':list(range(1,L)),'all_target_tokens':seq[1:],
            'prediction_position_rule':'target_position-1','continuation_target_positions':list(range(P,L)),
            'distribution_positions':selected,'distribution_history_rule':'input_ids[:prediction_position+1]',
            'selected_native_BF16_shape':[47,VOCABULARY],'original_full_native_shape':[1,L,VOCABULARY],
            'unscored_finite_native_prediction_positions':[L-1],'modes':plans})
    require(counts==Counter({P:12 for P in BINS}),'all12 examples per exact bin required')
    result={'schema_version':2,'kind':'reserved48-independent-expected-inventory-v2','task':TASK,'stage_id':STAGE_ID,
        'stage_spec_sha256':stage_sha,'manifest_sha256':MANIFEST_SHA256,'config_sha256':CONFIG_SHA256,'vocabulary_size':VOCABULARY,
        'context_limit_from_pinned_config':CONTEXT_LIMIT,'prompt_bins':BINS,'samples':rows,'pairs_per_input':pair_plan(),
        'counts':{'inputs':48,'inputs_per_bin':12,'modes_per_input':3,'calls_per_input':68,'calls_per_backend':3264,
            'all_target_scores_per_mode':132048,'all_target_scores_per_backend':396144,'finite_native_rows_per_backend':396288,
            'selected_full_vocabulary_rows_per_backend':6768,'selected_native_BF16_bytes_per_backend':3548381184,
            'pairs_per_input':9,'pairs_total':432,'distribution_pair_positions':20304},
        'scope':'English reserved training articles only; no multilingual/code/math, policy selection, Q02/P01 or full raw/KV retention claim',
        'native_executions_started':0,'thresholds':None,'acceptance':None}
    result['native_capture_schema_version']=2
    result['native_progress']={'schema_version':1,'filename':'native-progress.jsonl','parent':'permanent_bin_claim',
        'per_prompt_bin':{str(P):{'planned_cells':[{'sample':row['sample'],'mode':mode['mode'],'prompt_length':P,
            'sequence_length':row['sequence_length'],'spans':mode['input_spans_zero_based_half_open']}
            for row in rows if row['prompt_length']==P for mode in row['modes']],
            'mode_entries':36,'forward_entries':816,'synchronized_returns':816,'source_summary_refs':36,'terminal_required':True}
            for P in BINS},
        'failure_scope':'Typed Torch OOM, runtime OOM text, host MemoryError and timeout remain distinct; no OOM attribution to unentered cells',
        'missing_terminal':'Unknown diagnostic; absence does not prove36 unexecuted cells',
        'numeric_admission_performed_by_progress':False,'native_execution_allowed_by_inventory':False}
    return result


def build(manifest_path,input_dir,output,stage_path,stage_sha):
    require(isinstance(STAGE_SHA256,str) and len(STAGE_SHA256)==64 and stage_sha==STAGE_SHA256,
        'reserved48 stage remains unready; no invented stage hash')
    stage=load(stage_path);require(sha(stage_path)==STAGE_SHA256 and stage.get('stage_id')==STAGE_ID and
        stage.get('status')=='prepared_not_executed' and stage.get('manifest_sha256')==MANIFEST_SHA256,'frozen reviewed stage differs')
    doc=derive(manifest_path,input_dir,stage_sha);raw=(json.dumps(doc,indent=2,allow_nan=False)+'\n').encode()
    require(len(raw)<=16*1024**2,'compact independent inventory exceeds16MiB')
    with Path(output).open('xb') as stream:stream.write(raw)
    return {'status':'independent_reserved48_inventory_created','path':str(output),'sha256':sha(output),'size_bytes':len(raw),'native_executions_started':0}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('manifest','input-dir','output','stage-spec'):p.add_argument('--'+n,type=Path,required=True)
    p.add_argument('--stage-spec-sha256',required=True);a=p.parse_args()
    print(json.dumps(build(a.manifest,a.input_dir,a.output,a.stage_spec,a.stage_spec_sha256),indent=2))

"""Offline inventory regressions; synthetic identity pins never activate native."""
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import reserved48_expected_v1 as expected
import reserved48_common_v1 as common

HERE = Path(__file__).resolve().parent


def write(path, doc):
    path.write_text(json.dumps(doc, indent=2) + '\n', encoding='utf-8')


def fixture(root):
    root = Path(root); descriptors = []
    for index in range(48):
        P = expected.BINS[index // 12]; sample = 'synthetic-%02d' % index
        doc = {'sample': sample, 'prompt': [2] + [3] * (P - 1), 'continuation': [4] * 32,
            'input_role': 'reserved_validation_not_for_policy_selection', 'source_partition': 'train_reserved_disjoint_articles',
            'independent_representative_example': True, 'normalized_article_sha256': '%064x' % (index + 1)}
        doc['prompt'][5] = 0  # Valid vocabulary token, never padding inferred from token ID.
        path = root / (sample + '.json'); write(path, doc)
        descriptors.append({'file': path.name, 'sample': sample, 'sha256': expected.sha(path), 'bytes': path.stat().st_size,
            'prompt_length_including_BOS': P, 'normalized_article_sha256': doc['normalized_article_sha256']})
    manifest = root / 'reserved.json'
    write(manifest, {'state': 'frozen_reserved_english_article_validation', 'requested_prompt_bins_including_BOS': expected.BINS,
        'requested_per_bin': 12, 'continuation_tokens': 32, 'samples': descriptors,
        'selection_on_model_outputs': False, 'source': {'official_validation_split': False}})
    return manifest


class ExpectedTests(unittest.TestCase):
    def test_actual_frozen48_complete_geometry(self):
        inputs = HERE.parent / 'inputs/reserved-articles-v1'
        doc = expected.derive(inputs / 'reserved.json', inputs)
        self.assertEqual(len(doc['samples']), 48)
        self.assertEqual(sum(len(s['all_target_positions']) for s in doc['samples']), 132048)
        self.assertEqual(sum(s['sequence_length'] for s in doc['samples']), 132096)
        self.assertEqual(sum(sum(m['native_calls'] for m in s['modes']) for s in doc['samples']), 3264)
        self.assertEqual(len(doc['pairs_per_input']), 9)
        self.assertEqual(doc['counts']['pairs_total'], 432)
        self.assertEqual(doc['counts']['distribution_pair_positions'], 432 * 47)
        for s in doc['samples']:
            self.assertEqual(len(s['distribution_positions']), 47)
            self.assertEqual(s['distribution_positions'][-1], s['sequence_length'] - 2)
            self.assertEqual(s['all_target_positions'][-1], s['sequence_length'] - 1)
            self.assertEqual([m['native_calls'] for m in s['modes']], [1, 33, 34])
            chunk = s['modes'][2]['input_spans_zero_based_half_open']
            self.assertEqual(chunk[:2], [[0, s['prompt_length'] // 2 - 1], [s['prompt_length'] // 2 - 1, s['prompt_length']]])
            self.assertEqual(chunk[-1], [s['sequence_length'] - 1, s['sequence_length']])

    def test_independent_collector_agrees_without_importing_builder(self):
        inputs = HERE.parent / 'inputs/reserved-articles-v1'
        common.check_expected(expected.derive(inputs / 'reserved.json', inputs), common.inventory(inputs / 'reserved.json', inputs), None)

    def test_valid_zero_and_all_lengths_are_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            manifest = fixture(tmp)
            with patch.object(expected, 'MANIFEST_SHA256', expected.sha(manifest)):
                doc = expected.derive(manifest, tmp)
            for sample in doc['samples']:
                self.assertEqual(sample['input_ids'][5], 0)
                self.assertEqual(sample['all_target_tokens'][4], 0)
                self.assertEqual(len(sample['input_ids']), sample['prompt_length'] + 32)
                self.assertTrue(all(m['attention_mask_rule'].startswith('ones[1,end]') for m in sample['modes']))

    def test_truncation_hash_mutation_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            manifest = fixture(tmp); path = Path(tmp) / 'synthetic-47.json'
            doc = expected.load(path); doc['prompt'].pop(); write(path, doc)
            with patch.object(expected, 'MANIFEST_SHA256', expected.sha(manifest)):
                with self.assertRaisesRegex(ValueError, 'bytes differ'): expected.derive(manifest, tmp)

    def test_duplicate_article_rejected_even_with_valid_file_hashes(self):
        with tempfile.TemporaryDirectory() as tmp:
            manifest = fixture(tmp); doc = expected.load(manifest)
            second = Path(tmp) / doc['samples'][1]['file']; item = expected.load(second)
            item['normalized_article_sha256'] = doc['samples'][0]['normalized_article_sha256']; write(second, item)
            doc['samples'][1].update(sha256=expected.sha(second), bytes=second.stat().st_size,
                                    normalized_article_sha256=item['normalized_article_sha256']); write(manifest, doc)
            with patch.object(expected, 'MANIFEST_SHA256', expected.sha(manifest)):
                with self.assertRaisesRegex(ValueError, 'distinct'): expected.derive(manifest, tmp)

    def test_shared_omission_or_wrong_last_prediction_is_rejected(self):
        inputs = HERE.parent / 'inputs/reserved-articles-v1'
        doc = expected.derive(inputs / 'reserved.json', inputs); rows = common.inventory(inputs / 'reserved.json', inputs)
        for field in ('all_target_positions', 'distribution_positions'):
            wrong = copy.deepcopy(doc); wrong['samples'][-1][field].pop()
            with self.assertRaises(ValueError): common.check_expected(wrong, rows, None)

    def test_omitted_mode_not_hidden_by_zip(self):
        inputs = HERE.parent / 'inputs/reserved-articles-v1'
        doc = expected.derive(inputs / 'reserved.json', inputs); rows = common.inventory(inputs / 'reserved.json', inputs)
        doc['samples'][0]['modes'].pop()
        with self.assertRaisesRegex(ValueError, 'mode inventory'): common.check_expected(doc, rows, None)

    def test_build_unready_before_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / 'not-created.json'
            with self.assertRaisesRegex(ValueError, 'unready'): expected.build('absent', 'absent', output, 'absent', '0' * 64)
            self.assertFalse(output.exists())


if __name__ == '__main__': unittest.main()

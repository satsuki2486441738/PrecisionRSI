"""Bounded I03 hash/transport export; no framework, model or numeric admission.

GPU exports copy its five raw BF16 logits, two native KV files and235 NPY rows. Only NPU may explicitly
retain those242 source arrays. Original absolute source-map keys and all raw
receipt bytes survive relocation. A successfully built archive must still pass
the independent I03 admission; this exporter cannot establish model acceptance.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import tarfile
import time

STAGE_SHA = '6e53e3cdf3e7fad8f56b43cb99a42bdb999ac074a5a40a3c1e7df72eeb504005'
EXPECTED_SHA = '5c8cdcc3c5b88732ccd589d95fa5ce86bd9eac71f83620e3bc48bcfc3b3b9a25'
MAX_TRANSPORT = 1536 * 1024 ** 2
MAX_LOGICAL = 1024 ** 3
PROOF_SHA = '2d26531b83af3a3f0acf63c9b8472ce547a5bd288de6f92cd390a38a6011d840'
MAX_TASK_BYTES = 4 * 1024 ** 3
MAX_SMALL = 16 * 1024 ** 2
MIN_FREE = 5 * 1024 ** 3
POSITIONS = sorted(set(i * 127 // 15 for i in range(16)) | set(range(127, 159)))
MODES = ['full-r1', 'full-r2', 'full-r3', 'token', 'chunk63-65']
LARGE_NAMES = {'modes/%s/%s' % (mode, name) for mode in MODES for name in
    ({'raw-native-logits.safetensors'} | {'dist-p%03d.npy' % p for p in POSITIONS})}
LARGE_NAMES |= {'modes/%s/final-native-kv.safetensors' % mode for mode in MODES[3:]}

def safe_relative(name):
    part = PurePosixPath(name)
    require(isinstance(name, str) and name and not part.is_absolute() and '\\' not in name and
        str(part) == name and all(p not in ('', '.', '..') for p in name.split('/')), 'unsafe artifact member')
    return name


def require(ok, message):
    if not ok:
        raise ValueError(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    def pairs(items):
        value = {}
        for key, item in items:
            require(key not in value, 'duplicate JSON key')
            value[key] = item
        return value
    def reject(value):
        raise ValueError('nonfinite JSON token: ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'),
                      object_pairs_hook=pairs, parse_constant=reject)


def put(path, value):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def regular(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'original regular file required: ' + str(path))
    return path


def digest(path, deadline):
    value = hashlib.sha256()
    with regular(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 ** 2), b''):
            require(time.monotonic() < deadline, 'export deadline reached')
            value.update(block)
    return value.hexdigest()


def tree_size(root):
    total = 0
    for path in Path(root).rglob('*'):
        require(not path.is_symlink(), 'task tree contains symlink')
        if path.is_file():
            total += path.stat().st_size
    return total


def flag(argv, name):
    require(isinstance(argv, list) and argv.count(name) == 1, 'unique literal argv flag required: ' + name)
    position = argv.index(name)
    require(position + 1 < len(argv), 'argv flag has no literal value')
    return argv[position + 1]


def export(outer_receipt, task_root, output, retain_arrays=False, timeout=900):
    require(os.name == 'posix' and timeout == 900, 'POSIX export with fixed900s bound required')
    started = time.monotonic()
    deadline = started + timeout
    root = Path(task_root).resolve(strict=True)
    outer_path = regular(outer_receipt).resolve()
    output = Path(output).resolve()
    require(outer_path.is_relative_to(root) and output.is_relative_to(root) and
            output.parent.is_dir() and not output.exists(), 'new export and original outer receipt must belong to explicit task root')
    require(not Path(task_root).is_symlink() and shutil.disk_usage(root).free >= MIN_FREE,
            'task root identity/free5GiB gate failed')
    require(tree_size(root) <= MAX_TASK_BYTES, 'existing task exceeds4GiB sampled budget')
    archive = output.with_name(output.name + '.tar.gz')
    require(not archive.exists(), 'archive must be new')
    outer = read(outer_path)
    backend = outer.get('backend')
    require(outer.get('task') == 'I03' and outer.get('status') == 'completed' and
            outer.get('returncode') == 0 and outer.get('timed_out') is False and
            backend in ('GPU', 'NPU') and outer.get('native_capture_count') == 1 and
            outer.get('native_forward_calls_total') == 70 and outer.get('model_loads') == 1,
            'completed one-capture I03 outer receipt required')
    require(not retain_arrays or backend == 'NPU', 'GPU arrays must be fully copied')
    require(outer['stage_spec_source_sha256'] == STAGE_SHA and
            outer['expected_inventory_source_sha256'] == EXPECTED_SHA and
            outer['i01_prerequisite_source_sha256'] == PROOF_SHA, 'frozen stage/expected identities differ')
    artifacts = Path(outer['output_dir'])
    require(artifacts.is_dir() and not artifacts.is_symlink() and
            artifacts.resolve().is_relative_to(root), 'new native output must belong to task')
    require(all(flag(outer['argv'], name) == value for name, value in {
        '--input': outer['input_path'], '--allocation-receipt': outer['allocation_path'],
        '--stage-spec': outer['stage_spec_source_path'], '--stage-spec-sha256': STAGE_SHA,
        '--expected-inventory': outer['expected_inventory_source_path'],
        '--expected-inventory-sha256': EXPECTED_SHA,
        '--i01-prerequisite': outer['i01_prerequisite_source_path'],
        '--i01-prerequisite-sha256': PROOF_SHA, '--output': str(artifacts)}.items()),
        'outer identity does not match original literal collector argv')
    command = read(outer['generic_receipt']['path'])
    require(Path(outer['generic_receipt']['path']).resolve().is_relative_to(root),
            'generic recorder run escapes new task')
    require(command.get('status') == 'completed' and command.get('returncode') == 0 and
            command.get('argv') == outer['argv'] and command.get('start') == outer['started_utc'] and
            command.get('timeout') == (1500 if backend == 'GPU' else 1800), 'generic receipt differs from I03 envelope')
    status = read(artifacts / 'status.json')
    manifest = read(artifacts / 'artifacts-manifest.json')
    require(status.get('status') == 'completed' and
            status.get('artifacts_manifest_sha256') == outer['artifacts_manifest_sha256'] and
            manifest.get('backend') == backend.lower() and manifest.get('stage_spec_sha256') == STAGE_SHA and
            manifest.get('expected_inventory_sha256') == EXPECTED_SHA and
            manifest.get('i01_prerequisite_sha256') == PROOF_SHA,
            'capture completion/manifest binding differs')
    require(all(not p.is_symlink() for p in artifacts.rglob('*')), 'artifact tree contains symlink')
    require({p.relative_to(artifacts).as_posix() for p in artifacts.rglob('*') if p.is_file()} == set(manifest['files']) |
            {'artifacts-manifest.json', 'status.json'}, 'artifact inventory is not exact')
    require({name for name in manifest['files'] if name.endswith(('.npy', '.safetensors'))} == LARGE_NAMES,
            'only exact new I03 five logits/two KV/235 NPY files may be exported')
    output.mkdir(mode=0o700)
    state = {'schema_version': 1, 'status': 'exporting', 'started_utc': utc(),
             'task': 'I03', 'backend': backend, 'native_executions_started': 0,
             'timeout_seconds': timeout, 'max_transport_bytes': MAX_TRANSPORT,
             'max_logical_transport_bytes': MAX_LOGICAL,
             'max_new_task_bytes_sampled': MAX_TASK_BYTES, 'acceptance': None,
             'numeric_admission': 'Not performed by this hash/transport exporter.'}
    catalog, aliases = {}, {}
    claim = outer_path.parent

    def add_alias_map(path, expected=None):
        path = regular(path)
        require(path.resolve().is_relative_to(root), 'frozen source map escapes explicit new task')
        if expected is not None:
            require(digest(path, deadline) == expected, 'frozen source map SHA differs')
        for original, ref in read(path).items():
            require(PurePosixPath(original).is_absolute() and isinstance(ref, dict) and
                    {'path', 'sha256'} <= set(ref), 'invalid original/frozen source mapping')
            actual = regular(ref['path'])
            require(actual.resolve().is_relative_to(root), 'frozen copy escapes task')
            normalized = {'path': str(actual), 'sha256': ref['sha256'],
                          'size_bytes': ref.get('size_bytes', actual.stat().st_size)}
            if original in aliases:
                require(aliases[original]['sha256'] == normalized['sha256'] and
                        aliases[original]['size_bytes'] == normalized['size_bytes'], 'conflicting frozen source aliases')
            aliases[original] = normalized

    def add(original, expected=None, size=None, role='evidence'):
        original = str(original)
        require(PurePosixPath(original).is_absolute() and '\\' not in original,
                'original source keys must be absolute POSIX paths')
        alias = aliases.get(original)
        actual = regular(alias['path'] if alias is not None else original)
        if alias is not None:
            require(expected is None or expected == alias['sha256'], 'reference disagrees with frozen copy SHA')
            expected = alias['sha256']
            require(alias['size_bytes'] == actual.stat().st_size, 'frozen copy size differs')
        original_path = Path(original)
        large = original_path.is_relative_to(artifacts) and original_path.relative_to(artifacts).as_posix() in LARGE_NAMES
        require(large or actual.stat().st_size <= MAX_SMALL, 'large model/environment/legacy array export prohibited')
        require(large or not actual.name.endswith(('.npy', '.safetensors', '.tar', '.gz', '.whl')),
                'only the new I03 artifact arrays may be large binary evidence')
        observed = digest(actual, deadline)
        require(expected is None or observed == expected, 'original/frozen evidence SHA differs: ' + original)
        require(size is None or actual.stat().st_size == size, 'evidence size differs')
        entry = {'actual': str(actual), 'sha256': observed, 'size': actual.stat().st_size, 'large': large}
        if original in catalog:
            require(all(catalog[original][k] == entry[k] for k in ('sha256', 'size', 'large')), 'duplicate source identity differs')
            catalog[original]['roles'].add(role)
        else:
            catalog[original] = dict(entry, roles={role})

    try:
        maps = ['frozen-source-map.json', 'frozen-bootstrap-map.json',
                'frozen-native-packages-map.json', 'frozen-runtime-source-map.json', 'frozen-runtime-map.json']
        for name in maps:
            path = claim / name
            if path.exists():
                add_alias_map(path)
        require('runtime_source_map_path' in outer, 'runtime implementation source map missing')
        add_alias_map(outer['runtime_source_map_path'], outer['runtime_source_map_sha256'])
        controller = read(claim / 'controller-receipt.json')
        require(controller.get('task') == 'I03' and controller.get('status') == 'completed' and
            controller.get('returncode') == 0 and controller.get('timed_out') is False and
            controller.get('remaining_descendants') == [], 'native lifecycle must be completed and cleaned')
        add(outer_path, role='outer_receipt')
        for path in sorted(claim.rglob('*')):
            require(not path.is_symlink(), 'claim evidence contains symlink')
            if path.is_file():
                add(path, role='claim_closure')
        require(set(outer['source_sha256']) == set(outer['dependency_paths']), 'outer source/dependency inventory differs')
        for original, expected in outer['source_sha256'].items():
            add(original, expected, role='outer_frozen_source')
        for path_key, sha_key in [('collector_path', 'collector_sha256'), ('input_path', 'input_sha256'),
                ('allocation_path', 'allocation_sha256'), ('expected_inventory_source_path', 'expected_inventory_source_sha256'),
                ('stage_spec_source_path', 'stage_spec_source_sha256'),
                ('i01_prerequisite_source_path', 'i01_prerequisite_source_sha256')]:
            add(outer[path_key], outer[sha_key], role=path_key)
        generic = outer['generic_receipt']
        add(generic['path'], generic['sha256'], role='original_generic_receipt')
        for name in ('stdout.bin', 'stderr.bin', 'execution.json'):
            path = Path(generic['path']).parent / name
            require(path.is_file(), 'generic log/profile missing')
            add(path, role='original_generic_log_or_profile')
        add(artifacts / 'artifacts-manifest.json', outer['artifacts_manifest_sha256'], role='artifact_manifest')
        add(artifacts / 'status.json', role='capture_status')
        for name, ref in manifest['files'].items():
            safe_relative(name)
            add(artifacts / name, ref['sha256'], ref['size_bytes'], role='native_capture_artifact')
        runtime = read(artifacts / 'runtime.json')
        refs = []
        def collect_refs(value):
            if isinstance(value, dict):
                if set(value) == {'path', 'sha256', 'size_bytes'}:
                    refs.append(value)
                for nested in value.values(): collect_refs(nested)
            elif isinstance(value, list):
                for nested in value: collect_refs(nested)
        collect_refs(runtime)
        for ref in refs:
            add(ref['path'], ref['sha256'], ref['size_bytes'], role='actual_runtime_source')
        require(sum(entry['size'] for entry in catalog.values() if not
            (retain_arrays and entry['large'])) <= MAX_LOGICAL,
            'actual copied evidence exceeds1GiB logical transport cap')
        files = {}
        for index, (original, entry) in enumerate(sorted(catalog.items())):
            require(time.monotonic() < deadline, 'export deadline reached')
            item = {'sha256': entry['sha256'], 'size': entry['size'], 'roles': sorted(entry['roles'])}
            if retain_arrays and entry['large']:
                item['retained_at_source'] = True
            else:
                relative = 'payload/%04d/%s' % (index, Path(original).name)
                destination = output / relative
                destination.parent.mkdir(parents=True)
                observed = hashlib.sha256()
                with Path(entry['actual']).open('rb') as source, destination.open('xb') as target:
                    for block in iter(lambda: source.read(4 * 1024 ** 2), b''):
                        require(time.monotonic() < deadline, 'export deadline reached')
                        target.write(block)
                        observed.update(block)
                require(observed.hexdigest() == entry['sha256'] and destination.stat().st_size == entry['size'],
                        'source changed while copying original bytes')
                item['path'] = relative
            files[original] = item
        for original, entry in catalog.items():
            require(digest(entry['actual'], deadline) == entry['sha256'], 'evidence changed before archive creation')
        require(sum(entry['large'] for entry in catalog.values()) == 242, 'exact242 I03 large source objects required')
        source_map = {'schema_version': 1, 'request': {'task': 'I03', 'backend': backend,
            'outer_receipt': str(outer_path)}, 'files': files, 'raw_bytes_preserved': True,
            'full_array_hashes_checked': 242, 'retained_array_count': 242 if retain_arrays else 0,
            'numeric_admission': 'Not performed; independent raw-BF16 admission is still required.', 'acceptance': None}
        put(output / 'source-map.json', source_map)
        state.update(status='payload_copied_and_rehashed', mapped_files=len(files),
            copied_files=sum('path' in x for x in files.values()),
            retained_arrays=242 if retain_arrays else 0,
            source_map_sha256=digest(output / 'source-map.json', deadline))
        put(output / 'export-summary.json', state)
        require(tree_size(root) <= MAX_TASK_BYTES, 'task capture+payload exceeds4GiB sampled budget')
        logical_bytes = tree_size(output)
        require(logical_bytes <= MAX_LOGICAL, 'actual logical payload exceeds1GiB transport cap')
        # Regular members only; no path rewriting inside original evidence.
        with archive.open('xb') as destination:
            with tarfile.open(fileobj=destination, mode='w:gz') as package:
                for path in sorted(output.rglob('*')):
                    if path.is_file():
                        require(time.monotonic() < deadline, 'archive deadline reached')
                        package.add(path, arcname=path.relative_to(output).as_posix(), recursive=False)
                        require(destination.tell() <= MAX_TRANSPORT, 'actual compressed archive exceeds1.5GiB transport cap')
        require(archive.stat().st_size <= MAX_TRANSPORT, 'actual compressed archive exceeds1.5GiB transport cap')
        require(tree_size(root) <= MAX_TASK_BYTES, 'task including archive exceeds4GiB sampled budget')
        require(tree_size(output) == logical_bytes and
            digest(output / 'source-map.json', deadline) == state['source_map_sha256'],
            'export metadata changed during archive creation')
        for original, item in files.items():
            path = output / item['path'] if 'path' in item else Path(catalog[original]['actual'])
            require(path.stat().st_size == item['size'] and digest(path, deadline) == item['sha256'],
                    'payload or retained source changed during archive creation')
        receipt = {'schema_version': 1, 'status': 'i03_transport_export_completed',
            'finished_utc': utc(), 'archive': str(archive), 'archive_bytes': archive.stat().st_size,
            'archive_sha256': digest(archive, deadline), 'source_map_sha256': state['source_map_sha256'],
            'logical_payload_bytes': logical_bytes, 'max_logical_transport_bytes': MAX_LOGICAL,
            'max_encoded_transport_bytes': MAX_TRANSPORT, 'transport_allowed_by_actual_size': True, 'retained_array_count': state['retained_arrays'],
            'model_acceptance': None, 'native_executions_started': 0}
        put(output.with_name(output.name + '-receipt.json'), receipt)
        return receipt
    except BaseException as exc:
        put(output.with_name(output.name + '-failure.json'), {'status': 'failed', 'finished_utc': utc(),
            'error_type': type(exc).__name__, 'error': str(exc), 'partial_payload_and_archive_preserved': True,
            'transport_allowed': False, 'automatic_retry': False})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--outer-receipt', type=Path, required=True)
    parser.add_argument('--task-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--retain-arrays', action='store_true')
    args = parser.parse_args()
    def expire(_signum, _frame):
        raise TimeoutError('I03 CPU exporter exceeded900 seconds')
    signal.signal(signal.SIGALRM, expire)
    signal.setitimer(signal.ITIMER_REAL, 900)
    try:
        result = export(args.outer_receipt, args.task_root, args.output, args.retain_arrays)
        print(json.dumps(result, allow_nan=False))
        return 0
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


if __name__ == '__main__':
    raise SystemExit(main())

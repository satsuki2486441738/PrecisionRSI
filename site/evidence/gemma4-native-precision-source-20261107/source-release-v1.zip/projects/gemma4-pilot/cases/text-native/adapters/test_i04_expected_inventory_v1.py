"""Independent CPU coordinate/causal-padding regressions; no native imports."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('independent_i04_expected',HERE/'i04_expected_inventory_v1.py')
tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)
CASE=HERE.parent
INPUT_A=CASE/'inputs/discovery-v1/wikitext2-discovery-001.json'
INPUT_B=CASE/'inputs/i04-prefix-stress-096-v1.json'
STAGE=CASE/'i04-stage-v1.json'


class Coordinates(unittest.TestCase):
    def setUp(self):
        self.a=tool.load(INPUT_A);self.b=tool.load(INPUT_B)

    def derive(self,a=None,b=None):
        return tool.derive(self.a if a is None else a,self.b if b is None else b,tool.INPUT_A_SHA256,tool.INPUT_B_SHA256,tool.STAGE_SHA256)

    def test_actual_independent_native_logical_and_byte_inventory(self):
        expected=self.derive();tool.stage_check(STAGE,tool.STAGE_SHA256,expected)
        self.assertEqual(expected['counts'],{'native_calls_per_backend':4,'logical_observations_per_backend':6,'targets_per_backend':762,
            'distribution_rows_per_backend':282,'physical_raw_rows_per_backend':896,'valid_raw_rows_per_backend':768,
            'pad_only_raw_rows_per_backend':128,'raw_tensor_files':4,'npy_files':282,'large_objects':286,'target_distribution_pairs':18,
            'native_raw_data_bytes':469762048,'fp64_row_data_bytes':591396864,'payload_data_bytes_excluding_headers':1061158912})
        self.assertEqual([m['raw_logits']['shape'] for m in expected['modes']],[[1,160,262144],[1,96,262144],[2,160,262144],[2,160,262144]])

    def test_left_and_right_masks_positions_targets_are_distinct_and_causal(self):
        expected=self.derive();left,right=expected['modes'][2:]
        self.assertEqual(left['attention_mask'][1],[0]*64+[1]*96)
        self.assertEqual(left['position_ids'][1],[0]*64+list(range(96)))
        self.assertEqual(right['attention_mask'][1],[1]*96+[0]*64)
        self.assertEqual(right['position_ids'][1],list(range(96))+[0]*64)
        l,r=left['observations'][1],right['observations'][1]
        self.assertEqual((l['physical_offset'],r['physical_offset']),(64,0))
        self.assertEqual((l['all_targets'][0]['physical_prediction_position'],l['all_targets'][-1]['physical_prediction_position']),(64,158))
        self.assertEqual((r['all_targets'][0]['physical_prediction_position'],r['all_targets'][-1]['physical_prediction_position']),(0,94))
        self.assertEqual(l['all_targets'][0]['token'],self.b['prompt'][1])
        self.assertEqual(l['distribution_positions'][0]['history'],[self.b['prompt'][0]])
        self.assertEqual(left['pad_only_rows'],[{'slot':1,'physical_position':i} for i in range(64)])
        self.assertEqual(right['pad_only_rows'],[{'slot':1,'physical_position':i} for i in range(96,160)])

    def test_valid_ID0_is_preserved_and_never_used_as_a_padding_predicate(self):
        # Semantic-only synthetic edit, never used by build or presented as native evidence.
        a,b=copy.deepcopy(self.a),copy.deepcopy(self.b);a['prompt'][1]=b['prompt'][1]=0
        expected=self.derive(a,b)
        for mode in expected['modes']:
            for observation in mode['observations']:
                slot,offset=observation['slot'],observation['physical_offset']
                self.assertEqual(mode['input_ids'][slot][offset+1],0)
                self.assertEqual(mode['attention_mask'][slot][offset+1],1)
                self.assertEqual(mode['position_ids'][slot][offset+1],1)
                self.assertEqual(observation['all_targets'][0]['token'],0)

    def test_exact47_samples_per_observation_and18_no_cross_request_pairs(self):
        expected=self.derive();pairs=expected['comparison_pairs']
        self.assertEqual(len(pairs),18);self.assertEqual(sum(p['kind']=='cross_backend_matched' for p in pairs),6)
        memberships={(m['id'],o['request']) for m in expected['modes'] for o in m['observations']}
        for pair in pairs:
            self.assertIn((pair['left']['mode'],pair['request']),memberships)
            self.assertIn((pair['right']['mode'],pair['request']),memberships)
        for request,last,prompt_end in [('A',158,127),('B',94,63)]:
            selected=expected['sampling'][request]['deduplicated_predictors']
            self.assertEqual((len(selected),selected[-1],selected.count(prompt_end)),(47,last,1))
        self.assertEqual([t['position'] for t in expected['requests']['B']['all_targets']],list(range(1,96)))

    def test_bad_prefix_boolean_or_out_of_vocab_input_rejected(self):
        for change in ('prefix','bool','negative','too_big','independent'):
            a,b=copy.deepcopy(self.a),copy.deepcopy(self.b)
            if change=='prefix':b['continuation'][0]+=1
            elif change=='bool':a['prompt'][0]=True
            elif change=='negative':a['prompt'][0]=-1
            elif change=='too_big':a['prompt'][0]=262144
            else:b['independent_representative_example']=True
            with self.assertRaises(ValueError):self.derive(a,b)

    def test_exclusive_build_exact_bytes_and_tamper_rejection(self):
        with tempfile.TemporaryDirectory() as temporary:
            output=Path(temporary)/'inventory.json';result=tool.build(INPUT_A,INPUT_B,output,STAGE,tool.STAGE_SHA256)
            self.assertEqual(result['sha256'],hashlib.sha256(output.read_bytes()).hexdigest())
            self.assertEqual(tool.verify(output,INPUT_A,INPUT_B,STAGE),self.derive())
            with self.assertRaises(ValueError):tool.build(INPUT_A,INPUT_B,output,STAGE,tool.STAGE_SHA256)
            for section in ('target','slot','pad','position'):
                changed=self.derive()
                if section=='target':changed['modes'][2]['observations'][1]['all_targets'][0]['physical_prediction_position']=0
                elif section=='slot':changed['modes'][2]['observations'][1]['slot']=0
                elif section=='pad':changed['modes'][3]['attention_mask'][1][-1]=1
                else:changed['modes'][2]['position_ids'][1][64]=64
                output.write_text(json.dumps(changed))
                with self.assertRaisesRegex(ValueError,'inventory differs'):tool.verify(output,INPUT_A,INPUT_B,STAGE)

    def test_raw_file_changes_and_duplicate_or_nonfinite_JSON_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            bad=Path(temporary)/'changed.json';bad.write_bytes(INPUT_B.read_bytes()+b' ')
            with self.assertRaisesRegex(ValueError,'SHA differs'):tool.build(INPUT_A,bad,Path(temporary)/'out.json',STAGE,tool.STAGE_SHA256)
        for raw in ('{"sample":"a","sample":"b"}','{"x":NaN}'):
            with self.assertRaises(ValueError):tool.parse(raw)

    def test_no_collector_framework_imports(self):
        tree=ast.parse((HERE/'i04_expected_inventory_v1.py').read_text())
        modules=[n.module for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)]+[a.name for n in ast.walk(tree) if isinstance(n,ast.Import) for a in n.names]
        self.assertEqual(set(modules),{'argparse','hashlib','itertools','json','pathlib'})
        self.assertFalse(any(name in sys.modules for name in ('torch','torch_npu','numpy','i04_common_v1')))


if __name__=='__main__':unittest.main()

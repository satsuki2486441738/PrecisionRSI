"""Offline collector regressions; fake tensors are not native Torch evidence.

The separately pinned probe_observer_cpu_v1.py must run on actual Torch2.9 CPU
before any new observer native attempt. This file deliberately imports no Torch.
"""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import observer_collectors_v1 as c


class Tensor:
    def __init__(self,values=None,shape=(1,4,8),dtype='torch.bfloat16',device='cpu'):
        self.values=list(range(32)) if values is None else list(values)
        self.shape=list(shape);self.dtype=dtype;self.device=device;self.layout='torch.strided'
    def stride(self):return (self.shape[1]*self.shape[2],self.shape[2],1)
    def detach(self):return self
    def contiguous(self):return self
    def clone(self):return Tensor(self.values,self.shape,self.dtype,self.device)
    def index_select(self,axis,indices):
        require=unittest.TestCase().assertEqual;require(self.shape[0],1)
        if axis==1:
            width=self.shape[2];values=[v for i in indices for v in self.values[i*width:(i+1)*width]];shape=[1,len(indices),width]
        elif axis==2:
            width=self.shape[2];values=[self.values[r*width+i] for r in range(self.shape[1]) for i in indices];shape=[1,self.shape[1],len(indices)]
        else:raise AssertionError('fake selector axis')
        return Tensor(values,shape,self.dtype,self.device)


class FakeTorch:
    Tensor=Tensor;long='torch.int64'
    @staticmethod
    def tensor(indices,**_):return list(indices)


class Handle:
    next_id=0
    def __init__(self,module,kind,callback):
        self.module,self.kind=module,kind;self.id=Handle.next_id;Handle.next_id+=1
        getattr(module,kind)[self.id]=callback
    def remove(self):
        for name in ('_forward_pre_hooks','_forward_pre_hooks_with_kwargs','_forward_hooks','_forward_hooks_with_kwargs','_forward_hooks_always_called'):
            getattr(self.module,name).pop(self.id,None)


class Module:
    def __init__(self,forward=None,children=None):
        for name in ('_forward_pre_hooks','_forward_pre_hooks_with_kwargs','_forward_hooks','_forward_hooks_with_kwargs','_forward_hooks_always_called'):setattr(self,name,{})
        self.forward=forward or (lambda value:value);self.children=children or {}
    def register_forward_pre_hook(self,callback,with_kwargs=False):
        handle=Handle(self,'_forward_pre_hooks',callback)
        if with_kwargs:self._forward_pre_hooks_with_kwargs[handle.id]=True
        return handle
    def register_forward_hook(self,callback,with_kwargs=False,always_call=False):
        handle=Handle(self,'_forward_hooks',callback)
        if with_kwargs:self._forward_hooks_with_kwargs[handle.id]=True
        if always_call:self._forward_hooks_always_called[handle.id]=True
        return handle
    def named_modules(self,remove_duplicate=False):
        yield '',self
        for name,module in self.children.items():yield name,module
    def __call__(self,*args,**kwargs):
        result=None
        try:
            for callback in list(self._forward_pre_hooks.values()):callback(self,args,kwargs)
            result=self.forward(*args,**kwargs)
        except BaseException:
            for key,callback in list(self._forward_hooks.items()):
                if key in self._forward_hooks_always_called:callback(self,args,kwargs,None)
            raise
        for callback in list(self._forward_hooks.values()):callback(self,args,kwargs,result)
        return result


def fixture():
    def block(value):value.values[:]=[x+10 for x in value.values];return value
    embedding=Module(lambda x:x.clone());middle=Module(block);norm=Module(lambda x:x)
    modules={'embedding':embedding,'block':middle,'norm':norm,'unused':Module()}
    model=Module(lambda x:norm(middle(embedding(x))),modules)
    specs=c.boundary_specs(1,prefix='block',embedding='embedding',norm='norm');specs[1]['module']=specs[2]['module']='block'
    return model,dict(specs=specs,tokens=[0,3],channels=[0,7],hidden_shape=(1,4,8))


def observer(model,config,**kwargs):return c.Observer(model,FakeTorch,'cpu',**{**config,**kwargs})


class Contract(unittest.TestCase):
    def test_production98_unique_boundaries47tokens64channels_and_payload(self):
        specs=c.boundary_specs();self.assertEqual(len(specs),98)
        self.assertEqual(len({x['id'] for x in specs}),98);self.assertEqual(len(c.TOKENS),47);self.assertEqual(len(c.CHANNELS),64)
        self.assertEqual((c.TOKENS[0],c.TOKENS[-1],c.CHANNELS[0],c.CHANNELS[-1]),(0,158,0,3839))
        self.assertEqual(4*160*262144*2+4*47*262144*8+2*98*47*64*2,730988032)

    def test_boundary_clone_survives_inplace_and_census_preserves_existing_hooks(self):
        model,config=fixture();calls=[];external=model.children['block'].register_forward_hook(lambda *x:calls.append('external'))
        before=c.hook_registry(list(model.named_modules()));value=Tensor();original=list(value.values)
        o=observer(model,config)
        with o:result=model(value)
        report=o.report(False);self.assertEqual(result.values,[x+10 for x in original]);self.assertEqual(value.values,original)
        self.assertEqual(o.samples['embedding.scaled.output'].values,[0,7,24,31]);self.assertEqual(o.samples['block.00.input'].values,[0,7,24,31])
        self.assertEqual(o.samples['block.00.output'].values,[10,17,34,41]);self.assertIsNot(o.samples['embedding.scaled.output'],o.samples['block.00.input'])
        self.assertEqual(report['zero_fired_modules'],['unused']);self.assertEqual(report['actual_module_count'],5)
        self.assertEqual(report['total_module_invocations'],4);self.assertEqual(calls,['external'])
        self.assertEqual(c.hook_registry(list(model.named_modules())),before);external.remove()

    def test_original_module_exception_preserved_and_owned_hooks_removed(self):
        model,config=fixture();before=c.hook_registry(list(model.named_modules()))
        def broken(_):raise RuntimeError('fixture original failure')
        model.children['block'].forward=broken;o=observer(model,config)
        with self.assertRaisesRegex(RuntimeError,'fixture original failure'):
            with o:model(Tensor())
        self.assertEqual(o.status,'incomplete');self.assertEqual(o.scope,[]);self.assertEqual(c.hook_registry(list(model.named_modules())),before)

    def test_duplicate_boundary_call_fails_and_restores_hooks(self):
        model,config=fixture();embedding=model.children['embedding'];model.forward=lambda x:embedding(embedding(x));o=observer(model,config)
        with self.assertRaisesRegex(ValueError,'more than once'):
            with o:model(Tensor())
        self.assertEqual(o.status,'incomplete');self.assertTrue(o.before_registry==o.after_registry)

    def test_missing_boundary_and_wrong_shape_fail_closed(self):
        for malformed in ('missing','shape','dtype'):
            model,config=fixture();o=observer(model,config);value=Tensor()
            if malformed=='missing':model.forward=lambda x:model.children['embedding'](x)
            elif malformed=='shape':value.shape=[1,2,16]
            else:value.dtype='torch.float32'
            with self.assertRaises(ValueError):
                with o:model(value)
            self.assertEqual(o.status,'incomplete');self.assertTrue(o.before_registry==o.after_registry)

    def test_shared_module_alias_and_invalid_selection_refused_before_install(self):
        model,config=fixture();model.children['alias']=model.children['block']
        with self.assertRaisesRegex(ValueError,'aliases'):observer(model,config)
        model,config=fixture()
        for key,value in [('tokens',[0,0]),('channels',[8]),('tokens',[])]:
            with self.assertRaises(ValueError):observer(model,config,**{key:value})

    def test_module_registry_changed_by_foreign_code_is_not_falsely_restored(self):
        model,config=fixture();o=observer(model,config)
        with self.assertRaisesRegex(ValueError,'registries'):
            with o:
                model(Tensor());model.register_forward_hook(lambda *_:None)
        self.assertFalse(o.before_registry==o.after_registry)

    def test_dispatch_forwards_original_operation_once_and_records_metadata_not_values(self):
        model,config=fixture();o=observer(model,config);value=Tensor();calls=[]
        class Function:
            _schema='aten::example(Tensor x, int scalar) -> Tensor'
            def __str__(self):return 'aten.example.default'
            def __call__(self,*args,**kwargs):calls.append((args,kwargs));return args[0]
        result=o.dispatch(Function(),(value,37),{'flag':True})
        self.assertIs(result,value);self.assertEqual(len(calls),1);self.assertIs(calls[0][0][0],value);self.assertEqual(calls[0][0][1],37)
        item=list(o.signatures.values())[0];self.assertEqual(item['inputs']['items'][0]['shape'],[1,4,8])
        self.assertEqual(item['inputs']['items'][1],{'python_type':'builtins.int'});self.assertNotIn('37',c.canonical(item))
        self.assertEqual(item['count'],1);self.assertEqual(o.dispatch_calls,1)

    def test_guard_excludes_by_scope_not_operator_name_and_unwinds_on_exception(self):
        model,config=fixture();o=observer(model,config)
        class Function:
            _schema='clone';calls=0
            def __str__(self):return 'aten.clone.default'
            def __call__(self,value):self.calls+=1;return value.clone()
        func=Function();value=Tensor();o.dispatch(func,(value,),{})
        with o.collector_guard():
            with o.collector_guard():o.dispatch(func,(value,),{})
        self.assertEqual((func.calls,o.dispatch_calls,o.excluded_calls['aten.clone.default'],o.guard_depth),(2,1,1,0))
        with self.assertRaisesRegex(RuntimeError,'guard failure'):
            with o.collector_guard():raise RuntimeError('guard failure')
        self.assertEqual(o.guard_depth,0)

    def test_dispatch_operation_failure_propagates_once(self):
        model,config=fixture();o=observer(model,config)
        class Function:
            _schema='broken';calls=0
            def __str__(self):return 'aten.broken.default'
            def __call__(self,*_):self.calls+=1;raise RuntimeError('original dispatch failure')
        func=Function()
        with self.assertRaisesRegex(RuntimeError,'original dispatch failure'):o.dispatch(func,(Tensor(),),{})
        self.assertEqual(func.calls,1);self.assertEqual(len(o.signatures),0)

    def test_dispatch_caps_fail_without_truncation_or_retry(self):
        class Function:
            _schema='tiny'
            def __str__(self):return 'aten.tiny.default'
            def __call__(self,value):return value
        for kwargs in ({'max_calls':0},{'max_signatures':0},{'max_bytes':1}):
            model,config=fixture();o=observer(model,config,**kwargs)
            with self.assertRaisesRegex(ValueError,'cap'):o.dispatch(Function(),(Tensor(),),{})
            self.assertLessEqual(len(o.signatures),0)

    def test_metadata_depth_and_unsupported_boundary_container_are_explicit(self):
        nested=Tensor()
        for _ in range(14):nested=[nested]
        with self.assertRaisesRegex(ValueError,'nesting'):c.tensor_tree(nested,FakeTorch)
        with self.assertRaisesRegex(ValueError,'no guessed'):c.selected_tensor(SimpleNamespace(hidden_states=Tensor()),FakeTorch)
        with self.assertRaisesRegex(ValueError,'one explicit'):c.selected_tensor({'hidden_states':Tensor(),'last_hidden_state':Tensor()},FakeTorch)
        class OddStride(Tensor):
            def stride(self):raise RuntimeError('unsupported native stride')
        item=c.tensor_metadata(OddStride());self.assertIsNone(item['stride']);self.assertEqual(item['stride_gap']['error_type'],'RuntimeError')

    def test_other_python_thread_refused_and_observer_is_single_use(self):
        model,config=fixture();o=observer(model,config);o.owner=threading.get_ident()+1
        with self.assertRaisesRegex(ValueError,'concurrent'):o.pre('',model,(Tensor(),),{})
        o=observer(model,config)
        with o:model(Tensor())
        with self.assertRaisesRegex(ValueError,'single use'):o.__enter__()

    def test_probe_module_import_is_framework_free(self):
        path=Path(__file__).resolve().parents[1]/'transfer/probe_observer_cpu_v1.py'
        program="import importlib.util,sys; s=importlib.util.spec_from_file_location('probe',sys.argv[1]); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); assert not any(n in sys.modules for n in ('torch','numpy','torch_npu','transformers'))"
        result=subprocess.run([sys.executable,'-S','-B','-c',program,str(path)],capture_output=True,text=True,timeout=10)
        self.assertEqual(result.returncode,0,result.stderr)


if __name__=='__main__':unittest.main()

"""CPU-only I04 gates, permanent claims, source packaging and owned cleanup."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


job = load('i04_lifecycle_under_test', 'h100_i04_lifecycle_v1.py')
ops = load('i04_operations_under_test', 'h100_i04_operations_v1.py')


class Gates(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.fixed, self.new = {}, {}
        for relative in job.FIXED:
            path = self.root / 'source' / relative; path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes((HERE / 'npu_three_repeat_launcher_v4.py').read_bytes() if relative == job.CLEANUP else b'{}\n')
            self.fixed[relative] = job.sha(path)
        helper = ('import json\nfrom pathlib import Path\n'
            'def prerequisite(path,digest):\n'
            ' d=json.loads(Path(path).read_text())\n'
            ' if d.get("verified") is not True:raise ValueError("synthetic CPU protocol proof not admitted")\n'
            ' return {"document":d,"refs":{},"prerequisite_sha256":digest,"native_executions_started":0}\n')
        for relative in job.NEW_PINS:
            path = self.root / 'source' / relative; path.parent.mkdir(parents=True, exist_ok=True)
            raw = helper if relative in (job.PREREQUISITE, job.CPU_PREREQUISITE) else (
                "def derive(*args):return {'CPU_protocol_fixture':True}\ndef stage_check(*args):return {}\n"
                if relative == job.EXPECTED else '# synthetic CPU fixture; never execute as a collector\n')
            path.write_text(raw, encoding='utf-8'); self.new[relative] = job.sha(path)
        self.proofs = {}
        for prefix, count in [('i03', 8), ('cpu', 21)]:
            folder = self.root / ('prerequisite-' + prefix); (folder / 'proof').mkdir(parents=True)
            refs = {}
            for index in range(count):
                target = folder / 'proof' / ('fixture-%02d.json' % index)
                target.write_text('{"synthetic_CPU_protocol_fixture":true}\n', encoding='utf-8')
                refs[str(index)] = {'path': 'proof/' + target.name,
                    'source_path': '/synthetic-original-' + prefix + '/' + target.name, 'sha256': job.sha(target)}
            path = folder / 'prerequisite.json'; job.put(path, {'verified': True, 'refs': refs}); self.proofs[prefix] = path
        raw = (json.dumps({'CPU_protocol_fixture': True}, indent=2) + '\n').encode()
        (self.root / 'expected-inventory.json').write_bytes(raw)
        for name in (job.ENTRY, job.LIFECYCLE, job.OPERATIONS):
            (self.root / name).write_bytes(b'# synthetic CPU fixture, never execute\n')
        self.patches = [patch.dict(job.FIXED, self.fixed, clear=True), patch.dict(job.NEW_PINS, self.new, clear=True),
            patch.object(job, 'I03_PROOF_SHA', job.sha(self.proofs['i03'])),
            patch.object(job, 'CPU_PROOF_SHA', job.sha(self.proofs['cpu'])),
            patch.object(job, 'EXPECTED_JSON_SHA', hashlib.sha256(raw).hexdigest()),
            patch.object(job, 'EXPECTED_JSON_BYTES', len(raw))]
        for item in self.patches:
            item.start(); self.addCleanup(item.stop)
        self.source = {'schema_version': 1, 'task_id': job.TASK_ID, 'allocation_id': 'app-new-i04-cpu-fixture',
            'vendor': 'NVIDIA', 'visible_count': 1, 'observed_utc': '2026-11-07T00:00:00+00:00',
            'evidence_source': 'Synthetic CPU protocol fixture; not an actual platform app',
            'source_pins': {**self.fixed, **self.new}, 'expected_inventory_sha256': job.EXPECTED_JSON_SHA,
            'i03_prerequisite_path': str(self.proofs['i03']), 'i03_prerequisite_sha256': job.I03_PROOF_SHA,
            'cpu_prerequisite_path': str(self.proofs['cpu']), 'cpu_prerequisite_sha256': job.CPU_PROOF_SHA}
        for label, name in [('entry', job.ENTRY), ('lifecycle', job.LIFECYCLE), ('operations', job.OPERATIONS)]:
            self.source[label + '_path'] = str(self.root / name); self.source[label + '_sha256'] = job.sha(self.root / name)
        self.seal()

    def seal(self):
        manifest = {'schema_version': 1, 'task_id': job.TASK_ID, 'files': {}}
        for path in self.root.rglob('*'):
            if not path.is_file() or path.name in (job.MANIFEST, job.SOURCE): continue
            relative = path.relative_to(self.root).as_posix()
            manifest['files'][relative] = {'sha256': job.sha(path), 'size_bytes': path.stat().st_size,
                'kind': 'metadata' if relative.startswith('prerequisite-') or relative == 'expected-inventory.json' else 'code'}
        target = self.root / job.MANIFEST
        if target.exists(): target.unlink()
        job.put(target, manifest); self.source['source_manifest_sha256'] = job.sha(target)

    def source_file(self):
        job.put(self.root / job.SOURCE, self.source)

    def query(self, *_args, **_kwargs):
        return subprocess.CompletedProcess([], 0,
            b'GPU-REDACTED_DEVICE_UUID, NVIDIA H100 80GB HBM3, 580.95.05\n', b'')

    def test_actual_frozen_stage_bounds(self):
        stage = job.read(HERE.parent / 'i04-stage-v1.json'); limits = stage['limits']
        self.assertEqual(job.sha(HERE.parent / 'i04-stage-v1.json'), job.SPEC_SHA)
        self.assertEqual(stage['total_forward_calls_per_backend'], 4)
        for constant, key in [(job.CAPTURE_SECONDS, 'gpu_capture_timeout_seconds'),
                (job.MAX_SECONDS, 'whole_attempt_timeout_seconds_per_backend'),
                (job.MAX_CAPTURE_BYTES, 'maximum_capture_product_bytes_per_backend'),
                (job.MAX_TASK_BYTES, 'maximum_new_task_storage_bytes_per_backend'),
                (job.MIN_FREE, 'minimum_free_source_storage_bytes'),
                (job.LOGICAL_TRANSPORT, 'maximum_logical_artifact_transport_bytes_per_direction'),
                (job.ENCODED_TRANSPORT, 'maximum_encoded_transport_bytes_per_direction')]:
            self.assertEqual(constant, limits[key])

    def test_old_apps_and_unready_proof_rejected_without_claim(self):
        for old in ('REDACTED_APP_ID', 'REDACTED_APP_ID', 'REDACTED_APP_ID', 'REDACTED_APP_ID'):
            with self.assertRaises(ValueError): job.validate_source({**self.source, 'allocation_id': old}, self.root)
        with patch.object(job, 'CPU_PROOF_SHA', None), self.assertRaisesRegex(ValueError, 'unready'):
            job.validate_source(self.source, self.root)
        with patch.dict(job.NEW_PINS, {job.CPU_PREREQUISITE: None}), self.assertRaisesRegex(ValueError, 'unready'):
            job.validate_source(self.source, self.root)
        self.assertFalse((self.root / 'claims').exists())

    def test_failed_actual_cpu_proof_blocks_claim_driver_restore(self):
        path = self.proofs['cpu']; doc = job.read(path); doc['verified'] = False
        path.unlink(); job.put(path, doc)
        self.source['cpu_prerequisite_sha256'] = job.sha(path); self.seal(); self.source_file()
        with patch.object(job, 'CPU_PROOF_SHA', job.sha(path)), patch.object(job.sys, 'platform', 'linux'):
            with self.assertRaisesRegex(ValueError, 'not admitted'):
                job.launch(self.root, lambda *_a, **_k: self.fail('driver query before CPU proof'), lambda *_a: self.fail('restore/model before CPU proof'))
        self.assertFalse((self.root / 'claims').exists())

    def test_mutated_earlier_prerequisite_blocks_all_native(self):
        target = next((self.proofs['i03'].parent / 'proof').iterdir()); target.write_bytes(b'mutation')
        self.source_file()
        with patch.object(job.sys, 'platform', 'linux'), self.assertRaises(ValueError):
            job.launch(self.root, lambda *_a, **_k: self.fail('driver before frozen I03 proof'), lambda *_a: self.fail('worker started'))
        self.assertFalse((self.root / 'claims').exists())

    def test_both_portable_proofs_freeze_all_raw_original_aliases(self):
        _, first, aliases = job.prerequisite(self.source, self.root)
        _, second, cpu_aliases = job.cpu_prerequisite(self.source, self.root)
        self.assertEqual((len(first), len(aliases), len(second), len(cpu_aliases)), (9, 8, 22, 21))
        self.assertTrue(all(key.startswith('/synthetic-original-') for key in [*aliases, *cpu_aliases]))

    def test_independent_inventory_does_not_need_common_or_torch(self):
        observed = job.independent_expected(self.source, self.root)
        self.assertEqual(observed['sha256'], job.EXPECTED_JSON_SHA)
        self.assertFalse(any(name in sys.modules for name in ('torch', 'torch_npu', 'numpy')))

    def test_strict_json_and_metadata_size_class(self):
        path = self.root / 'duplicate.json'; path.write_text('{"x":1,"x":2}')
        with self.assertRaises(ValueError): job.read(path)
        path.unlink()
        target = self.root / 'oversize-metadata.json'; target.write_bytes(b' ' * (1024 ** 2 + 1000))
        self.seal(); manifest = job.read(self.root / job.MANIFEST)
        manifest['files'][target.name]['kind'] = 'metadata'
        (self.root / job.MANIFEST).unlink(); job.put(self.root / job.MANIFEST, manifest)
        job.manifest_files(self.root, job.sha(self.root / job.MANIFEST))
        manifest['files'][target.name]['kind'] = 'code'
        (self.root / job.MANIFEST).unlink(); job.put(self.root / job.MANIFEST, manifest)
        with self.assertRaisesRegex(ValueError, 'small original'): job.manifest_files(self.root, job.sha(self.root / job.MANIFEST))

    def test_concurrent_permanent_claims_only_one_winner(self):
        (self.root / 'claims').mkdir()
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda _: job.claim_once(self.root, 'app-cpu-fixture', {'synthetic': True}), range(16)))
        self.assertEqual(sum(x is not None for x in results), 1)

    def test_failed_driver_never_retries_and_claim_survives(self):
        self.source_file()
        def fail(*_a, **_k): return subprocess.CompletedProcess([], 1, b'', b'synthetic driver failure')
        with patch.object(job.sys, 'platform', 'linux'):
            self.assertEqual(job.launch(self.root, fail, lambda *_a: self.fail('worker after bad driver')), 1)
            self.assertEqual(job.launch(self.root, lambda *_a, **_k: self.fail('second query'), lambda *_a: self.fail('second worker')), 0)
        self.assertTrue((self.root / 'claims' / self.source['allocation_id'] / 'launch-failure.json').is_file())

    def test_valid_stub_uses_only_new_worker_and_bounds(self):
        self.source_file(); calls = []
        def run(argv, directory, root, deadline, helper):
            calls.append(argv); self.assertEqual(root, self.root)
            self.assertLessEqual(deadline - time.monotonic(), 3000)
            self.assertEqual(argv[-2], '--worker'); self.assertEqual(Path(argv[-3]).name, job.LIFECYCLE)
            return 0, {'status': 'completed'}
        with patch.object(job.sys, 'platform', 'linux'):
            self.assertEqual(job.launch(self.root, self.query, run), 0)
        self.assertEqual(len(calls), 1)

    @unittest.skipUnless(os.name == 'posix', 'POSIX symlink validation')
    def test_symlink_proof_is_not_admitted(self):
        original = self.proofs['cpu'].parent / 'proof/fixture-00.json'; moved = original.with_name('other.json')
        original.rename(moved); original.symlink_to(moved)
        with self.assertRaises(ValueError): job.cpu_prerequisite(self.source, self.root)


class Operations(unittest.TestCase):
    def test_unready_actual_cpu_proof_prevents_package_creation(self):
        actual = ops.module(HERE / job.LIFECYCLE)
        self.assertEqual(actual.CPU_PROOF_SHA, '8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec')
        with patch.object(actual,'CPU_PROOF_SHA',None), self.assertRaisesRegex(ValueError, 'unready'): ops.ready(actual)

    def test_unsafe_archive_paths_and_duplicate_json(self):
        for name in ('/etc/passwd', '../old/claim', 'x/../y', 'x\\y', 'x//y', './x'):
            with self.assertRaises(ValueError): ops.safe(name)
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp) / 'duplicate.json'; p.write_text('{"path":1,"path":2}')
            with self.assertRaises(ValueError): ops.read(p)

    def test_generated_shell_pins_only_new_lifecycle(self):
        raw = ops.shell_bytes(job, 'a' * 64)
        self.assertIn(job.LIFECYCLE.encode(), raw); self.assertIn(b'a' * 64, raw)
        self.assertIn(b'TORCH_DEVICE_BACKEND_AUTOLOAD=0', raw)
        self.assertNotIn(b'sleep', raw); self.assertNotIn(b'nvidia-smi', raw)
        self.assertNotIn(b'h100_i03_lifecycle', raw)

    def test_capture_argv_binds_both_requests_and_actual_i03_proof(self):
        source = {'expected_inventory_sha256': 'a' * 64, 'i03_prerequisite_path': '/synthetic/new/prerequisite.json',
            'i03_prerequisite_sha256': 'b' * 64}
        argv = job.capture_argv('/synthetic/python', '/synthetic/source', '/synthetic/claim', '/synthetic/run', source)
        flags = [item for item in argv if item.startswith('--')]
        self.assertEqual(len(flags), len(set(flags)))
        self.assertEqual(argv[argv.index('--input-b') + 1], str(Path('/synthetic/source') / job.INPUT_B))
        self.assertEqual(argv[argv.index('--i03-prerequisite-sha256') + 1], 'b' * 64)
        self.assertEqual(argv[argv.index('--device') + 1], 'cuda:0')
        self.assertNotIn('--cpu-prerequisite', argv)  # Launcher gate, never an unsupported collector flag.

    def stage_fixture(self, corruption=None):
        tmp = tempfile.TemporaryDirectory(); self.addCleanup(tmp.cleanup); base = Path(tmp.name).resolve()
        fake = SimpleNamespace(TASK=base, TASK_ID=job.TASK_ID, MANIFEST=job.MANIFEST,
            CPU_PROOF_SHA='a' * 64, NEW_PINS={'synthetic-helper': 'b' * 64}, HEX=job.HEX, MIN_FREE=1)
        payload = {job.LIFECYCLE: (HERE / job.LIFECYCLE).read_bytes(),
            job.OPERATIONS: (HERE / job.OPERATIONS).read_bytes(), 'expected-inventory.json': b' ' * 1082939}
        if corruption == 'ancestor_collision': payload.update({'collision': b'x', 'collision/child': b'y'})
        manifest = {'schema_version': 1, 'task_id': job.TASK_ID, 'cpu_prerequisite_sha256': fake.CPU_PROOF_SHA,
            'files': {name: {'kind': 'metadata' if name == 'expected-inventory.json' else 'code',
                'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw)} for name, raw in payload.items()}}
        if corruption == 'codecap': manifest['files']['expected-inventory.json']['kind'] = 'code'
        raw = (json.dumps(manifest, indent=2) + '\n').encode(); payload[job.MANIFEST] = raw
        archive = base / 'synthetic-package.tar'
        with tarfile.open(archive, 'w', format=tarfile.USTAR_FORMAT) as package:
            for relative, data in payload.items():
                info = tarfile.TarInfo(ops.NAME + '/' + relative); info.size = len(data)
                package.addfile(info, io.BytesIO(data))
            if corruption == 'duplicate':
                info = tarfile.TarInfo(ops.NAME + '/' + job.MANIFEST); info.size = len(raw); package.addfile(info, io.BytesIO(raw))
            elif corruption in ('traversal', 'symlink', 'hardlink'):
                info = tarfile.TarInfo(ops.NAME + '/../escape' if corruption == 'traversal' else ops.NAME + '/link')
                if corruption in ('symlink', 'hardlink'):
                    info.type = tarfile.SYMTYPE if corruption == 'symlink' else tarfile.LNKTYPE; info.linkname = job.LIFECYCLE
                package.addfile(info)
        return base, archive, hashlib.sha256(raw).hexdigest(), fake

    def test_stage_parser_accepts_large_metadata_and_never_overwrites(self):
        # Parser-only fixture: pure validation is mocked separately from the
        # independently exercised prerequisite gates above. No app/model exists.
        base, archive, digest, fake = self.stage_fixture()
        with patch.object(ops, 'module', return_value=fake), patch.object(ops, 'validate', return_value={'synthetic_parser_only': True}):
            result = ops.stage(base, archive, ops.sha(archive), digest)
            self.assertEqual(result['status'], 'i04_gpu_source_staged_not_executed')
            self.assertEqual((base / ops.NAME / 'expected-inventory.json').stat().st_size, 1082939)
            with self.assertRaisesRegex(ValueError, 'no overwrite'): ops.stage(base, archive, ops.sha(archive), digest)

    def test_bad_archive_members_and_code_size_fail_before_new_root(self):
        for corruption in ('duplicate', 'traversal', 'symlink', 'hardlink', 'codecap', 'ancestor_collision'):
            with self.subTest(corruption=corruption):
                base, archive, digest, fake = self.stage_fixture(corruption)
                with patch.object(ops, 'module', return_value=fake), patch.object(ops, 'validate', side_effect=AssertionError('must reject before staging')):
                    with self.assertRaises(ValueError): ops.stage(base, archive, ops.sha(archive), digest)
                self.assertFalse((base / ops.NAME).exists())

    def test_atomic_source_publication_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp).resolve()
            for name in (job.ENTRY, job.LIFECYCLE, job.OPERATIONS): (root / name).write_bytes(b'fixture')
            seen = []
            with patch.object(ops, 'validate', return_value={'status': 'synthetic_preflight'}), patch.object(ops, 'module', return_value=job), patch.object(job, 'validate_source', side_effect=lambda d, r: seen.append(d)):
                receipt = ops.publish(root, 'a' * 64, 'app-synthetic', '2026-11-07T00:00:00Z', 'Synthetic CPU fixture')
                self.assertEqual(ops.sha(root / job.SOURCE), receipt['source_sha256'])
                self.assertEqual(ops.read(root / job.SOURCE), seen[0])
                with self.assertRaisesRegex(ValueError, 'never overwrite'): ops.publish(root, 'a' * 64, 'app-different', '2026-11-07T00:00:00Z', 'Synthetic fixture')
                self.assertEqual(ops.read(root / job.SOURCE)['allocation_id'], 'app-synthetic')


@unittest.skipUnless(sys.platform.startswith('linux'), 'Actual CPU Linux owned-process cleanup')
class OwnedProcesses(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.helper = job.load_pinned(HERE / 'npu_three_repeat_launcher_v4.py', job.CLEANUP_SHA, 'i04_test_reviewed_cleanup')

    def execute(self, script, seconds=2, budget=1024 ** 2):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); folder = root / 'receipt'; folder.mkdir(); start = time.monotonic()
            with patch.object(job, 'MAX_TASK_BYTES', budget):
                code, state = job.supervise([sys.executable, '-c', script, str(root)], folder, root, start + job.CLEANUP_SECONDS + seconds, self.helper)
            self.assertLess(time.monotonic() - start, seconds + 12)
            self.assertEqual(state['remaining_descendants'], [])
            self.assertEqual(job.read(folder / 'controller-receipt.json')['returncode'], code)
            return code, state

    def test_normal_cpu_worker(self):
        code, state = self.execute("print('CPU only; no model')")
        self.assertEqual((code, state['status']), (0, 'completed'))

    def test_timeout_reaps_session_escaping_term_resistant_grandchild(self):
        child = 'import os,signal,time;os.setsid();signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(60)'
        parent = "import subprocess,sys,signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);subprocess.Popen([sys.executable,'-c',%r]);time.sleep(60)" % child
        self.assertEqual(self.execute(parent, .8)[0], 124)

    def test_parent_exit_with_live_orphan_is_failed_and_reaped(self):
        child = 'import os,signal,time;os.setsid();signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(60)'
        parent = "import subprocess,sys,time;subprocess.Popen([sys.executable,'-c',%r]);time.sleep(.3)" % child
        code, state = self.execute(parent)
        self.assertEqual(code, 1); self.assertIn('unexpected live descendants', state['error'])

    def test_sampled_storage_guard_stops_owned_cpu_process(self):
        script = "import pathlib,sys,time;(pathlib.Path(sys.argv[1])/'large').write_bytes(b'x'*8192);time.sleep(60)"
        code, state = self.execute(script, 4, 4096)
        self.assertEqual(code, 1); self.assertIn('4GiB limit', state['error'])


class ActualOfflineEvidence(unittest.TestCase):
    def test_actual_source_package_keeps_local_review_flat_and_remote_members_complete(self):
        with tempfile.TemporaryDirectory() as temp:
            output=Path(temp)/'new-package'
            receipt=ops.build(HERE.parents[4],output,
                HERE/'i03-numeric-small-local-20261106T170703Z/payload/i04-prerequisite/prerequisite.json',
                '3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c',
                HERE/'i04-cpu-proof-local-20261106T183346Z/payload/prerequisite.json',
                '8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec')
            self.assertFalse((output/ops.NAME).exists())
            self.assertTrue((output/job.ENTRY).is_file())
            with tarfile.open(receipt['archive'],'r:gz') as package:
                names={member.name for member in package.getmembers()}
                self.assertIn(ops.NAME+'/source/'+job.GPU,names)
                self.assertIn(ops.NAME+'/prerequisite-cpu/prerequisite.json',names)
                self.assertEqual(len(names),receipt['members'])

    def test_stage_work_reserves_metadata_export_and_owned_cleanup(self):
        stage=job.read(HERE.parent/'i04-stage-v1.json')
        self.assertEqual(job.METADATA_EXPORT_SECONDS,stage['limits']['cpu_metadata_export_whole_timeout_seconds'])
        self.assertEqual(job.WORK_SECONDS,2020)
        self.assertEqual(job.WORK_SECONDS+job.METADATA_EXPORT_SECONDS+job.CLEANUP_SECONDS,job.MAX_SECONDS)

    def test_actual_CPUv3_twenty_one_document_successful_proof(self):
        helper=job.load_pinned(HERE.parent/'adapters/i04_cpu_prerequisite_v2.py',
            '8943f40ceb3b6c98408142843db72aa9d3b53df176b4a9add0ab3d5222a78e38','i04_actual_cpuv3_prerequisite_fixture')
        proof=HERE/'i04-cpu-proof-local-20261106T183346Z/payload/prerequisite.json'
        checked=helper.prerequisite(proof,'8f79a09e15fd04492bcf60091c24ade65bcca08d56e6e87dbc42883cf35daaec')
        self.assertEqual(len(checked['refs']),21)
        self.assertEqual(checked['native_executions_started'],0)
        self.assertFalse(any(name in sys.modules for name in ('torch','torch_npu','numpy')))

    def test_expected_metadata_exceeds_code_cap_and_has_exact_hash(self):
        case = HERE.parent; path = case / 'transfer/i04-independent-expected-20261107.json'
        self.assertEqual(path.stat().st_size, 1082939); self.assertGreater(path.stat().st_size, ops.MAX_MEMBER_CODE)
        self.assertEqual(job.sha(path), '22af034f35c36940f2d1c9012cb421fae951a01236a636f9de69c28fa0017c76')
        helper = job.load_pinned(case / 'adapters/i04_expected_inventory_v1.py',
            'b8f134724a295072a77e292864ebf12e0e5944f184690ba36f0f9d55937f1752', 'i04_actual_expected_cpu_fixture')
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp) / 'expected.json'
            helper.build(case / 'inputs/discovery-v1/wikitext2-discovery-001.json', case / 'inputs/i04-prefix-stress-096-v1.json', out, case / 'i04-stage-v1.json', job.SPEC_SHA)
            self.assertEqual(out.read_bytes(), path.read_bytes())

    def test_actual_i03_eight_document_prerequisite(self):
        helper = job.load_pinned(HERE.parent / 'adapters/i04_prerequisite_v1.py',
            '8d42c0eb525c92c23c5324dc751149b47f3c20b8e74d65d4ba76de6c1ca068f0', 'i04_actual_i03_prerequisite_cpu_fixture')
        path = HERE / 'i03-numeric-small-local-20261106T170703Z/payload/i04-prerequisite/prerequisite.json'
        result = helper.prerequisite(path, '3344c9d703ca4c34778211ecc34bbaa94ef51b4c42e98418f3f7bf20fbdd385c')
        self.assertEqual(len(result['refs']), 8); self.assertEqual(result['native_executions_started'], 0)


if __name__ == '__main__': unittest.main()

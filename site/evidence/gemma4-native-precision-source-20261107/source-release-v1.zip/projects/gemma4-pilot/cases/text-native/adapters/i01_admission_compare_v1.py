"""Independent I01 raw-BF16 admission and scoped full/cached comparisons.

Spec schema 1 has endpoints GPU/NPU, each with source_map:{path,sha256},
receipt:{source_path,sha256}, and optional NPU retained_root. old_cached has
gpu_map/npu_map:{path,sha256}, npu_retained_root, and the original frozen
admission/gate references. Raw receipts/maps are read verbatim, never rewritten.
New GPU evidence must include actual copied bytes; NPU raw/NPY fallback is
confined to its explicit retained root. All outcomes have null acceptance.
"""
import argparse
from datetime import datetime,timezone
import hashlib
import itertools
import json
import math
from pathlib import Path,PurePosixPath
import re
import signal
import sys
import uuid

import numpy as np
import i01_expected_inventory_v1 as expected
import build_gpu290_npu3_compare_v1 as prior

require=expected.require
canonical=expected.canonical
load=expected.load
origin=prior.origin
child=prior.child
argument=prior.argument
VOCABULARY=262144
EXPECTED_SHA='416b4f7384c5676c7b1fc9c6d41a7e5c53e654d95554ceebe71dceb94049d5ee'
EXPECTED_SOURCE_SHA='834de8fef3d6147b908450116e39a48ea75a026bfc13a290db7db25492fbb40b'
COMMON_SHA='fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c'
COLLECTORS={'GPU':'64c4a9a2616ecffea69ed7d78bc2b37e6d38735305ad9a00a9e934ad034a6bba',
    'NPU':'6e41565fde0103cc532c75de78553bc8b941b7aae9f604d3aebb01a46bc70ceb'}
RECORDER_SHA='2a115f6587ac7df9c13dafd9e8c8e71ecd18757ac096385edb7a0dd71676b06b'
LAUNCHERS={'GPU':('h100_i01_lifecycle_v1.py','34b00c57a2fb08e3ded9332a1e4dae760791d9a9b261983dd3809909d58caafc'),
    'NPU':('npu_i01_launcher_v1.py','7d336bf62c1e9ff85343d4040bae588ca584053009e8781cc1095876a3892372')}
PRIOR_BUILDER_SHA='43115d8572e30ddedcdb4a85194ca4ddd3046e90e780be6f17f11c0bd8150c24'
OLD_ADMISSION_SHA='e48382c1d6cc073fcd4bc9bd115c67a54810949507a81a2f5db08421bb4e3a0b'
OLD_GATE_SHA='4309e2bbd0aac4b7dd4ddf8acc3c915aa41af289fe8db71f1158fc9c38f186aa'
OLD_MAPS={'gpu_map':'ab4bc030bf48a0cc4fd2a19335cb1cdcb3d044fbcd01cc2b1e5cf2456f6183b1',
    'npu_map':'f4f2e645811a81d07e2235f9b6071795b4c15e6c36c4bca36186de36a5885b85'}
ATOL=1e-12
GIB=1024**3
HEX=re.compile(r'^[a-f0-9]{64}$')


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def put(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def parse(raw):
    def pairs(items):
        result={}
        for key,value in items:
            require(key not in result,'duplicate JSON key');result[key]=value
        return result
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    result=json.loads(raw,object_pairs_hook=pairs,parse_constant=reject);canonical(result);return result


def verify_tools():
    prior.verify_tools()
    require(sha(Path(prior.__file__))==PRIOR_BUILDER_SHA and sha(Path(expected.__file__))==EXPECTED_SOURCE_SHA,
        'independent inventory/prior admission source changed')


class Endpoint(prior.Endpoint):
    """Extend the already reviewed resolver only for the one retained raw file."""
    def get(self,name,expected_sha=None):
        name=origin(name);entry=self.files[name]
        if entry.get('retained_at_source') is True and PurePosixPath(name).name=='raw-native-logits.safetensors':
            require(self.retained_root is not None and 'path' not in entry and type(entry.get('size')) is int and
                isinstance(entry.get('sha256'),str) and HEX.fullmatch(entry['sha256']), 'retained native raw logits need an explicit NPU root')
            path=Path(name)
            require(path.is_absolute() and path.is_relative_to(self.retained_root) and path.resolve(strict=True).is_relative_to(self.retained_root),
                'native raw logits escape explicit retained root')
            path=path.resolve(strict=True)
            require(path.is_file() and path.stat().st_size==entry['size'],'retained native raw size/type differs')
            digest=sha(path)
            require(digest==entry['sha256'] and (expected_sha is None or digest==expected_sha),'retained native raw SHA differs')
            self.checked[name]=digest;self.resolved[name]=str(path);return path
        return super().get(name,expected_sha)


def raw_tensor(path):
    """Decode only safetensors framing; native values remain memory mapped."""
    path=Path(path)
    with path.open('rb') as stream:
        length_raw=stream.read(8);require(len(length_raw)==8,'truncated raw safetensors length')
        length=int.from_bytes(length_raw,'little');require(0<length<=65536,'unbounded native raw header')
        raw=stream.read(length);require(len(raw)==length,'truncated native raw header');header=parse(raw)
    require(set(header) in ({'logits'},{'logits','__metadata__'}),'exactly the retained logits tensor is required')
    require(canonical(header['logits'])==canonical({'dtype':'BF16','shape':[1,160,VOCABULARY],
        'data_offsets':[0,320*VOCABULARY]}),'native raw tensor shape/dtype/offsets differ')
    if '__metadata__' in header:require(isinstance(header['__metadata__'],dict) and
        all(isinstance(k,str) and isinstance(v,str) for k,v in header['__metadata__'].items()),'raw metadata must contain strings')
    require(path.stat().st_size==8+length+320*VOCABULARY,'native raw payload length differs')
    return np.memmap(path,mode='r',dtype='<u2',offset=8+length,shape=(160,VOCABULARY))


def native_values(bits):
    require(bits.shape==(VOCABULARY,) and bits.dtype==np.dtype('<u2'),'one raw BF16 vocabulary row required')
    values=(np.asarray(bits,dtype='<u4')<<np.uint32(16)).view('<f4').astype(np.float64)
    require(np.isfinite(values).all(),'native raw logits contain nonfinite values')
    return values


def independent_logprobs(bits):
    values=native_values(bits);values-=float(np.max(values))
    # Independent scalar reduction rather than the capture helper's np.sum.
    log_sum=math.log(math.fsum(math.exp(float(v)) for v in values))
    values-=log_sum
    require(np.isfinite(values).all() and np.max(values)<=0,'independent raw-derived logprobs invalid')
    return values


def inspect_artifacts(endpoint,output,outer):
    output=origin(output)
    inp=endpoint.get(outer['input_path'],expected.INPUT_SHA256)
    stage=endpoint.get(outer['stage_spec_source_path'],expected.STAGE_SHA256)
    independent=endpoint.get(outer['expected_inventory_source_path'],EXPECTED_SHA)
    inventory=expected.verify(independent,inp,stage)
    manifest_path=endpoint.get(child(output,'artifacts-manifest.json'),outer['artifacts_manifest_sha256'])
    manifest=load(manifest_path);category=outer['backend']
    require(manifest.get('schema_version')==1 and manifest.get('kind')=='i01-capture-artifacts' and
        manifest.get('task')==expected.TASK and manifest.get('backend')==category.lower() and
        manifest.get('stage_spec_sha256')==expected.STAGE_SHA256 and manifest.get('input_sha256')==expected.INPUT_SHA256 and
        manifest.get('expected_inventory_sha256')==EXPECTED_SHA and manifest.get('acceptance') is None,'I01 artifact manifest identity differs')
    predictors=inventory['sampling']['deduplicated_predictors']
    files=manifest['files']
    names={'expected-inventory.json','raw-native-logits.safetensors','target-scores.json','distributions.json','events.json',
        'capture-summary.json','runtime.json','snapshot-verification.json','policy-before-load.json','policy-after-load.json',
        'policy-after-capture.json','loaded-model-inventory.json'}
    names|={'dist-p%03d%s'%(p,suffix) for p in predictors for suffix in ('.json','.npy')}
    if category=='NPU':names.add('driver-version-provenance.json')
    require(set(files)==names and len(files)==(106 if category=='GPU' else 107),'I01 exact output member inventory differs')
    observed={name for name in endpoint.files if str(PurePosixPath(name).parent)==output}
    require(observed=={child(output,name) for name in names|{'artifacts-manifest.json','status.json'}},'extra/missing original I01 output artifact')
    total=0;paths={}
    for name,ref in files.items():
        require(PurePosixPath(name).name==name and set(ref)=={'sha256','size_bytes'} and
            type(ref['size_bytes']) is int and ref['size_bytes']>=0 and HEX.fullmatch(ref['sha256']),'invalid manifest file reference')
        path=endpoint.get(child(output,name),ref['sha256']);require(path.stat().st_size==ref['size_bytes'],'manifest file size differs')
        total+=ref['size_bytes'];paths[name]=path
    require(total<=GIB,'I01 capture exceeds the one-GiB bounded artifact budget')
    require(sha(paths['expected-inventory.json'])==EXPECTED_SHA and paths['expected-inventory.json'].read_bytes()==independent.read_bytes(),
        'independent pre-capture expected bytes were not preserved')
    status_path=endpoint.get(child(output,'status.json'));status=load(status_path)
    require(status.get('status')=='completed' and status.get('rank')==0 and type(status['rank']) is int and
        status.get('task')==expected.TASK and status.get('backend')==category.lower() and
        status.get('stage_spec_sha256')==expected.STAGE_SHA256 and status.get('artifacts_manifest_sha256')==sha(manifest_path) and
        status.get('targets')==159 and status.get('distribution_positions')==47 and status.get('acceptance') is None and
        status.get('full_core_complete') is False,'I01 terminal status is not bound to the completed manifest')
    raw_sha=files['raw-native-logits.safetensors']['sha256'];targets=load(paths['target-scores.json']);distributions=load(paths['distributions.json'])
    for doc,kind in ((targets,'i01-native-target-scores'),(distributions,'i01-native-distribution-rows')):
        require(doc.get('schema_version')==1 and doc.get('kind')==kind and doc.get('input_sha256')==expected.INPUT_SHA256 and
            doc.get('inventory_sha256')==EXPECTED_SHA and doc.get('raw_logits_sha256')==raw_sha and
            doc.get('native_logits_dtype')=='torch.bfloat16' and doc.get('logprob_dtype')=='float64' and
            doc.get('normalization')==expected.NORMALIZATION,'raw-derived artifact provenance differs')
    scores=targets['scores'];positions=distributions['positions']
    require(len(scores)==159 and len(positions)==47,'I01 target/distribution coverage differs')
    for row,coordinate in zip(scores,inventory['all_targets']):
        require(all(canonical(row.get(k))==canonical(v) for k,v in coordinate.items()) and
            type(row.get('prediction_position')) is int and row['prediction_position']==coordinate['position']-1 and
            type(row.get('logprob')) in (int,float) and math.isfinite(row['logprob']) and row['logprob']<=0,'all159 causal target coordinates/values required')
    sequence=load(inp)['prompt']+load(inp)['continuation']
    event={'stage':'full_forward','input_ids':sequence,'positions':list(range(160)),'attention_mask':[[1]*160],
        'past_key_values':None,'use_cache':False,'logits_to_keep':0,'return_dict':True,'returned_cache':None,
        'native_logits_shape':[1,160,VOCABULARY],'native_logits_dtype':'torch.bfloat16'}
    require(canonical(load(paths['events.json']))==canonical([event]),'one complete cache-off causal native forward required')
    summary=load(paths['capture-summary.json'])
    fixed_summary={'native_forward_calls':1,'native_logits_shape':[1,160,VOCABULARY],'native_logits_dtype':'torch.bfloat16',
        'use_cache':False,'returned_cache':None,'logits_to_keep':0,'targets':159,'sampled_distributions':47,
        'unscored_native_prediction_indices':[159]}
    require(all(k in summary and canonical(summary[k])==canonical(v) for k,v in fixed_summary.items()),'native full-forward summary differs')
    require(summary['raw_logits']=={'path':child(output,'raw-native-logits.safetensors'),'sha256':raw_sha,
        'size_bytes':paths['raw-native-logits.safetensors'].stat().st_size},'native raw summary reference differs')
    by_predictor={};rows=[]
    for item,coordinate in zip(positions,inventory['distribution_positions']):
        p=coordinate['position'];prefix='dist-p%03d'%p;roles=(['prompt_sample'] if p in inventory['sampling']['conditioning_predictors'] else [])+(['continuation'] if p>=127 else [])
        descriptor={'path':prefix+'.npy','row':0}
        require(all(canonical(item.get(k))==canonical(v) for k,v in coordinate.items()) and item.get('roles')==roles and
            item.get('record')==prefix+'.json' and canonical(item.get('scores'))==canonical(descriptor),'47 prespecified native distribution coordinates/roles differ')
        record=load(paths[prefix+'.json'])
        required={**coordinate,'roles':roles,'target_position':p+1,'token':sequence[p+1],'scores':descriptor,
            'input_sha256':expected.INPUT_SHA256,'inventory_sha256':EXPECTED_SHA,'raw_logits_sha256':raw_sha,
            'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':expected.NORMALIZATION}
        require(all(k in record and canonical(record[k])==canonical(v) for k,v in required.items()) and
            record.get('logprob')==scores[p]['logprob'],'native row record/provenance/target differs')
        array=np.load(paths[prefix+'.npy'],mmap_mode='r',allow_pickle=False)
        try:require(array.shape==(1,VOCABULARY) and array.dtype==np.dtype('float64') and np.isfinite(array).all() and
            float(np.max(array))<=0 and float(array[0,sequence[p+1]])==scores[p]['logprob'],'retained FP64 row shape/dtype/target differs')
        finally:
            if getattr(array,'_mmap',None) is not None:array._mmap.close()
        by_predictor[p]=paths[prefix+'.npy'];rows.append({**coordinate,'scores':{'path':str(paths[prefix+'.npy']),'row':0}})
    raw=raw_tensor(paths['raw-native-logits.safetensors']);largest_delta=0.0
    try:
        for p in range(160):
            if p==159:native_values(raw[p]);continue
            derived=independent_logprobs(raw[p]);target_delta=abs(float(derived[sequence[p+1]])-scores[p]['logprob'])
            require(target_delta<=ATOL,'raw BF16 predictor/target derivation differs at '+str(p))
            largest_delta=max(largest_delta,target_delta)
            if p in by_predictor:
                array=np.load(by_predictor[p],mmap_mode='r',allow_pickle=False)
                try:delta=float(np.max(np.abs(array[0]-derived)))
                finally:array._mmap.close()
                require(delta<=ATOL,'raw BF16 full-vocabulary distribution derivation differs at '+str(p));largest_delta=max(largest_delta,delta)
    finally:raw._mmap.close()
    return {'inventory':inventory,'paths':paths,'status_path':str(status_path),'runtime':load(paths['runtime.json']),
        'positions':rows,'targets':inventory['all_targets'],'scores':[{k:row[k] for k in ('sample','position','token','logprob')} for row in scores],
        'raw_sha256':raw_sha,'manifest_sha256':sha(manifest_path),'raw_rederivation_max_abs_delta':largest_delta}


def checked_reference(endpoint,ref):
    require(isinstance(ref,dict) and set(ref)=={'path','sha256'} and HEX.fullmatch(ref['sha256']),'invalid original source reference')
    return endpoint.get(ref['path'],ref['sha256'])


def runtime_copies(endpoint,outer,runtime,category):
    """Bind original runtime paths to their preserved post-stop byte copies."""
    packages=runtime['package_sources']
    require(set(packages)==({'torch','transformers','numpy'} if category=='GPU' else
        {'torch','torch_npu','transformers','numpy'}),'exact observed runtime package closure required')
    frozen=endpoint.json(outer['runtime_source_map_path'],outer['runtime_source_map_sha256'])
    refs=[*packages.values(),runtime['model_identity']['modeling_source']]
    require(set(frozen)=={ref['path'] for ref in refs},'frozen runtime copy closure differs')
    for ref in refs:
        copied=frozen[ref['path']]
        require(set(copied)=={'path','sha256','size_bytes'} and copied['sha256']==ref['sha256'] and
            copied['size_bytes']==ref['size_bytes'],'frozen original/copy runtime identity differs')
        actual=endpoint.get(copied['path'],copied['sha256'])
        require(actual.stat().st_size==copied['size_bytes'] and
            endpoint.get(ref['path'],ref['sha256']).stat().st_size==ref['size_bytes'],'frozen runtime copy size differs')
        require(outer['source_sha256'].get(ref['path'])==ref['sha256'] or
            ref==runtime['model_identity']['modeling_source'],'pre-model runtime package source was not frozen')
    claim=str(PurePosixPath(outer['runtime_source_map_path']).parent)
    before_path=child(claim,'runtime-packages-before.json') if category=='GPU' else child(claim,'native-runtime-sources.json')
    require(before_path in outer['source_sha256'],'pre-model package observation was not frozen')
    observed=endpoint.json(before_path,outer['source_sha256'][before_path])
    if category=='GPU':
        require(set(observed)=={ref['path'] for ref in packages.values()} and
            all(observed[ref['path']]['sha256']==ref['sha256'] and observed[ref['path']]['size_bytes']==ref['size_bytes'] for ref in packages.values()),
            'GPU pre-model package identities differ')
    else:require(canonical(observed)==canonical(packages),'NPU pre-model package identities differ')


def admit(endpoint,receipt_ref,category):
    receipt_path=endpoint.get(receipt_ref['source_path'],receipt_ref['sha256']);outer=load(receipt_path)
    require(outer.get('schema_version')==1 and outer.get('task')=='I01' and outer.get('task_id')==expected.STAGE_ID and
        outer.get('backend')==category and outer.get('status')=='completed' and type(outer.get('returncode')) is int and outer['returncode']==0 and
        outer.get('timed_out') is False and outer.get('native_capture_count')==1 and outer.get('acceptance') is None,'successful new bounded I01 outer receipt required')
    require(outer.get('collector_sha256')==COLLECTORS[category] and outer.get('input_sha256')==expected.INPUT_SHA256 and
        outer.get('expected_inventory_source_sha256')==EXPECTED_SHA and outer.get('stage_spec_source_sha256')==expected.STAGE_SHA256,
        'prepared collector/input/independent expected/stage pins differ')
    sources=outer['source_sha256'];dependencies=outer['dependency_paths']
    require(isinstance(sources,dict) and isinstance(dependencies,list) and len(set(dependencies))==len(dependencies) and
        set(dependencies)==set(sources),'outer source inventory differs')
    for name,digest in sources.items():require(HEX.fullmatch(digest),'invalid original source digest');endpoint.get(name,digest)
    argv=outer['argv'];require(isinstance(argv,list) and len(argv)>3 and all(isinstance(a,str) and a for a in argv),'original I01 argv missing')
    index=2 if argv[1]=='-B' else 1
    require(argv[index]==outer['collector_path'] and sources.get(outer['collector_path'])==COLLECTORS[category] and
        sources.get(outer['input_path'])==expected.INPUT_SHA256,'direct I01 execution/source identity differs')
    flags={'--input':outer['input_path'],'--output':outer['output_dir'],'--device':'cuda:0' if category=='GPU' else 'npu:0',
        '--stage-spec':outer['stage_spec_source_path'],'--stage-spec-sha256':expected.STAGE_SHA256,
        '--expected-inventory':outer['expected_inventory_source_path'],'--expected-inventory-sha256':EXPECTED_SHA,
        '--allocation-receipt':outer['allocation_path']}
    for flag,value in flags.items():require(argument(argv,flag)==value,'I01 executed argument differs: '+flag)
    for name,digest in [(outer['expected_inventory_source_path'],EXPECTED_SHA),(outer['stage_spec_source_path'],expected.STAGE_SHA256),
                        (outer['allocation_path'],outer['allocation_sha256'])]:require(sources.get(name)==digest,'pre-model dynamic evidence was not a frozen source')
    expected_sources=[p for p in sources if PurePosixPath(p).name=='i01_expected_inventory_v1.py']
    recorder_sources=[p for p in sources if PurePosixPath(p).name=='record_run.py']
    require(len(expected_sources)==len(recorder_sources)==1 and sources[expected_sources[0]]==EXPECTED_SOURCE_SHA and
        sources[recorder_sources[0]]==RECORDER_SHA,'independent inventory/generic recorder source differs')
    launcher_name,launcher_sha=LAUNCHERS[category];launchers=[p for p in sources if PurePosixPath(p).name==launcher_name]
    require(len(launchers)==1 and sources[launchers[0]]==launcher_sha,'reviewed finite native lifecycle source differs')
    controller=endpoint.json(child(str(PurePosixPath(receipt_ref['source_path']).parent),'controller-receipt.json'))
    require(controller.get('status')=='completed' and type(controller.get('returncode')) is int and controller['returncode']==0 and
        controller.get('remaining_descendants')==[] and controller.get('timed_out',False) is False,
        'native lifecycle is not terminal with owned descendant cleanup complete')
    command_path=checked_reference(endpoint,outer['generic_receipt']);command=load(command_path)
    require(command.get('status')=='completed' and type(command.get('returncode')) is int and command['returncode']==0 and
        type(command.get('child_returncode')) is int and command['child_returncode']==0 and canonical(command.get('argv'))==canonical(argv) and
        command.get('timeout')==(900 if category=='GPU' else 1200),'original generic execution receipt differs')
    require(prior.npu.utc_time(outer['started_utc'])==prior.npu.utc_time(command['start']) and
        prior.npu.utc_time(command['start'])<prior.npu.utc_time(command['end'])<=prior.npu.utc_time(outer['finished_utc']),
        'original execution UTC chain differs')
    result=inspect_artifacts(endpoint,outer['output_dir'],outer);runtime=result['runtime'];paths=result['paths']
    fixed={'task':expected.TASK,'stage_id':expected.STAGE_ID,'stage_spec_sha256':expected.STAGE_SHA256,
        'input_sha256':expected.INPUT_SHA256,'expected_inventory_external_path':outer['expected_inventory_source_path'],
        'expected_inventory_sha256':EXPECTED_SHA,'model_repository':'google/gemma-4-12B','requested_revision':prior.npu.REVISION,
        'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':expected.NORMALIZATION,'seed':0,
        'backend':category.lower(),'device_argument':flags['--device'],'thresholds':None,'acceptance':None,'full_core_complete':False}
    require(all(k in runtime and canonical(runtime[k])==canonical(v) for k,v in fixed.items()),'I01 runtime task/input/mode identity differs')
    refs=runtime['sources'];common=refs['i01/i01_common_v1.py'];entry=refs['i01/i01_'+category.lower()+'_v1.py']
    require(common['sha256']==COMMON_SHA and entry['sha256']==COLLECTORS[category] and entry['path']==outer['collector_path'],
        'actual common/entry source differs from reviewed capture')
    for ref in refs.values():
        p=endpoint.get(ref['path'],ref['sha256']);require(p.stat().st_size==ref['size_bytes'],'runtime frozen source size differs')
    for ref in runtime['package_sources'].values():
        p=endpoint.get(ref['path'],ref['sha256']);require(p.stat().st_size==ref['size_bytes'],'actual package source bytes differ')
    runtime_copies(endpoint,outer,runtime,category)
    identity=runtime['model_identity']
    require(identity.get('model_class')=='Gemma4UnifiedForConditionalGeneration' and identity.get('model_type')=='gemma4_unified' and
        identity.get('parameter_dtypes')==['torch.bfloat16'] and identity.get('actual_attention')=='eager' and
        identity.get('observed_config_commit') in (None,prior.npu.REVISION) and 'logits_to_keep' in identity.get('forward_signature',''),
        'complete loaded model metadata differs')
    modeling=identity['modeling_source'];p=endpoint.get(modeling['path'],modeling['sha256']);require(p.stat().st_size==modeling['size_bytes'],'actual modeling source changed')
    snapshot=load(paths['snapshot-verification.json']);require(sha(paths['snapshot-verification.json'])==identity['snapshot_receipt_sha256'],'snapshot runtime/manifest chain differs')
    metadata=next(ref for name,ref in refs.items() if PurePosixPath(name).name=='upstream-identity.json')
    require(metadata['sha256']==prior.npu.METADATA_SHA,'official model metadata differs')
    model=prior.npu.snapshot_identity(snapshot,endpoint.json(metadata['path'],metadata['sha256']),identity['model_class'])
    require(snapshot.get('upstream_metadata_sha256')==prior.npu.METADATA_SHA,'snapshot original metadata pin differs')
    policy=runtime['math_policy'];require(canonical(policy)==canonical(load(paths['policy-after-load.json']))==canonical(load(paths['policy-after-capture.json'])),
        'actual backend policy changed during full capture')
    allocation=endpoint.json(outer['allocation_path'],outer['allocation_sha256']);physical=runtime['runtime_uuid']
    require(isinstance(physical,str) and str(uuid.UUID(physical))==physical and uuid.UUID(physical).int and
        allocation.get('physical_device_id')==physical and runtime['allocation_receipt_sha256']==outer['allocation_sha256'],
        'actual allocation/runtime physical identity differs')
    versions=runtime['versions']
    if category=='GPU':
        require(versions=={'torch':'2.9.0+cu128','transformers':'5.10.1','cuda_runtime':'12.8','numpy':'1.26.4'} and
            runtime['device_name']=='NVIDIA H100 80GB HBM3' and canonical(policy)==canonical(prior.gpu.FROZEN_POLICY),
            'new GPU stack/device/policy differs')
        rng=runtime['rng_observations'];require(all(type(rng.get(k)) is int and rng[k]==0 for k in
            ('seed','python_random_seed','numpy_seed','torch_initial_seed','cuda_initial_seed')) and
            canonical(rng['settings'])==canonical(policy)==canonical(load(paths['policy-before-load.json'])['settings']),
            'actual GPU seed/configuration differs')
        require(allocation.get('vendor')=='NVIDIA' and allocation.get('visible_count')==1 and allocation.get('logical_ordinal')==0,
            'GPU allocation ordinal/count differs')
        native_name=allocation['native_source'];native=endpoint.json(native_name,allocation['native_source_sha256'])
        platform_name=allocation['evidence_source'];platform=endpoint.json(platform_name,allocation['platform_source_sha256'])
        require(native_name in sources and sources[native_name]==allocation['native_source_sha256'] and
            platform_name in sources and sources[platform_name]==allocation['platform_source_sha256'] and
            native.get('status')=='native_preflight_passed' and native.get('runtime_uuid')==physical and
            native.get('device_name')==runtime['device_name'] and native.get('visible_count')==1 and
            platform.get('allocation_id')==allocation.get('allocation_id'),'GPU pre-model platform/native source chain differs')
    else:
        require(versions=={'torch':'2.9.0+cpu','torch_npu':'2.9.0.post2','transformers':'5.10.1','numpy':'1.26.4','cann':'9.1.0','driver':'25.5.2'},
            'new NPU software stack differs')
        require(runtime['instance_visible_count']==8 and runtime['compute_device_count']==1,'NPU execution must remain one device')
        # Normalized read-only view translates the new runtime field name only;
        # the original runtime/outer receipt bytes are preserved and hashed.
        view={**runtime,'device':runtime['device_argument']}
        prior.npu.verify_binding(view,outer,endpoint,outer['allocation_path'],argument(argv,'--native-mapping'),argument(argv,'--native-source'))
        prior.npu.verify_driver_provenance(runtime,outer,endpoint,outer['output_dir'])
        required={'float32_matmul_precision':'highest','matmul_allow_hf32':False,'conv_allow_hf32':True,
            'deterministic_algorithms':False,'deterministic_warn_only':False,'pythonhashseed':'0'}
        require(all(k in policy and type(policy[k]) is type(v) and policy[k]==v for k,v in required.items()) and
            canonical(load(paths['policy-before-load.json'])['configured'])==canonical(policy),'NPU configured/read-back policy differs')
    require(type(runtime['free_bytes_before_load']) is int and runtime['free_bytes_before_load']>=35*GIB and
        type(runtime['host_memory']['effective_available_bytes']) is int and runtime['host_memory']['effective_available_bytes']>=(40 if category=='GPU' else 80)*GIB,
        'recorded pre-model memory guard was below the finite stage')
    result.update(side='i01-'+category.lower(),category=category,model=model,hardware={'category':category,'model':runtime['device_name']},
        software={'framework':'torch',**versions},backend_policy=policy,runtime_uuid=physical,outer_sha256=receipt_ref['sha256'],
        mode={'use_cache':False,'forward_partition':'one_full_160_token_forward','native_forward_calls':1,'logits_to_keep':0})
    return result


def comparison_documents(a,b,targets,positions,scope):
    require(canonical(a['model'])==canonical(b['model']),'comparison model identity differs')
    numerics={'parameter_dtypes':['torch.bfloat16'],'attention':'eager','native_logits_dtype':'torch.bfloat16',
        'logprob_dtype':'float64','seed':0,'parallelism':'tp1','normalization':expected.NORMALIZATION}
    common={'model':a['model'],'inputs':{'sha256':expected.INPUT_SHA256},'numerics':numerics,'scope':scope}
    base={'schema_version':1,'common':common,'expected_ranks':{r['side']:[0] for r in (a,b)},
        'side_conditions':{r['side']:{'hardware':r['hardware'],'software':r['software'],'backend_policy':r['backend_policy'],
            'execution_mode':r['mode']} for r in (a,b)},'thresholds':None}
    docs={'targets-contract.json':{**base,'kind':'target-scores','targets':targets},
        'distributions-contract.json':{**base,'schema_version':2,'kind':'distributions','vocab_size':VOCABULARY,
            'normalization_tolerance':1e-5,'renormalization':'none','positions':positions}}
    for run in (a,b):
        side=run['side'];env=side+'-environment.json'
        docs[env]={'rank':0,'versions':run['software'],'actual':{**common,**base['side_conditions'][side]}}
        manifest={'common':common,'side':side,'expected_ranks':[0],'ranks':[{'rank':0,'environment':env,'status':run['status_path']}]}
        target_positions={(r['sample'],r['position'],r['token']) for r in targets};prediction_positions={(r['sample'],r['position']) for r in positions}
        scores=[row for row in run['scores'] if (row['sample'],row['position'],row['token']) in target_positions]
        distributions=[row for row in run['positions'] if (row['sample'],row['position']) in prediction_positions]
        require(len(scores)==len(targets) and len(distributions)==len(positions),'requested full/cached overlap not fully covered')
        docs[side+'-targets.json']={**manifest,'schema_version':1,'kind':'target-scores','scores':scores}
        docs[side+'-distributions.json']={**manifest,'schema_version':2,'kind':'distributions','positions':distributions}
    return docs


def compare_pair(output,a,b,targets,positions,scope):
    output.mkdir();documents=comparison_documents(a,b,targets,positions,scope)
    for name,document in documents.items():put(output/name,document)
    checks={}
    for side in (a['side'],b['side']):
        checks[side]=prior.npu.validate(output/'distributions-contract.json',output/(side+'-distributions.json'))
        require(checks[side]['status']=='validated' and checks[side]['item_count']==len(positions),'shared full-vocabulary validation rejected I01 comparison')
    target_report=prior.npu.compare_targets(output/'targets-contract.json',output/(a['side']+'-targets.json'),output/(b['side']+'-targets.json'))
    distribution_report=prior.npu.compare_distributions(output/'distributions-contract.json',output/(a['side']+'-distributions.json'),output/(b['side']+'-distributions.json'))
    require(target_report['status']==distribution_report['status']=='no_thresholds','shared I01 comparator rejected original artifacts')
    return {'sides':[a['side'],b['side']],'targets':target_report,'distributions':distribution_report,'validations':checks,
        'frozen_document_sha256':{name:sha(output/name) for name in documents},'thresholds':None,'acceptance':None}


def assess(spec_path,spec_sha,output):
    verify_tools();require(HEX.fullmatch(spec_sha) and sha(spec_path)==spec_sha,'independently frozen I01 comparison spec differs')
    spec=load(spec_path);require(spec.get('schema_version')==1 and spec.get('task')==expected.TASK and
        spec.get('stage_spec_sha256')==expected.STAGE_SHA256 and spec.get('acceptance') is None and set(spec['endpoints'])=={'GPU','NPU'},
        'frozen I01 comparison spec identity differs')
    endpoints={};runs={}
    for category,info in spec['endpoints'].items():
        ref=info['source_map'];endpoint=Endpoint(ref['path'],ref['sha256'],info.get('retained_root') if category=='NPU' else None)
        endpoints[category]=endpoint;runs[category]=admit(endpoint,info['receipt'],category)
    require(len({str(run['paths']['raw-native-logits.safetensors']) for run in runs.values()})==2,
        'native full raw source reused between backend captures')
    row_paths=[row['scores']['path'] for run in runs.values() for row in run['positions']]
    require(len(set(row_paths))==len(row_paths)==94,'new full distribution sources reused')
    old=spec['old_cached'];require(old['gpu_map']['sha256']==OLD_MAPS['gpu_map'] and old['npu_map']['sha256']==OLD_MAPS['npu_map'],
        'only the six already verified historical cached captures may be reused')
    require(old['admission']['sha256']==OLD_ADMISSION_SHA and sha(old['admission']['path'])==OLD_ADMISSION_SHA and
        old['gate']['sha256']==OLD_GATE_SHA and sha(old['gate']['path'])==OLD_GATE_SHA,'original historical frozen gate/admission bytes differ')
    historical=load(old['gate']['path']);require(historical['status']=='fixed_cross_backend_evidence_consistency_checked' and
        historical['admission_sha256']==OLD_ADMISSION_SHA,'historical gate was not successful')
    old_documents,old_checked=prior.prepare(old['gpu_map']['path'],OLD_MAPS['gpu_map'],old['npu_map']['path'],OLD_MAPS['npu_map'],old['npu_retained_root'])
    output=Path(output).resolve();require(not output.exists() and output.parent.is_dir(),'new I01 comparison directory required');output.mkdir()
    cross=compare_pair(output/'cross-backend-all159',runs['GPU'],runs['NPU'],runs['GPU']['targets'],
        [{k:p[k] for k in ('sample','position','history')} for p in runs['GPU']['positions']],
        'one fixed I01 cache-off input; all159 causal targets and47 prespecified distribution positions')
    overlaps=[]
    for category,prefix in (('GPU','h100'),('NPU','npu')):
        full=runs[category];positions=[{k:p[k] for k in ('sample','position','history')} for p in full['positions'] if p['position']>=127]
        for i in range(1,4):
            side=prefix+'-r%d'%i;environment=old_documents[side+'-environment.json']['actual'];manifest=old_documents[side+'-distributions.json']
            original=next(r for r in old_checked['runs'] if r['side']==side)
            cached={'side':side,'model':environment['model'],'hardware':environment['hardware'],'software':environment['software'],
                'backend_policy':environment['backend_policy'],'runtime_uuid':original['runtime_uuid'],
                'positions':manifest['positions'],'scores':old_documents[side+'-targets.json']['scores'],
                'status_path':manifest['ranks'][0]['status'],'mode':{'use_cache':True,'forward_partition':'prefill128_plus31_cached_decode',
                    'native_forward_calls':32,'logits_to_keep':'default0_all_input_positions',
                    'captured_prediction_selection':'last_row_per_native_call'}}
            shared_versions=set(full['software'])&set(cached['software'])
            require(all(full['software'][k]==cached['software'][k] for k in shared_versions) and
                full['hardware']==cached['hardware'] and canonical(full['backend_policy'])==canonical(cached['backend_policy']),
                'historical comparison no longer has compatible recorded peer conditions')
            report=compare_pair(output/(full['side']+'-vs-'+side+'-continuation32'),full,cached,full['inventory']['cached_overlap_targets'],positions,
                'compatible historical peer contrast only:32 continuation targets/distributions; different process/cache/partition/collector, possibly physical device')
            report['peer_context']={'same_physical_device_identifier':full['runtime_uuid']==cached['runtime_uuid'],
                'shared_recorded_software_fields_equal':sorted(shared_versions),'software_fields_unobserved_on_old_side':sorted(set(full['software'])-set(cached['software'])),
                'controlled_cache_only_intervention':False,'variables_not_controlled':['cache use','forward partition','fresh process','collector implementation','physical allocation/state'],
                'old_source_receipt_sha256':original['receipt_sha256']}
            overlaps.append(report)
    for endpoint in endpoints.values():
        for name,digest in endpoint.checked.items():require(sha(Path(endpoint.resolved[name]))==digest,'new I01 original source changed during comparison')
        require(sha(endpoint.manifest_path)==endpoint.expected_sha,'new I01 source-map changed during comparison')
    for entries in old_checked['resolved_sources'].values():
        for entry in entries.values():require(sha(Path(entry['path']))==entry['sha256'],'historical original source changed during comparison')
    for key in ('gpu_map','npu_map','admission','gate'):
        require(sha(old[key]['path'])==old[key]['sha256'],'historical source-map/frozen gate changed during comparison')
    require(sha(spec_path)==spec_sha,'frozen comparison spec changed')
    verify_tools()
    result={'schema_version':1,'status':'i01_raw_bf16_and_scoped_comparisons_checked','task':expected.TASK,'stage_spec_sha256':expected.STAGE_SHA256,
        'comparison_spec_sha256':spec_sha,'checked_utc':datetime.now(timezone.utc).isoformat(),
        'offline_tool_source_sha256':{**prior.IMPORT_PINS,'i01_expected_inventory_v1.py':EXPECTED_SOURCE_SHA,
            'build_gpu290_npu3_compare_v1.py':PRIOR_BUILDER_SHA,'i01_admission_compare_v1.py':sha(__file__)},
        'scope':{'independent_inputs':1,'new_native_captures_per_backend':1,'new_repeatability_measured':False,'full_targets_per_backend':159,
            'full_distribution_positions_per_backend':47,'old_cached_continuation_targets_only':32,'historical_peer_comparisons':6,
            'native_unscored_prediction_row159_retained':True},
        'raw_derivation':{k:{'raw_sha256':r['raw_sha256'],'manifest_sha256':r['manifest_sha256'],
            'largest_abs_logprob_derivation_delta':r['raw_rederivation_max_abs_delta']} for k,r in runs.items()},
        'cross_backend':cross,'historical_cached_peer_contrasts':overlaps,
        'verification_tolerances':{'raw_derivation_absolute':ATOL,'full_row_normalization_mass':1e-5,'model_acceptance_thresholds':False},
        'native_executions_started_by_admission':0,'thresholds':None,'acceptance':None,'full_core_complete':False,
        'limitations':['One input; one new full process per backend supplies no new repeatability/representative quality evidence',
            'Historical cached peer contrasts do not establish a same-state cache-only causal intervention',
            'Native raw BF16 is retained for I01; historical cached raw native logits remain unavailable',
            'Top100-union probability errors/coarsened complement JS are not full-vocabulary error/divergence',
            'Recorded source/binding hashes do not independently attest scheduler ownership or loader-consumed weight bytes']}
    put(output/'i01-comparison-report.json',result);return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec',required=True,type=Path);parser.add_argument('--spec-sha256',required=True)
    parser.add_argument('--output-dir',required=True,type=Path);parser.add_argument('--timeout-seconds',type=int,default=600)
    args=parser.parse_args();require(1<=args.timeout_seconds<=600,'CPU comparison bound must be1..600 seconds')
    require(hasattr(signal,'SIGALRM'),'bounded CPU admission requires POSIX')
    def expire(*_):raise TimeoutError('I01 offline admission/comparison CPU deadline exceeded')
    old=signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,args.timeout_seconds)
    try:report=assess(args.spec,args.spec_sha256,args.output_dir)
    except (OSError,ValueError,KeyError,TypeError,IndexError) as exc:parser.exit(2,type(exc).__name__+': '+str(exc)+'\n')
    finally:signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,old)
    print(json.dumps({'status':report['status'],'output':str(args.output_dir),'cross_targets':159,'cross_positions':47,
        'cached_peer_contrasts':6,'native_executions_started':0,'acceptance':None}))


if __name__=='__main__':main()

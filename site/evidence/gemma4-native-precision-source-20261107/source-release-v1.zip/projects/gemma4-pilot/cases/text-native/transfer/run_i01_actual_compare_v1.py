"""Freeze actual I01 endpoint references and run one bounded offline comparison.

No accelerator, framework, model or platform is invoked. Original receipts and
source maps are read verbatim. Failed controllers retain every new artifact.
"""
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path,PurePosixPath
import re
import signal
import subprocess
import sys
import time
import traceback

GPU_MAP_SHA='dbf3d67094a3b5399d46fc488724b89a497f9051486d4e50c8b2056e31cffd9b'
MAIN='projects/gemma4-pilot/cases/text-native/adapters/i01_admission_compare_v1.py'
MAIN_SHA='f7fe91cdcebeec910efed4579ecf379fd665cf305223a3fa77858004db81858a'
EXPECTED='projects/gemma4-pilot/cases/text-native/adapters/i01_expected_inventory_v1.py'
EXPECTED_SHA='834de8fef3d6147b908450116e39a48ea75a026bfc13a290db7db25492fbb40b'
STAGE_SHA='5aa7d50bb472aab82108ad6711fdd6c5bdd4780bbecb27cdf78c734d13093c05'
TASK='gemma4-i01-cache-off-anchor-v1'
OLD_CONTROLLER='runs/compare-gpu290-npu3-invocation-20261106T112725Z'
OLD_ADMISSION_SHA='e48382c1d6cc073fcd4bc9bd115c67a54810949507a81a2f5db08421bb4e3a0b'
OLD_GATE_SHA='4309e2bbd0aac4b7dd4ddf8acc3c915aa41af289fe8db71f1158fc9c38f186aa'
OLD_MAP_SHAS={'gpu_map':'ab4bc030bf48a0cc4fd2a19335cb1cdcb3d044fbcd01cc2b1e5cf2456f6183b1',
    'npu_map':'f4f2e645811a81d07e2235f9b6071795b4c15e6c36c4bca36186de36a5885b85'}
NPU_CLAIM='i01-cacheoff-20261106/claims/npu-i01-REDACTED_DEVICE_UUID'
HEX=re.compile(r'^[a-f0-9]{64}$')


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024**2),b''):digest.update(block)
    return digest.hexdigest()


def load(path):
    def pairs(items):
        result={}
        for key,value in items:require(key not in result,'duplicate JSON key');result[key]=value
        return result
    def reject(value):raise ValueError('nonfinite JSON token '+value)
    return json.loads(Path(path).read_text(encoding='utf-8'),object_pairs_hook=pairs,parse_constant=reject)


def put(path,value):
    with Path(path).open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def utc():return datetime.now(timezone.utc).isoformat()


def under(path,root):
    path=Path(path).resolve(strict=True)
    require(path.is_relative_to(root) and path.is_file(),'regular input must stay below explicit task root')
    return path


def verify_tools(tools,manifest_sha):
    path=tools/'tool-bundle-manifest.json'
    require(HEX.fullmatch(manifest_sha) and sha(path)==manifest_sha,'independently supplied tool manifest SHA differs')
    doc=load(path);require(doc['schema_version']==1 and doc['kind']=='i01-offline-tool-bundle' and
        doc['native_executions_started']==0 and doc['acceptance'] is None,'wrong offline tool bundle')
    require(doc['files'][MAIN]['sha256']==MAIN_SHA and doc['files'][EXPECTED]['sha256']==EXPECTED_SHA,'reviewed I01 source pins differ')
    for name,ref in doc['files'].items():
        require(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and '\\' not in name,'unsafe tool member')
        actual=(tools/name).resolve(strict=True)
        require(actual.is_relative_to(tools) and actual.is_file() and actual.stat().st_size==ref['size_bytes'] and sha(actual)==ref['sha256'],
            'tool source changed: '+name)
    require(sha(__file__)==doc['files']['projects/gemma4-pilot/cases/text-native/transfer/run_i01_actual_compare_v1.py']['sha256'],
        'controller source differs from frozen bundle')
    return doc


def map_outer(root,map_path,digest,category):
    map_path=under(map_path,root);require(HEX.fullmatch(digest) and sha(map_path)==digest,'actual new source-map SHA differs')
    mapping=load(map_path);request=mapping['request']
    require(request['task']=='I01' and request['backend']==category,'actual source map task/backend differs')
    original=request['outer_receipt'];require(PurePosixPath(original).is_absolute() and '\\' not in original and
        '..' not in PurePosixPath(original).parts,'original outer path must remain absolute POSIX')
    if category=='NPU':require(original==str(root/NPU_CLAIM/'capture-receipt.json'),'new NPU map belongs to another actual claim')
    ref=mapping['files'][original];require('path' in ref and not ref.get('retained_at_source'),'original outer receipt must be copied')
    actual=(map_path.parent/ref['path']).resolve(strict=True)
    require(actual.is_relative_to(map_path.parent) and actual.is_file() and actual.stat().st_size==ref['size'] and sha(actual)==ref['sha256'],
        'mapped original outer receipt bytes differ')
    receipt=load(actual);require(receipt['backend']==category and receipt['status']=='completed' and type(receipt['returncode']) is int and
        receipt['returncode']==0 and receipt['timed_out'] is False,'new actual outer capture is not completed')
    if category=='GPU':
        allocation_ref=mapping['files'][receipt['allocation_path']]
        allocation=(map_path.parent/allocation_ref['path']).resolve(strict=True)
        require(allocation.is_relative_to(map_path.parent) and sha(allocation)==allocation_ref['sha256'] and
            load(allocation)['allocation_id']=='REDACTED_APP_ID','new GPU map belongs to another actual allocation')
    return {'source_map':{'path':str(map_path),'sha256':digest},'receipt':{'source_path':original,'sha256':ref['sha256']},
        **({'retained_root':str(root/'i01-cacheoff-20261106')} if category=='NPU' else {})}


def build_spec(root,gpu_map,npu_map,npu_sha):
    require(npu_sha!=GPU_MAP_SHA,'the two new endpoint identities must be distinct')
    endpoints={'GPU':map_outer(root,gpu_map,GPU_MAP_SHA,'GPU'),'NPU':map_outer(root,npu_map,npu_sha,'NPU')}
    admission=under(root/OLD_CONTROLLER/'bundle/admission.json',root)
    gate=under(root/OLD_CONTROLLER/'bundle/gate-report.json',root)
    require(sha(admission)==OLD_ADMISSION_SHA and sha(gate)==OLD_GATE_SHA,'original successful cached admission/gate changed')
    old=load(admission)['sources'];references={}
    for key,digest in OLD_MAP_SHAS.items():
        ref=old[key];require(ref['sha256']==digest and sha(under(ref['path'],root))==digest,'original cached source-map changed')
        references[key]={'path':ref['path'],'sha256':digest}
    require(Path(old['npu_retained_root']).resolve(strict=True)==root,'old NPU retained root differs from original R')
    return {'schema_version':1,'task':TASK,'stage_spec_sha256':STAGE_SHA,'endpoints':endpoints,
        'old_cached':{**references,'npu_retained_root':str(root),'admission':{'path':str(admission),'sha256':OLD_ADMISSION_SHA},
            'gate':{'path':str(gate),'sha256':OLD_GATE_SHA}},'thresholds':None,'acceptance':None}


def execute(run,name,argv,timeout):
    receipt={'schema_version':1,'step':name,'argv':argv,'started_utc':utc(),'timeout_seconds':timeout,'timed_out':False}
    started=time.monotonic();process=None;stdout=run/(name+'.stdout');stderr=run/(name+'.stderr')
    try:
        with stdout.open('xb') as out,stderr.open('xb') as err:
            process=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True,env=os.environ.copy())
            try:receipt['returncode']=process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                receipt['timed_out']=True
                os.killpg(process.pid,signal.SIGTERM)
                try:receipt['returncode']=process.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);receipt['returncode']=process.wait(timeout=5)
    except BaseException as exc:
        receipt.update(error_type=type(exc).__name__,error=str(exc),returncode=process.poll() if process else None)
        if process is not None:
            try:os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:pass
        raise
    finally:
        receipt.update(finished_utc=utc(),elapsed_seconds=time.monotonic()-started)
        for key,path in [('stdout',stdout),('stderr',stderr)]:
            if path.is_file():receipt[key]={'path':str(path),'sha256':sha(path),'bytes':path.stat().st_size}
        put(run/(name+'-receipt.json'),receipt)
    require(receipt['returncode']==0 and not receipt['timed_out'],'offline child step failed: '+name)
    return receipt


def run_comparison(root,tools,manifest_sha,gpu_map,npu_map,npu_sha):
    require(os.name=='posix','bounded offline controller requires POSIX')
    root=Path(root).resolve(strict=True);tools=Path(tools).resolve(strict=True)
    require(tools.is_relative_to(root/'tools') and not tools.is_symlink(),'tool root must be the new verified R/tools import')
    verify_tools(tools,manifest_sha)
    run=root/'runs'/('compare-i01-invocation-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    run.mkdir(mode=0o700);state={'schema_version':1,'task':'I01','status':'running','started_utc':utc(),'run':str(run),
        'tools_root':str(tools),'tool_manifest_sha256':manifest_sha,'steps':[],'native_executions_started':0,'thresholds':None,'acceptance':None}
    put(run/'controller-start.json',state)
    print(json.dumps({'status':'running','controller':str(run/'controller-receipt.json'),'native_executions_started':0}),flush=True)
    def expire(*_):raise TimeoutError('I01 comparison controller whole900s deadline reached')
    old_handler=signal.signal(signal.SIGALRM,expire);signal.setitimer(signal.ITIMER_REAL,900)
    try:
        spec=build_spec(root,gpu_map,npu_map,npu_sha);spec_path=run/'comparison-spec.json';put(spec_path,spec)
        state['comparison_spec']={'path':str(spec_path),'sha256':sha(spec_path)}
        put(run/'execution-start.json',{'started_utc':utc(),'comparison_spec':state['comparison_spec'],'tool_manifest_sha256':manifest_sha,
            'controller_source_sha256':sha(__file__),'native_executions_started':0,'acceptance':None})
        python=root/'venv/bin/python';output=run/'bundle'
        argv=[str(python),'-B',str(tools/MAIN),'--spec',str(spec_path),'--spec-sha256',sha(spec_path),'--output-dir',str(output),'--timeout-seconds','600']
        state['steps'].append(execute(run,'01-independent-compare',argv,620))
        report=output/'i01-comparison-report.json';result=load(report)
        require(result['status']=='i01_raw_bf16_and_scoped_comparisons_checked' and result['comparison_spec_sha256']==sha(spec_path) and
            result['scope']['independent_inputs']==1 and result['scope']['new_repeatability_measured'] is False and
            result['scope']['full_targets_per_backend']==159 and result['scope']['full_distribution_positions_per_backend']==47 and
            result['scope']['historical_peer_comparisons']==6 and len(result['historical_cached_peer_contrasts'])==6 and
            result['thresholds'] is None and result['acceptance'] is None and result['full_core_complete'] is False,'offline comparison terminal scope differs')
        verify_tools(tools,manifest_sha)
        state.update(status='completed',returncode=0,report={'path':str(report),'sha256':sha(report)},scope=result['scope'])
    except BaseException as exc:
        state.update(status='failed',returncode=2,error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc())
    finally:
        signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,old_handler)
        state['finished_utc']=utc();put(run/'controller-receipt.json',state)
    print(json.dumps({'status':state['status'],'returncode':state['returncode'],'receipt':str(run/'controller-receipt.json'),
        'report':state.get('report'),'acceptance':None},indent=2),flush=True)
    return state['returncode']


def self_test():
    """Synthetic selector pin regressions only; no actual captures or numerics."""
    import tempfile
    with tempfile.TemporaryDirectory() as temporary:
        root=Path(temporary);mapping=root/'source-map.json'
        put(mapping,{'schema_version':1,'request':{'task':'I01','backend':'GPU','outer_receipt':'/synthetic/capture.json'},'files':{}})
        for digest in ('0'*64,'not-a-sha'):
            try:map_outer(root,mapping,digest,'GPU')
            except ValueError:pass
            else:raise AssertionError('changed source-map pin accepted')
        old=root/OLD_CONTROLLER/'bundle';old.mkdir(parents=True)
        put(old/'admission.json',{'synthetic_fixture':True});put(old/'gate-report.json',{'synthetic_fixture':True})
        require(sha(old/'admission.json')!=OLD_ADMISSION_SHA and sha(old/'gate-report.json')!=OLD_GATE_SHA,'synthetic old pins unexpectedly native')
        capture=root/'capture.json';allocation=root/'allocation.json'
        put(capture,{'backend':'GPU','status':'completed','returncode':0,'timed_out':False,'allocation_path':'/synthetic/allocation.json'})
        put(allocation,{'allocation_id':'synthetic-wrong-actual-app'})
        docs={'/synthetic/capture.json':capture,'/synthetic/allocation.json':allocation}
        mapping.unlink();put(mapping,{'schema_version':1,'request':{'task':'I01','backend':'GPU','outer_receipt':'/synthetic/capture.json'},
            'files':{name:{'path':path.name,'size':path.stat().st_size,'sha256':sha(path)} for name,path in docs.items()}})
        try:map_outer(root,mapping,sha(mapping),'GPU')
        except ValueError as exc:require('another actual allocation' in str(exc),'unexpected synthetic selector failure')
        else:raise AssertionError('wrong actual allocation accepted')
        mapping.unlink();put(mapping,{'request':{'task':'I01','backend':'NPU','outer_receipt':'/synthetic/wrong-claim/capture-receipt.json'},'files':{}})
        try:map_outer(root,mapping,sha(mapping),'NPU')
        except ValueError as exc:require('another actual claim' in str(exc),'unexpected NPU selector failure')
        else:raise AssertionError('wrong NPU claim accepted')
    print('synthetic_selector_pin_regressions_passed; native_executions_started=0')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--self-test',action='store_true')
    for name in ('root','tools-root','gpu-source-map','npu-source-map'):parser.add_argument('--'+name,type=Path)
    parser.add_argument('--tool-manifest-sha256');parser.add_argument('--npu-map-sha256');args=parser.parse_args()
    if args.self_test:self_test();return 0
    require(all(getattr(args,n) is not None for n in ('root','tools_root','gpu_source_map','npu_source_map','tool_manifest_sha256','npu_map_sha256')),'all actual paths/pins required')
    return run_comparison(args.root,args.tools_root,args.tool_manifest_sha256,args.gpu_source_map,args.npu_source_map,args.npu_map_sha256)


if __name__=='__main__':raise SystemExit(main())

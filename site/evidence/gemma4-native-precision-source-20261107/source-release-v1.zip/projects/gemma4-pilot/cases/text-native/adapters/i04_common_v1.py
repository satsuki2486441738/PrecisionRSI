"""Private I04 four-call batch/padding capture; no Torch work on import.

The old modules supply verified loading and pure state/RNG helpers only. New
launchers own one-shot claims, readiness, whole-attempt and cleanup budgets.
An actual successful I03 numerical admission is required before Torch import.
"""
import argparse
from contextlib import contextmanager
import gc
import importlib.util
import math
from pathlib import Path
import re
import shutil
import signal
import sys

import numpy as np
import i03_common_v1 as controlled

prior = controlled.prior
HERE, REPO = prior.HERE, prior.REPO
require, sha, read, put = prior.require, prior.sha, prior.read, prior.put
file_ref, check_refs = prior.file_ref, prior.check_refs
derive_logprobs, Array = prior.derive_logprobs, prior.Array
canonical, safe_relative = controlled.canonical, controlled.safe_relative
model_state, rng_observation = controlled.model_state, controlled.rng_observation
safetensors_header = controlled.safetensors_header
REVISION, NORMALIZATION = prior.REVISION, prior.NORMALIZATION
VOCABULARY = 262144
STAGE_ID = 'gemma4-gpu-npu-i04-batch-padding-v1-20261107'
STAGE_SHA256 = '26e03606180c6357b770f36fa03a3ad77e1e26c0ac3a224c025669fa5960e226'
TASK = 'gemma4-i04-batch-padding-v1'
INPUT_SHA256 = prior.INPUT_SHA256
INPUT_B_SHA256 = 'f4bca8e16d2e7768c6f9dff0677ea329ccf46ed254e211dc2ce2f9852f416792'
INPUT_SHAS = {'A': INPUT_SHA256, 'B': INPUT_B_SHA256}
MODES = ['alone-A', 'alone-B', 'batch-left', 'batch-right']
CAPTURE_CAP = 1342177280
HEX = re.compile(r'^[a-f0-9]{64}$')
PREREQUISITE_SOURCE_SHA256 = '8d42c0eb525c92c23c5324dc751149b47f3c20b8e74d65d4ba76de6c1ca068f0'
CASE = 'projects/gemma4-pilot/cases/text-native'
PINNED = {**prior.PINNED,
    CASE + '/adapters/i01_common_v1.py': 'fdf7ebffbceb2a09e362db23cf97bca27c8910b58296baf91c7d7943866fb70c',
    CASE + '/adapters/i03_common_v1.py': '5cf67f53b5392e4425c4534ec6f97961066c190d24dc1280f31e66781a0fe03a',
    CASE + '/adapters/i03_prerequisite_v1.py': 'e0650c00cefd7246d50602d5853a7f296fc1b6c9d678712b2457181d2b37af36'}


def request_coordinates(document, request):
    prompt_length, length = (128, 160) if request == 'A' else (64, 96)
    require(isinstance(document.get('sample'), str) and document['sample'].strip(), 'sample required')
    prompt, continuation = document.get('prompt'), document.get('continuation')
    require(isinstance(prompt, list) and len(prompt) == prompt_length and isinstance(continuation, list) and len(continuation) == 32,
            'frozen request lengths differ')
    sequence = prompt + continuation
    require(all(type(token) is int and 0 <= token < VOCABULARY for token in sequence), 'invalid request token')
    positions = sorted(set(i*(prompt_length-1)//15 for i in range(16)) | set(range(prompt_length-1, length-1)))
    return {'sample': document['sample'], 'prompt_length': prompt_length, 'continuation_length': 32,
        'sequence_length': length, 'input_ids': sequence,
        'all_targets': [{'sample': document['sample'], 'position': t, 'token': sequence[t]} for t in range(1, length)],
        'distribution_positions': [{'sample': document['sample'], 'position': p, 'history': sequence[:p+1]} for p in positions]}


def mode_plan(mode, requests):
    require(mode in MODES, 'unknown I04 mode')
    names = [mode[-1]] if mode.startswith('alone-') else ['A', 'B']
    width = requests[names[0]]['sequence_length'] if len(names) == 1 else 160
    ids, masks, positions, observations, pads = [], [], [], [], []
    for slot, name in enumerate(names):
        request = requests[name]; length = request['sequence_length']
        offset = width-length if mode == 'batch-left' else 0
        row = [0]*width; row[offset:offset+length] = request['input_ids']
        mask = [int(offset <= p < offset+length) for p in range(width)]
        pos = [p-offset if mask[p] else 0 for p in range(width)]
        ids.append(row); masks.append(mask); positions.append(pos)
        pads.extend({'slot': slot, 'physical_position': p} for p in range(width) if not mask[p])
        observations.append({'request': name, 'sample': request['sample'], 'slot': slot, 'physical_offset': offset,
            'sequence_length': length,
            'all_targets': [{**item, 'prediction_position': item['position']-1,
                'physical_prediction_position': offset+item['position']-1,
                'physical_target_position': offset+item['position']} for item in request['all_targets']],
            'distribution_positions': [{**item, 'physical_prediction_position': offset+item['position']}
                for item in request['distribution_positions']]})
    shape = [len(names), width, VOCABULARY]
    return {'id': mode, 'input_ids': ids, 'attention_mask': masks, 'position_ids': positions,
        'raw_logits': {'tensor_name': 'logits', 'dtype': 'BF16', 'shape': shape, 'data_bytes': math.prod(shape)*2},
        'observations': observations, 'pad_only_rows': pads}


def coordinates(input_a, input_b):
    requests = {'A': request_coordinates(input_a, 'A'), 'B': request_coordinates(input_b, 'B')}
    require(requests['B']['input_ids'] == requests['A']['input_ids'][:96], 'B must preserve the exact original prefix')
    require(input_b.get('parent_input_sha256') == INPUT_SHA256 and input_b.get('parent_token_span') == [0,96] and
        input_b.get('independent_representative_example') is False, 'B derived-prefix stress provenance differs')
    require(requests['A']['sample'] != requests['B']['sample'], 'requests must retain distinct logical identities')
    return {'requests': requests, 'modes': [mode_plan(mode, requests) for mode in MODES]}


def expected_core(inventory):
    return {'schema_version': 1, 'task': TASK, 'stage_id': STAGE_ID, 'stage_spec_sha256': STAGE_SHA256,
        'input_sha256s': INPUT_SHAS, 'requests': inventory['requests'], 'modes': inventory['modes']}


def prerequisite(path, digest):
    require(isinstance(PREREQUISITE_SOURCE_SHA256, str) and HEX.fullmatch(PREREQUISITE_SOURCE_SHA256),
            'new I04 pure prerequisite source is not frozen yet')
    source = HERE / 'i04_prerequisite_v1.py'
    require(source.is_file() and sha(source) == PREREQUISITE_SOURCE_SHA256, 'I04 prerequisite helper source differs')
    spec = importlib.util.spec_from_file_location('i04_pinned_pure_prerequisite', source)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    require(Path(module.__file__).resolve() == source, 'actual I04 prerequisite module differs')
    checked = module.prerequisite(path, digest)
    return checked['document'], checked['refs']


def arguments(backend):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('model','input','input-b','allocation-receipt','stage-spec','expected-inventory','i03-prerequisite','output'):
        parser.add_argument('--'+name, type=Path, required=True)
    for name in ('stage-spec-sha256','expected-inventory-sha256','i03-prerequisite-sha256'):
        parser.add_argument('--'+name, required=True)
    parser.add_argument('--device', required=True, choices=['cuda:0'] if backend == 'gpu' else ['npu:0'])
    for name in (('numerics-policy',) if backend == 'gpu' else ('driver-source','native-mapping','native-source')):
        parser.add_argument('--'+name, type=Path, required=True)
    return parser.parse_args()


def prepare(args, backend, entry):
    require('torch' not in sys.modules and 'torch_npu' not in sys.modules, 'I03 numeric proof must precede Torch import')
    require(args.stage_spec_sha256 == STAGE_SHA256 and sha(args.stage_spec) == STAGE_SHA256, 'I04 finite stage SHA differs')
    stage = read(args.stage_spec)
    require(stage.get('stage_id') == STAGE_ID and stage.get('status') == 'prepared_not_executed' and
        stage.get('modes') == MODES and stage.get('total_forward_calls_per_backend') == 4 and stage.get('acceptance') is None,
        'I04 frozen stage semantics differ')
    require(sha(args.input) == INPUT_SHA256 and sha(args.input_b) == INPUT_B_SHA256, 'frozen A/B request bytes differ')
    inventory = coordinates(read(args.input), read(args.input_b))
    require(HEX.fullmatch(args.expected_inventory_sha256) and sha(args.expected_inventory) == args.expected_inventory_sha256,
        'independent I04 expected inventory SHA differs')
    expected = read(args.expected_inventory)
    require(all(key in expected and canonical(expected[key]) == canonical(value) for key,value in expected_core(inventory).items()),
        'independent I04 logical/physical input inventory differs')
    proof, proof_refs = prerequisite(args.i03_prerequisite, args.i03_prerequisite_sha256)
    require(args.output.parent.is_dir() and not args.output.exists(), 'exclusive new output directory required')
    require(shutil.disk_usage(args.output.parent).free >= stage['limits']['minimum_free_source_storage_bytes'], 'source free storage is below5GiB')
    prior.check_import_paths()
    require(Path(controlled.__file__).resolve() == HERE/'i03_common_v1.py', 'I03 pure state helper imported outside staged sources')
    refs = {}
    for name, digest in PINNED.items():
        refs[name] = file_ref(REPO/name); require(refs[name]['sha256'] == digest, 'immutable reused dependency differs')
    for name in ('i04_prerequisite_v1.py','i04_common_v1.py',Path(entry).name): refs['i04/'+name] = file_ref(HERE/name)
    for key in ('input','input_b','allocation_receipt','stage_spec','expected_inventory','i03_prerequisite',
                *(['numerics_policy'] if backend == 'gpu' else ['driver_source','native_mapping','native_source'])):
        refs['input/'+key] = file_ref(getattr(args,key))
    refs.update({'i03-proof/'+key:ref for key,ref in proof_refs.items()})
    return stage, inventory, refs, proof


def initialize_output(args, proof):
    args.output.mkdir()
    for original,target in ((args.input,'input-A.json'),(args.input_b,'input-B.json'),(args.stage_spec,'stage-spec.json'),(args.expected_inventory,'expected-inventory.json')):
        with (args.output/target).open('xb') as stream: stream.write(original.read_bytes())
    directory = args.output/'prerequisite'; directory.mkdir()
    with (directory/'prerequisite.json').open('xb') as stream: stream.write(args.i03_prerequisite.read_bytes())
    refs = [proof[key] for key in ('report','comparison_spec','controller','analysis_source','artifact_helper_source','tool_manifest')]
    refs += list(proof['source_maps'].values())
    require(len({ref['path'] for ref in refs}) == 8, 'eight distinct original I03 proof documents required')
    for ref in refs:
        target = directory.joinpath(*safe_relative(ref['path']).parts); target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream: stream.write((args.i03_prerequisite.parent/ref['path']).read_bytes())
        require(sha(target) == ref['sha256'], 'original I03 proof copy differs')


@contextmanager
def bounded_native(stage, backend):
    require(hasattr(signal,'SIGALRM'), 'POSIX bounded native execution required')
    seconds = stage['limits'][backend+'_capture_timeout_seconds']
    require(seconds == (900 if backend == 'gpu' else 1200), 'I04 capture timeout differs')
    def expire(*_): raise TimeoutError('I04 native entry timeout')
    previous = signal.signal(signal.SIGALRM,expire); signal.setitimer(signal.ITIMER_REAL,seconds)
    try: yield
    finally: signal.setitimer(signal.ITIMER_REAL,0); signal.signal(signal.SIGALRM,previous)


def check_storage(output):
    size = 0
    for path in Path(output).rglob('*'):
        require(not path.is_symlink(), 'capture tree contains symlink')
        if path.is_file(): size += path.stat().st_size
    require(size <= CAPTURE_CAP, 'I04 capture product cap exceeded')
    return size


def save_raw(native_cpu, path, mode, shape):
    from safetensors.torch import save_file
    require(not Path(path).exists(), 'native raw tensor output must be new')
    save_file({'logits':native_cpu},str(path),metadata={'task':TASK,'mode':mode,'boundary':'native logits before score processing; padded rows retained unchanged'})
    safetensors_header(path,{'logits':shape})
    return file_ref(path)


def nonfinite_counts(values):
    return {'nan':int(np.isnan(values).sum()),'positive_infinity':int(np.isposinf(values).sum()),
        'negative_infinity':int(np.isneginf(values).sum()),'nonfinite':int((~np.isfinite(values)).sum())}


def derive_observations(native_cpu, inventory, plan, directory, raw_ref):
    mode = plan['id']; width = plan['raw_logits']['shape'][1]
    pad_counts = {'rows':len(plan['pad_only_rows']),'coordinates':len(plan['pad_only_rows'])*VOCABULARY,
        'rows_with_nonfinite':0,'nan':0,'positive_infinity':0,'negative_infinity':0,'nonfinite':0}
    for item in plan['pad_only_rows']:
        values = native_cpu[item['slot'],item['physical_position'],:].double().numpy()
        counts = nonfinite_counts(values); pad_counts['rows_with_nonfinite'] += int(counts['nonfinite'] > 0)
        for key,value in counts.items(): pad_counts[key] += value
    observations = []
    for observation in plan['observations']:
        name = observation['request']; request = inventory['requests'][name]
        target_dir = directory/('request-'+name); target_dir.mkdir()
        base = {'schema_version':1,'task':TASK,'mode':mode,'request':name,'stage_spec_sha256':STAGE_SHA256,
            'input_sha256s':INPUT_SHAS,'request_input_sha256':INPUT_SHAS[name],'raw_logits_sha256':raw_ref['sha256'],
            'native_logits_dtype':'torch.bfloat16','logprob_dtype':'float64','normalization':NORMALIZATION,
            'slot':observation['slot'],'physical_offset':observation['physical_offset']}
        sequence = request['input_ids']; targets, distributions = [], []
        selected = {item['position']:item for item in observation['distribution_positions']}
        for p in range(request['sequence_length']):
            physical = observation['physical_offset']+p
            values = native_cpu[observation['slot'],physical,:].double().numpy()
            require(np.isfinite(values).all(), 'valid logical native row is nonfinite')
            if p == request['sequence_length']-1: continue
            row = derive_logprobs(values,dtype='float64'); token = sequence[p+1]; value = float(row[token])
            require(math.isfinite(value) and value <= 0, 'raw-derived target logprob differs')
            coordinate = observation['all_targets'][p]
            targets.append({**coordinate,'request':name,'slot':observation['slot'],'logprob':value})
            if p in selected:
                stem = 'dist-p%03d'%p; descriptor = {'path':stem+'.npy','row':0}
                with (target_dir/descriptor['path']).open('xb') as stream: np.save(stream,row.reshape(1,VOCABULARY),allow_pickle=False)
                roles = (['prompt_sample'] if p in [i*(request['prompt_length']-1)//15 for i in range(16)] else [])
                roles += ['continuation'] if p >= request['prompt_length']-1 else []
                record = dict(base,**selected[p],roles=roles,target_position=p+1,token=token,logprob=value,scores=descriptor)
                put(target_dir/(stem+'.json'),record)
                distributions.append({**selected[p],'roles':roles,'scores':descriptor,'record':stem+'.json'})
            check_storage(directory.parent.parent)
        put(target_dir/'target-scores.json',dict(base,kind='i04-native-target-scores',scores=targets))
        put(target_dir/'distributions.json',dict(base,kind='i04-native-distribution-rows',positions=distributions))
        observations.append({'request':name,'sample':request['sample'],'slot':observation['slot'],
            'physical_offset':observation['physical_offset'],'sequence_length':request['sequence_length'],
            'targets':len(targets),'sampled_distributions':len(distributions),'unscored_logical_predictors':[request['sequence_length']-1]})
    valid_rows = sum(item['sequence_length'] for item in plan['observations'])
    rows = {'schema_version':1,'task':TASK,'mode':mode,'raw_logits_sha256':raw_ref['sha256'],
        'physical_raw_rows':plan['raw_logits']['shape'][0]*width,'valid_raw_rows':valid_rows,'valid_nonfinite_coordinates':0,
        'pad_only_rows':plan['pad_only_rows'],'pad_only_nonfinite_counts':pad_counts,
        'policy':'Pad-only rows are retained losslessly, counted separately and never normalized or paired.'}
    put(directory/'raw-row-inventory.json',rows)
    return observations, rows


def capture_mode(model, torch, device, inventory, directory, mode):
    plan = next(item for item in inventory['modes'] if item['id'] == mode); directory.mkdir()
    require(model.config.get_text_config().pad_token_id == 0, 'native padding token config differs')
    with torch.inference_mode():
        result = model(input_ids=torch.tensor(plan['input_ids'],dtype=torch.long,device=device),
            attention_mask=torch.tensor(plan['attention_mask'],dtype=torch.long,device=device),
            position_ids=torch.tensor(plan['position_ids'],dtype=torch.long,device=device),
            past_key_values=None,use_cache=False,logits_to_keep=0,return_dict=True)
        logits = result.logits
        require(list(logits.shape) == plan['raw_logits']['shape'] and str(logits.dtype) == 'torch.bfloat16', 'native batch logits shape/dtype differs')
        require(getattr(result,'past_key_values',None) is None and getattr(result,'shared_kv_states',None) is None,
            'cache-off native call returned unexpected persistent state')
        native_cpu = logits.detach().cpu().contiguous()
    raw_ref = save_raw(native_cpu,directory/'raw-native-logits.safetensors',mode,plan['raw_logits']['shape'])
    observations, rows = derive_observations(native_cpu,inventory,plan,directory,raw_ref)
    put(directory/'events.json',[{**plan,'mode':mode,'call_index':0,'use_cache':False,'past_key_values_is_none':True,
        'logits_to_keep':0,'labels_supplied':False,'shared_kv_states_supplied':False,'returned_cache':None,'returned_shared_kv_states':None,
        'native_logits_shape':list(logits.shape),'native_logits_dtype':str(logits.dtype)}])
    summary = {'schema_version':1,'task':TASK,'mode':mode,'native_forward_calls':1,'use_cache':False,
        'raw_logits':raw_ref,'native_logits_shape':plan['raw_logits']['shape'],'native_logits_dtype':'torch.bfloat16',
        'observations':observations,'targets':sum(x['targets'] for x in observations),
        'sampled_distributions':sum(x['sampled_distributions'] for x in observations),
        'physical_raw_rows':rows['physical_raw_rows'],'valid_raw_rows':rows['valid_raw_rows'],
        'pad_only_raw_rows':len(plan['pad_only_rows']),'pad_only_nonfinite_counts':rows['pad_only_nonfinite_counts']}
    put(directory/'capture-summary.json',summary)
    return summary


def capture_all(model, torch, device, inventory, output, backend, seed_callback, policy_callback, synchronize):
    output = Path(output); (output/'modes').mkdir()
    baseline = model_state(model,torch); put(output/'loaded-model-state.json',baseline)
    policy = policy_callback(); summaries, rng_anchor = [], None
    for mode in MODES:
        gc.collect(); synchronize()
        require(canonical(model_state(model,torch)) == canonical(baseline), 'persistent model state changed before mode')
        reset = seed_callback(); require(canonical(policy_callback()) == canonical(policy), 'policy changed before mode')
        before = rng_observation(torch,backend)
        if rng_anchor is None: rng_anchor = before
        require(canonical(before) == canonical(rng_anchor), 'observed seed0 RNG state did not reset')
        directory = output/'modes'/mode
        summary = capture_mode(model,torch,device,inventory,directory,mode)
        synchronize(); after = model_state(model,torch); put(directory/'model-state-after.json',after)
        require(canonical(after) == canonical(baseline), 'persistent model state changed during mode')
        require(canonical(policy_callback()) == canonical(policy), 'policy changed during mode')
        put(directory/'state-control.json',{'schema_version':1,'mode':mode,'seed_reset':reset,'rng_before':before,
            'rng_after':rng_observation(torch,backend),'math_policy':policy,
            'baseline_model_state_sha256':sha(output/'loaded-model-state.json'),'model_state_after_sha256':sha(directory/'model-state-after.json'),
            'scope':'same loaded model/device/policy; no cache; allocator/kernel warmup not reset'})
        summaries.append(summary); check_storage(output)
    require(sum(x['targets'] for x in summaries) == 762 and sum(x['sampled_distributions'] for x in summaries) == 282 and
        sum(x['physical_raw_rows'] for x in summaries) == 896 and sum(x['valid_raw_rows'] for x in summaries) == 768 and
        sum(x['pad_only_raw_rows'] for x in summaries) == 128, 'I04 aggregate raw/valid/target/distribution inventory differs')
    put(output/'capture-summary.json',{'schema_version':1,'task':TASK,'stage_spec_sha256':STAGE_SHA256,'modes':summaries,
        'native_forward_calls_total':4,'model_loads':1,'target_scores':762,'distribution_rows':282,
        'physical_raw_rows':896,'valid_raw_rows':768,'pad_only_raw_rows':128,'acceptance':None})
    return summaries


def finalize(args, backend, inventory, refs, runtime):
    prior.check_import_paths(); check_refs(refs); check_refs(runtime['implementation_sources'])
    runtime.update(task=TASK,stage_id=STAGE_ID,stage_spec_sha256=STAGE_SHA256,input_sha256s=INPUT_SHAS,
        expected_inventory_sha256=args.expected_inventory_sha256,expected_inventory_external_path=str(args.expected_inventory.resolve()),
        i03_prerequisite_sha256=args.i03_prerequisite_sha256,i03_prerequisite_external_path=str(args.i03_prerequisite.resolve()),
        sources=refs,model_repository='google/gemma-4-12B',requested_revision=REVISION,native_logits_dtype='torch.bfloat16',
        logprob_dtype='float64',normalization=NORMALIZATION,model_loads=1,native_forward_calls_total=4,modes=MODES,
        target_scores=762,distribution_rows=282,physical_raw_rows=896,valid_raw_rows=768,pad_only_raw_rows=128,
        thresholds=None,acceptance=None,full_core_complete=False,
        limitations=['one parent input plus derived prefix shape stress','same model/process; new repeatability unmeasured',
            'batch/padding differences are not operator cause','no1024 sliding eviction or cached serving/scheduler test',
            'snapshot receipts do not attest scheduler or loader-consumed bytes'])
    put(args.output/'runtime.json',runtime)
    files = {p.relative_to(args.output).as_posix():{'sha256':sha(p),'size_bytes':p.stat().st_size}
        for p in sorted(args.output.rglob('*')) if p.is_file()}
    put(args.output/'artifacts-manifest.json',{'schema_version':1,'kind':'i04-capture-artifacts','task':TASK,'backend':backend,
        'stage_spec_sha256':STAGE_SHA256,'input_sha256s':INPUT_SHAS,'expected_inventory_sha256':args.expected_inventory_sha256,
        'i03_prerequisite_sha256':args.i03_prerequisite_sha256,'files':files,'acceptance':None})
    validate_output(args.output,args.input,args.input_b,require_completed=False)
    check_refs(refs); check_refs(runtime['implementation_sources'])
    put(args.output/'status.json',{'schema_version':1,'status':'completed','rank':0,'task':TASK,'backend':backend,
        'stage_spec_sha256':STAGE_SHA256,'artifacts_manifest_sha256':sha(args.output/'artifacts-manifest.json'),
        'modes':MODES,'native_forward_calls_total':4,'model_loads':1,'acceptance':None,'full_core_complete':False})
    return validate_output(args.output,args.input,args.input_b)


def validate_output(output, input_path, input_b_path, require_completed=True):
    """Offline schema/hash/coordinate checks; independent CPU gate redoes math."""
    output = Path(output); require(sha(input_path) == INPUT_SHA256 and sha(input_b_path) == INPUT_B_SHA256, 'validator A/B input SHA differs')
    inventory = coordinates(read(input_path),read(input_b_path)); manifest = read(output/'artifacts-manifest.json')
    require(manifest.get('kind') == 'i04-capture-artifacts' and manifest.get('task') == TASK and manifest.get('stage_spec_sha256') == STAGE_SHA256 and
        manifest.get('input_sha256s') == INPUT_SHAS and manifest.get('backend') in ('gpu','npu'), 'I04 manifest identity differs')
    files = manifest['files']; actual = {p.relative_to(output).as_posix() for p in output.rglob('*') if p.is_file()}
    require(actual == set(files)|{'artifacts-manifest.json'}|({'status.json'} if require_completed else set()), 'I04 artifact inventory is not exact')
    for name,ref in files.items():
        safe_relative(name); path = output/name
        require(not path.is_symlink() and ref == {'sha256':sha(path),'size_bytes':path.stat().st_size}, 'I04 artifact bytes differ: '+name)
    require(sha(output/'input-A.json') == INPUT_SHA256 and sha(output/'input-B.json') == INPUT_B_SHA256 and sha(output/'stage-spec.json') == STAGE_SHA256,
        'retained request/stage source differs')
    expected = read(output/'expected-inventory.json')
    require(sha(output/'expected-inventory.json') == manifest['expected_inventory_sha256'] and
        all(key in expected and canonical(expected[key]) == canonical(value) for key,value in expected_core(inventory).items()), 'retained expected inventory differs')
    proof,_ = prerequisite(output/'prerequisite/prerequisite.json',manifest['i03_prerequisite_sha256'])
    required = {'input-A.json','input-B.json','stage-spec.json','expected-inventory.json','prerequisite/prerequisite.json',
        'snapshot-verification.json','loaded-model-inventory.json','loaded-model-state.json','runtime.json',
        'policy-before-load.json','policy-after-load.json','policy-after-capture.json','capture-summary.json'}
    proof_refs = [proof[key] for key in ('report','comparison_spec','controller','analysis_source','artifact_helper_source','tool_manifest')]+list(proof['source_maps'].values())
    required.update('prerequisite/'+ref['path'] for ref in proof_refs)
    if manifest['backend'] == 'npu': required.add('driver-version-provenance.json')
    totals = {'targets':0,'distributions':0,'physical':0,'valid':0,'pads':0}; rng_anchor = None
    for plan in inventory['modes']:
        mode = plan['id']; prefix = 'modes/'+mode+'/'; directory = output/'modes'/mode
        required.update(prefix+name for name in ('raw-native-logits.safetensors','events.json','raw-row-inventory.json','capture-summary.json','model-state-after.json','state-control.json'))
        safetensors_header(directory/'raw-native-logits.safetensors',{'logits':plan['raw_logits']['shape']}); raw = file_ref(directory/'raw-native-logits.safetensors')
        events = read(directory/'events.json')
        fixed_event = {'mode':mode,'call_index':0,'use_cache':False,'past_key_values_is_none':True,'logits_to_keep':0,
            'labels_supplied':False,'shared_kv_states_supplied':False,'returned_cache':None,'returned_shared_kv_states':None,
            'native_logits_shape':plan['raw_logits']['shape'],'native_logits_dtype':'torch.bfloat16'}
        require(len(events) == 1 and all(key in events[0] and canonical(events[0][key]) == canonical(value) for key,value in {**plan,**fixed_event}.items()), 'native batch/mask/position event differs')
        row_inventory = read(directory/'raw-row-inventory.json'); counts = row_inventory['pad_only_nonfinite_counts']
        valid = sum(item['sequence_length'] for item in plan['observations']); physical = math.prod(plan['raw_logits']['shape'][:2])
        require(row_inventory.get('raw_logits_sha256') == raw['sha256'] and row_inventory.get('physical_raw_rows') == physical and
            row_inventory.get('valid_raw_rows') == valid and row_inventory.get('valid_nonfinite_coordinates') == 0 and
            row_inventory.get('pad_only_rows') == plan['pad_only_rows'] and counts.get('rows') == len(plan['pad_only_rows']) and
            counts.get('coordinates') == len(plan['pad_only_rows'])*VOCABULARY and
            all(type(counts.get(k)) is int and counts[k] >= 0 for k in ('rows_with_nonfinite','nan','positive_infinity','negative_infinity','nonfinite')) and
            counts['nonfinite'] == counts['nan']+counts['positive_infinity']+counts['negative_infinity'] <= counts['coordinates'] and
            counts['rows_with_nonfinite'] <= counts['rows'], 'valid/pad-only row inventory differs')
        mode_targets, mode_distributions = 0,0
        for observation in plan['observations']:
            name = observation['request']; request = inventory['requests'][name]; sub = directory/('request-'+name)
            names = {'target-scores.json','distributions.json'}|{'dist-p%03d%s'%(item['position'],suffix) for item in observation['distribution_positions'] for suffix in ('.json','.npy')}
            required.update(prefix+'request-'+name+'/'+x for x in names)
            scores_doc = read(sub/'target-scores.json'); scores = scores_doc['scores']
            require(scores_doc.get('task') == TASK and scores_doc.get('mode') == mode and scores_doc.get('request') == name and
                scores_doc.get('raw_logits_sha256') == raw['sha256'] and len(scores) == request['sequence_length']-1, 'request target source/count differs')
            for score,coordinate in zip(scores,observation['all_targets']):
                require(all(key in score and canonical(score[key]) == canonical(value) for key,value in coordinate.items()) and score.get('request') == name and
                    score.get('slot') == observation['slot'] and type(score.get('logprob')) in (int,float) and math.isfinite(score['logprob']) and score['logprob'] <= 0,
                    'request logical/physical target or value differs')
            distributions = read(sub/'distributions.json')
            require(distributions.get('task') == TASK and distributions.get('request') == name and distributions.get('mode') == mode and
                distributions.get('raw_logits_sha256') == raw['sha256'] and len(distributions['positions']) == 47, 'request distribution source/count differs')
            for item,coordinate in zip(distributions['positions'],observation['distribution_positions']):
                p = coordinate['position']; stem = 'dist-p%03d'%p
                require(all(key in item and canonical(item[key]) == canonical(value) for key,value in coordinate.items()) and
                    item.get('record') == stem+'.json' and item.get('scores') == {'path':stem+'.npy','row':0}, 'request distribution logical/physical coordinate differs')
                record = read(sub/item['record'])
                require(record.get('raw_logits_sha256') == raw['sha256'] and record.get('request') == name and record.get('slot') == observation['slot'] and
                    record.get('physical_prediction_position') == observation['physical_offset']+p and record.get('token') == request['input_ids'][p+1] and
                    record.get('target_position') == p+1 and record.get('logprob') == scores[p]['logprob'], 'request row target/provenance differs')
                array = Array(sub,{'path':stem+'.npy'}); require(array.shape == [1,VOCABULARY] and array.dtype == np.dtype('float64'), 'full FP64 row shape/dtype differs')
                values = np.load(sub/(stem+'.npy'),mmap_mode='r',allow_pickle=False)
                try: require(np.isfinite(values).all() and values.max() <= 0 and float(values[0,request['input_ids'][p+1]]) == scores[p]['logprob'], 'retained row values differ')
                finally: values._mmap.close()
            mode_targets += len(scores); mode_distributions += len(distributions['positions'])
        summary = read(directory/'capture-summary.json')
        require(summary.get('mode') == mode and summary.get('native_forward_calls') == 1 and summary.get('raw_logits') == raw and
            summary.get('targets') == mode_targets and summary.get('sampled_distributions') == mode_distributions and
            summary.get('physical_raw_rows') == physical and summary.get('valid_raw_rows') == valid and
            summary.get('pad_only_raw_rows') == len(plan['pad_only_rows']) and summary.get('pad_only_nonfinite_counts') == counts, 'mode native summary differs')
        require(canonical(read(directory/'model-state-after.json')) == canonical(read(output/'loaded-model-state.json')), 'retained persistent model state differs')
        control = read(directory/'state-control.json')
        require(control.get('mode') == mode and control.get('seed_reset',{}).get('seed') == 0 and
            control.get('baseline_model_state_sha256') == sha(output/'loaded-model-state.json') and
            control.get('model_state_after_sha256') == sha(directory/'model-state-after.json') and
            canonical(control['math_policy']) == canonical(read(output/'runtime.json')['math_policy']), 'mode seed/state control chain differs')
        if rng_anchor is None: rng_anchor = control['rng_before']
        require(canonical(control['rng_before']) == canonical(rng_anchor), 'observed before-mode RNG resets differ')
        for key,value in {'targets':mode_targets,'distributions':mode_distributions,'physical':physical,'valid':valid,'pads':len(plan['pad_only_rows'])}.items(): totals[key] += value
    require(set(files) == required and totals == {'targets':762,'distributions':282,'physical':896,'valid':768,'pads':128}, 'I04 exact product/coordinate inventory differs')
    require(len(files) == (621 if manifest['backend'] == 'gpu' else 622), 'I04 recursive file count differs')
    summary = read(output/'capture-summary.json')
    require(summary.get('native_forward_calls_total') == 4 and summary.get('model_loads') == 1 and [x['mode'] for x in summary['modes']] == MODES,
        'I04 aggregate native calls/model loads differ')
    if require_completed:
        status = read(output/'status.json')
        require(status.get('status') == 'completed' and status.get('task') == TASK and status.get('artifacts_manifest_sha256') == sha(output/'artifacts-manifest.json'), 'I04 terminal manifest binding differs')
    return {'status':'i04_output_artifacts_checked','modes':MODES,'native_forward_calls_total':4,'model_loads':1,
        'target_scores':762,'distribution_rows':282,'physical_raw_rows':896,'valid_raw_rows':768,'pad_only_raw_rows':128,
        'artifacts_manifest_sha256':sha(output/'artifacts-manifest.json'),'output_bytes':check_storage(output),
        'native_executions_started_by_validator':0,'numeric_rederivation':'delegated to independent raw-BF16 admission','acceptance':None}

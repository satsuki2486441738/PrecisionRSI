"""CPU-only source/record protocol fixtures; synthetic probe is never evidence."""
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

import observer_cpu_operations_v1 as ops

REPO=Path(__file__).resolve().parents[5]


def fixture(root):
    output=Path(root)/'packet';receipt=ops.build(REPO,output);base=Path(root)/'R';base.mkdir();(base/'runs').mkdir()
    uploaded=base/ops.ARCHIVE;uploaded.write_bytes(Path(receipt['archive']['path']).read_bytes())
    staged=ops.stage(base,uploaded,ops.sha(uploaded),receipt['manifest_sha256'])
    return base,base/ops.SUBDIR,receipt


class Operations(unittest.TestCase):
    def test_actual_five_source_packet_roundtrip_pins_and_exclusive_stage(self):
        with tempfile.TemporaryDirectory() as temporary:
            base,target,receipt=fixture(temporary)
            self.assertEqual(ops.verify_tree(target/'source',target/'source-manifest.json',receipt['manifest_sha256'])['files'][ops.PROBE]['sha256'],ops.FROZEN[ops.PROBE])
            self.assertEqual(ops.read(target/'stage-receipt.json')['source_files'],5)
            self.assertFalse((target/'cpu-attempt-once.json').exists())
            with self.assertRaisesRegex(ValueError,'exclusive'):ops.stage(base,base/ops.ARCHIVE,ops.sha(base/ops.ARCHIVE),receipt['manifest_sha256'])

    def test_changed_frozen_source_rejected_before_attempt(self):
        with tempfile.TemporaryDirectory() as temporary:
            base,target,receipt=fixture(temporary);p=target/'source'/ops.COLLECTOR;p.write_bytes(p.read_bytes()+b'\n# tamper')
            with self.assertRaisesRegex(ValueError,'bytes differ'):ops.verify_tree(target/'source',target/'source-manifest.json',receipt['manifest_sha256'])
            self.assertFalse((target/'cpu-attempt-once.json').exists())

    def test_archive_link_traversal_duplicate_and_size_rejected_before_directory_write(self):
        for bad in ('link','traversal','duplicate','size'):
            with self.subTest(bad=bad),tempfile.TemporaryDirectory() as temporary:
                packet=Path(temporary)/'packet';receipt=ops.build(REPO,packet);base=Path(temporary)/'R';base.mkdir()
                with tarfile.open(receipt['archive']['path'],'r:gz') as package:data=[(x.name,package.extractfile(x).read()) for x in package.getmembers()]
                archive=base/ops.ARCHIVE
                with tarfile.open(archive,'w:gz') as package:
                    for index,(name,raw) in enumerate(data):
                        if index==1 and bad=='traversal':name='source/../escape.py'
                        if index==1 and bad=='duplicate':name=data[0][0]
                        if index==1 and bad=='size':raw=b'x'*(ops.MAX_CODE+1)
                        info=tarfile.TarInfo(name);info.size=len(raw)
                        if index==1 and bad=='link':info.type=tarfile.SYMTYPE;info.linkname='/tmp/escape';info.size=0;raw=b''
                        package.addfile(info,io.BytesIO(raw))
                with self.assertRaises(ValueError):ops.stage(base,archive,ops.sha(archive),receipt['manifest_sha256'])
                self.assertFalse((base/ops.SUBDIR).exists())

    def test_guard_rejects_prefix_escape_and_directory_symlink(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary)/'R';root.mkdir()
            with self.assertRaisesRegex(ValueError,'escapes'):ops.guard(root,root.parent/'R-other/file')
            if os.name=='posix':
                target=root/'link';target.symlink_to(root.parent,target_is_directory=True)
                with self.assertRaises(ValueError):ops.guard(root,target/'outside')

    def test_all_cpu_phase_predicates_allow_imported_but_uninitialized(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder=Path(temporary);artifact=folder/'tiny.safetensors';artifact.write_bytes(b'synthetic fixture, not native tensor')
            record={'status':'completed','returncode':0,'timeout_seconds':90,'source':{'sha256':ops.FROZEN[ops.PROBE]},
                'collectors_source':{'sha256':ops.FROZEN[ops.COLLECTOR]},'agent_hardware_or_availability_queries':0,
                'agent_accelerator_initialization_requests':0,'library_internal_availability_queries':'not instrumented',
                'versions':{'torch':'2.9.0+cpu'},'runtime_sources':{k:{} for k in ('torch','numpy','safetensors','torch_dispatch','module_hooks')},
                'phase_observations':[{'phase':name,'torch_npu_imported':True,'npu_namespace_registered':True,'npu_initialized':False,'cuda_initialized':False}
                    for name in ('after_torch','before_tiny_cpu_calls','after_tiny_cpu_calls')],
                'result':{'checks_passed':29,'checks':['synthetic%d'%i for i in range(29)],'tiny_cpu_forward_calls':5,
                    'production_model_loads':0,'production_model_forward_calls':0,'tiny_boundary_count':4,'production_boundary_count':98,
                    'mode_outputs':[{'mode':mode,'raw_bits_sha256':'a'*64,'artifact':ops.ref(artifact)} for mode in
                        ('off-before','hooks-only','off-after','hooks-plus-dispatch-metadata')],'selected_samples':ops.ref(artifact)}}
            path=folder/'receipt.json';ops.put(path,record);ops.validate_probe(path)
            for mutation in ('initialized','rng_checks','module_flag','output'):
                bad=copy.deepcopy(record)
                if mutation=='initialized':bad['phase_observations'][-1]['npu_initialized']=True
                elif mutation=='rng_checks':bad['result']['checks_passed']=28
                elif mutation=='module_flag':bad['phase_observations'][-1]['torch_npu_imported']='true'
                else:bad['result']['mode_outputs'][-1]['raw_bits_sha256']='b'*64
                path.write_text(json.dumps(bad),'utf8')
                with self.assertRaises(ValueError):ops.validate_probe(path)

    @unittest.skipUnless(os.name=='posix','POSIX run/PG lifecycle only')
    def test_real_child_failure_retains_attempt_and_original_stderr(self):
        with tempfile.TemporaryDirectory() as temporary:
            base,target,receipt=fixture(temporary);source=target/'source'
            # Replace only the synthetic probe within this in-process patched
            # fixture. Production pins/packet above remain untouched.
            probe=source/ops.PROBE;probe.write_text("if __name__=='__main__':raise SystemExit(7)\n",'utf8')
            manifest=target/'source-manifest.json';doc=ops.read(manifest);doc['files'][ops.PROBE]={'sha256':ops.sha(probe),'size_bytes':probe.stat().st_size};manifest.write_text(json.dumps(doc),'utf8')
            spec=importlib.util.spec_from_file_location('synthetic_observer_cpu_operations',source/ops.SELF);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
            with patch.dict(module.FROZEN,{ops.PROBE:ops.sha(probe)}):
                # Pure import checks succeed; the separate actual-probe child
                # exits7 and must preserve its permanent CPU attempt/logs.
                self.assertEqual(module.run(base,ops.sha(manifest)),2)
                with self.assertRaises(FileExistsError):module.run(base,ops.sha(manifest))
            receipts=list((target/'runs').glob('compare-observer-tiny-cpu-*/controller-receipt.json'));self.assertEqual(len(receipts),1)
            actual=ops.read(receipts[0]);self.assertEqual(actual['status'],'failed');self.assertEqual(actual['steps'][0]['returncode'],0)
            self.assertEqual(actual['steps'][1]['returncode'],7);self.assertFalse(actual['steps'][1]['cleanup']['remaining_owned_process_group'])
            self.assertTrue((target/'cpu-attempt-once.json').exists())


if __name__=='__main__':unittest.main()

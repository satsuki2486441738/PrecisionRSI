"""Admit one GPU/NPU P128 pair and run the unchanged Reserved48 CPU reducer."""

SOURCE_SUPPLEMENT_EXECUTION_ENABLED = None
if __name__ == '__main__' and SOURCE_SUPPLEMENT_EXECUTION_ENABLED is not True:
    raise SystemExit('SOURCE_SUPPLEMENT_CPU_REFERENCE_ONLY: inspect the indexed source and review a new execution context')
import argparse
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import signal
import sys
import time
from types import ModuleType


CASE = Path(__file__).resolve().parents[1]
ENDPOINT_SHA = 'ced5aa714d1e967e70f05d4e9d11e628ab58aa9a0a59f45fcf88e22ddd9cbd83'
PROFILES_SHA = '126ea9cc16b4b84fc9593a2c1e9d120236ee392b6e7cd517134be99280a4a9a7'
CONTRACT_V3 = 'd04a4d7ed7c1ff14a0d6ad9e2000afbc8fb32418b26959372b17990bc9d9d32e'
NUMPY_SHA = '22cd1535fa14d74ef6f457cca149ffdc80875f460be313b8f895273f78bc402e'
GPU_ARCHIVE = '23bca2630637c02a0f62e87cc26ddabc34307a570d1184c7abf887dbf7360ab2'
GPU_MAP = '427835676b5abb85b20d1af3af75beb66be3e7a16c7876ac4cefe65d21da2858'
GPU_CONTROLLER = '7537ffa76e6b14d2eeaf1c03c23c3d43d51ce77af48b797f4ce9744dce16c722'
GPU_CAPTURE = 'f218b973f7f2d8cecd2ab0d3b79ef9c34349bb4b948dbd673294341e84755c7b'
GPU_CONFIG = '2042594c51880bc3f3132f1b7577d46773024de1d0f7f5725c012d74fdfa9438'
VERSIONS = {
    'GPU': {'torch': '2.9.0+cu128', 'transformers': '5.10.1', 'cuda_runtime': '12.8', 'numpy': '1.26.4'},
    'NPU': {'torch': '2.9.0+cpu', 'torch_npu': '2.9.0.post2', 'transformers': '5.10.1', 'numpy': '1.26.4',
            'cann': '9.1.0', 'driver': '25.5.2'},
}


def tools():
    import hashlib
    result = []
    for path, pin in ((CASE / 'adapters/reserved48_cpu_profiles_v1.py', PROFILES_SHA),
                      (CASE / 'transfer/reserved48_p128_npu_endpoint_v1.py', ENDPOINT_SHA)):
        if pin is None or path.is_symlink() or path.stat().st_size > 1024**2:
            raise ValueError('reviewed P128 CPU tool gate is unready')
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != pin:
            raise ValueError('reviewed P128 CPU tool bytes differ')
        module = ModuleType(path.stem)
        module.__file__ = str(path)
        exec(compile(raw, str(path), 'exec'), module.__dict__)
        result.append(module)
    return tuple(result)


def imported_gpu(root, profiles, packet):
    require = packet.require
    require(root.resolve(strict=True) == root and root.is_dir(), 'canonical absolute original GPU P128 import required')
    mapping = root / 'source-map.json'
    local_receipt = root / 'import-receipt.json'
    require(packet.regular(mapping).stat().st_size <= packet.MAX_SMALL and packet.sha(mapping) == GPU_MAP,
            'exact imported GPU P128 source map differs')
    mapped = packet.load(mapping)
    imported = packet.load(local_receipt)
    require(imported['archive_sha256'] == GPU_ARCHIVE and imported['source_map_sha256'] == GPU_MAP and
            imported['source_map_path'] == str(mapping) and imported['prompt_bin'] == 128 and
            imported['status'] == 'full_original_byte_packet_verified_numeric_admission_pending' and
            imported['all_mapped_members_SHA_checked'] is True and imported['numeric_admission_performed'] is False and
            imported['native_executions_started'] == 0 and imported['copied_large_objects'] == 36 and
            imported['raw_JSON_paths_rewritten'] is False, 'original verified GPU P128 import receipt differs')
    outer = mapped['request']['outer_receipt']
    claim = profiles.gpu_claim(outer, 128)
    controller = str(claim / 'controller-receipt.json')
    require(mapped['request'] == {'task': 'RESERVED48', 'backend': 'GPU', 'prompt_bin': 128, 'outer_receipt': outer} and
            mapped['numeric_endpoint_eligible'] is True and mapped['metadata_only'] is False and
            mapped['source_capture_sha256'] == mapped['files'][outer]['sha256'] == GPU_CAPTURE and
            mapped['source_controller_sha256'] == mapped['files'][controller]['sha256'] == GPU_CONTROLLER and
            mapped['copied_large_objects'] == mapped['original_selected_native_objects'] == 36 and mapped['omitted_large_objects'] == 0,
            'exact full original GPU P128 endpoint required')
    return {'source_map': packet.ref(mapping), 'receipt': {'source_path': outer, 'sha256': GPU_CAPTURE},
            'controller': {'source_path': controller, 'sha256': GPU_CONTROLLER}, 'import_receipt': packet.ref(local_receipt)}


def retained_npu(receipt_path, receipt_sha, npu):
    p = npu.packet
    p.require(receipt_path.is_absolute() and p.regular(receipt_path).stat().st_size <= p.MAX_SMALL and
              p.sha(receipt_path) == receipt_sha, 'external NPU metadata-stage receipt SHA differs')
    doc = p.load(receipt_path)
    root = receipt_path.parent
    source_map = root / 'source-map.json'
    p.require(doc['status'] == 'npu_p128_retained_endpoint_metadata_staged_array_hash_pending' and
              doc['terminal_query']['sha256'] == npu.QUERY and doc['capture']['sha256'] == npu.CAPTURE and
              doc['controller']['sha256'] == npu.CONTROLLER and doc['config']['sha256'] == npu.CONFIG and
              doc['capture']['path'] == str(npu.ROOT / 'claims' / npu.ALLOCATION / 'capture-receipt.json') and
              doc['config']['path'] == str(npu.ROOT / 'prepared-config.json') and p.regular(source_map).stat().st_size <= p.MAX_SMALL and
              doc['source_map'] == p.ref(source_map) and
              doc['retained_large_objects'] == 36 and doc['large_payload_hashes_checked'] == 0 and
              doc['numeric_admission_performed'] is False and doc['native_executions_started'] == 0,
              'exact staged P128 NPU metadata receipt required')
    query, _, _, _ = npu.terminal(Path(doc['terminal_query']['path']), npu.QUERY)
    p.require(all(doc[a] == query[b] for a, b in (('controller', 'controller_receipt'), ('capture', 'capture_receipt'),
              ('config', 'prepared_config'), ('retained_root', 'output_dir'))), 'retained NPU metadata detached from actual original terminal')
    mapped = p.load(source_map)
    retained = {key for key, item in mapped['files'].items() if item.get('retained_at_source') is True}
    p.require(mapped['request'] == {'task': 'RESERVED48', 'backend': 'NPU', 'prompt_bin': 128,
              'outer_receipt': doc['capture']['path']} and mapped['raw_bytes_preserved'] is True and
              len(retained) == mapped['retained_large_objects'] == 36 and all(
                  key.endswith('/selected-native-logits.safetensors') and
                  PurePosixPath(key).is_relative_to(doc['retained_root']) and 'path' not in mapped['files'][key] for key in retained),
              'exact retained original NPU matrix map required')
    return {'source_map': doc['source_map'], 'receipt': {'source_path': doc['capture']['path'], 'sha256': npu.CAPTURE},
            'controller': {'source_path': doc['controller']['path'], 'sha256': npu.CONTROLLER},
            'retained_root': doc['retained_root']}, doc


class Route:
    def __init__(self, profiles, npu, endpoints):
        self.profiles, self.npu, self.endpoints = profiles, npu, endpoints
        self.base = profiles.original_helper()
        self.checked = []
        self.inventory = None
        self.budget_sha = None

    def __getattr__(self, name):
        return getattr(self.base, name)

    def read(self, ref, expected):
        raw = self.profiles.bound(ref, expected)
        self.checked.append(ref)
        return raw

    def source_inputs(self, config):
        p, npu, profiles = self.npu.packet, self.npu, self.profiles
        refs = {k: config[k] for k in ('stage_spec', 'expected_inventory', 'expected_builder', 'budget', 'manifest', 'prerequisite')}
        pins = {'stage_spec': p.STAGE_SHA, 'expected_inventory': p.EXPECTED_SHA,
                'expected_builder': profiles.PROFILES['gpu-v3']['expected_builder'], 'budget': p.NATIVE_BUDGET_SHA,
                'manifest': self.base.MANIFEST_SHA, 'prerequisite': profiles.NATIVE_PROOF_SHA}
        contents = {k: self.read(ref, pins[k]) for k, ref in refs.items()}
        p.require(all(Path(ref['path']).is_relative_to(npu.ROOT / 'source') for ref in refs.values()), 'frozen NPU input source escapes deployment')
        builder = profiles.checked_module(Path(refs['expected_builder']['path']), pins['expected_builder'], '_p128_expected_geometry')
        self.inventory = builder.derive(refs['manifest']['path'], config['input_dir'], p.STAGE_SHA)
        p.require(self.inventory == self.base.parse(contents['expected_inventory']), 'independent frozen P128 geometry differs')
        for row in self.inventory['samples']:
            path = Path(config['input_dir']) / self.base.safe_relative(row['input_file'])
            raw = profiles.meta_bytes(path, row['input_sha256'])
            self.checked.append({'path': str(path), 'sha256': row['input_sha256'], 'size_bytes': len(raw)})
        contract = profiles.checked_module(CASE / 'transfer/reserved48_stage_contract_v2.py', profiles.CONTRACT_CHECKER_SHA, '_p128_cpu_proof')
        proof = contract.prerequisite(refs['prerequisite']['path'], profiles.NATIVE_PROOF_SHA)
        p.require(proof['native_executions_started'] == 0, 'portable prerequisite is precondition only')
        self.checked.extend(proof['refs'].values())
        cpu_prerequisite = Path(refs['prerequisite']['path']).parent / 'cpu/prerequisite.json'
        cpu_proof = p.ref(cpu_prerequisite)
        self.read(cpu_proof, profiles.CPU_PROOF_SHA)
        request = {k: refs[k] for k in ('stage_spec', 'expected_inventory', 'expected_builder', 'manifest')}
        request.update(native_budget=refs['budget'], native_prerequisite=refs['prerequisite'], cpu_prerequisite=cpu_proof)
        return request, contract.proposed_cpu_budget(p.STAGE_SHA)

    def admit_endpoint(self, endpoint, inventory, stage_sha, expected_sha):
        side = endpoint.backend
        p, npu, profiles = self.npu.packet, self.npu, self.profiles
        p.require(endpoint.prompt_bin == 128 and endpoint.info == self.endpoints[side] and inventory is self.inventory and
                  stage_sha == p.STAGE_SHA and expected_sha == p.EXPECTED_SHA, 'only the pre-bound P128 endpoint may be admitted')
        helper = profiles.original_helper()
        helper.GATES.update(stage_sha256=stage_sha, expected_inventory_sha256=expected_sha,
            budget_sha256=self.budget_sha, native_budget_sha256=p.NATIVE_BUDGET_SHA,
            cpu_prerequisite_sha256=profiles.CPU_PROOF_SHA, cpu_prerequisite_checker_sha256=profiles.CPU_CHECKER_SHA,
            native_prerequisite_sha256=profiles.NATIVE_PROOF_SHA, native_prerequisite_checker_sha256=profiles.CONTRACT_CHECKER_SHA,
            expected_builder_sha256=profiles.PROFILES['gpu-v3']['expected_builder'], native_endpoint_schema_reviewed=True)
        source_pins = profiles.source_pins('gpu-v3')
        config_sha = GPU_CONFIG
        if side == 'NPU':
            config_sha = npu.CONFIG
            source_pins = dict(source_pins, lifecycle=npu.LAUNCHER, contract=CONTRACT_V3)
        helper.SOURCE_PINS[side].update(source_pins)
        helper.ENDPOINT_PINS[side]['128'].update(source_map=endpoint.info['source_map']['sha256'],
            receipt=endpoint.info['receipt']['sha256'], controller=endpoint.info['controller']['sha256'], prepared_config=config_sha)
        helper.activation_ready()
        result = helper.admit_endpoint(endpoint, inventory, stage_sha, expected_sha)
        p.require(result['runtime']['versions'] == VERSIONS[side], 'original backend software tuple differs')
        return result

    def recheck(self):
        for ref in {item['path']: item for item in self.checked}.values():
            self.profiles.bound(ref)


def execute(args):
    started = time.monotonic()
    profiles, npu = tools()
    p = npu.packet
    p.require(sys.platform.startswith('linux') and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and
              not any(name in sys.modules for name in ('numpy', 'torch', 'torch_npu', 'transformers')),
              'fresh isolated Linux CPU process required before admission')
    workspace = args.workspace
    p.require(workspace.is_absolute() and workspace.parent.resolve(strict=True) == workspace.parent and
              re.fullmatch(r'compare-reserved48-p128-cross-\d{8}T\d{6}Z', workspace.name) and
              not workspace.exists() and not workspace.is_symlink() and not workspace.is_relative_to(npu.ROOT) and
              shutil.disk_usage(workspace.parent).free >= 96 * p.GIB,
              'canonical exclusive CPU output with actual96GiB free required')
    gpu = imported_gpu(args.gpu_import, profiles, p)
    asc, metadata = retained_npu(args.npu_metadata_receipt, args.npu_metadata_receipt_sha256, npu)
    route = Route(profiles, npu, {'GPU': gpu, 'NPU': asc})
    route.checked.extend([gpu['source_map'], gpu['import_receipt'], asc['source_map'],
                          p.ref(args.npu_metadata_receipt), metadata['terminal_query']])
    config = route.base.parse(route.read(metadata['config'], npu.CONFIG))
    request, budget = route.source_inputs(config)
    p.require(not any(name in sys.modules for name in ('numpy', 'torch', 'torch_npu', 'transformers')),
              'P128 metadata gates imported a numerical or model runtime')
    numpy_init = args.numpy_site / 'numpy/__init__.py'
    p.require(args.numpy_site.is_absolute() and args.numpy_site.resolve(strict=True) == args.numpy_site and
              p.sha(numpy_init) == NUMPY_SHA, 'actual existing CPU NumPy init provenance differs')
    sys.path.insert(0, str(args.numpy_site))
    np, _ = route.libraries()
    p.require(np.__version__ == '1.26.4' and Path(np.__file__).resolve() == numpy_init, 'CPU NumPy version or import path differs')
    workspace.mkdir(mode=0o700)
    budget_path = workspace / 'reviewed-cpu-budget.json'
    p.put(budget_path, budget)
    request['budget'] = p.ref(budget_path)
    request['cpu_workspace_root'] = str(workspace)
    route.budget_sha = request['budget']['sha256']
    request['coverage'] = {side: {str(b): {'status': 'blocked', 'reason': 'Outside scoped P128 paired comparison.'}
        for b in route.base.BINS} for side in ('GPU', 'NPU')}
    for side in route.endpoints:
        request['coverage'][side]['128'] = {'status': 'completed', 'reason': 'Verified source terminal pending numeric admission.',
                                            'endpoint': route.endpoints[side]}
    p.put(workspace / 'request.json', request)
    reducer = profiles.checked_module(CASE / 'adapters/derive_compare_reserved48_cpu_v2.py', profiles.REDUCER_SHA,
                                      '_p128_unchanged_cpu_reducer', route)
    ref = reducer.run_bin(request, route.inventory, 128, workspace / 'p0128')
    report = p.load(ref['path'])
    p.require(report['status'] == 'completed' and report['native_observations'] == report['new_FP64_matrices'] == 72 and
              report['input_pairs'] == 108 and report['distribution_pair_positions'] == 5076 and
              report['available_backends'] == ['GPU', 'NPU'] and report['acceptance'] is None and
              report['full_cohort_NLL'] is None, 'exact completed paired P128 numerical scope required')
    route.recheck()
    p.require(p.sha(numpy_init) == NUMPY_SHA and not any(name in sys.modules for name in ('torch', 'torch_npu', 'transformers')),
              'CPU provenance changed or a native model runtime was imported')
    result = {'status': 'completed_scoped_p128_pair', 'native_executions_started': 0, 'report': ref,
              'request': p.ref(workspace / 'request.json'), 'numpy_init': p.ref(numpy_init),
              'npu_metadata_stage': p.ref(args.npu_metadata_receipt), 'gpu_import': gpu['import_receipt'],
              'planned_articles': 48, 'paired_articles': 12, 'matched_cross_backend_input_pairs': 36,
              'within_backend_input_pairs': 72, 'distribution_pair_positions': 5076,
              'full48_cohort_complete': False, 'acceptance': None, 'cpu_elapsed_seconds': time.monotonic() - started}
    p.put(workspace / 'comparison-receipt.json', result)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for key in ('workspace', 'gpu-import', 'npu-metadata-receipt', 'numpy-site'):
        p.add_argument('--' + key, type=Path, required=True)
    p.add_argument('--npu-metadata-receipt-sha256', required=True)
    args = p.parse_args()

    def expire(*_):
        raise TimeoutError('scoped P128 CPU work exceeded3580s')

    previous = signal.signal(signal.SIGALRM, expire)
    signal.setitimer(signal.ITIMER_REAL, 3580)
    try:
        print(json.dumps(execute(args), indent=2))
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous)


if __name__ == '__main__':
    main()

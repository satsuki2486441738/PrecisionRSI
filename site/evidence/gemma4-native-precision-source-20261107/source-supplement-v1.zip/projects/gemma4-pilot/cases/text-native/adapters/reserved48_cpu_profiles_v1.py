"""Verified per-bin provenance for the existing reserved48 CPU reducers."""

SOURCE_SUPPLEMENT_EXECUTION_ENABLED = None
if __name__ == '__main__' and SOURCE_SUPPLEMENT_EXECUTION_ENABLED is not True:
    raise SystemExit('SOURCE_SUPPLEMENT_CPU_REFERENCE_ONLY: inspect the indexed source and review a new execution context')
import builtins
import hashlib
from pathlib import Path, PurePosixPath
import re
import sys
from types import ModuleType


HERE = Path(__file__).resolve().parent
CASE = HERE.parent
BINS = (128, 512, 2048, 8192)
SIDES = ('GPU', 'NPU')
TASK = 'gemma4-reserved48-i05-q01-v1'
KIND = 'reserved48-common-cpu-mixed-request-v3'
HELPER_SHA = 'ab2c1890fb80f4be07bed6f25d0b22caef48d0a19ebaa51deb5b3b1864e005e4'
REDUCER_SHA = '99e021def9ebdc50c6cea02b1daaf368e1797c8f352b398ceac67933bebafd10'
NATIVE_PROOF_SHA = '7acedd06be98e639efb308fbaca4caafb27cc17ad6cb14022e3932c6283020e8'
CPU_PROOF_SHA = '5f798c29e0cbe28d0f17869e49774631c51b2f4d01ad8cbd6195ef3844cc4f07'
CONTRACT_CHECKER_SHA = '924fc9dda795fe66c0ffc047a3b158289b2baac50a91c220f9991d899390ddc5'
CPU_CHECKER_SHA = '5b6d11ce989e84c3d777f0136fd3e74c5ac410f66bb78f35ea3fb6c317e9bdcd'
RECOVERY_CHECKER_SHA = '761e69d06fa667683667734eb71faab457c659a12884fa005f185afbe9d57df9'
RECOVERY_PROOF_SHA = 'b6179d53ba1187ddd647e12fd4cfd10ffc9aab1813786c5d4d8d8154bb6e922c'
RECOVERY_PLATFORM_SHA = 'e0934963ce35ddd01081a70b2a080837edefc0b22a0c06c52ea95185d24a8953'
RECOVERY_APP = 'REDACTED_APP_ID'
RECOVERY_FAILURE_SHA = '03667d1bbf8efdb0afb0d32846b96d7f71b003adb35ce199e79a7ffa243967da'
RECOVERY_PROGRESS_SHA = 'bc6af9d7cf65dc6f9ccdb6386f8fe2e49e70429bc1f32b2e0514294773a09839'
RECOVERY_STOPPED_SHA = '68feb221a2be232bf9bbfda7e163cb590ae430f9daa2147f7bb2085306becf29'
RECOVERY_SOURCE = 'projects/gemma4-pilot/cases/text-native/prerequisites/reserved48-p8192-recovery-v1'
RECOVERY_CHECKER = 'projects/gemma4-pilot/cases/text-native/transfer/check_reserved48_p8192_recovery_v1.py'
GPU_BASE = '/srv/precision-task/reserved48-i05-q01-20261107/gpu'
CONFIG = {128: '2042594c51880bc3f3132f1b7577d46773024de1d0f7f5725c012d74fdfa9438',
          512: 'dfa3f6f9077c40fe087602ff783185a3b1f3ba03ba5a73053d901ea60ab7660e',
          2048: 'fa30b5aa8231da46fba76335ab3abf2a15361d497ee2176a4d9b2871117b06a1',
          8192: 'fbe90f3e394f93a93a56c83f2a8a0e99cde74aa6b4a05dc38875300d55240c76'}
PROFILES = {
    'gpu-v3': {
        'stage_spec': '4f6ae6ed0b342b508ab90cdb32049797d8fcc4e1350fc8ac679215d5dcc0d46f',
        'expected_inventory': '1c2638d2e678dc198ffc04f58d38be96a82c1531449fd5c06a572eb1bd21c14f',
        'native_budget': 'd59a153ec73139a6c7bfcb1cf2d6e39d59fe03f56c6bae3ed464588d3dc26391',
        'expected_builder': '23884241df4d7f4280e47788b4203e5a48c70c6e9d98ba112c4c5177d7cf21ae',
        'sources': {'collector': 'a8fcf3a4d2d806be4cbad174115119bb0f2c2b481833808858da2c9332349229',
                    'common': 'c89e9fa0780a9de74362f23ea54ddc8657c99f598a80c15c4331000954ba40c7',
                    'lifecycle': 'a12f1f752c2db8b21d186893abb7499761be18d1655927af4e962099db10a1da',
                    'contract': 'd04a4d7ed7c1ff14a0d6ad9e2000afbc8fb32418b26959372b17990bc9d9d32e'}},
    'gpu-recovery-v4': {
        'stage_spec': 'e5879c5f0dd704170937079652509003dd27cc683cbe1ad81abe5d3e3fb22335',
        'expected_inventory': '224f304ffa6bb1d361e97685f48a48d939fc3fdb9c82de81c70619096c61f1ce',
        'native_budget': 'bd6ace2f0f844fdac550cd0a5b9922c991dd2a17a00511b6efdbb50ec3ad7bde',
        'expected_builder': 'ec760c13c78050cc227af97037e875597e97443b1355b6f2d634138d91adf5c0',
        'sources': {'collector': '14fc76f3fe9e8946770957a456e6cc86741c6324ee3c0bcc9f7f087943c34caa',
                    'common': 'e90e02ec71304555ebce7ddab7f1c8c08cc2028570745249a8e9bbcbfa73023f',
                    'lifecycle': 'bace6e5d9fbaeff1d530f9e31b2fc6ed03573b529e0341a66812aa1de6b2ebca',
                    'contract': 'd9f4bf7ed10afe8bb479ef34f0a7f3c1e6379211b5dcb00d80d29c325d0d8c12'}}}
PROFILE_FIELDS = ('stage_spec', 'expected_inventory', 'native_budget', 'expected_builder')
META_CAP = 16 * 1024**2
HEX = re.compile(r'[0-9a-f]{64}')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def meta_bytes(path, pin=None, size=None):
    path = Path(path)
    require(path.is_absolute() and path.suffix in ('.json', '.jsonl', '.py', '.txt', '.stdout', '.stderr', '.bin') and
            path.is_file() and not any(p.is_symlink() for p in (path, *path.parents)),
            'bounded regular metadata path required')
    length = path.stat().st_size
    require(length <= META_CAP and (size is None or type(size) is int and size == length), 'metadata size differs')
    with path.open('rb') as stream:
        raw = stream.read(length + 1)
    require(len(raw) == length and (pin is None or digest(raw) == pin), 'metadata bytes differ')
    return raw


def bound(value, pin=None):
    require(type(value) is dict and set(value) == {'path', 'sha256', 'size_bytes'} and
            type(value['sha256']) is str and HEX.fullmatch(value['sha256']) and
            (pin is None or value['sha256'] == pin), 'exact metadata reference/SHA required')
    return meta_bytes(value['path'], value['sha256'], value['size_bytes'])


def checked_module(path, pin, name, artifacts=None):
    """Load approved bytes into a private module namespace with no sys.modules edits."""
    raw = meta_bytes(path, pin)
    module = ModuleType(name)
    module.__file__ = str(path)
    if artifacts is not None:
        def import_dependency(name, globals=None, locals=None, fromlist=(), level=0):
            if level == 0 and name == 'reserved48_cpu_artifacts_v2':
                return artifacts
            return builtins.__import__(name, globals, locals, fromlist, level)
        module.__dict__['__builtins__'] = dict(vars(builtins), __import__=import_dependency)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def original_helper():
    return checked_module(HERE / 'reserved48_cpu_artifacts_v2.py', HELPER_SHA, '_mixed_reserved48_artifacts')


def geometry(document):
    """The execution stage token is the sole allowed inventory difference."""
    require(type(document['stage_spec_sha256']) is str and HEX.fullmatch(document['stage_spec_sha256']) and
            document['schema_version'] == 2 and document['native_capture_schema_version'] == 2 and
            document['native_progress']['schema_version'] == 1 and len(document['samples']) == 48 and
            len({row['sample'] for row in document['samples']}) == 48 and len(document['pairs_per_input']) == 9 and
            document['counts']['pairs_total'] == 432, 'exact independent 48-input / 432-pair inventory required')
    return {key: value for key, value in document.items() if key != 'stage_spec_sha256'}


def profile_id(side, prompt_bin):
    require(side == 'GPU' and prompt_bin in BINS, 'completed backend/bin has no reviewed source profile')
    return 'gpu-recovery-v4' if prompt_bin == 8192 else 'gpu-v3'


def task_root(prompt_bin):
    return GPU_BASE + '/p%04d-v%d' % (prompt_bin, 2 if prompt_bin == 8192 else 1)


def gpu_claim(receipt, prompt_bin):
    path = PurePosixPath(receipt)
    parent = path.parent
    require(str(path) == receipt and path.name == 'capture-receipt.json' and
            parent.parent == PurePosixPath(task_root(prompt_bin)) / 'claims' and
            re.fullmatch(r'app-[a-z0-9]{8}', parent.name), 'original capture is outside its reviewed GPU bin namespace')
    if prompt_bin == 8192:
        require(parent.name == RECOVERY_APP, 'only the actual fresh recovery allocation can complete GPU P8192')
    return parent


def source_pins(profile):
    fields = PROFILES[profile]
    return dict(fields['sources'], expected=fields['expected_builder'])


class Plan:
    def __init__(self, path, pin):
        self.base = original_helper()
        require(not any(name in sys.modules for name in ('numpy', 'torch', 'torch_npu', 'transformers')),
                'verify mixed provenance before numeric imports')
        raw = meta_bytes(path, pin)
        doc = self.base.parse(raw)
        require(set(doc) == {'schema_version', 'kind', 'task', 'coverage', 'profile_files', 'budget', 'manifest',
                             'input_dir', 'cpu_prerequisite', 'native_prerequisite', 'cpu_workspace_root',
                             'prior_interruption', 'recovery_stopped_ui'} and doc['schema_version'] == 3 and doc['kind'] == KIND and
                doc['task'] == TASK and pin == digest(raw), 'exact externally pinned mixed CPU request required')
        self.request_ref = {'path': str(Path(path)), 'sha256': pin, 'size_bytes': len(raw)}
        self.checked = [self.request_ref]
        self.request = doc
        self.base.check_coverage(doc)
        self.recovery_failure = self.validate_recovery_failure(doc['coverage']['GPU']['8192'], doc['recovery_stopped_ui'])
        self.endpoints = {}
        for side in SIDES:
            for prompt_bin in BINS:
                item = doc['coverage'][side][str(prompt_bin)]
                if item['status'] == 'completed':
                    self.endpoints[side, prompt_bin] = self.validate_packet(side, prompt_bin, item['endpoint'])

        contract = checked_module(CASE / 'transfer/reserved48_stage_contract_v2.py', CONTRACT_CHECKER_SHA, '_mixed_proof_contract')
        cpu = checked_module(CASE / 'transfer/export_reserved48_cpu_proof_v1.py', CPU_CHECKER_SHA, '_mixed_cpu_proof')
        for field, expected, module in (('cpu_prerequisite', CPU_PROOF_SHA, cpu),
                                        ('native_prerequisite', NATIVE_PROOF_SHA, contract)):
            self.read(doc[field], expected)
            proof = module.prerequisite(doc[field]['path'], expected)
            require(proof['native_executions_started'] == 0, 'portable precondition scope differs')
            self.checked.extend(proof['refs'].values())
        self.read(doc['manifest'], self.base.MANIFEST_SHA)
        require(self.base.parse(self.read(doc['budget'])) == contract.proposed_cpu_budget(PROFILES['gpu-v3']['stage_spec']),
                'reviewed common CPU budget differs')

        require(set(doc['profile_files']) == set(PROFILES), 'both reviewed v3/v4 source profile closures required')
        self.inventory = None
        self.geometry_sha = None
        for name, profile in PROFILES.items():
            refs = doc['profile_files'][name]
            require(set(refs) == set(PROFILE_FIELDS), 'source profile metadata fields differ')
            for field in PROFILE_FIELDS:
                self.read(refs[field], profile[field])
            expected = checked_module(Path(refs['expected_builder']['path']), profile['expected_builder'], '_mixed_expected_' + name)
            generated = expected.derive(doc['manifest']['path'], doc['input_dir'], profile['stage_spec'])
            require(generated == self.base.parse(self.read(refs['expected_inventory'])), 'independent expected inventory differs')
            value = digest(self.base.canonical(geometry(generated)).encode())
            if self.inventory is None:
                self.inventory, self.geometry_sha = generated, value
            else:
                require(value == self.geometry_sha, 'v4 changed inventory geometry beyond the stage token')
            for prompt_bin in BINS:
                self.base.expected_rows(generated, prompt_bin)
        self.request = dict(doc, **doc['profile_files']['gpu-v3'], source_maps={side: {
            str(prompt_bin): item['endpoint'] for prompt_bin in BINS
            if (item := doc['coverage'][side][str(prompt_bin)])['status'] == 'completed'} for side in SIDES})
        for row in self.inventory['samples']:
            path = Path(doc['input_dir']) / self.base.safe_relative(row['input_file'])
            raw = meta_bytes(path, row['input_sha256'])
            self.checked.append({'path': str(path), 'sha256': row['input_sha256'], 'size_bytes': len(raw)})

        self.checker = checked_module(CASE / 'transfer' / Path(RECOVERY_CHECKER).name,
                                      RECOVERY_CHECKER_SHA, '_mixed_recovery_proof')
        refs = doc['prior_interruption']
        require(set(refs) == {'controller', 'progress', 'stopped_ui'}, 'the old GPU P8192 failure must be retained')
        self.prior = self.checker.document(*(self.read(refs[name]) for name in ('controller', 'progress', 'stopped_ui')))
        require(digest(self.checker.encoded(self.prior)) == RECOVERY_PROOF_SHA, 'original recovery precondition differs')
        require(not any(name in sys.modules for name in ('numpy', 'torch', 'torch_npu', 'transformers')),
                'provenance imported a numeric or model runtime')

    def read(self, value, pin=None):
        raw = bound(value, pin)
        self.checked.append(value)
        return raw

    def validate_recovery_failure(self, item, stopped_ref):
        require(item['status'] == 'failed' and 'failure_evidence' in item,
                'actual GPU P8192 recovery must remain a failed coverage cell')
        evidence = item['failure_evidence']
        claim = task_root(8192) + '/claims/' + RECOVERY_APP
        controller_path = claim + '/controller-receipt.json'
        progress_path = claim + '/native-progress.jsonl'
        require(evidence['controller_source_path'] == controller_path and evidence['progress_source_path'] == progress_path,
                'actual recovery failure source namespace differs')
        controller_ref = evidence['files'][controller_path]
        progress_ref = evidence['files'][progress_path]
        controller = self.base.parse(self.read(controller_ref, RECOVERY_FAILURE_SHA))
        require(controller['task'] == 'RESERVED48' and controller['backend'] == 'GPU' and controller['prompt_bin'] == 8192 and
                controller['status'] == 'cleanup_failed' and controller['returncode'] == 1 and
                controller['timed_out'] is False and controller['timeout_observations']['outer_controller_deadline'] is False and
                controller['remaining_descendants'] == [142] and controller['automatic_retry'] is False and
                controller['wall_seconds'] == 1054.5087545919232 and 'capture_receipt' not in controller and
                controller['progress_diagnostic']['source'] == {'path': progress_path, 'sha256': RECOVERY_PROGRESS_SHA,
                    'size_bytes': progress_ref['size_bytes']}, 'actual second interruption controller differs')
        records = [self.base.parse(line) for line in self.read(progress_ref, RECOVERY_PROGRESS_SHA).splitlines()]
        returns = [record for record in records if record['event'] == 'forward_returned']
        completed = sum(record['event'] == 'mode_capture_completed' for record in records)
        require(len(records) == 1399 and len(returns) == 341 and completed == 15 and
                returns[-1]['sample'] == 'wikitext2-reserved-doc-042' and returns[-1]['mode'] == 'full' and
                not any(record['event'] == 'terminal' for record in records), 'actual recovery progress markers differ')
        observed = self.base.parse(self.read(stopped_ref, RECOVERY_STOPPED_SHA))
        fields = [line.strip() for line in observed['row'].splitlines()]
        require(fields.count(RECOVERY_APP) == 1 and '0/1' in fields and '已停止' in fields,
                'actual recovery STOPPED observation differs')
        return {'controller': controller_ref, 'progress': progress_ref, 'stopped_ui': stopped_ref,
                'source_controller_path': controller_path, 'source_progress_path': progress_path,
                'controller_status': controller['status'], 'controller_wall_seconds': controller['wall_seconds'],
                'outer_timeout': False, 'remaining_descendants_reported': controller['remaining_descendants'],
                'platform_observed_utc': observed['observed_utc'], 'platform_observed_stopped': '0/1',
                'progress_event_count': len(records), 'forward_return_markers': len(returns),
                'completed_mode_markers': completed, 'last_forward_return': returns[-1],
                'terminal_capture_receipt_exists': False, 'numeric_observations_admitted': 0,
                'unexecuted_cells_inferred': False, 'interruption_cause': None}

    def validate_packet(self, side, prompt_bin, info):
        name = profile_id(side, prompt_bin)
        require(prompt_bin != 8192 or RECOVERY_FAILURE_SHA is None,
                'actual GPU P8192 recovery is diagnostic-only after its failed terminal')
        require(set(info) == {'source_map', 'receipt', 'controller', 'import_receipt'},
                'explicit full import, map, capture and controller required')
        for field in ('receipt', 'controller'):
            value = info[field]
            require(set(value) == {'source_path', 'sha256'} and type(value['sha256']) is str and
                    HEX.fullmatch(value['sha256']), 'external original receipt pin required')
        claim = gpu_claim(info['receipt']['source_path'], prompt_bin)
        require(info['controller']['source_path'] == str(claim / 'controller-receipt.json'), 'controller and capture are not siblings')
        document = self.base.parse(self.read(info['source_map']))
        require(document['schema_version'] == 1 and document['request'] == {'task': 'RESERVED48', 'backend': side,
            'prompt_bin': prompt_bin, 'outer_receipt': info['receipt']['source_path']} and
            document['metadata_only'] is False and document['numeric_endpoint_eligible'] is True and
            document['copied_large_objects'] == document['original_selected_native_objects'] == 36 and
            document['omitted_large_objects'] == 0 and document['raw_bytes_preserved'] is True and
            document['source_stage_sha256'] == PROFILES[name]['stage_spec'] and
            document['source_expected_sha256'] == PROFILES[name]['expected_inventory'], 'actual full GPU source map required for this profile')
        for field in ('receipt', 'controller'):
            require(document['files'][info[field]['source_path']]['sha256'] == info[field]['sha256'], 'packet original receipt pin differs')
        require(document['source_capture_sha256'] == info['receipt']['sha256'] and
                document['source_controller_sha256'] == info['controller']['sha256'], 'packet terminal reference differs')
        matrices = [value for key, value in document['files'].items() if key.endswith('/selected-native-logits.safetensors')]
        require(len(matrices) == 36 and all('path' in value and not value.get('retained_at_source') and
                not value.get('omitted_large') for value in matrices) and len({value['path'] for value in matrices}) == 36,
                'exact 36 distinct copied original matrices required')
        imported = self.base.parse(self.read(info['import_receipt']))
        require(imported['schema_version'] == 1 and imported['status'] == 'full_original_byte_packet_verified_numeric_admission_pending' and
                imported['prompt_bin'] == prompt_bin and imported['source_map_sha256'] == info['source_map']['sha256'] and
                imported['source_map_path'] == info['source_map']['path'] and imported['copied_large_objects'] == 36 and
                imported['all_mapped_members_SHA_checked'] is True and imported['raw_JSON_paths_rewritten'] is False and
                imported['native_executions_started'] == 0 and imported['numeric_admission_performed'] is False,
                'completed local full-packet import receipt required')
        return {'profile': name, 'source_pins': source_pins(name), 'prepared_config_sha256': CONFIG[prompt_bin],
                'task_root': task_root(prompt_bin), 'packet': info, 'profile_refs': self.request['profile_files'][name]}

    def scope(self, side, prompt_bin, failure_controller=None):
        helper = original_helper()
        if failure_controller is not None:
            helper.ENDPOINT_PINS[side][str(prompt_bin)]['controller'] = failure_controller
            return helper
        endpoint = self.endpoints[side, prompt_bin]
        refs, info = endpoint['profile_refs'], endpoint['packet']
        helper.GATES.update(stage_sha256=refs['stage_spec']['sha256'], expected_inventory_sha256=refs['expected_inventory']['sha256'],
            budget_sha256=self.request['budget']['sha256'], native_budget_sha256=refs['native_budget']['sha256'],
            cpu_prerequisite_sha256=CPU_PROOF_SHA, cpu_prerequisite_checker_sha256=CPU_CHECKER_SHA,
            native_prerequisite_sha256=NATIVE_PROOF_SHA, native_prerequisite_checker_sha256=CONTRACT_CHECKER_SHA,
            expected_builder_sha256=refs['expected_builder']['sha256'], native_endpoint_schema_reviewed=True)
        helper.SOURCE_PINS[side].update(endpoint['source_pins'])
        helper.ENDPOINT_PINS[side][str(prompt_bin)].update(source_map=info['source_map']['sha256'],
            receipt=info['receipt']['sha256'], controller=info['controller']['sha256'], prepared_config=CONFIG[prompt_bin])
        helper.activation_ready()
        return helper

    def admit_endpoint(self, endpoint, inventory, stage_sha, expected_sha):
        """Route v2's common inventory arguments into the verified endpoint scope."""
        require(inventory is self.inventory and stage_sha == PROFILES['gpu-v3']['stage_spec'] and
                expected_sha == PROFILES['gpu-v3']['expected_inventory'], 'unexpected caller geometry or common binding')
        side, prompt_bin = endpoint.backend, endpoint.prompt_bin
        provenance = self.endpoints[side, prompt_bin]
        require(endpoint.info == provenance['packet'], 'endpoint changed after plan validation')
        helper = self.scope(side, prompt_bin)
        outer_path = endpoint.info['receipt']['source_path']
        claim = gpu_claim(outer_path, prompt_bin)
        outer = endpoint.json(outer_path, endpoint.info['receipt']['sha256'])
        require(PurePosixPath(helper.origin(outer['output_dir'])).is_relative_to(PurePosixPath(provenance['task_root']) / 'runs'),
                'native output escapes reviewed bin namespace')
        claim_doc = endpoint.json(str(claim / 'claim.json'))
        config_ref = claim_doc['config']
        require(config_ref['path'] == provenance['task_root'] + '/prepared-config.json' and
                config_ref['sha256'] == CONFIG[prompt_bin], 'prepared config is outside the exact profile')
        config = endpoint.json(config_ref['path'], config_ref['sha256'])
        if prompt_bin == 8192:
            self.verify_recovery(endpoint, outer, claim_doc, config)
        refs = provenance['profile_refs']
        return helper.admit_endpoint(endpoint, inventory, refs['stage_spec']['sha256'], refs['expected_inventory']['sha256'])

    def verify_recovery(self, endpoint, outer, claim_doc, config):
        require(claim_doc['allocation_id'] == RECOVERY_APP and
                claim_doc['allocation_source']['sha256'] == RECOVERY_PLATFORM_SHA and
                claim_doc['allocation_source']['path'] == task_root(8192) + '/platform-allocation-source.json',
                'recovery is detached from the observed fresh app')
        endpoint.bound_ref(claim_doc['allocation_source'])
        source = task_root(8192) + '/source/'
        manual = config['manual_recovery']
        require(manual['limits'] == self.checker.budget() and manual['checker']['path'] == source + RECOVERY_CHECKER and
                manual['checker']['sha256'] == RECOVERY_CHECKER_SHA and
                manual['precondition']['path'] == source + RECOVERY_SOURCE + '/prerequisite.json' and
                manual['precondition']['sha256'] == RECOVERY_PROOF_SHA, 'new manual recovery config differs')
        for value in (manual['checker'], manual['precondition']):
            endpoint.bound_ref(value)
            require(outer['source_sha256'][value['path']] == value['sha256'], 'manual precondition missing from frozen capture source')
        for value in self.prior['refs'].values():
            original = source + RECOVERY_SOURCE + '/' + value['path']
            endpoint.bound_ref({'path': original, 'sha256': value['sha256'], 'size_bytes': value['size_bytes']})
            require(outer['source_sha256'][original] == value['sha256'], 'prior attempt bytes missing from recovery source')

    def inspect_failure_evidence(self, audit, item, rows, side, prompt_bin):
        evidence = item.get('failure_evidence')
        if evidence is None:
            return self.base.inspect_failure_evidence(audit, item, rows, side, prompt_bin)
        original = evidence['controller_source_path']
        if side == 'GPU':
            gpu_claim(str(PurePosixPath(original).parent / 'capture-receipt.json'), prompt_bin)
        require(PurePosixPath(original).name == 'controller-receipt.json', 'exact original failure controller required')
        helper = self.scope(side, prompt_bin, evidence['files'][original]['sha256'])
        return helper.inspect_failure_evidence(audit, item, rows, side, prompt_bin)

    def bin_binding(self, prompt_bin):
        require(prompt_bin in BINS, 'explicit prompt bin required')
        return {'geometry_sha256': self.geometry_sha, 'prior_interruption_sha256': RECOVERY_PROOF_SHA,
            'recovery_failure_controller_sha256': RECOVERY_FAILURE_SHA,
            'common_source_sha256': {name: self.request[name]['sha256'] for name in (
                'stage_spec', 'expected_inventory', 'budget', 'native_budget', 'cpu_prerequisite', 'native_prerequisite', 'manifest')},
            'coverage': {side: self.request['coverage'][side][str(prompt_bin)] for side in SIDES},
            'profiles': {side: self.endpoints[side, prompt_bin] for side in SIDES if (side, prompt_bin) in self.endpoints}}

    def finish(self):
        for value in {item['path']: item for item in self.checked}.values():
            bound(value)

"""Reserved48 CPU analysis with isolated, reviewed per-bin source profiles."""

SOURCE_SUPPLEMENT_EXECUTION_ENABLED = None
if __name__ == '__main__' and SOURCE_SUPPLEMENT_EXECUTION_ENABLED is not True:
    raise SystemExit('SOURCE_SUPPLEMENT_CPU_REFERENCE_ONLY: inspect the indexed source and review a new execution context')
import argparse
import hashlib
import json
from pathlib import Path
import signal
import sys
from types import ModuleType


PROFILES_SHA = '126ea9cc16b4b84fc9593a2c1e9d120236ee392b6e7cd517134be99280a4a9a7'
profile_source = Path(__file__).resolve().with_name('reserved48_cpu_profiles_v1.py')
profile_raw = profile_source.read_bytes()
if hashlib.sha256(profile_raw).hexdigest() != PROFILES_SHA:
    raise ValueError('reviewed mixed source profile bytes differ')
profiles = ModuleType('_mixed_reserved48_profiles')
profiles.__file__ = str(profile_source)
exec(compile(profile_raw, str(profile_source), 'exec'), profiles.__dict__)


class RoutedArtifacts:
    def __init__(self, plan):
        self.plan = plan

    def __getattr__(self, name):
        return getattr(self.plan.base, name)

    def admit_endpoint(self, endpoint, inventory, stage_sha, expected_sha):
        return self.plan.admit_endpoint(endpoint, inventory, stage_sha, expected_sha)

    def inspect_failure_evidence(self, audit, item, rows, side, prompt_bin):
        return self.plan.inspect_failure_evidence(audit, item, rows, side, prompt_bin)


def reducer(plan):
    return profiles.checked_module(profiles.HERE / 'derive_compare_reserved48_cpu_v2.py', profiles.REDUCER_SHA,
                                   '_mixed_reserved48_reducer', RoutedArtifacts(plan))


def run_bin(plan, prompt_bin, output):
    profiles.require(prompt_bin in profiles.BINS, 'one explicit reviewed prompt bin required')
    result = reducer(plan).run_bin(plan.request, plan.inventory, prompt_bin, output)
    plan.finish()
    envelope = {'schema_version': 1, 'kind': 'reserved48_mixed_cpu_bin_seal', 'task': profiles.TASK,
        'prompt_bin': prompt_bin, 'request': plan.request_ref, 'binding': plan.bin_binding(prompt_bin),
        'bin_report': result, 'helper_sha256': profiles.HELPER_SHA, 'reducer_sha256': profiles.REDUCER_SHA,
        'profiles_sha256': PROFILES_SHA,
        'native_executions_started': 0, 'acceptance': None}
    path = Path(output) / 'bin-provenance.json'
    plan.base.put(path, envelope)
    return plan.base.ref(path)


def bin_report(plan, value):
    document = plan.base.parse(profiles.bound(value))
    prompt_bin = document['prompt_bin']
    profiles.require(document['schema_version'] == 1 and document['kind'] == 'reserved48_mixed_cpu_bin_seal' and
        document['task'] == profiles.TASK and document['helper_sha256'] == profiles.HELPER_SHA and
        document['reducer_sha256'] == profiles.REDUCER_SHA and document['profiles_sha256'] == PROFILES_SHA and
        document['native_executions_started'] == 0 and
        document['acceptance'] is None and document['binding'] == plan.bin_binding(prompt_bin),
        'sealed bin profile/coverage/geometry differs')
    original = plan.base.parse(profiles.bound(document['request']))
    profiles.require(original['kind'] == profiles.KIND and original['task'] == profiles.TASK and
        all(original['coverage'][side][str(prompt_bin)] == plan.request['coverage'][side][str(prompt_bin)]
            for side in profiles.SIDES), 'original seal request is detached from its bin')
    seal_path = Path(value['path']).resolve(strict=True)
    report_ref = document['bin_report']
    profiles.require(seal_path.name == 'bin-provenance.json' and
        Path(report_ref['path']) == seal_path.parent / 'bin-report.json' and
        seal_path.is_relative_to(Path(plan.request['cpu_workspace_root']).resolve(strict=True)),
        'sealed report must be in its owned CPU bin directory')
    raw_report = plan.base.parse(profiles.bound(report_ref))
    profiles.require(raw_report['prompt_bin'] == prompt_bin, 'sealed CPU report belongs to a different bin')
    return prompt_bin, report_ref


def aggregate(plan, seals, output):
    profiles.require(len(seals) <= 4, 'at most four explicit bin seals allowed')
    sealed = dict(bin_report(plan, value) for value in seals)
    profiles.require(len(sealed) == len(seals), 'duplicate sealed prompt bin')
    result = reducer(plan).aggregate(plan.request, plan.inventory, list(sealed.values()), output)
    plan.finish()
    for value in seals:
        bin_report(plan, value)
    envelope = {'schema_version': 1, 'kind': 'reserved48_mixed_cpu_cohort_provenance', 'task': profiles.TASK,
        'request': plan.request_ref, 'geometry_sha256': plan.geometry_sha, 'cohort_report': result,
        'bin_seals': seals, 'bin_bindings': {str(prompt_bin): plan.bin_binding(prompt_bin) for prompt_bin in profiles.BINS},
        'historical_gpu_p8192_interruption': {'prerequisite_sha256': profiles.RECOVERY_PROOF_SHA,
            'original_metadata': plan.request['prior_interruption'], 'observation': plan.prior,
            'numeric_observations_admitted': 0},
        'gpu_p8192_recovery_interruption': plan.recovery_failure,
        'helper_sha256': profiles.HELPER_SHA, 'reducer_sha256': profiles.REDUCER_SHA,
        'profiles_sha256': PROFILES_SHA,
        'native_executions_started': 0, 'acceptance': None}
    path = Path(output) / 'cohort-provenance.json'
    plan.base.put(path, envelope)
    return plan.base.ref(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('bin', 'aggregate'))
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--request-sha256', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--prompt-bin', type=int, choices=profiles.BINS)
    parser.add_argument('--bin-seal', type=Path, action='append', default=[])
    parser.add_argument('--bin-seal-sha256', action='append', default=[])
    args = parser.parse_args()
    profiles.require(sys.platform.startswith('linux') and hasattr(signal, 'SIGALRM'), 'finite Linux CPU execution required')

    def expire(*_):
        raise TimeoutError('reserved48 CPU work exceeded3580s')

    old = signal.signal(signal.SIGALRM, expire)
    signal.setitimer(signal.ITIMER_REAL, 3580)
    try:
        plan = profiles.Plan(args.request.absolute(), args.request_sha256)
        if args.phase == 'bin':
            profiles.require(not args.bin_seal and not args.bin_seal_sha256, 'bin phase takes no aggregate seals')
            result = run_bin(plan, args.prompt_bin, args.output_dir)
        else:
            profiles.require(args.prompt_bin is None and len(args.bin_seal) == len(args.bin_seal_sha256) <= 4,
                'aggregate requires explicit paired bin seal paths and SHA pins')
            seals = [{'path': str(path.absolute()), 'sha256': pin, 'size_bytes': path.stat().st_size}
                     for path, pin in zip(args.bin_seal, args.bin_seal_sha256)]
            result = aggregate(plan, seals, args.output_dir)
        print(json.dumps({'status': 'completed', 'result': result, 'native_executions_started': 0, 'acceptance': None}, indent=2))
        return 0
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, old)


if __name__ == '__main__':
    raise SystemExit(main())

"""Independent CPU replay of all sixteen formal observer score pairs."""

SOURCE_SUPPLEMENT_EXECUTION_ENABLED = None
if __name__ == '__main__' and SOURCE_SUPPLEMENT_EXECUTION_ENABLED is not True:
    raise SystemExit('SOURCE_SUPPLEMENT_CPU_REFERENCE_ONLY: inspect the indexed source and review a new execution context')
import argparse
from datetime import datetime, timezone
import importlib.util
import itertools
import json
import os
from pathlib import Path, PurePosixPath
import signal
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
GPU_E02_SHA = '72a72fe7b24c11c3e3069a22f58eba949c2816595bfd403ac2620f5efad41d37'
FORMAL_CONTROLLER_SHA = '0b1cd5ad8ff034b71f6f8565826b66d78e56815c7762b482e75a8773e7ee039f'
FORMAL_REPORT_SHA = '2cec40e7e8954364b5fceda5037fc81544fbc8c3051a341372647b05124985e1'
STAGE_SHA = '54683b3e1697b8358e7371d516596c42db347ff04de7253231236498ad15e22d'
EXPECTED_SHA = '2f9821d74578735f2d8f1c82ec86c5f28dedc077ae7e293dce474e701cd7181a'
INPUT_SHA = '643d29f23d00f97665c5c72d73c63bc20525950b2ca5c50b435140b6066214f0'
CAPTURE = {
    'GPU':('71538b5c387d56997f5b1bf3553d8f29236f6f1255f63e3943080a3b5bb01765',
           'cec57b3ccc5bba9841cf74256d86937c1427bab1b6264d5126df8326e683a229'),
    'NPU':('639a88fed20d4c0adfc8e42c453ab91cccf06203fbcdb8ccf713b9b5ae995844',
           '5bd682b0c18780941789ecd329c2a3869f8ebeb88729da39df79c03fa3704516'),
}
WORK_SECONDS = 900
MAX_METADATA = 16 * 1024**2


def load_arithmetic():
    path = HERE/'verify_observer_gpu_e02_v3.py'
    import hashlib
    if hashlib.sha256(path.read_bytes()).hexdigest()!=GPU_E02_SHA:
        raise ValueError('frozen independent observer E02 arithmetic source differs')
    spec=importlib.util.spec_from_file_location('_dual_observer_gpu_e02_arithmetic',path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


mathcheck = load_arithmetic()
base = mathcheck.base
require, equal, put, ref = mathcheck.require, mathcheck.equal, mathcheck.put, mathcheck.ref
MODES, POSITIONS, VOCAB = mathcheck.MODES, mathcheck.POSITIONS, mathcheck.VOCAB
ENABLED = ['hooks-only','hooks-plus-dispatch-metadata']


def pair_inventory():
    within=[((s,a),(s,b)) for s in ('GPU','NPU') for a,b in itertools.combinations(MODES,2)]
    cross=[(('GPU',m),('NPU',m)) for m in MODES]
    pairs=within+cross
    samples=[pair for pair in pairs if all(m in ENABLED for s,m in pair)]
    require(len(pairs)==16 and len(samples)==4,'independent score/sample pair inventory differs')
    return pairs,samples


def sides(pair):
    return [backend.lower()+'-'+mode for backend,mode in pair]


def metadata(audit,path,digest):
    p=Path(path)
    require(p.is_absolute() and p.resolve(strict=True)==p and p.is_file() and not p.is_symlink() and
            p.stat().st_size<=MAX_METADATA,'bounded absolute original metadata required')
    return audit.json(p,digest)


class Endpoint(base.Endpoint):
    """Independent original-key lookup and exact NPU retained-array root."""
    def __init__(self,audit,info,backend):
        self.audit,self.backend=audit,backend
        self.path=Path(info['source_map']['path'])
        self.document=metadata(audit,self.path,info['source_map']['sha256'])
        self.files=self.document['files']
        self.root=Path(info['retained_root']) if backend=='NPU' else None
        require((self.root is None or self.root.resolve(strict=True)==self.root and self.root.is_dir()) and
                self.document['schema_version']==1 and self.document['request']=={'task':'OBSERVER','backend':backend,
                    'outer_receipt':info['receipt']['source_path']} and self.document['full_array_hashes_checked']==194 and
                self.document['raw_bytes_preserved'] is True and
                self.document['retained_array_count']==sum(x.get('retained_at_source') is True for x in self.files.values())==
                    (194 if backend=='NPU' else 0),'original observer source-map role differs')

    def locate(self,name,expected=None):
        path,item=super().locate(name,expected)
        require(path.resolve(strict=True)==path,'original source path traverses an alias')
        return path,item

    def json(self,name,expected=None):
        path,item=self.locate(name,expected)
        require(item['size']<=MAX_METADATA,'original metadata exceeds read cap')
        return metadata(self.audit,path,item['sha256'])


def formal(audit,controller_path):
    require(all(isinstance(x,str) and base.HEX.fullmatch(x) for x in (FORMAL_CONTROLLER_SHA,FORMAL_REPORT_SHA)),
            'formal dual original controller/report pins not yet available')
    path=Path(controller_path)
    ctrl=metadata(audit,path,FORMAL_CONTROLLER_SHA)
    require(ctrl['status']=='completed' and ctrl['task']=='OBSERVER-DUAL-CPU' and type(ctrl['returncode']) is int and
            ctrl['returncode']==0 and ctrl['timed_out'] is False and ctrl['remaining_descendants']==[] and
            ctrl['native_executions_started']==0 and ctrl['child_processes_spawned']==0 and ctrl['acceptance'] is None,
            'actual clean completed formal CPU attempt required')
    report_ref=ctrl['report']; spec_ref=ctrl['spec']
    require(report_ref['sha256']==FORMAL_REPORT_SHA and Path(report_ref['path'])==path.parent/'analysis/observer-comparison-report.json'
            and Path(spec_ref['path'])==path.parent/'comparison-spec.json','formal report/spec paths differ')
    report=metadata(audit,report_ref['path'],FORMAL_REPORT_SHA); spec=metadata(audit,spec_ref['path'],spec_ref['sha256'])
    expected_scope={'target_distribution_pairs':16,'distribution_pair_rows':752,'boundary_tensor_comparisons':4,
                    'boundary_tensor_pairs':392,'targets_rederived':1272,'full_vocabulary_rows_rederived':376,
                    'original_large_sources_final_bytehash_checked':388}
    require(report['status']=='observer_raw_bf16_and_sampled_boundary_comparisons_checked' and
            report['comparison_spec_sha256']==spec_ref['sha256'] and report['stage_spec_sha256']==spec['stage_spec_sha256']==STAGE_SHA and
            report['expected_inventory_sha256']==spec['expected_inventory_sha256']==EXPECTED_SHA and
            set(spec['endpoints'])=={'GPU','NPU'} and all(report['scope'].get(k)==v for k,v in expected_scope.items()) and
            report['scope']==ctrl['scope'] and report['thresholds'] is report['acceptance'] is None,
            'formal original report/spec and exact scope differ')
    return ctrl,report,spec


def endpoint_data(audit,info,backend):
    endpoint=Endpoint(audit,info,backend)
    outer_sha,manifest_sha=CAPTURE[backend]
    r=info['receipt']
    require(r['sha256']==outer_sha,'original native capture binding differs')
    outer=endpoint.json(r['source_path'],outer_sha); output=outer['output_dir']
    require(outer['status']=='completed' and outer['native_forward_calls_total']==4 and outer['model_loads']==1 and
            outer['input_sha256']==INPUT_SHA and outer['artifacts_manifest_sha256']==manifest_sha and
            (endpoint.root is None or str(endpoint.root)==output),'original capture geometry differs')
    artifacts=endpoint.json(base.child(output,'artifacts-manifest.json'),manifest_sha)['files']
    expected=endpoint.json(base.child(output,'expected-inventory.json'),EXPECTED_SHA)
    sequence=mathcheck.input_sequence(expected); sample=expected['sample']
    shapes={x['id']:[1,47,64] for x in expected['boundaries']}
    require(len(shapes)==98 and expected['distribution_positions']==POSITIONS and expected['enabled_modes']==ENABLED,
            'independent boundary/token inventory differs')
    expected_names={f'modes/{m}/dist-p{p:03d}.npy' for m in MODES for p in POSITIONS}
    expected_names|={f'modes/{m}/raw-native-logits.safetensors' for m in MODES}
    expected_names|={f'modes/{m}/boundary-samples.safetensors' for m in ENABLED}
    require(len(expected_names)==194 and expected_names=={p for p in artifacts if p.endswith(('.npy','.safetensors'))},
            'original194-file native array inventory differs')
    retained={p for p,x in endpoint.files.items() if x.get('retained_at_source') is True}
    require(retained==({base.child(output,name) for name in expected_names} if backend=='NPU' else set()),
            'retained NPU map differs from exact original artifact manifest')
    large={}
    for name in sorted(expected_names):
        logical=base.child(output,name); item=artifacts[name]
        path=endpoint.get(logical,item['sha256'])
        require(path.stat().st_size==item['size_bytes'],'native manifest size differs')
        large[logical]=item['sha256']
    data={}
    for mode in MODES:
        prefix=f'modes/{mode}/'
        name=prefix+'target-scores.json'
        scores=endpoint.json(base.child(output,name),artifacts[name]['sha256'])
        require(scores['mode']==mode and scores['input_sha256']==INPUT_SHA and len(scores['scores'])==159,
                'exact causal target vector required')
        for p,item in enumerate(scores['scores']):
            require(item['sample']==sample and item['position']==p+1 and item['prediction_position']==p and
                    type(item['token']) is int and item['token']==sequence[p+1],'original causal target differs')
        def original(name):
            relative=prefix+name
            return endpoint.get(base.child(output,relative),artifacts[relative]['sha256'])
        raw=mathcheck.tensor_payload(original('raw-native-logits.safetensors'),{'logits':[1,160,VOCAB]},audit)
        require(raw['BF16_values']==41943040,'original 160xV raw payload geometry differs')
        rows={p:original(f'dist-p{p:03d}.npy') for p in POSITIONS}
        pack=original('boundary-samples.safetensors') if mode in ENABLED else None
        sample_payload=mathcheck.tensor_payload(pack,shapes,audit) if pack else None
        require(sample_payload is None or sample_payload['BF16_values']==294784,'exact sample payload geometry differs')
        data[mode]={'targets':[x['logprob'] for x in scores['scores']],'rows':rows,'pack':pack,
                    'raw_payload':raw,'sample_payload':sample_payload}
    return endpoint,expected,data,large


def replay_scores(audit,pair,a,b,original,coords):
    require(original['sides']==sides(pair) and original['targets']['status']==original['distributions']['status']=='no_thresholds'
            and original['distributions']['position_count']==47 and original['distributions']['renormalization']=='none',
            'formal score pair order/coverage differs')
    target=base.target_metrics(a['targets'],b['targets'],coords)
    for key,value in target.items():
        equal(value,original['targets']['metrics'][key],'target/'+key)
    rows=[]
    shared=original['distributions']['positions']
    require(len(shared)==47,'exact all47 formal rows required')
    for position,claim in zip(POSITIONS,shared):
        audit.tick()
        require(claim['sample']==coords[0]['sample'] and claim['position']==position,'formal distribution coordinate differs')
        result=base.distribution_metrics(base.read_npy(a['rows'][position]),base.read_npy(b['rows'][position]))
        mathcheck.compare_distribution(result,claim)
        rows.append({'sample':claim['sample'],'position':position,**result})
    diagnostics=mathcheck.summarize_distribution(rows,original['distributions']['aggregate'])
    return {'id':original['id'],'sides':sides(pair),'targets':target,'distribution_rows':rows,
            'distribution_maximum_coordinate_diagnostics':diagnostics}


def replay_samples(audit,pair,a,b,original,expected):
    require(original['sides']==sides(pair),'formal sample pair order differs')
    shared=original['metrics']; inventory={x['id']:x for x in expected['boundaries']}
    require(set(shared['per_tensor'])==set(inventory) and len(inventory)==98,'exact all98 formal sample boundaries required')
    global_a=[];global_b=[];tensors={};shape=[1,47,64]
    for key in sorted(inventory):
        audit.tick()
        values=[base.native_values(row['pack'],key,0,3008,shape) for row in (a,b)]
        metric=base.tensor_metrics(*values);claim=shared['per_tensor'][key]
        for field,value in metric.items():
            equal(value,claim[field],key+'/'+field)
        boundary=inventory[key]
        equal(claim['coordinates'],{'sample':expected['sample'],'boundary':key,'module':boundary['module'],'when':boundary['when'],
              'token_indices':POSITIONS,'channel_indices':expected['channels']},key+'/coordinates')
        equal(claim['max_coordinate'],base.unravel(metric['max_flat_index'],shape),key+'/max-coordinate')
        global_a.extend(values[0]);global_b.extend(values[1]);tensors[key]=metric
    total=base.tensor_metrics(global_a,global_b)
    for key,value in total.items():
        equal(value,shared['global'][key],'global sample/'+key)
    ordinal,index=divmod(total['max_flat_index'],3008);key=sorted(inventory)[ordinal]
    equal(shared['global']['max_coordinate'],{'tensor':key,'index':index,'coordinate':base.unravel(index,shape),
          'observation':shared['per_tensor'][key]['coordinates']},'global sample max coordinate')
    return {'id':original['id'],'sides':sides(pair),'per_tensor':tensors,'global':total}


def verify(controller_path,output):
    require(os.name=='posix' and sys.flags.no_site and sys.dont_write_bytecode,'fresh Linux -S -B CPU required')
    require(all(isinstance(x,str) and base.HEX.fullmatch(x) for x in (FORMAL_CONTROLLER_SHA,FORMAL_REPORT_SHA)),
            'actual formal comparison not yet bound')
    output=Path(output)
    require(output.is_absolute() and output.parent.resolve(strict=True)==output.parent and not output.exists() and
            not output.is_symlink(),'exclusive original E02 output required')
    output.mkdir(mode=0o700)
    started=time.monotonic();audit=base.Audit(WORK_SECONDS-20)
    state={'schema_version':1,'task':'OBSERVER-DUAL-E02','status':'running','started_utc':datetime.now(timezone.utc).isoformat(),
           'formal_controller_sha256':FORMAL_CONTROLLER_SHA,'formal_report_sha256':FORMAL_REPORT_SHA,
           'native_executions_started':0,'child_processes_spawned':0,'automatic_retry':False,'acceptance':None}
    def stop(*_):
        raise TimeoutError('observer independent E02 CPU deadline or termination signal')
    handlers={s:signal.signal(s,stop) for s in (signal.SIGALRM,signal.SIGTERM,signal.SIGINT,signal.SIGHUP)}
    signal.setitimer(signal.ITIMER_REAL,WORK_SECONDS-10)
    try:
        put(output/'controller-start.json',state)
        verifier=ref(__file__); gpu_arithmetic=ref(HERE/'verify_observer_gpu_e02_v3.py')
        ctrl,report,spec=formal(audit,controller_path)
        scores,samples=pair_inventory(); endpoints={}; expected={}; data={}; large={}
        for backend in ('GPU','NPU'):
            info=spec['endpoints'][backend]
            require(info['source_map']['sha256']==report['source_map_sha256'][backend],'formal original source-map SHA differs')
            endpoints[backend],expected[backend],data[backend],large[backend]=endpoint_data(audit,info,backend)
        equal(expected['GPU'],expected['NPU'],'same frozen expected geometry')
        originals=set(large['GPU'])|set(large['NPU'])
        require(len(originals)==len({audit.originals[n]['actual_path'] for n in originals})==388 and len(audit.large)==388,
                '388 distinct original/actual large sources required')
        inv=expected['GPU']; sequence=mathcheck.input_sequence(inv)
        coords=[{'sample':inv['sample'],'position':p,'token':sequence[p]} for p in range(1,160)]
        raw_checks=[];sample_checks=[]
        require(len(report['target_distribution_pairs'])==16 and len(report['boundary_sample_comparisons'])==4,
                'formal expected full pair order differs')
        for pair,original in zip(scores,report['target_distribution_pairs']):
            a,b=[data[s][m] for s,m in pair]
            raw_checks.append(replay_scores(audit,pair,a,b,original,coords))
        for pair,original in zip(samples,report['boundary_sample_comparisons']):
            a,b=[data[s][m] for s,m in pair]
            sample_checks.append(replay_samples(audit,pair,a,b,original,inv))
        bits={'within_backend':{},'matched_cross_modes':{}}
        for backend,by_mode in data.items():
            bits['within_backend'][backend]={'raw_logits':mathcheck.same_payloads({m:d['raw_payload'] for m,d in by_mode.items()}),
                'boundary_samples':mathcheck.same_payloads({m:by_mode[m]['sample_payload'] for m in ENABLED})}
        for mode in MODES:
            bits['matched_cross_modes'][mode]={'raw_logits':mathcheck.same_payloads({s:data[s][mode]['raw_payload'] for s in data}),
                'boundary_samples':mathcheck.same_payloads({s:data[s][mode]['sample_payload'] for s in data}) if mode in ENABLED else None}
        for backend in ('GPU','NPU'):
            for name,digest in large[backend].items():
                endpoints[backend].get(name,digest,force=True)
        audit.recheck_small()
        require(ref(__file__)==verifier and ref(HERE/'verify_observer_gpu_e02_v3.py')==gpu_arithmetic and
                mathcheck.sha(HERE/'verify_i03_selected_e02_v1.py')==mathcheck.BASE_SHA and
                not any(n=='numpy' or n=='torch' or n.startswith(('torch.','torch_npu','transformers')) for n in sys.modules),
                'independent CPU arithmetic/source closure differs')
        result={'schema_version':1,'status':'independent_observer_dual_E02_matched',
                'scope':{'target_pairs':16,'distribution_pair_rows':sum(len(x['distribution_rows']) for x in raw_checks),
                         'boundary_tensor_pairs':sum(len(x['per_tensor']) for x in sample_checks),
                         'large_sources':388,'large_hash_passes':2},'source_formal_report':ctrl['report'],
                'source_formal_controller':ref(controller_path),'source_comparison_spec':ctrl['spec'],
                'target_distribution_checks':raw_checks,'boundary_sample_checks':sample_checks,'payload_identity':bits,
                'original_large_sources':{n:audit.originals[n] for n in sorted(originals)},
                'diagnostic_tolerances':{'absolute':base.ATOL,'relative':base.RTOL,'model_acceptance_threshold':None},
                'independent_arithmetic':'Pinned stdlib BF16/FP64 primitives and observer E02 scalar checks; no original comparator calls.',
                'thresholds':None,'acceptance':None,'full_core_complete':False,'native_executions_started':0}
        require(result['scope']['distribution_pair_rows']==752 and result['scope']['boundary_tensor_pairs']==392,
                'independent final E02 pair totals differ')
        report_path=output/'e02-report.json';put(report_path,result)
        state.update(status='completed',returncode=0,timed_out=False,report=ref(report_path),scope=result['scope'])
    except BaseException as exc:
        state.update(status='failed',returncode=124 if isinstance(exc,TimeoutError) else 1,timed_out=isinstance(exc,TimeoutError),
                     error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc())
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        try:
            state.update(finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-started)
            put(output/'controller-receipt.json',state)
        finally:
            for sig,handler in handlers.items():
                signal.signal(sig,handler)
    return state


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--formal-controller',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    state=verify(args.formal_controller,args.output)
    print(json.dumps(state,indent=2),flush=True)
    raise SystemExit(state['returncode'])

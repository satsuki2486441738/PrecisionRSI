"""Copy a byte-exact P128 NPU metadata catalog, counting physical copies once."""

SOURCE_SUPPLEMENT_EXECUTION_ENABLED = None
if __name__ == '__main__' and SOURCE_SUPPLEMENT_EXECUTION_ENABLED is not True:
    raise SystemExit('SOURCE_SUPPLEMENT_CPU_REFERENCE_ONLY: inspect the indexed source and review a new execution context')
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys
from types import ModuleType


V1_SHA = 'ced5aa714d1e967e70f05d4e9d11e628ab58aa9a0a59f45fcf88e22ddd9cbd83'
MAX_COPIED_METADATA = 512 * 1024**2  # Existing Reserved48 transport metadata envelope.
MAX_CATALOG_KEYS = 8192


def load_original(path):
    if path.name != 'reserved48_p128_npu_endpoint_v1.py' or not path.is_file() or path.resolve(strict=True) != path or path.stat().st_size > 1024**2:
        raise ValueError('bounded canonical original endpoint source required')
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != V1_SHA:
        raise ValueError('original endpoint source changed')
    module = ModuleType('_reserved48_p128_original_catalog')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def copy_plan(v1, cat, query, cap=MAX_COPIED_METADATA):
    p = v1.packet
    p.require(0 < len(cat.files) <= MAX_CATALOG_KEYS and 0 < cap <= MAX_COPIED_METADATA,
              'bounded metadata catalog key count/copy budget required')
    files, physical = {}, {}
    aliased_bytes = 0
    retained = set()
    for name, item in sorted(cat.files.items()):
        ref = {key: item[key] for key in ('sha256', 'size', 'roles')}
        if item['large']:
            p.require(item['omitted_large'] and name.endswith('/selected-native-logits.safetensors') and
                      Path(name).is_relative_to(Path(query['output_dir'])), 'only manifest BF16 may stay retained')
            ref['retained_at_source'] = True
            retained.add(name)
        else:
            actual = Path(item['actual'])
            expected = item['sha256'], item['size']
            p.require(actual.is_absolute() and 0 <= item['size'] <= p.MAX_SMALL, 'bounded original metadata copy required')
            if actual not in physical:
                physical[actual] = (f'payload/{len(physical):04d}.bin', expected)
            relative, frozen = physical[actual]
            p.require(expected == frozen, 'original aliases disagree on physical metadata SHA/size')
            ref['path'] = relative
            aliased_bytes += item['size']
        files[name] = ref
    physical_bytes = sum(expected[1] for _, expected in physical.values())
    p.require(retained == cat.large and len(retained) == 36, 'exact retained 36 original descriptors required')
    p.require(physical_bytes <= cap, 'unique physical metadata copies exceed bounded byte cap')
    return files, physical, {'metadata_alias_keys': len(files) - len(retained), 'metadata_aliased_bytes': aliased_bytes,
                             'copied_metadata_objects': len(physical), 'copied_metadata_bytes': physical_bytes,
                             'copied_metadata_cap_bytes': cap}


def stage(v1, query_path, query_sha, destination, cap):
    p = v1.packet
    p.require(sys.platform.startswith('linux') and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,
              'isolated Linux -I -S -B required')
    p.require(destination.is_absolute() and destination.parent.resolve(strict=True) == destination.parent and
              not destination.exists() and not destination.is_symlink() and not destination.is_relative_to(v1.ROOT) and
              shutil.disk_usage(destination.parent).free >= 8 * p.GIB, 'exclusive new metadata destination and 8GiB free required')
    with p.bounded():
        cat, query = v1.source_catalog(query_path, query_sha)
        files, physical, counts = copy_plan(v1, cat, query, cap)
        mapping = {'schema_version': 1, 'request': {'task': 'RESERVED48', 'backend': 'NPU', 'prompt_bin': 128,
                   'outer_receipt': query['capture_receipt']['path']}, 'files': files, 'raw_bytes_preserved': True,
                   'retained_large_objects': 36, 'large_payload_hashes_checked': 0, 'numeric_admission_performed': False}
        p.require(len(p.encode(mapping)) <= p.MAX_SMALL, 'bounded source-map metadata required')
        destination.mkdir(mode=0o700)
        (destination / 'payload').mkdir(mode=0o700)
        for source, (relative, (digest, size)) in physical.items():
            p.require(p.regular(source).stat().st_size == size, 'NPU original metadata size changed before copy')
            with source.open('rb') as stream:
                raw = stream.read(size + 1)
            p.require(len(raw) == size and p.digest(raw) == digest, 'NPU original metadata changed before copy')
            path = destination / relative
            with path.open('xb') as stream:
                stream.write(raw)
            p.require(p.sha(path) == digest, 'copied NPU metadata differs')
        cat.finish()
        path = destination / 'source-map.json'
        p.put(path, mapping)
        receipt = {'status': 'npu_p128_retained_endpoint_metadata_staged_array_hash_pending', 'schema_version': 1,
            'terminal_query': p.ref(query_path), 'source_map': p.ref(path), 'controller': query['controller_receipt'],
            'capture': query['capture_receipt'], 'config': query['prepared_config'], 'retained_root': query['output_dir'],
            **counts, 'original_catalog_source_sha256': V1_SHA, 'metadata_stage_revision': 2,
            'retained_large_objects': 36, 'large_payload_hashes_checked': 0, 'native_executions_started': 0,
            'numeric_admission_performed': False}
        p.put(destination / 'metadata-receipt.json', receipt)
        return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('v1-source', 'query', 'output-dir'):
        parser.add_argument('--' + key, type=Path, required=True)
    parser.add_argument('--query-sha256', required=True)
    parser.add_argument('--metadata-cap-mib', required=True, type=int, choices=range(1, 513), metavar='1..512')
    args = parser.parse_args()
    receipt = stage(load_original(args.v1_source), args.query, args.query_sha256, args.output_dir,
                    args.metadata_cap_mib * 1024**2)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
